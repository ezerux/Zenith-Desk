"""Demo mode: the full UI and API with an in-memory Zammad and Asterisk (no real systems needed).

    Users: anna/pw, boris/pw (operators), boss/pw (supervisor), admin/admin (administrator)

    python -m scripts.demo            # http://localhost:8000  (anna/pw, boris/pw, boss/pw)
    curl -X POST localhost:8000/demo/call?ext=101&number=89123456789   # simulate an incoming call
    curl -X POST "localhost:8000/demo/telegram/message?name=Maria&text=Hello"     # a customer writes to the bot
    curl -X POST "localhost:8000/demo/whatsapp/message?name=Aram&text=Hello"      # … to the WhatsApp number

v3.9: Telegram and WhatsApp work against built-in simulators of their APIs (scripts/sim_messengers.py); mail works
with a real local mail server when one answers on 127.0.0.1:993 (tests/realstack/mailserver.sh) — or DEMO_MAIL=0.
"""
import base64
from pathlib import Path
import socket
import threading
import os
import time
import tempfile
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI

from app.config import Settings
from app.crypto import hash_password
from app.db import Database
from app.main import create_app
from app.models import AgentMapping, AgentState, TicketType
from app.services import Services
from app.zammad import ZammadClient
from scripts.demo_history import seed_history
from tests.fakes import FakePbx, FakeZammad

QUEUES = ["400", "401"]
IFACES = {e: f"Local/{e}@from-queue/n" for e in ("101", "102", "103", "104", "105")}


async def seed(db: Database, fz: FakeZammad) -> None:
    await db.create_all()
    async with db.sessionmaker() as s:
        pw = hash_password("pw")
        s.add_all([
            AgentMapping(id=1, username="anna", password_hash=pw, first_name="Anna", last_name="Petrova",
                         display_name="Anna Petrova", position="Support operator", level="level1", zammad_user_id=10,
                         asterisk_interface=IFACES["101"], extension="101"),
            AgentMapping(id=2, username="boris", password_hash=pw, first_name="Boris", last_name="Ivanov",
                         display_name="Boris Ivanov", position="Sales operator", level="level2", zammad_user_id=11,
                         asterisk_interface=IFACES["102"], extension="102"),
            AgentMapping(id=3, username="boss", password_hash=pw, first_name="Olga", last_name="Sarkisyan",
                         display_name="Olga Sarkisyan", position="Head of support", level="manager", zammad_user_id=20,
                         extension="200", role="supervisor"),
            AgentMapping(id=4, username="admin", password_hash=hash_password("admin"), first_name="System",
                         last_name="Administrator", display_name="System Administrator", position="IT administrator", level="admin",
                         role="admin", enabled=False),
        ])
        await s.flush()
        s.add_all([AgentState(agent_id=i) for i in (1, 2, 3, 4)])
        s.add(TicketType(name="Order", zammad_value="order",
                         required_fields=[{"name": "order_no", "label": "Order number"}]))
        s.add(TicketType(name="Technical issue", zammad_value="incident",
                         required_fields=[{"name": "category", "label": "Category", "type": "select",
                                           "options": ["Access", "Billing", "Hardware"]}]))
        await s.commit()
    seed_zammad(fz)


def seed_zammad(fz: FakeZammad) -> None:
    both = {"Users": ["full"], "Sales": ["full"]}
    fz.add_user(10, "anna", firstname="Anna", lastname="Petrova", email="anna@company.demo")
    fz.add_user(11, "boris", firstname="Boris", lastname="Ivanov", email="boris@company.demo", groups=both)
    fz.add_user(20, "boss", firstname="Olga", lastname="Sarkisyan", email="olga@company.demo", groups=both, roles=["Agent", "Admin"])
    fz.add_user(12, "karen", firstname="Karen", lastname="Petrosyan", email="karen@company.demo", groups=both)
    fz.add_user(13, "lilit", firstname="Lilit", lastname="Hakobyan", email="lilit@company.demo")
    fz.add_user(50, "ivan", firstname="Ivan", lastname="Sidorov", phone="+7 (912) 345-67-89",
                email="ivan@example.com", organization="Acme LLC", note="VIP customer")
    fz.add_user(51, "maria", firstname="Maria", lastname="Kuznetsova", phone="+7 (903) 555-10-20", email="maria@example.com")
    fz.add_user(52, "aram", firstname="Aram", lastname="Grigoryan", phone="+374 91 123456", email="aram@example.am", organization="Ararat Trade")
    fz.add_user(53, "elena", firstname="Elena", lastname="Volkova", email="elena@example.com", organization="Acme LLC")
    fz.add_user(54, "tigran", firstname="Tigran", lastname="Sahakyan", mobile="+374 77 445566", organization="Yerevan Motors")

    def ticket(title, owner, state, channel, customer, msgs, **kw):
        t = fz.add_ticket(title, owner_id=owner, state=state, article_type=channel, customer_id=customer, **kw)
        for who, text, typ in msgs:
            extra = {}
            if who == "Customer":
                cust = fz.users[customer]
                extra["from"] = f"{cust['firstname']} {cust['lastname']} <{cust['email']}>" if typ == "email" else cust.get("phone") or cust["email"]
                if typ == "email":
                    extra["message_id"] = f"<{t['id']}.{len(fz.articles)}@mail.example.com>"
            fz.add_article(t["id"], text, sender=who, type=typ, internal=(typ == "note"),
                           created_by_id=customer if who == "Customer" else owner, **extra)
        return t

    ticket("Invoice email not received", 1, "new", "email", 50, [
        ("Customer", "Hello! I paid order 4512 yesterday, but the invoice e-mail never arrived. Could you resend it?", "email")])
    ticket("Question about delivery", 1, "new", "telegram personal-message", 51, [
        ("Customer", "Hi, when will my parcel arrive? Order 7781.", "telegram personal-message")])
    ticket("I want to change my order", 1, "new", "whatsapp message", 52, [
        ("Customer", "Can I change the colour of the sofa to grey before you ship it?", "whatsapp message")])
    ticket("Onboarding a new employee", 10, "open", "phone", 50, [
        ("Agent", "Call from Ivan: they hired a new accountant, needs access to the portal.", "phone"),
        ("Agent", "Sent the access request to IT, waiting for confirmation.", "note")])
    ticket("Waiting for documents from customer", 10, "pending reminder", "email", 53, [
        ("Customer", "We will send the signed contract next week.", "email"),
        ("Agent", "Thank you, Elena! We will wait for the documents.", "email")], pending_time="2026-10-20T09:00:00Z")
    ticket("Refund for a damaged chair", 10, "open", "email", 54, [
        ("Customer", "The chair arrived with a broken leg. Photos attached. I would like a refund.", "email"),
        ("Agent", "Warehouse confirmed the damage, refund approved by Olga.", "note")], priority="3 high")
    ticket("Corporate discount request", 11, "open", "email", 52, [
        ("Customer", "We plan to buy 40 office chairs. Is there a corporate discount?", "email")], group="Sales")
    ticket("Login problem in the customer portal", 10, "closed", "web", 51, [
        ("Customer", "I cannot log in to the portal.", "web"),
        ("Agent", "Password was reset, the customer confirmed that it works now.", "note")])


# the demo photo a customer sends (a parcel that arrived damaged)
DEMO_JPEG = (Path(__file__).parent / "demo_parcel.jpg").read_bytes()


def start_simulator() -> str:
    """Telegram + WhatsApp API simulators on a free local port (a background thread)."""
    from scripts.sim_messengers import build_sim
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    server = uvicorn.Server(uvicorn.Config(build_sim(), host="127.0.0.1", port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True, name="messenger-simulator").start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    return f"http://127.0.0.1:{port}"


def mail_server_up() -> bool:
    if os.environ.get("DEMO_MAIL") == "0":
        return False
    s = socket.socket()
    s.settimeout(0.5)
    try:
        s.connect(("127.0.0.1", 993))
        return True
    except OSError:
        return False
    finally:
        s.close()


def demo_timezone() -> str:
    """The demo shows "a working day up to now". Shortly after midnight there is no working day yet, so the demo
    picks a time zone where it is daytime now (DEMO_TZ overrides)."""
    from datetime import datetime
    from zoneinfo import ZoneInfo
    if os.environ.get("DEMO_TZ"):
        return os.environ["DEMO_TZ"]
    for tz in ("Europe/Moscow", "Asia/Yerevan", "Asia/Tokyo", "Pacific/Auckland", "America/Sao_Paulo", "America/New_York", "America/Los_Angeles"):
        if 8 <= datetime.now(ZoneInfo(tz)).hour <= 22:
            return tz
    return "Europe/Moscow"


def build() -> FastAPI:
    # DEMO_DB=/path/demo.db keeps the demo data between restarts (default: a fresh database every start)
    db_file = os.environ.get("DEMO_DB") or os.path.join(tempfile.mkdtemp(), "demo.db")
    fresh = not os.path.exists(db_file)
    settings = Settings(_env_file=None, database_url=f"sqlite+aiosqlite:///{db_file}",
                        jwt_secret="demo-secret-demo-secret-demo-secret", zammad_url="http://zammad.demo",
                        managed_queues=",".join(QUEUES), zammad_complete_states="closed,pending close",
                        login_sets_ready=True, phone_enabled=True,
                        # DEMO_PHONE_WSS=ws://…: the real WebRTC phone against a SIP server (tests/e2e_phone.py uses a fake one)
                        phone_mode="webrtc" if os.environ.get("DEMO_PHONE_WSS") else "demo",
                        phone_wss_url=os.environ.get("DEMO_PHONE_WSS", ""), phone_sip_domain="zenith", phone_ice_servers="",
                        display_timezone=demo_timezone(), ui_language=os.environ.get("UI_LANGUAGE", "en"), recording_url_template="https://pbx.demo/rec/{file}")
    from scripts.sim_messengers import TG_TOKEN, WA_PHONE_ID, WA_TOKEN
    sim = start_simulator()
    settings.telegram_enabled, settings.telegram_bot_token, settings.telegram_api_base, settings.telegram_mode = True, TG_TOKEN, sim + "/telegram", "polling"
    settings.whatsapp_enabled, settings.whatsapp_access_token, settings.whatsapp_phone_number_id = True, WA_TOKEN, WA_PHONE_ID
    settings.whatsapp_app_secret, settings.whatsapp_api_base, settings.whatsapp_templates = "demo-app-secret", sim + "/graph", "hello_followup:en,order_ready:ru"
    settings.messenger_quick_replies = ("Greeting | Hello, {name}! Thank you for writing to us. How can I help?\n"
                                        "Delivery | Delivery takes 1–2 working days; the courier calls 30 minutes before.\n"
                                        "Payment | You can pay by card to the courier or online.")
    mail = mail_server_up()
    if mail:
        settings.mail_enabled, settings.mail_protocol, settings.mail_in_host, settings.mail_in_port, settings.mail_in_security = True, "imap", "127.0.0.1", 993, "ssl"
        settings.mail_smtp_host, settings.mail_smtp_port, settings.mail_smtp_security, settings.mail_verify_tls = "127.0.0.1", 587, "starttls", False
        settings.mail_domain = "company.test"
    fz, pbx = FakeZammad(), FakePbx(QUEUES, list(IFACES.values()))
    # DEMO_AMI=host:port:user:secret — a real Asterisk instead of the simulated PBX (tests/realstack/asterisk_e2e.py)
    if os.environ.get("DEMO_AMI"):
        host, port, user, secret = os.environ["DEMO_AMI"].split(":", 3)
        settings.ami_host, settings.ami_port, settings.ami_user, settings.ami_secret = host, int(port), user, secret
        settings.phone_mode, pbx = "webrtc", None
    if os.environ.get("DEMO_RECORDING_DIR"):
        settings.recording_dir = os.environ["DEMO_RECORDING_DIR"]
    db = Database(settings.database_url)
    services = Services(settings, db=db, zammad=ZammadClient(settings.zammad_url, "x", transport=fz.transport()), pbx=pbx)
    app = create_app(settings, services, background=True)
    run = format(int(time.time() * 1000), "x")  # unique per start, so calls never reuse an id of a kept database
    counter = (f"{run}.{n}" for n in range(1, 10**6))

    inner = app.router.lifespan_context

    @asynccontextmanager
    async def lifespan(a):
        if fresh:
            await seed(db, fz)  # seed BEFORE the service starts reconciling
            if os.environ.get("DEMO_PHONE_WSS"):  # SIP passwords of the demo extensions (boris gets a wrong one)
                async with db.sessionmaker() as s:
                    pws = dict(x.split("=", 1) for x in os.environ.get("DEMO_SIP_PASSWORDS", "1=sip-pass-101,2=wrong-password").split(","))
                    for aid, pw in ((int(k), v) for k, v in pws.items()):
                        m = await s.get(AgentMapping, aid)
                        m.sip_secret = services.store.box.encrypt(pw)
                    await s.commit()
            if os.environ.get("DEMO_HISTORY", "1") != "0":
                await seed_history(db)  # a realistic working day for the manager overview
        else:
            seed_zammad(fz)
        async with inner(a):
            if fresh:
                await seed_chats()
            yield

    app.router.lifespan_context = lifespan

    import httpx
    from fastapi import Request

    async def sim_call(path: str, body: dict) -> dict:
        async with httpx.AsyncClient(timeout=10) as c:
            return (await c.post(sim + path, json=body)).json()

    class TellSimulatorWhereWeAre:
        """Like entering the webhook URL at Meta: the WhatsApp simulator learns our address from the first request.
        Pure ASGI (never BaseHTTPMiddleware: it would cancel database work and buffer the live SSE streams)."""

        def __init__(self, inner):
            self.inner, self.done = inner, False

        async def __call__(self, scope, receive, send):
            if scope["type"] == "http" and not self.done:
                self.done = True
                host = dict(scope.get("headers") or []).get(b"host", b"").decode() or "127.0.0.1"
                url = f"{scope.get('scheme', 'http')}://{host}/api/integrations/whatsapp/webhook"
                try:
                    await sim_call("/sim/whatsapp/config", {"webhook_url": url, "app_secret": settings.whatsapp_app_secret})
                except Exception as exc:  # noqa: BLE001
                    print("demo: simulator not told:", exc)
            await self.inner(scope, receive, send)

    app.add_middleware(TellSimulatorWhereWeAre)

    async def seed_chats():
        await sim_call("/sim/telegram/message", {"chat_id": 555001, "first_name": "Maria", "last_name": "Kuznetsova", "username": "maria_k",
                                                 "text": "Hi! The chair arrived with a scratch on the leg 😕"})
        await sim_call("/sim/telegram/message", {"chat_id": 555002, "first_name": "Narine", "last_name": "Avetisyan", "username": "narine_a",
                                                 "text": "Do you have a corporate price list?"})
        wa = {"object": "whatsapp_business_account", "entry": [{"id": "1", "changes": [{"field": "messages", "value": {
            "messaging_product": "whatsapp", "metadata": {"display_phone_number": "37410555000", "phone_number_id": WA_PHONE_ID},
            "contacts": [{"profile": {"name": "Aram Grigoryan"}, "wa_id": "37491123456"}],
            "messages": [{"from": "37491123456", "id": f"wamid.seed{run}1", "timestamp": str(int(time.time()) - 600), "type": "text",
                          "text": {"body": "Hello! I ordered a sofa yesterday, order 55-1209. When will it be delivered?"}}]}}]}]}
        await services.messengers.handle_whatsapp(wa)
        wa["entry"][0]["changes"][0]["value"]["contacts"][0] = {"profile": {"name": "Tigran Sahakyan"}, "wa_id": "37477445566"}
        wa["entry"][0]["changes"][0]["value"]["messages"][0] = {"from": "37477445566", "id": f"wamid.seed{run}2", "timestamp": str(int(time.time())),
                                                                 "type": "text", "text": {"body": "Is the store open on Sunday?"}}
        await services.messengers.handle_whatsapp(wa)
        if mail:
            seed_mail()

    def seed_mail():
        import smtplib
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
        try:
            c = smtplib.SMTP("127.0.0.1", 587, timeout=10)
            c.starttls(context=ctx)
            c.login("client@company.test", "client-mail-3")
            for subj, body in (("Order 4512: invoice please", "Hello Anna,\n\ncould you send the invoice for order 4512 again?\n\nThanks, Narine"),
                               ("Meeting on Thursday", "Hi! Can we move our call to Thursday 15:00?")):
                c.sendmail("client@company.test", ["anna@company.test"],
                           f"From: Narine Avetisyan <client@company.test>\r\nTo: anna@company.test\r\nSubject: {subj}\r\n\r\n{body}".encode())
            c.quit()
        except Exception as exc:  # noqa: BLE001
            print("demo mail seed:", exc)

    @app.post("/demo/telegram/message", tags=["demo"])
    async def demo_tg(name: str = "Maria", text: str = "Hello!", chat_id: int = 555001, username: str = "", photo: bool = False):
        body = {"chat_id": chat_id, "first_name": name, "username": username, "text": text}
        if photo:
            body["photo"] = base64.b64encode(DEMO_JPEG).decode()
        return await sim_call("/sim/telegram/message", body)

    @app.post("/demo/whatsapp/message", tags=["demo"])
    async def demo_wa(request: Request, name: str = "Aram Grigoryan", text: str = "Hello!", phone: str = "37491123456"):
        await sim_call("/sim/whatsapp/config", {"webhook_url": str(request.base_url).rstrip("/") + "/api/integrations/whatsapp/webhook",
                                                 "app_secret": settings.whatsapp_app_secret})
        return await sim_call("/sim/whatsapp/message", {"from": phone, "name": name, "text": text})

    @app.get("/demo/messengers/sent", tags=["demo"])
    async def demo_sent():
        async with httpx.AsyncClient(timeout=10) as c:
            return {"telegram": (await c.get(sim + "/sim/telegram/sent")).json(), "whatsapp": (await c.get(sim + "/sim/whatsapp/sent")).json()}

    @app.post("/demo/call", tags=["demo"])
    async def demo_call(ext: str = "101", number: str = "89123456789"):
        n = next(counter)
        await services.calls.handle_event({"Event": "AgentCalled", "Queue": "400", "Interface": IFACES[ext],
                                           "CallerIDNum": number, "Uniqueid": f"d.{n}", "Linkedid": f"d.{n}"})
        await _ring_softphone(ext, number, f"d.{n}")
        return {"linkedid": f"d.{n}"}

    async def _ring_softphone(ext: str, number: str, linkedid: str) -> None:
        """Demo Zenith Phone: the simulated SIP phone of that extension rings too."""
        async with db.sessionmaker() as s:
            from sqlalchemy import select
            agent = (await s.execute(select(AgentMapping).where(AgentMapping.extension == ext))).scalars().first()
        if agent:
            services.broker.publish_agent(agent.id, "phone_demo", {"type": "incoming", "number": number, "linkedid": linkedid})

    @app.post("/demo/phone", tags=["demo"])
    async def demo_phone(kind: str, ext: str, number: str = "", linkedid: str = ""):
        """What a real PBX would report over AMI for calls of the demo softphone (dial / answered / hangup)."""
        chan = f"PJSIP/{ext}-{linkedid or 'x'}"
        if kind == "dial":
            linkedid = f"p.{next(counter)}"
            await services.calls.handle_event({"Event": "DialBegin", "Channel": f"PJSIP/{ext}-{linkedid}", "DestChannel": "PJSIP/trunk-1",
                                               "DestCallerIDNum": number, "Uniqueid": linkedid, "Linkedid": linkedid})
        elif kind == "answered":
            await services.calls.handle_event({"Event": "DialEnd", "DialStatus": "ANSWER", "Channel": chan, "DestChannel": "PJSIP/trunk-1",
                                               "Uniqueid": linkedid, "Linkedid": linkedid})
        elif kind == "answer_in":
            await services.calls.handle_event({"Event": "AgentConnect", "Queue": "400", "Interface": IFACES.get(ext, ""),
                                               "Uniqueid": linkedid, "Linkedid": linkedid})
        elif kind == "hangup":
            await services.calls.handle_event({"Event": "AgentComplete", "Queue": "400", "Interface": IFACES.get(ext, ""),
                                               "Uniqueid": linkedid, "Linkedid": linkedid})
            await services.calls.handle_event({"Event": "Hangup", "Uniqueid": linkedid, "Linkedid": linkedid})
        return {"linkedid": linkedid}

    @app.post("/demo/phone/ring", tags=["demo"])
    async def demo_phone_ring(ext: str = "101", number: str = "+37491123456"):
        """A direct call to the extension (not via a queue)."""
        n = next(counter)
        await services.calls.handle_event({"Event": "DialBegin", "Channel": "PJSIP/trunk-1", "DestChannel": f"PJSIP/{ext}-r{n}",
                                           "CallerIDNum": number, "Uniqueid": f"r.{n}", "Linkedid": f"r.{n}"})
        await _ring_softphone(ext, number, f"r.{n}")
        return {"linkedid": f"r.{n}"}

    @app.post("/demo/answer", tags=["demo"])
    async def demo_answer(linkedid: str, ext: str = "101"):
        for ev in ("AgentConnect", "AgentComplete"):
            await services.calls.handle_event({"Event": ev, "Queue": "400", "Interface": IFACES[ext],
                                               "Uniqueid": linkedid, "Linkedid": linkedid})
        return {"ok": True}

    @app.post("/demo/zammad/change", tags=["demo"])
    async def demo_zammad_change(ticket: int, owner: int | None = None, state: str | None = None, note: str | None = None):
        """Simulate a colleague changing a ticket directly in Zammad (then Zammad's webhook arrives)."""
        t = fz.tickets[ticket]
        upd: dict = {}
        if owner is not None:
            upd["owner_id"] = owner
        if state:
            upd["state"] = state
        fz._apply_update(t, upd, 20)
        if note:
            fz.add_article(ticket, note, sender="Customer", type="email", **{"from": "customer@example.com"})
        services.desk.kick()
        return {"ok": True, "updated_at": t["updated_at"]}

    @app.post("/demo/zammad/ticket", tags=["demo"])
    async def demo_zammad_ticket(title: str, text: str, customer: int = 54, owner: int = 10, group: str = "Users"):
        """Simulate an e-mail from a customer that became a ticket in Zammad."""
        t = fz.add_ticket(title, owner_id=owner, state="open", article_type="email", customer_id=customer, group=group)
        c = fz.users[customer]
        fz.add_article(t["id"], text, sender="Customer", type="email",
                       **{"from": f"{c['firstname']} {c.get('lastname', '')} <{c['email']}>", "message_id": f"<{t['id']}@mail.example.com>"})
        services.desk.kick()
        return {"id": t["id"], "number": t["number"]}

    @app.post("/demo/zammad/customer", tags=["demo"])
    async def demo_zammad_customer(firstname: str, lastname: str = "", phone: str = "", organization: str = ""):
        """Simulate a customer registered in Zammad."""
        uid = max(fz.users) + 1
        fz.add_user(max(uid, 60), f"c{uid}", firstname=firstname, lastname=lastname, phone=phone, organization=organization,
                    email=f"c{uid}@example.com", roles=["Customer"])
        services.directory.kick()
        return {"id": max(uid, 60)}

    @app.get("/demo/pbx", tags=["demo"])
    async def demo_pbx():
        return pbx.members

    return app


if __name__ == "__main__":
    uvicorn.run(build(), host="0.0.0.0", port=8000)
