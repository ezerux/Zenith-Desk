"""Settings that the administrator edits in the admin panel.

.env only needs DATABASE_URL and JWT_SECRET; everything below can be changed from the UI.
Values saved in the panel override .env defaults. Secrets are encrypted in the database.
"""
import json
import logging
from dataclasses import dataclass, field

from sqlalchemy import select

from .config import Settings
from .crypto import SecretBox
from .db import Database
from .models import SystemSetting

log = logging.getLogger("settings")


@dataclass
class Item:
    key: str
    type: str  # str | int | bool | list | choice | secret
    en: str
    ru: str
    help_en: str = ""
    help_ru: str = ""
    options: list[str] = field(default_factory=list)


GROUPS: list[tuple[str, str, str, list[Item]]] = [
    ("zammad", "Zammad (tickets)", "Zammad (тикеты)", [
        Item("zammad_url", "str", "Zammad URL", "Адрес Zammad", "e.g. https://zammad.company.com", "например https://zammad.company.ru"),
        Item("zammad_token", "secret", "API token", "API-токен",
             "Token of a service user with admin.user and ticket.agent permissions",
             "Токен сервисного пользователя с правами admin.user и ticket.agent"),
        Item("zammad_webhook_secret", "secret", "Webhook signature token (HMAC)", "Токен подписи webhook (HMAC)",
             "The same token as in Zammad → Manage → Webhook", "Тот же токен, что в Zammad → Manage → Webhook"),
        Item("zammad_verify_tls", "bool", "Verify TLS certificate", "Проверять TLS-сертификат"),
        Item("zammad_timeout_sec", "int", "Request timeout, seconds", "Таймаут запроса, сек"),
        Item("zammad_poll_sec", "int", "Check Zammad for ticket changes every N seconds (0 = webhook only)",
             "Проверять изменения тикетов в Zammad каждые N секунд (0 = только webhook)"),
        Item("directory_sync_sec", "int", "Sync customers and Zammad users every N seconds (0 = off)",
             "Синхронизировать клиентов и пользователей Zammad каждые N секунд (0 = выкл.)"),
        Item("attachment_max_mb", "int", "Maximum attachment size, MB", "Максимальный размер вложения, МБ"),
    ]),
    ("telephony", "Telephony (FreePBX / Asterisk AMI)", "Телефония (FreePBX / Asterisk AMI)", [
        Item("ami_host", "str", "AMI host", "Адрес AMI", "IP or hostname of the FreePBX server", "IP или имя сервера FreePBX"),
        Item("ami_port", "int", "AMI port", "Порт AMI"),
        Item("ami_user", "str", "AMI user", "Пользователь AMI"),
        Item("ami_secret", "secret", "AMI password", "Пароль AMI"),
        Item("managed_queues", "list", "Managed queues", "Управляемые очереди",
             "Comma-separated queue numbers, e.g. 400,401", "Номера очередей через запятую, например 400,401"),
        Item("pause_reason", "str", "Pause reason in Asterisk", "Причина паузы в Asterisk"),
        Item("respect_external_pause", "bool", "Do not remove pauses set from the phone", "Не снимать паузу, поставленную с телефона"),
        Item("wrap_up_seconds", "int", "Wrap-up after a call, seconds (0 = off)", "Постобработка после звонка, сек (0 = выкл.)"),
        Item("call_auto_ticket", "choice", "Ticket for every call", "Тикет на каждый звонок",
             "off — the operator creates it with a button; answered — Zenith Desk creates it in Zammad for every answered incoming call",
             "off — оператор создаёт кнопкой; answered — Zenith Desk создаёт его в Zammad на каждый принятый входящий звонок",
             options=["off", "answered"]),
        Item("recording_url_template", "str", "Call recording URL template", "Шаблон ссылки на запись",
             "Placeholders: {file} {date} {uniqueid} {linkedid}", "Подстановки: {file} {date} {uniqueid} {linkedid}"),
    ]),
    ("phone", "Zenith Phone (calls from the browser, WebRTC)", "Zenith Phone (звонки из браузера, WebRTC)", [
        Item("phone_enabled", "bool", "Enable the phone in the browser", "Включить телефон в браузере",
             "Each user also needs an extension and its SIP password (Users → edit)",
             "Каждому сотруднику нужны внутренний номер и его SIP-пароль (Users → изменить)"),
        Item("phone_wss_url", "str", "WebSocket address of FreePBX (WSS)", "WebSocket-адрес FreePBX (WSS)",
             "e.g. wss://pbx.company.com:8089/ws — FreePBX → Settings → Advanced Settings → HTTPS/WebSocket",
             "например wss://pbx.company.ru:8089/ws — FreePBX → Settings → Advanced Settings → HTTPS/WebSocket"),
        Item("phone_sip_domain", "str", "SIP domain (empty = host of the WSS address)", "SIP-домен (пусто = адрес из WSS)"),
        Item("phone_ice_servers", "list", "STUN / TURN servers", "STUN / TURN серверы",
             "Comma separated, e.g. stun:stun.l.google.com:19302, turn:turn.company.com:3478",
             "Через запятую, например stun:stun.l.google.com:19302, turn:turn.company.ru:3478"),
        Item("phone_turn_username", "str", "TURN user (optional)", "Пользователь TURN (необязательно)"),
        Item("phone_turn_password", "secret", "TURN password (optional)", "Пароль TURN (необязательно)"),
        Item("phone_voicemail_number", "str", "Voicemail number (button 📼)", "Номер голосовой почты (кнопка 📼)",
             "FreePBX: *97 — own voicemail", "FreePBX: *97 — своя голосовая почта"),
    ]),
    ("telegram", "Telegram (company bot)", "Telegram (бот компании)", [
        Item("telegram_enabled", "bool", "Receive and answer Telegram chats", "Принимать и отвечать на чаты Telegram",
             "One bot of the company for the whole team: customers write to it, operators answer in Zenith Desk",
             "Один бот компании на всю команду: клиенты пишут ему, операторы отвечают в Zenith Desk"),
        Item("telegram_bot_token", "secret", "Bot token", "Токен бота",
             "From @BotFather → /newbot (or /token for an existing bot), e.g. 7012345678:AAH…",
             "У @BotFather → /newbot (или /token для готового бота), например 7012345678:AAH…"),
        Item("telegram_mode", "choice", "How messages arrive", "Как приходят сообщения",
             "polling — Zenith Desk asks Telegram itself (works without a public address, recommended in a LAN); "
             "webhook — Telegram calls Zenith Desk instantly (needs the public address below). Both have a fallback check.",
             "polling — Zenith Desk сам опрашивает Telegram (работает без внешнего адреса, рекомендуется в локальной сети); "
             "webhook — Telegram сразу вызывает Zenith Desk (нужен внешний адрес ниже). В обоих режимах есть резервная проверка.",
             options=["polling", "webhook"]),
    ]),
    ("whatsapp", "WhatsApp (WhatsApp Business Cloud API)", "WhatsApp (WhatsApp Business Cloud API)", [
        Item("whatsapp_enabled", "bool", "Receive and answer WhatsApp chats", "Принимать и отвечать на чаты WhatsApp",
             "One WhatsApp Business number of the company for the whole team",
             "Один номер WhatsApp Business компании на всю команду"),
        Item("whatsapp_phone_number_id", "str", "Phone number ID", "Phone number ID",
             "Meta for Developers → your app → WhatsApp → API Setup → “Phone number ID”",
             "Meta for Developers → приложение → WhatsApp → API Setup → «Phone number ID»"),
        Item("whatsapp_business_account_id", "str", "WhatsApp Business Account ID", "WhatsApp Business Account ID",
             "Same page, “WhatsApp Business Account ID” (used for templates)", "Там же, «WhatsApp Business Account ID» (для шаблонов)"),
        Item("whatsapp_access_token", "secret", "Access token (permanent, system user)", "Токен доступа (постоянный, системного пользователя)",
             "Business settings → System users → Generate token with whatsapp_business_messaging and whatsapp_business_management",
             "Настройки бизнеса → Системные пользователи → Создать токен с whatsapp_business_messaging и whatsapp_business_management"),
        Item("whatsapp_app_secret", "secret", "App secret (checks the webhooks)", "Секрет приложения (проверка webhook)",
             "App settings → Basic → App secret", "Настройки приложения → Основное → Секрет приложения"),
        Item("whatsapp_api_version", "str", "Graph API version", "Версия Graph API"),
        Item("whatsapp_templates", "list", "Approved message templates (to write after 24 h)", "Одобренные шаблоны (чтобы написать через 24 ч)",
             "WhatsApp allows free text only within 24 h after the customer's last message. Later — only a template: "
             "name:language, e.g. hello_followup:ru, order_ready:en",
             "WhatsApp разрешает свободный текст только 24 ч после последнего сообщения клиента. Позже — только шаблон: "
             "имя:язык, например hello_followup:ru, order_ready:en"),
    ]),
    ("messengers", "Chats: common rules", "Чаты: общие правила", [
        Item("public_url", "str", "Public address of Zenith Desk (for webhooks)", "Внешний адрес Zenith Desk (для webhook)",
             "How Telegram and Meta reach this server from the internet, e.g. https://desk.company.com (HTTPS required)",
             "Как Telegram и Meta достают этот сервер из интернета, например https://desk.company.ru (нужен HTTPS)"),
        Item("messenger_zammad_mirror", "bool", "Every chat is also a ticket in Zammad", "Каждый чат — также тикет в Zammad",
             "The conversation is copied to a Zammad ticket: history, reports, “Start” (blocking / background) as for e-mail",
             "Переписка копируется в тикет Zammad: история, отчёты, «Приступить» (blocking / background) как для почты"),
        Item("messenger_zammad_group", "str", "Zammad group for chat tickets (empty = default)", "Группа Zammad для тикетов чатов (пусто = по умолчанию)"),
        Item("messenger_quick_replies", "text", "Quick replies", "Быстрые ответы",
             "One per line: Title | text. {name} = customer's name", "По одному в строке: Название | текст. {name} = имя клиента"),
        Item("messenger_media_max_mb", "int", "Maximum file size in chats, MB", "Максимальный размер файла в чатах, МБ"),
        Item("messenger_auto_close_days", "int", "Close chats without messages for N days (0 = never)", "Закрывать чаты без сообщений N дней (0 = никогда)"),
    ]),
    ("mail", "E-mail (company mail server)", "Почта (почтовый сервер компании)", [
        Item("mail_enabled", "bool", "Mail in Zenith Desk", "Почта в Zenith Desk",
             "The server is set here once; each employee then only enters own e-mail and password (Mail page)",
             "Сервер настраивается здесь один раз; сотрудник затем вводит только свой e-mail и пароль (раздел «Почта»)"),
        Item("mail_protocol", "choice", "Incoming mail protocol", "Протокол входящей почты",
             "IMAP — folders and read marks stay on the server (recommended); POP3 — mail is downloaded into Zenith Desk",
             "IMAP — папки и отметки о прочтении на сервере (рекомендуется); POP3 — письма загружаются в Zenith Desk",
             options=["imap", "pop3"]),
        Item("mail_in_host", "str", "Incoming server (IMAP / POP3)", "Сервер входящей почты (IMAP / POP3)", "e.g. imap.company.com", "например imap.company.ru"),
        Item("mail_in_port", "int", "Incoming port", "Порт входящей почты", "IMAP: 993 (SSL) or 143 (STARTTLS); POP3: 995 (SSL) or 110", "IMAP: 993 (SSL) или 143 (STARTTLS); POP3: 995 (SSL) или 110"),
        Item("mail_in_security", "choice", "Incoming encryption", "Шифрование входящей", options=["ssl", "starttls", "none"]),
        Item("mail_smtp_host", "str", "Outgoing server (SMTP)", "Сервер исходящей почты (SMTP)", "e.g. smtp.company.com", "например smtp.company.ru"),
        Item("mail_smtp_port", "int", "SMTP port", "Порт SMTP", "465 (SSL) or 587 (STARTTLS)", "465 (SSL) или 587 (STARTTLS)"),
        Item("mail_smtp_security", "choice", "SMTP encryption", "Шифрование SMTP", options=["ssl", "starttls", "none"]),
        Item("mail_smtp_auth", "bool", "SMTP needs the user's login and password", "SMTP требует логин и пароль сотрудника"),
        Item("mail_login_format", "choice", "Login on the mail server", "Логин на почтовом сервере",
             "email — the full address (anna@company.com); local — only the name (anna)",
             "email — полный адрес (anna@company.ru); local — только имя (anna)", options=["email", "local"]),
        Item("mail_domain", "str", "Company mail domain (optional)", "Почтовый домен компании (необязательно)",
             "e.g. company.com — employees may type just “anna”; only addresses of this domain are accepted",
             "например company.ru — можно ввести просто «anna»; принимаются только адреса этого домена"),
        Item("mail_verify_tls", "bool", "Verify the mail server certificate", "Проверять сертификат почтового сервера"),
        Item("mail_save_sent", "bool", "Put a copy of sent mail into “Sent”", "Сохранять отправленные письма в «Отправленные»",
             "Turn off if the server does it itself (Gmail, Microsoft 365)", "Выключите, если сервер делает это сам (Gmail, Microsoft 365)"),
        Item("mail_idle", "bool", "New mail arrives instantly (IMAP IDLE)", "Новые письма приходят сразу (IMAP IDLE)"),
        Item("mail_max_attach_mb", "int", "Maximum attachment size, MB", "Максимальный размер вложения, МБ"),
    ]),
    ("sync", "Background synchronisation", "Фоновая синхронизация", [
        Item("sync_fallback_min", "int", "Fallback check of every integration every N minutes", "Резервная проверка всех интеграций каждые N минут",
             "Real-time events (webhooks, AMI, IMAP IDLE) are the main channel. This check recovers what a network failure "
             "made us miss: Zammad tickets, Asterisk queue states, Telegram updates, WhatsApp delivery, new mail. 5–10 recommended.",
             "Основной канал — события в реальном времени (webhook, AMI, IMAP IDLE). Эта проверка восстанавливает то, что "
             "пропущено из-за сбоев сети: тикеты Zammad, состояния очередей Asterisk, сообщения Telegram, доставку WhatsApp, новые письма. "
             "Рекомендуется 5–10."),
    ]),
    ("tickets", "Tickets and work rules", "Тикеты и правила работы", [
        Item("zammad_state_in_progress", "str", "State set on “Start” (empty = do not change)",
             "Статус при «Приступить» (пусто = не менять)"),
        Item("zammad_complete_states", "list", "States offered on “Complete” (first = default)",
             "Статусы для «Завершить» (первый — по умолчанию)"),
        Item("zammad_final_states", "list", "Final states (ticket is finished)", "Конечные статусы"),
        Item("zammad_pending_states", "list", "Waiting states (customer / third party)", "Статусы ожидания"),
        Item("pending_state_action", "choice", "When a ticket goes to a waiting state", "Когда тикет переходит в ожидание",
             "background: keep as background task; complete: finish the work; none: do nothing",
             "background — оставить фоновой задачей; complete — завершить работу; none — ничего не делать",
             options=["background", "complete", "none"]),
        Item("zammad_default_group", "str", "Default group for new tickets", "Группа по умолчанию для новых тикетов"),
        Item("zammad_ticket_type_attribute", "str", "Ticket attribute holding the type", "Атрибут тикета с типом"),
        Item("zammad_require_ticket_type", "bool", "Require a ticket type before “Start”", "Требовать тип тикета перед «Приступить»"),
        Item("auto_assign_on_start", "bool", "Assign unassigned tickets on “Start”", "Назначать свободный тикет при «Приступить»"),
    ]),
    ("reports", "Manager overview (statistics)", "Обзор руководителя (статистика)", [
        Item("sla_answer_seconds", "int", "Service level: answer within N seconds", "Уровень сервиса: ответ за N секунд",
             "Industry standard 80/20: 80 % of calls answered within 20 s", "Стандарт 80/20: 80 % звонков с ответом за 20 с"),
        Item("sla_target_percent", "int", "Service level target, %", "Цель уровня сервиса, %"),
        Item("short_abandon_seconds", "int", "Short abandon: caller hung up within N seconds (not counted)",
             "Короткий сброс: клиент положил трубку за N секунд (не учитывается)"),
    ]),
    ("privacy", "Data protection and recordings", "Защита данных и записи разговоров", [
        Item("recording_dir", "str", "Folder with FreePBX call recordings", "Папка с записями разговоров FreePBX",
             "e.g. /var/spool/asterisk/monitor mounted read-only into the container. Recordings are then played only through "
             "Zenith Desk: the operator of the call and managers, every playback is in the audit log",
             "например /var/spool/asterisk/monitor, подключённая в контейнер только для чтения. Тогда записи проигрываются "
             "только через Zenith Desk: оператору звонка и руководителям, каждое прослушивание — в журнале аудита"),
        Item("retention_audit_days", "int", "Keep the audit log N days (0 = forever)", "Хранить журнал аудита N дней (0 = всегда)"),
        Item("retention_calls_days", "int", "Keep call records N days (0 = forever)", "Хранить записи о звонках N дней (0 = всегда)"),
        Item("retention_messages_days", "int", "Keep chat and messenger messages N days (0 = forever)", "Хранить сообщения чатов и мессенджеров N дней (0 = всегда)"),
    ]),
    ("general", "General", "Общие", [
        Item("ui_language", "choice", "Interface language", "Язык интерфейса", options=["en", "ru"]),
        Item("display_timezone", "str", "Time zone", "Часовой пояс", "e.g. Europe/Moscow, Asia/Yerevan", "например Europe/Moscow"),
        Item("login_sets_ready", "bool", "Operator is Ready right after sign-in", "Оператор «Готов» сразу после входа"),
        Item("idle_timeout_min", "int", "Pause after inactivity, minutes (0 = off)", "Пауза при бездействии, минут (0 = выкл.)",
             "Nobody touched Zenith Desk for this long: the screen dims, calls stop, managers see the person as offline",
             "Если Zenith Desk не использовали столько минут: экран затемняется, звонки не поступают, руководитель видит «не в сети»"),
        Item("presence_offline_sec", "int", "Offline when the workplace is closed for N seconds (0 = off)",
             "Офлайн, если рабочее место закрыто N секунд (0 = выкл.)"),
        Item("phone_country_code", "str", "Country code for phone numbers", "Код страны для номеров"),
        Item("phone_national_prefix", "str", "National prefix (e.g. 8)", "Национальный префикс (например 8)"),
        Item("admin_alert_webhook_url", "str", "Alert webhook URL (optional)", "URL для оповещений (необязательно)"),
        Item("reconcile_interval_sec", "int", "Reconcile with Asterisk every N seconds", "Сверка с Asterisk каждые N сек"),
        Item("zammad_reconcile_interval_sec", "int", "Reconcile with Zammad every N seconds", "Сверка с Zammad каждые N сек"),
        Item("retry_base_sec", "int", "First retry after an error, seconds", "Первый повтор после ошибки, сек"),
        Item("retry_max_sec", "int", "Maximum retry interval, seconds", "Максимальный интервал повтора, сек"),
    ]),
]

ITEMS: dict[str, Item] = {it.key: it for _, _, _, items in GROUPS for it in items}
ZAMMAD_CONNECTION = {"zammad_url", "zammad_token", "zammad_verify_tls", "zammad_timeout_sec"}
AMI_CONNECTION = {"ami_host", "ami_port", "ami_user", "ami_secret"}
QUEUE_RULES = {"managed_queues", "pause_reason", "respect_external_pause"}
MESSENGER_CONNECTION = {"telegram_enabled", "telegram_bot_token", "telegram_mode", "public_url", "whatsapp_enabled",
                        "whatsapp_phone_number_id", "whatsapp_access_token", "whatsapp_api_version"}
MAIL_CONNECTION = {k for k in ITEMS if k.startswith("mail_")}


# Values the service generates itself and keeps encrypted with the settings (never typed by the administrator)
INTERNAL_SECRETS = {"telegram_webhook_secret", "whatsapp_verify_token"}


class SettingsError(ValueError):
    pass


def _coerce(item: Item, value):
    """Convert a value from the UI into the type stored on Settings."""
    if item.type in ("str", "secret"):
        return "" if value is None else str(value).strip()
    if item.type == "text":
        return "" if value is None else str(value).replace("\r\n", "\n").strip()
    if item.type == "int":
        try:
            v = int(value)
        except (TypeError, ValueError) as exc:
            raise SettingsError(f"{item.key}: number expected") from exc
        if v < 0:
            raise SettingsError(f"{item.key}: must be >= 0")
        return v
    if item.type == "bool":
        if isinstance(value, bool):
            return value
        return str(value).lower() in ("1", "true", "yes", "on")
    if item.type == "list":
        parts = value if isinstance(value, list) else str(value or "").split(",")
        return ",".join(p.strip() for p in parts if str(p).strip())
    if item.type == "choice":
        if value not in item.options:
            raise SettingsError(f"{item.key}: allowed {', '.join(item.options)}")
        return value
    raise SettingsError(f"unknown type {item.type}")


class SettingsStore:
    def __init__(self, db: Database, settings: Settings):
        self.db = db
        self.settings = settings
        self.box = SecretBox(settings.jwt_secret)
        self.from_db: set[str] = set()

    async def load(self) -> None:
        """Apply settings saved in the admin panel on top of .env defaults."""
        async with self.db.sessionmaker() as s:
            rows = (await s.execute(select(SystemSetting))).scalars().all()
        for row in rows:
            item = ITEMS.get(row.key)
            if item is None and row.key in INTERNAL_SECRETS:
                value = self.box.decrypt(row.value)
                if value is not None:
                    setattr(self.settings, row.key, value)
                continue
            if item is None:
                continue
            if row.is_secret:
                value = self.box.decrypt(row.value)
                if value is None:
                    log.error("cannot decrypt setting %s (was JWT_SECRET changed?) — keeping .env value", row.key)
                    continue
            else:
                value = json.loads(row.value)
            setattr(self.settings, row.key, value)
            self.from_db.add(row.key)

    def describe(self, lang: str) -> list[dict]:
        out = []
        for gid, en, ru, items in GROUPS:
            rows = []
            for it in items:
                value = getattr(self.settings, it.key)
                rows.append({
                    "key": it.key, "type": it.type,
                    "label": it.ru if lang == "ru" else it.en,
                    "help": (it.help_ru if lang == "ru" else it.help_en),
                    "options": it.options,
                    "value": "" if it.type == "secret" else value,
                    "has_value": bool(value) if it.type == "secret" else None,
                    "source": "panel" if it.key in self.from_db else "server",
                })
            out.append({"id": gid, "title": ru if lang == "ru" else en, "items": rows})
        return out

    async def save(self, values: dict, user_id: int | None) -> set[str]:
        """Validate, persist and apply. Empty secret = keep the current one. Returns changed keys."""
        clean: dict[str, object] = {}
        for key, raw in values.items():
            item = ITEMS.get(key)
            if item is None:
                raise SettingsError(f"unknown setting {key}")
            if item.type == "secret" and (raw is None or raw == ""):
                continue
            clean[key] = _coerce(item, raw)
        if clean.get("zammad_url") and not str(clean["zammad_url"]).startswith(("http://", "https://")):
            raise SettingsError("zammad_url: must start with http:// or https://")
        if clean.get("public_url") and not str(clean["public_url"]).startswith(("http://", "https://")):
            raise SettingsError("public_url: must start with https://")
        for key in ("mail_in_port", "mail_smtp_port"):
            if key in clean and not 0 < int(clean[key]) < 65536:
                raise SettingsError(f"{key}: 1–65535")
        changed = {k for k, v in clean.items() if getattr(self.settings, k) != v}
        async with self.db.sessionmaker() as s:
            for key in changed:
                item = ITEMS[key]
                stored = self.box.encrypt(str(clean[key])) if item.type == "secret" else json.dumps(clean[key])
                row = await s.get(SystemSetting, key)
                if row is None:
                    row = SystemSetting(key=key)
                    s.add(row)
                row.value, row.is_secret, row.updated_by = stored, item.type == "secret", user_id
            await s.commit()
        for key in changed:
            setattr(self.settings, key, clean[key])
            self.from_db.add(key)
        return changed

    async def save_internal(self, values: dict) -> None:
        """Store generated secrets (webhook tokens) encrypted, like the other secrets."""
        async with self.db.sessionmaker() as s:
            for key, value in values.items():
                if key not in INTERNAL_SECRETS:
                    raise SettingsError(f"unknown internal setting {key}")
                row = await s.get(SystemSetting, key)
                if row is None:
                    row = SystemSetting(key=key)
                    s.add(row)
                row.value, row.is_secret = self.box.encrypt(str(value)), True
                setattr(self.settings, key, value)
            await s.commit()
