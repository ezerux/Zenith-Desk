/* Operator workplace — build-free SPA (Vue 3). Language: UI_LANGUAGE on the server (en | ru). */
const { createApp, reactive, computed, onMounted, h, nextTick, watch } = Vue;

const I18N = {
  en: {
    "app.title": "Zenith Desk",
    "app.subtitle": "Operator Workplace",
    "nav.settings": "Settings", "nav.menu": "Menu", "nav.chat": "Messages",
    "nav.whatsapp": "WhatsApp", "nav.telegram": "Telegram", "msg.soon": "Being prepared",
    "msg.soon_t": "{ch} chats with customers will be here",
    "msg.soon_d": "Customers write to the company's {ch}; Zammad receives the messages through its {ch} channel and keeps them as tickets. Zenith Desk will show them here as live chats: the list of conversations, the history, quick replies and files — your answer goes back to the customer in {ch}.",
    "msg.soon_n": "The look of this page is being agreed. Until then, these chats are in Tickets.", "msg.open_tickets": "Open Tickets",
    "chat.search_results": "Chats and colleagues", "chat.no_chats": "No chats yet — search a colleague by name to start one",
    "chat.edited": "edited", "chat.actions": "Message actions", "chat.copy": "Copy text", "chat.copied": "Copied",
    "chat.edit": "Edit", "chat.editing": "Editing", "chat.save": "Save", "chat.delete": "Delete", "chat.delete_q": "Delete this message?",
    "chat.delete_all": "Also delete for {name}", "chat.delete_me_only": "It will disappear only for you.",
    "push.title": "Notifications when Zenith Desk is closed", "push.hint": "New messages pop up on this computer even with every Zenith Desk tab closed (the browser must be running).",
    "push.enable": "Turn on", "push.disable": "Turn off", "push.enabled": "Background notifications are on for this browser",
    "push.failed": "Could not turn on notifications", "push.banner": "Turn on notifications so you don't miss messages",
    "push.unsupported": "not supported by this browser", "push.insecure": "needs HTTPS", "push.denied": "blocked in browser settings",
    "chat.search": "Search", "chat.you": "You", "chat.typing": "typing…", "chat.online": "online", "chat.away": "away",
    "chat.last_seen": "last seen {t}", "chat.long_ago": "last seen a long time ago", "chat.today": "Today", "chat.yesterday": "Yesterday",
    "chat.write": "Write a message…", "chat.send": "Send", "chat.pick": "Select a chat to start messaging", "chat.back": "Back",
    "chat.info": "User info", "chat.nobody": "Nobody found", "chat.no_people": "No colleagues yet",
    "chat.hello_title": "No messages here yet…", "chat.hello_text": "Say hello to {name}. Messages are saved and stay private between the two of you.",
    "chat.messages_total": "messages together · {w} this week", "chat.member_since": "in Zenith Desk since",
    "idle.title": "Paused — you were away", "idle.text": "Nobody used Zenith Desk for more than {min} minutes, so calls were stopped and your manager sees you as offline. Your tasks are kept.",
    "idle.since": "Away since", "idle.since_short": "since", "idle.back": "I'm back", "idle.tag": "Away",
    "idle.warn": "No activity — you will be paused in {t}. Move the mouse to stay online.",
    "live.on": "Live", "live.lost": "Reconnecting…", "live.connecting": "Connecting…",
    "live.on_hint": "Connected: every change appears here the moment the server receives it",
    "live.lost_hint": "Connection lost — reconnecting automatically; the screen is refreshed as soon as it is back",
    "set.motion": "Animations and smooth transitions", "set.motion_hint": "Turn off on slow computers. Also off automatically when “reduce motion” is enabled in the operating system.",
    "ws.customize": "Customize",
    "ws.editing": "Editing your workspace",
    "ws.hint": "Drag blocks to reorder them, or use ◀ ▶. ⅓ ⅔ ▭ change the width, ↕ the height, ✕ hides a block. Changes are saved automatically.",
    "ws.preset": "Layout",
    "ws.hidden": "Hidden blocks",
    "ws.reset": "Reset to default",
    "ws.done": "Done",
    "ws.drag": "Drag to move", "ws.left": "Move left / up", "ws.right": "Move right / down",
    "ws.width": "Width", "ws.height": "Height", "ws.hide": "Hide block",
    "ws.saved": "Workspace saved",
    "h.auto": "auto", "h.s": "S", "h.m": "M", "h.l": "L",
    "wg.kpis": "Summary cards", "wg.active": "Active tasks", "wg.background": "Background tasks",
    "wg.notifications": "Notifications", "wg.new": "New requests", "wg.mine": "Assigned to me",
    "wg.pending": "Pending", "wg.calls": "Recent calls",
    "preset.default": "Default", "preset.calls": "Calls focus", "preset.tickets": "Tickets focus",
    "preset.compact": "Compact", "preset.focus": "Minimal", "preset.custom": "My layout",
    "preset.default_d": "Command Center: summary strip on top, your work on the left, notifications and calls on the right.",
    "preset.calls_d": "For call-heavy shifts: large recent calls and notifications next to tasks.",
    "preset.tickets_d": "For email / messenger work: wide task and request lists, calls small.",
    "preset.compact_d": "Everything on one screen: dense spacing, short blocks.",
    "preset.focus_d": "Only what you work on now: active tasks, new requests, notifications.",
    "set.title": "My settings",
    "set.appearance": "Appearance",
    "set.theme": "Theme",
    "set.theme_system": "Like the system", "set.theme_light": "Light", "set.theme_dark": "Dark (default)",
    "set.compact": "Compact density (smaller spacing)",
    "set.workspace": "Workspace layout",
    "set.workspace_hint": "Pick a ready layout or arrange the blocks yourself. Saved to your account — the same on any computer.",
    "set.current": "current",
    "set.alerts": "Calls and notifications",
    "set.sound": "Sound signal on an incoming call",
    "set.account": "Account",
    "set.name": "Name", "set.username": "Login", "set.level": "Level", "set.position": "Position", "set.role": "Role",
    "theme.dark": "Dark theme",
    "theme.light": "Light theme",
    "kpi.blocking": "Active tasks",
    "kpi.background": "Background",
    "kpi.done": "Completed today",
    "kpi.calls": "Calls today",
    "kpi.calls_sub": "{a} answered · {m} missed",
    "kpi.busy": "Busy with tasks today",
    "kpi.busy_sub": "calls paused",
    "ntf.title": "Notifications",
    "ntf.empty": "No notifications",
    "ntf.mark_read": "Mark as read",
    "ntf.desktop": "Desktop alerts",
    "ntf.desktop_on": "Desktop alerts are on",
    "sup.assign": "Assign ticket",
    "sup.assign_title": "Assign / reassign a ticket",
    "sup.ticket_number": "Ticket number",
    "sup.assign_to": "Operator",
    "sup.mode": "Start work",
    "sup.mode_none": "No — only assign",
    "sup.k.online": "Online",
    "sup.k.ready": "Ready",
    "sup.k.busy": "Busy",
    "sup.k.break": "On break",
    "sup.k.offline": "Offline",
    "sup.k.sync": "Sync problems",
    "toast.assigned": "Ticket assigned",
    "call.desktop_title": "Incoming call",
    "login.hint": "Sign in with the login issued by your administrator",
    "login.login": "Login",
    "nav.work": "My workplace",
    "nav.sup": "Manager panel",
    "team.all": "All",
    "btn.change_password": "Change password",
    "pw.title": "Change password",
    "pw.forced": "Your administrator asks you to set your own password before you start.",
    "pw.current": "Current password",
    "pw.new": "New password (at least 8 characters)",
    "pw.repeat": "Repeat the new password",
    "pw.mismatch": "Passwords do not match",
    "pw.changed": "Password changed",
    "login.password": "Password",
    "login.submit": "Sign in",
    "ext": "ext.",
    "btn.ready": "Ready",
    "btn.break": "Break",
    "btn.logout": "Sign out",
    "tab.work": "My work",
    "tab.sup": "Supervisor",
    "state.ready": "Ready",
    "state.busy_task": "Busy with a task",
    "state.break": "On break",
    "state.offline": "Offline",
    "state.wrap_up": "Wrap-up",
    "state.ready_unconfirmed": "Ready — not confirmed",
    "state.external_pause": "Paused on the phone",
    "src.phone": "Phone", "src.email": "Email", "src.telegram": "Telegram", "src.whatsapp": "WhatsApp", "src.web": "Web", "src.internal": "Internal",
    "call.ringing": "ringing", "call.answered": "in call", "call.ended": "ended", "call.missed": "missed",
    "banner.sse": "No connection to the server. The state may be outdated — you are not treated as ready until the connection is restored.",
    "banner.sync_error": "Telephony sync error",
    "banner.sync_pending": "Syncing with telephony…",
    "banner.retry_at": "retry at",
    "call.incoming": "Incoming call",
    "call.outgoing": "Outgoing call",
    "call.hidden": "hidden number",
    "call.queue": "queue",
    "call.several": "Several customers found:",
    "call.no_tickets": "No tickets",
    "call.not_found": "Customer not found by this number.",
    "call.create_ticket": "Create ticket from call",
    "call.open_ticket": "Open the call's ticket",
    "call.create_customer": "Create customer",
    "call.hide": "Hide",
    "panel.active": "Active tasks",
    "panel.active_empty": "No blocking tasks — calls come in when you are ready.",
    "panel.background": "My background tasks",
    "panel.background_empty": "No background tasks",
    "panel.new": "New requests",
    "panel.new_empty": "No unassigned tickets",
    "panel.mine": "Assigned to me",
    "panel.mine_empty": "No tickets without active work",
    "panel.pending": "Pending",
    "panel.pending_empty": "No pending tickets",
    "panel.calls": "Recent calls",
    "panel.calls_empty": "No calls yet",
    "tag.blocking": "blocks calls",
    "tag.background": "does not block",
    "since": "since",
    "btn.start": "Start",
    "btn.background": "Background task",
    "btn.complete": "Complete",
    "btn.postpone": "Postpone",
    "btn.remove": "Remove",
    "btn.card": "Card / ticket",
    "link.ticket": "ticket",
    "link.recording": "recording",
    "hidden": "hidden",
    "sup.ami_down": "No connection to Asterisk (AMI). Queue pauses are not managed.",
    "sup.operators": "Operators",
    "sup.refresh": "Refresh",
    "sup.col.operator": "Operator",
    "sup.col.state": "State",
    "sup.col.phone": "Telephony",
    "sup.col.tasks": "Tasks",
    "sup.synced": "synced",
    "sup.cancel": "cancel",
    "sup.reconcile": "Reconcile",
    "sup.override": "Override",
    "sup.report": "Last 24 hours",
    "sup.col.completed": "Completed",
    "sup.col.blocking": "Blocking work",
    "sup.col.background": "Background",
    "sup.col.paused": "Queue paused",
    "sup.col.errors": "Errors",
    "sup.audit": "Audit log",
    "sup.all": "all",
    "sup.operator": "operator",
    "sup.ticket": "ticket",
    "modal.complete": "Complete task",
    "modal.zammad_state": "Ticket state in Zammad",
    "modal.note": "Internal note (optional)",
    "modal.cancel": "Cancel",
    "modal.new_customer": "New customer",
    "modal.firstname": "First name",
    "modal.lastname": "Last name",
    "modal.phone": "Phone",
    "modal.email": "Email",
    "modal.notes": "Note",
    "modal.create": "Create",
    "modal.new_ticket": "New ticket",
    "modal.call_note": "Call details (number, time, call ID, recording) will be added automatically.",
    "modal.customer": "Customer",
    "modal.choose": "— choose —",
    "modal.type": "Type",
    "modal.priority": "Priority",
    "prio.low": "low", "prio.normal": "normal", "prio.high": "high",
    "modal.subject": "Subject",
    "modal.description": "Description",
    "modal.save": "Save",
    "modal.save_bg": "Save as background",
    "modal.save_start": "Save and start",
    "modal.override": "Override",
    "modal.audit_note": "This action is recorded in the audit log.",
    "modal.state": "State",
    "modal.ignore_blocking": "Return to the queue despite blocking tasks",
    "modal.reason": "Reason",
    "modal.apply": "Apply",
    "toast.started_blocking": "Work started — incoming calls are paused",
    "toast.started_background": "Added to background tasks",
    "toast.released": "Stopped working on the ticket",
    "toast.completed": "Task completed",
    "toast.customer_created": "Customer created",
    "toast.ticket_created": "Ticket created",
    "toast.reconciled": "Reconciliation done",
    "toast.override": "Override applied",
    "toast.session_cancelled": "Session cancelled",
    "err.session_expired": "Session expired",
    "err.status": "Error {status}",
    "err.choose_customer": "Choose or create a customer",
    "prompt.cancel": "Cancel work on ticket #{n}? Enter a reason:",
    "dur.h": "h", "dur.min": "min",
  },
  ru: {
    "app.title": "Zenith Desk",
    "app.subtitle": "Рабочее место оператора",
    "nav.settings": "Настройки", "nav.menu": "Меню", "nav.chat": "Сообщения",
    "nav.whatsapp": "WhatsApp", "nav.telegram": "Telegram", "msg.soon": "Готовится",
    "msg.soon_t": "Здесь будут чаты с клиентами в {ch}",
    "msg.soon_d": "Клиенты пишут в {ch} компании; Zammad принимает сообщения через свой канал {ch} и хранит их как тикеты. Zenith Desk покажет их здесь как живые чаты: список диалогов, история, быстрые ответы и файлы — ваш ответ уйдёт клиенту в {ch}.",
    "msg.soon_n": "Вид этой страницы согласовывается. Пока эти чаты доступны в разделе «Тикеты».", "msg.open_tickets": "Открыть тикеты",
    "chat.search_results": "Чаты и коллеги", "chat.no_chats": "Пока нет чатов — найдите коллегу по имени, чтобы начать",
    "chat.edited": "изменено", "chat.actions": "Действия", "chat.copy": "Копировать текст", "chat.copied": "Скопировано",
    "chat.edit": "Изменить", "chat.editing": "Редактирование", "chat.save": "Сохранить", "chat.delete": "Удалить", "chat.delete_q": "Удалить сообщение?",
    "chat.delete_all": "Удалить также у {name}", "chat.delete_me_only": "Сообщение исчезнет только у вас.",
    "push.title": "Уведомления, когда Zenith Desk закрыт", "push.hint": "Новые сообщения появятся на этом компьютере, даже если все вкладки Zenith Desk закрыты (браузер должен быть запущен).",
    "push.enable": "Включить", "push.disable": "Выключить", "push.enabled": "Фоновые уведомления включены для этого браузера",
    "push.failed": "Не удалось включить уведомления", "push.banner": "Включите уведомления, чтобы не пропускать сообщения",
    "push.unsupported": "браузер не поддерживает", "push.insecure": "нужен HTTPS", "push.denied": "запрещены в настройках браузера",
    "chat.search": "Поиск", "chat.you": "Вы", "chat.typing": "печатает…", "chat.online": "в сети", "chat.away": "отошёл",
    "chat.last_seen": "был(а) {t}", "chat.long_ago": "был(а) давно", "chat.today": "Сегодня", "chat.yesterday": "Вчера",
    "chat.write": "Написать сообщение…", "chat.send": "Отправить", "chat.pick": "Выберите, кому хотите написать", "chat.back": "Назад",
    "chat.info": "Информация", "chat.nobody": "Никого не найдено", "chat.no_people": "Пока нет коллег",
    "chat.hello_title": "Здесь пока нет сообщений…", "chat.hello_text": "Напишите {name}. Сообщения сохраняются и видны только вам двоим.",
    "chat.messages_total": "сообщений вместе · {w} за неделю", "chat.member_since": "в Zenith Desk с",
    "idle.title": "Пауза — вы отошли", "idle.text": "Zenith Desk не использовали больше {min} минут, поэтому звонки остановлены, а руководитель видит вас «не в сети». Ваши задачи сохранены.",
    "idle.since": "Нет на месте с", "idle.since_short": "с", "idle.back": "Я вернулся", "idle.tag": "Отошёл",
    "idle.warn": "Нет активности — пауза через {t}. Пошевелите мышью, чтобы остаться в сети.",
    "live.on": "Онлайн", "live.lost": "Переподключение…", "live.connecting": "Подключение…",
    "live.on_hint": "Подключено: любое изменение появляется здесь в момент, когда его получает сервер",
    "live.lost_hint": "Связь потеряна — переподключаемся автоматически; экран обновится сразу после восстановления",
    "set.motion": "Анимации и плавные переходы", "set.motion_hint": "Отключите на медленных компьютерах. Отключаются автоматически, если в системе включено «уменьшение движения».",
    "ws.customize": "Настроить",
    "ws.editing": "Настройка рабочего места",
    "ws.hint": "Перетаскивайте блоки или используйте ◀ ▶. ⅓ ⅔ ▭ — ширина, ↕ — высота, ✕ — скрыть блок. Изменения сохраняются автоматически.",
    "ws.preset": "Раскладка",
    "ws.hidden": "Скрытые блоки",
    "ws.reset": "Сбросить по умолчанию",
    "ws.done": "Готово",
    "ws.drag": "Перетащите, чтобы переместить", "ws.left": "Влево / выше", "ws.right": "Вправо / ниже",
    "ws.width": "Ширина", "ws.height": "Высота", "ws.hide": "Скрыть блок",
    "ws.saved": "Рабочее место сохранено",
    "h.auto": "авто", "h.s": "S", "h.m": "M", "h.l": "L",
    "wg.kpis": "Сводные карточки", "wg.active": "Активные задачи", "wg.background": "Фоновые задачи",
    "wg.notifications": "Уведомления", "wg.new": "Новые обращения", "wg.mine": "Назначены мне",
    "wg.pending": "В ожидании", "wg.calls": "Последние звонки",
    "preset.default": "По умолчанию", "preset.calls": "Фокус на звонках", "preset.tickets": "Фокус на тикетах",
    "preset.compact": "Компактный", "preset.focus": "Минимальный", "preset.custom": "Моя раскладка",
    "preset.default_d": "Командный центр: сводка сверху, работа слева, уведомления и звонки справа.",
    "preset.calls_d": "Для смен с большим потоком звонков: крупные звонки и уведомления рядом с задачами.",
    "preset.tickets_d": "Для работы с почтой и мессенджерами: широкие списки задач и обращений.",
    "preset.compact_d": "Всё на одном экране: плотные отступы, короткие блоки.",
    "preset.focus_d": "Только текущая работа: активные задачи, новые обращения, уведомления.",
    "set.title": "Мои настройки",
    "set.appearance": "Внешний вид",
    "set.theme": "Тема",
    "set.theme_system": "Как в системе", "set.theme_light": "Светлая", "set.theme_dark": "Тёмная (по умолчанию)",
    "set.compact": "Компактный режим (меньше отступов)",
    "set.workspace": "Раскладка рабочего места",
    "set.workspace_hint": "Выберите готовую раскладку или расставьте блоки сами. Сохраняется в учётной записи — одинаково на любом компьютере.",
    "set.current": "текущая",
    "set.alerts": "Звонки и уведомления",
    "set.sound": "Звуковой сигнал при входящем звонке",
    "set.account": "Учётная запись",
    "set.name": "Имя", "set.username": "Логин", "set.level": "Уровень", "set.position": "Должность", "set.role": "Роль",
    "theme.dark": "Тёмная тема",
    "theme.light": "Светлая тема",
    "kpi.blocking": "Активные задачи",
    "kpi.background": "Фоновые",
    "kpi.done": "Завершено сегодня",
    "kpi.calls": "Звонки сегодня",
    "kpi.calls_sub": "{a} принято · {m} пропущено",
    "kpi.busy": "Занят задачами сегодня",
    "kpi.busy_sub": "звонки на паузе",
    "ntf.title": "Уведомления",
    "ntf.empty": "Уведомлений нет",
    "ntf.mark_read": "Прочитано",
    "ntf.desktop": "Уведомления на рабочем столе",
    "ntf.desktop_on": "Уведомления на рабочем столе включены",
    "sup.assign": "Назначить тикет",
    "sup.assign_title": "Назначить / переназначить тикет",
    "sup.ticket_number": "Номер тикета",
    "sup.assign_to": "Оператор",
    "sup.mode": "Начать работу",
    "sup.mode_none": "Нет — только назначить",
    "sup.k.online": "Онлайн",
    "sup.k.ready": "Готовы",
    "sup.k.busy": "Заняты",
    "sup.k.break": "Перерыв",
    "sup.k.offline": "Не в системе",
    "sup.k.sync": "Ошибки синхронизации",
    "toast.assigned": "Тикет назначен",
    "call.desktop_title": "Входящий звонок",
    "login.hint": "Войдите с логином, который выдал администратор",
    "login.login": "Логин",
    "nav.work": "Моё рабочее место",
    "nav.sup": "Панель руководителя",
    "team.all": "Все",
    "btn.change_password": "Сменить пароль",
    "pw.title": "Смена пароля",
    "pw.forced": "Администратор просит задать собственный пароль перед началом работы.",
    "pw.current": "Текущий пароль",
    "pw.new": "Новый пароль (не менее 8 символов)",
    "pw.repeat": "Повторите новый пароль",
    "pw.mismatch": "Пароли не совпадают",
    "pw.changed": "Пароль изменён",
    "login.password": "Пароль",
    "login.submit": "Войти",
    "ext": "вн.",
    "btn.ready": "Готов",
    "btn.break": "Перерыв",
    "btn.logout": "Выход",
    "tab.work": "Моя работа",
    "tab.sup": "Руководитель",
    "state.ready": "Готов",
    "state.busy_task": "Занят задачей",
    "state.break": "Перерыв",
    "state.offline": "Не в системе",
    "state.wrap_up": "Постобработка",
    "state.ready_unconfirmed": "Готов — не подтверждено",
    "state.external_pause": "Пауза на телефоне",
    "src.phone": "Телефон", "src.email": "Email", "src.telegram": "Telegram", "src.whatsapp": "WhatsApp", "src.web": "Веб", "src.internal": "Внутр.",
    "call.ringing": "звонит", "call.answered": "разговор", "call.ended": "завершён", "call.missed": "пропущен",
    "banner.sse": "Нет связи с сервером. Состояние может быть неактуальным — система не считает вас готовым, пока связь не восстановится.",
    "banner.sync_error": "Ошибка синхронизации с телефонией",
    "banner.sync_pending": "Синхронизация с телефонией…",
    "banner.retry_at": "повтор в",
    "call.incoming": "Входящий звонок",
    "call.outgoing": "Исходящий звонок",
    "call.hidden": "скрытый номер",
    "call.queue": "очередь",
    "call.several": "Найдено несколько клиентов:",
    "call.no_tickets": "Тикетов нет",
    "call.not_found": "Клиент не найден по номеру.",
    "call.create_ticket": "Создать тикет по звонку",
    "call.open_ticket": "Открыть тикет звонка",
    "call.create_customer": "Создать клиента",
    "call.hide": "Скрыть",
    "panel.active": "Активные задачи",
    "panel.active_empty": "Нет блокирующих задач — звонки поступают, если вы готовы.",
    "panel.background": "Мои фоновые задачи",
    "panel.background_empty": "Нет фоновых задач",
    "panel.new": "Новые обращения",
    "panel.new_empty": "Нет неназначенных тикетов",
    "panel.mine": "Назначены мне",
    "panel.mine_empty": "Нет тикетов без активной работы",
    "panel.pending": "В ожидании",
    "panel.pending_empty": "Нет тикетов в ожидании",
    "panel.calls": "Последние звонки",
    "panel.calls_empty": "Звонков пока нет",
    "tag.blocking": "блокирует звонки",
    "tag.background": "не блокирует",
    "since": "с",
    "btn.start": "Приступить",
    "btn.background": "Фоновая задача",
    "btn.complete": "Завершить",
    "btn.postpone": "Отложить",
    "btn.remove": "Убрать",
    "btn.card": "Карточка / тикет",
    "link.ticket": "тикет",
    "link.recording": "запись",
    "hidden": "скрытый",
    "sup.ami_down": "Нет соединения с Asterisk (AMI). Паузы в очередях не управляются.",
    "sup.operators": "Операторы",
    "sup.refresh": "Обновить",
    "sup.col.operator": "Оператор",
    "sup.col.state": "Состояние",
    "sup.col.phone": "Телефония",
    "sup.col.tasks": "Задачи",
    "sup.synced": "сверка",
    "sup.cancel": "снять",
    "sup.reconcile": "Сверка",
    "sup.override": "Override",
    "sup.report": "Сводка за 24 часа",
    "sup.col.completed": "Завершено",
    "sup.col.blocking": "Блок. работа",
    "sup.col.background": "Фоновая",
    "sup.col.paused": "Пауза в очереди",
    "sup.col.errors": "Ошибки",
    "sup.audit": "Журнал событий",
    "sup.all": "все",
    "sup.operator": "оператор",
    "sup.ticket": "тикет",
    "modal.complete": "Завершить задачу",
    "modal.zammad_state": "Статус тикета в Zammad",
    "modal.note": "Внутренняя заметка (необязательно)",
    "modal.cancel": "Отмена",
    "modal.new_customer": "Новый клиент",
    "modal.firstname": "Имя",
    "modal.lastname": "Фамилия",
    "modal.phone": "Телефон",
    "modal.email": "Email",
    "modal.notes": "Заметка",
    "modal.create": "Создать",
    "modal.new_ticket": "Новый тикет",
    "modal.call_note": "Данные звонка (номер, время, call ID, запись) будут добавлены автоматически.",
    "modal.customer": "Клиент",
    "modal.choose": "— выберите —",
    "modal.type": "Тип",
    "modal.priority": "Приоритет",
    "prio.low": "низкий", "prio.normal": "обычный", "prio.high": "высокий",
    "modal.subject": "Тема",
    "modal.description": "Описание",
    "modal.save": "Сохранить",
    "modal.save_bg": "Сохранить как фоновую",
    "modal.save_start": "Сохранить и приступить",
    "modal.override": "Override",
    "modal.audit_note": "Действие записывается в журнал аудита.",
    "modal.state": "Состояние",
    "modal.ignore_blocking": "Вернуть в очередь, несмотря на блокирующие задачи",
    "modal.reason": "Причина",
    "modal.apply": "Применить",
    "toast.started_blocking": "Работа начата — входящие звонки приостановлены",
    "toast.started_background": "Добавлено в фоновые задачи",
    "toast.released": "Работа по тикету остановлена",
    "toast.completed": "Задача завершена",
    "toast.customer_created": "Клиент создан",
    "toast.ticket_created": "Тикет создан",
    "toast.reconciled": "Сверка выполнена",
    "toast.override": "Override применён",
    "toast.session_cancelled": "Сессия снята",
    "err.session_expired": "Сессия истекла",
    "err.status": "Ошибка {status}",
    "err.choose_customer": "Выберите или создайте клиента",
    "prompt.cancel": "Снять работу по тикету #{n}? Укажите причину:",
    "dur.h": "ч", "dur.min": "мин",
  },
};

for (const mod of [window.ZenithInbox, window.ZenithMail]) if (mod) { Object.assign(I18N.en, mod.i18n.en); Object.assign(I18N.ru, mod.i18n.ru); }
if (window.ZenithPhone) {
  Object.assign(I18N.en, window.ZenithPhone.i18n.en);
  Object.assign(I18N.ru, window.ZenithPhone.i18n.ru);
}
if (window.AgentixTickets) {
  Object.assign(I18N.en, window.AgentixTickets.i18n.en);
  Object.assign(I18N.ru, window.AgentixTickets.i18n.ru);
}
if (window.AgentixAdmin) {
  Object.assign(I18N.en, window.AgentixAdmin.i18n.en);
  Object.assign(I18N.ru, window.AgentixAdmin.i18n.ru);
}


// ---------------- manager overview (v2.5)
Object.assign(I18N.en, {
  "nav.overview": "Overview",
  "ov.today": "Today", "ov.yesterday": "Yesterday", "ov.7d": "7 days", "ov.30d": "30 days",
  "ov.updated": "updated", "ov.refresh": "Refresh", "ov.loading": "Loading…",
  "ov.offered": "Incoming calls", "ov.answered": "answered", "ov.missed": "missed", "ov.missed_calls": "Missed calls",
  "ov.missed_sub": "{a} abandoned · {u} not answered", "ov.short": "+{n} short abandons (≤{s} s, not counted)",
  "ov.answer_rate": "Answer rate", "ov.abandon_rate": "abandon rate {p}",
  "ov.sl": "Service level", "ov.sl_sub": "answered within {s} s · target {p}",
  "ov.asa": "Avg speed of answer", "ov.longest": "longest wait {v}",
  "ov.aht": "Avg talk time", "ov.talk_total": "total talk {v}",
  "ov.outbound": "Outbound", "ov.outbound_sub": "{c} connected",
  "ov.live": "Right now", "ov.waiting": "waiting in queue", "ov.longest_now": "longest {v}", "ov.talking": "on a call",
  "ov.ready": "ready", "ov.busy": "busy", "ov.break": "on break", "ov.offline": "offline",
  "ov.calls_chart": "Calls by hour", "ov.calls_chart_day": "Calls by day", "ov.peak": "Peak: {l} · {n} calls",
  "ov.load_chart": "Staffing vs workload", "ov.load_agents": "Operators logged in", "ov.load_erl": "Talk load (Erlang)",
  "ov.load_hint": "Average number of operators logged in vs average number of calls in progress. When the two lines meet, everyone is on the phone.",
  "ov.team": "Team", "ov.occupancy": "occupancy", "ov.worked": "{n} operators worked", "ov.logged": "logged in {v}",
  "ov.top_calls": "Most calls answered", "ov.top_tickets": "Most tickets completed", "ov.none_yet": "No data yet",
  "ov.tickets": "Tickets", "ov.t_started": "taken into work", "ov.t_done": "completed", "ov.t_avg": "avg work time",
  "ov.t_active": "in work now: {b} blocking · {g} background",
  "ov.unreturned": "Missed callers not called back", "ov.unreturned_none": "Every missed caller was reached",
  "ov.attempts": "attempts: {n}", "ov.ago": "{n} min ago",
  "ov.agents": "Operators", "ov.sort": "Sort",
  "ov.col.operator": "Operator", "ov.col.now": "Now", "ov.col.logged": "Logged in", "ov.col.ready": "Ready",
  "ov.col.break": "Break", "ov.col.occ": "Occupancy", "ov.col.calls": "Calls", "ov.col.rona": "Not picked up",
  "ov.col.talk": "Talk · avg", "ov.col.tickets": "Tickets", "ov.col.score": "Engagement",
  "ov.calls_fmt": "{a} of {r}",
  "flag.rona": "Does not pick up", "flag.long_breaks": "Long breaks", "flag.low_occupancy": "Low load",
  "flag.rona_d": "The phone rang and the operator did not answer (no colleague had answered yet)",
  "flag.long_breaks_d": "Breaks take more than 20% of logged-in time",
  "flag.low_occupancy_d": "Less than 30% of available time spent on calls and tasks",
  "ov.legend.answered": "Answered", "ov.legend.missed": "Missed",
  "ov.how": "How the numbers are calculated",
  "ov.how.offered": "Incoming calls — customer calls that finished in the period (answered + abandoned + not answered). A call ringing several operators is counted once.",
  "ov.how.short": "Short abandon — the caller hung up within {s} seconds; excluded from all rates (most likely a wrong number).",
  "ov.how.rates": "Answer rate = answered ÷ (calls − short abandons). Service level = answered within {sl} s ÷ (calls − short abandons).",
  "ov.how.asa": "Average speed of answer — mean waiting time in the queue of answered calls. Talk time — from pick-up to hang-up.",
  "ov.how.rona": "Not picked up — the operator's phone rang and the operator did not answer while no colleague had answered yet (a ring cancelled because a colleague answered first is not counted).",
  "ov.how.time": "Logged in / Ready / Break — exact time in each state from the operator's state history. Occupancy = (talk + blocking tasks + wrap-up) ÷ (logged in − break).",
  "ov.how.score": "Engagement = 50% answer reliability (answered ÷ (answered + not picked up)) + 30% presence (1 − break share) + 20% occupancy against an 85% target. Shown after 10 minutes of work.",
  "ov.how.unreturned": "Missed callers not called back — numbers whose missed call was neither answered later nor called back.",
  "ov.how.load": "Workload — average operators logged in per hour vs talk load in Erlang (average number of calls in progress).",
  "dur.s": "s",
});
Object.assign(I18N.ru, {
  "nav.overview": "Обзор",
  "ov.today": "Сегодня", "ov.yesterday": "Вчера", "ov.7d": "7 дней", "ov.30d": "30 дней",
  "ov.updated": "обновлено", "ov.refresh": "Обновить", "ov.loading": "Загрузка…",
  "ov.offered": "Входящие звонки", "ov.answered": "принято", "ov.missed": "пропущено", "ov.missed_calls": "Пропущенные",
  "ov.missed_sub": "{a} сброшено · {u} без ответа", "ov.short": "+{n} коротких сбросов (≤{s} с, не учитываются)",
  "ov.answer_rate": "Доля принятых", "ov.abandon_rate": "доля сбросов {p}",
  "ov.sl": "Уровень сервиса", "ov.sl_sub": "ответ за {s} с · цель {p}",
  "ov.asa": "Среднее время ответа", "ov.longest": "макс. ожидание {v}",
  "ov.aht": "Средний разговор", "ov.talk_total": "всего разговоров {v}",
  "ov.outbound": "Исходящие", "ov.outbound_sub": "{c} дозвонились",
  "ov.live": "Сейчас", "ov.waiting": "ждут в очереди", "ov.longest_now": "дольше всех {v}", "ov.talking": "разговаривают",
  "ov.ready": "готовы", "ov.busy": "заняты", "ov.break": "на перерыве", "ov.offline": "не в сети",
  "ov.calls_chart": "Звонки по часам", "ov.calls_chart_day": "Звонки по дням", "ov.peak": "Пик: {l} · {n} звонков",
  "ov.load_chart": "Операторы и нагрузка", "ov.load_agents": "Операторов в сети", "ov.load_erl": "Нагрузка (Эрланг)",
  "ov.load_hint": "Среднее число операторов в сети и среднее число одновременных разговоров. Когда линии сходятся — заняты все.",
  "ov.team": "Команда", "ov.occupancy": "загрузка", "ov.worked": "работали {n} операторов", "ov.logged": "в сети {v}",
  "ov.top_calls": "Больше всех принял звонков", "ov.top_tickets": "Больше всех закрыл тикетов", "ov.none_yet": "Пока нет данных",
  "ov.tickets": "Тикеты", "ov.t_started": "взято в работу", "ov.t_done": "завершено", "ov.t_avg": "среднее время работы",
  "ov.t_active": "в работе сейчас: {b} blocking · {g} фоновых",
  "ov.unreturned": "Не перезвонили пропущенным", "ov.unreturned_none": "Со всеми пропущенными связались",
  "ov.attempts": "попыток: {n}", "ov.ago": "{n} мин назад",
  "ov.agents": "Операторы", "ov.sort": "Сортировка",
  "ov.col.operator": "Оператор", "ov.col.now": "Сейчас", "ov.col.logged": "В сети", "ov.col.ready": "Готов",
  "ov.col.break": "Перерыв", "ov.col.occ": "Загрузка", "ov.col.calls": "Звонки", "ov.col.rona": "Не взял трубку",
  "ov.col.talk": "Разговор · ср.", "ov.col.tickets": "Тикеты", "ov.col.score": "Вовлечённость",
  "ov.calls_fmt": "{a} из {r}",
  "flag.rona": "Не берёт трубку", "flag.long_breaks": "Долгие перерывы", "flag.low_occupancy": "Мало работы",
  "flag.rona_d": "Телефон звонил, оператор не ответил (коллеги ещё не ответили)",
  "flag.long_breaks_d": "Перерывы занимают больше 20% времени в сети",
  "flag.low_occupancy_d": "Меньше 30% доступного времени — звонки и задачи",
  "ov.legend.answered": "Принято", "ov.legend.missed": "Пропущено",
  "ov.how": "Как считаются показатели",
  "ov.how.offered": "Входящие звонки — звонки клиентов, завершившиеся в периоде (принятые + сброшенные + без ответа). Звонок, который звонил нескольким операторам, считается один раз.",
  "ov.how.short": "Короткий сброс — клиент положил трубку в течение {s} секунд; не учитывается в долях (скорее всего, ошибся номером).",
  "ov.how.rates": "Доля принятых = принятые ÷ (звонки − короткие сбросы). Уровень сервиса = принятые за {sl} с ÷ (звонки − короткие сбросы).",
  "ov.how.asa": "Среднее время ответа — среднее ожидание в очереди у принятых звонков. Разговор — от ответа до завершения.",
  "ov.how.rona": "Не взял трубку — телефон оператора звонил, а он не ответил, пока никто из коллег ещё не ответил (звонок, прерванный из-за ответа коллеги, не считается).",
  "ov.how.time": "В сети / Готов / Перерыв — точное время в каждом состоянии по истории статусов. Загрузка = (разговоры + blocking-задачи + постобработка) ÷ (в сети − перерыв).",
  "ov.how.score": "Вовлечённость = 50% надёжность ответа (принятые ÷ (принятые + не взял трубку)) + 30% присутствие (1 − доля перерывов) + 20% загрузка относительно цели 85%. Считается после 10 минут работы.",
  "ov.how.unreturned": "Не перезвонили — номера, чей пропущенный звонок не был принят позже и по которым не было исходящего звонка.",
  "ov.how.load": "Нагрузка — среднее число операторов в сети за час и нагрузка разговорами в Эрлангах (среднее число одновременных разговоров).",
  "dur.s": "с",
});

let LANG = "en";
let VERSION = "";
function t(key, params) {
  let s = (I18N[LANG] && I18N[LANG][key]) || I18N.en[key] || key;
  if (params) for (const [k, v] of Object.entries(params)) s = s.split(`{${k}}`).join(v);
  return s;
}

function uuid() {
  return (crypto.randomUUID && crypto.randomUUID()) || String(Date.now()) + Math.random().toString(16).slice(2);
}
const WIDGETS = ["kpis", "active", "background", "notifications", "new", "mine", "pending", "calls"];
const W = (id, w, h = "auto", hidden = false) => ({ id, w, h, hidden });
const PRESETS = {
  // Command Center: KPI strip, work column on the left (⅔), live side column on the right (⅓)
  default: { compact: false, layout: [W("kpis", 3), W("active", 2), W("notifications", 1, "m"), W("background", 2), W("calls", 1, "m"), W("new", 2), W("mine", 1), W("pending", 1)] },
  calls: { compact: false, layout: [W("kpis", 3), W("calls", 2, "l"), W("notifications", 1, "l"), W("active", 1, "m"), W("background", 1, "m"), W("new", 1, "m"), W("mine", 1, "s"), W("pending", 1, "s")] },
  tickets: { compact: false, layout: [W("kpis", 3), W("active", 2), W("notifications", 1, "m"), W("new", 2, "l"), W("mine", 1, "l"), W("background", 1), W("pending", 1), W("calls", 1, "s")] },
  compact: { compact: true, layout: [W("kpis", 3), W("active", 1, "s"), W("background", 1, "s"), W("notifications", 1, "s"), W("new", 1, "s"), W("mine", 1, "s"), W("pending", 1, "s"), W("calls", 1, "s")] },
  focus: { compact: false, layout: [W("active", 2), W("notifications", 1, "m"), W("new", 2, "m"), W("background", 1, "m"), W("kpis", 3, "auto", true), W("mine", 1, "auto", true), W("pending", 1, "auto", true), W("calls", 1, "auto", true)] },
};
const clone = (x) => JSON.parse(JSON.stringify(x));
const ICONS = {
  work: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  team: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0"/><circle cx="17" cy="9" r="2.4"/><path d="M15.5 14.2A5 5 0 0 1 21 19"/>',
  users: '<circle cx="12" cy="8" r="3.6"/><path d="M5 20.5a7 7 0 0 1 14 0"/>',
  plug: '<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0zM12 17v4"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.3"/>',
  pulse: '<path d="M3 12h4l3-7 4 14 3-7h4"/>',
  // gear: Lucide "settings" icon (ISC licence)
  gear: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
  out: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9.5h8M8 12.5h5"/>',
  send: '<path d="M4 12l16-8-6 16-2.5-6.5z"/><path d="M11.5 13.5L20 4"/>',
  check: '<path d="M5 12.5l4 4 10-10"/>',
  checks: '<path d="M2 12.5l4 4 10-10"/><path d="M11 16.5l1 0 10-10"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  sidebar: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M15 4v16"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  dnd: '<circle cx="12" cy="12" r="9"/><path d="M7.5 12h9"/>',
  // generic messenger glyphs (not brand logos): a round speech bubble and a paper plane
  wa: '<path d="M12 3.5a8.5 8.5 0 0 1 0 17 8.6 8.6 0 0 1-3.9-.9L3.5 20.5l1.2-4.2A8.5 8.5 0 0 1 12 3.5z"/><circle cx="8.6" cy="12" r=".6"/><circle cx="12" cy="12" r=".6"/><circle cx="15.4" cy="12" r=".6"/>',
  tg: '<path d="M21 4L3 11l6 2.2L18 7l-7.2 7.6.2 5.4 3-3.6 4 3z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5l8.5 6.5 8.5-6.5"/>',
  inbox: '<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1.5 2.5h5L16 13h5"/>',
  clip: '<path d="M20 11l-8.5 8.5a5 5 0 0 1-7-7L13 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L14 7"/>',
  note: '<path d="M5 4h14v12l-4 4H5z"/><path d="M15 20v-4h4"/>',
  reply: '<path d="M10 7L4 12l6 5"/><path d="M4 12h10a6 6 0 0 1 6 6"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="M6 6l12 12"/>',
  folder: '<path d="M3 6h6l2 2h10v11H3z"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
  briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5h6v2M3 13h18"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  at: '<circle cx="12" cy="12" r="4"/><path d="M16 12v1.5a2.5 2.5 0 0 0 5 0V12a9 9 0 1 0-4 7.5"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  popout: '<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1"/>',
  popin: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M14 9l-5 5M9 10v4h4"/>',
  minus: '<path d="M5 12h14"/>',
  spk: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  spkoff: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 10l4 4M21 10l-4 4"/>',
  voicemail: '<circle cx="6.5" cy="12" r="3.5"/><circle cx="17.5" cy="12" r="3.5"/><path d="M6.5 15.5h11"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  micoff: '<path d="M4 4l16 16"/><path d="M9 9v2a3 3 0 0 0 5 2.2M15 9.5V6a3 3 0 0 0-5.7-1.3"/><path d="M5 11a7 7 0 0 0 11.5 5.3M19 11a7 7 0 0 1-.6 2.8M12 18v3"/>',
  pause: '<path d="M9 5v14M15 5v14"/>',
  fwd: '<path d="M14 5l7 7-7 7M21 12H9a6 6 0 0 0-6 6"/>',
  grid: '<circle cx="6" cy="6" r="1.3"/><circle cx="12" cy="6" r="1.3"/><circle cx="18" cy="6" r="1.3"/><circle cx="6" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="18" cy="12" r="1.3"/><circle cx="6" cy="18" r="1.3"/><circle cx="12" cy="18" r="1.3"/><circle cx="18" cy="18" r="1.3"/>',
  ticket: '<path d="M4 6h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4z"/><path d="M14 6v2M14 11v2M14 16v2"/>',
  book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/><circle cx="12" cy="8.5" r="1.8"/>',
};
const Ico = {
  props: { name: String },
  setup(props) { return () => h("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 1.8,
    "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", innerHTML: ICONS[props.name] || "" }); },
};
function normalizeLayout(layout) {
  const seen = new Set(), out = [];
  for (const w of layout || []) if (WIDGETS.includes(w.id) && !seen.has(w.id)) { seen.add(w.id); out.push({ ...W(w.id, 1), ...w }); }
  for (const d of PRESETS.default.layout) if (!seen.has(d.id)) out.push(clone(d));  // blocks added in newer versions
  return out;
}

function loadTheme() { try { return localStorage.getItem("agentix_theme") || ""; } catch { return ""; } }
function applyTheme(theme) {
  document.documentElement.dataset.theme = effectiveTheme(theme);
  try { theme ? localStorage.setItem("agentix_theme", theme) : localStorage.removeItem("agentix_theme"); } catch { /* ignore */ }
}
function effectiveTheme(theme) {
  if (theme === "light" || theme === "dark") return theme;
  if (theme === "system") return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  return "dark";  // default look: dark console
}
applyTheme(loadTheme());

// ---------------- motion (v2.6)
const reduceMotion = () => document.documentElement.dataset.motion === "off" ||
  (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
const canViewTransition = () => typeof document.startViewTransition === "function" && !reduceMotion();
if (typeof document.startViewTransition !== "function") document.documentElement.classList.add("no-vt");
/** Run a DOM change inside a View Transition (visual only: data and DOM change immediately). */
function withTransition(kind, change, opts = {}) {
  if (!canViewTransition()) { change(); return; }
  const root = document.documentElement;
  root.dataset.vt = kind;
  if (opts.dir) root.dataset.dir = opts.dir;
  if (opts.x !== undefined) { root.style.setProperty("--vx", opts.x + "px"); root.style.setProperty("--vy", opts.y + "px"); }
  try {
    const vt = document.startViewTransition(async () => { change(); await nextTick(); });
    vt.ready.catch(() => {}); vt.updateCallbackDone.catch(() => {});  // a skipped transition is not an error
    vt.finished.catch(() => {}).finally(() => { delete root.dataset.vt; delete root.dataset.dir; });
  } catch { change(); delete root.dataset.vt; }
}
function applyMotion(on) { if (on === false) document.documentElement.dataset.motion = "off"; else delete document.documentElement.dataset.motion; }
/** Ripple + press feedback for buttons: the touch point becomes the centre of the wave. */
document.addEventListener("pointerdown", (ev) => {
  const el = ev.target.closest && ev.target.closest(".btn, .seg button, .level-filter button, .preset, .wt");
  if (!el || el.disabled || reduceMotion()) return;
  const r = el.getBoundingClientRect();
  el.style.setProperty("--rx", (ev.clientX - r.left) + "px");
  el.style.setProperty("--ry", (ev.clientY - r.top) + "px");
  // a data attribute, not a class: Vue rewrites `class` when e.g. the pressed chip becomes active
  el.removeAttribute("data-ripple"); void el.offsetWidth; el.setAttribute("data-ripple", "");
  clearTimeout(el._rip); el._rip = setTimeout(() => el.removeAttribute("data-ripple"), 650);
}, { passive: true });
/** v-flash: a value that changes briefly lights up, so live numbers feel alive without moving. */
const flashDirective = {
  mounted(el) { el._txt = el.textContent; },
  updated(el) {
    if (el.textContent === el._txt) return;
    el._txt = el.textContent;
    if (reduceMotion()) return;
    el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
    clearTimeout(el._fl); el._fl = setTimeout(() => el.classList.remove("flash"), 900);
  },
};

function loadToken() { try { return localStorage.getItem("aws_token") || ""; } catch { return ""; } }
function saveToken(v) { try { v ? localStorage.setItem("aws_token", v) : localStorage.removeItem("aws_token"); } catch { /* ignore */ } }

const App = {
  setup() {
    const s = reactive({
      token: loadToken(), me: null, tab: "work", busy: false,
      login: { username: "", password: "" }, loginError: "", pw: { current_password: "", new_password: "", repeat: "", error: "" },
      config: { timezone: "Europe/Moscow", complete_states: ["closed"], ticket_types: [] },
      state: null, tasks: { blocking: [], background: [] }, mine: { active: [], pending: [] }, unassigned: [],
      calls: [], call: null, customers: [], customerCard: null, ticketsError: "",
      toasts: [], modal: null, form: {},
      sup: { agents: [], ami: true, audit: [], report: null, auditAgent: "", level: "" },
      chat: { contacts: [], unread: 0, q: "", peer: null, msgs: [], hasMore: false, loading: false, sending: false,
              info: false, profile: null, typing: {}, drafts: {}, text: "", menu: null, editing: null, del: null },
      push: "off", phoneOpen: false, phone: { status: "off", call: "idle", startedAt: 0, name: "" },
      msgCounts: {}, inOpen: null, mailUnseen: 0, mailOn: false, tkOpen: null, tkNew: null, ctOpen: null,
      ov: { data: null, period: "today", loading: false, updated: null, sort: "engagement", hover: -1, cw: 720 },
      sse: "connecting", liveAt: null, clock: Date.now(), navOpen: false, idleLocal: false, idleWarn: 0, idleSince: null, theme: loadTheme(),
      prefs: { theme: loadTheme(), sound: true, compact: false, motion: true, preset: "default", layout: clone(PRESETS.default.layout) },
      editing: false, dragId: null, overId: null,
      dash: null, ntf: { items: [], unread: 0, seen_at: null }, ntfOpen: false,
      desktop: (window.Notification && Notification.permission) || "unsupported",
    });
    let es = null;
    const locale = LANG === "ru" ? "ru-RU" : "en-GB";

    const stateText = (st) => t(`state.${st}`);
    const srcText = (src) => (src ? t(`src.${src}`) : "");
    const callText = (st) => t(`call.${st}`);

    const fmt = (iso, withDate) => {
      if (!iso) return "";
      try {
        return new Intl.DateTimeFormat(locale, {
          timeZone: s.config.timezone, hour: "2-digit", minute: "2-digit",
          ...(withDate ? { day: "2-digit", month: "2-digit" } : {}),
        }).format(new Date(iso));
      } catch { return iso; }
    };
    const dur = (sec) => {
      sec = Math.max(0, Math.round(sec || 0));
      const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
      return h ? `${h} ${t("dur.h")} ${m} ${t("dur.min")}` : `${m} ${t("dur.min")}`;
    };
    const toast = (text, kind = "", onClick = null) => {
      const item = { id: uuid(), text, kind, onClick };
      s.toasts.push(item);
      setTimeout(() => { s.toasts = s.toasts.filter((x) => x.id !== item.id); }, kind === "error" ? 8000 : kind === "chat" ? 6000 : 4000);
    };
    const toastClick = (x) => { if (x.onClick) { x.onClick(); s.toasts = s.toasts.filter((y) => y.id !== x.id); } };

    async function api(method, path, body, opts = {}) {
      const headers = { "Content-Type": "application/json" };
      if (s.token) headers.Authorization = `Bearer ${s.token}`;
      if (opts.idem) headers["Idempotency-Key"] = opts.idem;
      const r = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
      let data = null;
      try { data = await r.json(); } catch { /* empty */ }
      if (r.status === 401 && path !== "/api/auth/login") { logoutLocal(); throw new Error(t("err.session_expired")); }
      if (!r.ok) {
        const d = data && data.detail;
        const msg = typeof d === "string" ? d : (d && d.message) || (Array.isArray(d) ? d.map((x) => x.msg).join("; ") : t("err.status", { status: r.status }));
        const err = new Error(msg); err.status = r.status; err.detail = d; throw err;
      }
      return data;
    }
    async function act(fn, okKey) {
      if (s.busy) return;
      s.busy = true;
      try { const res = await fn(); if (okKey) toast(t(okKey)); return res; }
      catch (e) { toast(e.message, "error"); }
      finally { s.busy = false; }
    }

    // ------------------------------------------------------------ auth
    async function doLogin() {
      s.loginError = "";
      try {
        const r = await api("POST", "/api/auth/login", s.login);
        s.token = r.token; saveToken(r.token); s.login.password = "";
        await boot();
      } catch (e) { s.loginError = e.message; }
    }
    function logoutLocal() { s.token = ""; s.me = null; saveToken(""); if (es) es.close(); }
    async function logout() { try { await api("POST", "/api/auth/logout"); } catch { /* ignore */ } logoutLocal(); }

    // ------------------------------------------------------------ data
    async function refreshState() { s.state = await api("GET", "/api/agents/me/state"); }
    async function refreshTasks() {
      s.tasks = await api("GET", "/api/agents/me/tasks");
      api("GET", "/api/agents/me/dashboard").then((d) => { s.dash = d; }).catch(() => {});
    }
    async function refreshNotifications() {
      try { s.ntf = await api("GET", "/api/agents/me/notifications?limit=30"); } catch { /* ignore */ }
    }
    async function markRead() {
      try { await api("POST", "/api/agents/me/notifications/seen"); } catch { /* ignore */ }
      s.ntf.seen_at = new Date().toISOString(); s.ntf.unread = 0;
    }
    function toggleNtf() {
      s.ntfOpen = !s.ntfOpen;
      if (s.ntfOpen && s.ntf.unread) markRead();
    }
    const isUnread = (n) => !s.ntf.seen_at || n.ts > s.ntf.seen_at;
    const ntfIcon = (n) => ({ sync: "SY", ticket: "#", override: "MG", call: "CL", account: "AC" }[n.kind] || "•");
    async function enableDesktop() {
      if (!window.Notification) return;
      s.desktop = await Notification.requestPermission();
    }
    function ring(call) {
      if (s.prefs.sound) try {  // short two-tone beep, no audio files needed
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [0, 0.25].forEach((at, i) => {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.frequency.value = i ? 660 : 880; o.connect(g); g.connect(ctx.destination);
          g.gain.setValueAtTime(0.15, ctx.currentTime + at); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + at + 0.2);
          o.start(ctx.currentTime + at); o.stop(ctx.currentTime + at + 0.21);
        });
      } catch { /* audio not allowed */ }
      if (document.hidden && window.Notification && Notification.permission === "granted") {
        try { new Notification(t("call.desktop_title"), { body: call.caller_number || "", tag: "agentix-call" }); } catch { /* ignore */ }
      }
    }
    function toggleTheme(ev) {
      const next = effectiveTheme(s.theme) === "dark" ? "light" : "dark";
      const r = ev && ev.currentTarget && ev.currentTarget.getBoundingClientRect ? ev.currentTarget.getBoundingClientRect() : null;
      withTransition("theme", () => setTheme(next), r ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : { x: 36, y: innerHeight - 160 });
    }
    function setTheme(theme) {
      s.theme = theme; s.prefs.theme = theme; applyTheme(theme);
      if (s.me) savePrefs();
    }
    function toggleMotion() { s.prefs.motion = !s.prefs.motion; applyMotion(s.prefs.motion); savePrefs(); }
    // ---------------- personal preferences & workspace layout
    let saveTimer = null;
    function savePrefs(immediate) {
      clearTimeout(saveTimer);
      const run = () => api("PUT", "/api/agents/me/preferences", s.prefs).catch((e) => toast(e.message, "error"));
      if (immediate) return run();
      saveTimer = setTimeout(run, 500);
    }
    function loadPrefs(p) {
      p = p || {};
      const base = p.layout && p.layout.length ? p.layout : (PRESETS[p.preset] || PRESETS.default).layout;
      s.prefs = { theme: p.theme !== undefined ? p.theme : s.theme, sound: p.sound !== false, compact: !!p.compact,
                  motion: p.motion !== false, preset: p.preset || "default", layout: normalizeLayout(clone(base)) };
      applyMotion(s.prefs.motion);
      if (p.theme !== undefined) { s.theme = s.prefs.theme; applyTheme(s.theme); }
    }
    const presetIds = Object.keys(PRESETS);
    const visibleLayout = computed(() => s.prefs.layout.filter((w) => !w.hidden));
    const hiddenWidgets = computed(() => s.prefs.layout.filter((w) => w.hidden));
    const widgetName = (id) => t(`wg.${id}`);
    function changed() { s.prefs.preset = "custom"; savePrefs(); }
    function applyPreset(name) {
      if (!PRESETS[name]) return;
      s.prefs.layout = normalizeLayout(clone(PRESETS[name].layout));
      s.prefs.compact = PRESETS[name].compact; s.prefs.preset = name;
      savePrefs();
    }
    function moveW(i, dir) {
      const vis = visibleLayout.value, a = vis[i], b = vis[i + dir];
      if (!b) return;
      const L = s.prefs.layout, ia = L.indexOf(a), ib = L.indexOf(b);
      [L[ia], L[ib]] = [L[ib], L[ia]]; changed();
    }
    function setW(w, n) { w.w = n; changed(); }
    function cycleH(w) { const o = ["auto", "s", "m", "l"]; w.h = o[(o.indexOf(w.h) + 1) % o.length]; changed(); }
    function hideW(w) { w.hidden = true; changed(); }
    function showW(w) { w.hidden = false; const L = s.prefs.layout; L.splice(L.indexOf(w), 1); L.push(w); changed(); }
    function dragStart(w, e) { if (!s.editing) return; s.dragId = w.id; try { e.dataTransfer.setData("text/plain", w.id); e.dataTransfer.effectAllowed = "move"; } catch { /* ignore */ } }
    function dropOn(target) {
      const L = s.prefs.layout, from = L.findIndex((x) => x.id === s.dragId), to = L.indexOf(target);
      s.dragId = null; s.overId = null;
      if (from < 0 || to < 0 || from === to) return;
      const [item] = L.splice(from, 1); L.splice(to, 0, item); changed();
    }
    function startEditing() { s.tab = "work"; s.editing = true; s.navOpen = false; }
    function finishEditing() { s.editing = false; savePrefs(true); toast(t("ws.saved")); }
    function toggleSound() { s.prefs.sound = !s.prefs.sound; savePrefs(); }
    function toggleCompact() { s.prefs.compact = !s.prefs.compact; savePrefs(); }
    const levelText = (l) => (l ? t(`level.${l}`) : "");
    async function refreshTickets() {
      const [mine, un] = await Promise.all([api("GET", "/api/agents/me/tickets"), api("GET", "/api/tickets/unassigned")]);
      s.ticketsError = mine.error || un.error || "";
      s.mine = mine; s.unassigned = un.tickets || [];
    }
    async function refreshCalls() { s.calls = await api("GET", "/api/agents/me/calls?limit=15"); }
    async function refreshAll() {
      await Promise.allSettled([refreshState(), refreshTasks(), refreshTickets(), refreshCalls(), refreshNotifications()]);
      if (isSup.value && s.tab === "sup") await refreshSup();
    }
    async function refreshSup() {
      const [a, audit, rep] = await Promise.all([
        api("GET", "/api/admin/agents"),
        api("GET", "/api/admin/audit?limit=60" + (s.sup.auditAgent ? `&agent_id=${s.sup.auditAgent}` : "")),
        api("GET", "/api/admin/reports/summary"),
      ]);
      s.sup.agents = a.agents; s.sup.ami = a.ami_connected; s.sup.audit = audit; s.sup.report = rep;
    }

    // ---------------- live mode (v2.7): the server pushes `changed` after every commit
    const live = { last: Date.now(), timers: {}, backoff: 1000, wasLost: false };
    /** Coalesce a burst of events into one refresh; the first event fixes the moment (bounded delay). */
    function soon(key, fn, ms) {
      if (live.timers[key]) return;
      live.timers[key] = setTimeout(() => { delete live.timers[key]; Promise.resolve().then(fn).catch(() => {}); }, ms);
    }
    async function refreshMe() {
      const m = await api("GET", "/api/auth/me");
      const { prefs, ...rest } = m;  // keep the layout the user may be editing right now
      Object.assign(s.me, rest);
      if (m.must_change_password) s.modal = "password";
      const allowed = { work: isOperatorView.value, tickets: isOperatorView.value, sup: isSup.value, overview: isSup.value };
      if (s.tab in allowed && !allowed[s.tab]) s.tab = isOperatorView.value ? "work" : "users";
    }
    async function refreshConfig() { s.config = await api("GET", "/api/config"); applyPhoneFlag(); }
    function applyPhoneFlag() { document.documentElement.classList.toggle("phone-on", !!(s.config.phone_enabled && isOperatorView.value)); }

    // ---------------- inactivity pause (v2.8)
    // Any mouse / keyboard / touch / scroll in any Zenith Desk tab counts. The server keeps the last moment and is the
    // final judge (it pauses people even if their browser is asleep); the browser just reacts at the exact second.
    const idle = { lastAct: Date.now(), lastSent: 0, lastShared: 0 };
    const IDLE_KEY = "agentix_last_activity";
    function idleTimeoutMs() {
      try { const test = +localStorage.getItem("agentix_idle_test_ms"); if (test > 0) return test; } catch { /* ignore */ }
      return Math.max(0, (s.config.idle_timeout_min || 0) * 60000);
    }
    const isFrozen = computed(() => !!(s.me && (s.idleLocal || (s.state && s.state.idle_since))));
    function markActive() {
      if (!s.me || isFrozen.value) return;
      const now = Date.now();
      idle.lastAct = now; s.idleWarn = 0;
      if (now - idle.lastShared > 5000) { idle.lastShared = now; try { localStorage.setItem(IDLE_KEY, String(now)); } catch { /* ignore */ } }
      if (now - idle.lastSent > 60000) { idle.lastSent = now; api("POST", "/api/agents/me/activity").catch(() => {}); }
    }
    let moveT = 0;
    for (const evName of ["pointerdown", "keydown", "wheel", "touchstart"]) window.addEventListener(evName, markActive, { passive: true });
    window.addEventListener("pointermove", () => { const n = Date.now(); if (n - moveT > 1000) { moveT = n; markActive(); } }, { passive: true });
    setInterval(async () => {
      const limit = idleTimeoutMs();
      if (!s.me || !limit || isFrozen.value || s.modal === "password") { s.idleWarn = 0; return; }
      let last = idle.lastAct;
      try { last = Math.max(last, +localStorage.getItem(IDLE_KEY) || 0); } catch { /* ignore */ }
      const left = limit - (Date.now() - last);
      const warnWindow = Math.min(120000, limit / 2);
      s.idleWarn = left > 0 && left <= warnWindow ? Math.ceil(left / 1000) : 0;
      if (left <= 0) {
        s.idleLocal = true; s.idleSince = new Date().toISOString();
        try { const r = await api("POST", "/api/agents/me/idle"); if (r && r.agent_id === s.me.id) s.state = r; } catch { /* server will do it */ }
      }
    }, 1000);
    async function resumeIdle() {
      try {
        const r = await api("POST", "/api/agents/me/resume");
        s.idleLocal = false; s.idleWarn = 0;
        if (r && r.agent_id === s.me.id) s.state = r; else if (s.state) s.state = { ...s.state, idle_since: null };
        idle.lastAct = idle.lastSent = Date.now();
        try { localStorage.setItem(IDLE_KEY, String(Date.now())); } catch { /* ignore */ }
        if (!isAdmin.value) refreshAll();
      } catch (err) { toast(err.message, "error"); }
    }
    const idleSinceText = computed(() => fmt((s.state && s.state.idle_since) || s.idleSince));
    function onChanged(topics) {
      s.liveAt = new Date().toISOString();
      const op = s.me && !isAdmin.value;
      for (const tp of topics) {
        if (tp === "tasks" && op) soon("tasks", refreshTasks, 30);
        else if (tp === "calls" && op) soon("calls", refreshCalls, 30);
        else if (tp === "notifications" && op) soon("ntf", refreshNotifications, 60);
        else if (tp === "tickets" && op) soon("tickets", refreshTickets, 80);
        else if (tp === "me") soon("me", refreshMe, 30);
        else if (tp === "config") soon("config", refreshConfig, 80);
        else if (tp === "team") {
          if (s.tab === "sup") soon("sup", refreshSup, 100);
          if (s.tab === "overview") soon("ov", () => refreshOverview(true), 250);
        }
      }
      window.dispatchEvent(new CustomEvent("agentix:changed", { detail: { topics } }));  // admin pages listen too
    }
    function resyncAfterReconnect() {
      refreshChatUnread();
      if (s.tab === "chat") { loadContacts().catch(() => {}); if (s.chat.peer) openChat({ id: s.chat.peer }); }
      if (!isAdmin.value) refreshAll();
      if (s.tab === "sup") refreshSup().catch(() => {});
      if (s.tab === "overview") refreshOverview(true);
      window.dispatchEvent(new CustomEvent("agentix:changed", { detail: { topics: ["team", "users", "config"] } }));
    }
    // watchdog: the server sends `ping` every 15 s; silence for 35 s means a dead connection -> reconnect
    setInterval(() => {
      if (s.me && es && Date.now() - live.last > 35000) { s.sse = "lost"; live.wasLost = true; connectSSE(); }
    }, 5000);
    const wake = () => { if (s.me && es && (Date.now() - live.last > 20000 || es.readyState === 2)) { live.wasLost = true; connectSSE(); } };
    window.addEventListener("online", wake);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) wake(); });

    function connectSSE() {
      if (es) es.close();
      s.sse = s.sse === "ok" ? "connecting" : s.sse;
      live.last = Date.now();
      es = new EventSource(`/api/events/stream?token=${encodeURIComponent(s.token)}`);
      const alive = () => { live.last = Date.now(); };
      es.onopen = () => {
        alive(); s.sse = "ok"; live.backoff = 1000;
        resyncAfterReconnect();  // anything that happened while disconnected is loaded now
        live.wasLost = false;
      };
      es.onerror = () => {
        s.sse = "lost"; live.wasLost = true;
        if (es.readyState === 2) {  // the browser gave up (e.g. the session ended): check, then retry with backoff
          api("GET", "/api/auth/me").then(() => {
            const wait = live.backoff; live.backoff = Math.min(live.backoff * 2, 15000);
            setTimeout(() => { if (s.me) connectSSE(); }, wait);
          }).catch(() => {});
        }
      };
      es.addEventListener("hello", alive);
      es.addEventListener("ping", alive);
      es.addEventListener("changed", (ev) => { alive(); onChanged(JSON.parse(ev.data).topics || []); });
      es.addEventListener("chat", (ev) => { alive(); onChatEvent(JSON.parse(ev.data)); });
      es.addEventListener("chat_read", (ev) => { alive(); onChatRead(JSON.parse(ev.data)); });
      es.addEventListener("chat_update", (ev) => { alive(); onChatUpdate(JSON.parse(ev.data)); });
      es.addEventListener("chat_typing", (ev) => { alive(); onChatTyping(JSON.parse(ev.data)); });
      es.addEventListener("agent_state", (e) => {
        live.last = Date.now();
        const d = JSON.parse(e.data);
        if (s.me && d.agent_id === s.me.id) { s.state = d; refreshTasks(); refreshNotifications(); }
        const i = s.sup.agents.findIndex((a) => a.agent_id === d.agent_id);
        if (i >= 0) s.sup.agents[i] = { ...s.sup.agents[i], ...d };
      });
      es.addEventListener("phone_demo", (e) => { alive(); window.dispatchEvent(new CustomEvent("zenith:phone_demo", { detail: JSON.parse(e.data) })); });
      es.addEventListener("call_ringing", (e) => {
        const d = JSON.parse(e.data);
        if (d.call && d.call.direction === "out") { refreshCalls(); return; }  // own call from Zenith Phone: no call card
        s.call = d.call; s.customers = d.customers || []; s.customerCard = null; s.tab = "work";
        if (s.customers.length === 1) openCustomer(s.customers[0].id);
        ring(d.call);
        refreshCalls();
      });
      for (const ev of ["call_answered", "call_ended", "call_missed", "call_updated"]) {
        es.addEventListener(ev, (e) => {
          const d = JSON.parse(e.data);
          window.dispatchEvent(new CustomEvent("zenith:call_update", { detail: d.call }));  // demo phone stops ringing
          if (s.call && s.call.id === d.call.id) s.call = d.call;
          refreshCalls();
          if (ev === "call_missed" || ev === "call_ended") { refreshNotifications(); refreshTasks(); }
        });
      }
      es.addEventListener("alert", (e) => { toast(JSON.parse(e.data).text, "error"); refreshNotifications(); });
      es.addEventListener("ticket_changed", (e) => {
        alive(); const d = JSON.parse(e.data);
        window.dispatchEvent(new CustomEvent("agentix:ticket_changed", { detail: d }));
        if (!isAdmin.value) soon("tickets", refreshTickets, 150);
      });
      es.addEventListener("ticket_assigned", (e) => {
        alive(); const d = JSON.parse(e.data);
        toast(t("tk.assigned_toast", { by: d.by || "Zammad", n: d.number }), "chat", () => openTicket(d.ticket_id));
        ring({ caller_number: "#" + d.number });
        refreshNotifications();
      });
      // v3.9 chats (Telegram / WhatsApp) and e-mail
      es.addEventListener("msg", (e) => {
        alive(); const d = JSON.parse(e.data);
        window.dispatchEvent(new CustomEvent("zenith:msg", { detail: d }));
        soon("msgcounts", refreshMsgCounts, 300);
      });
      es.addEventListener("msg_new", (e) => {
        alive(); const d = JSON.parse(e.data);
        const here = (s.tab === "whatsapp" || s.tab === "telegram") && !document.hidden;
        if (!here) {
          toast(d.assigned_by ? t("in.tr_done", { name: s.me.name }) + " · " + d.name : t("in.new_msg", { ch: d.channel === "whatsapp" ? "WhatsApp" : "Telegram", name: d.name }) + (d.text ? ": " + d.text : ""),
                "chat", () => openConversation(d.conversation_id, d.channel));
          ring({ caller_number: d.name });
        }
        soon("msgcounts", refreshMsgCounts, 300);
      });
      es.addEventListener("mail", (e) => {
        alive(); const d = JSON.parse(e.data);
        s.mailUnseen = d.unseen || 0;
        window.dispatchEvent(new CustomEvent("zenith:mail", { detail: d }));
      });
      es.addEventListener("mail_new", (e) => {
        alive(); const d = JSON.parse(e.data);
        s.mailUnseen = d.unseen || s.mailUnseen;
        if (s.tab !== "mail" || document.hidden) toast(t("ml.new_mail", { from: d.from || "?" }) + (d.subject ? ": " + d.subject : ""), "chat", () => setTab("mail"));
        window.dispatchEvent(new CustomEvent("zenith:mail", { detail: d }));
      });
      es.addEventListener("directory_new", (e) => {
        alive(); const d = JSON.parse(e.data);
        for (const p of (d.items || []).slice(0, 3)) toast(t("ct.new_toast", { name: p.name }), "chat", () => openContact(p.id, p.kind === "staff" ? "staff" : "customers"));
      });
    }

    async function boot() {
      try {
        s.me = await api("GET", "/api/auth/me");
        loadPrefs(s.me.prefs);
        if (s.me.must_change_password) { s.modal = "password"; return; }
        s.config = await api("GET", "/api/config");
        applyPhoneFlag();
        refreshChatUnread();
        refreshMsgCounts();
        refreshMail();
        registerSW().then(refreshPushState);
        const openId = +new URLSearchParams(location.search).get("chat");
        if (openId) { history.replaceState(null, "", "/"); setTab("chat"); openChat({ id: openId }); }
        const openTk = +new URLSearchParams(location.search).get("ticket");
        if (openTk) { history.replaceState(null, "", "/"); if (s.me.role !== "admin") openTicket(openTk); }
        if (s.me.role === "admin" && ["work"].includes(s.tab)) s.tab = "users";
        if (s.me.role !== "admin") await refreshAll();
        connectSSE();
      } catch (e) { if (s.token) toast(e.message, "error"); }
    }

    // ------------------------------------------------------------ operator actions
    const goReady = () => act(async () => { s.state = await api("POST", "/api/agents/me/ready", undefined, { idem: uuid() }); });
    const goBreak = () => act(async () => { s.state = await api("POST", "/api/agents/me/break", { reason: "" }, { idem: uuid() }); });

    function startTicket(tk, mode) {
      return act(async () => {
        const r = await api("POST", `/api/tickets/${tk.id || tk.ticket_id}/start`, { work_mode: mode }, { idem: uuid() });
        if (r.agent_state) s.state = r.agent_state;
        await Promise.all([refreshTasks(), refreshTickets()]);
      }, mode === "blocking" ? "toast.started_blocking" : "toast.started_background");
    }
    const changeMode = (sess, mode) => act(async () => {
      const r = await api("POST", `/api/tickets/${sess.ticket_id}/mode`, { work_mode: mode }, { idem: uuid() });
      if (r.agent_state) s.state = r.agent_state;
      await refreshTasks();
    });
    const release = (sess) => act(async () => {
      const r = await api("POST", `/api/tickets/${sess.ticket_id}/release`, { reason: "released" });
      s.state = r.agent_state; await Promise.all([refreshTasks(), refreshTickets()]);
    }, "toast.released");

    function openComplete(sess) {
      s.form = { ticket_id: sess.ticket_id, title: `#${sess.ticket_number} ${sess.ticket_title}`, ticket_state: s.config.complete_states[0], note: "", idem: uuid() };
      s.modal = "complete";
    }
    const submitComplete = () => act(async () => {
      const f = s.form;
      const r = await api("POST", `/api/tickets/${f.ticket_id}/complete`, { ticket_state: f.ticket_state, note: f.note || null }, { idem: f.idem });
      s.state = r.agent_state; s.modal = null;
      await Promise.all([refreshTasks(), refreshTickets()]);
    }, "toast.completed");

    // ------------------------------------------------------------ calls / customers / tickets
    async function openCustomer(id) {
      try { s.customerCard = await api("GET", `/api/customers/${id}`); } catch (e) { toast(e.message, "error"); }
    }
    function openNewCustomer() {
      s.form = { firstname: "", lastname: "", phone: s.call ? s.call.caller_number : "", email: "", note: "" };
      s.modal = "customer";
    }
    const submitCustomer = () => act(async () => {
      const r = await api("POST", "/api/customers", s.form);
      s.customers = [{ id: r.customer.id, name: [r.customer.firstname, r.customer.lastname].filter(Boolean).join(" "), phone: r.customer.phone, email: r.customer.email }];
      s.modal = null; await openCustomer(r.customer.id);
    }, "toast.customer_created");

    function openTicketForm(fromCall) {
      const cust = s.customerCard ? s.customerCard.customer.id : (s.customers[0] && s.customers[0].id) || "";
      s.form = { title: "", body: "", customer_id: cust, ticket_type: "", fields: {}, priority: "2 normal",
                 call_id: fromCall && s.call ? s.call.id : null, idem: uuid() };
      s.modal = "ticket";
    }
    const currentType = computed(() => s.config.ticket_types.find((x) => x.name === s.form.ticket_type));
    const submitTicket = (startMode) => act(async () => {
      const f = s.form;
      if (!f.customer_id) throw new Error(t("err.choose_customer"));
      const r = await api("POST", "/api/tickets", {
        title: f.title, body: f.body, customer_id: Number(f.customer_id), priority: f.priority,
        ticket_type: f.ticket_type || null, fields: f.fields, call_id: f.call_id, start_mode: startMode || null,
      }, { idem: f.idem + (startMode || "") });
      if (r.agent_state) s.state = r.agent_state;
      s.modal = null;
      if (f.call_id) { s.call = null; s.customerCard = null; }
      await Promise.all([refreshTasks(), refreshTickets(), refreshCalls()]);
      return r;
    }, "toast.ticket_created");
    const dismissCall = () => { s.call = null; s.customers = []; s.customerCard = null; };
    const reopenCall = (c) => { s.call = c; s.customers = []; s.customerCard = null;
      api("GET", `/api/customers/lookup?phone=${encodeURIComponent(c.caller_number)}`).then((r) => {
        s.customers = r.customers; if (r.customers.length === 1) openCustomer(r.customers[0].id);
      }); };

    // ------------------------------------------------------------ supervisor
    const isSup = computed(() => s.me && (s.me.role === "supervisor" || s.me.role === "admin"));
    const reconcile = (a) => act(async () => { await api("POST", `/api/admin/agents/${a.agent_id}/reconcile`); await refreshSup(); }, "toast.reconciled");
    function openOverride(a) { s.form = { agent: a, manual_state: "ready", ignore_blocking: false, reason: "" }; s.modal = "override"; }
    const submitOverride = () => act(async () => {
      const f = s.form;
      await api("POST", `/api/admin/agents/${f.agent.agent_id}/override`, { manual_state: f.manual_state, ignore_blocking: f.ignore_blocking, reason: f.reason });
      s.modal = null; await refreshSup();
    }, "toast.override");
    const cancelSession = (w) => {
      const reason = prompt(t("prompt.cancel", { n: w.ticket_number }));
      if (!reason) return;
      act(async () => { await api("POST", `/api/admin/sessions/${w.id}/cancel`, { reason }); await refreshSup(); }, "toast.session_cancelled");
    };
    const showStatus = computed(() => isOperatorView.value && ["work", "tickets", "contacts", "sup", "chat"].includes(s.tab));
    const pageTitle = computed(() => t({ tickets: "nav.tickets", contacts: "nav.contacts", chat: "nav.chat", mail: "nav.mail", whatsapp: "nav.whatsapp", telegram: "nav.telegram", overview: "nav.overview", sup: "nav.sup", users: "nav.users", integrations: "nav.integrations", settings: "nav.sys_settings",
      types: "nav.types", system: "nav.system", mysettings: "nav.settings", work: "nav.work" }[s.tab] || "app.title"));
    const initials = computed(() => ((s.me && s.me.name) || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase());
    // ---------------- manager overview (v2.5)
    async function refreshOverview(silent) {
      if (!silent) s.ov.loading = true;
      try { s.ov.data = await api("GET", `/api/admin/overview?period=${s.ov.period}`); s.ov.updated = new Date().toISOString(); watchChartWidth(); }
      catch (e) { if (!silent) toast(e.message, "error"); }
      finally { s.ov.loading = false; }
    }
    function setPeriod(p) { s.ov.period = p; s.ov.hover = -1; refreshOverview(); }
    setInterval(() => { if (s.tab === "overview" && s.me && !document.hidden) refreshOverview(true); }, 30000);  // safety net
    setInterval(() => { if (s.tab === "overview" && s.ov.data && s.ov.data.live.waiting) s.clock = Date.now(); }, 1000);
    const liveWait = computed(() => {
      const d = s.ov.data; if (!d || !d.live.waiting) return 0;
      return d.live.longest_wait_sec + Math.max(0, (s.clock - new Date(s.ov.updated).getTime()) / 1000);
    });
    const pct = (x) => (x === null || x === undefined ? "—" : Math.round(x * 100) + "%");
    const secs = (x) => {
      if (x === null || x === undefined) return "—";
      x = Math.round(x);
      return x < 60 ? `${x} ${t("dur.s")}` : `${Math.floor(x / 60)}:${String(x % 60).padStart(2, "0")}`;
    };
    const ovAgents = computed(() => {
      const d = s.ov.data; if (!d) return [];
      const k = s.ov.sort;
      return d.agents.filter((x) => !s.sup.level || x.level === s.sup.level).slice()
        .sort((x, y) => ((y[k] ?? -1) - (x[k] ?? -1)) || x.name.localeCompare(y.name));
    });
    const scoreClass = (v) => (v === null || v === undefined ? "" : v >= 80 ? "good" : v >= 60 ? "mid" : "low");
    const slClass = computed(() => {
      const d = s.ov.data; if (!d || d.calls.service_level === null) return "";
      return d.calls.service_level >= d.settings.sla_target ? "good" : d.calls.service_level >= d.settings.sla_target * 0.75 ? "mid" : "low";
    });
    // half-circle gauge: 0..100 % mapped to 180°..0°
    const gauge = computed(() => {
      const d = s.ov.data; const v = d && d.calls.service_level !== null ? d.calls.service_level : 0;
      const pt = (f, r) => { const a = Math.PI * (1 - f); return [90 + r * Math.cos(a), 90 - r * Math.sin(a)]; };
      const arc = (f) => { const [x, y] = pt(Math.max(0.0001, Math.min(f, 1)), 70); return `M 20 90 A 70 70 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)}`; };
      const tg = d ? d.settings.sla_target : 0.8;
      const [t1x, t1y] = pt(tg, 60), [t2x, t2y] = pt(tg, 82);
      return { track: "M 20 90 A 70 70 0 0 1 160 90", value: arc(v), empty: !d || d.calls.service_level === null,
               target: { x1: t1x, y1: t1y, x2: t2x, y2: t2y } };
    });
    // hourly view: hide the empty night hours (always keep 08:00–20:00)
    const ovSeries = computed(() => {
      const d = s.ov.data; if (!d) return [];
      if (d.bucket !== "hour") return d.series;
      const busy = (x) => x.offered || x.agents_avg || x.tickets_completed;
      const idx = d.series.map((x, i) => (busy(x) ? i : -1)).filter((i) => i >= 0);
      const lo = Math.min(idx.length ? idx[0] : 8, 8), hi = Math.max(idx.length ? idx[idx.length - 1] : 19, 19);
      return d.series.slice(Math.max(0, lo), Math.min(d.series.length, hi + 1));
    });
    // charts are drawn at their real pixel width, so labels keep the same size on a phone and on a 4K monitor
    const CH = { h: 220, l: 36, r: 10, t: 12, b: 26 };
    let chartRO = null;
    function watchChartWidth() {
      nextTick(() => {
        const el = document.querySelector(".ov-chart .chart-box");
        if (!el || !window.ResizeObserver) return;
        if (chartRO) chartRO.disconnect();
        chartRO = new ResizeObserver(([en]) => { const w = Math.round(en.contentRect.width); if (w > 100 && Math.abs(w - s.ov.cw) > 2) s.ov.cw = w; });
        chartRO.observe(el);
      });
    }
    // axis maximum = 4 round steps (1, 2, 5 × 10^n), so every grid line has a whole, readable value
    function niceMax(m) {
      const raw = Math.max(1, m) / 4, p = Math.pow(10, Math.floor(Math.log10(raw)));
      const step = [1, 2, 5, 10].map((k) => k * p).find((v) => v >= raw);
      return step * 4;
    }
    const callChart = computed(() => {
      const d = s.ov.data; if (!d) return null;
      const W = s.ov.cw, H = Math.round(Math.min(300, Math.max(200, W * 0.3)));
      const se = ovSeries.value, n = se.length, iw = W - CH.l - CH.r, ih = H - CH.t - CH.b;
      const max = niceMax(Math.max(4, ...se.map((x) => x.offered))), bw = iw / n, w = Math.max(2, Math.min(34, bw * 0.6));
      const y = (v) => CH.t + ih - (v / max) * ih;
      const every = n > 16 ? 3 : n > 10 ? 2 : 1;
      const bars = se.map((x, i) => {
        const cx = CH.l + bw * i + bw / 2, ya = y(x.answered), ym = y(x.answered + x.missed);
        return { i, x: cx - w / 2, w, cx, label: x.label, showLabel: i % every === 0, future: x.future,
                 ans: { y: ya, h: Math.max(0, CH.t + ih - ya) }, mis: { y: ym, h: Math.max(0, ya - ym - (x.answered ? 2 : 0)) },
                 hit: { x: CH.l + bw * i, w: bw }, d: x };
      });
      const grid = [0, 0.25, 0.5, 0.75, 1].map((f) => ({ y: y(max * f), v: Math.round(max * f) }));
      return { bars, grid, base: CH.t + ih, ...CH, w: W, h: H };
    });
    const loadChart = computed(() => {
      const d = s.ov.data; if (!d) return null;
      const W = s.ov.cw, h = Math.round(Math.min(200, Math.max(150, W * 0.2)));
      const se = ovSeries.value, n = se.length, iw = W - CH.l - CH.r, ih = h - CH.t - CH.b;
      const max = niceMax(Math.max(1, ...se.map((x) => Math.max(x.agents_avg || 0, x.erlangs || 0))));
      const X = (i) => CH.l + (iw / n) * i + iw / n / 2, Y = (v) => CH.t + ih - (v / max) * ih;
      const line = (k) => se.map((x, i) => (x.future || x[k] === null ? null : [X(i), Y(x[k])])).filter(Boolean)
        .map((p, j) => `${j ? "L" : "M"} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");
      const every = n > 16 ? 3 : n > 10 ? 2 : 1;
      return { h, agents: line("agents_avg"), erl: line("erlangs"), base: CH.t + ih, l: CH.l, r: CH.r, w: W,
               grid: [0, 0.5, 1].map((f) => ({ y: Y(max * f), v: +(max * f).toFixed(1) })),
               labels: se.map((x, i) => ({ x: X(i), label: x.label, show: i % every === 0 })) };
    });
    const ovHover = computed(() => (callChart.value && s.ov.hover >= 0 ? callChart.value.bars[s.ov.hover] : null));
    // ---------------- messenger (v3.0)
    const chatPeer = computed(() => s.chat.contacts.find((c) => c.id === s.chat.peer) || null);
    const AV = 6;
    const avClass = (id) => "av-" + (Math.abs(+id || 0) % AV);
    const initials2 = (name) => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase();
    const dayKey = (iso) => { try { return new Intl.DateTimeFormat("en-CA", { timeZone: s.config.timezone }).format(new Date(iso)); } catch { return iso.slice(0, 10); } };
    function dayLabel(iso) {
      const k = dayKey(iso), today = dayKey(new Date().toISOString()), yest = dayKey(new Date(Date.now() - 86400000).toISOString());
      if (k === today) return t("chat.today");
      if (k === yest) return t("chat.yesterday");
      try { return new Intl.DateTimeFormat(locale, { timeZone: s.config.timezone, day: "numeric", month: "long", year: "numeric" }).format(new Date(iso)); } catch { return k; }
    }
    function shortTime(iso) {
      if (!iso) return "";
      if (dayKey(iso) === dayKey(new Date().toISOString())) return fmt(iso);
      try { return new Intl.DateTimeFormat(locale, { timeZone: s.config.timezone, day: "2-digit", month: "2-digit" }).format(new Date(iso)); } catch { return ""; }
    }
    function lastSeen(c) {
      if (!c) return "";
      if (s.chat.typing[c.id] && s.chat.typing[c.id] > s.clock) return t("chat.typing");
      if (c.online) return t("chat.online");
      if (c.away) return t("chat.away");
      return c.last_seen ? t("chat.last_seen", { t: (dayKey(c.last_seen) === dayKey(new Date().toISOString()) ? "" : shortTime(c.last_seen) + " ") + fmt(c.last_seen) }) : t("chat.long_ago");
    }
    // messages grouped like Telegram: day separators, consecutive messages of one person within 5 min form a group
    const chatItems = computed(() => {
      const out = []; let prevDay = "", prev = null;
      s.chat.msgs.forEach((m, i) => {
        const d = dayKey(m.at);
        if (d !== prevDay) { out.push({ kind: "day", key: "d" + d, label: dayLabel(m.at) }); prevDay = d; prev = null; }
        const next = s.chat.msgs[i + 1];
        const joinPrev = prev && prev.from === m.from && new Date(m.at) - new Date(prev.at) < 300000;
        const joinNext = next && next.from === m.from && dayKey(next.at) === d && new Date(next.at) - new Date(m.at) < 300000;
        out.push({ kind: "msg", key: "m" + m.id, m, mine: m.from === s.me.id, first: !joinPrev, last: !joinNext });
        prev = m;
      });
      return out;
    });
    let contactsTimer = null;
    let contactsSeq = 0;
    async function loadContacts() {
      const seq = ++contactsSeq;  // only the newest answer is shown (a slow older request must not overwrite a search)
      const r = await api("GET", "/api/chat/contacts" + (s.chat.q.trim() ? "?q=" + encodeURIComponent(s.chat.q.trim()) : ""));
      if (seq !== contactsSeq) return;
      s.chat.contacts = r.contacts; s.chat.unread = r.unread_total;
    }
    function searchContacts() { clearTimeout(contactsTimer); contactsTimer = setTimeout(() => loadContacts().catch(() => {}), 160); }
    async function refreshChatUnread() { try { s.chat.unread = (await api("GET", "/api/chat/unread")).unread; } catch { /* ignore */ } }
    const chatScroller = () => document.querySelector(".chat-scroll");
    function scrollChatBottom(smooth) {
      nextTick(() => { const el = chatScroller(); if (el) el.scrollTo({ top: el.scrollHeight, behavior: smooth && !reduceMotion() ? "smooth" : "auto" }); });
    }
    const nearBottom = () => { const el = chatScroller(); return !el || el.scrollHeight - el.scrollTop - el.clientHeight < 120; };
    async function openChat(c) {
      if (s.chat.peer && s.chat.peer !== c.id) s.chat.drafts[s.chat.peer] = s.chat.text;
      s.chat.peer = c.id; s.chat.editing = null; s.chat.menu = null; s.chat.text = s.chat.drafts[c.id] || ""; s.chat.msgs = []; s.chat.hasMore = false; s.chat.profile = null;
      s.chat.loading = true;
      try {
        const r = await api("GET", `/api/chat/${c.id}/messages`);
        if (s.chat.peer !== c.id) return;
        s.chat.msgs = r.messages; s.chat.hasMore = r.has_more;
        scrollChatBottom(false);
        markChatRead(true);  // opening a conversation = reading it
        if (s.chat.info) loadProfile();
        nextTick(() => { const ta = document.querySelector(".chat-compose textarea"); if (ta && innerWidth > 900) ta.focus(); autoGrow(); });
      } catch (e) { toast(e.message, "error"); } finally { s.chat.loading = false; }
    }
    async function markChatRead(opening) {
      const peer = s.chat.peer;
      if (!peer || document.hidden || (!opening && s.tab !== "chat")) return;
      const c = s.chat.contacts.find((x) => x.id === peer);
      if (!s.chat.msgs.some((m) => m.from === peer && !m.read_at) && !(c && c.unread)) return;
      try {
        await api("POST", `/api/chat/${peer}/read`);
        if (c) c.unread = 0;
        s.chat.msgs.forEach((m) => { if (m.from === peer && !m.read_at) m.read_at = new Date().toISOString(); });
        refreshChatUnread();
      } catch { /* ignore */ }
    }
    async function loadOlder() {
      if (!s.chat.hasMore || s.chat.loading || !s.chat.msgs.length) return;
      const el = chatScroller(), before = el ? el.scrollHeight - el.scrollTop : 0;
      s.chat.loading = true;
      try {
        const r = await api("GET", `/api/chat/${s.chat.peer}/messages?before_id=${s.chat.msgs[0].id}`);
        s.chat.msgs = [...r.messages, ...s.chat.msgs]; s.chat.hasMore = r.has_more;
        nextTick(() => { if (el) el.scrollTop = el.scrollHeight - before; });  // keep the reading position
      } finally { s.chat.loading = false; }
    }
    function onChatScroll(ev) { if (ev.target.scrollTop < 60) loadOlder(); }
    function autoGrow() {
      const ta = document.querySelector(".chat-compose textarea");
      if (ta) { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 180) + "px"; }
    }
    let typingSent = 0;
    function onType() {
      autoGrow();
      if (s.chat.peer && Date.now() - typingSent > 2500 && s.chat.text.trim()) { typingSent = Date.now(); api("POST", `/api/chat/${s.chat.peer}/typing`).catch(() => {}); }
    }
    async function sendChat() {
      if (s.chat.editing) return saveEdit();
      const body = s.chat.text.trim(), peer = s.chat.peer;
      if (!body || !peer || s.chat.sending) return;
      s.chat.sending = true;
      try {
        const m = await api("POST", `/api/chat/${peer}/messages`, { body });
        s.chat.text = ""; s.chat.drafts[peer] = ""; typingSent = 0;
        if (s.chat.peer === peer && !s.chat.msgs.some((x) => x.id === m.id)) s.chat.msgs.push(m);
        bumpContact(m);
        scrollChatBottom(true);
        nextTick(autoGrow);
      } catch (e) { toast(e.message, "error"); } finally { s.chat.sending = false; }
    }
    async function loadProfile() { if (s.chat.peer) try { s.chat.profile = await api("GET", `/api/chat/${s.chat.peer}/profile`); } catch { /* ignore */ } }
    function toggleChatInfo() { s.chat.info = !s.chat.info; if (s.chat.info) loadProfile(); }
    function chatBack() { if (s.chat.peer) s.chat.drafts[s.chat.peer] = s.chat.text; s.chat.peer = null; s.chat.info = false; }
    function chime() {
      if (!s.prefs.sound) return;
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)(), o = ctx.createOscillator(), g = ctx.createGain();
        o.type = "sine"; o.frequency.setValueAtTime(740, ctx.currentTime); o.frequency.exponentialRampToValueAtTime(1180, ctx.currentTime + 0.12);
        g.gain.setValueAtTime(0.06, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
        o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.3);
      } catch { /* audio not allowed */ }
    }
    function onChatEvent(d) {
      const m = d.message, mine = m.from === s.me.id, peerId = mine ? m.to : m.from;
      const viewing = (s.tab === "chat" || document.documentElement.dataset.vt === "page") && s.chat.peer === peerId;
      if (viewing && !s.chat.msgs.some((x) => x.id === m.id)) {
        const stick = nearBottom() || mine;
        s.chat.msgs.push(m);
        if (stick) scrollChatBottom(true);
      }
      if (!mine) {
        delete s.chat.typing[m.from];
        if (viewing && !document.hidden) markChatRead();
        else {
          s.chat.unread += 1; chime();
          toast(`${d.sender.name}: ${m.body.length > 90 ? m.body.slice(0, 90) + "…" : m.body}`, "chat", () => { setTab("chat"); openChat({ id: m.from }); });
          if (document.hidden && window.Notification && Notification.permission === "granted") {
            try { new Notification(d.sender.name, { body: m.body.slice(0, 140), tag: "agentix-chat-" + m.from }); } catch { /* ignore */ }
          }
        }
      }
      bumpContact(m, d.sender);
    }
    function onChatRead(d) {
      if (d.reader === s.me.id) { soon("chatUnread", refreshChatUnread, 60); if (s.tab === "chat") soon("chatContacts", loadContacts, 120); return; }
      if (s.chat.peer === d.reader) s.chat.msgs.forEach((m) => { if (m.from === s.me.id && m.id <= d.up_to && !m.read_at) m.read_at = d.at; });
      const c = s.chat.contacts.find((x) => x.id === d.reader);
      if (c && c.last && c.last.from === s.me.id && c.last.id <= d.up_to) c.last.read_at = d.at;
    }
    function onChatTyping(d) { s.chat.typing[d.from] = Date.now() + 4500; s.clock = Date.now(); }
    setInterval(() => { if (Object.keys(s.chat.typing).length) s.clock = Date.now(); }, 1000);
    setInterval(() => { if (s.phone.startedAt) s.clock = Date.now(); }, 1000);  // call timer on the phone button
    setInterval(() => { if (s.me && s.tab === "chat" && !document.hidden) loadContacts().catch(() => {}); }, 30000);  // presence
    document.addEventListener("visibilitychange", () => { if (!document.hidden) markChatRead(); });
    // ---------------- messenger v3.1: live list order, reactions, edit / delete, background notifications
    const REACTIONS = ["❤️", "👍", "😂", "😮", "😢", "🔥", "👏", "🙏"];
    /** A message arrived or was sent: update that chat's time / preview at once and move it to the top. */
    function bumpContact(m, sender) {
      const mine = m.from === s.me.id, peerId = mine ? m.to : m.from;
      let c = s.chat.contacts.find((x) => x.id === peerId);
      if (!c) { if (s.tab === "chat" || s.chat.contacts.length) soon("chatContacts", loadContacts, 60); return; }
      c.last = m;
      const viewing = s.chat.peer === peerId && (s.tab === "chat" || document.documentElement.dataset.vt === "page") && !document.hidden;
      if (!mine && !viewing) c.unread = (c.unread || 0) + 1;
      if (sender && !c.name) c.name = sender.name;
      s.chat.contacts = [c, ...s.chat.contacts.filter((x) => x !== c)];
    }
    function reactionsOf(m) {
      return (m.reactions || []).map((r) => ({ emoji: r.emoji, n: r.users.length, mine: r.users.includes(s.me.id) }));
    }
    async function react(m, emoji) {
      s.chat.menu = null;
      try { const v = await api("POST", `/api/chat/messages/${m.id}/react`, { emoji }); applyUpdate(v); } catch (e) { toast(e.message, "error"); }
    }
    function applyUpdate(v) {
      const i = s.chat.msgs.findIndex((x) => x.id === v.id);
      if (i >= 0) s.chat.msgs[i] = { ...s.chat.msgs[i], ...v };
      const c = s.chat.contacts.find((x) => x.last && x.last.id === v.id);
      if (c) c.last = { ...c.last, ...v };
    }
    function removeLocal(id) {
      s.chat.msgs = s.chat.msgs.filter((x) => x.id !== id);
      const c = s.chat.contacts.find((x) => x.last && x.last.id === id);
      if (c) soon("chatContacts", loadContacts, 80);
    }
    function onChatUpdate(d) {
      if (d.deleted) { removeLocal(d.deleted); soon("chatUnread", refreshChatUnread, 80); return; }
      applyUpdate(d.message);
    }
    // context menu: right click / long press / the "⋯" button on a bubble
    function openMenu(ev, it) {
      const el = ev.currentTarget.closest(".bubble-row").querySelector(".bubble").getBoundingClientRect();
      const box = document.querySelector(".chat-main").getBoundingClientRect();
      const x = ev.type === "contextmenu" ? ev.clientX : (it.mine ? el.left : el.right);
      const y = ev.type === "contextmenu" ? ev.clientY : el.bottom;
      s.chat.menu = { m: it.m, mine: it.mine,
        x: Math.max(8, Math.min(x - box.left, box.width - 236)), y: Math.max(8, Math.min(y - box.top, box.height - 260)) };
    }
    let pressT = null;
    function pressStart(ev, it) { clearTimeout(pressT); pressT = setTimeout(() => { navigator.vibrate && navigator.vibrate(15); openMenu({ ...ev, currentTarget: ev.currentTarget, type: "press" }, it); }, 480); }
    function pressEnd() { clearTimeout(pressT); }
    const canEdit = (m) => m.from === s.me.id && Date.now() - new Date(m.at).getTime() < 48 * 3600 * 1000;
    function startEdit(m) {
      s.chat.menu = null; s.chat.editing = m; s.chat.text = m.body;
      nextTick(() => { const ta = document.querySelector(".chat-compose textarea"); if (ta) { ta.focus(); autoGrow(); } });
    }
    function cancelEdit() { s.chat.editing = null; s.chat.text = s.chat.drafts[s.chat.peer] || ""; nextTick(autoGrow); }
    async function saveEdit() {
      const m = s.chat.editing, body = s.chat.text.trim();
      if (!m || !body) return;
      try {
        const v = await api("PATCH", `/api/chat/messages/${m.id}`, { body });
        applyUpdate(v); s.chat.editing = null; s.chat.text = ""; nextTick(autoGrow);
      } catch (e) { toast(e.message, "error"); }
    }
    function editLast(ev) {  // ↑ in an empty box edits my last message, like Telegram
      if (s.chat.text || s.chat.editing) return;
      const last = [...s.chat.msgs].reverse().find((m) => m.from === s.me.id);
      if (last && canEdit(last)) { ev.preventDefault(); startEdit(last); }
    }
    async function copyMsg(m) {
      s.chat.menu = null;
      try { await navigator.clipboard.writeText(m.body); toast(t("chat.copied")); } catch { /* clipboard blocked */ }
    }
    function askDelete(m) { s.chat.menu = null; s.chat.del = { m, all: m.from === s.me.id }; }
    async function confirmDelete() {
      const d = s.chat.del; if (!d) return;
      try {
        await api("DELETE", `/api/chat/messages/${d.m.id}?scope=${d.all ? "all" : "me"}`);
        removeLocal(d.m.id); s.chat.del = null;
      } catch (e) { toast(e.message, "error"); }
    }
    document.addEventListener("click", (e) => { if (s.chat.menu && !e.target.closest(".msg-menu, .b-more")) s.chat.menu = null; });
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      if (s.chat.menu) s.chat.menu = null; else if (s.chat.del) s.chat.del = null; else if (s.chat.editing) cancelEdit();
    });
    // background notifications (Web Push) — work even when every Zenith Desk tab is closed
    const pushSupported = () => "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
    async function registerSW() {
      if (!("serviceWorker" in navigator)) return null;
      try { return await navigator.serviceWorker.register("/sw.js", { scope: "/" }); } catch { return null; }
    }
    async function refreshPushState() {
      if (!pushSupported()) { s.push = "unsupported"; return; }
      if (!window.isSecureContext) { s.push = "insecure"; return; }
      if (Notification.permission === "denied") { s.push = "denied"; return; }
      const reg = await navigator.serviceWorker.getRegistration("/");
      const sub = reg && await reg.pushManager.getSubscription();
      s.push = sub ? "on" : "off";
    }
    async function enablePush() {
      try {
        if (await Notification.requestPermission() !== "granted") { s.push = "denied"; return; }
        s.desktop = "granted";
        const reg = await registerSW(); await navigator.serviceWorker.ready;
        const { key } = await api("GET", "/api/push/key");
        const raw = Uint8Array.from(atob(key.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((key.length + 3) % 4)), (c) => c.charCodeAt(0));
        const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: raw });
        await api("POST", "/api/push/subscribe", sub.toJSON());
        s.push = "on"; toast(t("push.enabled"));
      } catch (e) { toast(t("push.failed") + (e && e.message ? ": " + e.message : ""), "error"); refreshPushState(); }
    }
    async function disablePush() {
      try {
        const reg = await navigator.serviceWorker.getRegistration("/");
        const sub = reg && await reg.pushManager.getSubscription();
        if (sub) { await api("POST", "/api/push/unsubscribe", sub.toJSON()).catch(() => {}); await sub.unsubscribe(); }
      } finally { refreshPushState(); }
    }
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.addEventListener("message", (ev) => {
        if (ev.data && ev.data.type === "open-chat" && s.me) { setTab("chat"); openChat({ id: ev.data.from }); }
        if (ev.data && ev.data.type === "open-ticket" && s.me) openTicket(ev.data.ticket);
      });
    }
    const LEVEL_ORDER = { level1: 1, level2: 2, level3: 3, manager: 4, admin: 5 };
    const teamLevels = computed(() => ["level1", "level2", "level3", "manager"].map((l) => ({ id: l, n: s.sup.agents.filter((a) => a.level === l).length })));
    const teamAgents = computed(() => s.sup.agents
      .filter((a) => !s.sup.level || a.level === s.sup.level)
      .slice().sort((x, y) => (LEVEL_ORDER[x.level] || 9) - (LEVEL_ORDER[y.level] || 9) || x.name.localeCompare(y.name)));
    const teamReport = computed(() => {
      const r = (s.sup.report && s.sup.report.agents) || [];
      if (!s.sup.level) return r;
      const ids = new Set(teamAgents.value.map((a) => a.agent_id));
      return r.filter((x) => ids.has(x.agent_id));
    });
    const supCounts = computed(() => {
      const a = teamAgents.value, c = (f) => a.filter(f).length;
      return {
        online: c((x) => x.manual_state !== "offline"), ready: c((x) => x.display_state === "ready"),
        busy: c((x) => ["busy_task", "wrap_up"].includes(x.computed_state)), brk: c((x) => x.computed_state === "break"),
        offline: c((x) => x.computed_state === "offline"), sync: c((x) => x.sync_status === "error"),
      };
    });
    function openAssign() { s.form = { ticket: "", agent_id: "", work_mode: "" }; s.modal = "assign"; }
    const submitAssign = () => act(async () => {
      await api("POST", "/api/admin/assign", { ticket: String(s.form.ticket), agent_id: Number(s.form.agent_id), work_mode: s.form.work_mode || null });
      s.modal = null; await refreshSup();
    }, "toast.assigned");
    const TAB_ORDER = ["work", "tickets", "contacts", "chat", "mail", "whatsapp", "telegram", "sup", "overview", "users", "integrations", "settings", "types", "system", "mysettings"];
    const setTab = (tab) => {
      if (tab === s.tab) { s.navOpen = false; return; }
      if (tab !== "work" && s.editing) finishEditing();
      const dir = TAB_ORDER.indexOf(tab) >= TAB_ORDER.indexOf(s.tab) ? "fwd" : "back";
      withTransition("page", () => { s.tab = tab; s.navOpen = false; }, { dir });
      if (tab === "sup") refreshSup().catch((e) => toast(e.message, "error"));
      if (tab === "overview") refreshOverview();
      if (tab === "chat") { loadContacts().catch((e) => toast(e.message, "error")); if (s.chat.peer) nextTick(() => { scrollChatBottom(false); markChatRead(); }); }
    };
    const isAdmin = computed(() => s.me && s.me.role === "admin");
    const isOperatorView = computed(() => s.me && s.me.role !== "admin");
    const roleText = (r) => t(`role.${r}`);
    function openPassword() { s.pw = { current_password: "", new_password: "", repeat: "", error: "" }; s.modal = "password"; }
    async function submitPassword() {
      s.pw.error = "";
      if (s.pw.new_password !== s.pw.repeat) { s.pw.error = t("pw.mismatch"); return; }
      try {
        const r = await api("POST", "/api/auth/change-password", { current_password: s.pw.current_password, new_password: s.pw.new_password });
        s.token = r.token; saveToken(r.token); s.modal = null; toast(t("pw.changed"));
        await boot();
      } catch (e) { s.pw.error = e.message; }
    }

    const freeMine = computed(() => s.mine.active.filter((x) => !x.session));
    // ---------------- v3.3: tickets and customers inside Zenith Desk
    let reqN = 0;
    function openTicket(id) {
      if (!id) return;
      if (!isOperatorView.value) { window.open(zLink(id), "_blank", "noopener"); return; }  // admins work in Zammad itself
      setTab("tickets"); s.tkOpen = { id: +id, n: ++reqN };
    }
    function openContact(id, kind) { if (!id) return; setTab("contacts"); s.ctOpen = { id: +id, kind: kind || null, n: ++reqN }; }
    function dialNumber(number, name) { if (number) window.dispatchEvent(new CustomEvent("zenith:dial", { detail: { number, name } })); }
    window.zenithDial = dialNumber;  // used by the ticket and customer pages
    window.addEventListener("zenith:chat", (e) => { const id = e.detail && e.detail.id; if (id) { setTab("chat"); openChat({ id }); } });  // phone → messenger
    const phoneOn = computed(() => !!(s.me && isOperatorView.value && s.config.phone_enabled));
    async function refreshMsgCounts() { if (!s.me || !isOperatorView.value) return; try { s.msgCounts = await api("GET", "/api/msg/counts"); } catch { /* ignore */ } }
    async function refreshMail() {
      if (!s.me || !isOperatorView.value) return;
      try { const a = await api("GET", "/api/mail/account"); s.mailOn = a.enabled; s.mailUnseen = a.connected ? a.unseen : 0; } catch { /* ignore */ }
    }
    async function playRecording(ev, c) {  // v3.9: recordings served by Zenith Desk need the token
      if (!c.recording_url.startsWith("/api/")) return;
      ev.preventDefault();
      try {
        const r = await fetch(c.recording_url, { headers: { Authorization: `Bearer ${s.token}` } });
        if (!r.ok) { toast((await r.json().catch(() => ({}))).detail || t("err.status", { status: r.status }), "error"); return; }
        window.open(URL.createObjectURL(await r.blob()), "_blank", "noopener");
      } catch (e) { toast(e.message, "error"); }
    }
    function openConversation(id, channel) { setTab(channel === "telegram" ? "telegram" : "whatsapp"); s.inOpen = { id, n: Date.now() }; }
    // v3.8 Windows desktop client (WebView2): tell the window about calls and unread messages, so it can flash the
    // taskbar / show a tray balloon when it is minimized. Nothing happens in a normal browser.
    const host = window.chrome && window.chrome.webview;
    if (host) {
      const post = (m) => { try { host.postMessage(m); } catch { /* ignore */ } };
      watch(() => [s.phone.call, s.phone.name], ([call, name]) => post({ type: "call", state: call || "idle", name: name || "" }));
      watch(() => s.chat.unread, (n) => post({ type: "unread", n: n || 0 }));
      watch(() => (s.me ? s.me.name : ""), (name) => post({ type: "user", name: name || "" }), { immediate: true });
    }
    window.addEventListener("zenith:agent_state", (e) => { if (e.detail && s.me && e.detail.agent_id === s.me.id) s.state = e.detail; });  // DND from the phone
    const phoneTimer = computed(() => {
      if (!s.phone.startedAt) return "";
      const sec = Math.max(0, Math.floor((s.clock - s.phone.startedAt) / 1000));
      return `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;
    });
    function newTicketFor(customer) { setTab("tickets"); s.tkNew = { customer, n: ++reqN }; }
    const zLink = (id) => `${s.config.zammad_url || ""}/#ticket/zoom/${id}`;

    onMounted(() => {
      document.title = `${t("app.title")} — ${t("app.subtitle")}`;
      if (s.token) boot();
      setInterval(() => { if (s.me && !isAdmin.value && !s.me.must_change_password) { refreshTickets().catch(() => {}); refreshNotifications(); } }, 30000);
      document.addEventListener("click", (e) => { if (s.ntfOpen && !e.target.closest(".ntf-wrap")) s.ntfOpen = false; });
      setInterval(() => { if (s.me && s.tab === "sup") refreshSup().catch(() => {}); }, 15000);
    });

    return { s, t, version: VERSION, stateText, srcText, callText, fmt, dur, doLogin, logout, goReady, goBreak, startTicket, changeMode, release,
      openComplete, submitComplete, openCustomer, openNewCustomer, submitCustomer, openTicketForm, submitTicket,
      currentType, dismissCall, reopenCall, isSup, reconcile, openOverride, submitOverride, cancelSession, setTab,
      freeMine, zLink, dialNumber, phoneTimer, phoneOn, openConversation, playRecording, openTicket, openContact, newTicketFor, refreshSup, isAdmin, isOperatorView, roleText, openPassword, submitPassword, api, toast,
      toggleNtf, markRead, isUnread, ntfIcon, enableDesktop, toggleTheme, effectiveTheme, supCounts, openAssign, submitAssign,
      PRESETS_PREVIEW: Object.fromEntries(Object.entries(PRESETS).map(([k, v]) => [k, v.layout.filter((w) => !w.hidden)])),
      teamLevels, teamAgents, teamReport, showStatus, pageTitle, initials,
      refreshOverview, setPeriod, liveWait, isFrozen, resumeIdle, idleSinceText,
      toastClick, dayLabel, chatPeer, avClass, initials2, shortTime, lastSeen, chatItems, searchContacts, openChat, onChatScroll, onType, sendChat,
      toggleChatInfo, chatBack, REACTIONS, reactionsOf, react, openMenu, pressStart, pressEnd, canEdit, startEdit, cancelEdit,
      editLast, copyMsg, askDelete, confirmDelete, enablePush, disablePush, pushSupported, pct, secs, ovAgents, scoreClass, slClass, gauge, callChart, loadChart, ovHover,
      setTheme, toggleMotion, presetIds, visibleLayout, hiddenWidgets, widgetName, applyPreset, moveW, setW, cycleH, hideW, showW,
      dragStart, dropOn, startEditing, finishEditing, toggleSound, toggleCompact, levelText };
  },

  template: `
<div v-if="!s.me" class="panel login">
  <button class="theme-btn" @click="toggleTheme" :aria-label="effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark')" :title="effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark')"><ico :name="effectiveTheme(s.theme)==='dark' ? 'sun' : 'moon'"></ico></button>
  <h1 class="logo"><img src="/static/logo.svg" alt="" class="logo-img">{{ t('app.title') }}</h1>
  <div class="logo-sub">{{ t('app.subtitle') }}</div>
  <p class="empty">{{ t('login.hint') }}</p>
  <form @submit.prevent="doLogin">
    <label>{{ t('login.login') }}</label><input v-model="s.login.username" autocomplete="username" autocapitalize="off" required>
    <label>{{ t('login.password') }}</label><input v-model="s.login.password" type="password" autocomplete="current-password" required>
    <p v-if="s.loginError" style="color:var(--danger)">{{ s.loginError }}</p>
    <div style="margin-top:16px"><button class="btn primary" style="width:100%">{{ t('login.submit') }}</button></div>
  </form>
  <div class="version" v-if="version">v{{ version }}</div>
</div>

<template v-else>
<div class="layout" :class="{frozen: isFrozen}" :inert="isFrozen || null" :aria-hidden="isFrozen ? 'true' : null">
  <aside class="sidebar" :class="{open: s.navOpen}">
    <div class="side-head">
      <div class="logo-mark" :title="t('app.title')"><img src="/static/logo.svg" alt="" class="logo-img"><span class="full">{{ t('app.title') }}</span></div>
      <button class="burger" @click="s.navOpen = !s.navOpen" :aria-label="t('nav.menu')">☰</button>
    </div>
    <nav class="side-nav" :aria-label="t('nav.menu')">
      <button v-if="isOperatorView" data-nav="work" :class="{on: s.tab==='work'}" @click="setTab('work')" :aria-label="t('nav.work')"><ico name="work"></ico><span class="lbl">{{ t('nav.work') }}</span></button>
      <button v-if="isOperatorView" data-nav="tickets" :class="{on: s.tab==='tickets'}" @click="setTab('tickets')" :aria-label="t('nav.tickets')"><ico name="ticket"></ico><span class="lbl">{{ t('nav.tickets') }}</span></button>
      <button data-nav="contacts" :class="{on: s.tab==='contacts'}" @click="setTab('contacts')" :aria-label="t('nav.contacts')"><ico name="book"></ico><span class="lbl">{{ t('nav.contacts') }}</span></button>
      <button data-nav="chat" class="chat-nav" :class="{on: s.tab==='chat'}" @click="setTab('chat')" :aria-label="t('nav.chat')"><ico name="chat"></ico><span v-if="s.chat.unread" class="nav-badge">{{ s.chat.unread > 99 ? '99+' : s.chat.unread }}</span><span class="lbl">{{ t('nav.chat') }}</span></button>
      <button v-if="isOperatorView" data-nav="mail" class="msg-nav ml-nav" :class="{on: s.tab==='mail'}" @click="setTab('mail')" :aria-label="t('nav.mail')"><ico name="mail"></ico><span v-if="s.mailUnseen" class="nav-badge">{{ s.mailUnseen > 99 ? '99+' : s.mailUnseen }}</span><span class="lbl">{{ t('nav.mail') }}</span></button>
      <button v-if="isOperatorView" data-nav="whatsapp" class="msg-nav wa" :class="{on: s.tab==='whatsapp'}" @click="setTab('whatsapp')" :aria-label="t('nav.whatsapp')"><ico name="wa"></ico><span v-if="s.msgCounts.whatsapp" class="nav-badge">{{ s.msgCounts.whatsapp }}</span><span class="lbl">{{ t('nav.whatsapp') }}</span></button>
      <button v-if="isOperatorView" data-nav="telegram" class="msg-nav tg" :class="{on: s.tab==='telegram'}" @click="setTab('telegram')" :aria-label="t('nav.telegram')"><ico name="tg"></ico><span v-if="s.msgCounts.telegram" class="nav-badge">{{ s.msgCounts.telegram }}</span><span class="lbl">{{ t('nav.telegram') }}</span></button>
      <button v-if="isSup" data-nav="sup" :class="{on: s.tab==='sup'}" @click="setTab('sup')" :aria-label="t('nav.sup')"><ico name="team"></ico><span class="lbl">{{ t('nav.sup') }}</span></button>
      <button v-if="isSup" data-nav="overview" class="ov-nav" :class="{on: s.tab==='overview'}" @click="setTab('overview')" :aria-label="t('nav.overview')"><ico name="chart"></ico><span class="lbl">{{ t('nav.overview') }}</span></button>
      <template v-if="isAdmin">
        <div class="side-title" v-if="isOperatorView || isSup">{{ t('nav.admin') }}</div>
        <button data-nav="users" :class="{on: s.tab==='users'}" @click="setTab('users')" :aria-label="t('nav.users')"><ico name="users"></ico><span class="lbl">{{ t('nav.users') }}</span></button>
        <button data-nav="integrations" :class="{on: s.tab==='integrations'}" @click="setTab('integrations')" :aria-label="t('nav.integrations')"><ico name="plug"></ico><span class="lbl">{{ t('nav.integrations') }}</span></button>
        <button data-nav="settings" :class="{on: s.tab==='settings'}" @click="setTab('settings')" :aria-label="t('nav.sys_settings')"><ico name="sliders"></ico><span class="lbl">{{ t('nav.sys_settings') }}</span></button>
        <button data-nav="types" :class="{on: s.tab==='types'}" @click="setTab('types')" :aria-label="t('nav.types')"><ico name="tag"></ico><span class="lbl">{{ t('nav.types') }}</span></button>
        <button data-nav="system" :class="{on: s.tab==='system'}" @click="setTab('system')" :aria-label="t('nav.system')"><ico name="pulse"></ico><span class="lbl">{{ t('nav.system') }}</span></button>
      </template>
    </nav>
    <div class="side-foot">
      <button class="settings-btn" :class="{on: s.tab==='mysettings'}" @click="setTab('mysettings')" :aria-label="t('nav.settings')"><ico name="gear"></ico><span class="lbl">{{ t('nav.settings') }}</span></button>
      <button class="theme-toggle" @click="toggleTheme" :aria-label="effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark')"><ico :name="effectiveTheme(s.theme)==='dark' ? 'sun' : 'moon'"></ico><span class="lbl">{{ effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark') }}</span></button>
      <button @click="openPassword" :aria-label="t('btn.change_password')"><ico name="key"></ico><span class="lbl">{{ t('btn.change_password') }}</span></button>
      <button class="logout" @click="logout" :aria-label="t('btn.logout')"><ico name="out"></ico><span class="lbl">{{ t('btn.logout') }}</span></button>
      <div class="version" v-if="version">v{{ version }}</div>
    </div>
  </aside>
  <div class="content">
  <header class="topbar">
    <div v-if="showStatus && s.state" class="status" :class="'st-' + s.state.display_state" :key="'st-' + s.state.display_state">
      <span class="dot"></span>
      <div>{{ stateText(s.state.display_state) }}
        <small>{{ s.state.reason }} · {{ s.state.phone_label }}</small></div>
    </div>
    <div v-if="!showStatus" class="page-title">{{ pageTitle }}<small>{{ t('app.title') }}</small></div>
    <button v-if="showStatus" class="btn go" @click="goReady" :disabled="s.busy || (s.state && s.state.manual_state==='ready' && s.state.computed_state!=='wrap_up')">{{ t('btn.ready') }}</button>
    <button v-if="showStatus" class="btn" @click="goBreak" :disabled="s.busy || (s.state && s.state.manual_state==='break')">{{ t('btn.break') }}</button>
    <div class="spacer"></div>
    <button v-if="showStatus && s.tab==='work' && !s.editing" class="btn sm customize-btn" @click="startEditing"><ico name="edit" style="width:15px;height:15px"></ico> {{ t('ws.customize') }}</button>
    <div v-if="phoneOn" id="ph-bar-slot" class="ph-bar-slot"></div>
    <div class="ntf-wrap" v-if="showStatus">
      <button class="bell" @click.stop="toggleNtf" :title="t('ntf.title')" :aria-label="t('ntf.title')"><ico name="bell"></ico><span v-if="s.ntf.unread" class="badge" v-flash>{{ s.ntf.unread }}</span></button>
      <div v-if="s.ntfOpen" class="panel ntf-pop">
        <h2>{{ t('ntf.title') }}</h2>
        <div class="body">
          <div v-if="!s.ntf.items.length" class="empty">{{ t('ntf.empty') }}</div>
          <div v-for="n in s.ntf.items.slice(0, 15)" :key="n.id" class="ntf-item" :class="[n.level, {clickable: n.ticket_id && isOperatorView}]" @click="n.ticket_id && isOperatorView && (s.ntfOpen = false, openTicket(n.ticket_id))">
            <span class="ico">{{ ntfIcon(n) }}</span><div class="txt">{{ n.text }}<div class="when">{{ fmt(n.ts, true) }}</div></div>
          </div>
        </div>
      </div>
    </div>
    <div class="live-pill" :class="'lv-' + s.sse" role="status" :title="s.sse==='ok' ? t('live.on_hint') : t('live.lost_hint')">
      <span class="lv-dot" aria-hidden="true"></span>{{ s.sse==='ok' ? t('live.on') : s.sse==='lost' ? t('live.lost') : t('live.connecting') }}
    </div>
    <div class="me">
      <div class="avatar" aria-hidden="true">{{ initials }}</div>
      <div>
        <div class="me-name">{{ s.me.name }}</div>
        <div class="me-level" v-if="s.me.level">{{ levelText(s.me.level) }}<span v-if="s.me.position" class="me-pos"> · {{ s.me.position }}</span></div>
        <div class="me-meta" v-else>{{ s.me.position || roleText(s.me.role) }}</div>
      </div>
    </div>
    <div v-if="phoneOn" id="ph-strip-slot" class="ph-strip-slot"></div>
  </header>

  <main>
    <div v-if="s.sse==='lost'" class="banner error">{{ t('banner.sse') }}</div>
    <div v-if="isOperatorView && s.state && s.state.sync_status!=='ok'" class="banner" :class="{error: s.state.sync_status==='error'}">
      {{ s.state.sync_status==='error' ? t('banner.sync_error') : t('banner.sync_pending') }}
      <span v-if="s.state.sync_error">: {{ s.state.sync_error }}</span>
      <span v-if="s.state.next_retry_at"> · {{ t('banner.retry_at') }} {{ fmt(s.state.next_retry_at) }}</span>
    </div>
    <div v-if="s.ticketsError && s.tab==='work'" class="banner">Zammad: {{ s.ticketsError }}</div>
    <div class="page" :key="s.tab" :data-page="s.tab">

    <!-- ===================== OPERATOR ===================== -->
    <template v-if="s.tab==='work' && isOperatorView">
      <section v-if="s.call" class="panel call" :class="{ringing: s.call.state==='ringing'}">
        <h2>{{ s.call.direction==='out' ? t('call.outgoing') : t('call.incoming') }} <span class="count">{{ callText(s.call.state) }}</span></h2>
        <div class="body">
          <div class="number">{{ s.call.caller_number || t('call.hidden') }}</div>
          <div class="meta empty">{{ [s.call.caller_name, s.call.queue ? t('call.queue') + ' ' + s.call.queue : '', fmt(s.call.started_at)].filter(Boolean).join(' · ') }}</div>
          <div v-if="s.customers.length > 1" class="customer">
            {{ t('call.several') }}
            <div v-for="c in s.customers" :key="c.id"><a href="#" @click.prevent="openCustomer(c.id)">{{ c.name }}</a> <span class="empty">{{ c.email }}</span></div>
          </div>
          <div v-if="s.customerCard" class="customer">
            <div class="title"><b>{{ [s.customerCard.customer.firstname, s.customerCard.customer.lastname].filter(Boolean).join(' ') }}</b></div>
            <div class="meta empty">{{ [s.customerCard.customer.phone || s.customerCard.customer.mobile, s.customerCard.customer.email, s.customerCard.customer.organization].filter(Boolean).join(' · ') }}</div>
            <div v-if="s.customerCard.customer.note" style="margin-top:4px">{{ s.customerCard.customer.note }}</div>
            <div style="margin-top:8px" v-if="s.customerCard.tickets.length">
              <div v-for="tk in s.customerCard.tickets" :key="tk.id" class="meta">
                <a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }} <span class="tag">{{ tk.state }}</span>
              </div>
            </div>
            <div v-else class="empty">{{ t('call.no_tickets') }}</div>
          </div>
          <div v-if="!s.customers.length" class="customer">{{ t('call.not_found') }}</div>
          <div class="item actions" style="border:0">
            <button v-if="s.call.ticket_id" class="btn primary" @click="openTicket(s.call.ticket_id)" data-act="call-open-ticket">{{ t('call.open_ticket') }}</button>
            <button v-else class="btn primary" @click="openTicketForm(true)">{{ t('call.create_ticket') }}</button>
            <button v-if="!s.customers.length" class="btn" @click="openNewCustomer">{{ t('call.create_customer') }}</button>
            <button class="btn" @click="dismissCall">{{ t('call.hide') }}</button>
          </div>
        </div>
      </section>

      <div v-if="s.editing" class="panel edit-bar">
        <div class="edit-title">{{ t('ws.editing') }}</div>
        <div class="edit-hint">{{ t('ws.hint') }}</div>
        <div class="edit-row">
          <label class="inline">{{ t('ws.preset') }}
            <select :value="s.prefs.preset" @change="applyPreset($event.target.value)">
              <option v-for="p in presetIds" :key="p" :value="p">{{ t('preset.' + p) }}</option>
              <option v-if="s.prefs.preset==='custom'" value="custom">{{ t('preset.custom') }}</option>
            </select></label>
          <span v-if="hiddenWidgets.length" class="hidden-list">{{ t('ws.hidden') }}:
            <button v-for="w in hiddenWidgets" :key="w.id" class="btn sm" @click="showW(w)">+ {{ widgetName(w.id) }}</button></span>
          <span class="spacer"></span>
          <button class="btn sm" @click="applyPreset('default')">{{ t('ws.reset') }}</button>
          <button class="btn sm primary ws-done" @click="finishEditing">{{ t('ws.done') }}</button>
        </div>
      </div>

      <div class="dash" :class="{editing: s.editing, compact: s.prefs.compact}">
        <div v-for="(w, i) in visibleLayout" :key="w.id" class="widget" :data-w="w.id" :style="{'--i': i}"
             :class="['w' + w.w, 'h-' + w.h, {dragging: s.dragId === w.id, over: s.overId === w.id && s.dragId !== w.id}]"
             :draggable="s.editing" @dragstart="dragStart(w, $event)" @dragover.prevent="s.editing && (s.overId = w.id)"
             @drop.prevent="dropOn(w)" @dragend="s.dragId = null; s.overId = null">
          <div v-if="s.editing" class="widget-tools">
            <span class="grip" :title="t('ws.drag')">⠿</span><b>{{ widgetName(w.id) }}</b>
            <span class="spacer"></span>
            <button class="wt" :title="t('ws.left')" @click="moveW(i, -1)">◀</button>
            <button class="wt" :title="t('ws.right')" @click="moveW(i, 1)">▶</button>
            <button v-for="n in [1, 2, 3]" :key="n" class="wt" :class="{on: w.w === n}" :title="t('ws.width')" @click="setW(w, n)">{{ ['⅓', '⅔', '▭'][n - 1] }}</button>
            <button class="wt" :title="t('ws.height')" @click="cycleH(w)">↕ {{ t('h.' + w.h) }}</button>
            <button class="wt hide" :title="t('ws.hide')" @click="hideW(w)">✕</button>
          </div>
          <template v-if="w.id==='kpis'">
          <div class="kpis">
            <div class="panel kpi blocking"><div class="k">{{ t('kpi.blocking') }}</div><div class="v" v-flash>{{ s.tasks.blocking.length }}</div>
              <div class="sub">{{ s.tasks.blocking.length ? t('tag.blocking') : t('state.ready') }}</div></div>
            <div class="panel kpi background"><div class="k">{{ t('kpi.background') }}</div><div class="v" v-flash>{{ s.tasks.background.length }}</div>
              <div class="sub">{{ t('tag.background') }}</div></div>
            <div class="panel kpi done"><div class="k">{{ t('kpi.done') }}</div><div class="v" v-flash>{{ s.dash ? s.dash.completed_today : '—' }}</div></div>
            <div class="panel kpi calls"><div class="k">{{ t('kpi.calls') }}</div><div class="v" v-flash>{{ s.dash ? s.dash.calls_today : '—' }}</div>
              <div class="sub" v-if="s.dash">{{ t('kpi.calls_sub', {a: s.dash.calls_answered, m: s.dash.calls_missed}) }}</div></div>
            <div class="panel kpi time"><div class="k">{{ t('kpi.busy') }}</div><div class="v">{{ s.dash ? dur(s.dash.busy_sec_today) : '—' }}</div>
              <div class="sub">{{ t('kpi.busy_sub') }}</div></div>
          </div>
          </template>
          <template v-else-if="w.id==='active'">
          <section class="panel">
            <h2>{{ t('panel.active') }} <span class="count">{{ s.tasks.blocking.length }}</span></h2>
            <div class="body">
              <div v-if="!s.tasks.blocking.length" class="empty">{{ t('panel.active_empty') }}</div>
              <div v-for="w in s.tasks.blocking" :key="w.id" class="item">
                <div class="title"><a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a> {{ w.ticket_title }}</div>
                <div class="meta"><span class="tag blocking">{{ t('tag.blocking') }}</span><span v-if="w.source">{{ srcText(w.source) }}</span><span>{{ t('since') }} {{ fmt(w.started_at) }}</span></div>
                <div class="actions">
                  <button class="btn go sm" @click="openComplete(w)">{{ t('btn.complete') }}</button>
                  <button class="btn sm" @click="changeMode(w, 'background')">{{ t('btn.background') }}</button>
                  <button class="btn sm" @click="release(w)">{{ t('btn.postpone') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='background'">
          <section class="panel">
            <h2>{{ t('panel.background') }} <span class="count">{{ s.tasks.background.length }}</span></h2>
            <div class="body">
              <div v-if="!s.tasks.background.length" class="empty">{{ t('panel.background_empty') }}</div>
              <div v-for="w in s.tasks.background" :key="w.id" class="item">
                <div class="title"><a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a> {{ w.ticket_title }}</div>
                <div class="meta"><span class="tag background">{{ t('tag.background') }}</span><span v-if="w.source">{{ srcText(w.source) }}</span><span>{{ t('since') }} {{ fmt(w.started_at, true) }}</span></div>
                <div class="actions">
                  <button class="btn primary sm" @click="changeMode(w, 'blocking')">{{ t('btn.start') }}</button>
                  <button class="btn go sm" @click="openComplete(w)">{{ t('btn.complete') }}</button>
                  <button class="btn sm" @click="release(w)">{{ t('btn.remove') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='notifications'">
          <section class="panel ntf-panel">
            <h2>{{ t('ntf.title') }} <span class="h-actions">
              <button v-if="s.ntf.unread" class="btn sm" @click="markRead">{{ t('ntf.mark_read') }}</button>
              <button v-if="s.desktop==='default'" class="btn sm" @click="enableDesktop">{{ t('ntf.desktop') }}</button>
            </span></h2>
            <div class="body">
              <div v-if="!s.ntf.items.length" class="empty">{{ t('ntf.empty') }}</div>
              <div v-for="n in s.ntf.items" :key="n.id" class="ntf-item" :class="[n.level, {unread: isUnread(n), clickable: n.ticket_id}]" @click="n.ticket_id && openTicket(n.ticket_id)">
                <span class="ico">{{ ntfIcon(n) }}</span><div class="txt">{{ n.text }}<div class="when">{{ fmt(n.ts, true) }}</div></div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='new'">
          <section class="panel">
            <h2>{{ t('panel.new') }} <span class="count">{{ s.unassigned.length }}</span></h2>
            <div class="body">
              <div v-if="!s.unassigned.length" class="empty">{{ t('panel.new_empty') }}</div>
              <div v-for="tk in s.unassigned" :key="tk.id" class="item">
                <div class="title"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }}</div>
                <div class="meta"><span class="tag">{{ srcText(tk.source) || '—' }}</span><span>{{ tk.group }}</span><span>{{ fmt(tk.created_at, true) }}</span></div>
                <div class="actions">
                  <button class="btn primary sm" @click="startTicket(tk, 'blocking')">{{ t('btn.start') }}</button>
                  <button class="btn sm" @click="startTicket(tk, 'background')">{{ t('btn.background') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='mine'">
          <section class="panel">
            <h2>{{ t('panel.mine') }} <span class="count">{{ freeMine.length }}</span></h2>
            <div class="body">
              <div v-if="!freeMine.length" class="empty">{{ t('panel.mine_empty') }}</div>
              <div v-for="tk in freeMine" :key="tk.id" class="item">
                <div class="title"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }}</div>
                <div class="meta"><span class="tag">{{ tk.state }}</span><span>{{ srcText(tk.source) }}</span><span>{{ fmt(tk.updated_at, true) }}</span></div>
                <div class="actions">
                  <button class="btn primary sm" @click="startTicket(tk, 'blocking')">{{ t('btn.start') }}</button>
                  <button class="btn sm" @click="startTicket(tk, 'background')">{{ t('btn.background') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='pending'">
          <section class="panel">
            <h2>{{ t('panel.pending') }} <span class="count">{{ s.mine.pending.length }}</span></h2>
            <div class="body">
              <div v-if="!s.mine.pending.length" class="empty">{{ t('panel.pending_empty') }}</div>
              <div v-for="tk in s.mine.pending" :key="tk.id" class="item">
                <div class="title"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }}</div>
                <div class="meta"><span class="tag">{{ tk.state }}</span><span>{{ fmt(tk.updated_at, true) }}</span></div>
                <div class="actions" v-if="!tk.session"><button class="btn sm" @click="startTicket(tk, 'blocking')">{{ t('btn.start') }}</button></div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='calls'">
          <section class="panel">
            <h2>{{ t('panel.calls') }} <span class="count">{{ s.calls.length }}</span></h2>
            <div class="body">
              <div v-if="!s.calls.length" class="empty">{{ t('panel.calls_empty') }}</div>
              <div v-for="c in s.calls" :key="c.id" class="item">
                <div class="title">{{ c.direction==='out' ? '↗' : '↙' }} {{ c.caller_number || t('hidden') }} <span class="empty">{{ c.caller_name }}</span></div>
                <div class="meta">
                  <span class="tag">{{ callText(c.state) }}</span>
                  <span>{{ fmt(c.started_at, true) }}</span><span v-if="c.queue">{{ t('call.queue') }} {{ c.queue }}</span>
                  <a v-if="c.ticket_id" :href="zLink(c.ticket_id)" @click.prevent="openTicket(c.ticket_id)">{{ t('link.ticket') }}</a>
                  <a v-if="c.recording_url" :href="c.recording_url" target="_blank" @click="playRecording($event, c)">{{ t('link.recording') }}</a>
                </div>
                <div class="actions"><button v-if="!c.ticket_id" class="btn sm" @click="reopenCall(c)">{{ t('btn.card') }}</button>
                  <button v-if="c.caller_number" class="btn sm dial-btn" @click="dialNumber(c.caller_number, c.caller_name)" data-act="call-back"><ico name="phone"></ico> {{ t('ph.call') }}</button></div>
              </div>
            </div>
          </section>
          </template>
        </div>
      </div>
    </template>

    <!-- ===================== TICKETS & CUSTOMERS (v3.3) ===================== -->
    <tickets-page v-if="s.tab==='tickets' && isOperatorView" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :config="s.config"
                  :token="s.token" :open-req="s.tkOpen" :new-req="s.tkNew" :state-text="stateText"
                  @open-customer="(id) => openContact(id, 'customers')"></tickets-page>
    <contacts-page v-if="s.tab==='contacts'" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :open-req="s.ctOpen"
                   @open-ticket="openTicket" @new-ticket="newTicketFor"></contacts-page>

    <!-- ===================== WHATSAPP / TELEGRAM (v3.9) and MAIL ===================== -->
    <inbox-page v-if="(s.tab==='whatsapp' || s.tab==='telegram') && isOperatorView" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :token="s.token"
                :channel="s.tab" :open-req="s.inOpen" @open-ticket="openTicket" @open-customer="(id) => openContact(id, 'customers')"
                @counts="(c) => s.msgCounts = c"></inbox-page>
    <mail-page v-if="s.tab==='mail' && isOperatorView" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :token="s.token"
               @open-ticket="openTicket" @unseen="(n) => s.mailUnseen = n"></mail-page>

    <!-- ===================== MY SETTINGS ===================== -->
    <div v-if="s.tab==='mysettings'" class="my-settings">
      <section class="panel">
        <h2>{{ t('set.appearance') }}</h2>
        <div class="body">
          <label>{{ t('set.theme') }}</label>
          <div class="seg">
            <button :class="{on: !s.theme || s.theme==='dark'}" data-theme-opt="dark" @click="setTheme('dark')">{{ t('set.theme_dark') }}</button>
            <button :class="{on: s.theme==='light'}" data-theme-opt="light" @click="setTheme('light')">{{ t('set.theme_light') }}</button>
            <button :class="{on: s.theme==='system'}" data-theme-opt="system" @click="setTheme('system')">{{ t('set.theme_system') }}</button>
          </div>
          <label class="check" v-if="isOperatorView"><input type="checkbox" name="compact" :checked="s.prefs.compact" @change="toggleCompact"> {{ t('set.compact') }}</label>
          <label class="check"><input type="checkbox" name="motion" :checked="s.prefs.motion" @change="toggleMotion"> {{ t('set.motion') }}</label>
          <div class="hint">{{ t('set.motion_hint') }}</div>
        </div>
      </section>

      <section class="panel" v-if="isOperatorView">
        <h2>{{ t('set.workspace') }} <span class="h-actions"><button class="btn sm primary" @click="startEditing"><ico name="edit" style="width:15px;height:15px"></ico> {{ t('ws.customize') }}</button></span></h2>
        <div class="body">
          <div class="hint" style="margin-bottom:12px">{{ t('set.workspace_hint') }}</div>
          <div class="presets">
            <button v-for="p in presetIds" :key="p" class="preset" :class="{on: s.prefs.preset===p}" :data-preset="p" @click="applyPreset(p)">
              <div class="mini"><span v-for="w in PRESETS_PREVIEW[p]" :key="w.id" :class="'m' + w.w + ' mh-' + w.h"></span></div>
              <b>{{ t('preset.' + p) }}</b> <span v-if="s.prefs.preset===p" class="tag ok">{{ t('set.current') }}</span>
              <div class="hint">{{ t('preset.' + p + '_d') }}</div>
            </button>
            <div v-if="s.prefs.preset==='custom'" class="preset on"><div class="mini"><span v-for="w in visibleLayout" :key="w.id" :class="'m' + w.w + ' mh-' + w.h"></span></div>
              <b>{{ t('preset.custom') }}</b> <span class="tag ok">{{ t('set.current') }}</span></div>
          </div>
        </div>
      </section>

      <section class="panel" v-if="isOperatorView">
        <h2>{{ t('set.alerts') }}</h2>
        <div class="body">
          <label class="check"><input type="checkbox" name="sound" :checked="s.prefs.sound" @change="toggleSound"> {{ t('set.sound') }}</label>
          <div class="push-row">
            <div><b>{{ t('push.title') }}</b><div class="hint">{{ t('push.hint') }}</div></div>
            <button v-if="s.push === 'off'" class="btn sm primary push-on" @click="enablePush">{{ t('push.enable') }}</button>
            <button v-else-if="s.push === 'on'" class="btn sm push-off" @click="disablePush">{{ t('push.disable') }}</button>
            <span v-else class="tag off">{{ t('push.' + s.push) }}</span>
          </div>
          <div style="margin-top:10px">
            <button v-if="s.desktop==='default'" class="btn sm" @click="enableDesktop">{{ t('ntf.desktop') }}</button>
            <span v-else-if="s.desktop==='granted'" class="tag ok">{{ t('ntf.desktop_on') }}</span>
          </div>
        </div>
      </section>

      <phone-settings v-if="phoneOn" :t="t" :me="s.me" :api="api" :dnd="!!(s.state && s.state.dnd)"></phone-settings>

      <section class="panel">
        <h2>{{ t('set.account') }} <span class="h-actions"><button class="btn sm" @click="openPassword"><ico name="key" style="width:15px;height:15px"></ico> {{ t('btn.change_password') }}</button></span></h2>
        <div class="body account">
          <div><span>{{ t('set.name') }}</span><b>{{ s.me.name }}</b></div>
          <div><span>{{ t('set.username') }}</span><b>{{ s.me.username }}</b></div>
          <div><span>{{ t('set.level') }}</span><b>{{ levelText(s.me.level) }}</b></div>
          <div><span>{{ t('set.position') }}</span><b>{{ s.me.position || '—' }}</b></div>
          <div><span>{{ t('set.role') }}</span><b>{{ roleText(s.me.role) }}</b></div>
          <div v-if="s.me.extension"><span>{{ t('ext') }}</span><b>{{ s.me.extension }}</b></div>
        </div>
      </section>
    </div>

    <!-- ===================== ADMIN ===================== -->
    <admin-panel v-if="isAdmin && ['users','integrations','settings','types','system'].includes(s.tab)"
                 :view="s.tab" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me"></admin-panel>

    <!-- ===================== MESSENGER (v3.0) ===================== -->
    <div v-if="s.tab==='chat'" class="chat" :class="{'has-peer': s.chat.peer, 'info-open': s.chat.info && chatPeer}">
      <aside class="chat-list" :aria-label="t('nav.chat')">
        <label class="chat-search">
          <ico name="search"></ico>
          <input v-model="s.chat.q" @input="searchContacts" name="chat-search" type="search" :placeholder="t('chat.search')" autocomplete="off">
        </label>
        <button v-if="s.push === 'off'" class="push-banner" @click="enablePush"><ico name="bell"></ico><span>{{ t('push.banner') }}</span></button>
        <div v-if="s.chat.q.trim()" class="chat-sec">{{ t('chat.search_results') }}</div>
        <transition-group name="cl" tag="div" class="chat-items">
          <button v-for="c in s.chat.contacts" :key="c.id" class="chat-item" :class="{on: c.id === s.chat.peer}" :data-user="c.id" @click="openChat(c)">
            <span class="av" :class="avClass(c.id)">{{ initials2(c.name) }}<i v-if="c.online" class="av-online" aria-hidden="true"></i></span>
            <span class="ci-main">
              <span class="ci-top"><b class="ci-name">{{ c.name }}</b><time v-if="c.last">{{ shortTime(c.last.at) }}</time></span>
              <span class="ci-bottom">
                <span v-if="s.chat.typing[c.id] > s.clock" class="ci-prev typing">{{ t('chat.typing') }}</span>
                <span v-else-if="c.last" class="ci-prev"><span v-if="c.last.from === s.me.id" class="you">{{ t('chat.you') }}: </span>{{ c.last.body }}</span>
                <span v-else class="ci-prev muted">{{ c.position || levelText(c.level) || roleText(c.role) }}</span>
                <span v-if="c.unread" class="ci-badge">{{ c.unread }}</span>
                <ico v-else-if="c.last && c.last.from === s.me.id" :name="c.last.read_at ? 'checks' : 'check'" class="tick" :class="{read: c.last.read_at}"></ico>
              </span>
            </span>
          </button>
          <div v-if="!s.chat.contacts.length" key="none" class="chat-none">{{ s.chat.q ? t('chat.nobody') : t('chat.no_chats') }}</div>
        </transition-group>
      </aside>

      <section class="chat-main">
        <template v-if="s.chat.peer">
          <header class="chat-head">
            <button class="chat-back" @click="chatBack" :aria-label="t('chat.back')"><ico name="back"></ico></button>
            <button class="ch-person" @click="toggleChatInfo" :title="t('chat.info')">
              <span class="av sm" :class="avClass(s.chat.peer)">{{ initials2(chatPeer && chatPeer.name) }}<i v-if="chatPeer && chatPeer.online" class="av-online" aria-hidden="true"></i></span>
              <span class="ch-text"><b>{{ chatPeer ? chatPeer.name : '' }}</b>
                <small :class="{on: chatPeer && (chatPeer.online || s.chat.typing[chatPeer.id] > s.clock)}">{{ lastSeen(chatPeer) }}</small></span>
            </button>
            <span class="spacer"></span>
            <button class="ch-btn" :class="{on: s.chat.info}" @click="toggleChatInfo" :aria-label="t('chat.info')" :title="t('chat.info')"><ico name="sidebar"></ico></button>
          </header>
          <div class="chat-scroll" @scroll.passive="onChatScroll">
            <div class="chat-msgs">
              <div v-if="s.chat.hasMore" class="chat-more">{{ t('ov.loading') }}</div>
              <div v-if="!s.chat.loading && !s.chat.msgs.length" class="chat-hello">
                <div class="hello-card"><b>{{ t('chat.hello_title') }}</b><span>{{ t('chat.hello_text', {name: chatPeer ? chatPeer.name : ''}) }}</span></div>
              </div>
              <template v-for="it in chatItems" :key="it.key">
                <div v-if="it.kind === 'day'" class="chat-day"><span>{{ it.label }}</span></div>
                <div v-else class="bubble-row" :class="{mine: it.mine, first: it.first, last: it.last, menu: s.chat.menu && s.chat.menu.m.id === it.m.id}">
                  <div class="bubble" :data-msg="it.m.id" @contextmenu.prevent="openMenu($event, it)"
                       @touchstart.passive="pressStart($event, it)" @touchend="pressEnd" @touchmove.passive="pressEnd">
                    <span class="b-text">{{ it.m.body }}</span>
                    <span class="b-meta"><span v-if="it.m.edited_at" class="b-edited">{{ t('chat.edited') }}</span><time>{{ fmt(it.m.at) }}</time>
                      <ico v-if="it.mine" :name="it.m.read_at ? 'checks' : 'check'" class="tick" :class="{read: it.m.read_at}"></ico></span>
                    <div v-if="it.m.reactions && it.m.reactions.length" class="b-reacts">
                      <button v-for="r in reactionsOf(it.m)" :key="r.emoji" class="react-chip" :class="{mine: r.mine}" @click="react(it.m, r.emoji)"
                              :aria-pressed="r.mine">{{ r.emoji }}<b v-if="r.n > 1">{{ r.n }}</b></button>
                    </div>
                  </div>
                  <button class="b-more" @click.stop="openMenu($event, it)" :aria-label="t('chat.actions')"><ico name="more"></ico></button>
                </div>
              </template>
            </div>
          </div>
          <div v-if="s.chat.menu" class="msg-menu" :style="{left: s.chat.menu.x + 'px', top: s.chat.menu.y + 'px'}" role="menu">
            <div class="mm-reacts">
              <button v-for="em in REACTIONS" :key="em" class="mm-react" :data-emoji="em" @click="react(s.chat.menu.m, em)">{{ em }}</button>
            </div>
            <button class="mm-item" role="menuitem" @click="copyMsg(s.chat.menu.m)"><ico name="copy"></ico>{{ t('chat.copy') }}</button>
            <button v-if="canEdit(s.chat.menu.m)" class="mm-item mm-edit" role="menuitem" @click="startEdit(s.chat.menu.m)"><ico name="edit"></ico>{{ t('chat.edit') }}</button>
            <button class="mm-item danger mm-delete" role="menuitem" @click="askDelete(s.chat.menu.m)"><ico name="trash"></ico>{{ t('chat.delete') }}</button>
          </div>
          <div v-if="s.chat.del" class="chat-dialog-wrap" @click.self="s.chat.del = null">
            <div class="chat-dialog" role="dialog" aria-modal="true">
              <b>{{ t('chat.delete_q') }}</b>
              <p>{{ s.chat.del.m.body.length > 120 ? s.chat.del.m.body.slice(0, 120) + '…' : s.chat.del.m.body }}</p>
              <label v-if="s.chat.del.m.from === s.me.id" class="check"><input type="checkbox" name="del-all" v-model="s.chat.del.all"> {{ t('chat.delete_all', {name: chatPeer ? chatPeer.name : ''}) }}</label>
              <div v-else class="hint">{{ t('chat.delete_me_only') }}</div>
              <div class="cd-actions"><button class="btn" @click="s.chat.del = null">{{ t('modal.cancel') }}</button>
                <button class="btn danger cd-confirm" @click="confirmDelete">{{ t('chat.delete') }}</button></div>
            </div>
          </div>
          <div v-if="s.chat.editing" class="edit-strip"><ico name="edit"></ico>
            <div><b>{{ t('chat.editing') }}</b><span>{{ s.chat.editing.body }}</span></div>
            <button class="ch-btn" @click="cancelEdit" :aria-label="t('modal.cancel')"><ico name="close"></ico></button></div>
          <form class="chat-compose" @submit.prevent="sendChat">
            <textarea v-model="s.chat.text" name="chat-text" rows="1" maxlength="4000" :placeholder="t('chat.write')"
                      @keydown.enter.exact.prevent="sendChat" @keydown.up="editLast" @input="onType"></textarea>
            <button class="send-btn" type="submit" :disabled="!s.chat.text.trim() || s.chat.sending" :aria-label="s.chat.editing ? t('chat.save') : t('chat.send')"><ico :name="s.chat.editing ? 'check' : 'send'"></ico></button>
          </form>
        </template>
        <div v-else class="chat-empty"><span>{{ t('chat.pick') }}</span></div>
      </section>

      <aside v-if="s.chat.info && chatPeer" class="chat-info" :aria-label="t('chat.info')">
        <div class="ci-head">
          <span class="ci-title">{{ t('chat.info') }}</span>
          <button class="ch-btn" @click="s.chat.info = false" :aria-label="t('modal.cancel')"><ico name="close"></ico></button>
        </div>
        <div class="ci-hero">
          <span class="av xl" :class="avClass(chatPeer.id)">{{ initials2(chatPeer.name) }}<i v-if="chatPeer.online" class="av-online" aria-hidden="true"></i></span>
          <b>{{ chatPeer.name }}</b>
          <small :class="{on: chatPeer.online}">{{ lastSeen(chatPeer) }}</small>
        </div>
        <div class="ci-rows" v-if="s.chat.profile">
          <div class="ci-row" v-if="s.chat.profile.position"><ico name="briefcase"></ico><div><b>{{ s.chat.profile.position }}</b><span>{{ t('set.position') }}</span></div></div>
          <div class="ci-row"><ico name="layers"></ico><div><b>{{ levelText(s.chat.profile.level) || roleText(s.chat.profile.role) }}</b><span>{{ t('set.level') }}</span></div></div>
          <div class="ci-row" v-if="s.chat.profile.extension"><ico name="phone"></ico><div><b class="mono">{{ s.chat.profile.extension }}</b><span>{{ t('ext') }}</span></div></div>
          <div class="ci-row" v-if="s.chat.profile.username"><ico name="at"></ico><div><b>@{{ s.chat.profile.username }}</b><span>{{ t('set.username') }}</span></div></div>
          <div class="ci-row"><span class="status" :class="'st-' + s.chat.profile.state"><span class="dot"></span>{{ s.chat.profile.state_label }}</span>
            <div><span>{{ s.chat.profile.reason }}</span></div></div>
          <div class="ci-sep"></div>
          <div class="ci-row"><ico name="chat"></ico><div><b>{{ s.chat.profile.messages_total }}</b><span>{{ t('chat.messages_total', {w: s.chat.profile.messages_week}) }}</span></div></div>
          <div class="ci-row" v-if="s.chat.profile.member_since"><ico name="calendar"></ico><div><b>{{ dayLabel(s.chat.profile.member_since) }}</b><span>{{ t('chat.member_since') }}</span></div></div>
        </div>
      </aside>
    </div>

    <!-- ===================== MANAGER OVERVIEW (v2.5) ===================== -->
    <div v-if="s.tab==='overview' && isSup" class="ov">
      <div class="ov-bar">
        <div class="seg ov-period">
          <button v-for="p in ['today','yesterday','7d','30d']" :key="p" :data-period="p" :class="{on: s.ov.period===p}" @click="setPeriod(p)">{{ t('ov.' + p) }}</button>
        </div>
        <div class="level-filter ov-levels">
          <button :class="{on: !s.sup.level}" @click="s.sup.level = ''">{{ t('team.all') }}</button>
          <button v-for="l in ['level1','level2','level3','manager']" :key="l" :data-level="l" :class="{on: s.sup.level === l}" @click="s.sup.level = l">{{ levelText(l) }}</button>
        </div>
        <span class="spacer"></span>
        <span class="ov-updated" v-if="s.ov.updated">{{ t('ov.updated') }} {{ fmt(s.ov.updated) }}</span>
        <button class="btn sm" @click="refreshOverview()" :disabled="s.ov.loading">{{ s.ov.loading ? t('ov.loading') : t('ov.refresh') }}</button>
      </div>

      <div v-if="!s.ov.data" class="skeleton-grid" aria-busy="true" :aria-label="t('ov.loading')">
        <div v-for="n in 5" :key="n" class="skeleton sk-tile"></div><div class="skeleton sk-wide"></div><div class="skeleton sk-side"></div>
      </div>
      <template v-else>
      <!-- tiles -->
      <div class="ov-tiles">
        <section class="panel tile tile-calls">
          <h2>{{ t('ov.offered') }}</h2>
          <div class="big" v-flash>{{ s.ov.data.calls.offered }}</div>
          <div class="tile-sub"><b class="ok-ink">{{ s.ov.data.calls.answered }}</b> {{ t('ov.answered') }}</div>
          <div class="tile-alert" :class="{on: s.ov.data.calls.missed > 0}">
            <div class="mid">{{ s.ov.data.calls.missed }}</div>
            <div><b>{{ t('ov.missed_calls') }}</b>
              <div class="tile-sub">{{ t('ov.missed_sub', {a: s.ov.data.calls.abandoned, u: s.ov.data.calls.unanswered}) }}</div>
              <div class="tile-sub muted" v-if="s.ov.data.calls.short_abandoned">{{ t('ov.short', {n: s.ov.data.calls.short_abandoned, s: s.ov.data.settings.short_abandon_seconds}) }}</div></div>
          </div>
        </section>
        <section class="panel tile tile-sl" :class="slClass">
          <h2>{{ t('ov.sl') }}</h2>
          <svg viewBox="0 0 180 104" class="gauge" role="img" :aria-label="t('ov.sl') + ' ' + pct(s.ov.data.calls.service_level)">
            <path :d="gauge.track" class="g-track"></path>
            <path v-if="!gauge.empty" :d="gauge.value" class="g-value" pathLength="1"></path>
            <line :x1="gauge.target.x1" :y1="gauge.target.y1" :x2="gauge.target.x2" :y2="gauge.target.y2" class="g-target"></line>
            <text x="20" y="103" class="g-axis">0</text><text x="160" y="103" class="g-axis" text-anchor="end">100</text>
          </svg>
          <div class="gauge-val">{{ pct(s.ov.data.calls.service_level) }}</div>
          <div class="tile-sub center">{{ t('ov.sl_sub', {s: s.ov.data.settings.sla_answer_seconds, p: pct(s.ov.data.settings.sla_target)}) }}</div>
        </section>
        <section class="panel tile">
          <h2>{{ t('ov.answer_rate') }}</h2>
          <div class="big">{{ pct(s.ov.data.calls.answer_rate) }}</div>
          <div class="tile-sub">{{ t('ov.abandon_rate', {p: pct(s.ov.data.calls.abandon_rate)}) }}</div>
          <h2 class="h-inner">{{ t('ov.asa') }}</h2>
          <div class="mid">{{ secs(s.ov.data.calls.asa_sec) }}</div>
          <div class="tile-sub">{{ t('ov.longest', {v: secs(s.ov.data.calls.longest_wait_sec)}) }}</div>
        </section>
        <section class="panel tile">
          <h2>{{ t('ov.aht') }}</h2>
          <div class="big">{{ secs(s.ov.data.calls.aht_talk_sec) }}</div>
          <div class="tile-sub">{{ t('ov.talk_total', {v: dur(s.ov.data.calls.talk_sec)}) }}</div>
          <h2 class="h-inner">{{ t('ov.outbound') }}</h2>
          <div class="mid">{{ s.ov.data.calls.outbound }}</div>
          <div class="tile-sub">{{ t('ov.outbound_sub', {c: s.ov.data.calls.outbound_connected}) }}</div>
        </section>
        <section class="panel tile tile-live" :class="{alert: s.ov.data.live.waiting > 0}">
          <h2>{{ t('ov.live') }} <span class="live-dot" aria-hidden="true"></span></h2>
          <div class="big" v-flash>{{ s.ov.data.live.waiting }}</div>
          <div class="tile-sub">{{ t('ov.waiting') }}<span v-if="s.ov.data.live.waiting"> · {{ t('ov.longest_now', {v: secs(liveWait)}) }}</span></div>
          <div class="live-grid">
            <div><b>{{ s.ov.data.live.talking }}</b><span>{{ t('ov.talking') }}</span></div>
            <div><b class="st-c st-ready">{{ s.ov.data.live.agents.ready }}</b><span>{{ t('ov.ready') }}</span></div>
            <div><b class="st-c st-busy_task">{{ s.ov.data.live.agents.busy_task + s.ov.data.live.agents.wrap_up }}</b><span>{{ t('ov.busy') }}</span></div>
            <div><b class="st-c st-break">{{ s.ov.data.live.agents.break }}</b><span>{{ t('ov.break') }}</span></div>
          </div>
        </section>
      </div>

      <!-- charts + leaders -->
      <div class="ov-row">
        <section class="panel ov-chart">
          <h2>{{ s.ov.data.bucket==='hour' ? t('ov.calls_chart') : t('ov.calls_chart_day') }}
            <span class="h-actions legend"><span><i class="sw sw-ans"></i>{{ t('ov.legend.answered') }}</span><span><i class="sw sw-mis"></i>{{ t('ov.legend.missed') }}</span></span></h2>
          <div class="body chart-box" @mouseleave="s.ov.hover = -1">
            <svg :key="'c' + s.ov.period" :viewBox="'0 0 ' + callChart.w + ' ' + callChart.h" class="chart" role="img" :aria-label="t('ov.calls_chart')">
              <g v-for="g in callChart.grid" :key="g.y"><line :x1="callChart.l" :x2="callChart.w - callChart.r" :y1="g.y" :y2="g.y" class="grid-line"></line>
                <text :x="callChart.l - 6" :y="g.y + 4" text-anchor="end" class="axis-t">{{ g.v }}</text></g>
              <g v-for="b in callChart.bars" :key="b.i" :class="{dim: b.future, hov: s.ov.hover === b.i}" :style="{'--i': b.i}">
                <rect v-if="b.ans.h > 0" :x="b.x" :y="b.ans.y" :width="b.w" :height="b.ans.h" rx="3" class="bar-ans"></rect>
                <rect v-if="b.mis.h > 0" :x="b.x" :y="b.mis.y" :width="b.w" :height="b.mis.h" rx="3" class="bar-mis"></rect>
                <text v-if="b.showLabel" :x="b.cx" :y="callChart.base + 17" text-anchor="middle" class="axis-t">{{ b.label }}</text>
                <rect :x="b.hit.x" :y="callChart.t" :width="b.hit.w" :height="callChart.base - callChart.t" class="hit" @mouseenter="s.ov.hover = b.i"></rect>
              </g>
              <line :x1="callChart.l" :x2="callChart.w - callChart.r" :y1="callChart.base" :y2="callChart.base" class="base-line"></line>
            </svg>
            <div v-if="ovHover" class="chart-tip" :style="{left: (ovHover.cx / callChart.w * 100) + '%'}">
              <b>{{ ovHover.label }}</b>
              <div><i class="sw sw-ans"></i>{{ t('ov.legend.answered') }}: {{ ovHover.d.answered }}</div>
              <div><i class="sw sw-mis"></i>{{ t('ov.legend.missed') }}: {{ ovHover.d.missed }}</div>
              <div class="muted">{{ t('ov.sl') }}: {{ pct(ovHover.d.service_level) }}</div>
            </div>
          </div>
          <div class="chart-foot" v-if="s.ov.data.peak">{{ t('ov.peak', {l: s.ov.data.peak.label, n: s.ov.data.peak.offered}) }}</div>
        </section>
        <section class="panel ov-leaders">
          <h2>{{ t('ov.top_calls') }}</h2>
          <div class="body">
            <div v-if="!s.ov.data.leaders.answered.length" class="empty">{{ t('ov.none_yet') }}</div>
            <div v-for="(x, i) in s.ov.data.leaders.answered" :key="x.agent_id" class="lead"><span class="rank">{{ i + 1 }}</span><span class="nm">{{ x.name }}</span><b>{{ x.value }}</b></div>
          </div>
          <h2>{{ t('ov.top_tickets') }}</h2>
          <div class="body">
            <div v-if="!s.ov.data.leaders.tickets.length" class="empty">{{ t('ov.none_yet') }}</div>
            <div v-for="(x, i) in s.ov.data.leaders.tickets" :key="x.agent_id" class="lead"><span class="rank">{{ i + 1 }}</span><span class="nm">{{ x.name }}</span><b>{{ x.value }}</b></div>
          </div>
        </section>
      </div>

      <div class="ov-row">
        <section class="panel ov-chart">
          <h2>{{ t('ov.load_chart') }}
            <span class="h-actions legend"><span><i class="ln ln-ag"></i>{{ t('ov.load_agents') }}</span><span><i class="ln ln-erl"></i>{{ t('ov.load_erl') }}</span></span></h2>
          <div class="body">
            <svg :key="'l' + s.ov.period" :viewBox="'0 0 ' + loadChart.w + ' ' + loadChart.h" class="chart" role="img" :aria-label="t('ov.load_chart')">
              <g v-for="g in loadChart.grid" :key="g.y"><line :x1="loadChart.l" :x2="loadChart.w - loadChart.r" :y1="g.y" :y2="g.y" class="grid-line"></line>
                <text :x="loadChart.l - 6" :y="g.y + 4" text-anchor="end" class="axis-t">{{ g.v }}</text></g>
              <path :d="loadChart.agents" class="line-ag" pathLength="1"></path>
              <path :d="loadChart.erl" class="line-erl"></path>
              <g v-for="(x, i) in loadChart.labels" :key="i"><text v-if="x.show" :x="x.x" :y="loadChart.base + 17" text-anchor="middle" class="axis-t">{{ x.label }}</text></g>
            </svg>
            <div class="hint">{{ t('ov.load_hint') }}</div>
          </div>
        </section>
        <section class="panel tile">
          <h2>{{ t('ov.team') }}</h2>
          <div class="big">{{ pct(s.ov.data.team.occupancy) }}</div>
          <div class="tile-sub">{{ t('ov.occupancy') }} · {{ t('ov.worked', {n: s.ov.data.team.agents_worked}) }}</div>
          <div class="tile-sub">{{ t('ov.logged', {v: dur(s.ov.data.team.logged_in_sec)}) }}</div>
          <h2 class="h-inner">{{ t('ov.tickets') }}</h2>
          <div class="kv"><span>{{ t('ov.t_started') }}</span><b>{{ s.ov.data.tickets.started }}</b></div>
          <div class="kv"><span>{{ t('ov.t_done') }}</span><b>{{ s.ov.data.tickets.completed }}</b></div>
          <div class="kv"><span>{{ t('ov.t_avg') }}</span><b>{{ s.ov.data.tickets.avg_work_sec === null ? '—' : dur(s.ov.data.tickets.avg_work_sec) }}</b></div>
          <div class="chips"><span v-for="(n, ch) in s.ov.data.tickets.by_channel" :key="ch" class="tag">{{ srcText(ch) || ch }} {{ n }}</span></div>
          <div class="tile-sub">{{ t('ov.t_active', {b: s.ov.data.tickets.active_blocking, g: s.ov.data.tickets.active_background}) }}</div>
        </section>
      </div>

        <section class="panel ov-unret" :class="{alert: s.ov.data.unreturned_count > 0}">
          <h2><span>{{ t('ov.unreturned') }} <span class="count">{{ s.ov.data.unreturned_count }}</span></span></h2>
          <div class="body unret-grid">
            <div v-if="!s.ov.data.unreturned.length" class="empty">{{ t('ov.unreturned_none') }}</div>
            <div v-for="u in s.ov.data.unreturned" :key="u.number" class="item unret">
              <div class="title mono">{{ u.number }} <span class="empty" v-if="u.name">{{ u.name }}</span></div>
              <div class="meta"><span>{{ fmt(u.last_missed_at, s.ov.period !== 'today') }}</span><span>{{ t('ov.attempts', {n: u.attempts}) }}</span>
                <span class="warn-ink">{{ t('ov.ago', {n: u.waiting_min}) }}</span></div>
            </div>
          </div>
        </section>

      <!-- operators -->
      <section class="panel ov-agents">
        <h2><span>{{ t('ov.agents') }} <span class="count">{{ ovAgents.length }}</span></span>
          <span class="h-actions"><label class="inline">{{ t('ov.sort') }}
            <select v-model="s.ov.sort" name="ov-sort">
              <option value="engagement">{{ t('ov.col.score') }}</option><option value="calls_answered">{{ t('ov.col.calls') }}</option>
              <option value="tickets_completed">{{ t('ov.col.tickets') }}</option><option value="occupancy">{{ t('ov.col.occ') }}</option>
              <option value="rona">{{ t('ov.col.rona') }}</option><option value="break_sec">{{ t('ov.col.break') }}</option>
              <option value="logged_in_sec">{{ t('ov.col.logged') }}</option></select></label></span></h2>
        <div class="table-wrap"><table class="ov-table">
          <thead><tr><th>{{ t('ov.col.operator') }}</th><th>{{ t('ov.col.now') }}</th><th>{{ t('ov.col.logged') }}</th><th>{{ t('ov.col.ready') }}</th>
            <th>{{ t('ov.col.break') }}</th><th>{{ t('ov.col.occ') }}</th><th>{{ t('ov.col.calls') }}</th><th>{{ t('ov.col.rona') }}</th>
            <th>{{ t('ov.col.talk') }}</th><th>{{ t('ov.col.tickets') }}</th><th>{{ t('ov.col.score') }}</th></tr></thead>
          <tbody>
            <tr v-for="a in ovAgents" :key="a.agent_id" :data-agent="a.agent_id">
              <td><b>{{ a.name }}</b><div class="lvl">{{ levelText(a.level) }}</div>
                <div class="flags"><span v-for="f in a.flags" :key="f" class="flag" :class="'f-' + f" :title="t('flag.' + f + '_d')">{{ t('flag.' + f) }}</span></div></td>
              <td><span class="status" :class="'st-' + a.state_now"><span class="dot"></span>{{ stateText(a.state_now) }}</span></td>
              <td class="num">{{ dur(a.logged_in_sec) }}</td>
              <td class="num">{{ pct(a.ready_share) }}</td>
              <td class="num">{{ dur(a.break_sec) }}<div class="sub">{{ pct(a.break_share) }}</div></td>
              <td><div class="meter" :title="pct(a.occupancy)"><i :style="{width: Math.round((a.occupancy || 0) * 100) + '%'}"></i></div><span class="num">{{ pct(a.occupancy) }}</span></td>
              <td class="num">{{ t('ov.calls_fmt', {a: a.calls_answered, r: a.calls_rang}) }}<div class="sub" v-if="a.outbound">↗ {{ a.outbound }}</div></td>
              <td class="num" :class="{bad: a.rona > 0}">{{ a.rona }}</td>
              <td class="num">{{ dur(a.talk_sec) }}<div class="sub">{{ secs(a.aht_talk_sec) }}</div></td>
              <td class="num">{{ a.tickets_completed }}<div class="sub" v-if="a.avg_ticket_work_sec">{{ dur(a.avg_ticket_work_sec) }}</div></td>
              <td><span class="score" :class="scoreClass(a.engagement)">{{ a.engagement === null ? '—' : a.engagement }}</span></td>
            </tr>
          </tbody>
        </table></div>
      </section>

      <details class="panel ov-how">
        <summary>{{ t('ov.how') }}</summary>
        <ul>
          <li>{{ t('ov.how.offered') }}</li>
          <li>{{ t('ov.how.short', {s: s.ov.data.settings.short_abandon_seconds}) }}</li>
          <li>{{ t('ov.how.rates', {sl: s.ov.data.settings.sla_answer_seconds}) }}</li>
          <li>{{ t('ov.how.asa') }}</li><li>{{ t('ov.how.rona') }}</li><li>{{ t('ov.how.time') }}</li>
          <li>{{ t('ov.how.score') }}</li><li>{{ t('ov.how.unreturned') }}</li><li>{{ t('ov.how.load') }}</li>
        </ul>
      </details>
      </template>
    </div>

    <!-- ===================== SUPERVISOR ===================== -->
    <template v-if="s.tab==='sup' && isSup">
      <div v-if="!s.sup.ami" class="banner error">{{ t('sup.ami_down') }}</div>
      <div class="level-filter">
        <button :class="{on: !s.sup.level}" @click="s.sup.level = ''">{{ t('team.all') }} <span class="count">{{ s.sup.agents.length }}</span></button>
        <button v-for="l in teamLevels" :key="l.id" :data-level="l.id" :class="{on: s.sup.level === l.id}" @click="s.sup.level = l.id">
          {{ levelText(l.id) }} <span class="count">{{ l.n }}</span></button>
      </div>
      <div class="kpis sup-kpis">
        <div class="panel kpi k-online"><div class="k">{{ t('sup.k.online') }}</div><div class="v">{{ supCounts.online }}</div></div>
        <div class="panel kpi k-ready"><div class="k">{{ t('sup.k.ready') }}</div><div class="v" v-flash>{{ supCounts.ready }}</div></div>
        <div class="panel kpi k-busy"><div class="k">{{ t('sup.k.busy') }}</div><div class="v" v-flash>{{ supCounts.busy }}</div></div>
        <div class="panel kpi k-break"><div class="k">{{ t('sup.k.break') }}</div><div class="v">{{ supCounts.brk }}</div></div>
        <div class="panel kpi k-off"><div class="k">{{ t('sup.k.offline') }}</div><div class="v">{{ supCounts.offline }}</div></div>
        <div class="panel kpi k-err"><div class="k">{{ t('sup.k.sync') }}</div><div class="v" :class="{warn: supCounts.sync}">{{ supCounts.sync }}</div></div>
      </div>
      <section class="panel" style="margin-bottom:16px">
        <h2>{{ t('sup.operators') }} <span class="h-actions"><button class="btn sm primary assign-btn" @click="openAssign">{{ t('sup.assign') }}</button>
          <button class="btn sm" @click="refreshSup">{{ t('sup.refresh') }}</button></span></h2>
        <div class="table-wrap"><table>
          <thead><tr><th>{{ t('sup.col.operator') }}</th><th>{{ t('sup.col.state') }}</th><th>{{ t('sup.col.phone') }}</th><th>{{ t('sup.col.tasks') }}</th><th></th></tr></thead>
          <tbody>
            <tr v-for="a in teamAgents" :key="a.agent_id">
              <td><b>{{ a.name }}</b><div class="lvl">{{ levelText(a.level) }}</div><div class="empty">{{ a.position || roleText(a.role) }} · {{ t('ext') }} {{ a.extension || '—' }}</div></td>
              <td><span class="status" :class="'st-' + a.display_state" style="display:inline-flex"><span class="dot"></span>{{ stateText(a.display_state) }}</span>
                <div class="empty" style="margin-top:4px">{{ a.reason }}<span v-if="a.idle_since"> · {{ t('idle.since_short') }} {{ fmt(a.idle_since) }}</span><span v-if="a.override_ready"> · override: {{ a.override_reason }}</span></div>
                <span v-if="a.idle_since" class="tag idle-tag">{{ t('idle.tag') }}</span></td>
              <td>{{ a.phone_label }}<div v-if="a.sync_status!=='ok'" style="color:var(--danger)">{{ a.sync_status }}: {{ a.sync_error }}</div>
                <div class="empty" v-if="a.last_asterisk_sync_at">{{ t('sup.synced') }} {{ fmt(a.last_asterisk_sync_at) }}</div></td>
              <td>
                <div v-for="w in a.blocking" :key="w.id"><span class="tag blocking">B</span> <a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a> <a href="#" class="empty" @click.prevent="cancelSession(w)">{{ t('sup.cancel') }}</a></div>
                <div v-for="w in a.background" :key="w.id"><span class="tag background">F</span> <a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a></div>
                <span v-if="!a.blocking.length && !a.background.length" class="empty">—</span>
              </td>
              <td style="white-space:nowrap"><button class="btn sm" @click="reconcile(a)">{{ t('sup.reconcile') }}</button> <button class="btn sm warn" @click="openOverride(a)">{{ t('sup.override') }}</button></td>
            </tr>
          </tbody>
        </table></div>
      </section>

      <div class="grid" style="grid-template-columns: minmax(0,1fr) minmax(0,1fr)">
        <section class="panel" v-if="s.sup.report">
          <h2>{{ t('sup.report') }}</h2>
          <div class="table-wrap"><table>
            <thead><tr><th>{{ t('sup.col.operator') }}</th><th>{{ t('sup.col.completed') }}</th><th>{{ t('sup.col.blocking') }}</th><th>{{ t('sup.col.background') }}</th><th>{{ t('sup.col.paused') }}</th><th>{{ t('sup.col.errors') }}</th></tr></thead>
            <tbody><tr v-for="r in teamReport" :key="r.agent_id">
              <td>{{ r.name }}</td><td>{{ r.sessions_completed }}</td><td>{{ dur(r.blocking_work_sec) }}</td>
              <td>{{ dur(r.background_work_sec) }}</td><td>{{ dur(r.queue_paused_sec) }}</td><td>{{ r.sync_errors }}</td>
            </tr></tbody>
          </table></div>
        </section>
        <section class="panel">
          <h2>{{ t('sup.audit') }}
            <select v-model="s.sup.auditAgent" @change="refreshSup" style="width:auto;padding:2px 6px;text-transform:none">
              <option value="">{{ t('sup.all') }}</option><option v-for="a in s.sup.agents" :key="a.agent_id" :value="a.agent_id">{{ a.name }}</option>
            </select></h2>
          <div class="body" style="max-height:480px;overflow:auto">
            <div v-for="e in s.sup.audit" :key="e.id" class="item">
              <div><b :style="e.level==='error' ? 'color:var(--danger)' : e.level==='warning' ? 'color:var(--busy)' : ''">{{ e.action }}</b>
                <span class="empty"> · {{ fmt(e.ts, true) }} · {{ e.actor_type }}<span v-if="e.agent_id"> · {{ t('sup.operator') }} {{ e.agent_id }}</span><span v-if="e.ticket_id"> · {{ t('sup.ticket') }} {{ e.ticket_id }}</span></span></div>
              <div class="meta">{{ Object.entries(e.details || {}).map(([k,v]) => k + ': ' + (typeof v === 'object' ? JSON.stringify(v) : v)).join(' · ') }}</div>
            </div>
          </div>
        </section>
      </div>
    </template>
    </div>
  </main>
  </div>
</div>

  <!-- ===================== INACTIVITY (v2.8) ===================== -->
  <transition name="idle">
    <div v-if="isFrozen" class="idle-overlay" role="dialog" aria-modal="true" aria-labelledby="idle-title">
      <div class="idle-card">
        <div class="idle-ico" aria-hidden="true"><ico name="moon"></ico></div>
        <h2 id="idle-title">{{ t('idle.title') }}</h2>
        <p>{{ t('idle.text', {min: s.config.idle_timeout_min || 60}) }}</p>
        <div class="idle-since">{{ t('idle.since') }} <b>{{ idleSinceText }}</b></div>
        <div class="idle-actions">
          <button class="btn primary idle-back" @click="resumeIdle">{{ t('idle.back') }}</button>
          <button class="btn" @click="logout">{{ t('btn.logout') }}</button>
        </div>
      </div>
    </div>
  </transition>
  <transition name="toast">
    <div v-if="s.idleWarn && !isFrozen" class="idle-warn" role="status">
      <ico name="moon"></ico><span>{{ t('idle.warn', {t: Math.floor(s.idleWarn / 60) + ':' + String(s.idleWarn % 60).padStart(2, '0')}) }}</span>
    </div>
  </transition>

  <!-- ===================== MODALS ===================== -->
  <div v-if="s.modal" class="overlay" @click.self="!s.me.must_change_password && (s.modal = null)">
    <div class="panel modal" v-if="s.modal==='password'">
      <h3>{{ t('pw.title') }}</h3>
      <div class="banner" v-if="s.me.must_change_password">{{ t('pw.forced') }}</div>
      <form @submit.prevent="submitPassword">
        <label>{{ t('pw.current') }}</label><input type="password" v-model="s.pw.current_password" autocomplete="current-password" required>
        <label>{{ t('pw.new') }}</label><input type="password" v-model="s.pw.new_password" autocomplete="new-password" minlength="8" required>
        <label>{{ t('pw.repeat') }}</label><input type="password" v-model="s.pw.repeat" autocomplete="new-password" minlength="8" required>
        <p v-if="s.pw.error" style="color:var(--danger)">{{ s.pw.error }}</p>
        <div class="footer"><button type="button" class="btn" v-if="!s.me.must_change_password" @click="s.modal=null">{{ t('modal.cancel') }}</button>
          <button class="btn primary">{{ t('modal.apply') }}</button></div>
      </form>
    </div>
    <div class="panel modal" v-if="s.modal==='complete'">
      <h3>{{ t('modal.complete') }}</h3><div class="empty">{{ s.form.title }}</div>
      <label>{{ t('modal.zammad_state') }}</label>
      <select v-model="s.form.ticket_state"><option v-for="st in s.config.complete_states" :key="st" :value="st">{{ st }}</option></select>
      <label>{{ t('modal.note') }}</label><textarea v-model="s.form.note"></textarea>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button><button class="btn go" :disabled="s.busy" @click="submitComplete">{{ t('btn.complete') }}</button></div>
    </div>

    <div class="panel modal" v-if="s.modal==='customer'">
      <h3>{{ t('modal.new_customer') }}</h3>
      <div class="row"><div><label>{{ t('modal.firstname') }}</label><input v-model="s.form.firstname"></div><div><label>{{ t('modal.lastname') }}</label><input v-model="s.form.lastname"></div></div>
      <label>{{ t('modal.phone') }}</label><input v-model="s.form.phone">
      <label>{{ t('modal.email') }}</label><input v-model="s.form.email" type="email">
      <label>{{ t('modal.notes') }}</label><textarea v-model="s.form.note"></textarea>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button><button class="btn primary" :disabled="s.busy" @click="submitCustomer">{{ t('modal.create') }}</button></div>
    </div>

    <div class="panel modal" v-if="s.modal==='ticket'">
      <h3>{{ t('modal.new_ticket') }}</h3>
      <div class="empty" v-if="s.form.call_id">{{ t('modal.call_note') }}</div>
      <label>{{ t('modal.customer') }}</label>
      <select v-model="s.form.customer_id">
        <option value="">{{ t('modal.choose') }}</option>
        <option v-for="c in s.customers" :key="c.id" :value="c.id">{{ c.name }} {{ c.phone }}</option>
        <option v-if="s.customerCard && !s.customers.find(c => c.id === s.customerCard.customer.id)" :value="s.customerCard.customer.id">{{ s.customerCard.customer.firstname }} {{ s.customerCard.customer.lastname }}</option>
      </select>
      <div class="row">
        <div><label>{{ t('modal.type') }}</label><select v-model="s.form.ticket_type"><option value="">—</option><option v-for="tt in s.config.ticket_types" :key="tt.name" :value="tt.name">{{ tt.name }}</option></select></div>
        <div><label>{{ t('modal.priority') }}</label><select v-model="s.form.priority"><option value="1 low">{{ t('prio.low') }}</option><option value="2 normal">{{ t('prio.normal') }}</option><option value="3 high">{{ t('prio.high') }}</option></select></div>
      </div>
      <template v-if="currentType">
        <div v-for="f in currentType.required_fields" :key="f.name">
          <label>{{ f.label || f.name }} *</label>
          <select v-if="f.type==='select'" v-model="s.form.fields[f.name]"><option v-for="o in f.options || []" :key="o" :value="o">{{ o }}</option></select>
          <textarea v-else-if="f.type==='textarea'" v-model="s.form.fields[f.name]"></textarea>
          <input v-else v-model="s.form.fields[f.name]">
        </div>
      </template>
      <label>{{ t('modal.subject') }} *</label><input v-model="s.form.title" required>
      <label>{{ t('modal.description') }}</label><textarea v-model="s.form.body"></textarea>
      <div class="footer">
        <button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button>
        <button class="btn" :disabled="s.busy || !s.form.title" @click="submitTicket(null)">{{ t('modal.save') }}</button>
        <button class="btn" :disabled="s.busy || !s.form.title" @click="submitTicket('background')">{{ t('modal.save_bg') }}</button>
        <button class="btn primary" :disabled="s.busy || !s.form.title" @click="submitTicket('blocking')">{{ t('modal.save_start') }}</button>
      </div>
    </div>

    <div class="panel modal" v-if="s.modal==='assign'">
      <h3>{{ t('sup.assign_title') }}</h3>
      <label>{{ t('sup.ticket_number') }} *</label><input name="ticket" v-model="s.form.ticket" placeholder="31103">
      <label>{{ t('sup.assign_to') }} *</label>
      <select name="agent" v-model="s.form.agent_id"><option value="">{{ t('modal.choose') }}</option>
        <option v-for="a in s.sup.agents.filter(x => x.zammad_user_id)" :key="a.agent_id" :value="a.agent_id">{{ a.name }} — {{ stateText(a.display_state) }}</option></select>
      <label>{{ t('sup.mode') }}</label>
      <select name="mode" v-model="s.form.work_mode"><option value="">{{ t('sup.mode_none') }}</option>
        <option value="blocking">{{ t('btn.start') }} (blocking)</option><option value="background">{{ t('btn.background') }}</option></select>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button>
        <button class="btn primary" :disabled="s.busy || !s.form.ticket || !s.form.agent_id" @click="submitAssign">{{ t('modal.apply') }}</button></div>
    </div>

    <div class="panel modal" v-if="s.modal==='override'">
      <h3>{{ t('modal.override') }}: {{ s.form.agent.name }}</h3>
      <div class="empty">{{ t('modal.audit_note') }}</div>
      <label>{{ t('modal.state') }}</label>
      <select v-model="s.form.manual_state"><option value="ready">{{ t('state.ready') }}</option><option value="break">{{ t('state.break') }}</option><option value="offline">{{ t('state.offline') }}</option></select>
      <label v-if="s.form.manual_state==='ready'" style="display:flex;gap:8px;align-items:center;color:var(--ink)">
        <input type="checkbox" v-model="s.form.ignore_blocking" style="width:auto"> {{ t('modal.ignore_blocking') }}</label>
      <label>{{ t('modal.reason') }} *</label><textarea v-model="s.form.reason"></textarea>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button><button class="btn warn" :disabled="s.busy || s.form.reason.trim().length < 3" @click="submitOverride">{{ t('modal.apply') }}</button></div>
    </div>
  </div>

  <zenith-phone v-if="phoneOn" v-model:open="s.phoneOpen" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :dnd="!!(s.state && s.state.dnd)"
                @state="(x) => { s.phone = x; s.clock = Date.now(); }"></zenith-phone>
  <transition-group name="toast" tag="div" class="toasts"><div v-for="x in s.toasts" :key="x.id" class="toast" :class="[x.kind, {clickable: x.onClick}]" @click="toastClick(x)">{{ x.text }}</div></transition-group>
</template>`,
};

(async () => {
  try {
    const r = await fetch("/api/ui-language");
    if (r.ok) { const j = await r.json(); LANG = j.language || "en"; VERSION = j.version || ""; }
  } catch { /* default en */ }
  document.documentElement.lang = LANG;
  const app = createApp(App);
  app.component("ico", Ico);
  app.directive("flash", flashDirective);
  if (window.AgentixAdmin) app.component("admin-panel", window.AgentixAdmin.component);
  if (window.ZenithPhone) { app.component("zenith-phone", window.ZenithPhone.PhoneWidget); app.component("phone-settings", window.ZenithPhone.PhoneSettings); }
  if (window.ZenithInbox) app.component("inbox-page", window.ZenithInbox.InboxPage);
  if (window.ZenithMail) app.component("mail-page", window.ZenithMail.MailPage);
  if (window.AgentixTickets) { app.component("tickets-page", window.AgentixTickets.TicketsPage); app.component("contacts-page", window.AgentixTickets.ContactsPage); }
  app.mount("#app");
})();
