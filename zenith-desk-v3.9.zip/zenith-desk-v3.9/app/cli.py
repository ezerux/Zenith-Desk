"""Server-side CLI for emergencies only — normal administration is done in the admin panel.

    python -m app.cli reset-password admin           # prints a new random password
    python -m app.cli create-admin --username boss   # creates another administrator
    python -m app.cli list-users
"""
import argparse
import asyncio
import secrets

from sqlalchemy import func, select

from .config import get_settings
from .crypto import hash_password
from .db import Database
from .models import AgentMapping, AgentState


async def reset_password(a) -> None:
    db = Database(get_settings().database_url)
    async with db.sessionmaker() as s:
        m = (await s.execute(select(AgentMapping).where(func.lower(AgentMapping.username) == a.username.lower()))).scalars().first()
        if m is None:
            print("user not found")
        else:
            password = a.password or secrets.token_urlsafe(9)
            m.password_hash, m.must_change_password, m.active = hash_password(password), not a.password, True
            await s.commit()
            print(f"login: {m.username}\npassword: {password}")
    await db.dispose()


async def create_admin(a) -> None:
    db = Database(get_settings().database_url)
    async with db.sessionmaker() as s:
        if (await s.execute(select(AgentMapping).where(func.lower(AgentMapping.username) == a.username.lower()))).scalars().first():
            print("username taken")
        else:
            password = a.password or secrets.token_urlsafe(9)
            m = AgentMapping(username=a.username.lower(), password_hash=hash_password(password), first_name=a.name,
                             display_name=a.name, role="admin", level="admin", enabled=False, must_change_password=not a.password)
            s.add(m)
            await s.flush()
            s.add(AgentState(agent_id=m.id))
            await s.commit()
            print(f"login: {m.username}\npassword: {password}")
    await db.dispose()


async def list_users(_) -> None:
    db = Database(get_settings().database_url)
    async with db.sessionmaker() as s:
        for m in (await s.execute(select(AgentMapping).order_by(AgentMapping.id))).scalars().all():
            print(f"{m.id:>3}  {m.username or '-':<16} {m.role:<10} {'active' if m.active else 'disabled':<8} "
                  f"ext={m.extension or '-':<6} zammad={m.zammad_user_id or '-':<5} {m.display_name}")
    await db.dispose()


def main() -> None:
    p = argparse.ArgumentParser(prog="python -m app.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("reset-password", help="set a new password (random if not given)")
    r.add_argument("username")
    r.add_argument("--password")
    r.set_defaults(fn=reset_password)
    c = sub.add_parser("create-admin", help="create an administrator")
    c.add_argument("--username", required=True)
    c.add_argument("--name", default="Administrator")
    c.add_argument("--password")
    c.set_defaults(fn=create_admin)
    sub.add_parser("list-users").set_defaults(fn=list_users)
    args = p.parse_args()
    asyncio.run(args.fn(args))


if __name__ == "__main__":
    main()
