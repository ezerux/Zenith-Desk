"""Wiring of all components + background tasks."""
import asyncio
import logging
import secrets
import time
from datetime import timedelta

from sqlalchemy import func, select

from .ami import AMIClient
from .audit import audit
from .calls import CallService
from .config import Settings
from .crypto import MessageCipher, hash_password
from .directory import Directory
from .db import Database, utcnow
from . import live
from .events import EventBroker
from .i18n import set_language, t as tr
from .models import AgentMapping, AgentState, AuditLog, ChatMessage, IntegrationEvent
from .pbx import AmiPbx, Pbx
from .settings_store import AMI_CONNECTION, MAIL_CONNECTION, MESSENGER_CONNECTION, QUEUE_RULES, ZAMMAD_CONNECTION, SettingsStore
from .sync_hub import SyncHub
from .sync import StateEngine
from .ticketing import TicketDesk
from .workflow import Actor, Workflow
from .webpush import WebPush
from .zammad import ZammadClient

log = logging.getLogger("services")


class Services:
    def __init__(self, settings: Settings, *, db: Database | None = None, zammad: ZammadClient | None = None,
                 pbx: Pbx | None = None, ami: AMIClient | None = None):
        self.settings = settings
        self.db = db or Database(settings.database_url)
        self.store = SettingsStore(self.db, settings)
        self.cipher = MessageCipher(settings.jwt_secret)  # chat messages encrypted at rest (v3.1)
        self.push = WebPush(self.db, self.store.box)        # background notifications (v3.1)
        self.broker = EventBroker()
        live.register(self.db.engine.sync_engine, self.broker)  # every COMMIT reaches the browsers (v2.7)
        # Clients built here may be rebuilt when the administrator changes settings in the panel.
        # Injected clients (demo / tests) are never replaced.
        self._owns_zammad = zammad is None
        self._owns_ami = pbx is None and ami is None
        self.zammad = zammad or self._new_zammad()
        self._ami_events: asyncio.Queue = asyncio.Queue(maxsize=10000)
        self.ami = ami
        if pbx is None:
            self.ami = ami or self._new_ami()
            pbx = AmiPbx(self.ami)
        self.pbx = pbx
        self.engine = StateEngine(self.db, self.pbx, self.broker, settings)
        self.workflow = Workflow(self.db, self.zammad, self.engine, settings)
        self.calls = CallService(self.db, self.zammad, self.engine, self.broker, settings)
        self.directory = Directory(self)  # v3.3: customers and staff copied from Zammad
        self.desk = TicketDesk(self)       # v3.3: ticketing inside Zenith Desk
        self.hub = SyncHub(settings, self.broker)  # v3.9: real time + fallback polling of every integration
        from .messengers.service import MessengerService  # noqa: PLC0415
        from .mail.service import MailService  # noqa: PLC0415
        self.messengers = MessengerService(self)  # v3.9: Telegram / WhatsApp, one company number
        self.mail = MailService(self)              # v3.9: e-mail of every employee
        self.hub.register("zammad", "Zammad", self._fallback_zammad, lambda: bool(self.settings.zammad_token) or not self._owns_zammad)
        self.hub.register("asterisk", "Asterisk / FreePBX (AMI)", self._fallback_asterisk, lambda: self.ami_configured or not self._owns_ami)
        if self.ami is not None:
            self.ami.on_connect = self.engine.on_ami_connect
            self.ami.on_disconnect = self.engine.on_ami_disconnect
        self.broker.on_presence_change = self._on_presence
        self._presence_tasks: dict[int, asyncio.Task] = {}
        self._bg_tasks: set[asyncio.Task] = set()  # detached fire-and-forget work (kept referenced until done)
        self._tasks: list[asyncio.Task] = []
        self._background = False

    def _new_zammad(self) -> ZammadClient:
        s = self.settings
        return ZammadClient(s.zammad_url, s.zammad_token, verify_tls=s.zammad_verify_tls, timeout=s.zammad_timeout_sec)

    def _new_ami(self) -> AMIClient:
        s = self.settings
        return AMIClient(s.ami_host, s.ami_port, s.ami_user, s.ami_secret,
                         on_event=self._enqueue_ami_event, action_timeout=s.ami_action_timeout_sec)

    @property
    def ami_configured(self) -> bool:
        return bool(self.settings.ami_secret and self.settings.ami_host)

    # ------------------------------------------------------------------ live reconfiguration
    async def rebuild_zammad(self) -> None:
        if not self._owns_zammad:
            return
        old, self.zammad = self.zammad, self._new_zammad()
        self.workflow.zammad = self.calls.zammad = self.zammad
        await old.close()
        self.directory.kick()
        log.info("Zammad client reconfigured: %s", self.settings.zammad_url)

    async def restart_ami(self, start: bool = True) -> None:
        if not self._owns_ami:
            return
        old = self.ami
        self.ami = self._new_ami()
        self.ami.on_connect = self.engine.on_ami_connect
        self.ami.on_disconnect = self.engine.on_ami_disconnect
        self.pbx.ami = self.ami
        if old is not None:
            old.on_disconnect = None
            await old.stop()
        if start and self.ami_configured:
            self.ami.start()
        log.info("AMI client reconfigured: %s:%s", self.settings.ami_host, self.settings.ami_port)

    async def apply_settings(self, changed: set[str]) -> None:
        """Called after the administrator saved settings in the panel."""
        set_language(self.settings.ui_language)
        if changed & MESSENGER_CONNECTION:
            await self.messengers.configure()
        if changed & MAIL_CONNECTION:
            await self.mail.configure()
        if "sync_fallback_min" in changed:
            self.hub.kick()
        if changed & ZAMMAD_CONNECTION:
            await self.rebuild_zammad()
        if changed & AMI_CONNECTION:
            await self.restart_ami(start=self._background)
        elif changed & QUEUE_RULES and self._background:
            t = asyncio.create_task(self.engine.reconcile_all("settings_changed"))
            self._bg_tasks.add(t)
            t.add_done_callback(self._bg_tasks.discard)

    async def test_zammad(self, url: str, token: str, verify_tls: bool) -> dict:
        if not self._owns_zammad:
            client, temp = self.zammad, False
        else:
            client, temp = ZammadClient(url, token, verify_tls=verify_tls, timeout=8), True
        try:
            me = await client.me()
            return {"ok": True, "detail": f"{me.get('login') or me.get('email')} (id {me.get('id')})"}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "detail": str(exc)[:300]}
        finally:
            if temp:
                await client.close()

    async def test_ami(self, host: str, port: int, user: str, secret: str) -> dict:
        if not self._owns_ami:
            return {"ok": self.pbx.connected, "detail": "connected" if self.pbx.connected else "not connected"}
        client = AMIClient(host, port, user, secret, action_timeout=5)
        client.start()
        try:
            ok = await client.wait_connected(6)
            return {"ok": ok, "detail": "Login accepted" if ok else (client.last_error or "no answer from AMI")}
        finally:
            await client.stop()

    # ------------------------------------------------------------------ first administrator
    async def encrypt_old_messages(self) -> int:
        """Messages written before v3.1 were stored as plain text: encrypt them once."""
        n = 0
        async with self.db.sessionmaker() as s:
            rows = (await s.execute(select(ChatMessage).where(~ChatMessage.body.startswith(MessageCipher.PREFIX)))).scalars().all()
            for m in rows:
                m.body = self.cipher.seal(m.body)
                n += 1
            if n:
                await s.commit()
                log.info("encrypted %s chat messages at rest", n)
        return n

    async def ensure_admin(self) -> None:
        """If there is no active administrator with a login, create one (password printed to the log once)."""
        async with self.db.sessionmaker() as s:
            admins = (await s.execute(select(AgentMapping).where(
                AgentMapping.role == "admin", AgentMapping.active.is_(True),
                AgentMapping.username.is_not(None), AgentMapping.password_hash != ""))).scalars().first()
            if admins is not None:
                return
            base = (self.settings.initial_admin_username or "admin").strip().lower()
            username, n = base, 1
            while (await s.execute(select(AgentMapping).where(AgentMapping.username == username))).scalars().first():
                n += 1
                username = f"{base}{n}"
            password = self.settings.initial_admin_password or secrets.token_urlsafe(9)
            user = AgentMapping(username=username, password_hash=hash_password(password), first_name="Administrator",
                                display_name="Administrator", role="admin", level="admin", enabled=False,
                                must_change_password=not self.settings.initial_admin_password)
            s.add(user)
            await s.flush()
            s.add(AgentState(agent_id=user.id))
            audit(s, "admin_bootstrap", agent_id=user.id, username=username)
            await s.commit()
        banner = "=" * 64
        log.warning("\n%s\n  FIRST ADMINISTRATOR CREATED\n  login:    %s\n  password: %s\n"
                    "  Sign in and change the password in the admin panel.\n%s",
                    banner, username, "(INITIAL_ADMIN_PASSWORD from .env)" if self.settings.initial_admin_password else password, banner)

    async def refresh_backlog(self) -> None:
        """ТЗ 10: monitoring of the retry queues — how much is still waiting per integration."""
        from .models import AgentState, IntegrationEvent, MsgMessage  # noqa: PLC0415
        async with self.db.sessionmaker() as s:
            z = (await s.execute(select(func.count()).select_from(IntegrationEvent).where(
                IntegrationEvent.source == "zammad", IntegrationEvent.status.in_(("new", "retry"))))).scalar() or 0
            a = (await s.execute(select(func.count()).select_from(AgentState).where(AgentState.sync_status.in_(("pending", "error"))))).scalar() or 0
            waiting = MsgMessage.status == "queued"
            if self.settings.messenger_zammad_mirror:  # not yet copied to Zammad
                waiting = waiting | (MsgMessage.mirrored.is_(False) & (MsgMessage.direction != "event"))
            rows = (await s.execute(select(MsgMessage.channel, func.count()).where(waiting).group_by(MsgMessage.channel))).all()
        per = dict(rows)
        self.hub.get("zammad").backlog = int(z)
        self.hub.get("asterisk").backlog = int(a) + self._ami_events.qsize()
        for ch in ("telegram", "whatsapp"):
            self.hub.get(ch).backlog = int(per.get(ch, 0))

    def integrations_view(self) -> list[dict]:
        """Health of every integration for the administrator (real-time channel + fallback checks)."""
        hub = self.hub
        if self.ami is not None or not self._owns_ami:
            hub.realtime("asterisk", self.pbx.connected, tr("rt.ami_events") if self.pbx.connected else (getattr(self.ami, "last_error", "") or tr("rt.not_connected")))
        z = hub.get("zammad")
        recent = z.last_event and (time.time() - z.last_event) < 86400
        hub.realtime("zammad", "on" if recent else "n/a",
                     tr("rt.zammad", how=tr("rt.webhook") if recent else tr("rt.no_webhook"), n=self.settings.zammad_poll_sec))
        return hub.view()

    async def _fallback_zammad(self) -> int:
        """Missed Zammad webhooks: tickets changed in Zammad that no webhook announced are found and applied."""
        since = utcnow() - timedelta(minutes=max(self.hub.interval_min, 1) + 2)
        changed = await self.desk.poll()
        await self.workflow.reconcile_zammad()
        self.directory.kick()
        if not changed:
            return 0
        async with self.db.sessionmaker() as s:
            rows = (await s.execute(select(IntegrationEvent.payload).where(IntegrationEvent.source == "zammad",
                                                                           IntegrationEvent.created_at >= since))).scalars().all()
        announced = {int(p.get("ticket_id")) for p in rows if isinstance(p, dict) and p.get("ticket_id")}
        return sum(1 for t in changed if int(t) not in announced)

    async def _fallback_asterisk(self) -> int:
        """Missed AMI events / changes made on the phone: the queue members are compared with the computed states."""
        started = utcnow()
        self.hub.realtime("asterisk", self.pbx.connected, tr("rt.ami_connected") if self.pbx.connected else tr("rt.not_connected"))
        if not self.pbx.connected:
            raise RuntimeError(getattr(self.ami, "last_error", "") or "AMI not connected")
        await self.engine.reconcile_all("fallback")
        async with self.db.sessionmaker() as s:
            rows = (await s.execute(select(AuditLog.details).where(AuditLog.ts >= started, AuditLog.action.in_(("queue_pause", "queue_unpause"))))).scalars().all()
        return sum(1 for d in rows if isinstance(d, dict) and d.get("cause") == "fallback")

    async def retention_cleanup(self) -> dict:
        """v3.9 (ТЗ 10: no extra personal data, audit retention): delete what is older than the configured days."""
        from sqlalchemy import delete as sql_delete  # noqa: PLC0415
        from .models import CallRecord, MsgConversation, MsgFile, MsgMessage, QueueCall  # noqa: PLC0415
        cfg, now, done = self.settings, utcnow(), {}
        async with self.db.sessionmaker() as s:
            if cfg.retention_audit_days > 0:
                r = await s.execute(sql_delete(AuditLog).where(AuditLog.ts < now - timedelta(days=cfg.retention_audit_days)))
                done["audit"] = r.rowcount or 0
            if cfg.retention_calls_days > 0:
                limit = now - timedelta(days=cfg.retention_calls_days)
                done["calls"] = (await s.execute(sql_delete(CallRecord).where(CallRecord.started_at < limit))).rowcount or 0
                done["queue_calls"] = (await s.execute(sql_delete(QueueCall).where(QueueCall.joined_at < limit))).rowcount or 0
            if cfg.retention_messages_days > 0:
                limit = now - timedelta(days=cfg.retention_messages_days)
                done["chat"] = (await s.execute(sql_delete(ChatMessage).where(ChatMessage.created_at < limit))).rowcount or 0
                done["messenger"] = (await s.execute(sql_delete(MsgMessage).where(MsgMessage.created_at < limit))).rowcount or 0
                done["files"] = (await s.execute(sql_delete(MsgFile).where(MsgFile.created_at < limit))).rowcount or 0
                done["conversations"] = (await s.execute(sql_delete(MsgConversation).where(
                    MsgConversation.status == "closed", MsgConversation.last_message_at < limit))).rowcount or 0
            if any(done.values()):
                audit(s, "retention_cleanup", **done)
            await s.commit()
        if any(done.values()):
            log.info("retention cleanup: %s", done)
        return done

    async def _retention_loop(self) -> None:
        while True:
            await asyncio.sleep(60)
            try:
                await self.retention_cleanup()
            except Exception:  # noqa: BLE001
                log.exception("retention cleanup failed")
            await asyncio.sleep(6 * 3600)

    async def _enqueue_ami_event(self, ev: dict) -> None:
        self.hub.event("asterisk")
        try:
            self._ami_events.put_nowait(ev)
        except asyncio.QueueFull:
            log.error("AMI event queue overflow, dropping %s", ev.get("Event"))

    async def _consume_ami_events(self) -> None:
        while True:
            ev = await self._ami_events.get()
            try:
                await self.calls.handle_event(ev)
            except Exception:  # noqa: BLE001
                log.exception("failed to handle AMI event %s", ev.get("Event"))

    async def _mail_presence(self, agent_id: int, connections: int) -> None:
        try:
            await self.mail.presence(agent_id, connections)
        except Exception:  # noqa: BLE001
            log.exception("mail presence")

    async def _on_presence(self, agent_id: int, connections: int) -> None:
        # v3.9: IMAP IDLE only while the person is online. A detached task: presence changes arrive from the SSE stream,
        # often from a cancelled request (the browser went away) — database work must never run inside that cancel scope.
        mail_task = asyncio.create_task(self._mail_presence(agent_id, connections), name=f"mail-presence-{agent_id}")
        self._bg_tasks.add(mail_task)
        mail_task.add_done_callback(self._bg_tasks.discard)
        timeout = self.settings.presence_offline_sec
        if timeout <= 0:
            return
        task = self._presence_tasks.pop(agent_id, None)
        if task:
            task.cancel()
        if connections == 0:
            self._presence_tasks[agent_id] = asyncio.create_task(self._presence_timeout(agent_id, timeout))

    async def _presence_timeout(self, agent_id: int, timeout: int) -> None:
        await asyncio.sleep(timeout)
        if self.broker.connections(agent_id) == 0:
            async with self.db.sessionmaker() as s:
                st = await self.engine.ensure_state(s, agent_id)
                if st.manual_state == "offline":
                    return
                audit(s, "presence_lost", agent_id=agent_id, level="warning", seconds=timeout)
                await s.commit()
            await self.workflow.set_manual_state(agent_id, "offline", Actor("system", None), tr("presence.lost"))

    async def start(self, *, background: bool = True) -> None:
        self._background = background
        await self.store.load()  # settings saved in the admin panel override .env
        set_language(self.settings.ui_language)
        if self.store.from_db & ZAMMAD_CONNECTION:
            await self.rebuild_zammad()
        if self.store.from_db & AMI_CONNECTION:
            await self.restart_ami(start=False)
        await self.ensure_admin()
        await self.encrypt_old_messages()
        if background:
            self._tasks.append(asyncio.create_task(self._consume_ami_events(), name="ami-consumer"))
            self.engine.start()
            self.workflow.start()
            if self.ami is not None and (self.ami_configured or not self._owns_ami):
                self.ami.start()
            elif self._owns_ami:
                log.warning("AMI is not configured yet — set it in the admin panel (Integrations)")
            self._tasks.append(asyncio.create_task(self._idle_loop(), name="idle-watchdog"))
            self.directory.start()
            self.desk.start()
            await self.messengers.start()
            await self.mail.start()
            self.hub.start()
            self._tasks.append(asyncio.create_task(self._retention_loop(), name="retention"))
            # Сценарий D: after restart restore state from DB and reconcile with Asterisk.
            self._tasks.append(asyncio.create_task(self._startup_reconcile(), name="startup-reconcile"))

    async def check_idle(self) -> list[int]:
        """Server-side guard (v2.8): pause everybody who has not used Zenith Desk for idle_timeout_min.
        Works even if the browser is frozen, asleep or closed without signing out."""
        minutes = self.settings.idle_timeout_min
        if minutes <= 0:
            return []
        limit = utcnow() - timedelta(minutes=minutes)
        async with self.db.sessionmaker() as s:
            rows = (await s.execute(select(AgentState.agent_id).join(AgentMapping, AgentMapping.id == AgentState.agent_id).where(
                AgentState.idle_since.is_(None), AgentState.last_activity_at.is_not(None),
                AgentState.last_activity_at < limit, AgentMapping.active.is_(True),
                (AgentState.manual_state != "offline") | (AgentMapping.role == "admin")))).scalars().all()
        paused = []
        for agent_id in rows:
            try:
                if await self.workflow.go_idle(agent_id, minutes, "server"):
                    paused.append(agent_id)
            except Exception:  # noqa: BLE001
                log.exception("idle pause failed for agent %s", agent_id)
        return paused

    async def _idle_loop(self) -> None:
        while True:
            await asyncio.sleep(30)
            try:
                await self.check_idle()
            except Exception:  # noqa: BLE001
                log.exception("idle watchdog failed")

    async def _startup_reconcile(self) -> None:
        if self.ami is not None and self.ami_configured:
            await self.ami.wait_connected(15)
        await self.engine.reconcile_all("startup")
        await self.workflow.reconcile_zammad()

    async def stop(self) -> None:
        bg = [*self._bg_tasks, *self._presence_tasks.values()]
        for t in bg:
            t.cancel()
        await asyncio.gather(*bg, return_exceptions=True)
        await self.calls.stop()
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        await self.engine.stop()
        await self.workflow.stop()
        await self.hub.stop()
        await self.messengers.stop()
        await self.mail.stop()
        await self.directory.stop()
        await self.desk.stop()
        if self.ami is not None:
            await self.ami.stop()
        await self.zammad.close()
        await self.push.close()
        await self.db.dispose()
