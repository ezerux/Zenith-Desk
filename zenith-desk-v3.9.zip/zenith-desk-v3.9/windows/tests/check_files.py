"""Checks the produced Windows files with independent parsers: .lnk (LnkParse3) and .exe resources (pefile)."""
import glob, os, sys
import LnkParse3, pefile

root, setup, client = sys.argv[1:4]
ok = True
def check(cond, what):
    global ok
    print(("  PASS  " if cond else "  FAIL  ") + what)
    ok = ok and cond

with open(os.path.join(root, "lnk", "manual.lnk"), "rb") as f:
    j = LnkParse3.lnk_file(f).get_json()
li, data = j.get("link_info", {}), j.get("data", {})
check(li.get("local_base_path") == r"C:\Program Files\Zenith Desk\ZenithDesk.exe" or li.get("local_base_path_unicode") == r"C:\Program Files\Zenith Desk\ZenithDesk.exe",
      "manual.lnk target: %s" % li.get("local_base_path"))
check(data.get("command_line_arguments") == "/settings" and data.get("working_directory") == r"C:\Program Files\Zenith Desk", "manual.lnk arguments / folder")
check(data.get("description") == "Zenith Desk — подключение к серверу" and data.get("icon_location", "").endswith("ZenithDesk.exe"), "manual.lnk description (Cyrillic) / icon")
lnks = [p for p in glob.glob(os.path.join(root, "gui-upgrade", "**", "*.lnk"), recursive=True)]
check(len(lnks) == 3, "wizard made 3 shortcuts: %s" % [os.path.basename(p) for p in lnks])
for p in lnks:
    with open(p, "rb") as f:
        j = LnkParse3.lnk_file(f).get_json()
    target = j.get("link_info", {}).get("local_base_path_unicode") or j.get("link_info", {}).get("local_base_path", "")
    check(target.endswith("ZenithDesk.exe"), "%s → %s %s" % (os.path.basename(p), target[-40:], j.get("data", {}).get("command_line_arguments", "")))

for exe, level, desc in ((setup, "requireAdministrator", "Zenith Desk Setup"), (client, "asInvoker", "Zenith Desk")):
    pe = pefile.PE(exe)
    types = {pefile.RESOURCE_TYPE.get(e.struct.Id) for e in pe.DIRECTORY_ENTRY_RESOURCE.entries}
    st = {k.decode(): v.decode() for fi in pe.FileInfo[0] if fi.Key == b"StringFileInfo" for t in fi.StringTable for k, v in t.entries.items()}
    man = next(e for e in pe.DIRECTORY_ENTRY_RESOURCE.entries if e.struct.Id == 24).directory.entries[0].directory.entries[0].data.struct
    manifest = pe.get_data(man.OffsetToData, man.Size).decode()
    check({"RT_ICON", "RT_GROUP_ICON", "RT_VERSION", "RT_MANIFEST"} <= types, "%s: icon, version, manifest" % os.path.basename(exe))
    check(st.get("FileDescription") == desc and st.get("ProductVersion") == "3.9.0", "%s: %s %s" % (os.path.basename(exe), st.get("FileDescription"), st.get("ProductVersion")))
    check('level="%s"' % level in manifest and "Common-Controls" in manifest and "dpiAware" in manifest, "%s: %s, visual styles, DPI aware" % (os.path.basename(exe), level))
sys.exit(0 if ok else 1)
