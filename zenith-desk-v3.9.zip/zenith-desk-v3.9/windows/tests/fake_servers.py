"""Servers that misbehave in every way the installer's "Test connection" must explain (used by tests/run_tests.sh)."""
import http.server, json, socket, ssl, sys, threading, time

ZD = {"product": "Zenith Desk", "version": "3.9", "language": "ru", "database": True, "https_required": False}


def handler(kind):
    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def send(self, code, body, ctype="application/json", extra=()):
            data = body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            for k, v in extra:
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if kind == "other":
                return self.send(404 if self.path.startswith("/api/") else 200, "<html>Router admin</html>", "text/html")
            if kind == "redirect":
                return self.send(308, "", extra=[("Location", "https://example.local" + self.path)])
            if kind == "nodb":
                return self.send(200, json.dumps({**ZD, "database": False}))
            if kind == "httpsreq":
                return self.send(200, json.dumps({**ZD, "https_required": True}))
            if kind == "error":
                return self.send(500, "Internal Server Error", "text/plain")
            return self.send(200, json.dumps(ZD))
    return H


def serve(port, kind, tls=None):
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), handler(kind))
    if tls:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(*tls)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()


def blackhole(port):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", port)); s.listen(50)
    keep = []
    def loop():
        while True:
            c, _ = s.accept(); keep.append(c)  # accept, never answer
    threading.Thread(target=loop, daemon=True).start()


if __name__ == "__main__":
    cert, key = sys.argv[1], sys.argv[2]
    serve(8901, "other"); serve(8902, "redirect"); serve(8903, "nodb"); serve(8904, "httpsreq"); serve(8906, "error")
    serve(8443, "zd", (cert, key))
    blackhole(8905)
    print("fake servers up", flush=True)
    while True:
        time.sleep(3600)
