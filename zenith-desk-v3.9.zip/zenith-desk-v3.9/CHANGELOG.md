# Changelog

## 3.9 — 2026-10-11
- **Telegram and WhatsApp windows** (one company bot and one company number — no personal numbers):
  - list «Open / Mine / Unassigned / Closed» with counters and badges in the side menu; conversation with photos, files,
    voice messages, ✓ sent / ✓✓ delivered / read, failed → «Resend»; **Take**, **Transfer** to a colleague (he is
    notified), only the person who has the conversation may answer; internal notes; quick replies with `{name}`;
    «Call» the customer; «Start» / «Background task» (FR-06); close / reopen.
  - WhatsApp: the 24-hour customer-service window is shown; after it only approved templates can be sent.
  - every conversation is also a **Zammad ticket** (customer found by phone or created; messages, files and notes copied;
    closing closes the ticket; a message after closing opens a new ticket).
  - Telegram Bot API: long polling (no public address needed) or webhook with a secret header. WhatsApp Cloud API:
    signed webhooks (`X-Hub-Signature-256`), verify token, media upload / download, statuses.
  - outbox with retries for messages that could not be sent; duplicates are impossible (unique external id).
- **Mail** (new icon in the side menu): the employee types only the **e-mail and password**; the administrator sets the
  server once — IMAP or POP3, SMTP, ports, SSL / STARTTLS, login format, domain, certificate check. Folders, search,
  safe HTML (cleaned with nh3, sandboxed, remote images on request), attachments, reply / reply all / forward with
  attachments, drafts, Sent, move, delete, **create a Zammad ticket from an e-mail**, new mail instantly (IMAP IDLE).
  Mailbox passwords are verified on the mail server and stored encrypted; a wrong mailbox password never signs the
  person out of Zenith Desk.
- **Admin panel → Integrations** now has tabs: Zammad · Telephony · Telegram · WhatsApp · Mail · **Sync**; every tab
  has «Test» against the real service (bot name, number and quality, mailbox login); Callback URL / Verify token /
  webhook URL to copy.
- **Background synchronisation of every system** (Zammad, Asterisk, Telegram, WhatsApp, mail): real-time events plus a
  **fallback check every 5 minutes** (configurable) that finds and repairs what a network failure made us miss
  (re-registers the Telegram webhook and fetches lost updates, re-sends the outbox, re-copies to Zammad, re-checks
  queue pauses, re-reads the mailbox). Panel *Sync*: real time on/off, last event, last / next check, recovered,
  **retry-queue length**, last error, «Check now». `/api/health` → `integrations`.
- ТЗ gaps closed: **protected call recordings** (played through Zenith Desk — only the operator of the call and managers,
  every play / refusal audited, paths outside the recordings folder refused); **data retention** (audit, calls,
  messages, days set in the panel); **ticket for every answered call** as a setting (ТЗ 15, default: by the button);
  monitoring of the retry queues (ТЗ 10).
- Fixes found by the new real-system tests: the Asterisk fallback check failed on every run (missing `await`); a
  recording announced before the agent's phone rang was lost; database work started from a closed event stream could
  spin forever and block shutdown — it now runs detached; the IMAP IDLE connection broke after the first quiet second
  (a socket timeout poisons Python's buffered reader) — IDLE now waits with select() and stays connected; background
  tasks (push notifications, downloads, inbox checks) are finished or cancelled on shutdown, never left holding a
  database transaction; Sync panel texts follow the interface language.
- Tests: 129 pytest (mail against **real Dovecot + Postfix**, Telegram / WhatsApp against faithful API simulators);
  UI e2e 72 scenarios (Telegram, WhatsApp, mail, integration tabs and Sync); **new end-to-end run on a real
  Asterisk 20.6** (`tests/realstack/asterisk_e2e.py`: AMI with the documented permissions, WebRTC phone registration,
  pause / unpause / DND, Asterisk restart recovery, customer call into a queue answered in the browser, recording
  playback, echo test) — part of the release check.
- Migration 0013 (msg_conversation, msg_message, msg_file, mail_account, mail_local). New dependency: nh3 (MIT).

## 3.8 — 2026-10-11
- **Zenith Desk for Windows** (`windows/`, C# / .NET Framework 4.8 / WinForms + Microsoft Edge WebView2):
  - **`ZenithDesk-Setup-3.8.exe`** — a classic installation wizard (like 1C): language → welcome → license →
    custom setup (desktop / Start menu shortcuts, start with Windows, folder) → **system check** (Windows 10/11,
    .NET Framework 4.8, WebView2 Runtime, disk, admin rights; missing Microsoft components are downloaded from
    Microsoft and installed) → **server connection with a mandatory “Test connection”** (every failure explained:
    name not found, port closed, no answer, not Zenith Desk, HTTPS needed, untrusted certificate, server without
    database) → ready → install (with rollback) → finish (“Launch Zenith Desk”). Repair / Remove when installed,
    update keeps folder and server. Registered in “Installed apps” with an uninstaller. Silent mode for
    administrators: `/S /SERVER= /PORT= [/HTTPS] [/AUTOSTART] …`, removal `/uninstall /S [/REMOVEDATA]`.
  - **`ZenithDesk.exe`** — the workplace window: checks the server first (explained error screen, Retry, Server
    settings, automatic retry), then the sign-in page; login remembered; microphone and notifications only for the
    company server (works on plain HTTP in the LAN too); stays in the notification area so calls are not missed;
    incoming call brings the window back and flashes the taskbar; unread count and user in the title; one window
    per user; window size remembered; links to other sites open in the normal browser.
- Server: `GET /api/desktop/hello` (is this Zenith Desk, version, database, HTTPS required — answered even when
  HTTP is redirected to HTTPS). The web app tells the Windows window about calls and unread messages.
- Tests: `windows/tests/run_tests.sh` — 28 scenarios + file checks (wizard page by page, silent install / update /
  removal, connection test against misbehaving servers, program window, .lnk and .exe resources); part of the
  release check.

## 3.7 — 2026-10-11
- **Minimized phone lives in the top bar**: phone button (status, timer) · “Number or name…” box with live search of
  customers and colleagues · green Call button · **DND** button. Enter calls the highlighted person.
- **Call strip under the top bar on every page** while a call is on (narrow, centred): name / number / company, timer or
  state, +N other lines, Mute · Hold · Transfer · Keypad (DTMF) · End; while ringing — Answer / Decline. Clicking the strip
  opens the phone. An incoming call no longer pops the phone window over the page (the strip rings instead).
- **Do not disturb on the server** (`POST /api/agents/me/dnd`): the operator is paused in all queues (reason “Do not
  disturb”), the browser phone rejects direct calls (486). Same switch in the top bar, the phone menu and My settings;
  pressing **Ready** turns DND off. New column `agent_state.dnd` (migration 0012).
- Phone window: **Keypad** on demand, **Hide** for the volume sliders and AC · AA · CONF · REC · VM, **resize from the
  corner** (80–160 %, the whole phone scales; kept on screen).
- **My settings → Phone**: window style **Classic** (MicroSIP), **Compact** (narrow, keypad and controls on demand) or
  **Side panel** (docked on the right, the page moves aside); minimized to the top-bar dialer or to the button only; call
  strip on/off; keypad / controls; size; DND. Kept per user on that computer.
- **WhatsApp and Telegram** in the side menu (generic icons). The pages explain what is coming; the chat interface is being
  agreed (mock-ups A / B / C), until then these chats are handled in Tickets.
- Tests: 111 pytest (DND), UI e2e 69 scenarios (strip, top-bar dialer, DND, hide / resize, window styles, messenger pages),
  phone e2e 12 scenarios (incoming call in the strip with hold and DTMF over real SIP; DND kept on the server).

## 3.6 — 2026-10-11
- **Zenith Phone with MicroSIP functionality and layout**, drawn in the Command Center design (dark / light):
  - title bar, tabs **Phone · Logs · Contacts**, ▾ menu, status bar (Online / Connecting / Not connected / Do not disturb · extension);
  - number box with history (▾) and live search of customers and colleagues; keypad 1–9 * 0 # with letters,
    **R** (redial), **+**, **C** (delete, double click clears); typing digits on the keyboard works too;
  - **Call / End / Answer** button, **Transfer** on the left (blind, or attended to another line), **Message** on the right
    (opens the messenger with that colleague);
  - **speaker and microphone sliders** with mute buttons and a live microphone level meter;
  - **AC** auto-conference, **AA** auto-answer, **CONF** 3-way conference (mixed in the browser), **REC** call recording
    (saved as a .webm file), **voicemail** button (*97, configurable);
  - **up to 3 lines**: a second call puts the first on hold automatically, line chips to switch, answer / decline a waiting call
    (soft call-waiting tone), DTMF from the keypad during a call (RFC 4733, SIP INFO as fallback);
  - **Logs**: every call kept on this computer (incoming, outgoing, missed, rejected, busy) with duration, missed badge, click to call back;
  - **Contacts**: colleagues with their live state (Ready / busy / break / offline) and customers from Zammad, one click to call;
  - ▾ menu: Do not disturb, Auto-answer, Auto-conference, ring sound, **microphone and speaker selection**, own always-on-top window.
- Admin panel: voicemail number (Integrations → Zenith Phone). New API: `/api/phone/contacts`.
- Tests: `tests/e2e_phone.py` now 12 scenarios against the SIP server (two lines, conference, recording, attended / blind transfer,
  DND, auto-answer, redial, voicemail, logs, contacts).

## 3.5 — 2026-10-11
- **Zenith Phone** — a softphone in the browser (WebRTC to FreePBX / Asterisk, JsSIP 3.13.8 bundled locally):
  - “Phone” button in the top bar with live status (ready / connecting / not connected) and the call timer;
  - small phone window: number or name search (customers from Zammad, colleagues by extension), keypad, recent calls;
  - incoming call rings in the window with the customer's name; Answer / Decline; it opens by itself and, if the call is
    missed, closes again;
  - in a call: mute, hold / resume, keypad (DTMF), blind transfer to a colleague or number, hang up;
  - **own window, always on top of other programs** (Document Picture-in-Picture, Chrome / Edge); elsewhere a floating
    window that can be dragged anywhere;
  - “Call” buttons on the customer card, the ticket page and in the recent calls list;
  - only one tab per browser holds the phone, a second tab offers “Use the phone in this tab”.
- Calls of the browser phone go through FreePBX, so the call card, customer lookup, queues and statistics work as for a
  desk phone (AMI events of the PJSIP channel).
- Admin panel: Integrations → **Zenith Phone** (on/off, WSS address, SIP domain, STUN/TURN); Users → SIP login and
  SIP password of the extension (stored encrypted, delivered only to the owner's browser). DB migration 0011.
- Security headers: microphone allowed for Zenith Desk itself; the PBX WebSocket is added to the Content-Security-Policy.
- Tests: `tests/test_softphone.py`, and `tests/e2e_phone.py` — the real WebRTC engine in Chromium against a SIP-over-WebSocket
  server (`tests/fake_sip.py`): digest registration, outgoing / busy / incoming calls, hold, DTMF, transfer.

## 3.4 — 2026-10-11
- **New name: Zenith Desk** (was Agentix) — in the interface, browser tab, login page, notifications,
  API title and documentation.
- **New logo**: the “Z” with a green dot — sidebar, login page, browser tab icon (SVG + PNG), phone home-screen icon
  and background notifications.
- Nothing changes for data: saved settings, themes, chat encryption and secrets keep working after the update.

## 3.3 — 2026-10-11
- **Tickets inside Agentix** (new “Tickets” page). Operators work with Zammad tickets without opening Zammad:
  - lists Mine / Unassigned / All open / Closed, search, filters by state, priority and group, paging;
  - ticket page: the whole conversation (e-mail, phone, Telegram, WhatsApp, notes) with attachments;
  - internal note, public note or reply to the customer in his own channel (e-mail threaded to his last message,
    Telegram, WhatsApp, SMS), file attachments, optional state change in the same step;
  - state (waiting with a date), priority, group and title; “Take it”; Start / Background work sessions;
  - transfer to a colleague with a comment: only Zammad users with full access to the group are offered, with their
    Agentix status; Zammad silently unassigns an owner without access — Agentix detects it, restores the owner and says why;
  - new ticket: customer search, group, priority, state, type with required fields, “assign to me” or leave for the team.
  Everything is written to Zammad at once **in the operator’s own name** (`From` header) — Zammad checks his group
  rights and its history shows who did it.
- **Two-way sync**: changes made in Zammad itself reach every open Agentix screen by themselves (webhook instantly,
  otherwise a light check every 10 s); the new owner of a transferred ticket gets a notification and a push.
  Closing / transferring a ticket also ends the operator's work session (calls come back).
- **Customers** page (read-only directory of Zammad customers and staff): search by name, phone, e-mail, company,
  card with tickets, “New ticket”. People are created in Zammad; Agentix copies them every 60 s (full check every 6 h,
  “Sync now” button) and shows newcomers immediately.
- Links to tickets everywhere in Agentix (workplace, call card, manager panel, notifications) now open the ticket
  inside Agentix; “Open in Zammad” stays available on the ticket page.
- New settings: ticket check interval, directory sync interval, maximum attachment size. DB migration 0010.
- Tests: `tests/test_ticketing.py` (9 scenarios), contract tests for the new Zammad endpoints, 7 new browser scenarios.

## 3.2 — 2026-10-10
- **Zammad API contract check**: every request Agentix sends was compared with the official Zammad source
  (routes, controllers, ticket selector rules, webhook job). Two compatibility fixes:
  - acting for an operator now sends the `From` header (Zammad 6+) together with `X-On-Behalf-Of` (older versions);
  - ticket and user search read every response shape Zammad uses (`[...]`, `{records}`, `{record_ids, assets}`).
- New `tests/test_zammad_contract.py`: a strict fake that validates conditions, payloads and auth exactly like Zammad.

## 3.1 — 2026-10-10
- **Chat list = conversations**: only people you have written with are listed; search finds any colleague to start a new chat.
- **Live order**: when a message arrives (or you send one) that chat's time and preview change at once and it slides
  to the top with an animation — on every page, not only in Messages.
- **Reactions** ❤️ 👍 😂 😮 😢 🔥 👏 🙏 — one per person per message (like Telegram), the same emoji again removes it,
  shown under the bubble with counters, live on both sides.
- **Edit** your own message within 48 hours (menu → Edit, or ↑ in an empty box); “edited” mark, live on both sides.
- **Delete** for me, or for everyone (own messages) — the text is removed from the database as well.
- Message menu: right click, long press on phones, or the “⋯” button next to a bubble; also “Copy text”.
- **Background notifications (Web Push)**: Settings → “Notifications when Agentix is closed”. A new message pops up on
  the computer even with every Agentix tab closed; clicking it opens the conversation. Sent only when the person has
  no Agentix window open (no doubles). Standard Web Push: payload encrypted for that browser (RFC 8291), server signed
  with VAPID (RFC 8292); expired subscriptions are removed automatically. Requires HTTPS.
- **Security**
  - Messages are **encrypted at rest** in the database (AES via Fernet, key derived from the server secret); messages
    written before 3.1 are encrypted automatically at start-up. A database dump or backup no longer reveals chats.
  - Transport: HTTPS (TLS) through the proxy as before, plus **HSTS**; optional `FORCE_HTTPS=true` redirects plain HTTP.
  - Security headers on every response: Content-Security-Policy (scripts/styles/fonts/connections only from Agentix),
    no framing, no MIME sniffing, strict referrer policy, camera/microphone/location disabled.
  - Privacy unchanged: only the two participants can read a conversation, administrators included.
- Migration `0009` (edit/delete fields, `chat_reaction`, `push_subscription`).
- Tests: 87 automated + 60 browser scenarios.

## 3.0 — 2026-10-10
- **Messenger for employees** — new “Messages” item in the left rail (second icon) with an unread badge.
  Layout like Telegram, colours of the Command Center design:
  - **Left**: search and the list of colleagues — avatar with initials and an online dot, name, time and preview of the
    last message (“You: …”), unread counter, ✓/✓✓ for my last message, position when there is no conversation yet,
    “typing…” live. Newest conversation on top.
  - **Middle**: the conversation — day separators (Today / Yesterday / date), bubbles grouped by sender, time and ✓ sent /
    ✓✓ read in every bubble, older messages load when scrolling up, multi-line messages (Shift+Enter), Enter sends,
    drafts are kept per chat. Header: name and “online / typing… / last seen at …”.
  - **Right** (click the name or avatar): user info — position, level, extension, login, current state, number of
    messages together, in Agentix since.
- **Saved and private**: every message is stored in the database (new table `chat_message`, migration `0008`).
  Only the two participants can read a conversation — administrators included.
- **Live**: messages, read receipts and “typing…” arrive instantly; a new message elsewhere shows a clickable toast,
  a soft chime (if sound is on) and a desktop notification when the window is hidden.
- Works on phones (list → conversation with a back button) and on any monitor.
- Tests: 79 automated + 59 browser scenarios (new: search, live delivery, badge, toast, ✓✓, typing, profile, history,
  privacy, validation).

## 2.9 — 2026-10-10
- **Responsive on every screen**: the interface now fills the whole width of any monitor (the content used to stop
  at 1680 px and leave an empty strip on the right on Full-HD and larger screens).
  - Large monitors (1800 px+, 2400 px+): a little more spacing and larger key numbers.
  - Charts are drawn at their real pixel width, so axis labels keep the same size from a phone to a 4K monitor.
  - Small phones (≤ 420 px): tighter spacing, full-width buttons in dialogs, period buttons share the row.
  - Long values (audit details, URLs) wrap instead of pushing the page sideways — fixed horizontal scrolling of the
    Manager panel on phones.
- Checked automatically on every page (login, workplace, manager panel, overview, settings, all admin pages) at
  360, 390, 768, 1024, 1280, 1440, 1920, 2560 and 3440 px: no sideways scrolling, no empty strip, nothing cut off.
- Tests: 74 automated + 58 browser scenarios (new: responsive check from 360 px to 2560 px).

## 2.8 — 2026-10-10
- **Inactivity pause**: when somebody has not used Agentix for 60 minutes (System settings → General →
  “Pause after inactivity, minutes”, 0 = off):
  - two minutes before, a quiet reminder appears at the bottom with a countdown — any movement keeps the person online;
  - then the whole interface **freezes**: it slowly dims to a dark, desaturated tone, animations stop, nothing can be
    clicked, and a card says “Paused — you were away” with the time the person left;
  - the person becomes **Offline**, so queue calls stop ringing at an empty desk; tasks are kept untouched;
  - managers see it live on the Manager panel: “Offline · Away: no activity in Agentix · since 18:53” and an AWAY tag;
  - “I'm back” restores exactly the previous state (Ready or Break) and calls resume; “Sign out” is also offered.
- Activity is any mouse, keyboard, touch or scroll in **any** Agentix tab; the server keeps the last moment and also
  pauses people whose computer went to sleep or whose browser was left open (checked every 30 s).
  Nobody is paused during an active phone call. A manager override also ends the pause.
- Audit log: `idle_offline` and `idle_returned`.
- Migration `0007` (agent_state.last_activity_at, idle_since).
- Tests: 74 automated + 57 browser scenarios.

## 2.7 — 2026-10-10
- **Live mode everywhere**: whatever the server receives reaches every screen that shows it at the same moment
  (measured 50–80 ms from a call event to the operator's screen), no reload, no waiting for a timer.
  - The service watches its own database: after every successful commit it pushes a small `changed` event to
    exactly the right people. New code paths cannot “forget” to notify — and nothing is sent for a rolled-back change.
  - Operator: tasks, calls, notifications, ticket lists (a Zammad webhook refreshes “New requests” for everyone),
    own account (level, position, being disabled → signed out at once).
  - Manager panel and Overview: states, tasks, calls, queue, audit log and statistics update live;
    the “longest wait” counter ticks every second.
  - Administration: users, ticket types, system status and settings reload when someone else changes them
    (never over unsaved edits).
- **Connection that heals itself**: “Live / Reconnecting…” indicator in the top bar; heartbeat every 15 s, a silent
  dead connection is detected within 35 s, reconnect after 1 s with backoff, and after every reconnect the screen
  is fully re-synchronised, so nothing that happened while offline is lost.
- **Instant restarts**: open live connections no longer block the server from stopping (it used to wait until
  Docker killed it); browsers reconnect to the new process in ~1.5 s.
- Demo: `DEMO_DB=/path/demo.db` keeps demo data between restarts.
- Tests: 69 automated + 56 browser scenarios (new: commit → push routing, rollback sends nothing, Zammad webhook →
  ticket lists, admin change → user's screen, timed live update on the Overview).

## 2.6 — 2026-10-10
- **Motion design** — minimal, calm and fast (120–320 ms), never moves data around:
  - **Page transitions**: the old page fades and slides out, the new one slides in; the direction follows the
    order of the menu (forward = from the right, back = from the left). Built on the browser's View Transitions API,
    so data and buttons change instantly — the animation is only visual. Older browsers get a soft fade-in.
  - **Theme switch** spreads as a circle from the button you clicked.
  - **Micro-interactions**: buttons lift on hover and press in on click with a ripple from the touch point;
    rail icons grow, the active item gets a sliding marker, tooltips glide in; the bell wiggles; checkboxes became
    animated switches; level and period chips pop; presets and leaders respond to the pointer.
  - **Fluid content**: dashboard blocks, cards and table rows appear with a short stagger; charts grow from the
    baseline, lines and the service-level gauge draw themselves, meters fill; changed live numbers briefly light up;
    toasts slide in and out; dialogs and popovers scale in; skeleton placeholders while statistics load.
- **Settings → Animations and smooth transitions** (per user, saved in the account). Animations are also switched off
  automatically when the operating system asks for reduced motion.
- Tests: 64 automated + 55 browser scenarios (all run with animations on; new: transitions, ripple, switching animations off).

## 2.5 — 2026-10-10
- **Manager Overview** (new item in the left rail for Managers): the whole picture of the contact center for
  Today / Yesterday / 7 days / 30 days, filter by level, refreshes every 30 s.
  - Incoming calls, answered, **missed** (abandoned + not answered; short abandons ≤ 5 s shown but not counted),
    answer rate, abandon rate, **service level** gauge (answered within 20 s, target 80 % — configurable),
    average speed of answer, longest wait, average talk time, outbound calls.
  - **Right now**: calls waiting in the queue and the longest wait, operators on a call / ready / busy / on break.
  - **Calls by hour** (answered vs missed, tooltip with service level), peak hour;
    **staffing vs workload** (operators logged in vs talk load in Erlang).
  - **Leaders**: most calls answered, most tickets completed.
  - **Missed callers not called back**: numbers whose missed call was neither answered later nor called back.
  - **Operators table**: logged-in time, ready share, breaks, occupancy, calls answered of rung,
    “did not pick up” (RONA — a colleague answering first is not counted), talk and average talk, tickets,
    **engagement index** and warning flags (does not pick up / long breaks / low load). Sortable.
  - “How the numbers are calculated” — every formula is written on the page.
- New table `queue_call` (migration `0006`) filled from AMI `QueueCallerJoin / AgentConnect / AgentComplete /
  QueueCallerAbandon / QueueCallerLeave`: one row per customer call, so a call that rang several operators is counted once.
- System settings → “Manager overview (statistics)”: service-level seconds, target %, short-abandon seconds.
- Demo: four extra operators with a realistic working day so the overview can be shown right away.
- Tests: 64 automated (hand-calculated scenario for every metric + real AMI event flow) and 54 browser scenarios.

## 2.4 — 2026-10-10
- **New design “Command Center”** (option A chosen by the customer) for the whole system: operator workplace,
  Manager panel, administration, personal settings, login, dialogs and mobile view.
  - Dark console look by default; the light variant of the same design stays available
    (Settings → Theme: Dark (default) / Light / Like the system, or the sun/moon button in the rail).
  - Narrow icon rail on the left with tooltips; on phones it turns into a top bar with a menu.
  - Top bar: live status with Asterisk confirmation line, Ready / Break, Customize, notifications,
    and the user block (initials, name, level and position under the name).
  - KPI strip with large monospaced numbers; default layout: work on the left (⅔),
    notifications and recent calls on the right (⅓); the incoming call is a green “live call” card.
  - IBM Plex Sans / IBM Plex Mono fonts (Latin + Cyrillic) served by Agentix itself — no internet needed.
  - Emoji replaced by line icons.
- Personal theme value `system` added (`""` = default dark look).
- Tests: 58 automated + 52 browser scenarios (new: design check — dark by default, icon rail, local fonts).

## 2.3 — 2026-10-10
- **Manager leads Level 1–3 staff (ТЗ FR-08, FR-10, criterion 10)**: the level now decides access rights.
  Level 1/2/3 → operator workplace; Manager → workplace + Manager panel; Administrator → administration.
  A separate “role” field is gone, so a Manager can no longer be left without team rights by mistake.
  Migration `0005` aligns existing users with their level.
- **Manager panel** (renamed from “Supervisor”): filter the team by level (All / Level 1 / Level 2 / Level 3 / Manager)
  with counts; summary cards and the 24-hour report follow the filter; staff sorted by level.
  The manager sees each operator's state and reason, tasks, can reconcile, override with a reason (audited),
  cancel a session and assign a ticket by number.
- User form: “Access (follows the level)” shows what the chosen level allows.
- Tests: 58 automated + 51 browser scenarios (new: level filter, “Manager” level gives the Manager panel).

## 2.2 — 2026-10-10
- **Customizable workspace**: every user can rearrange dashboard blocks (drag & drop or ◀ ▶), change their width
  (⅓ / ⅔ / full) and height (auto / S / M / L), hide and show blocks. Changes are saved to the user's account,
  so the workspace looks the same on any computer.
- **Ready layouts**: Default, Calls focus, Tickets focus, Compact, Minimal + “My layout”; “Reset to default”.
- **Settings** (personal) in the sidebar: theme (system / light / dark), compact density, workspace layout,
  sound on incoming calls, desktop notifications, account details, password change.
- **Levels (grades)**: Administrator, Level 1 (Entry-Level), Level 2 (Mid-Level), Level 3 & Above (Senior), Manager.
  Required when the administrator creates a user; shown in light color under the user's name (sidebar, supervisor
  panel, users list). Choosing a level suggests the matching role.
- Admin menu item “Settings” renamed to “System settings” (personal settings are separate).
- Database migration 0004 (level, personal preferences); existing supervisors get “Manager”, admins “Administrator”.
- Release check: 57 automated tests (SQLite + PostgreSQL), migrations, 49/49 browser scenarios (EN and RU).

## 2.1 — 2026-10-10
- **Operator dashboard**: summary cards (active tasks, background, completed today, calls today answered/missed,
  time busy with tasks) above the work panels.
- **Notification center** (FR-09): bell with unread counter + notifications panel — telephony sync problems,
  ticket reassigned / removed by supervisor, supervisor override, ticket closed or put on hold in Zammad,
  missed calls, password reset. Supervisors also see sync problems of all operators.
- Incoming call: sound signal and desktop notification (when the tab is in the background).
- **Light / dark theme** switch (sidebar and login page), remembered per browser; follows the system by default.
- **Supervisor** (FR-10): summary cards (online/ready/busy/break/offline/sync problems) and
  **assign / reassign a ticket by its number** from the panel.
- Database migration 0003 (notifications read marker).
- `docs/TZ_COMPLIANCE.md`: item-by-item compliance with the specification.
- Release check: 55 automated tests (SQLite + PostgreSQL), migrations, 45/45 browser scenarios (EN and RU).

## 2.0 — 2026-10-10
- **Administrator panel** (left sidebar): Users, Integrations (API), Settings, Ticket types, System status.
- **Own logins**: the administrator creates employees (first/last name, login, position, password, role) and links them
  to a Zammad user and a phone extension. Employees sign in with that login — no Zammad password and no setup on their computers.
- Password management: set/reset passwords, “change at first sign-in”, users change their own password,
  sessions end immediately when a user is disabled or the password changes, lock-out after 5 failed sign-ins.
- **All settings in the panel** (Zammad, AMI, queues, ticket states, language, time zone, rules…), applied immediately
  without restarting the server. API tokens and passwords are stored encrypted. “Test connection” for Zammad and AMI.
- `.env` now needs only POSTGRES_PASSWORD and JWT_SECRET; the first administrator is created automatically.
- New database migration 0002 (existing data is kept). Users from 1.x need a login and password set in the panel.
- Release check: 51 automated tests (SQLite + PostgreSQL), migrations, 40/40 browser scenarios.

## 1.4 — 2026-10-10
- Full release check: `python -m scripts.release_check` runs all tests (SQLite + PostgreSQL), migrations
  (upgrade/check/downgrade) and an end-to-end browser test of every UI function (28 scenarios).
- Zammad HTTP requests are no longer logged one by one (less log noise).
- Release check result for 1.4: ALL CHECKS PASSED (41 tests, migrations, 28/28 UI scenarios, EN and RU).

## 1.3 — 2026-10-10
- Product name: **Agentix**. Shown on the login page, in the top bar, browser tab and API docs.

## 1.2 — 2026-10-10
- Login: leading/trailing spaces in the login are ignored; demo logins are case-insensitive.
- Version number shown in the interface (login page and top bar) and in `/api/health`.

## 1.1 — 2026-10-10
- Interface in English by default; `UI_LANGUAGE=en|ru` switches the interface and server messages.
- Demo data translated to English.

## 1.0 — 2026-10-10
- First release: Task & Agent State Service, operator and supervisor UI, Zammad + FreePBX/Asterisk (AMI) integration,
  tests, Docker Compose, documentation.
