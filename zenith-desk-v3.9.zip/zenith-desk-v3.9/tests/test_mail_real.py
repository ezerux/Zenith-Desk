"""v3.9 E-mail against a REAL mail server: Dovecot (IMAP / POP3 / IDLE) + Postfix (SMTP submission / smtps).

Started by tests/realstack/mailserver.sh (skipped where Dovecot / Postfix are not installed)."""
import asyncio
import base64
import shutil
import smtplib
import socket
import ssl
import subprocess
import time
import uuid
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
ANNA, BORIS, CLIENT = ("anna@company.test", "anna-mail-1"), ("boris@company.test", "boris-mail-2"), ("client@company.test", "client-mail-3")


def port_open(p: int) -> bool:
    s = socket.socket()
    s.settimeout(1)
    try:
        s.connect(("127.0.0.1", p))
        return True
    except OSError:
        return False
    finally:
        s.close()


@pytest.fixture(scope="module", autouse=True)
def mailserver():
    if not (port_open(993) and port_open(587)):
        if not shutil.which("dovecot") or not shutil.which("postfix"):
            pytest.skip("Dovecot / Postfix are not installed (real mail server tests)")
        subprocess.run(["sh", str(ROOT / "tests/realstack/mailserver.sh"), "start"], check=True, timeout=120, capture_output=True)
        for _ in range(40):
            if port_open(993) and port_open(587):
                break
            time.sleep(0.5)
    yield


def configure(env, protocol="imap", port=993, security="ssl", smtp_port=587, smtp_security="starttls", idle=True):
    c = env.settings
    c.mail_enabled, c.mail_protocol, c.mail_in_host, c.mail_in_port, c.mail_in_security = True, protocol, "127.0.0.1", port, security
    c.mail_smtp_host, c.mail_smtp_port, c.mail_smtp_security, c.mail_smtp_auth = "127.0.0.1", smtp_port, smtp_security, True
    c.mail_verify_tls, c.mail_domain, c.mail_login_format, c.mail_idle, c.mail_save_sent = False, "company.test", "email", idle, True
    env.services.mail._loop = asyncio.get_running_loop()


def raw_send(frm, pw, to, data: bytes):
    ctx = ssl.create_default_context()
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    c = smtplib.SMTP("127.0.0.1", 587, timeout=10)
    c.starttls(context=ctx)
    c.login(frm, pw)
    c.sendmail(frm, [to], data)
    c.quit()


async def wait_list(env, h, folder, subject, timeout=10):
    t0 = time.monotonic()
    fid = base64.urlsafe_b64encode(folder.encode()).decode().rstrip("=")
    while time.monotonic() - t0 < timeout:
        r = await env.client.get(f"/api/mail/folders/{fid}/messages", headers=h)
        if r.status_code == 200:
            for it in r.json()["items"]:
                if it["subject"] == subject:
                    return it, fid
        await asyncio.sleep(0.3)
    raise AssertionError(f"{subject} not in {folder}")


def fid(name):
    return base64.urlsafe_b64encode(name.encode()).decode().rstrip("=")


async def test_admin_probe_and_sign_in_with_only_email_and_password(env):
    configure(env)
    from tests.test_messengers import _admin
    ha = await _admin(env)
    r = (await env.client.post("/api/admin/settings/test/mail", headers=ha, json={"values": {}})).json()
    assert r["ok"] and "IDLE" in r["detail"] and "SMTP 127.0.0.1:587" in r["detail"], r
    r = (await env.client.post("/api/admin/settings/test/mail", headers=ha, json={"values": {"test_email": "anna", "test_password": "anna-mail-1"}})).json()
    assert r["ok"] and "anna@company.test: sign-in OK" in r["detail"], r
    r = (await env.client.post("/api/admin/settings/test/mail", headers=ha, json={"values": {"mail_in_port": 1}})).json()
    assert not r["ok"] and "refused" in r["detail"]
    h = await env.login("anna")
    acc = (await env.client.get("/api/mail/account", headers=h)).json()
    assert acc["enabled"] and not acc["connected"] and acc["domain"] == "company.test"
    r = await env.client.post("/api/mail/account", headers=h, json={"email": "anna", "password": "wrong"})
    assert r.status_code == 422 and "password" in r.text  # never 401: that would sign the person out of Zenith Desk
    r = await env.client.post("/api/mail/account", headers=h, json={"email": "anna@other.com", "password": "x"})
    assert r.status_code == 422
    r = await env.client.post("/api/mail/account", headers=h, json={"email": "anna", "password": "anna-mail-1"})
    assert r.status_code == 200 and r.json()["connected"] and r.json()["email"] == "anna@company.test", r.text
    folders = (await env.client.get("/api/mail/folders", headers=h)).json()["folders"]
    roles = {f["role"]: f["name"] for f in folders}
    assert {"inbox", "sent", "drafts", "trash", "junk"} <= set(roles), folders
    # the password is stored encrypted
    from app.models import MailAccount
    async with env.services.db.sessionmaker() as s:
        acc = await s.get(MailAccount, 1)
    assert "anna-mail-1" not in acc.secret
    await env.services.mail.stop()


async def test_send_read_reply_attachments_folders_search_drafts(env):
    configure(env)
    ha, hb = await env.login("anna"), await env.login("boris")
    assert (await env.client.post("/api/mail/account", headers=ha, json={"email": "anna", "password": "anna-mail-1"})).status_code == 200
    assert (await env.client.post("/api/mail/account", headers=hb, json={"email": "boris@company.test", "password": "boris-mail-2"})).status_code == 200
    tag = uuid.uuid4().hex[:6]
    subject = f"Отчёт за неделю {tag}"
    pdf = b"%PDF-1.4 weekly report " * 100
    r = await env.client.post("/api/mail/send", headers=ha, json={
        "to": [{"name": "Boris", "email": "boris@company.test"}], "cc": "client@company.test", "subject": subject,
        "text": "Борис, привет!\nОтчёт во вложении.\nhttps://zenith.example/report",
        "files": [{"name": "отчёт.pdf", "mime": "application/pdf", "data": base64.b64encode(pdf).decode()}]})
    assert r.status_code == 200, r.text
    item, inbox = await wait_list(env, hb, "INBOX", subject)
    assert item["has_files"] and not item["seen"] and item["from"][0]["email"] == "anna@company.test"
    m = (await env.client.get(f"/api/mail/messages/{inbox}/{item['uid']}", headers=hb)).json()
    assert "Отчёт во вложении" in m["text"] and "<script" not in m["html"] and 'href="https://zenith.example/report"' in m["html"]
    assert m["to"][0]["email"] == "boris@company.test" and m["cc"][0]["email"] == "client@company.test"
    att = m["attachments"][0]
    assert att["name"] == "отчёт.pdf" and att["size"] == len(pdf)
    data = await env.client.get(att["url"], headers=hb)
    assert data.content == pdf and "attachment" in data.headers["content-disposition"]
    item2, _ = await wait_list(env, hb, "INBOX", subject)
    assert item2["seen"], "opened message must be marked read"
    # a copy in Anna's Sent
    await wait_list(env, ha, "Sent", subject)
    # reply all prepared correctly, then sent
    rp = m["reply_all"]
    assert rp["subject"] == "Re: " + subject and rp["to"][0]["email"] == "anna@company.test" and rp["cc"][0]["email"] == "client@company.test"
    assert rp["in_reply_to"] == m["message_id"] and "> Борис, привет!" in rp["text"]
    r = await env.client.post("/api/mail/send", headers=hb, json={**rp, "text": "Спасибо!" + rp["text"]})
    assert r.status_code == 200
    rep, _ = await wait_list(env, ha, "INBOX", "Re: " + subject)
    rm = (await env.client.get(f"/api/mail/messages/{inbox}/{rep['uid']}", headers=ha)).json()
    assert rm["references"].endswith(m["message_id"])
    # forward with the original attachment
    fw = m["forward"]
    r = await env.client.post("/api/mail/send", headers=hb, json={"to": "client@company.test", "subject": fw["subject"], "text": fw["text"],
                                                                     "forward_files": [{"folder": inbox, "uid": item["uid"], "idx": 0}]})
    assert r.status_code == 200
    # search (Cyrillic), unread / flag, move to Junk, delete → Trash → gone
    res = (await env.client.get(f"/api/mail/folders/{inbox}/messages?q=недел", headers=hb)).json()
    assert any(i["uid"] == item["uid"] for i in res["items"])
    await env.client.post("/api/mail/flags", headers=hb, json={"folder": inbox, "uids": [item["uid"]], "seen": False, "flagged": True})
    it, _ = await wait_list(env, hb, "INBOX", subject)
    assert not it["seen"] and it["flagged"]
    assert (await env.client.post("/api/mail/move", headers=hb, json={"folder": inbox, "uids": [item["uid"]], "target": fid("Junk")})).status_code == 200
    junk_item, junk = await wait_list(env, hb, "Junk", subject)
    assert (await env.client.post("/api/mail/delete", headers=hb, json={"folder": junk, "uids": [junk_item["uid"]]})).status_code == 200
    tr_item, trash = await wait_list(env, hb, "Trash", subject)
    assert (await env.client.post("/api/mail/delete", headers=hb, json={"folder": trash, "uids": [tr_item["uid"]]})).status_code == 200
    left = (await env.client.get(f"/api/mail/folders/{trash}/messages", headers=hb)).json()["items"]
    assert all(i["subject"] != subject for i in left)
    # drafts: saved, replaced by the next save, removed when sent
    r = await env.client.post("/api/mail/draft", headers=ha, json={"to": "boris@company.test", "subject": f"Draft {tag}", "text": "v1"})
    d1, drafts = await wait_list(env, ha, "Drafts", f"Draft {tag}")
    await env.client.post("/api/mail/draft", headers=ha, json={"to": "boris@company.test", "subject": f"Draft {tag}", "text": "v2", "draft_uid": d1["uid"]})
    lst = (await env.client.get(f"/api/mail/folders/{drafts}/messages", headers=ha)).json()["items"]
    assert len([i for i in lst if i["subject"] == f"Draft {tag}"]) == 1
    # bad recipient refused by the server's rules
    r = await env.client.post("/api/mail/send", headers=ha, json={"to": "not-an-address", "subject": "x", "text": "x"})
    assert r.status_code == 422
    await env.services.mail.stop()


async def test_dangerous_html_is_cleaned_and_remote_images_blocked(env):
    configure(env)
    hb = await env.login("boris")
    assert (await env.client.post("/api/mail/account", headers=hb, json={"email": "boris", "password": "boris-mail-2"})).status_code == 200
    tag = uuid.uuid4().hex[:6]
    html = (f'<html><body><h1 onclick="alert(1)">Promo {tag}</h1><script>alert(document.cookie)</script>'
            '<img src="https://tracker.example/pixel.gif"><form action="https://phish"><input name=p></form>'
            '<a href="javascript:alert(1)">x</a><iframe src="https://evil"></iframe></body></html>')
    data = ("From: client@company.test\r\nTo: boris@company.test\r\nSubject: Promo " + tag + "\r\nMIME-Version: 1.0\r\n"
            "Content-Type: text/html; charset=utf-8\r\n\r\n" + html).encode()
    raw_send(*CLIENT, "boris@company.test", data)
    item, inbox = await wait_list(env, hb, "INBOX", "Promo " + tag)
    m = (await env.client.get(f"/api/mail/messages/{inbox}/{item['uid']}", headers=hb)).json()
    low = m["html"].lower()
    for bad in ("<script", "onclick", "<form", "<iframe", "javascript:", ' src="https://tracker'):
        assert bad not in low, bad
    assert m["remote_images"] and 'data-src="https://tracker.example/pixel.gif"' in m["html"]
    await env.services.mail.stop()


async def test_idle_real_time_and_fallback_recovers_missed_mail(env):
    configure(env)
    hb = await env.login("boris")
    assert (await env.client.post("/api/mail/account", headers=hb, json={"email": "boris", "password": "boris-mail-2"})).status_code == 200
    q = asyncio.Queue()
    env.services.broker._agent_subs[2].add(q)  # boris has Zenith Desk open
    await env.services.mail.presence(2, 1)
    t0 = time.monotonic()
    while not env.services.mail.idle_state.get(2, (False,))[0]:
        assert time.monotonic() - t0 < 10, "IDLE did not start"
        await asyncio.sleep(0.1)
    assert env.services.hub.items["mail"].realtime == "on"
    # a quiet mailbox must keep the IDLE connection (v3.9 fix: a 1 s read timeout used to break the connection)
    await asyncio.sleep(4)
    assert env.services.mail.idle_state[2] == (True, ""), env.services.mail.idle_state[2]
    assert env.services.hub.items["mail"].last_error == ""
    for n in range(2):  # two mails in a row: IDLE is renewed after each one
        tag = uuid.uuid4().hex[:6]
        raw_send(*ANNA, "boris@company.test", f"From: Anna <anna@company.test>\r\nTo: boris@company.test\r\nSubject: Instant {tag}\r\n\r\nhi".encode())
        got = None
        t0 = time.monotonic()
        while time.monotonic() - t0 < 10 and not got:
            try:
                ev = await asyncio.wait_for(q.get(), timeout=1)
            except asyncio.TimeoutError:
                continue
            if "mail_new" in str(ev) and f"Instant {tag}" in str(ev):
                got = ev
        assert got, f"IMAP IDLE did not announce new mail #{n + 1}"
        print("IDLE latency", round(time.monotonic() - t0, 2), "s")
    assert env.services.mail.idle_state[2] == (True, "")
    # real time off (network failure): the fallback check finds the mail that arrived meanwhile
    await env.services.mail.presence(2, 0)
    raw_send(*ANNA, "boris@company.test", f"Subject: Missed {tag}\r\n\r\nmissed".encode())
    await asyncio.sleep(1.5)
    res = await env.services.hub.poll("mail")
    assert res["last_recovered"] >= 1 and res["ok"], res
    env.services.broker._agent_subs[2].discard(q)
    await env.services.mail.stop()


async def test_pop3_mode_downloads_and_keeps_local_folders(env):
    configure(env, protocol="pop3", port=995)
    hc = await env.login("anna")  # anna's account here reads client's mailbox over POP3
    tag = uuid.uuid4().hex[:6]
    raw_send(*BORIS, "client@company.test", f"From: boris@company.test\r\nTo: client@company.test\r\nSubject: POP {tag}\r\n\r\nvia pop3".encode())
    await asyncio.sleep(1.5)
    r = await env.client.post("/api/mail/account", headers=hc, json={"email": "client", "password": "client-mail-3"})
    assert r.status_code == 200, r.text
    folders = (await env.client.get("/api/mail/folders", headers=hc)).json()["folders"]
    assert [f["name"] for f in folders] == ["INBOX", "Drafts", "Sent", "Trash"]
    item, inbox = await wait_list(env, hc, "INBOX", f"POP {tag}")
    m = (await env.client.get(f"/api/mail/messages/{inbox}/{item['uid']}", headers=hc)).json()
    assert "via pop3" in m["text"]
    r = await env.client.post("/api/mail/send", headers=hc, json={"to": "boris@company.test", "subject": f"From POP {tag}", "text": "ok"})
    assert r.status_code == 200
    await wait_list(env, hc, "Sent", f"From POP {tag}")
    assert (await env.client.post("/api/mail/delete", headers=hc, json={"folder": inbox, "uids": [item["uid"]]})).status_code == 200
    await wait_list(env, hc, "Trash", f"POP {tag}")
    # the same message is not downloaded twice
    n = await env.services.mail._pop3_sync(1)
    assert n == 0
    await env.services.mail.stop()


async def test_ticket_from_email(env):
    configure(env)
    hb = await env.login("boris")
    assert (await env.client.post("/api/mail/account", headers=hb, json={"email": "boris", "password": "boris-mail-2"})).status_code == 200
    tag = uuid.uuid4().hex[:6]
    raw_send(*CLIENT, "boris@company.test", (f"From: Narine Avetisyan <client@company.test>\r\nTo: boris@company.test\r\nSubject: Broken chair {tag}\r\n\r\n"
                                              "The chair arrived broken.").encode())
    item, inbox = await wait_list(env, hb, "INBOX", f"Broken chair {tag}")
    r = await env.client.post(f"/api/mail/messages/{inbox}/{item['uid']}/ticket", headers=hb)
    assert r.status_code == 200, r.text
    t = env.zammad.tickets[r.json()["ticket_id"]]
    cust = env.zammad.users[t["customer_id"]]
    assert t["title"] == f"Broken chair {tag}" and cust["email"] == "client@company.test" and cust["firstname"] == "Narine"
    arts = [a for a in env.zammad.articles if a.get("ticket_id") == t["id"]]
    assert arts and "arrived broken" in arts[0]["body"]
    await env.services.mail.stop()
