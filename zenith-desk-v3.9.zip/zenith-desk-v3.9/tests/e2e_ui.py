"""End-to-end UI check of every function in a real browser against the demo server.

    python -m scripts.demo &          # or let scripts/release_check.py start it
    python tests/e2e_ui.py http://localhost:8000 [screenshots_dir]

Exits with code 1 and prints the failed step if anything does not work.
Requires: pip install playwright (Chromium installed via `playwright install chromium`).
"""
import asyncio
import time
import json
import sys
import urllib.error
import urllib.request

from playwright.async_api import Page, async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
SHOTS = sys.argv[2] if len(sys.argv) > 2 else ""
RESULTS: list[tuple[str, bool, str]] = []


def http(method: str, path: str, data: dict | None = None, token: str = ""):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(data).encode() if data else None,
                                 headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read() or b"null")


def http_raw(path: str) -> bytes:
    with urllib.request.urlopen(BASE + path) as r:
        return r.read()


def pbx(iface: str = "Local/101@from-queue/n") -> bool:
    return http("GET", "/demo/pbx")["400"][iface]["paused"]


async def step(name: str, coro):
    try:
        await coro
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}")
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, False, str(exc)[:300]))
        print(f"  FAIL  {name}: {str(exc)[:300]}")


async def login(page: Page, user: str, password: str = "pw", wait: str = ".topbar .status") -> None:
    await page.goto(BASE + "/")
    await page.wait_for_selector("input[autocomplete=username]")
    await page.fill("input[autocomplete=username]", user)
    await page.fill("input[type=password]", password)
    await page.click("form button.primary")
    await page.wait_for_selector(wait, timeout=8000)
    await page.wait_for_timeout(600)


async def nav(page: Page, key) -> None:
    """Click a sidebar item by its key (work, chat, sup, overview, users, …) — works in any interface language."""
    if await page.locator(".burger").is_visible():
        await page.click(".burger")
    if isinstance(key, int):
        await page.locator(".side-nav button").nth(key).click()
    else:
        await page.click(f".side-nav button[data-nav={key}]")
    await page.wait_for_timeout(900)


async def status_text(page: Page) -> str:
    return await page.inner_text(".topbar .status")


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


async def main() -> int:
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        errors: list[str] = []

        def new_page(width=1440, height=950):
            async def make():
                pg = await browser.new_page(viewport={"width": width, "height": height})
                pg.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
                # HTTP 4xx answers provoked on purpose (wrong password, refused Ready, validation) are not JS errors
                pg.on("console", lambda m: errors.append(f"console: {m.text}")
                      if m.type == "error" and "Failed to load resource" not in m.text else None)
                return pg
            return make()

        pg = await new_page()

        # ---------------------------------------------------------------- login
        async def bad_login():
            await pg.goto(BASE + "/")
            await pg.fill("input[autocomplete=username]", "anna")
            await pg.fill("input[type=password]", "wrong")
            await pg.click("form button.primary")
            await pg.wait_for_selector("form p", timeout=5000)
            expect("Wrong" in await pg.inner_text("form p") or "Невер" in await pg.inner_text("form p"), "no error text")
        await step("Login: wrong password shows an error", bad_login())

        async def version_on_login():
            expect((await pg.inner_text(".login .version")).startswith("v"), "version missing")
            expect("Zenith Desk" in await pg.inner_text(".login .logo"), "product name missing on the login page")
            expect("Zenith Desk" in await pg.title(), "product name missing in the browser tab")
            loaded = await pg.evaluate("(() => { const i = document.querySelector('.login .logo img'); return !!i && i.complete && i.naturalWidth > 0; })()")
            expect(loaded, "logo not loaded")
            icon = http_raw("/static/logo-192.png")
            expect(icon.startswith(b"\x89PNG"), "PNG icon missing")
        await step("Login page: Zenith Desk name, logo, tab icon and version", version_on_login())

        await step("Login: operator anna", login(pg, "anna"))

        async def dashboard_cards():
            expect(await pg.locator(".kpis .kpi").count() == 5, "dashboard cards missing")
            expect(await pg.locator(".ntf-panel").count() == 1, "notifications panel missing")
            expect(await pg.locator(".bell").count() == 1, "bell missing")
        await step("Operator dashboard: 5 summary cards, notifications panel, bell", dashboard_cards())

        async def console_design():
            expect(await pg.evaluate("document.documentElement.dataset.theme") == "dark", "dark console is not the default look")
            w = await pg.evaluate("document.querySelector('.sidebar').getBoundingClientRect().width")
            expect(w <= 80, f"sidebar is not an icon rail (width {w})")
            expect(await pg.locator(".side-nav button svg").count() >= 1, "rail icons missing")
            font = await pg.evaluate("getComputedStyle(document.body).fontFamily")
            expect("IBM Plex Sans" in font, f"font: {font}")
            ok = await pg.evaluate("document.fonts.check('16px \"IBM Plex Sans\"')")
            expect(ok, "IBM Plex Sans not loaded from the server")
            await pg.hover(".side-nav button >> nth=0")
            try:
                await pg.wait_for_function("getComputedStyle(document.querySelector('.side-nav button .lbl')).opacity === '1'", timeout=2000)
            except Exception as exc:
                raise AssertionError("rail tooltip not shown on hover") from exc
            expect(await pg.locator(".topbar .me .avatar").count() == 1, "user block missing in the top bar")
        await step("Command Center design: dark by default, icon rail with tooltips, local fonts", console_design())

        async def theme_toggle():
            before = await pg.evaluate("getComputedStyle(document.body).backgroundColor")
            await pg.click(".sidebar .theme-toggle")
            await pg.wait_for_timeout(300)
            after = await pg.evaluate("getComputedStyle(document.body).backgroundColor")
            theme = await pg.evaluate("document.documentElement.dataset.theme")
            expect(before != after and theme in ("dark", "light"), f"theme did not change ({before} -> {after})")
            await pg.reload()
            await pg.wait_for_selector(".sidebar")
            expect(await pg.evaluate("document.documentElement.dataset.theme") == theme, "theme not remembered after reload")
            await pg.click(".sidebar .theme-toggle")  # back
            await pg.wait_for_timeout(300)
            expect(await pg.evaluate("getComputedStyle(document.body).backgroundColor") == before, "theme did not switch back")
        await step("Dark / light theme switch is applied and remembered", theme_toggle())

        async def level_under_name():
            txt = await pg.inner_text(".topbar .me-level")
            expect("1" in txt, f"level missing: {txt!r}")
        await step("Level is shown under the user's name", level_under_name())

        async def customize_workspace():
            await pg.click(".customize-btn")
            await pg.wait_for_selector(".edit-bar")
            calls = pg.locator(".widget[data-w=calls]")
            await calls.locator(".widget-tools .wt").nth(4).click()          # width: full (▭)
            await calls.locator(".widget-tools .wt").nth(5).click()          # height: M (default) -> L
            await pg.locator(".widget[data-w=pending] .widget-tools .wt.hide").click()
            await pg.drag_and_drop(".widget[data-w=notifications] .widget-tools", ".widget[data-w=active] .widget-tools")
            await pg.wait_for_timeout(300)
            await pg.click(".ws-done")
            await pg.wait_for_timeout(800)
            await pg.reload()
            await pg.wait_for_selector(".dash")
            await pg.wait_for_timeout(800)
            order = await pg.eval_on_selector_all(".dash > .widget", "els => els.map(e => e.dataset.w)")
            expect("pending" not in order, f"hidden block still visible: {order}")
            expect(order.index("notifications") < order.index("active"), f"drag & drop order not saved: {order}")
            cls = await pg.get_attribute(".widget[data-w=calls]", "class")
            expect("w3" in cls and "h-l" in cls, f"size not saved: {cls}")
        await step("Customize workspace: resize, hide, drag & drop — saved after reload", customize_workspace())

        async def presets_and_restore():
            await pg.click(".settings-btn")
            await pg.wait_for_selector(".presets")
            expect(await pg.locator(".preset").count() >= 6, "presets missing (5 + my layout)")
            await pg.click(".preset[data-preset=focus]")
            await pg.click(".side-nav button >> nth=0")
            await pg.wait_for_timeout(700)
            order = await pg.eval_on_selector_all(".dash > .widget", "els => els.map(e => e.dataset.w)")
            expect(order == ["active", "notifications", "new", "background"], f"focus preset wrong: {order}")
            await pg.click(".customize-btn")
            await pg.click(".edit-bar button:has-text('Reset'), .edit-bar button:has-text('Сбросить')")
            await pg.click(".ws-done")
            await pg.wait_for_timeout(600)
            order = await pg.eval_on_selector_all(".dash > .widget", "els => els.map(e => e.dataset.w)")
            expect(order == ["kpis", "active", "notifications", "background", "calls", "new", "mine", "pending"], f"default not restored: {order}")
        await step("Ready layouts (presets) and reset to default", presets_and_restore())

        async def settings_follow_user():
            await pg.click(".settings-btn")
            await pg.click(".seg button[data-theme-opt=light]")
            await pg.uncheck(".my-settings input[name=sound]")
            await pg.wait_for_timeout(900)
            other = await browser.new_page()   # a "different computer": empty browser storage
            await login(other, "anna", wait=".sidebar")
            expect(await other.evaluate("document.documentElement.dataset.theme") == "light", "theme not loaded from the account")
            await other.click(".settings-btn")
            expect(not await other.is_checked(".my-settings input[name=sound]"), "sound setting not loaded from the account")
            await other.close()
            await pg.click(".seg button[data-theme-opt=system]")
            expect(await pg.evaluate("document.documentElement.dataset.theme") in ("light", "dark"), "system theme not applied")
            await pg.click(".seg button[data-theme-opt=dark]")
            await pg.check(".my-settings input[name=sound]")
            await pg.wait_for_timeout(700)
            await pg.click(".side-nav button >> nth=0")
            await pg.wait_for_timeout(500)
        await step("Personal settings follow the user to another computer", settings_follow_user())

        async def motion():
            # a page change runs as a View Transition, and the new page is in the DOM immediately after it
            vt = await pg.evaluate("""() => new Promise(res => {
                const seen = []; const obs = new MutationObserver(() => seen.push(document.documentElement.dataset.vt || ''));
                obs.observe(document.documentElement, {attributes: true, attributeFilter: ['data-vt']});
                document.querySelector('.settings-btn').click();
                setTimeout(() => { obs.disconnect(); res(seen); }, 700);
            })""")
            expect("page" in vt, f"no page transition: {vt}")
            expect(await pg.locator(".my-settings").count() == 1, "settings page not shown after the transition")
            await pg.click(".seg button[data-theme-opt=light]")       # ripple feedback on press
            expect(await pg.evaluate("!!document.querySelector('.seg [data-ripple]')"), "no ripple on press")
            await pg.click(".seg button[data-theme-opt=dark]")
            await pg.click(".my-settings input[name=motion]")          # switch animations off
            await pg.wait_for_timeout(700)
            expect(await pg.evaluate("document.documentElement.dataset.motion") == "off", "animations not switched off")
            await pg.reload()
            await pg.wait_for_selector(".sidebar")
            await pg.wait_for_timeout(600)
            expect(await pg.evaluate("document.documentElement.dataset.motion") == "off", "animation setting not saved")
            dur = await pg.evaluate("getComputedStyle(document.querySelector('.btn')).transitionDuration")
            expect(all(float(x.strip()[:-1]) < 0.01 for x in dur.split(",")), f"transitions still on: {dur}")
            await pg.click(".settings-btn")
            await pg.click(".my-settings input[name=motion]")          # back on
            await pg.wait_for_timeout(700)
            expect(await pg.evaluate("document.documentElement.dataset.motion") is None, "animations not switched back on")
            await pg.click(".side-nav button >> nth=0")
            await pg.wait_for_timeout(500)
        await step("Motion: page transitions, ripple, animations can be switched off and it is saved", motion())

        async def initial_ready():
            st = await status_text(pg)
            expect("Ready" in st or "Готов" in st, f"status: {st}")
            expect(not pbx(), "anna should not be paused when ready")
        await step("After login operator is Ready and receives calls", initial_ready())

        # ---------------------------------------------------------------- break / ready
        async def go_break():
            await pg.click(".topbar button:nth-of-type(2)")
            await pg.wait_for_timeout(700)
            expect("break" in (await status_text(pg)).lower() or "Перерыв" in await status_text(pg), "not on break")
            expect(pbx(), "should be paused on break")
        await step("Break pauses the operator in queues", go_break())

        async def go_ready():
            await pg.click(".topbar button.go")
            await pg.wait_for_timeout(700)
            expect(not pbx(), "should be unpaused after Ready")
        await step("Ready unpauses the operator", go_ready())

        # ---------------------------------------------------------------- start blocking / complete
        async def start_blocking():
            await pg.click(".widget[data-w=mine] section .item .actions button.primary")  # "Assigned to me" -> Start
            await pg.wait_for_timeout(900)
            expect(pbx(), "blocking task must pause the operator")
            expect(await pg.locator(".widget[data-w=active] section .item").count() == 1, "no active task")
        await step("Start (blocking) pauses calls and shows the active task", start_blocking())

        async def ready_refused():
            await pg.evaluate("""() => fetch('/api/agents/me/ready', {method:'POST', headers:{Authorization:'Bearer '+localStorage.getItem('aws_token')}}).then(r => window.__ready = r.status)""")
            await pg.wait_for_timeout(400)
            expect(await pg.evaluate("window.__ready") == 409, "Ready must be refused while blocking")
        await step("Manual Ready is refused while a blocking task exists", ready_refused())

        async def to_background_and_back():
            await pg.click(".widget[data-w=active] section .item .actions button:nth-child(2)")  # Background task
            await pg.wait_for_timeout(800)
            expect(not pbx(), "background must not pause")
            expect(await pg.locator(".widget[data-w=background] section .item").count() == 1, "not in background list")
            await pg.click(".widget[data-w=background] section .item .actions button.primary")  # Start (back to blocking)
            await pg.wait_for_timeout(800)
            expect(pbx(), "back to blocking must pause")
        await step("Switch blocking -> background -> blocking", to_background_and_back())

        async def complete():
            await pg.click(".widget[data-w=active] section .item .actions button.go")
            await pg.wait_for_selector(".modal")
            await pg.fill(".modal textarea", "Resolved by e2e test")
            await pg.click(".modal button.go")
            await pg.wait_for_timeout(900)
            expect(not pbx(), "complete must return the operator to the queue")
            expect(await pg.locator(".widget[data-w=active] section .item").count() == 0, "task still active")
        await step("Complete closes the task and returns calls", complete())

        async def kpi_completed():
            await pg.wait_for_timeout(500)
            expect((await pg.inner_text(".kpi.done .v")).strip() == "1", "completed-today counter not updated")
        await step("Dashboard counter 'completed today' updates", kpi_completed())

        # ---------------------------------------------------------------- unassigned (messenger) tickets
        async def two_blocking():
            await pg.click(".widget[data-w=new] section .item >> nth=0 >> button.primary")
            await pg.wait_for_timeout(700)
            await pg.click(".widget[data-w=new] section .item >> nth=0 >> button.primary")
            await pg.wait_for_timeout(700)
            expect(await pg.locator(".widget[data-w=active] section .item").count() == 2, "expected 2 blocking tasks")
            await pg.click(".widget[data-w=active] section .item >> nth=0 >> button.go")
            await pg.wait_for_selector(".modal"); await pg.click(".modal button.go"); await pg.wait_for_timeout(900)
            expect(pbx(), "one blocking task left — must stay paused")
            await pg.click(".widget[data-w=active] section .item >> nth=0 >> button.go")
            await pg.wait_for_selector(".modal"); await pg.click(".modal button.go"); await pg.wait_for_timeout(900)
            expect(not pbx(), "no blocking tasks — must be unpaused")
        await step("New requests: two blocking tasks, completing one keeps the pause", two_blocking())

        async def background_from_new():
            await pg.click(".widget[data-w=new] section .item >> nth=0 >> button:nth-child(2)")
            await pg.wait_for_timeout(800)
            expect(not pbx(), "background task must not pause")
            await pg.click(".widget[data-w=background] section .item >> nth=0 >> button:nth-child(3)")  # Remove
            await pg.wait_for_timeout(700)
        await step("Background task from a messenger ticket does not pause", background_from_new())

        # ---------------------------------------------------------------- incoming call
        async def incoming_call():
            http("POST", "/demo/call?ext=101&number=89123456789")
            await pg.wait_for_selector(".call", timeout=5000)
            await pg.wait_for_selector(".call .customer b", timeout=5000)
            expect("Ivan" in await pg.inner_text(".call"), "customer card not shown")
        await step("Incoming call opens the customer card", incoming_call())

        async def ticket_from_call():
            await pg.click(".call button.primary")
            await pg.wait_for_selector(".modal")
            await pg.select_option(".modal select >> nth=1", "Order")
            await pg.fill(".modal input >> nth=0", "A-777")
            await pg.fill(".modal input >> nth=1", "E2E ticket from call")
            await pg.click(".modal .footer button.primary")
            await pg.wait_for_timeout(1000)
            expect(await pg.locator(".modal").count() == 0, "modal still open")
            expect(pbx(), "save and start (blocking) must pause")
            expect("E2E ticket from call" in await pg.inner_text(".widget[data-w=active] section"), "ticket not in active tasks")
        await step("Create ticket from call with required fields and start", ticket_from_call())

        async def required_field_check():
            http("POST", "/demo/call?ext=101&number=89123456789")
            await pg.wait_for_selector(".call")
            await pg.click(".call button.primary")
            await pg.wait_for_selector(".modal")
            await pg.select_option(".modal select >> nth=1", "Order")
            await pg.fill(".modal input >> nth=1", "Missing order number")
            await pg.click(".modal .footer button:nth-child(2)")
            await pg.wait_for_selector(".toast.error", timeout=4000)
            expect(await pg.locator(".modal").count() == 1, "modal must stay open on validation error")
            await pg.click(".modal .footer button:nth-child(1)")
        await step("Required fields are validated", required_field_check())

        async def unknown_caller():
            http("POST", "/demo/call?ext=101&number=89990000000")
            await pg.wait_for_timeout(1000)
            await pg.click(".call .actions button:nth-child(2)")  # Create customer
            await pg.wait_for_selector(".modal")
            await pg.fill(".modal input >> nth=0", "New")
            await pg.fill(".modal input >> nth=1", "Caller")
            await pg.click(".modal .footer button.primary")
            await pg.wait_for_selector(".call .customer b", timeout=5000)
            expect("New Caller" in await pg.inner_text(".call"), "new customer not shown")
            await pg.click(".call .actions button:last-child")  # Hide
        await step("Unknown caller: create customer", unknown_caller())

        async def recent_calls():
            expect(await pg.locator(".widget[data-w=calls] section .item").count() >= 3, "recent calls missing")
        await step("Recent calls list", recent_calls())

        # ---------------------------------------------------------------- v3.3 ticketing inside Zenith Desk
        anna_tok = await pg.evaluate("localStorage.getItem('aws_token')")

        def find_ticket(title: str, view: str = "all") -> dict:
            from urllib.parse import quote
            rows = http("GET", f"/api/tk/tickets?view={view}&q={quote(title)}", token=anna_tok)["tickets"]
            return next(r for r in rows if r["title"] == title)

        http("POST", "/demo/zammad/ticket?title=Refund%20for%20a%20damaged%20sofa&text=The%20sofa%20arrived%20with%20a%20broken%20leg.%20I%20want%20a%20refund.")

        async def tk_lists():
            await nav(pg, "tickets")
            await pg.wait_for_selector(".tk-row", timeout=6000)
            mine = await pg.locator(".tk-row").count()
            expect(mine >= 2, f"my tickets missing ({mine})")
            for v in ("unassigned", "all", "closed"):
                await pg.click(f".tk-views [data-view={v}]")
                await pg.wait_for_timeout(500)
            expect(await pg.locator(".tk-row").count() >= 1, "closed tickets missing")
            await pg.click(".tk-views [data-view=all]")
            await pg.fill(".tk-search input", "damaged sofa")
            await pg.wait_for_timeout(800)
            rows = await pg.locator(".tk-row").all_inner_texts()
            expect(len(rows) == 1 and "Refund for a damaged sofa" in rows[0], f"search: {rows}")
            await pg.select_option(".tk-filters select >> nth=1", "3 high")
            await pg.wait_for_timeout(500)
            expect(await pg.locator(".tk-row").count() == 0, "priority filter")
            await pg.select_option(".tk-filters select >> nth=1", "")
            await pg.wait_for_timeout(500)
        await step("Tickets: my / unassigned / all / closed lists, search and filters", tk_lists())

        async def tk_conversation():
            await pg.click(".tk-row >> nth=0")
            await pg.wait_for_selector(".tk-art", timeout=6000)
            expect("broken leg" in await pg.inner_text(".tk-thread"), "customer message not shown")
            await pg.fill(".tk-compose textarea", "Photos checked, refund goes today.")
            await pg.set_input_files(".tc-attach input[type=file]", files=[{"name": "refund.txt", "mimeType": "text/plain", "buffer": b"refund 4512"}])
            await pg.wait_for_selector(".tc-files .ta-file")
            await pg.click(".tc-send")
            await pg.wait_for_selector(".tk-art.internal >> text=refund goes today", timeout=6000)
            expect(await pg.locator(".tk-art.internal .ta-file").count() >= 1, "attachment not in the note")
            await pg.click(".tc-modes [data-kind=reply]")
            target = await pg.inner_text(".tc-target")
            expect("E-mail" in target and "tigran" in target.lower(), f"reply target: {target}")
            await pg.fill(".tk-compose textarea", "Dear Tigran, your refund is approved.")
            await pg.click(".tc-send")
            await pg.wait_for_selector(".tk-art.from-agent:not(.internal) >> text=refund is approved", timeout=6000)
            d = http("GET", f"/api/tk/tickets/{find_ticket('Refund for a damaged sofa')['id']}", token=anna_tok)
            last = d["articles"][-1]
            expect(last["type"] == "email" and not last["internal"] and "tigran" in last["to"], f"reply not sent by e-mail: {last}")
        await step("Ticket page: conversation, internal note with a file, reply to the customer by e-mail (saved in Zammad)", tk_conversation())

        async def tk_properties():
            await pg.select_option(".tk-side select[data-f=priority]", "2 normal")
            await pg.wait_for_timeout(700)
            await pg.select_option(".tk-side select[data-f=state]", "pending reminder")
            await pg.wait_for_selector(".tk-hnum .tk-chip.c-pending", timeout=5000)
            t = find_ticket("Refund for a damaged sofa")
            expect(t["priority"] == "2 normal" and t["state"] == "pending reminder", f"not saved in Zammad: {t}")
            await pg.click(".tk-title")
            await pg.fill(".tk-title-input", "Refund for a damaged sofa (approved)")
            await pg.press(".tk-title-input", "Enter")
            await pg.wait_for_selector(".tk-title >> text=(approved)", timeout=5000)
            await pg.select_option(".tk-side select[data-f=state]", "open")
            await pg.wait_for_selector(".tk-hnum .tk-chip.c-open", timeout=5000)
        await step("Ticket: state, priority and title are changed in Zammad", tk_properties())

        bp = await new_page()
        await login(bp, "boris")

        async def tk_transfer():
            await nav(bp, "tickets")
            await bp.wait_for_selector(".tk-list", timeout=5000)
            before = await bp.locator(".tk-row").count()
            await pg.click(".tk-side [data-act=transfer]")
            await pg.wait_for_selector(".tr-person[data-person]", timeout=5000)
            await pg.click(".tr-person[data-person='11']")
            await pg.fill(".tk-transfer textarea", "Boris, please call Tigran back")
            await pg.click("[data-act=do-transfer]")
            await pg.wait_for_selector(".tk-transfer", state="detached", timeout=5000)
            await bp.wait_for_selector(".toast.chat", timeout=4000)
            await bp.wait_for_function(f"document.querySelectorAll('.tk-row').length === {before + 1}", timeout=4000)
            expect("(approved)" in await bp.inner_text(".tk-items"), "transferred ticket not in Boris' list")
            await bp.click(".toast.chat")
            await bp.wait_for_selector(".tk-art >> text=please call Tigran back", timeout=5000)
            expect("Boris" in await pg.inner_text(".ts-owner"), "owner not updated for Anna")
        await step("Transfer to a colleague: he gets it live with a notification, comment included", tk_transfer())

        async def tk_live_from_zammad():
            tid = find_ticket("Refund for a damaged sofa (approved)")["id"]
            http("POST", f"/demo/zammad/change?ticket={tid}&note=Thank%20you%20very%20much!")
            await bp.wait_for_selector(".tk-art >> text=Thank you very much!", timeout=5000)
            http("POST", f"/demo/zammad/change?ticket={tid}&state=closed")
            await bp.wait_for_selector(".tk-hnum .tk-chip.c-closed", timeout=5000)
        await step("Changes made in Zammad (new message, closed) appear in Zenith Desk by themselves", tk_live_from_zammad())

        async def tk_create():
            await pg.click(".tk-new")
            await pg.wait_for_selector(".tk-newform")
            await pg.fill(".tk-newform [name=customer-q]", "Maria")
            await pg.click(".tk-newform .zitem >> text=Maria Kuznetsova")
            await pg.fill(".tk-newform [name=title]", "Gift card balance")
            await pg.fill(".tk-newform [name=body]", "Customer asks how much is left on the gift card.")
            await pg.click("[data-act=create]")
            await pg.wait_for_selector(".tk-title >> text=Gift card balance", timeout=6000)
            t = find_ticket("Gift card balance", "mine")
            expect(t["customer_name"] == "Maria Kuznetsova" and t["mine"], f"ticket not created in Zammad: {t}")
        await step("New ticket created in Zenith Desk is created in Zammad (customer search, assigned to me)", tk_create())

        async def contacts():
            await nav(pg, "contacts")
            await pg.wait_for_selector(".ct-row", timeout=5000)
            await pg.fill(".tk-search input", "Acme")
            await pg.wait_for_timeout(600)
            expect(await pg.locator(".ct-row").count() == 2, "company search")
            await pg.fill(".tk-search input", "")
            await pg.wait_for_timeout(600)
            await pg.click(".ct-row >> text=Ivan Sidorov")
            await pg.wait_for_selector(".ct-hero", timeout=5000)
            expect("VIP customer" in await pg.inner_text(".ct-card") and await pg.locator(".ct-card .tk-row").count() >= 2, "customer card")
            n = await pg.locator(".ct-row").count()
            http("POST", "/demo/zammad/customer?firstname=Narine&lastname=Avetisyan&organization=Sevan%20Hotels")
            await pg.wait_for_selector(".toast.chat >> text=Narine Avetisyan", timeout=6000)
            await pg.wait_for_function(f"document.querySelectorAll('.ct-row').length === {n + 1}", timeout=4000)
            await pg.click("[data-kind=staff]")
            await pg.wait_for_timeout(500)
            expect(await pg.locator(".ct-row").count() >= 4, "Zammad users missing")
            await pg.click(".ct-row >> nth=0")
            await pg.wait_for_selector(".ct-hero")
            await pg.click(".ct-card .tk-row >> nth=0") if await pg.locator(".ct-card .tk-row").count() else None
            await nav(pg, "work")
        await step("Customers: search, card with tickets, new customer from Zammad appears live; Zammad users", contacts())

        async def zenith_phone():
            await pg.wait_for_selector(".phone-btn.p-registered", timeout=6000)
            await pg.wait_for_selector(".phone-btn.c-idle", timeout=30000)  # calls of earlier steps stopped ringing
            if await pg.locator(".ph-card").is_visible():
                await pg.click("[data-act=minimize]")
            await nav(pg, "contacts")
            await pg.click("[data-kind=customers]")
            await pg.wait_for_selector(".ct-row")
            await pg.click(".ct-row >> text=Ivan Sidorov")
            await pg.wait_for_selector(".ct-hero")
            await pg.click("[data-act=dial-phone]")  # click-to-call from the customer card
            # v3.7: the phone stays minimized, the call strip under the top bar shows the call
            await pg.wait_for_selector(".ph-strip.cs-active >> text=Ivan Sidorov", timeout=6000)
            expect(not await pg.locator(".ph-card").is_visible(), "the phone window must stay minimized during a call")
            await pg.wait_for_selector(".phone-btn.c-active", timeout=3000)
            await pg.click("[data-act=strip-hold]")
            await pg.wait_for_selector(".ph-strip.cs-held", timeout=3000)
            await pg.click("[data-act=strip-hold]")
            await pg.wait_for_selector(".ph-strip.cs-active", timeout=3000)
            await pg.click(".ph-strip .ph-stext")  # click the strip → the phone opens
            await pg.wait_for_selector(".ph-card.ph-active", timeout=3000)
            await pg.wait_for_selector(".ph-who >> text=Ivan Sidorov", timeout=4000)
            await pg.click("[data-act=hold]")
            await pg.wait_for_selector(".ph-line.l-held", timeout=3000)
            await pg.click("[data-act=hold]")
            await pg.click("[data-act=call]")  # End
            await pg.wait_for_selector(".ph-card.ph-idle", timeout=4000)
            expect(await pg.locator(".ph-strip").count() == 0, "call strip must disappear after the call")
            await pg.click("[data-tab=logs]")
            await pg.wait_for_selector(".ph-logrow >> text=Ivan Sidorov", timeout=4000)  # in the call log
            await pg.click("[data-tab=phone]")
            # hide / show the volume sliders and AC · AA · CONF · REC · VM
            await pg.click("[data-act=toggle-ctl]")
            expect(await pg.locator(".ph-card .ph-flags").count() == 0 and await pg.locator(".ph-card .ph-vol").count() == 0, "controls not hidden")
            await pg.click("[data-act=toggle-ctl]")
            await pg.wait_for_selector(".ph-card .ph-flags")
            # resize from the corner
            w0 = (await pg.locator(".ph-card").bounding_box())["width"]
            r = await pg.locator(".ph-resize").bounding_box()
            await pg.mouse.move(r["x"] + 8, r["y"] + 8); await pg.mouse.down()
            await pg.mouse.move(r["x"] - 40, r["y"] - 40, steps=4); await pg.mouse.up()
            w1 = (await pg.locator(".ph-card").bounding_box())["width"]
            expect(w1 < w0 - 10, f"resize from the corner did not work: {w0} -> {w1}")
            await pg.click("[data-act=minimize]")
            expect(await pg.locator(".ph-card:visible").count() == 0, "phone did not minimize")
            # incoming call: the strip rings (Answer / Decline) without covering the page
            http("POST", "/demo/phone/ring?ext=101&number=%2B37491123456")
            await pg.wait_for_selector(".ph-strip.cs-ringing >> text=Aram Grigoryan", timeout=5000)  # caller recognised
            await pg.click("[data-act=strip-answer]")
            await pg.wait_for_selector(".ph-strip.cs-active", timeout=4000)
            await pg.click("[data-act=strip-keypad]")
            await pg.click("[data-skey='7']")
            await pg.wait_for_selector(".ph-sdtmf >> text=7", timeout=2000)
            await pg.click("[data-act=strip-hangup]")
            await pg.wait_for_selector(".ph-strip", state="detached", timeout=4000)
            # the top-bar dialer: search by name and call
            await pg.fill("[data-tb]", "Maria")
            await pg.wait_for_selector(".ph-tbdrop .ph-res >> text=Maria Kuznetsova", timeout=4000)
            await pg.press("[data-tb]", "Enter")
            await pg.wait_for_selector(".ph-strip >> text=Maria Kuznetsova", timeout=5000)
            await pg.click("[data-act=strip-hangup]")
            await pg.wait_for_selector(".ph-strip", state="detached", timeout=4000)
            # Do not disturb: the operator is paused and the phone rejects calls
            await pg.click("[data-act=dnd]")
            await pg.wait_for_selector(".ph-dndbtn.on", timeout=3000)
            await pg.wait_for_selector(".phone-btn.p-dnd", timeout=3000)
            st = http("GET", "/api/agents/me/state", token=await pg.evaluate("localStorage.getItem('aws_token')"))
            expect(st.get("dnd") is True and st.get("computed_state") == "break", f"DND not on the server: {st}")
            http("POST", "/demo/phone/ring?ext=101&number=%2B37491123456")
            await pg.wait_for_timeout(1500)
            expect(await pg.locator(".ph-strip.cs-ringing").count() == 0, "DND must reject the call")
            await pg.click("[data-act=dnd]")
            await pg.wait_for_selector(".ph-dndbtn:not(.on)", timeout=3000)
            await pg.wait_for_selector(".phone-btn.p-registered", timeout=3000)
            await nav(pg, "work")
        await step("Zenith Phone: click-to-call shows the call strip, hold, open, End, log, hide controls, resize; incoming call in the strip; top-bar dialer; DND", zenith_phone())

        async def phone_settings():
            await pg.click(".settings-btn")
            await pg.wait_for_selector("[data-phone-settings]", timeout=4000)
            await pg.click("[data-layout=docked]")
            await pg.click("[data-act=phone]")
            await pg.wait_for_selector(".ph-card.lay-docked", timeout=3000)
            expect(await pg.evaluate("document.documentElement.classList.contains('ph-docked')"), "side panel must move the page aside")
            box = await pg.locator(".ph-card").bounding_box()
            vw = await pg.evaluate("innerWidth")
            expect(abs(box["x"] + box["width"] - vw) < 2 and box["y"] < 2, f"side panel not docked: {box}")
            await pg.click("[data-layout=compact]")
            await pg.wait_for_selector(".ph-card.lay-compact", timeout=3000)
            expect(await pg.locator(".ph-card .ph-pad").count() == 0 and await pg.locator(".ph-card .ph-flags").count() == 0, "compact: keypad and controls on demand")
            expect(not await pg.evaluate("document.documentElement.classList.contains('ph-docked')"), "page still moved aside")
            await pg.click("[data-act=toggle-pad]")
            await pg.wait_for_selector(".ph-card .ph-pad", timeout=2000)
            await pg.click("[data-min=button]")
            await pg.wait_for_selector("[data-tb]", state="detached", timeout=2000)
            await pg.click("[data-min=bar]")
            await pg.wait_for_selector("[data-tb]", timeout=2000)
            await pg.click("[data-layout=classic]")
            await pg.wait_for_selector(".ph-card.lay-classic .ph-flags", timeout=2000)
            await pg.click("[data-act=minimize]")
            await nav(pg, "work")
        await step("Phone settings: classic / compact / side panel, top-bar dialer on/off", phone_settings())

        async def telegram_inbox():
            # the company bot (one for the whole organisation): the seeded chats are already there, mirrored to Zammad
            await nav(pg, "telegram")
            await pg.wait_for_selector(".ib[data-channel=telegram] .ib-item", timeout=6000)
            expect(await pg.locator(".ib-item:has-text('Maria Kuznetsova')").count() == 1, "Telegram chat of Maria missing")
            expect(await pg.locator(".ib-item .ib-badge.whatsapp").count() == 0, "WhatsApp chat shown under Telegram")
            # a new message comes in live (real time: long polling of the bot) with a photo
            http("POST", "/demo/telegram/message?name=Lilit&text=" + urllib.request.quote("Where is my parcel?") + "&chat_id=777001&username=lilit_s&photo=true")
            await pg.wait_for_selector(".ib-item:has-text('Lilit')", timeout=8000)
            await pg.wait_for_function("document.querySelector('[data-nav=telegram] .nav-badge')", timeout=6000)
            await pg.click(".ib-item:has-text('Lilit')")
            await pg.wait_for_selector(".ib-b.in .ib-text:has-text('Where is my parcel?')", timeout=5000)
            await pg.wait_for_selector(".ib-b.in img.ib-img", timeout=8000)  # the photo was downloaded from Telegram and shown
            await pg.wait_for_selector(".ib-tht small:has-text('#')", timeout=8000)  # a Zammad ticket was opened for the chat
            # take it and answer with a quick reply; it reaches Telegram (simulator) and gets ✓✓ when delivered
            await pg.click("[data-act=in-take]")
            await pg.wait_for_selector("[data-act=in-take]", state="detached", timeout=4000)
            await pg.click(".ib-quick button >> nth=0")
            expect("Lilit" in await pg.input_value("textarea[name=ib-text]"), "quick reply did not fill in the name")
            await pg.fill("textarea[name=ib-text]", "Hello Lilit! Your parcel arrives tomorrow.")
            await pg.click("[data-act=in-send]")
            await pg.wait_for_selector(".ib-b.out .ib-text:has-text('arrives tomorrow')", timeout=5000)
            await pg.wait_for_selector(".ib-b.out .ib-tick.s-sent, .ib-b.out .ib-tick.s-delivered", timeout=8000)
            sent = http("GET", "/demo/messengers/sent")["telegram"]["sent"]
            expect(any("arrives tomorrow" in (m.get("text") or "") and str(m.get("chat_id")) == "777001" for m in sent), f"not sent to Telegram: {sent[-2:]}")
            # an internal note stays inside (Zammad), never goes to the customer
            n_before = len(sent)
            await pg.click("[data-act=in-note]")
            await pg.fill("textarea[name=ib-text]", "VIP customer, check the courier")
            await pg.click("[data-act=in-send]")
            await pg.wait_for_selector(".ib-b.note .ib-text:has-text('VIP customer')", timeout=5000)
            await pg.click("[data-act=in-note]")
            await pg.wait_for_timeout(600)
            expect(len(http("GET", "/demo/messengers/sent")["telegram"]["sent"]) == n_before, "internal note was sent to the customer")
            # close the conversation (also closes the Zammad ticket) and find it under Closed
            await pg.click("[data-act=in-close]")
            await pg.wait_for_selector("[data-act=in-reopen]", timeout=5000)
            await pg.click(".ib-tabs [data-view=closed]")
            await pg.wait_for_selector(".ib-item:has-text('Lilit')", timeout=5000)
            await pg.click(".ib-tabs [data-view=open]")
        await step("Telegram (company bot): live incoming message with photo, Zammad ticket, take, quick reply, ✓ delivered, internal note, close", telegram_inbox())

        async def whatsapp_inbox():
            await nav(pg, "whatsapp")
            await pg.wait_for_selector(".ib[data-channel=whatsapp] .ib-item", timeout=6000)
            await pg.click(".ib-item:has-text('Aram Grigoryan')")
            await pg.wait_for_selector(".ib-window:not(.closed)", timeout=4000)  # 24-hour customer-service window is open
            await pg.wait_for_selector(".ib-tht small:has-text('+374')", timeout=4000)
            await pg.fill("textarea[name=ib-text]", "Hello Aram! The sofa will be delivered on Friday.")
            await pg.keyboard.press("Enter")
            await pg.wait_for_selector(".ib-b.out .ib-text:has-text('on Friday')", timeout=5000)
            await pg.wait_for_selector(".ib-b.out .ib-tick.s-delivered, .ib-b.out .ib-tick.s-read", timeout=10000)  # status webhook from Meta
            sent = http("GET", "/demo/messengers/sent")["whatsapp"]["sent"]
            expect(any("on Friday" in json.dumps(m) for m in sent), "not sent to WhatsApp Cloud API")
            # a reply from the customer arrives live (signed webhook)
            http("POST", "/demo/whatsapp/message?text=" + urllib.request.quote("Great, thank you!"))
            await pg.wait_for_selector(".ib-b.in .ib-text:has-text('Great, thank you!')", timeout=8000)
            # transfer to a colleague
            await pg.click("[data-act=in-transfer]")
            await pg.click(".ib-tr .ib-tra[data-agent='2']")
            await pg.wait_for_selector(".ib-taken", timeout=5000)
            await pg.wait_for_selector(".ib-event", timeout=5000)
            # the number is the organisation's: the operator has no personal number, the call button uses the company phone
            expect(await pg.locator("[data-act=in-call]").count() == 1, "call button missing")
        await step("WhatsApp (company number): 24-hour window, send ✓✓ via Cloud API, live reply by webhook, transfer to a colleague", whatsapp_inbox())

        async def mail_page():
            await nav(pg, "mail")
            await pg.wait_for_selector("[data-mail-login], .ml-center, .ml-folders", timeout=6000)
            if await pg.locator(".ml-center .ml-card h2").count() and not await pg.locator("[data-mail-login]").count():
                RESULTS.append(("Mail: (mail server not running in this environment — skipped)", True, ""))
                return
            # the employee types only the e-mail and password: the server was set up by the administrator
            await pg.fill("input[name=mail-email]", "anna@company.test")
            await pg.fill("input[name=mail-password]", "wrong")
            await pg.click("[data-mail-login] button.primary")
            await pg.wait_for_selector(".toast.error", timeout=8000)
            await pg.fill("input[name=mail-password]", "anna-mail-1")
            await pg.click("[data-mail-login] button.primary")
            await pg.wait_for_selector(".ml-folders [data-folder=inbox]", timeout=10000)
            await pg.wait_for_selector(".ml-item:has-text('Order 4512')", timeout=8000)
            await pg.click(".ml-item:has-text('Order 4512')")
            await pg.wait_for_selector(".ml-head h2:has-text('Order 4512')", timeout=6000)
            body = await pg.frame_locator("iframe.ml-frame").locator("body").inner_text()
            expect("invoice for order 4512" in body, f"message body not shown: {body[:200]}")
            # reply: goes out through SMTP with Anna's own login and lands in Sent
            await pg.click("[data-act=ml-reply]")
            await pg.wait_for_selector("[data-compose]", timeout=3000)
            expect("client@company.test" in await pg.input_value("input[name=ml-to]"), "reply recipient not filled in")
            expect((await pg.input_value("input[name=ml-subject]")).lower().startswith("re:"), "reply subject")
            await pg.fill("textarea[name=ml-body]", "Hello Narine, the invoice is attached.\n\n" + await pg.input_value("textarea[name=ml-body]"))
            await pg.set_input_files("[data-compose] input[type=file]", files=[{"name": "invoice-4512.txt", "mimeType": "text/plain", "buffer": b"Invoice 4512: 120 000 AMD"}])
            await pg.click("[data-act=ml-send]")
            await pg.wait_for_selector("[data-compose]", state="detached", timeout=10000)
            await pg.click(".ml-folders [data-folder=sent]")
            await pg.wait_for_selector(".ml-item:has-text('Order 4512')", timeout=8000)
            await pg.click(".ml-folders [data-folder=inbox]")
            await pg.wait_for_selector(".ml-item", timeout=6000)
            # create a Zammad ticket from the e-mail
            await pg.click(".ml-item:has-text('Meeting on Thursday')")
            await pg.wait_for_selector(".ml-head h2:has-text('Meeting')", timeout=6000)
            await pg.click("[data-act=ml-ticket]")
            await pg.wait_for_selector(".toast:not(.error)", timeout=8000)
            # a new e-mail arrives in real time (IMAP IDLE) — no reload
            import smtplib, ssl  # noqa: E401
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE  # noqa: E702
            c = smtplib.SMTP("127.0.0.1", 587, timeout=10); c.starttls(context=ctx); c.login("client@company.test", "client-mail-3")  # noqa: E702
            c.sendmail("client@company.test", ["anna@company.test"], b"From: client@company.test\r\nTo: anna@company.test\r\nSubject: Urgent: live test\r\n\r\nhi")
            c.quit()
            await nav(pg, "work")
            await pg.wait_for_function("document.querySelector('[data-nav=mail] .nav-badge')", timeout=15000)
            await nav(pg, "mail")
            await pg.wait_for_selector(".ml-item:has-text('Urgent: live test')", timeout=10000)
        await step("Mail: sign in with e-mail + password only, read, reply with attachment (SMTP → Sent), ticket from e-mail, live new mail (IMAP IDLE)", mail_page())
        await bp.close()

        if SHOTS:
            await pg.screenshot(path=f"{SHOTS}/e2e_operator.png", full_page=True)

        # ---------------------------------------------------------------- supervisor
        sp = await new_page()
        await step("Login: supervisor boss", login(sp, "boss"))

        async def sup_view():
            await nav(sp, "sup")
            await sp.wait_for_selector("table tbody tr", timeout=5000)
            txt = await sp.inner_text("table")
            expect("Anna" in txt and "Boris" in txt, "operators missing")
            expect("blocking" in txt.lower() or "блок" in txt.lower(), "anna's reason missing")
            expect(await sp.locator("table tbody tr:has-text('Anna') .lvl").count() == 1, "level not shown in supervisor table")
        await step("Supervisor sees operators with reasons", sup_view())

        async def sup_level_filter():
            await sp.click(".level-filter button[data-level=level1]")
            await sp.wait_for_timeout(300)
            rows = await sp.locator("table").first.locator("tbody tr").count()
            names = await sp.inner_text("table tbody")
            expect(rows == 1 and "Anna" in names, f"level filter shows: {names!r}")
            await sp.click(".level-filter button >> nth=0")
            await sp.wait_for_timeout(300)
            expect(await sp.locator("table").first.locator("tbody tr").count() >= 2, "'All' filter does not show everyone")
        await step("Manager panel: filter the team by level", sup_level_filter())

        async def overview_page():
            await nav(sp, "overview")
            await sp.wait_for_selector(".ov-tiles .tile", timeout=8000)
            expect(await sp.locator(".ov-tiles .tile").count() == 5, "overview tiles missing")
            offered = int((await sp.inner_text(".tile-calls .big")).strip())
            expect(offered >= 20, f"incoming calls on the overview: {offered}")
            sl = (await sp.inner_text(".gauge-val")).strip()
            expect(sl.endswith("%"), f"service level: {sl!r}")
            expect(await sp.locator(".ov-chart .bar-ans").count() >= 3, "hourly chart has no bars")
            await sp.hover(".ov-chart .hit >> nth=4")
            expect(await sp.locator(".chart-tip").count() == 1, "chart tooltip missing")
            rows = await sp.locator(".ov-table tbody tr").count()
            expect(rows >= 6, f"operators table rows: {rows}")
            davit = await sp.inner_text(".ov-table tbody tr:has-text('Davit')")
            expect("Does not pick up" in davit or "Не берёт" in davit, f"no RONA flag for the avoider: {davit!r}")
            best = await sp.inner_text(".ov-leaders .lead >> nth=0")
            expect(any(n in best for n in ("Mariam", "Narek", "Sona")), f"leader: {best!r}")
            expect(await sp.locator(".ov-unret .unret").count() >= 1, "missed callers list empty")
        await step("Manager overview: calls, service level, chart, ranking, flags", overview_page())

        async def overview_filters():
            await sp.click(".ov-levels button[data-level=level3]")
            await sp.wait_for_timeout(300)
            names = await sp.inner_text(".ov-table tbody")
            expect("Mariam" in names and "Davit" not in names, f"level filter on overview: {names[:120]!r}")
            await sp.click(".ov-levels button >> nth=0")
            await sp.select_option(".ov-agents select[name=ov-sort]", "rona")
            await sp.wait_for_timeout(300)
            first = await sp.inner_text(".ov-table tbody tr >> nth=0")
            expect("Davit" in first, f"sort by 'not picked up' should put Davit first: {first[:60]!r}")
            await sp.click(".ov-period button[data-period='7d']")
            await sp.wait_for_timeout(1200)
            expect(await sp.locator(".ov-chart .bar-ans").count() >= 1, "7-day chart empty")
            await sp.click(".ov-period button[data-period=today]")
            await sp.wait_for_timeout(800)
            await nav(sp, "sup")
        await step("Overview: level filter, sorting, period switch", overview_filters())

        async def live_push():
            expect(await sp.locator(".live-pill.lv-ok").count() == 1, "live indicator is not green")
            await nav(sp, "overview")
            await sp.wait_for_selector(".tile-live .big")
            await sp.wait_for_timeout(600)
            before = int((await sp.inner_text(".tile-live .big")).strip())
            t0 = time.monotonic()
            link = http("POST", "/demo/call?ext=102&number=89995554433")["linkedid"]   # a call starts ringing
            now = before
            while time.monotonic() - t0 < 3 and now != before + 1:
                await sp.wait_for_timeout(50)
                now = int((await sp.inner_text(".tile-live .big")).strip())
            took = time.monotonic() - t0
            expect(now == before + 1, f"waiting calls did not update live ({before} -> {now})")
            expect(took < 2.0, f"live update took {took:.2f} s")            # polling would take up to 30 s
            http("POST", f"/demo/answer?linkedid={link}&ext=102")             # answered -> gone from the queue
            t0 = time.monotonic()
            while time.monotonic() - t0 < 3 and now != before:
                await sp.wait_for_timeout(50)
                now = int((await sp.inner_text(".tile-live .big")).strip())
            expect(now == before, f"answered call still waiting ({now})")
            await nav(sp, "sup")
        await step("Live mode: a new call appears on the manager's overview within 2 s, no reload", live_push())

        async def idle_pause():
            # boris opens Zenith Desk and walks away; a short test limit (8 s) instead of the real 60 minutes
            bp = await new_page()
            await login(bp, "boris")
            await bp.evaluate("localStorage.setItem('agentix_idle_test_ms', '8000'); localStorage.removeItem('agentix_last_activity')")
            await bp.reload()
            await bp.wait_for_selector(".topbar .status")
            await bp.wait_for_selector(".idle-warn", timeout=12000)                 # warning before the pause
            await bp.wait_for_selector(".idle-overlay .idle-back", timeout=12000)   # paused
            expect(await bp.locator(".layout.frozen").count() == 1, "interface is not dimmed / frozen")
            try:   # the screen freezes at once; the server's confirmation (offline) follows within a moment
                await bp.wait_for_selector(".topbar .status.st-offline", state="attached", timeout=5000)
            except Exception:  # noqa: BLE001
                expect(False, "operator not offline after the pause")
            expect(http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["paused"], "calls still go to the absent operator")
            row = sp.locator("table tbody tr:has-text('Boris')").first
            await row.locator(".idle-tag").wait_for(timeout=4000)                    # manager sees it live
            expect(await row.locator(".status.st-offline").count() == 1, "manager does not see Boris offline")
            await bp.evaluate("localStorage.removeItem('agentix_idle_test_ms')")
            await bp.click(".idle-back")
            await bp.wait_for_selector(".idle-overlay", state="detached", timeout=4000)
            await bp.wait_for_timeout(600)
            expect(await bp.locator(".layout.frozen").count() == 0, "still frozen after 'I'm back'")
            expect(not http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["paused"], "calls did not resume")
            await sp.wait_for_timeout(800)
            expect(await sp.locator("table tbody tr:has-text('Boris') .idle-tag").count() == 0, "manager still sees Boris away")
            await bp.close()
        await step("Inactivity: warning, screen dims and freezes, calls stop, manager sees 'Away'; 'I'm back' resumes", idle_pause())

        async def messenger():
            # the manager finds Anna, writes to her; Anna gets it live, answers; ✓✓ and history are kept
            await nav(sp, "chat")
            await sp.wait_for_selector(".chat-item")
            await sp.fill("input[name=chat-search]", "anna")
            try:
                await sp.wait_for_function("document.querySelectorAll('.chat-item').length === 1", timeout=3000)
            except Exception:  # noqa: BLE001
                pass
            items = await sp.locator(".chat-item").count()
            names = await sp.evaluate("[...document.querySelectorAll('.chat-item .ci-name')].map(e => e.textContent)")
            expect(items == 1 and "Anna" in names[0], f"search did not find Anna: {names}")
            await sp.click(".chat-item")
            await sp.wait_for_selector(".chat-compose textarea")
            before = await pg.evaluate("+(document.querySelector('.nav-badge') || {textContent: '0'}).textContent")
            await sp.fill(".chat-compose textarea", "E2E hello Anna\nsecond line")
            await sp.keyboard.press("Enter")
            await sp.wait_for_selector(".bubble-row.mine:has-text('E2E hello Anna')")
            expect(await sp.locator(".chat-compose textarea").input_value() == "", "composer not cleared")
            # Anna (on her workplace) gets an unread badge and a clickable toast, live
            await pg.wait_for_selector(".toast.chat", timeout=4000)
            after = await pg.evaluate("+(document.querySelector('.nav-badge') || {textContent: '0'}).textContent")
            expect(after == before + 1, f"unread badge did not go up live ({before} -> {after})")
            await pg.click(".toast.chat")                       # opens the conversation
            await pg.wait_for_selector(".bubble-row:not(.mine):has-text('E2E hello Anna')", timeout=4000)
            expect("second line" in await pg.inner_text(".bubble-row:not(.mine):has-text('E2E hello Anna')"), "multi-line text lost")
            await sp.wait_for_selector(".bubble-row.mine:has-text('E2E hello Anna') .tick.read", timeout=4000)   # ✓✓ read
            # typing indicator + reply
            await pg.type(".chat-compose textarea", "Hi! On my way", delay=20)
            await sp.wait_for_selector(".ch-text small.on", timeout=4000)
            await pg.click(".send-btn")
            await sp.wait_for_selector(".bubble-row:not(.mine):has-text('Hi! On my way')", timeout=4000)
            # user info panel
            await sp.click(".ch-person")
            await sp.wait_for_selector(".chat-info .ci-row")
            info = await sp.inner_text(".chat-info")
            expect("101" in info and "Anna" in info, f"profile card: {info[:120]!r}")
            await sp.click(".chat-info .ch-btn")
            # history is kept: reload and it is still there
            await sp.reload()
            await sp.wait_for_selector(".sidebar")
            await nav(sp, "chat")
            await sp.click(".chat-item:has-text('Anna')")
            await sp.wait_for_selector(".bubble:has-text('Hi! On my way')", timeout=4000)
            await nav(pg, "work")
            await nav(sp, "sup")
        await step("Messenger: search, send, live delivery + badge + toast, ✓✓ read, typing, profile, history kept", messenger())

        async def messenger_plus():
            await nav(sp, "chat")
            await sp.click(".chat-item:has-text('Anna')")
            await sp.wait_for_selector(".bubble")
            # the list shows only conversations; Boris writes -> his chat jumps to the top with the new time, live
            boris_token = http("POST", "/api/auth/login", {"username": "boris", "password": "pw"})["token"]
            boss_id = await sp.evaluate("JSON.parse(atob(localStorage.getItem('aws_token').split('.')[1])).sub")
            http("POST", f"/api/chat/{boss_id}/messages", {"body": "E2E ping from Boris"}, token=boris_token)
            await sp.wait_for_function("document.querySelector('.chat-item .ci-name') && document.querySelector('.chat-item .ci-name').textContent.includes('Boris')", timeout=4000)
            expect("E2E ping from Boris" in await sp.inner_text(".chat-item >> nth=0"), "preview of the newest chat not updated")
            # reactions: Anna reacts to the manager's message from her side, the manager sees it live
            await nav(pg, "chat")
            await pg.click(".chat-item:has-text('Olga'), .chat-item:has-text('Руковод'), .chat-item >> nth=0")
            await pg.wait_for_selector(".bubble-row:not(.mine) .bubble")
            await pg.locator(".bubble-row:not(.mine) .bubble").last.click(button="right")
            await pg.click(".mm-react[data-emoji='👍']")
            await sp.wait_for_selector(".bubble-row.mine .react-chip:has-text('👍')", timeout=4000)
            # edit: the manager fixes his last message, Anna sees the new text live with "edited"
            await sp.locator(".bubble-row.mine .bubble").last.click(button="right")
            await sp.click(".mm-edit")
            await sp.fill(".chat-compose textarea", "E2E edited text")
            await sp.keyboard.press("Enter")
            await pg.wait_for_selector(".bubble:has-text('E2E edited text') .b-edited", timeout=4000)
            # delete for everyone: gone on both screens
            await sp.fill(".chat-compose textarea", "E2E to be deleted")
            await sp.keyboard.press("Enter")
            await pg.wait_for_selector(".bubble:has-text('E2E to be deleted')", timeout=4000)
            await sp.locator(".bubble:has-text('E2E to be deleted')").click(button="right")
            await sp.click(".mm-delete")
            expect(await sp.is_checked(".chat-dialog input[name=del-all]"), "'also delete for Anna' should be on for own messages")
            await sp.click(".cd-confirm")
            await sp.wait_for_selector(".bubble:has-text('E2E to be deleted')", state="detached", timeout=3000)
            await pg.wait_for_selector(".bubble:has-text('E2E to be deleted')", state="detached", timeout=4000)
            # background notifications: the service worker is installed and the setting is offered
            reg = await pg.evaluate("navigator.serviceWorker.getRegistration('/').then(r => !!r)")
            expect(reg, "service worker for background notifications not registered")
            await pg.click(".settings-btn")
            await pg.wait_for_selector(".push-row")
            await nav(pg, "work")
            await nav(sp, "sup")
        await step("Messenger v3.1: live re-order, reactions, edit, delete for everyone, background notifications", messenger_plus())

        async def sup_reconcile():
            await sp.click("table tbody tr:has-text('Anna') button:has-text('Reconcile'), table tbody tr:has-text('Anna') button:has-text('Сверка')")
            await sp.wait_for_selector(".toast", timeout=4000)
        await step("Supervisor: reconcile", sup_reconcile())

        async def sup_override():
            await sp.click("table tbody tr:has-text('Anna') button.warn")
            await sp.wait_for_selector(".modal")
            await sp.check(".modal input[type=checkbox]")
            await sp.fill(".modal textarea", "E2E peak load")
            await sp.click(".modal .footer button.warn")
            await sp.wait_for_timeout(900)
            expect(not pbx(), "override ready must unpause despite blocking")
        await step("Supervisor: override with reason", sup_override())

        async def sup_cancel():
            sp.once("dialog", lambda d: asyncio.ensure_future(d.accept("E2E cancel")))
            await sp.click("table tbody tr:has-text('Anna') a.empty")
            await sp.wait_for_timeout(1000)
            tasks = http("GET", "/api/agents/me/tasks", token=await pg.evaluate("localStorage.getItem('aws_token')"))
            expect(len(tasks["blocking"]) == 0, "session not cancelled")
        await step("Supervisor: cancel an operator's session", sup_cancel())

        async def operator_notified():
            await pg.wait_for_timeout(1500)
            await pg.reload()
            await pg.wait_for_selector(".bell")
            await pg.wait_for_timeout(800)
            expect(await pg.locator(".bell .badge").count() == 1, "no unread badge on the bell")
            await pg.click(".bell")
            await pg.wait_for_selector(".ntf-pop .ntf-item", timeout=4000)
            expect("E2E cancel" in await pg.inner_text(".ntf-pop"), "cancel reason not in notifications")
            await pg.wait_for_timeout(500)
            expect(await pg.locator(".bell .badge").count() == 0, "badge not cleared after opening")
            await pg.click("main", position={"x": 12, "y": 12})  # outside the popup closes it
            await pg.wait_for_selector(".ntf-pop", state="detached", timeout=3000)
        await step("Operator gets a notification (bell + panel) when supervisor intervenes", operator_notified())

        async def sup_kpis_and_assign():
            expect(await sp.locator(".sup-kpis .kpi").count() == 6, "supervisor summary cards missing")
            await sp.click(".assign-btn")
            await sp.wait_for_selector(".modal")
            await sp.fill(".modal input[name=ticket]", "31102")  # still unassigned/new
            boris = await sp.evaluate("[...document.querySelectorAll('.modal select[name=agent] option')].find(o => o.textContent.includes('Boris')).value")
            await sp.select_option(".modal select[name=agent]", boris)
            await sp.select_option(".modal select[name=mode]", "background")
            await sp.click(".modal .footer button.primary")
            await sp.wait_for_timeout(1200)
            expect(await sp.locator(".modal").count() == 0, "assign modal still open")
            txt = await sp.inner_text("table")
            expect("#31102" in txt, "assigned ticket not shown in operator tasks")
        await step("Supervisor: summary cards and assign a ticket by number", sup_kpis_and_assign())

        async def sup_audit_report():
            txt = await sp.inner_text("main")
            expect("supervisor_override" in txt, "override not in audit log")
            expect(await sp.locator(".grid table tbody tr").count() >= 3, "report rows missing")
        await step("Supervisor: audit log and report", sup_audit_report())

        if SHOTS:
            await sp.screenshot(path=f"{SHOTS}/e2e_supervisor.png", full_page=True)

        # ---------------------------------------------------------------- second operator, mobile, logout
        mob = await new_page(390, 844)
        await step("Login: operator boris on mobile", login(mob, "boris"))

        async def mobile_layout():
            width = await mob.evaluate("document.documentElement.scrollWidth")
            expect(width <= 390, f"horizontal scroll on mobile: {width}px")
        await step("Mobile layout has no horizontal scroll", mobile_layout())

        async def logout():
            await mob.click(".burger")
            await mob.click(".side-foot .logout")
            await mob.wait_for_selector("input[autocomplete=username]", timeout=5000)
            expect(http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["paused"], "logout must pause (offline)")
        await step("Sign out sets the operator offline (paused)", logout())

        # ---------------------------------------------------------------- administrator panel
        ad = await new_page()
        await step("Login: administrator (no operator controls)", login(ad, "admin", "admin", wait=".sidebar"))

        async def admin_nav_only():
            expect(await ad.locator(".topbar button.go, .topbar .status, .topbar .bell").count() == 0, "admin must not see Ready/Break")
            expect(await ad.locator(".side-nav button").count() == 9, "admin menu must have 9 items (customers, messages, manager panel, overview + 5 admin pages)")
            expect(await ad.locator("table.users tbody tr").count() == 8, "users table not shown")  # 4 + 4 demo-history operators
        await step("Admin opens on the Users page with the admin menu", admin_nav_only())

        async def create_user():
            await ad.click(".toolbar button.primary")
            await ad.wait_for_selector(".modal.wide")
            f = lambda n: f".modal.wide input[name={n}]"  # noqa: E731
            await ad.fill(f("first_name"), "Karen")
            await ad.fill(f("last_name"), "Petrosyan")
            await ad.fill(f("username"), "karen")
            await ad.fill(f("position"), "Night shift operator")
            await ad.select_option(".modal.wide select[name=level]", "level2")
            await ad.fill(f("password"), "karen-pass-1")
            await ad.fill(f("zammad_search"), "karen")
            await ad.click(".modal.wide button.zsearch")
            await ad.wait_for_selector(".zitem", timeout=4000)
            await ad.click(".zitem >> nth=0")
            await ad.fill(f("extension"), "103")
            await ad.click(".modal.wide button.fill-iface")
            expect(await ad.input_value(f("asterisk_interface")) == "Local/103@from-queue/n", "interface not filled")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(900)
            expect(await ad.locator(".modal").count() == 0, "user modal still open")
            row = await ad.inner_text("table.users tbody tr:has-text('Karen')")
            expect("karen" in row and "103" in row and "#12" in row, f"row: {row!r}")
        await step("Admin creates a user with Zammad link and extension", create_user())

        async def new_user_works():
            kp = await new_page()
            await login(kp, "karen", "karen-pass-1")
            expect("Karen Petrosyan" in await kp.inner_text(".topbar .me"), "name not in the top bar")
            expect("Night shift operator" in await kp.inner_text(".topbar .me"), "position not in the top bar")
            lvl = await kp.inner_text(".topbar .me-level")
            expect("2" in lvl, f"level not shown under the name: {lvl!r}")
            expect(await kp.locator(".side-nav button").count() == 7, "operator must see the workplace, tickets, customers, messages, mail, WhatsApp and Telegram")
            expect(not http("GET", "/demo/pbx")["400"]["Local/103@from-queue/n"]["paused"], "karen must receive calls")
            await kp.close()
        await step("New user signs in and gets the workplace (no setup needed)", new_user_works())

        async def reset_password_forced_change():
            await ad.click("table.users tbody tr:has-text('Karen') button >> nth=1")
            await ad.wait_for_selector(".modal")
            pw = ad.locator(".modal input").nth(0)
            await pw.fill("temp-pass-99")
            await ad.check(".modal input[type=checkbox]")
            await ad.click(".modal .footer button.primary")
            await ad.wait_for_selector(".modal input[readonly]")
            expect("temp-pass-99" in await ad.input_value(".modal input[readonly]"), "password not shown to admin")
            await ad.click(".modal .footer button.primary")
            kp = await new_page()
            await login(kp, "karen", "temp-pass-99", wait=".modal form")
            fields = kp.locator(".modal form input")
            await fields.nth(0).fill("temp-pass-99")
            await fields.nth(1).fill("karen-own-pass")
            await fields.nth(2).fill("karen-own-pass")
            await kp.click(".modal form button.primary")
            await kp.wait_for_selector(".topbar .status", timeout=6000)
            await kp.close()
        await step("Password reset forces the user to set an own password", reset_password_forced_change())

        async def disable_user():
            await ad.click("table.users tbody tr:has-text('Karen') button >> nth=0")
            await ad.wait_for_selector(".modal.wide")
            await ad.uncheck(".modal.wide input[name=active]")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(900)
            expect("disabled" in (await ad.inner_text("table.users tbody tr:has-text('Karen')")).lower()
                   or "отключ" in (await ad.inner_text("table.users tbody tr:has-text('Karen')")).lower(), "not disabled")
            kp = await new_page()
            await kp.goto(BASE + "/")
            await kp.fill("input[autocomplete=username]", "karen")
            await kp.fill("input[type=password]", "karen-own-pass")
            await kp.click("form button.primary")
            await kp.wait_for_selector("form p", timeout=5000)
            await kp.close()
        await step("Disabled user cannot sign in", disable_user())

        async def manager_level_gives_team_rights():
            await ad.click(".toolbar button.primary")
            await ad.wait_for_selector(".modal.wide")
            f = lambda n: f".modal.wide input[name={n}]"  # noqa: E731
            await ad.fill(f("first_name"), "Lilit")
            await ad.fill(f("last_name"), "Hakobyan")
            await ad.fill(f("username"), "lilit")
            await ad.fill(f("position"), "Shift manager")
            await ad.select_option(".modal.wide select[name=level]", "manager")
            access = await ad.inner_text(".modal.wide .access")
            expect("Manager" in access or "руковод" in access, f"access text: {access!r}")
            await ad.fill(f("password"), "lilit-pass-1")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(900)
            lp = await new_page()
            await login(lp, "lilit", "lilit-pass-1")
            expect(await lp.locator(".side-nav button").count() == 9, "manager must see workplace + tickets + customers + messages + mail + WhatsApp + Telegram + manager panel + overview")
            await nav(lp, "sup")
            await lp.wait_for_selector("table tbody tr")
            expect("Anna" in await lp.inner_text("table"), "manager does not see the team")
            await lp.close()
        await step("Level 'Manager' gives the manager panel automatically", manager_level_gives_team_rights())

        async def integrations():
            await nav(ad, "integrations")
            expect(await ad.locator(".itabs [data-itab]").count() == 6, "integration tabs missing")
            await ad.click("[data-itab=zammad]")
            expect("/api/integrations/zammad/webhook" in await ad.input_value("[data-group=zammad] .webhook input"), "webhook url missing")
            await ad.click("[data-test=zammad]")
            await ad.wait_for_selector("[data-group=zammad] .banner.ok", timeout=6000)
            await ad.click("[data-itab=telephony]")
            expect(await ad.locator("[data-group=telephony], [data-group=phone]").count() == 2, "telephony + Zenith Phone groups")
            await ad.click("[data-test=telephony]")
            await ad.wait_for_selector("[data-group=telephony] .banner", timeout=6000)
            expect(await ad.locator("[data-group=telephony] .banner.ok").count() == 1, "AMI test not ok")
            # Telegram: the organisation's bot; the test asks Telegram who the bot is (getMe)
            await ad.click("[data-itab=telegram]")
            await ad.wait_for_selector("[data-group=telegram]", timeout=3000)
            expect(await ad.locator("[data-group=messengers]").count() == 1, "common messenger settings (Zammad mirror, quick replies) missing")
            await ad.click("[data-test=telegram]")
            await ad.wait_for_selector("[data-group=telegram] .banner.ok", timeout=8000)
            expect("@" in await ad.inner_text("[data-group=telegram] .banner.ok"), "bot name not shown")
            # WhatsApp: one company number; Callback URL + verify token for Meta
            await ad.click("[data-itab=whatsapp]")
            expect("/api/integrations/whatsapp/webhook" in await ad.inner_html("[data-group=whatsapp] .webhook"), "WhatsApp callback URL missing")
            expect(len(await ad.input_value("input[name=wa-verify]")) >= 16, "verify token missing")
            await ad.click("[data-test=whatsapp]")
            await ad.wait_for_selector("[data-group=whatsapp] .banner.ok", timeout=8000)
            expect("555 000" in await ad.inner_text("[data-group=whatsapp] .banner.ok"), "company number not shown")
            # Mail: the administrator sets IMAP/POP3/SMTP once; the test logs in with a real mailbox
            await ad.click("[data-itab=mail]")
            expect(await ad.locator("[data-group=mail] .setting").count() >= 10, "mail server settings missing")
            if http("GET", "/api/mail/account", token=await ad.evaluate("localStorage.getItem('aws_token')")).get("enabled"):
                await ad.fill("input[name=mail-test-email]", "boris@company.test")
                await ad.fill("input[name=mail-test-password]", "boris-mail-2")
                await ad.click("[data-test=mail]")
                await ad.wait_for_selector("[data-group=mail] .banner.ok", timeout=12000)
            # Sync: every system with real time + fallback check
            await ad.click("[data-itab=sync]")
            await ad.wait_for_selector("table.sync tr[data-sync=telegram]", timeout=5000)
            expect(await ad.locator("table.sync tbody tr").count() == 5, "sync table must list Zammad, Asterisk, Telegram, WhatsApp, Mail")
            await ad.click("[data-poll=telegram]")
            await ad.wait_for_function("document.querySelector('tr[data-sync=telegram] td:nth-child(4)').textContent.includes('ms')", timeout=8000)
            expect(await ad.locator("tr[data-sync=telegram] .sdot.ok").count() == 1, "Telegram not OK in the sync table")
        await step("Integrations: tabs; Zammad, AMI, Telegram bot, WhatsApp number and mail server tests; sync panel with a manual check", integrations())

        async def save_setting():
            await ad.click("[data-itab=telephony]")
            box = ad.locator(".setting:has-text('Wrap-up'), .setting:has-text('Постобработка')").locator("input")
            await box.fill("20")
            await ad.wait_for_selector(".savebar.show")
            await ad.click(".savebar button.primary")
            await ad.wait_for_timeout(900)
            expect(await ad.locator(".savebar.show").count() == 0, "save bar still visible")
            await ad.reload()
            await ad.wait_for_selector(".sidebar")
            await nav(ad, "integrations")
            await ad.click("[data-itab=telephony]")
            expect(await box.input_value() == "20", "setting not persisted")
            await box.fill("0")
            await ad.click(".savebar button.primary")
            await ad.wait_for_timeout(700)
        await step("Integrations: change a setting, it is saved and applied", save_setting())

        async def settings_page():
            await nav(ad, "settings")
            expect(await ad.locator(".settings-group").count() == 4, "settings groups missing (tickets, statistics, general, privacy)")
            expect(await ad.locator(".setting select").count() >= 2, "choice settings missing")
        await step("Settings page", settings_page())

        async def ticket_types():
            await nav(ad, "types")
            await ad.click(".admin h2 button.primary")
            await ad.wait_for_selector(".modal.wide")
            row = ad.locator(".modal.wide .row input")
            await row.nth(0).fill("Complaint")
            await row.nth(1).fill("complaint")
            await ad.click(".modal.wide button:has-text('+')")
            await ad.locator(".field-row input").nth(0).fill("severity")
            await ad.locator(".field-row input").nth(1).fill("Severity")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(800)
            expect("Complaint" in await ad.inner_text(".admin"), "type not created")
            ad.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await ad.click(".item:has-text('Complaint') button.danger")
            await ad.wait_for_timeout(800)
            expect("Complaint" not in await ad.inner_text(".admin"), "type not deleted")
        await step("Ticket types: create and delete", ticket_types())

        async def system_status():
            await nav(ad, "system")
            await ad.wait_for_selector(".cards .card")
            expect(await ad.locator(".card.good").count() == 2, "Zammad/AMI not shown as connected")
            expect(await ad.locator(".sys-int .sys-it").count() == 5, "integration health block missing")
        await step("System status page", system_status())

        async def operator_no_admin_api():
            r = urllib.request.Request(BASE + "/api/admin/users", headers={"Authorization": "Bearer " + await pg.evaluate("localStorage.getItem('aws_token')")})
            try:
                urllib.request.urlopen(r)
                raise AssertionError("operator could open admin API")
            except urllib.error.HTTPError as exc:
                expect(exc.code in (401, 403), f"code {exc.code}")
        await step("Operators have no access to the admin API", operator_no_admin_api())

        if SHOTS:
            await nav(ad, "sup")
            await ad.screenshot(path=f"{SHOTS}/e2e_admin.png", full_page=True)

        async def health():
            h = http("GET", "/api/health")
            expect(h["status"] == "ok" and h["database"] and h["ami_connected"], f"health: {h}")
        await step("Health endpoint", health())

        async def responsive():
            # every main screen fills the whole width and never scrolls sideways, from a small phone to a 4K monitor
            check = """() => { const vw = document.documentElement.clientWidth, m = document.querySelector('main');
                return { h: document.documentElement.scrollWidth - vw, gap: m ? Math.round(vw - m.getBoundingClientRect().right) : 0 }; }"""
            problems = []
            for w, h in ((360, 740), (768, 1024), (1280, 800), (1920, 1080), (2560, 1440)):
                rp = await new_page(w, h)
                await rp.emulate_media(reduced_motion="reduce")
                await login(rp, "boss")
                for idx, name in ((None, "workplace"), ("sup", "manager panel"), ("overview", "overview"), ("chat", "messages")):
                    if idx is not None:
                        await nav(rp, idx)
                        await rp.wait_for_timeout(900)
                    r = await rp.evaluate(check)
                    if r["h"] > 1 or r["gap"] > 2:
                        problems.append(f"{w}px {name}: sideways scroll {r['h']}px, empty right gap {r['gap']}px")
                await rp.close()
            expect(not problems, "; ".join(problems))
        await step("Responsive: 360 px phone to 2560 px monitor, full width, no sideways scrolling", responsive())

        async def no_js_errors():
            expect(not errors, "; ".join(errors[:5]))
        await step("No JavaScript errors in the browser", no_js_errors())

        await browser.close()

    failed = [r for r in RESULTS if not r[1]]
    print(f"\nE2E: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
