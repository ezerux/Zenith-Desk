# Zenith Desk — Компоненты и лицензии

Все компоненты распространяются под open-source лицензиями, которые допускают внутреннее использование.
Перед стартом сверьте версии с `requirements.txt` и при необходимости уточните лицензии в репозиториях проектов.

## Собственный код
Исходный код сервиса и интерфейса (`app/`, `migrations/`, `scripts/`, `tests/`) передаётся заказчику.
Лицензию на него определяет договор.

## Зависимости, работающие в составе сервиса
| Компонент | Назначение | Лицензия |
|---|---|---|
| Python 3.12 | среда выполнения | PSF License |
| FastAPI | веб-фреймворк / API | MIT |
| Starlette | ASGI-основа FastAPI | BSD-3-Clause |
| Uvicorn (+ uvloop, httptools, websockets, watchfiles, python-dotenv) | ASGI-сервер | BSD-3-Clause (uvloop: MIT/Apache-2.0; httptools, watchfiles: MIT; websockets, python-dotenv: BSD-3-Clause) |
| SQLAlchemy | ORM / доступ к БД | MIT |
| asyncpg | драйвер PostgreSQL | Apache-2.0 |
| Alembic | миграции БД | MIT |
| Pydantic, pydantic-settings | валидация и конфигурация | MIT |
| HTTPX | HTTP-клиент для Zammad API | BSD-3-Clause |
| PyJWT | токены сессий | MIT |
| cryptography | шифрование в базе (Fernet), резервные копии (AES-GCM), сертификаты TLS (v3.17) | Apache-2.0 / BSD-3-Clause |
| Vue 3 (vendored `app/static/vue.global.prod.js`) | интерфейс | MIT |
| Шрифты IBM Plex Sans / IBM Plex Mono (`app/static/fonts`, текст лицензии в `OFL-IBM-Plex.txt`) | интерфейс | SIL OFL 1.1 |
| Шрифт Manrope (`app/static/fonts`, текст лицензии в `OFL-Manrope.txt`) | стиль интерфейса Flow | SIL OFL 1.1 |
| Иконка «settings» из Lucide (`app/static/app.js`) | интерфейс | ISC |
| JsSIP 3.13.8 + debug, events, ms, sdp-transform (собрано в `app/static/vendor/jssip-3.13.8.min.js`, лицензия в `JSSIP-LICENSE.md`) | Zenith Phone: SIP/WebRTC в браузере | MIT |
| nh3 (привязка к Rust-библиотеке Ammonia) | очистка HTML входящих писем (v3.9) | MIT (Ammonia: MIT/Apache-2.0) |
| imaplib / poplib / smtplib (стандартная библиотека Python) | IMAP, POP3, SMTP (v3.9) | PSF License |
| PostgreSQL 16 | БД сервиса | PostgreSQL License |

## Только для разработки и тестов
| Компонент | Лицензия |
|---|---|
| pytest | MIT |
| pytest-asyncio | Apache-2.0 |
| aiosqlite | MIT |

## Внешние системы (уже установлены у заказчика, не изменяются)
| Система | Лицензия | Как используется |
|---|---|---|
| Zammad | AGPL-3.0 | только через официальный REST API и webhooks, код Zammad не изменяется и не распространяется |
| Asterisk | GPL-2.0 | только через AMI (сетевой протокол) |
| Telegram Bot API | условия Telegram | только через официальный HTTPS API бота организации |
| WhatsApp Business Cloud API (Meta) | условия Meta | только через официальный Graph API номера организации |
| Почтовый сервер организации (Dovecot, Postfix, Exchange и т.п.) | лицензия сервера | только по стандартным протоколам IMAP/POP3/SMTP |
| FreePBX (базовые модули) | GPL-3.0 / AGPL-3.0 (в зависимости от модуля) | платные коммерческие модули не нужны и не используются |

Сервис взаимодействует с Zammad и Asterisk по сети как отдельная программа и не встраивает их код.
