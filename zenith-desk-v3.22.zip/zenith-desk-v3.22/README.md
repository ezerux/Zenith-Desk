<div align="center">

<img src="app/static/logo.svg" width="72" alt="Zenith Desk logo">

# Zenith Desk

**One workplace for contact-center operators — calls, tickets, Telegram, WhatsApp and e-mail in a single window.**
Built on top of **Zammad** and **FreePBX / Asterisk**, open-source only, no paid CRM or VoIP modules.

**English** · [Русский](README.ru.md)

![version](https://img.shields.io/badge/version-3.20.1-1fb87a)
![python](https://img.shields.io/badge/python-3.12-3d7fe0)
![fastapi](https://img.shields.io/badge/FastAPI-async-0f141c)
![postgres](https://img.shields.io/badge/PostgreSQL-16-3d7fe0)
![checks](https://img.shields.io/badge/release%20check-250%2B%20checks%20passing-1fb87a)
![languages](https://img.shields.io/badge/UI-English%20%7C%20Russian-5d6675)

<img src="docs/screenshots/manager-overview.jpg" alt="Zenith Desk — manager overview" width="100%">

</div>

---

## Contents

- [Why Zenith Desk](#why-zenith-desk)
- [Features](#features)
- [Screenshots](#screenshots)
- [Architecture](#architecture)
- [Quick start (demo)](#quick-start-demo)
- [Production install](#production-install)
- [Integrations](#integrations)
- [Reliability and security](#reliability-and-security)
- [Testing](#testing)
- [Project layout](#project-layout)
- [Documentation](#documentation)
- [Version history](#version-history)

---

## Why Zenith Desk

Operators usually juggle a desk phone, Zammad, messengers and a mail client — and Asterisk keeps sending them calls
while they are busy with a ticket. Zenith Desk puts everything in one window and lets the **server decide who can
take calls**:

| | |
|---|---|
| **Start** a ticket (blocking) | the operator is **paused in every managed Asterisk queue** — only after Asterisk confirms it |
| **Background task** | the ticket stays with the operator, calls keep coming |
| **Complete** | the ticket gets its final state in Zammad, calls come back — unless a break or another blocking task remains |
| **Ready** | refused while a blocking task exists; a manual break is never removed by closing a ticket |

Operator states: `READY` · `BUSY_TASK` · `BREAK` · `OFFLINE` · `WRAP_UP`. Priority: offline/break › blocking tasks › ready.
Ticket state and operator state are separate (`work_mode = blocking | background`).

---

## Features

### Operator
- **Dashboard** — today's numbers, active and background tasks, new requests from every channel with *Start* /
  *Background task*, tickets assigned to me, notifications, recent calls. Blocks can be rearranged, resized and hidden;
  the layout follows the user to any computer.
- **Incoming call** — the caller is found in Zammad by the normalized number, the customer card opens with recent
  tickets; unknown caller → *Create customer*. *Create ticket from call* attaches number, time, extension, queue,
  call ID and recording. Optionally a ticket is created automatically for every answered call.
- **Zenith Phone** — a WebRTC softphone with MicroSIP functionality (JsSIP → FreePBX): up to 3 lines, hold, blind and
  attended transfer, 3-way conference, DTMF, call recording, voicemail, auto-answer, *Do not disturb* (paused in all
  queues), device selection. A slim call strip under the top bar shows the call on every page.
- **Two interface styles** (v3.12) — *Classic* or *Studio* in My settings → Appearance; the icons and buttons stay in
  place. Studio adds a section panel with counters next to the icon rail (Zammad overviews on Tickets, channels on the
  workplace, levels on the manager pages), a framed workspace with a greeting, number cards, work as cards with status
  pills and a start-of-shift checklist; the account is shown only bottom left. The section panel is either next to the
  icons (compact, can be hidden) or a pop-up over the page (v3.13) — each user chooses.
- **Interface style Flow** (v3.16) — pill navigation at the top with a sliding active pill, a floating toolbar
  (bottom dock on a phone), big titles, rounded white cards, smooth motion; light and dark.
- **Messenger: files, emoji, groups** (v3.20) — send files (encrypted, only for the people of the conversation),
  emoji, «Anna is typing…» with the name, group conversations with members managed by their creator.
- **Flow is the default look, tools on the left** (v3.19) — the menu stays on top; Ready / Break, the phone (dialer,
  do not disturb), Customize and the account buttons are on a rail in the middle of the left edge; the bell, LIVE and
  the account picture are at the right of the header. Each person pins up to **5 sections** of the top menu to the
  rail for quick access (they stay in the top menu too); saved to the account.
- **Five layouts of «My workplace»** (v3.14) — Blocks, Focus, Board, Inbox or Table; each operator chooses in
  My settings → Interface, where every interface setting is collected.
- **New ticket from a call** (v3.14) — a button in the phone during the call opens a ticket draft with the caller and
  the number as a link that types it in the phone for a call back; the ticket gets the call details.
- **Account picture** (v3.12) — a photo (cut to a square in the browser) or the initials of the first and last name;
  colleagues see it in the messenger and the manager panel; the administrator can remove an unsuitable photo.
- **Tickets like in Zammad** (v3.11) — the operator's **own Zammad overviews** with their counts (*My Assigned
  Tickets*, *Unassigned & Open Tickets*, *Open Tickets*, custom ones like *My Closed Tickets* or *On-site Requests*),
  a table with search, filters (group, state, priority, owner) and sorting; opened tickets and drafts stay as tabs on
  the left (kept on the server). A **new ticket is a draft** until *Create*: title, customer, channel, text, group,
  owner, state, priority, tags. In a ticket the side panel (group, owner, state, priority, tags) is saved with
  **Update**. Full conversation (e-mail, calls, Telegram, WhatsApp, notes) with attachments, reply or internal note,
  hand-over to a colleague. Everything is written to Zammad **on behalf of the operator**; Zammad group rights apply.
- **Customers** — Zammad customers and users, search by name / phone / e-mail / company, customer card with tickets.
- **Team chat** — Telegram-style messenger for staff: read receipts, typing, reactions, edit / delete, desktop push
  notifications; messages encrypted at rest and visible only to the two participants.
- **Telegram & WhatsApp** — **one company bot and one company number** (no personal numbers): Open / Mine /
  Unassigned / Closed, *Take* and *Transfer*, photos / files / voice, ✓ sent · ✓✓ delivered · read, internal notes,
  quick replies, *Call*, *Start*. Every conversation is mirrored into a Zammad ticket. WhatsApp 24-hour window and
  approved templates are handled.
- **Mail** — the employee types **only e-mail and password**; IMAP or POP3 + SMTP are set once by the administrator.
  Folders, search, safe HTML (sanitized, remote images on request), attachments, reply / reply all / forward,
  drafts, *Create ticket* from an e-mail, new mail instantly via IMAP IDLE.
- **Inactivity pause**, dark / light theme, animations, English / Russian, works from a 360 px phone to a 4K monitor.

### Manager (level *Manager*)
- **Team now** (v3.18) — live, for every employee: *ringing* (who calls, queue), *calling out* (which number), *talking*
  (number, customer, timer), *on hold*, *wrap-up*; time in status; the ticket and for how long; filters, sorting and
  quick actions (listen / whisper / join, open the ticket, write, his day). **Queues now** (who waits and how long,
  free operators, today per queue), **calls of the team** (the last 50, live), **a person's day** (timeline, numbers,
  calls), **alerts** (long call / break, not answered, queue full, missed call) and a **wallboard** for a TV.
- **Call routing** (v3.18) — distribution per queue (round robin, longest idle, fewest calls, all at once), overflow
  (Level 2 / 3 / managers help when a queue is full), VIP customers and «the last operator» straight to the right
  person with a safe way back into the queue.
- **Manager panel** — every operator's state **and the reason** (which ticket, blocking or background), queue pause
  and Asterisk sync status; filter by level 1 / 2 / 3.
- *Assign ticket* by number (optionally start it), **override** with a mandatory reason (audited), cancel a session,
  **reconcile** with Asterisk and Zammad, audit log, 24-hour report.
- **Overview** — today / yesterday / 7 / 30 days: incoming, answered, missed, **service level** gauge, answer rate,
  average speed of answer and talk time, live queue, calls by hour, staffing vs workload (Erlang), leaders,
  *missed callers not called back*, per-operator table with occupancy, *not picked up* and engagement index.
  Every formula is explained on the page.
- Plays **call recordings** of the whole team (operators only their own; every play is audited).
- **Call supervision** (v3.15) — on the manager panel every operator on a call has **Listen** (nobody hears the
  manager), **Whisper** (only the operator hears him, the customer does not) and **Join** (a three-way call). Asterisk
  ChanSpy; Zenith Desk rings the manager's own phone and Zenith Phone answers by itself; the mode changes with the
  buttons or keys 4 / 5 / 6. Every session is in the log.
- **Shift schedule** (v3.15) — who works when: templates, several people × several days at once, copy the previous
  week, night shifts. Late arrival, early leave and absence are noticed automatically from the presence history and
  the managers are notified once per case; today's attendance (came in, left, worked).
- **Recordings archive** (v3.15) — find a conversation by day and hours (also over midnight), operator, number or
  name, direction, queue, duration, with / without ticket; listen and download through Zenith Desk (rights + audit); managers and administrators only (v3.17.1).
- **Log** (v3.15) — staff actions and system problems (server warnings and errors, repeats counted) with filters:
  from / to (day and time), section, level, who did it, about whom, action, text, ticket; CSV export. Managers see the
  staff actions, the administrator everything.

### Administrator
- **API keys** (v3.18) — other programs use the Zenith Desk API with a key (acts as a chosen user; read-only, allowed
  addresses, expiry, revoke); the API description downloads from the same page.
- **Moving to a new version / server** (v3.18) — Backup → *Download full export*, restore it on the new installation:
  everything comes over, people stay signed in, the HTTPS certificate is the same.
- **Users** — own logins (no Zammad password needed), level = rights, link to a Zammad user and an extension,
  SIP password for the browser phone, password reset, lock-out after failed sign-ins.
- **Call routing by level** (v3.11) — Level 1 gets the call first (one by one), Level 2 only when **every** Level 1
  is on a call, on a break or busy with a ticket, Level 3 only when Level 2 is busy too. Zenith Desk sets the member
  penalty in Asterisk from the level (QueuePenalty) and shows live who is free and who gets the next call.
- **Ticket groups** (v3.11) — Zammad groups (e.g. *Cabling*, *IT Security*, *IT Support*): create, rename, switch
  off and choose the agents of each group from the Zenith Desk panel.
- **Integrations** — tabs Zammad · Telephony · Telegram · WhatsApp · Mail · Sync, each with **Test connection**
  against the real service; webhook URLs and verify tokens ready to copy. Secrets are stored encrypted, changes apply
  without restart.
- **Settings**, **ticket types with required fields** (validated before *Start*), **system status**,
  data-retention periods.
- **Backup** (v3.10) — the **whole system in one encrypted file**: users and passwords, settings and integrations,
  chats, Telegram / WhatsApp conversations with their files, mail, calls, audit log and the server key. *Create backup
  now*, automatic backups **every day or week at a chosen time**, **keep the last N copies**, list with date and size,
  download, upload, *Check* (password + integrity) and **Restore** from the panel — on the same server or on a brand-new
  one (secrets are re-encrypted for the new server's key). A safety copy is made before every restore; administrators
  are notified when a backup fails. AES-256-GCM, password-derived key (scrypt).

### Windows desktop app
`ZenithDesk-Setup-3.11.exe` — a classic setup wizard (C# / .NET Framework 4.8 + Edge WebView2): system check with
download of missing Microsoft components, server address and port with a **mandatory connection test**, desktop
shortcut, autostart, uninstall from *Installed apps*, silent mode `/S /SERVER= /PORT=`. `ZenithDesk.exe` keeps running
in the notification area and brings the window back on an incoming call. See [windows/README.md](windows/README.md).

---

## Screenshots

<table>
<tr>
<td width="50%"><img src="docs/screenshots/operator-dashboard.jpg" alt="Operator dashboard"><br><b>Operator dashboard</b> — tasks, new requests from every channel, notifications</td>
<td width="50%"><img src="docs/screenshots/incoming-call.jpg" alt="Incoming call"><br><b>Incoming call</b> — customer found in Zammad, call strip with Answer / Decline</td>
</tr>
<tr>
<td><img src="docs/screenshots/zenith-phone.jpg" alt="Zenith Phone"><br><b>Zenith Phone</b> — WebRTC softphone during a call</td>
<td><img src="docs/screenshots/ticket.jpg" alt="Ticket"><br><b>Ticket page</b> — conversation, properties, Start / Background</td>
</tr>
<tr>
<td><img src="docs/screenshots/telegram.jpg" alt="Telegram"><br><b>Telegram</b> — company bot, photo from a customer, Zammad ticket</td>
<td><img src="docs/screenshots/whatsapp.jpg" alt="WhatsApp"><br><b>WhatsApp</b> — company number, 24-hour window, delivered ✓✓</td>
</tr>
<tr>
<td><img src="docs/screenshots/mail.jpg" alt="Mail"><br><b>Mail</b> — folders, reading, reply, create ticket from e-mail</td>
<td><img src="docs/screenshots/mail-sign-in.jpg" alt="Mail sign-in"><br><b>Mail sign-in</b> — only e-mail and password</td>
</tr>
<tr>
<td><img src="docs/screenshots/customers.jpg" alt="Customers"><br><b>Customers</b> — Zammad customers with their tickets</td>
<td><img src="docs/screenshots/team-chat.jpg" alt="Team chat"><br><b>Team chat</b> — encrypted staff messenger</td>
</tr>
<tr>
<td><img src="docs/screenshots/manager-panel.jpg" alt="Manager panel"><br><b>Manager panel</b> — states, reasons, reconcile, override</td>
<td><img src="docs/screenshots/overview-team.jpg" alt="Team overview"><br><b>Team overview</b> — occupancy, not picked up, engagement</td>
</tr>
<tr>
<td><img src="docs/screenshots/admin-users.jpg" alt="Users"><br><b>Administration</b> — users, levels, Zammad link, extension</td>
<td><img src="docs/screenshots/admin-whatsapp.jpg" alt="WhatsApp integration"><br><b>Integrations</b> — WhatsApp number with connection test</td>
</tr>
<tr>
<td><img src="docs/screenshots/admin-mail.jpg" alt="Mail server settings"><br><b>Mail server</b> — IMAP / POP3, SMTP, ports, encryption</td>
<td><img src="docs/screenshots/admin-sync.jpg" alt="Sync panel"><br><b>Sync</b> — real time + fallback checks for every system</td>
</tr>
<tr>
<td><img src="docs/screenshots/my-settings.jpg" alt="My settings"><br><b>My settings</b> — theme, layouts, sounds, phone style</td>
<td><img src="docs/screenshots/admin-system.jpg" alt="System status"><br><b>System status</b> — integrations, errors, sessions</td>
</tr>
<tr>
<td><img src="docs/screenshots/studio-workplace.jpg" alt="Studio workplace"><br><b>Studio style</b> (v3.12) — section panel, greeting, number cards, work as cards</td>
<td><img src="docs/screenshots/studio-tickets.jpg" alt="Studio tickets"><br><b>Studio: tickets</b> — Zammad overviews in the section panel</td>
</tr>
<tr>
<td><img src="docs/screenshots/studio-manager.jpg" alt="Studio manager panel"><br><b>Studio: manager panel</b> — operators as cards, levels and states in the panel</td>
<td><img src="docs/screenshots/interface-style.jpg" alt="Interface style"><br><b>Interface style</b> — Classic or Studio, saved to the account</td>
</tr>
<tr>
<td><img src="docs/screenshots/account-picture.jpg" alt="Account picture"><br><b>Account picture</b> — photo or initials</td>
<td><img src="docs/screenshots/call-to-ticket.jpg" alt="New ticket from a call"><br><b>New ticket from a call</b> (v3.14) — caller and number filled in</td>
</tr>
<tr>
<td><img src="docs/screenshots/workplace-focus.jpg" alt="Focus layout"><br><b>My workplace: Focus</b> — the next request, big</td>
<td><img src="docs/screenshots/workplace-board.jpg" alt="Board layout"><br><b>My workplace: Board</b> — columns by stage</td>
</tr>
<tr>
<td><img src="docs/screenshots/flow-light.jpg" alt="Flow style"><br><b>Style Flow</b> (v3.16) — pill navigation, floating toolbar</td>
<td><img src="docs/screenshots/flow-dark.jpg" alt="Flow dark"><br><b>Flow, dark</b> — the same in the dark theme; <a href="docs/screenshots/flow-phone.jpg">on a phone</a></td>
</tr>
<tr>
<td><img src="docs/screenshots/call-supervision.jpg" alt="Call supervision"><br><b>Call supervision</b> (v3.15) — listen, whisper, join</td>
<td><img src="docs/screenshots/shifts.jpg" alt="Shift schedule"><br><b>Shift schedule</b> (v3.15) — late arrival and absence flagged</td>
</tr>
<tr>
<td><img src="docs/screenshots/recordings.jpg" alt="Recordings"><br><b>Recordings archive</b> (v3.15) — by day, hours, operator, number</td>
<td><img src="docs/screenshots/log.jpg" alt="Log"><br><b>Log</b> (v3.15) — staff actions and system problems with filters</td>
</tr>
<tr>
<td><img src="docs/screenshots/workplace-inbox.jpg" alt="Inbox layout"><br><b>My workplace: Inbox</b> — one list with filters</td>
<td><img src="docs/screenshots/workplace-table.jpg" alt="Table layout"><br><b>My workplace: Table</b> — one ticket per row</td>
</tr>
<tr>
<td><img src="docs/screenshots/tickets-overview.jpg" alt="Ticket overviews"><br><b>Tickets</b> — the operator's Zammad overviews, filters, open tabs</td>
<td><img src="docs/screenshots/ticket-draft.jpg" alt="New ticket draft"><br><b>New ticket</b> — a draft until «Create»: group, owner, state, priority, tags</td>
</tr>
<tr>
<td><img src="docs/screenshots/call-routing.jpg" alt="Call routing"><br><b>Call routing</b> — Level 1 → Level 2 → Level 3, who is free, who gets the next call</td>
<td><img src="docs/screenshots/ticket-groups.jpg" alt="Ticket groups"><br><b>Ticket groups</b> — Zammad groups and their agents</td>
</tr>
<tr>
<td><img src="docs/screenshots/backup.jpg" alt="Backup"><br><b>Backup</b> — the whole system in one encrypted file, schedule, copies</td>
<td><img src="docs/screenshots/backup-restore.jpg" alt="Restore"><br><b>Restore</b> — from the list or an uploaded file, safety copy first</td>
</tr>
<tr>
<td><img src="docs/screenshots/windows-setup.png" alt="Windows setup"><br><b>Windows setup wizard</b> — mandatory connection test</td>
<td align="center"><img src="docs/screenshots/mobile.jpg" alt="Mobile" width="45%"><br><b>Mobile</b> — the same app on a phone</td>
</tr>
</table>

---

## Architecture

```mermaid
flowchart TB
    UI["Zenith Desk workplace<br/>browser · Windows app · WebRTC phone"]
    S["Zenith Desk server<br/>state service · blocking/background rules<br/>sync hub · audit · retries · REST API"]
    DB[("PostgreSQL<br/>states · sessions · audit")]
    Z["Zammad<br/>REST · webhooks"]
    A["FreePBX / Asterisk<br/>AMI · WebRTC (PJSIP)"]
    T["Telegram<br/>Bot API"]
    W["WhatsApp<br/>Cloud API (Meta)"]
    M["Mail server<br/>IMAP · POP3 · SMTP"]
    UI -- "HTTPS + SSE (live events)" --> S
    S --> DB
    S --> Z & A & T & W & M
```

- **Server:** Python 3.12, FastAPI, async SQLAlchemy 2, PostgreSQL 16, Alembic migrations, one process
  (SSE broker and per-agent locks live in memory), Docker Compose. Live events reach the browser in 50–80 ms.
- **Web UI:** Vue 3 without a build step, IBM Plex fonts, JsSIP 3.13 for the phone — all served locally.
- **Desktop:** C# / .NET Framework 4.8 WinForms + Microsoft Edge WebView2.
- Zammad and FreePBX are **never modified** — only their official APIs (REST, webhooks, AMI) are used.

**A call, step by step:** customer calls queue 400 → AMI event → the operator's screen shows the customer card from
Zammad → the operator answers in Zenith Phone and creates a ticket → *Start* (blocking) assigns the ticket in Zammad
and pauses the operator in all queues after Asterisk confirms → the manager sees “busy with ticket #…” → *Complete*
closes the ticket and unpauses, unless another reason remains.

---

## Quick start (demo)

The demo replaces Zammad and Asterisk with in-memory fakes and starts Telegram / WhatsApp API simulators, so every
screen works without real systems.

```bash
pip install -r requirements-dev.txt
python -m scripts.demo                       # http://localhost:8000
UI_LANGUAGE=ru python -m scripts.demo        # Russian interface
```

| User | Password | Role |
|---|---|---|
| `anna`, `boris` | `pw` | operators |
| `boss` | `pw` | manager |
| `admin` | `admin` | administrator |

```bash
curl -X POST "localhost:8000/demo/call?ext=101&number=89123456789"            # incoming call
curl -X POST "localhost:8000/demo/telegram/message?name=Maria&text=Hello"     # message to the company bot
curl -X POST "localhost:8000/demo/whatsapp/message?name=Aram&text=Hello"      # message to the company number
```

The demo mailbox works when a local mail server is running: `sh tests/realstack/mailserver.sh start`
(Dovecot + Postfix; users `anna@company.test` / `anna-mail-1`, `boris@company.test` / `boris-mail-2`).

---

## Production install

A technician installs the server once; everything else is done by the administrator in the web panel.

```bash
cp .env.example .env            # set POSTGRES_PASSWORD and JWT_SECRET (openssl rand -hex 32) — never change JWT_SECRET later
                                # (v3.20.2: the server refuses to start with an empty / example / weak value)
docker compose up -d --build
docker compose logs app | grep -A3 "FIRST ADMINISTRATOR"     # first administrator's login and password
```

Zenith Desk serves **HTTPS itself** (port 443, TLS 1.2 / 1.3; port 80 only redirects) with your certificate or a
self-signed one made on the first start; PostgreSQL accepts only TLS connections with a checked certificate — see
[docs/INSTALL.md](docs/INSTALL.md) §3. Then sign in as administrator:

1. **Integrations → Zammad** — URL, service token, webhook token; add the shown webhook URL and a trigger in Zammad.
2. **Integrations → Telephony** — AMI host / user / password (`read = call,agent,dialplan`, `write = agent,originate,call`), managed
   queues, Zenith Phone WebSocket address.
3. **Users** — create employees, link each to a Zammad user and an extension.
4. Optional: **Telegram**, **WhatsApp**, **Mail**, **ticket types**, **retention**.
5. **Backup** — set the backup password and switch on automatic backups. Files are kept in the Docker volume
   `backups` (`/srv/backups`); download a copy regularly or copy them off the server.

Move to a new server: install Zenith Desk there (any `JWT_SECRET`), sign in as the first administrator,
*Backup → Upload a backup file → Restore*. From the command line (app stopped):
`docker compose run --rm app python -m app.cli restore /srv/backups/FILE.zdb`.

Forgot the admin password: `docker compose exec app python -m app.cli reset-password admin`.
Interface language: *Settings → General → Interface language* (`en` / `ru`) or `UI_LANGUAGE` in `.env`.

---

## Integrations

| System | How | Real time | Fallback check (every 5 min, configurable) |
|---|---|---|---|
| **Zammad** | REST API on behalf of the operator, signed webhooks | webhook | finds tickets changed without a webhook, reconciles sessions |
| **FreePBX / Asterisk** | AMI (pause / unpause with result check), PJSIP WebSocket for the phone | AMI events | compares every operator's pause with the real queue state |
| **Telegram** | company bot, Bot API | long polling (no public address needed) or webhook with secret header | re-registers the webhook, fetches missed updates |
| **WhatsApp** | WhatsApp Business Platform Cloud API, signed webhooks | webhook from Meta | checks number and token, re-sends the outbox, re-copies to Zammad |
| **Mail** | IMAP / POP3 + SMTP with the employee's own login | IMAP IDLE | checks for new mail, downloads new POP3 mail |

*Integrations → Sync* shows for every system: real time on / off, last event, last and next check, recovered items,
**retry-queue length**, last error and a *Check now* button. `GET /api/health` returns a short summary for monitoring.

> **Gmail:** IMAP / SMTP accept an **App Password** (requires 2-Step Verification), not the normal Google password.

---

## Reliability and security

- After a restart the service loads states from the database and **reconciles with Asterisk**; a pause is never
  removed while the queue state is unknown. AMI commands are confirmed by the response and the event, retried with
  back-off; *Ready* is never shown as confirmed while the queue state is unknown.
- Idempotent webhooks and commands (`X-Zammad-Delivery`, `Idempotency-Key`) — no duplicate sessions.
- **Nothing travels the network as plain text** (v3.17): built-in HTTPS (TLS 1.2 / 1.3 only) + HSTS, PostgreSQL over
  verified TLS, AMI over TLS with certificate pinning, https / wss / IMAP-SMTP TLS for every integration — an
  unencrypted address is refused when saved, and *System status → Encryption* lists anything left.
- Strict Content-Security-Policy, no framing, `no-store` on API answers, request-size limits, login throttling per
  user and per address; the live stream uses a 60-second ticket, never the session token in the address.
- Passwords hashed (scrypt); tokens, SIP and mail passwords, chat, mail and messenger messages and messenger files
  **encrypted at rest**; webhook signatures required and verified (Zammad HMAC, Telegram secret, Meta SHA-256).
- Call recordings are played through Zenith Desk with rights check and audit; configurable retention for audit,
  calls and messages.
- Backup and restore of the whole system in one encrypted file — admin panel → *Backup*, or
  `python -m app.cli backup` / `restore` — see [docs/OPERATIONS.md](docs/OPERATIONS.md).

---

## Testing

```bash
pip install -r requirements-dev.txt && playwright install chromium
pytest                                                                   # SQLite
TEST_DATABASE_URL=postgresql+asyncpg://aws:aws@localhost/aws_test pytest   # PostgreSQL
python -m scripts.release_check                                           # everything, before every release
```

| Check | Count | Against |
|---|---|---|
| Server tests | 174 | SQLite and PostgreSQL: availability rules, all acceptance criteria, API, backup / restore |
| UI end-to-end | 91 × 3 | Chromium: operator, manager, administrator, mobile — in all three interface styles |
| WebRTC phone | 12 | SIP-over-WebSocket server: register, calls, hold, DTMF, transfer |
| **Real Asterisk 20.6** | 9 + 8 | AMI with minimal rights, pause / DND, Asterisk restart, queue call answered in the browser, recording, call supervision (ChanSpy, browser phones, keys); routing by level (L1 → next L1 → L2 → L3) |
| **Real mail server** | 6 | Dovecot (IMAP, POP3, IDLE) + Postfix (SMTP) |
| **Backup on the real stack** | 14 | PostgreSQL + Alembic + uvicorn: two servers with different keys, restore over HTTP, restart, CLI |
| Backup page | 11 | Chromium: schedule, create, check, download, upload, live restore |
| Windows app | 41 | setup wizard, silent install / removal, connection test, program window (Mono) |
| Migrations | 4 | upgrade, model = schema, downgrade, upgrade again |

The real-system runs are scripted: `tests/realstack/asterisk.sh start && python tests/realstack/asterisk_e2e.py`.

---

## Project layout

```
app/                 FastAPI service
  api/               REST endpoints (OpenAPI at /docs, exported to docs/openapi.json)
  messengers/        Telegram and WhatsApp connectors
  mail/              IMAP / POP3 / SMTP
  static/            web UI (Vue 3, no build), Zenith Phone, fonts
  sync_hub.py        real-time + fallback synchronisation of every integration
migrations/          Alembic migrations
scripts/             demo server, API simulators, release check
tests/               pytest suites, UI and phone end-to-end tests, realstack/ (real Asterisk and mail)
windows/             C# setup wizard and desktop client, tests
docs/                install, operations, acceptance, ТЗ compliance, OpenAPI, screenshots
```

---

## Documentation

| Document | |
|---|---|
| [docs/INSTALL.md](docs/INSTALL.md) | installation: FreePBX / AMI, Zammad, TLS proxy, Telegram, WhatsApp, mail, recordings |
| [docs/OPERATIONS.md](docs/OPERATIONS.md) | updates, backup and restore, monitoring, behaviour during failures, limitations |
| [docs/ACCEPTANCE.md](docs/ACCEPTANCE.md) | acceptance test protocol |
| [docs/TZ_COMPLIANCE.md](docs/TZ_COMPLIANCE.md) | requirement-by-requirement compliance with the specification |
| [docs/openapi.json](docs/openapi.json) | OpenAPI of the service API (182 methods), interactive at `/docs` |
| [windows/README.md](windows/README.md) | Windows setup and client |
| [LICENSES.md](LICENSES.md) | third-party components and their licenses |
| [CHANGELOG.md](CHANGELOG.md) | every version in detail |

Most operational documents are written in Russian.

---

## Version history

| Version | Highlights |
|---|---|
| 1.0–1.4 | state service, Zammad + AMI, operator and supervisor UI, tests, Docker Compose, EN / RU |
| 2.0–2.3 | administration panel, own logins, dashboard, notifications, levels decide rights |
| 2.4–2.9 | *Command Center* design, manager overview, live mode (50–80 ms), inactivity pause, responsive |
| 3.0–3.4 | staff messenger, tickets and customers inside, Zammad API contract check, new name *Zenith Desk* |
| 3.5–3.7 | Zenith Phone (WebRTC, MicroSIP features), call strip, server-side Do not disturb |
| 3.8 | Windows setup wizard and desktop client |
| 3.9 | Telegram, WhatsApp, mail, background sync of every system, protected recordings, retention, real Asterisk 20 tests |
| 3.10 | Backup and restore of the whole system in one encrypted file: schedule, copies, alerts, restore on a new server |
| 3.11 | Tickets like in Zammad (overviews, filters, tabs, drafts, Update, tags), Zammad groups, call routing L1 → L2 → L3 |
| 3.12 | Interface style Classic / Studio (section panel, cards, account in one place), account picture: photo or initials |
| 3.13 | Studio section panel next to the icons or as a pop-up, chosen per user |
| 3.14 | Five layouts of My workplace, Interface section in My settings, new ticket straight from a call |
| 3.15 | Manager tools: listen / whisper / join a call, shift schedule with lateness and absence, recordings archive, log with filters; 3.15.1: administration and manager tools grouped on the rail, tables scroll on phones |
| 3.16 | Interface style Flow: pill navigation with a sliding active pill, floating toolbar, rounded cards, smoother motion |
| 3.17 | Security: nothing travels as plain text (built-in HTTPS, PostgreSQL and AMI over TLS), messenger files encrypted at rest, security audit fixes; 3.17.1: recordings for managers only, ticket stages by colour |
| 3.18 | Team now (live call phases, queues, call feed, a person's day, alerts, wallboard), call routing for managers (distribution, overflow, VIP), API keys, seamless move to a new version; 3.18.1: the drawn ZENITH. wordmark in the header and on the wallboard, new login page |
| 3.19 | Flow is the default look; tools on a rail at the left (status, phone, Customize), menu on top, up to 5 sections pinned for quick access; 3.19.1: login page with a grid background |
| **3.20** | Internal messenger: files, emoji, «typing…» with the name, group conversations; the call strip in the top bar; 3.20.1: pop-ups centred, phone layout checked page by page |

---

<sub>Third-party components are open source; see <a href="LICENSES.md">LICENSES.md</a>. Zammad and FreePBX/Asterisk are used only through their public APIs.</sub>
