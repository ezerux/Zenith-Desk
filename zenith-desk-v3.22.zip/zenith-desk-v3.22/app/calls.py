"""Call events from AMI -> call log, screen pop and wrap-up (FR-01, FR-02, FR-09)."""
import asyncio
import logging
import re
from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from .audit import audit
from .config import Settings
from .db import Database, as_utc, utcnow
from .events import EventBroker
from .models import AgentMapping, CallRecord, QueueCall
from .pbx import SPY_PREFIX
from .phone import normalize_phone, phone_matches
from .sync import StateEngine
from .views import call_view
from .zammad import ZammadClient, ZammadError

log = logging.getLogger("calls")

DEVICE_RE = re.compile(r"^(?:PJSIP|SIP|IAX2)/([^-/@]+)-", re.I)


def device_ext(channel: str) -> str:
    m = DEVICE_RE.match(channel or "")
    return m.group(1) if m else ""


class CallService:
    def __init__(self, db: Database, zammad: ZammadClient, engine: StateEngine, broker: EventBroker, settings: Settings):
        self.db, self.zammad, self.engine, self.broker, self.settings = db, zammad, engine, broker, settings
        self._tasks: set[asyncio.Task] = set()
        # recording file names announced before the operator's phone rang (MixMonitor starts before Queue()), by linkedid
        self._pending_rec: dict[str, str] = {}
        # v3.18: operators whose call is on hold right now (AMI Hold / Unhold on their phone's channel), by agent id
        self.hold: dict[int, datetime] = {}

    async def stop(self) -> None:
        for t in list(self._tasks):
            t.cancel()
        await asyncio.gather(*list(self._tasks), return_exceptions=True)

    def recording_url(self, c: CallRecord) -> str:
        if self.settings.recording_dir and c.recording_file and c.id:
            return f"/api/calls/{c.id}/recording"  # v3.9: protected playback through Zenith Desk (rights + audit)
        tpl = self.settings.recording_url_template
        if not tpl or not c.recording_file:
            return ""
        if not tpl.strip().lower().startswith(("https://", "http://", "/")):
            return ""  # SEC-11: never hand the browser a javascript: / data: link to open
        started = as_utc(c.started_at)
        return tpl.format(file=c.recording_file, uniqueid=c.uniqueid, linkedid=c.linkedid,
                          date=started.strftime("%Y/%m/%d") if started else "")

    def view(self, c: CallRecord) -> dict:
        return call_view(c, self.recording_url(c))

    def call_info(self, call: CallRecord) -> str:
        """The call details written into the ticket (FR-02: call ID, time, extension, queue, recording)."""
        from .i18n import t as tr  # noqa: PLC0415
        rec_url = self.recording_url(call)
        started = as_utc(call.started_at)
        return "\n".join(filter(None, [
            tr("call.header"),
            tr("call.number", v=call.caller_number),
            tr("call.time", v=f"{started:%Y-%m-%d %H:%M:%S}" if started else ""),
            tr("call.extension", v=call.extension),
            tr("call.queue", v=call.queue) if call.queue else "",
            tr("call.id", v=call.linkedid),
            tr("call.recording", v=rec_url or call.recording_file) if (rec_url or call.recording_file) else "",
        ]))

    # ------------------------------------------------------------------ v3.9: a ticket for every answered call (ТЗ 15)
    def _schedule_auto_ticket(self, call_id: int) -> None:
        task = asyncio.create_task(self.auto_ticket(call_id), name=f"auto-ticket-{call_id}")
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def auto_ticket(self, call_id: int) -> int | None:
        from .i18n import t as tr  # noqa: PLC0415
        async with self.db.sessionmaker() as s:
            call = await s.get(CallRecord, call_id)
            agent = await s.get(AgentMapping, call.agent_id) if call and call.agent_id else None
        if call is None or agent is None or call.ticket_id or call.direction != "in" or not call.answered_at:
            return None
        try:
            found = await self.lookup_customers(call.caller_number)
            if found:
                customer_id = found[0]["id"]
            else:
                first, _, last = (call.caller_name or call.caller_number).partition(" ")
                u = await self.zammad.create_user({"firstname": first, "lastname": last, "mobile": call.caller_number, "roles": ["Customer"]})
                customer_id = u["id"]
            payload = {"title": tr("call.auto_title", v=call.caller_name or call.caller_number), "group": self.settings.zammad_default_group,
                       "customer_id": customer_id, "state": "open",
                       "article": {"subject": tr("call.auto_title", v=call.caller_number), "body": self.call_info(call), "type": "phone",
                                   "internal": False, "sender": "Customer", "content_type": "text/plain"}}
            if agent.zammad_user_id:
                payload["owner_id"] = agent.zammad_user_id
            ticket = await self.zammad.create_ticket(payload)
        except Exception as exc:  # noqa: BLE001 — never lose the call because Zammad is down; the operator still has the button
            log.warning("automatic ticket for call %s failed: %s", call_id, exc)
            async with self.db.sessionmaker() as s:
                audit(s, "auto_ticket_failed", agent_id=agent.id, actor_type="system", call_id=call_id, error=str(exc)[:300])
                await s.commit()
            return None
        async with self.db.sessionmaker() as s:
            c = await s.get(CallRecord, call_id)
            if c.ticket_id:  # the operator was faster
                return c.ticket_id
            c.ticket_id = ticket["id"]
            audit(s, "ticket_created", agent_id=agent.id, ticket_id=ticket["id"], actor_type="system", call_id=call_id, auto=True)
            await s.commit()
            view = self.view(c)
        self.broker.publish_agent(agent.id, "call_updated", {"call": view, "ticket": {"id": ticket["id"], "number": ticket.get("number")}})
        return ticket["id"]

    # ------------------------------------------------------------------ customer lookup
    async def lookup_customers(self, number: str) -> list[dict]:
        kw = {"country_code": self.settings.phone_country_code, "national_prefix": self.settings.phone_national_prefix}
        norm = normalize_phone(number, **kw)
        if len(norm) < 5:
            return []
        try:
            users = await self.zammad.search_users(norm[-10:])
        except ZammadError as exc:
            log.warning("customer lookup failed: %s", exc)
            return []
        result = []
        for u in users:
            if any(phone_matches(norm, u.get(f), **kw) for f in ("phone", "mobile")):
                result.append({
                    "id": u.get("id"),
                    "name": " ".join(filter(None, [u.get("firstname"), u.get("lastname")])) or u.get("login"),
                    "email": u.get("email"),
                    "phone": u.get("phone") or u.get("mobile"),
                    "organization": u.get("organization"),
                    "note": u.get("note"),
                })
        return result

    # ------------------------------------------------------------------ AMI events
    async def _agent_by_interface(self, s, interface: str) -> AgentMapping | None:
        if not interface:
            return None
        return (await s.execute(
            select(AgentMapping).where(func.lower(AgentMapping.asterisk_interface) == interface.lower())
        )).scalars().first()

    async def _agent_by_ext(self, s, ext: str) -> AgentMapping | None:
        if not ext:
            return None
        return (await s.execute(select(AgentMapping).where(AgentMapping.extension == ext))).scalars().first()

    async def _upsert(self, s, linkedid: str, agent: AgentMapping, **fields) -> tuple[CallRecord, bool]:
        rec = (await s.execute(
            select(CallRecord).where(CallRecord.linkedid == linkedid, CallRecord.agent_id == agent.id)
        )).scalars().first()
        if rec is not None:
            if rec.state == "missed" and fields.get("state") == "ringing":  # rung again within the same call
                rec.state, rec.ended_at = "ringing", None
                return rec, True
            return rec, False
        rec = CallRecord(linkedid=linkedid, agent_id=agent.id, extension=agent.extension, **fields)
        s.add(rec)
        try:
            await s.flush()
        except IntegrityError:
            await s.rollback()
            rec = (await s.execute(
                select(CallRecord).where(CallRecord.linkedid == linkedid, CallRecord.agent_id == agent.id)
            )).scalars().first()
            return rec, False
        return rec, True

    on_spy_event = None  # v3.15: events of a manager's listening channel go to the supervision service

    async def handle_event(self, ev: dict) -> None:
        name = ev.get("Event", "")
        if any(str(ev.get(k, "")).startswith(SPY_PREFIX) for k in ("Uniqueid", "Linkedid", "DestUniqueid", "DestLinkedid")):
            if self.on_spy_event:  # never a customer call: not a call card, not in the statistics
                await self.on_spy_event(ev)
            return
        handler = {
            "AgentCalled": self._on_ringing_queue,
            "DialBegin": self._on_dial_begin,
            "AgentConnect": self._on_answer_queue,
            "DialEnd": self._on_dial_end,
            "AgentRingNoAnswer": self._on_ring_no_answer,
            "AgentComplete": self._on_agent_complete,
            "Hangup": self._on_hangup,
            "VarSet": self._on_varset,
            "QueueMemberPause": self._on_member_pause,
            "QueueCallerJoin": self._on_queue_join,
            "QueueCallerAbandon": self._on_queue_abandon,
            "QueueCallerLeave": self._on_queue_leave,
            "Hold": self._on_hold,
            "Unhold": self._on_hold,
        }.get(name)
        if handler:
            await handler(ev)
        if name in ("AgentConnect", "AgentComplete", "Hangup"):
            await self._queue_call_progress(name, ev)

    @staticmethod
    def _linkedid(ev: dict) -> str:
        return ev.get("Linkedid") or ev.get("Uniqueid") or ""

    async def _ringing(self, agent: AgentMapping, ev: dict, queue: str, number: str, name: str, direction: str) -> None:
        kw = {"country_code": self.settings.phone_country_code, "national_prefix": self.settings.phone_national_prefix}
        async with self.db.sessionmaker() as s:
            rec, created = await self._upsert(
                s, self._linkedid(ev), agent, uniqueid=ev.get("Uniqueid", ""), queue=queue, direction=direction,
                caller_number=number, caller_normalized=normalize_phone(number, **kw), caller_name=name,
                state="ringing", started_at=utcnow(),
            )
            if created and not rec.recording_file and self._pending_rec.get(rec.linkedid):
                rec.recording_file = self._pending_rec[rec.linkedid][:500]
            await s.commit()
            view = self.view(rec)
        if not created:
            return
        customers = await self.lookup_customers(number) if direction == "in" else []
        self.broker.publish_agent(agent.id, "call_ringing", {"call": view, "customers": customers})
        self.broker.publish_supervisors("call", {"call": view})

    async def _on_ringing_queue(self, ev: dict) -> None:
        async with self.db.sessionmaker() as s:
            agent = await self._agent_by_interface(s, ev.get("Interface") or ev.get("MemberName", ""))
        if agent:
            await self._ringing(agent, ev, ev.get("Queue", ""), ev.get("CallerIDNum", ""), ev.get("CallerIDName", ""), "in")

    async def _on_dial_begin(self, ev: dict) -> None:
        """Direct (non-queue) calls to/from an operator's device."""
        dest_ext = device_ext(ev.get("DestChannel", ""))
        src_ext = device_ext(ev.get("Channel", ""))
        async with self.db.sessionmaker() as s:
            dest_agent = await self._agent_by_ext(s, dest_ext)
            src_agent = await self._agent_by_ext(s, src_ext)
        if dest_agent and dest_agent != src_agent:
            await self._ringing(dest_agent, ev, "", ev.get("CallerIDNum", ""), ev.get("CallerIDName", ""), "in")
        elif src_agent:
            number = ev.get("DestCallerIDNum") or ev.get("DialString", "")
            await self._ringing(src_agent, ev, "", number, ev.get("DestCallerIDName", ""), "out")

    async def _set_state(self, linkedid: str, agent_id: int | None, state: str, event: str, **extra) -> None:
        async with self.db.sessionmaker() as s:
            q = select(CallRecord).where(CallRecord.linkedid == linkedid)
            if agent_id is not None:
                q = q.where(CallRecord.agent_id == agent_id)
            recs = (await s.execute(q)).scalars().all()
            changed = []
            for rec in recs:
                if rec.state in ("ended", "missed") and state != "recording":
                    continue
                if state == "answered":
                    rec.state, rec.answered_at = "answered", rec.answered_at or utcnow()
                elif state == "ended":
                    rec.state, rec.ended_at = ("ended" if rec.answered_at else "missed"), utcnow()
                elif state == "missed":
                    rec.state, rec.ended_at = "missed", utcnow()
                elif state == "recording":
                    rec.recording_file = extra.get("file", "")[:500]
                changed.append(rec)
            await s.commit()
            self._hold_over(changed)
            for rec in changed:
                if rec.agent_id:
                    self.broker.publish_agent(rec.agent_id, event, {"call": self.view(rec)})
                if (state == "ended" and rec.state == "ended" and rec.direction == "in" and not rec.ticket_id
                        and self.settings.call_auto_ticket == "answered"):
                    self._schedule_auto_ticket(rec.id)

    async def _on_answer_queue(self, ev: dict) -> None:
        async with self.db.sessionmaker() as s:
            agent = await self._agent_by_interface(s, ev.get("Interface") or ev.get("MemberName", ""))
        if agent:
            await self._set_state(self._linkedid(ev), agent.id, "answered", "call_answered")

    async def _on_dial_end(self, ev: dict) -> None:
        if ev.get("DialStatus") in ("NOANSWER", "CANCEL", "BUSY", "CHANUNAVAIL", "CONGESTION"):
            # v3.18: the phone stopped ringing without an answer — not «ringing» any more on the manager's board
            async with self.db.sessionmaker() as s:
                agent = await self._agent_by_ext(s, device_ext(ev.get("DestChannel", "")))
            if agent:
                await self._set_state(self._linkedid(ev), agent.id, "missed", "call_missed")
            return
        if ev.get("DialStatus") != "ANSWER":
            return
        async with self.db.sessionmaker() as s:
            agent = await self._agent_by_ext(s, device_ext(ev.get("DestChannel", ""))) or \
                await self._agent_by_ext(s, device_ext(ev.get("Channel", "")))
        if agent:
            await self._set_state(self._linkedid(ev), agent.id, "answered", "call_answered")

    async def _on_ring_no_answer(self, ev: dict) -> None:
        async with self.db.sessionmaker() as s:
            agent = await self._agent_by_interface(s, ev.get("Interface") or ev.get("MemberName", ""))
        if agent:
            await self._set_state(self._linkedid(ev), agent.id, "missed", "call_missed")

    async def _on_agent_complete(self, ev: dict) -> None:
        async with self.db.sessionmaker() as s:
            agent = await self._agent_by_interface(s, ev.get("Interface") or ev.get("MemberName", ""))
        if not agent:
            return
        await self._set_state(self._linkedid(ev), agent.id, "ended", "call_ended")
        if self.settings.wrap_up_seconds > 0:
            async with self.db.sessionmaker() as s:
                st = await self.engine.ensure_state(s, agent.id)
                st.wrap_up_until = utcnow() + timedelta(seconds=self.settings.wrap_up_seconds)
                audit(s, "wrap_up_started", agent_id=agent.id, seconds=self.settings.wrap_up_seconds)
                await s.commit()
            await self.engine.recompute(agent.id, "wrap_up")

    async def _on_hangup(self, ev: dict) -> None:
        linkedid = self._linkedid(ev)
        if linkedid and ev.get("Uniqueid") == linkedid:  # the originating channel hung up -> call over
            await self._set_state(linkedid, None, "ended", "call_ended")

    async def _on_hold(self, ev: dict) -> None:
        """v3.18: the operator put the customer on hold (or took him back) — shown live on the manager panel."""
        ext = device_ext(ev.get("Channel", ""))
        if not ext:
            return
        async with self.db.sessionmaker() as s:
            agent = await self._agent_by_ext(s, ext)
        if agent is None:
            return
        if ev.get("Event") == "Hold":
            self.hold.setdefault(agent.id, utcnow())
        elif self.hold.pop(agent.id, None) is None:
            return
        self.broker.publish_supervisors("changed", {"topics": ["team"]})  # nothing is written: tell the panels directly

    def _hold_over(self, recs) -> None:
        for rec in recs:
            if rec.agent_id in self.hold and rec.state in ("ended", "missed"):
                self.hold.pop(rec.agent_id, None)

    async def _on_varset(self, ev: dict) -> None:
        var = (ev.get("Variable") or "").lstrip("_")  # Set(__MIXMONITOR_FILENAME=…) is inherited by the agent's channels
        if var in ("MIXMONITOR_FILENAME", "CALLFILENAME") and ev.get("Value"):
            value = ev["Value"]
            if var == "CALLFILENAME" and "." not in value:
                return
            linkedid = self._linkedid(ev)
            if linkedid:
                self._pending_rec[linkedid] = value
                while len(self._pending_rec) > 2000:  # bounded: only recent calls matter
                    self._pending_rec.pop(next(iter(self._pending_rec)))
            await self._set_state(self._linkedid(ev), None, "recording", "call_updated", file=value)

    async def _on_member_pause(self, ev: dict) -> None:
        """Pause changed outside of our command (phone *46, FOP, other tools) -> re-check."""
        if ev.get("PausedReason", ev.get("Reason", "")) == self.settings.pause_reason:
            return
        async with self.db.sessionmaker() as s:
            agent = await self._agent_by_interface(s, ev.get("Interface") or ev.get("MemberName", ""))
        if agent:
            # separate task: never block the event consumer on the per-agent lock
            task = asyncio.create_task(self.engine.recompute(agent.id, "external_pause_event"))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)

    # ------------------------------------------------------------------ queue statistics (v2.5)
    @staticmethod
    def _int(v) -> int | None:
        try:
            return max(0, int(str(v).strip()))
        except (TypeError, ValueError):
            return None

    async def _queue_row(self, s, linkedid: str) -> QueueCall | None:
        if not linkedid:
            return None
        return (await s.execute(select(QueueCall).where(QueueCall.linkedid == linkedid))).scalars().first()

    async def _on_queue_join(self, ev: dict) -> None:
        linkedid = self._linkedid(ev)
        if not linkedid:
            return
        kw = {"country_code": self.settings.phone_country_code, "national_prefix": self.settings.phone_national_prefix}
        number = ev.get("CallerIDNum", "")
        async with self.db.sessionmaker() as s:
            row = await self._queue_row(s, linkedid)
            if row is None:
                s.add(QueueCall(linkedid=linkedid, uniqueid=ev.get("Uniqueid", ""), queue=ev.get("Queue", ""),
                                caller_number=number, caller_normalized=normalize_phone(number, **kw),
                                caller_name=ev.get("CallerIDName", ""), outcome="waiting", joined_at=utcnow()))
            elif row.outcome in ("exited", "redirected"):  # overflow into another queue / back from a VIP ring: the same call
                row.outcome, row.queue, row.left_at = "waiting", ev.get("Queue", row.queue), None
            try:
                await s.commit()
            except IntegrityError:
                await s.rollback()

    async def _on_queue_abandon(self, ev: dict) -> None:
        async with self.db.sessionmaker() as s:
            row = await self._queue_row(s, self._linkedid(ev))
            if row is None or row.answered_at:
                return
            now = utcnow()
            row.outcome, row.left_at = "abandoned", row.left_at or now
            hold = self._int(ev.get("HoldTime"))
            row.wait_sec = hold if hold is not None else int((now - as_utc(row.joined_at)).total_seconds())
            await s.commit()

    async def _on_queue_leave(self, ev: dict) -> None:
        # Sent both when an agent picks up and when the caller leaves unanswered; the outcome is decided by
        # AgentConnect / QueueCallerAbandon / the caller's Hangup.
        async with self.db.sessionmaker() as s:
            row = await self._queue_row(s, self._linkedid(ev))
            if row is not None and row.left_at is None:
                row.left_at = utcnow()
                await s.commit()

    async def _queue_call_progress(self, name: str, ev: dict) -> None:
        linkedid = self._linkedid(ev)
        async with self.db.sessionmaker() as s:
            row = await self._queue_row(s, linkedid)
            if row is None:
                return
            now = utcnow()
            if name == "AgentConnect" and row.answered_at is None:
                agent = await self._agent_by_interface(s, ev.get("Interface") or ev.get("MemberName", ""))
                hold = self._int(ev.get("HoldTime"))
                row.answered_at, row.outcome = now, "answered"
                row.agent_id = agent.id if agent else row.agent_id
                row.wait_sec = hold if hold is not None else int((now - as_utc(row.joined_at)).total_seconds())
                row.left_at = row.left_at or now
            elif name == "AgentComplete" and row.answered_at is not None and row.ended_at is None:
                talk = self._int(ev.get("TalkTime"))
                row.ended_at = now
                row.talk_sec = talk if talk is not None else int((now - as_utc(row.answered_at)).total_seconds())
            elif name == "Hangup" and ev.get("Uniqueid") == linkedid:  # the customer's channel is gone
                if row.answered_at is None and row.outcome == "redirected":
                    row.outcome = "abandoned"  # v3.18: hung up while the VIP target's phone rang
                    if row.wait_sec is None:
                        row.wait_sec = int((now - as_utc(row.joined_at)).total_seconds())
                elif row.answered_at is None and row.outcome == "waiting":
                    row.outcome = "exited" if row.left_at else "abandoned"
                    row.left_at = row.left_at or now
                    if row.wait_sec is None:
                        row.wait_sec = int((as_utc(row.left_at) - as_utc(row.joined_at)).total_seconds())
                elif row.answered_at is not None and row.ended_at is None:
                    row.ended_at = now
                    row.talk_sec = int((now - as_utc(row.answered_at)).total_seconds())
            else:
                return
            await s.commit()

    # ------------------------------------------------------------------ queries
    async def recent(self, agent_id: int, limit: int = 20) -> list[dict]:
        async with self.db.sessionmaker() as s:
            rows = (await s.execute(
                select(CallRecord).where(CallRecord.agent_id == agent_id).order_by(CallRecord.started_at.desc()).limit(limit)
            )).scalars().all()
        return [self.view(r) for r in rows]
