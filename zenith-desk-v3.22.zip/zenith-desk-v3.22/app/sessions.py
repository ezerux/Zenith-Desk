"""v3.18 session keys of a previous server.

After a backup of another server (an older version, another machine) is restored here, the people who were signed in
there keep working: their sign-in was signed with that server's key, which the backup carries. The key is kept
(encrypted, like every secret) only until those sign-ins expire by themselves."""
from __future__ import annotations

import json
from datetime import datetime

from .db import as_utc, utcnow


def previous_session_keys(cfg) -> list[dict]:
    try:
        keys = json.loads(getattr(cfg, "previous_session_keys", "") or "[]")
    except ValueError:
        return []
    now, out = utcnow(), []
    for k in keys if isinstance(keys, list) else []:
        try:
            if k.get("k") and as_utc(datetime.fromisoformat(k["until"])) > now:
                out.append({"k": str(k["k"]), "until": k["until"]})
        except (TypeError, ValueError, AttributeError):
            continue
    return out
