"""Contact-center statistics for the manager overview (v2.5).

All numbers are computed from data Zenith Desk records itself:

* queue_call      — one row per customer call in an ACD queue (AMI QueueCaller*/AgentConnect/AgentComplete)
* call_record     — every ring of an operator's phone (queue and direct calls, inbound and outbound)
* audit_log       — `availability_changed` events: the exact timeline of each operator's state
* work_session    — tickets taken into work (blocking / background) and completed

Definitions follow the usual contact-center (ACD / CRM) conventions:

* Offered          = customer calls that finished in the period: answered + abandoned + unanswered.
                     Calls still waiting are shown separately ("waiting now").
* Short abandon    = caller hung up within `short_abandon_seconds`; such calls are excluded from the
                     rates below (the caller most likely dialled by mistake).
* Answer rate      = answered / (offered − short abandons)
* Abandon rate     = abandoned (not short) / (offered − short abandons)
* Service level    = answered within `sla_answer_seconds` / (offered − short abandons)
* ASA              = average speed of answer = mean waiting time of answered calls
* AHT (talk)       = mean talk time of answered calls
* RONA             = "ring, no answer": the operator's phone rang and the operator did not pick up while
                     no colleague had answered the call yet (a ring cancelled because a colleague answered
                     first does not count).
* Logged-in time   = time not in "offline"; Break = "break" state; Ready = "ready" state.
* Occupancy        = productive time / available time, where productive = talk ∪ blocking tasks ∪ wrap-up
                     and available = logged-in − break (time the operator was supposed to work).
* Engagement index = 50 % answer reliability (answered / (answered + RONA))
                     + 30 % presence (1 − break share of logged-in time)
                     + 20 % occupancy (relative to an 85 % target, capped at 100 %).
                     Calculated only after 10 minutes of logged-in time.
* Unreturned missed calls = numbers whose last call was missed and that were neither answered later nor called
                     back (any outbound call to the number) up to now.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from .db import as_utc

STATES = ("ready", "busy_task", "wrap_up", "break", "offline")
RONA_TOLERANCE = timedelta(seconds=2)
STALE_WAIT = timedelta(hours=4)
OCCUPANCY_TARGET = 0.85
MIN_LOGGED_FOR_SCORE = 600  # seconds
THRESHOLDS = {"rona_count": 3, "rona_rate": 0.2, "break_share": 0.2, "low_occupancy": 0.3, "min_logged_sec": 3600}

Interval = tuple[datetime, datetime]


# ------------------------------------------------------------------ interval helpers
def clip(a: datetime | None, b: datetime | None, start: datetime, end: datetime) -> Interval | None:
    if a is None:
        return None
    a, b = max(as_utc(a), start), min(as_utc(b) if b else end, end)
    return (a, b) if b > a else None


def union(intervals: list[Interval]) -> list[Interval]:
    out: list[Interval] = []
    for a, b in sorted(intervals):
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def intersect(xs: list[Interval], ys: list[Interval]) -> list[Interval]:
    xs, ys, out, i, j = union(xs), union(ys), [], 0, 0
    while i < len(xs) and j < len(ys):
        a, b = max(xs[i][0], ys[j][0]), min(xs[i][1], ys[j][1])
        if b > a:
            out.append((a, b))
        if xs[i][1] < ys[j][1]:
            i += 1
        else:
            j += 1
    return out


def total(intervals: list[Interval]) -> float:
    return sum((b - a).total_seconds() for a, b in union(intervals))


def ratio(a: float, b: float) -> float | None:
    return round(a / b, 4) if b else None


def mean(xs: list[float]) -> float | None:
    return round(sum(xs) / len(xs), 1) if xs else None


# ------------------------------------------------------------------ customer calls
def customer_calls(queue_calls, records, start: datetime, end: datetime, now: datetime) -> list[dict]:
    """One entry per inbound customer call that started in [start, end)."""
    calls: list[dict] = []
    seen: set[str] = set()
    for q in queue_calls:
        joined = as_utc(q.joined_at)
        seen.add(q.linkedid)
        if not (start <= joined < end):
            continue
        answered_at = as_utc(q.answered_at)
        if answered_at:
            outcome = "answered"
        elif q.outcome in ("abandoned", "exited"):
            outcome = "abandoned" if q.outcome == "abandoned" else "unanswered"
        elif q.outcome == "redirected" and now - joined <= STALE_WAIT:
            outcome = "waiting"  # v3.18 VIP: ringing the chosen employee directly
        elif q.left_at and now - as_utc(q.left_at) > timedelta(seconds=5):
            outcome = "unanswered"
        elif now - joined > STALE_WAIT:
            outcome = "unanswered"
        else:
            outcome = "waiting"
        if q.wait_sec is not None:
            wait = float(q.wait_sec)
        else:
            stop = answered_at or (now if q.outcome == "redirected" else as_utc(q.left_at)) or now
            wait = max(0.0, (stop - joined).total_seconds())
        talk = None
        if answered_at:
            talk = float(q.talk_sec) if q.talk_sec is not None else \
                max(0.0, ((as_utc(q.ended_at) or now) - answered_at).total_seconds())
        calls.append({"linkedid": q.linkedid, "start": joined, "queue": q.queue, "number": q.caller_normalized or q.caller_number,
                      "name": q.caller_name, "outcome": outcome, "wait": wait, "talk": talk, "agent_id": q.agent_id,
                      "answered_at": answered_at, "source": "queue"})

    by_link: dict[str, list] = defaultdict(list)
    for r in records:
        if r.direction == "in" and r.linkedid not in seen:
            by_link[r.linkedid].append(r)
    for linkedid, rs in by_link.items():
        first = min(as_utc(r.started_at) for r in rs)
        if not (start <= first < end):
            continue
        ans = sorted((r for r in rs if r.answered_at), key=lambda r: as_utc(r.answered_at))
        if ans:
            r = ans[0]
            answered_at = as_utc(r.answered_at)
            outcome, agent_id = "answered", r.agent_id
            wait = max(0.0, (answered_at - first).total_seconds())
            talk = max(0.0, ((as_utc(r.ended_at) or now) - answered_at).total_seconds())
        else:
            answered_at, agent_id, talk = None, None, None
            ringing = any(r.state == "ringing" and not r.ended_at for r in rs)
            outcome = "waiting" if ringing and now - first < STALE_WAIT else "unanswered"
            stop = max((as_utc(r.ended_at) for r in rs if r.ended_at), default=now)
            wait = max(0.0, (stop - first).total_seconds())
        r0 = rs[0]
        calls.append({"linkedid": linkedid, "start": first, "queue": r0.queue, "number": r0.caller_normalized or r0.caller_number,
                      "name": r0.caller_name, "outcome": outcome, "wait": wait, "talk": talk, "agent_id": agent_id,
                      "answered_at": answered_at, "source": "queue" if r0.queue else "direct"})
    calls.sort(key=lambda c: c["start"])
    return calls


def call_summary(calls: list[dict], sla_sec: int, short_sec: int) -> dict:
    done = [c for c in calls if c["outcome"] != "waiting"]
    answered = [c for c in done if c["outcome"] == "answered"]
    abandoned = [c for c in done if c["outcome"] == "abandoned"]
    short = [c for c in abandoned if c["wait"] <= short_sec]
    unanswered = [c for c in done if c["outcome"] == "unanswered"]
    base = len(done) - len(short)
    within = [c for c in answered if c["wait"] <= sla_sec]
    talks = [c["talk"] for c in answered if c["talk"] is not None]
    return {
        "offered": len(done),
        "answered": len(answered),
        "abandoned": len(abandoned) - len(short),
        "short_abandoned": len(short),
        "unanswered": len(unanswered),
        "missed": len(abandoned) - len(short) + len(unanswered),
        "answer_rate": ratio(len(answered), base),
        "abandon_rate": ratio(len(abandoned) - len(short), base),
        "service_level": ratio(len(within), base),
        "answered_within_sla": len(within),
        "asa_sec": mean([c["wait"] for c in answered]),
        "longest_wait_sec": max((c["wait"] for c in done), default=None),
        "avg_abandon_wait_sec": mean([c["wait"] for c in abandoned if c["wait"] > short_sec]),
        "aht_talk_sec": mean(talks),
        "talk_sec": int(sum(talks)),
    }


def unreturned_missed(calls: list[dict], outbound, now: datetime, until: datetime | None = None) -> list[dict]:
    """Missed callers that nobody reached afterwards (no later answered call, no call back)."""
    by_number: dict[str, list[dict]] = defaultdict(list)
    for c in calls:
        if c["number"]:
            by_number[c["number"]].append(c)
    out_times: dict[str, list[datetime]] = defaultdict(list)
    for r in outbound:
        if r.caller_normalized:
            out_times[r.caller_normalized].append(as_utc(r.started_at))
    result = []
    for number, cs in by_number.items():
        missed = [c for c in cs if c["outcome"] in ("abandoned", "unanswered") and (until is None or c["start"] < until)]
        if not missed:
            continue
        last_missed = max(c["start"] for c in missed)
        reached = any(c["outcome"] == "answered" and c["start"] > last_missed for c in cs) or \
            any(t > last_missed for t in out_times.get(number, []))
        if not reached:
            result.append({"number": number, "name": next((c["name"] for c in missed if c["name"]), ""),
                           "attempts": len(missed), "last_missed_at": last_missed,
                           "waiting_min": int((now - last_missed).total_seconds() // 60)})
    result.sort(key=lambda x: x["last_missed_at"])
    return result


# ------------------------------------------------------------------ operator state timeline
def state_intervals(events, initial: dict[int, str], start: datetime, end: datetime) -> dict[int, dict[str, list[Interval]]]:
    """events: availability_changed audit rows in [start, end), sorted by ts. initial: state at `start`."""
    timeline: dict[int, list[tuple[datetime, str]]] = defaultdict(list)
    for agent_id, st in initial.items():
        timeline[agent_id].append((start, st))
    for e in events:
        if e.agent_id is None:
            continue
        new = (e.details or {}).get("new")
        if new in STATES:
            timeline[e.agent_id].append((max(as_utc(e.ts), start), new))
    out: dict[int, dict[str, list[Interval]]] = {}
    for agent_id, points in timeline.items():
        points.sort(key=lambda p: p[0])
        per: dict[str, list[Interval]] = defaultdict(list)
        for i, (t0, st) in enumerate(points):
            t1 = points[i + 1][0] if i + 1 < len(points) else end
            if t1 > t0:
                per[st].append((t0, min(t1, end)))
        out[agent_id] = per
    return out


# ------------------------------------------------------------------ main entry
def compute_overview(*, start: datetime, end: datetime, now: datetime, tz: str, agents, states_now,
                     queue_calls, records, sessions, events, initial_states: dict[int, str],
                     sla_sec: int, short_sec: int, sla_target: float) -> dict:
    eff_end = min(end, now)
    try:
        zone = ZoneInfo(tz)
    except Exception:  # noqa: BLE001
        zone = timezone.utc

    in_period = [r for r in records if start <= as_utc(r.started_at) < end]
    calls = customer_calls(queue_calls, records, start, end, now)
    summary = call_summary(calls, sla_sec, short_sec)
    outbound = [r for r in in_period if r.direction == "out"]
    out_by_link: dict[str, list] = defaultdict(list)
    for r in outbound:
        out_by_link[r.linkedid].append(r)
    summary["outbound"] = len(out_by_link)
    summary["outbound_connected"] = sum(1 for rs in out_by_link.values() if any(r.answered_at for r in rs))
    waiting = [c for c in calls if c["outcome"] == "waiting"]
    # callbacks may happen after the period: look at every outbound call up to now
    all_outbound = [r for r in records if r.direction == "out"]
    unreturned = unreturned_missed(customer_calls(queue_calls, records, start, now + timedelta(seconds=1), now), all_outbound, now, end) \
        if eff_end > start else []

    timelines = state_intervals(events, initial_states, start, eff_end)

    # ------------------------------------------------ per operator
    answered_by_link: dict[str, list] = defaultdict(list)
    for r in records:
        if r.answered_at:
            answered_by_link[r.linkedid].append(r)
    rows = []
    agent_ids = {a.id for a in agents}
    for a in agents:
        mine = [r for r in in_period if r.agent_id == a.id]
        inbound = [r for r in mine if r.direction == "in"]
        rang_links = {r.linkedid for r in inbound}
        answered = [r for r in inbound if r.answered_at]
        rona = 0
        for r in inbound:
            if r.answered_at:
                continue
            ended = as_utc(r.ended_at)
            if ended is None and r.state != "missed":
                continue  # still ringing
            ended = ended or as_utc(r.started_at)
            others = [o for o in answered_by_link.get(r.linkedid, []) if o.agent_id != a.id]
            if not any(as_utc(o.answered_at) <= ended + RONA_TOLERANCE for o in others):
                rona += 1
        talk_iv = [iv for r in mine if r.answered_at for iv in [clip(r.answered_at, r.ended_at or now, start, eff_end)] if iv]
        talk_sec = total(talk_iv)
        per = timelines.get(a.id, {})
        secs = {st: total(per.get(st, [])) for st in STATES}
        logged = secs["ready"] + secs["busy_task"] + secs["wrap_up"] + secs["break"]
        available_iv = per.get("ready", []) + per.get("busy_task", []) + per.get("wrap_up", [])
        available = secs["ready"] + secs["busy_task"] + secs["wrap_up"]
        productive = total(intersect(talk_iv + per.get("busy_task", []) + per.get("wrap_up", []), available_iv))
        occupancy = ratio(productive, available) if available >= 60 else None
        break_share = ratio(secs["break"], logged) if logged else None
        ready_share = ratio(secs["ready"], logged) if logged else None
        reliability = ratio(len(answered), len(answered) + rona) if (len(answered) + rona) else None
        engagement = None
        if logged >= MIN_LOGGED_FOR_SCORE:
            engagement = round(100 * (0.5 * (reliability if reliability is not None else 1.0)
                                      + 0.3 * (1 - (break_share or 0))
                                      + 0.2 * min((occupancy or 0) / OCCUPANCY_TARGET, 1.0)))
        ws = [w for w in sessions if w.agent_id == a.id]
        done = [w for w in ws if w.state == "completed" and w.ended_at and start <= as_utc(w.ended_at) < end]
        flags = []
        if rona >= THRESHOLDS["rona_count"] or (len(rang_links) >= 5 and rona / max(1, len(rang_links)) >= THRESHOLDS["rona_rate"]):
            flags.append("rona")
        if logged >= THRESHOLDS["min_logged_sec"] and (break_share or 0) > THRESHOLDS["break_share"]:
            flags.append("long_breaks")
        if logged >= THRESHOLDS["min_logged_sec"] and occupancy is not None and occupancy < THRESHOLDS["low_occupancy"]:
            flags.append("low_occupancy")
        st_now = states_now.get(a.id)
        rows.append({
            "agent_id": a.id, "name": a.display_name, "level": a.level, "position": a.position, "extension": a.extension,
            "state_now": st_now.computed_state if st_now else "offline",
            "calls_rang": len(rang_links), "calls_answered": len({r.linkedid for r in answered}), "rona": rona,
            "answer_reliability": reliability,
            "outbound": len({r.linkedid for r in mine if r.direction == "out"}),
            "talk_sec": int(talk_sec),
            "aht_talk_sec": mean([(as_utc(r.ended_at) - as_utc(r.answered_at)).total_seconds()
                                  for r in answered if r.ended_at]),
            "tickets_started": sum(1 for w in ws if start <= as_utc(w.started_at) < end),
            "tickets_completed": len(done),
            "avg_ticket_work_sec": mean([(as_utc(w.ended_at) - as_utc(w.started_at)).total_seconds() for w in done]),
            "logged_in_sec": int(logged), "ready_sec": int(secs["ready"]), "busy_task_sec": int(secs["busy_task"]),
            "wrap_up_sec": int(secs["wrap_up"]), "break_sec": int(secs["break"]),
            "productive_sec": int(productive), "occupancy": occupancy, "ready_share": ready_share, "break_share": break_share,
            "engagement": engagement, "flags": flags,
        })
    rows.sort(key=lambda r: (-(r["engagement"] if r["engagement"] is not None else -1), -r["calls_answered"], r["name"]))

    # ------------------------------------------------ team totals and workload
    team_available = sum(r["ready_sec"] + r["busy_task_sec"] + r["wrap_up_sec"] for r in rows)
    team_productive = sum(r["productive_sec"] for r in rows)
    ws_all = [w for w in sessions if w.agent_id in agent_ids]
    completed = [w for w in ws_all if w.state == "completed" and w.ended_at and start <= as_utc(w.ended_at) < end]
    by_channel: dict[str, int] = defaultdict(int)
    for w in completed:
        by_channel[w.source or "other"] += 1
    tickets = {
        "started": sum(1 for w in ws_all if start <= as_utc(w.started_at) < end),
        "completed": len(completed),
        "avg_work_sec": mean([(as_utc(w.ended_at) - as_utc(w.started_at)).total_seconds() for w in completed]),
        "active_blocking": sum(1 for w in ws_all if w.state == "active" and w.work_mode == "blocking"),
        "active_background": sum(1 for w in ws_all if w.state == "active" and w.work_mode == "background"),
        "by_channel": dict(sorted(by_channel.items(), key=lambda kv: -kv[1])),
    }

    # ------------------------------------------------ buckets (hours for one day, days for longer periods)
    hourly = (end - start) <= timedelta(hours=25)
    buckets = []
    cur = start
    while cur < end:
        nxt = cur + timedelta(hours=1) if hourly else \
            datetime.combine(cur.astimezone(zone).date() + timedelta(days=1), datetime.min.time(), tzinfo=zone).astimezone(timezone.utc)
        nxt = min(nxt, end)
        buckets.append((cur, nxt))
        cur = nxt
    staffed: list[Interval] = []
    for per in timelines.values():
        staffed += per.get("ready", []) + per.get("busy_task", []) + per.get("wrap_up", []) + per.get("break", [])
    talk_all = [iv for r in in_period if r.answered_at and r.agent_id in agent_ids
                for iv in [clip(r.answered_at, r.ended_at or now, start, eff_end)] if iv]
    series = []
    for b0, b1 in buckets:
        cs = [c for c in calls if b0 <= c["start"] < b1 and c["outcome"] != "waiting"]
        sm = call_summary(cs, sla_sec, short_sec)
        length = (min(b1, eff_end) - b0).total_seconds()
        staffed_sec = sum((min(b, b1) - max(a, b0)).total_seconds() for a, b in staffed if min(b, b1) > max(a, b0))
        talk_sec = sum((min(b, b1) - max(a, b0)).total_seconds() for a, b in talk_all if min(b, b1) > max(a, b0))
        series.append({
            "start": b0, "label": b0.astimezone(zone).strftime("%H:%M" if hourly else "%d.%m"),
            "offered": sm["offered"], "answered": sm["answered"], "missed": sm["missed"], "service_level": sm["service_level"],
            "tickets_completed": sum(1 for w in completed if b0 <= as_utc(w.ended_at) < b1),
            "agents_avg": round(staffed_sec / length, 2) if length > 0 else None,
            "erlangs": round(talk_sec / length, 2) if length > 0 else None,
            "future": b0 >= now,
        })
    peak = max((s for s in series if s["offered"]), key=lambda s: s["offered"], default=None)

    counts_now = defaultdict(int)
    for a in agents:
        st = states_now.get(a.id)
        counts_now[st.computed_state if st else "offline"] += 1
    talking_now = sum(1 for r in records if r.answered_at and not r.ended_at and now - as_utc(r.answered_at) < STALE_WAIT
                      and r.agent_id in agent_ids)

    return {
        "from": start, "to": end, "now": now, "timezone": tz, "bucket": "hour" if hourly else "day",
        "settings": {"sla_answer_seconds": sla_sec, "short_abandon_seconds": short_sec, "sla_target": sla_target,
                     "occupancy_target": OCCUPANCY_TARGET, "thresholds": THRESHOLDS},
        "calls": summary,
        "live": {
            "waiting": len(waiting),
            "longest_wait_sec": int(max((now - c["start"]).total_seconds() for c in waiting)) if waiting else 0,
            "talking": talking_now,
            "agents": {st: counts_now.get(st, 0) for st in STATES},
        },
        "team": {
            "logged_in_sec": sum(r["logged_in_sec"] for r in rows),
            "productive_sec": team_productive,
            "occupancy": ratio(team_productive, team_available) if team_available >= 60 else None,
            "break_sec": sum(r["break_sec"] for r in rows),
            "agents_worked": sum(1 for r in rows if r["logged_in_sec"] > 0),
        },
        "tickets": tickets,
        "series": series,
        "peak": {"label": peak["label"], "offered": peak["offered"]} if peak else None,
        "agents": rows,
        "leaders": {
            "answered": [{"agent_id": r["agent_id"], "name": r["name"], "value": r["calls_answered"]}
                         for r in sorted(rows, key=lambda r: -r["calls_answered"]) if r["calls_answered"]][:5],
            "tickets": [{"agent_id": r["agent_id"], "name": r["name"], "value": r["tickets_completed"]}
                        for r in sorted(rows, key=lambda r: -r["tickets_completed"]) if r["tickets_completed"]][:5],
        },
        "unreturned": [{**u, "last_missed_at": u["last_missed_at"]} for u in unreturned][:50],
        "unreturned_count": len(unreturned),
    }
