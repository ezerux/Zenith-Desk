"""v3.18 API keys: other programs call the Zenith Desk API.

A key looks like ``zdk_<prefix>_<secret>`` and is sent as ``Authorization: Bearer zdk_…`` or ``X-API-Key: zdk_…``.
It acts as the user the administrator chose (with that user's rights). Options: read-only (GET only), allowed
addresses (IPs / networks), an expiry date. Only a SHA-256 of the key is stored; the key is shown once.
A key can never manage API keys or change a password, and is limited to RATE requests a minute.
"""
from __future__ import annotations

import hashlib
import hmac
import ipaddress
import secrets
import time
from collections import defaultdict, deque
from datetime import timedelta

from sqlalchemy import select

from .db import as_utc, utcnow
from .models import ApiKey

PREFIX = "zdk_"
RATE = 1200          # requests per minute and key
USE_EVERY = 60       # seconds: how often «last used» is written (not on every request)
READ_METHODS = {"GET", "HEAD", "OPTIONS"}
READ_ONLY_POSTS = {"/api/auth/stream-token"}  # a read-only key may still open the live event stream
NEVER = ("/api/admin/api-keys", "/api/auth/change-password", "/api/auth/logout")
_hits: dict[str, deque] = defaultdict(deque)
_written: dict[str, float] = {}
_pending: dict[str, int] = defaultdict(int)


class KeyRefused(Exception):
    def __init__(self, status: int, code: str):
        super().__init__(code)
        self.status, self.code = status, code


def new_key() -> tuple[str, str, str]:
    """(full key, public prefix, hash to store)"""
    prefix = secrets.token_hex(4)
    full = f"{PREFIX}{prefix}_{secrets.token_urlsafe(32)}"
    return full, prefix, digest(full)


def digest(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def parse_networks(text: str) -> list:
    out = []
    for part in (text or "").replace(";", ",").replace("\n", ",").split(","):
        part = part.strip()
        if part:
            out.append(ipaddress.ip_network(part, strict=False))  # ValueError for nonsense
    return out


def ip_allowed(allowed: str, ip: str) -> bool:
    nets = parse_networks(allowed)
    if not nets:
        return True
    try:
        addr = ipaddress.ip_address((ip or "").strip("[]"))
    except ValueError:
        return False
    return any(addr in n for n in nets)


def is_key(token: str | None) -> bool:
    return bool(token) and token.startswith(PREFIX)


async def check(services, token: str, method: str, path: str, ip: str) -> ApiKey:
    """The key row if this request may use it, else KeyRefused."""
    parts = token.split("_", 2)
    if len(parts) != 3 or not parts[1]:
        raise KeyRefused(401, "api.bad_key")
    async with services.db.sessionmaker() as s:
        k = (await s.execute(select(ApiKey).where(ApiKey.prefix == parts[1]))).scalars().first()
        if k is None or not hmac.compare_digest(k.secret_hash, digest(token)):
            raise KeyRefused(401, "api.bad_key")
        now = utcnow()
        if k.revoked_at is not None:
            raise KeyRefused(401, "api.revoked")
        if k.expires_at is not None and as_utc(k.expires_at) <= now:
            raise KeyRefused(401, "api.expired")
        if not ip_allowed(k.allowed_ips, ip):
            raise KeyRefused(403, "api.ip")
        if path.startswith(NEVER):
            raise KeyRefused(403, "api.not_with_key")
        if k.read_only and method.upper() not in READ_METHODS and path not in READ_ONLY_POSTS:
            raise KeyRefused(403, "api.read_only")
        mono = time.monotonic()
        hits = _hits[k.prefix]
        while hits and mono - hits[0] > 60:
            hits.popleft()
        if len(hits) >= RATE:
            raise KeyRefused(429, "api.rate")
        hits.append(mono)
        _pending[k.prefix] += 1
        last = _written.get(k.prefix)
        # «last used» without a database write on every call; the first use is always written (v3.18.1: monotonic time
        # starts at boot, so «0» as the default missed the first use on a server up for less than a minute)
        if last is None or mono - last >= USE_EVERY:
            _written[k.prefix] = mono
            k.last_used_at, k.last_used_ip = now, (ip or "")[:64]
            k.uses = (k.uses or 0) + _pending.pop(k.prefix, 0)
            await s.commit()
        s.expunge(k)
        return k


def view(k: ApiKey, names: dict[int, str] | None = None) -> dict:
    now = utcnow()
    state = "revoked" if k.revoked_at else "expired" if (k.expires_at and as_utc(k.expires_at) <= now) else "active"
    return {"id": k.id, "name": k.name, "prefix": f"{PREFIX}{k.prefix}_…", "agent_id": k.agent_id,
            "agent": (names or {}).get(k.agent_id, ""), "read_only": k.read_only, "allowed_ips": k.allowed_ips,
            "expires_at": as_utc(k.expires_at), "created_at": as_utc(k.created_at), "created_by": k.created_by,
            "last_used_at": as_utc(k.last_used_at), "last_used_ip": k.last_used_ip, "uses": k.uses or 0,
            "revoked_at": as_utc(k.revoked_at), "state": state}


def expiry(days: int | None):
    return utcnow() + timedelta(days=days) if days else None
