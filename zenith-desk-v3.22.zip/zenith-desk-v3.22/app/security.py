"""Security headers and HTTPS enforcement (v3.1).

Pure ASGI (not BaseHTTPMiddleware), so live SSE streams are never buffered.
* Every response: no MIME sniffing, no framing (click-jacking), no referrer leaks, no camera/geolocation;
  the microphone only for Zenith Desk itself (v3.5 Zenith Phone).
* App pages: Content-Security-Policy — scripts, styles, fonts and connections only from Zenith Desk itself.
  ('unsafe-eval' is needed by the Vue template compiler; inline <script> is still forbidden.)
* HTTPS (directly or behind the proxy): HSTS, so browsers never fall back to plain HTTP.
* FORCE_HTTPS=true: plain-HTTP requests are redirected to HTTPS (behind a TLS proxy that sets X-Forwarded-Proto).
"""
from urllib.parse import quote

CSP = ("default-src 'self'; script-src 'self' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; media-src 'self' blob:; "
       "font-src 'self'; connect-src 'self'; worker-src 'self'; manifest-src 'self'; frame-ancestors 'none'; "
       "base-uri 'self'; form-action 'self'; object-src 'none'")
COMMON = [(b"x-content-type-options", b"nosniff"), (b"referrer-policy", b"same-origin"), (b"x-frame-options", b"DENY"),
          (b"permissions-policy", b"camera=(), microphone=(self), geolocation=(), payment=()"),
          (b"cross-origin-opener-policy", b"same-origin")]
LOCAL = ("localhost", "127.0.0.1", "::1")


class SecurityHeaders:
    def __init__(self, app, force_https: bool = False, connect_sources=None):
        # connect_sources(): extra origins the page may connect to, e.g. the FreePBX WebSocket (v3.5)
        self.app, self.force_https, self.connect_sources = app, force_https, connect_sources

    def csp(self) -> bytes:
        extra = []
        if self.connect_sources:
            try:
                extra = [s for s in self.connect_sources() if s and all(c not in s for c in " ;'\"\n")]
            except Exception:  # noqa: BLE001
                extra = []
        if not extra:
            return CSP.encode()
        return CSP.replace("connect-src 'self'", "connect-src 'self' " + " ".join(extra)).encode()

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers") or [])
        proto = headers.get(b"x-forwarded-proto", scope.get("scheme", "http").encode()).decode().split(",")[0].strip()
        host = headers.get(b"host", b"").decode()
        path = scope.get("path", "")
        if self.force_https and proto == "http" and host.split(":")[0] not in LOCAL and path not in ("/api/health", "/api/desktop/hello"):
            query = scope.get("query_string", b"").decode()
            location = f"https://{host}{quote(path)}" + (f"?{query}" if query else "")
            await send({"type": "http.response.start", "status": 308, "headers": [(b"location", location.encode()), *COMMON]})
            return await send({"type": "http.response.body", "body": b""})
        api_docs = path.startswith(("/docs", "/redoc", "/openapi.json"))  # Swagger UI loads its own assets

        api = path.startswith("/api/") and not path.startswith(("/api/avatars/", "/api/health"))

        async def wrapped(message):
            if message["type"] == "http.response.start":
                extra = list(COMMON)
                names = {k.lower() for k, _ in message.get("headers", [])}
                if api and b"cache-control" not in names:  # v3.17: personal data is never kept in browser / proxy caches
                    extra.append((b"cache-control", b"no-store"))
                if not api_docs:
                    extra.append((b"content-security-policy", self.csp()))
                if proto == "https":
                    extra.append((b"strict-transport-security", b"max-age=31536000; includeSubDomains"))
                message = {**message, "headers": [*message.get("headers", []), *extra]}
            await send(message)
        return await self.app(scope, receive, wrapped)


class BodyLimit:
    """v3.17: refuse request bodies over `max_request_mb` (public webhooks: 5 MB), so nobody can exhaust the server's
    memory with one huge request. The backup upload streams to disk and has its own limit."""
    WEBHOOK_MB = 5
    EXEMPT = ("/api/admin/backups/upload",)

    def __init__(self, app, settings):
        self.app, self.settings = app, settings

    def limit(self, path: str) -> int:
        if path.startswith(self.EXEMPT):
            return 0
        if "/webhook" in path:
            return self.WEBHOOK_MB * 1024 * 1024
        return max(1, int(self.settings.max_request_mb or 64)) * 1024 * 1024

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope.get("method") in ("GET", "HEAD", "OPTIONS"):
            return await self.app(scope, receive, send)
        limit = self.limit(scope.get("path", ""))
        if not limit:
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers") or [])
        try:
            declared = int(headers.get(b"content-length", b"0") or 0)
        except ValueError:
            declared = 0
        if declared > limit:
            return await _too_large(send)
        seen = 0

        async def counted():
            nonlocal seen
            message = await receive()
            if message["type"] == "http.request":
                seen += len(message.get("body", b""))
                if seen > limit:
                    raise _TooLarge()
            return message
        started = False

        async def tracked(message):
            nonlocal started
            if message["type"] == "http.response.start":
                started = True
            await send(message)
        try:
            await self.app(scope, counted, tracked)
        except _TooLarge:
            if not started:
                await _too_large(send)


from starlette.exceptions import HTTPException as _HTTPException  # noqa: E402


class _TooLarge(_HTTPException):
    def __init__(self):
        super().__init__(413, "request too large")


async def _too_large(send):
    body = b'{"detail":"request too large"}'
    await send({"type": "http.response.start", "status": 413,
                "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(body)).encode()), *COMMON]})
    await send({"type": "http.response.body", "body": body})
