"""v3.11 — ticketing like the operator's own Zammad.

* **Overviews** come straight from Zammad (`GET /api/v1/ticket_overviews`, in the operator's name): the same list,
  names, order and counts as in Zammad — «Назначенные мне», «Не назначенные и открытые», «Открытые», «My Closed
  Tickets», custom ones like «On-site Requests». A list is the overview's tickets in Zammad's order (up to Zammad's
  limit of 2000), filtered, sorted and paged here.
* **Tabs**: tickets the operator opened and **drafts** of new tickets, kept on the server (task bar of Zammad).
  A draft is created in Zammad only by «Create» — group, owner, state, priority, tags, customer, text first.
* **Groups** (Cabling, IT Security, IT Support …) are Zammad groups; the administrator creates, renames, switches
  them off and gives agents access from the Zenith Desk panel.
"""
from __future__ import annotations

import asyncio
import time
from datetime import datetime

from sqlalchemy import delete, select

from .audit import audit
from .db import utcnow
from .directory import full_name, has_full_access
from .i18n import t as tr
from .models import AgentMapping, TicketTab, ZammadUser
from .ticketing import TicketError, category
from .zammad import ZammadError

OVERVIEW_TTL = 8.0
SORT_KEYS = {"number", "title", "customer", "organization", "group", "state", "priority", "owner", "created_at", "updated_at"}
DRAFT_FIELDS = {"title", "customer", "group", "owner_id", "state", "priority", "tags", "body", "type", "fields", "article_type",
                "phone", "call_id"}  # v3.14: phone + call_id = the draft was opened from a call
MAX_TABS = 40


def _name(u: dict | None) -> str:
    if not u:
        return ""
    n = f"{u.get('firstname') or ''} {u.get('lastname') or ''}".strip()
    return n or u.get("login") or u.get("email") or ""


class DeskViews:
    def __init__(self, desk):
        self.desk = desk
        self.sv = desk.sv
        self._cache: dict[tuple[int, str], tuple[float, dict]] = {}
        self._locks: dict[tuple[int, str], asyncio.Lock] = {}

    @property
    def z(self):
        return self.sv.zammad

    def forget(self) -> None:
        """A ticket changed somewhere: the next look at any overview asks Zammad again."""
        self._cache.clear()

    # ================================================================== overviews
    async def overviews(self, agent: AgentMapping) -> list[dict]:
        uid = self.desk._need_link(agent)
        try:
            rows = await self.z.overviews(uid)
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc
        out = [{"id": r.get("id"), "name": r.get("name") or r.get("link"), "link": r.get("link"), "count": int(r.get("count") or 0),
                "prio": r.get("prio") or 0} for r in rows if isinstance(r, dict) and r.get("link")]
        out.sort(key=lambda o: (o["prio"], o["name"]))
        return out

    async def _overview_raw(self, uid: int, link: str, fresh: bool = False) -> dict:
        key = (uid, link)
        hit = self._cache.get(key)
        if hit and not fresh and time.monotonic() - hit[0] < OVERVIEW_TTL:
            return hit[1]
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            hit = self._cache.get(key)
            if hit and not fresh and time.monotonic() - hit[0] < OVERVIEW_TTL:
                return hit[1]
            data = await self.z.overview(link, uid)
            self._cache[key] = (time.monotonic(), data)
            if len(self._cache) > 300:
                for k in list(self._cache)[:100]:
                    self._cache.pop(k, None)
            return data

    async def overview(self, agent: AgentMapping, link: str, *, q: str = "", group: str = "", state: str = "", priority: str = "",
                       owner: str = "", sort: str = "", direction: str = "", page: int = 1, per_page: int = 50,
                       fresh: bool = False) -> dict:
        uid = self.desk._need_link(agent)
        unassigned = self.sv.settings.zammad_unassigned_owner_id
        try:
            data = await self._overview_raw(uid, link, fresh)
            by_id, _ = await self.desk._state_maps()
            prios = {p["id"]: p["name"] for p in await self.z.priorities()}
            groups = {g["id"]: g["name"] for g in await self.z.groups(None)}
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc
        index = data.get("index") or {}
        if not index:
            raise TicketError(404, tr("tk.no_overview"))
        assets = data.get("assets") or {}
        tickets = assets.get("Ticket") or {}
        users = assets.get("User") or {}
        orgs = assets.get("Organization") or {}
        rows = []
        for meta in index.get("tickets") or []:
            t = tickets.get(str(meta.get("id"))) or tickets.get(meta.get("id"))
            if not t:
                continue
            st = by_id.get(int(t.get("state_id") or 0)) or {}
            owner_id = t.get("owner_id")
            if owner_id in (None, unassigned):
                owner_id = None
            cust = users.get(str(t.get("customer_id"))) or {}
            org = orgs.get(str(t.get("organization_id") or cust.get("organization_id") or "")) or {}
            rows.append({
                "id": t.get("id"), "number": str(t.get("number") or ""), "title": t.get("title") or "",
                "customer_id": t.get("customer_id"), "customer": _name(cust), "organization": org.get("name") or "",
                "group_id": t.get("group_id"), "group": groups.get(t.get("group_id"), ""),
                "state_id": t.get("state_id"), "state": st.get("name", ""), "category": category(st.get("type", "")),
                "priority_id": t.get("priority_id"), "priority": prios.get(t.get("priority_id"), ""),
                "owner_id": owner_id, "owner": _name(users.get(str(owner_id))) if owner_id else "",
                "created_at": t.get("created_at"), "updated_at": t.get("updated_at"), "pending_time": t.get("pending_time"),
                "escalation_at": t.get("escalation_at"), "mine": owner_id == uid,
            })
        facets = {
            "groups": sorted({r["group"] for r in rows if r["group"]}),
            "states": sorted({r["state"] for r in rows if r["state"]}),
            "priorities": sorted({r["priority"] for r in rows if r["priority"]}),
            "owners": sorted({(r["owner_id"], r["owner"]) for r in rows if r["owner_id"]}, key=lambda x: x[1].lower()),
        }
        ql = q.strip().lower()
        if ql:
            rows = [r for r in rows if ql in f"{r['number']} {r['title']} {r['customer']} {r['organization']}".lower()]
        if group:
            rows = [r for r in rows if r["group"] == group]
        if state:
            rows = [r for r in rows if r["state"] == state or r["category"] == state]
        if priority:
            rows = [r for r in rows if r["priority"] == priority]
        if owner == "none":
            rows = [r for r in rows if not r["owner_id"]]
        elif owner == "me":
            rows = [r for r in rows if r["owner_id"] == uid]
        elif owner.isdigit():
            rows = [r for r in rows if r["owner_id"] == int(owner)]
        if sort in SORT_KEYS:
            rows.sort(key=lambda r: str(r.get(sort) or "").lower() if sort not in ("number",) else int(r["number"] or 0),
                      reverse=direction == "desc")
        per_page = max(10, min(per_page, 200))
        total = len(rows)
        page = max(1, page)
        shown = rows[(page - 1) * per_page: page * per_page]
        ov = index.get("overview") or {}
        count = int(index.get("count") or 0)
        return {
            "overview": {"id": ov.get("id"), "name": ov.get("name") or link, "link": ov.get("view") or link, "count": count},
            "tickets": shown, "total": total, "page": page, "per_page": per_page,
            "loaded": len(index.get("tickets") or []), "limited": count > len(index.get("tickets") or []),
            "facets": {**facets, "owners": [{"id": i, "name": n} for i, n in facets["owners"]]},
        }

    # ================================================================== tabs and drafts
    @staticmethod
    def tab_view(t: TicketTab) -> dict:
        return {"id": t.id, "kind": t.kind, "ticket_id": t.ticket_id, "number": t.number, "title": t.title,
                "draft": t.draft if t.kind == "draft" else None,
                "opened_at": t.opened_at.isoformat() if isinstance(t.opened_at, datetime) else t.opened_at}

    async def tabs(self, agent: AgentMapping, with_state: bool = False) -> list[dict]:
        async with self.sv.db.sessionmaker() as s:
            rows = (await s.execute(select(TicketTab).where(TicketTab.agent_id == agent.id).order_by(TicketTab.id))).scalars().all()
        out = [self.tab_view(t) for t in rows]
        if with_state:
            await self._add_states(agent, out)
        return out

    async def _add_states(self, agent: AgentMapping, tabs: list[dict]) -> None:
        """The current state of each ticket behind a tab (read as the operator; a ticket he can't see stays unknown)."""
        ids = [t["ticket_id"] for t in tabs if t["kind"] == "ticket" and t["ticket_id"]]
        if not ids or not agent.zammad_user_id:
            return
        try:
            by_id, _ = await self.desk._state_maps()
        except Exception:  # noqa: BLE001 — the dots are a hint, the tabs must still open
            return
        gate = asyncio.Semaphore(8)

        async def one(tid: int):
            async with gate:
                try:
                    return tid, await self.z.get_ticket(tid, on_behalf_of=agent.zammad_user_id)
                except Exception:  # noqa: BLE001
                    return tid, None
        found = dict(await asyncio.gather(*(one(i) for i in ids)))
        for t in tabs:
            tk = found.get(t["ticket_id"])
            if tk:
                st = by_id.get(int(tk.get("state_id") or 0)) or {}
                t["state"], t["category"] = st.get("name", ""), category(st.get("type", ""))

    async def open_tab(self, agent: AgentMapping, ticket_id: int, number: str = "", title: str = "") -> dict:
        async with self.sv.db.sessionmaker() as s:
            t = (await s.execute(select(TicketTab).where(TicketTab.agent_id == agent.id, TicketTab.ticket_id == ticket_id))).scalars().first()
            if t is None:
                await self._trim(s, agent.id)
                t = TicketTab(agent_id=agent.id, kind="ticket", ticket_id=ticket_id)
                s.add(t)
            if number:
                t.number = number[:50]
            if title:
                t.title = title[:255]
            await s.commit()
            return self.tab_view(t)

    async def _trim(self, s, agent_id: int) -> None:
        """Keep at most MAX_TABS open tickets (the oldest ticket tabs close; drafts are never dropped)."""
        rows = (await s.execute(select(TicketTab).where(TicketTab.agent_id == agent_id, TicketTab.kind == "ticket")
                                .order_by(TicketTab.updated_at))).scalars().all()
        for t in rows[: max(0, len(rows) - MAX_TABS + 1)]:
            await s.delete(t)

    async def new_draft(self, agent: AgentMapping, data: dict | None = None) -> dict:
        draft = self._clean_draft(data or {})
        if not draft.get("group"):
            draft["group"] = self.sv.settings.zammad_default_group
        async with self.sv.db.sessionmaker() as s:
            t = TicketTab(agent_id=agent.id, kind="draft", title=(draft.get("title") or "")[:255], draft=draft)
            s.add(t)
            await s.commit()
            audit(s, "ticket_draft", agent_id=agent.id, actor_type="agent", actor_id=agent.id, tab=t.id)
            await s.commit()
            return self.tab_view(t)

    @staticmethod
    def _clean_draft(data: dict) -> dict:
        out = {k: v for k, v in (data or {}).items() if k in DRAFT_FIELDS}
        if isinstance(out.get("tags"), str):
            out["tags"] = [x.strip() for x in out["tags"].split(",") if x.strip()]
        if "tags" in out:
            out["tags"] = [str(x)[:100] for x in out["tags"] or []][:30]
        for k in ("title", "body"):
            if k in out:
                out[k] = str(out[k] or "")[: 250 if k == "title" else 60000]
        if "phone" in out:  # v3.14: the number of the call the draft was opened from
            out["phone"] = "".join(ch for ch in str(out["phone"] or "") if ch.isdigit() or ch in "+*#")[:40]
        if "call_id" in out:
            try:
                out["call_id"] = int(out["call_id"]) if out["call_id"] else None
            except (TypeError, ValueError):
                out["call_id"] = None
        cust = out.get("customer")
        if cust is not None and not (isinstance(cust, dict) and cust.get("id")):
            out["customer"] = None
        elif isinstance(cust, dict):
            out["customer"] = {k: cust.get(k) for k in ("id", "name", "email", "phone", "mobile", "organization")}
        return out

    async def _own_tab(self, s, agent: AgentMapping, tab_id: int) -> TicketTab:
        t = await s.get(TicketTab, tab_id)
        if t is None or t.agent_id != agent.id:
            raise TicketError(404, tr("tk.no_tab"))
        return t

    async def save_draft(self, agent: AgentMapping, tab_id: int, data: dict) -> dict:
        async with self.sv.db.sessionmaker() as s:
            t = await self._own_tab(s, agent, tab_id)
            if t.kind != "draft":
                raise TicketError(409, tr("tk.not_draft"))
            t.draft = {**(t.draft or {}), **self._clean_draft(data)}
            t.title = (t.draft.get("title") or "")[:255]
            t.updated_at = utcnow()
            await s.commit()
            return self.tab_view(t)

    async def close_tab(self, agent: AgentMapping, tab_id: int) -> None:
        async with self.sv.db.sessionmaker() as s:
            await s.execute(delete(TicketTab).where(TicketTab.id == tab_id, TicketTab.agent_id == agent.id))
            await s.commit()

    async def create_from_draft(self, agent: AgentMapping, tab_id: int, start_mode: str | None = None) -> dict:
        """«Create»: the draft becomes a real Zammad ticket (in the operator's name) and the tab shows it."""
        from .models import TicketType  # noqa: PLC0415
        uid = self.desk._need_link(agent)
        async with self.sv.db.sessionmaker() as s:
            t = await self._own_tab(s, agent, tab_id)
            if t.kind != "draft":
                raise TicketError(409, tr("tk.not_draft"))
            d = dict(t.draft or {})
            tt = None
            if d.get("type"):
                tt = (await s.execute(select(TicketType).where(TicketType.name == d["type"]))).scalars().first()
        missing = [tr(f"tk.f.{k}") for k in ("title", "customer", "group", "state", "priority") if not d.get(k)]
        if missing:
            raise TicketError(422, tr("tk.draft_missing", fields=", ".join(missing)), {"missing": missing})
        attrs: dict = {}
        if tt is not None:
            attrs = dict(d.get("fields") or {})
            attrs[self.sv.settings.zammad_ticket_type_attribute] = tt.zammad_value
            req = [f.get("label") or f["name"] for f in tt.required_fields or [] if attrs.get(f["name"]) in (None, "", [])]
            if req:
                raise TicketError(422, tr("err.required_fields", fields=", ".join(req)), {"missing": req})
        cust = d["customer"]
        body = (d.get("body") or "").strip()
        # v3.14: a draft opened from a call carries the call (its details go into the ticket, the call gets the link)
        call = None
        call_text = ""
        if d.get("call_id"):
            from .models import CallRecord  # noqa: PLC0415
            async with self.sv.db.sessionmaker() as s:
                call = await s.get(CallRecord, int(d["call_id"]))
            if call is not None and call.agent_id == agent.id:
                call_text = self.sv.calls.call_info(call)
            else:
                call = None
        if not call_text and (d.get("phone") or "").strip():
            call_text = tr("tk.caller", number=str(d["phone"]).strip()[:40])
        if call_text:
            body = "\n\n".join(filter(None, [body, call_text]))
        payload: dict = {
            "title": d["title"].strip(), "group": d["group"], "customer_id": int(cust["id"]), "state": d["state"],
            "priority": d["priority"],
            "article": {"subject": d["title"].strip(), "body": body or d["title"].strip(),
                        "type": "phone" if call_text else (d.get("article_type") if d.get("article_type") in ("phone", "note", "web") else "note"),
                        "internal": False, "sender": "Agent", "content_type": "text/plain"},
            **attrs,
        }
        if d.get("owner_id"):
            payload["owner_id"] = int(d["owner_id"])
        if d.get("tags"):
            payload["tags"] = ",".join(d["tags"])
        _, by_name = await self.desk._state_maps()
        st = by_name.get(str(d["state"]).lower())
        if st is None:
            raise TicketError(422, tr("tk.bad_state", state=d["state"]))
        if st["type"].startswith("pending"):
            from datetime import timedelta  # noqa: PLC0415
            payload["pending_time"] = (utcnow() + timedelta(days=1)).replace(microsecond=0).isoformat()
        ticket = await self.desk.create(agent, payload)
        owner_dropped = bool(d.get("owner_id")) and ticket.get("owner_id") != int(d["owner_id"])
        async with self.sv.db.sessionmaker() as s:
            t = await self._own_tab(s, agent, tab_id)
            other = (await s.execute(select(TicketTab).where(TicketTab.agent_id == agent.id, TicketTab.ticket_id == ticket["id"]))).scalars().first()
            if other is not None:
                await s.delete(t)
                t = other
            else:
                t.kind, t.ticket_id, t.draft = "ticket", int(ticket["id"]), None
            t.number, t.title = str(ticket.get("number") or "")[:50], (ticket.get("title") or "")[:255]
            if call is not None:
                from .models import CallRecord  # noqa: PLC0415
                c = await s.get(CallRecord, call.id)
                c.ticket_id = ticket["id"]
            audit(s, "ticket_created", agent_id=agent.id, ticket_id=ticket["id"], actor_type="agent", actor_id=agent.id,
                  number=str(ticket.get("number") or ""), from_draft=True, tags=d.get("tags") or None,
                  call_id=call.id if call is not None else None)
            await s.commit()
            tab = self.tab_view(t)
        self.forget()
        result: dict = {"tab": tab, "ticket": {"id": ticket["id"], "number": ticket.get("number"), "title": ticket.get("title")},
                        "owner_dropped": owner_dropped}
        if start_mode:
            from .workflow import Actor  # noqa: PLC0415
            result.update(await self.sv.workflow.start_work(agent, ticket["id"], start_mode, Actor("agent", agent.id)))
        del uid
        return result

    # ================================================================== tags
    async def set_tags(self, agent: AgentMapping, ticket_id: int, wanted: list[str]) -> list[str]:
        uid = self.desk._need_link(agent)
        wanted = [w.strip()[:100] for w in wanted if w and w.strip()]
        try:
            have = await self.z.tags(ticket_id, uid)
            for w in wanted:
                if w not in have:
                    await self.z.tag_add(ticket_id, w, uid)
            for h in have:
                if h not in wanted:
                    await self.z.tag_remove(ticket_id, h, uid)
            return await self.z.tags(ticket_id, uid)
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc

    async def tag_search(self, agent: AgentMapping, term: str) -> list[str]:
        uid = self.desk._need_link(agent)
        try:
            return await self.z.tag_search(term, uid)
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc

    # ================================================================== owners for a group
    async def group_assignees(self, agent: AgentMapping, group: str) -> dict:
        uid = self.desk._need_link(agent)
        try:
            groups = await self.z.groups(uid)
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc
        gid = next((g["id"] for g in groups if group in (g["name"], g["full_name"])), None)
        people = await self.sv.directory.agents_for_group(group, gid)
        async with self.sv.db.sessionmaker() as s:
            links = {m.zammad_user_id: m for m in (await s.execute(select(AgentMapping).where(
                AgentMapping.zammad_user_id.is_not(None), AgentMapping.active.is_(True)))).scalars().all()}
        out = [{"id": p.id, "name": links[p.id].display_name if p.id in links else full_name(p), "email": p.email,
                "me": p.id == uid, "level": links[p.id].level if p.id in links else None} for p in people]
        out.sort(key=lambda x: (not x["me"], x["name"].lower()))
        return {"group": group, "people": out}

    # ================================================================== administrator: Zammad groups
    async def admin_groups(self) -> dict:
        try:
            rows = await self.z.all_groups()
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc
        async with self.sv.db.sessionmaker() as s:
            staff = (await s.execute(select(ZammadUser).where(ZammadUser.is_agent.is_(True), ZammadUser.active.is_(True))
                                     .order_by(ZammadUser.firstname, ZammadUser.lastname))).scalars().all()
            links = {m.zammad_user_id: m for m in (await s.execute(select(AgentMapping).where(
                AgentMapping.zammad_user_id.is_not(None)))).scalars().all()}
        groups = []
        for g in rows:
            if not isinstance(g, dict):
                continue
            name = g.get("name_last") or g.get("name") or ""
            members = [{"id": u.id, "name": full_name(u), "email": u.email, "user": links[u.id].display_name if u.id in links else ""}
                       for u in staff if has_full_access(u.groups or {}, g.get("name") or name, int(g["id"]))]
            groups.append({"id": int(g["id"]), "name": name, "full_name": g.get("name") or name, "active": g.get("active", True) is not False,
                           "note": g.get("note") or "", "members": members})
        groups.sort(key=lambda x: (not x["active"], x["name"].lower()))
        agents = [{"id": u.id, "name": full_name(u), "email": u.email, "user": links[u.id].display_name if u.id in links else ""} for u in staff]
        return {"groups": groups, "agents": agents, "directory_synced": self.sv.directory.last_sync is not None}

    async def admin_save_group(self, admin: AgentMapping, group_id: int | None, name: str, active: bool = True, note: str = "") -> dict:
        data = {"name": name.strip()[:160], "active": bool(active), "note": (note or "")[:250]}
        if not data["name"]:
            raise TicketError(422, tr("tk.group_name"))
        try:
            g = await (self.z.update_group(group_id, data) if group_id else self.z.create_group(data))
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc
        async with self.sv.db.sessionmaker() as s:
            audit(s, "zammad_group_saved", actor_type="admin", actor_id=admin.id, group_id=int(g.get("id") or group_id or 0),
                  name=data["name"], active=data["active"], created=not group_id)
            await s.commit()
        return await self.admin_groups()

    async def admin_set_access(self, admin: AgentMapping, group_id: int, zammad_user_id: int, access: bool) -> dict:
        """Give / take an agent's full access to a group in Zammad (the rest of his group access is kept)."""
        try:
            current = await self.z.user_group_ids(zammad_user_id)
            if access:
                current[str(group_id)] = ["full"]
            else:
                current.pop(str(group_id), None)
            await self.z.set_user_group_ids(zammad_user_id, current)
            await self.sv.directory.refresh_user(zammad_user_id)
        except ZammadError as exc:
            raise self.desk._zerr(exc) from exc
        async with self.sv.db.sessionmaker() as s:
            audit(s, "zammad_group_access", actor_type="admin", actor_id=admin.id, group_id=group_id,
                  zammad_user_id=zammad_user_id, access=access)
            await s.commit()
        return await self.admin_groups()
