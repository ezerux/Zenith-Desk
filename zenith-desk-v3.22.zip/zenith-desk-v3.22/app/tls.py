"""v3.17 encryption in transit: TLS helpers.

* `client_context()`      — TLS 1.2+ client context (system CAs, or a pinned SHA-256 fingerprint of a self-signed server)
* `server_cert()`         — the certificate of Zenith Desk itself (given files, or a self-signed one made on first start)
* `make_pg_certs()`       — CA + certificate for the PostgreSQL container (docker-compose «certs» step)
* `plain_problems()`      — every configured connection that would send data unencrypted (refused when saving settings,
                            listed on System status)

    python -m app.tls pg /tls         # CA + db certificate for PostgreSQL (run once by docker compose)
    python -m app.tls server /tls     # self-signed certificate for Zenith Desk (done automatically by app.serve)
"""
from __future__ import annotations

import datetime as dt
import hashlib
import ipaddress
import os
import socket
import ssl
import sys
from pathlib import Path
from urllib.parse import urlsplit

LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "ip6-localhost"}


def is_local(host: str) -> bool:
    """Traffic to this host never leaves the computer (loopback)."""
    host = (host or "").strip().strip("[]").lower()
    if host in LOCAL_HOSTS or host.endswith(".localhost"):
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def fingerprint(der: bytes) -> str:
    return hashlib.sha256(der).hexdigest()


def norm_fp(fp: str) -> str:
    return "".join(c for c in (fp or "").lower() if c in "0123456789abcdef")


def client_context(verify: bool = True, pin: str = "") -> ssl.SSLContext:
    """TLS 1.2+ for outgoing connections. With a pin the server's certificate must have exactly that SHA-256
    fingerprint (self-signed certificates of FreePBX / Asterisk); otherwise the system CAs + host name are checked."""
    ctx = ssl.create_default_context()
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    if pin or not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE  # checked by the pin after the handshake (check_pin)
    return ctx


def check_pin(ssl_object, pin: str) -> None:
    if not pin:
        return
    der = ssl_object.getpeercert(binary_form=True) if ssl_object else None
    if not der or fingerprint(der) != norm_fp(pin):
        got = fingerprint(der) if der else "none"
        raise ssl.SSLError(f"certificate fingerprint mismatch (got {got})")


# ------------------------------------------------------------------ certificates
def _key():
    from cryptography.hazmat.primitives.asymmetric import ec  # noqa: PLC0415
    return ec.generate_private_key(ec.SECP256R1())


def _pem(key) -> bytes:
    from cryptography.hazmat.primitives import serialization  # noqa: PLC0415
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())


def _san(names: list[str]):
    from cryptography import x509  # noqa: PLC0415
    out = []
    for n in dict.fromkeys(n for n in names if n):
        try:
            out.append(x509.IPAddress(ipaddress.ip_address(n)))
        except ValueError:
            out.append(x509.DNSName(n))
    return x509.SubjectAlternativeName(out)


def _cert(subject_cn: str, key, issuer_cn: str, issuer_key, names: list[str], ca: bool, days: int):
    from cryptography import x509  # noqa: PLC0415
    from cryptography.hazmat.primitives import hashes  # noqa: PLC0415
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID  # noqa: PLC0415
    now = dt.datetime.now(dt.timezone.utc)
    b = (x509.CertificateBuilder()
         .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, subject_cn)]))
         .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, issuer_cn)]))
         .public_key(key.public_key()).serial_number(x509.random_serial_number())
         .not_valid_before(now - dt.timedelta(minutes=5)).not_valid_after(now + dt.timedelta(days=days))
         .add_extension(x509.BasicConstraints(ca=ca, path_length=0 if ca else None), critical=True))
    if ca:
        b = b.add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True, content_commitment=False,
                                          key_encipherment=False, data_encipherment=False, key_agreement=False,
                                          encipher_only=False, decipher_only=False), critical=True)
    else:
        b = b.add_extension(_san(names), critical=False).add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
    from cryptography.hazmat.primitives import serialization  # noqa: PLC0415
    return b.sign(issuer_key, hashes.SHA256()).public_bytes(serialization.Encoding.PEM)


def _write(path: Path, data: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(data)
    os.chmod(tmp, mode)
    tmp.replace(path)


def default_names() -> list[str]:
    names = ["localhost", "127.0.0.1", "::1"]
    try:
        host = socket.gethostname()
        names.append(host)
        names.append(socket.getfqdn())
    except OSError:
        pass
    extra = os.environ.get("TLS_HOSTNAMES", "")  # e.g. desk.company.com,10.0.0.20
    names += [x.strip() for x in extra.split(",") if x.strip()]
    return names


def server_cert(folder: str | Path, cert_file: str = "", key_file: str = "") -> tuple[str, str, bool]:
    """(cert path, key path, made now). Uses the given files, else <folder>/server.crt|key, made once if missing."""
    if cert_file and key_file:
        return cert_file, key_file, False
    folder = Path(folder)
    crt, key = folder / "server.crt", folder / "server.key"
    if crt.exists() and key.exists():
        return str(crt), str(key), False
    k = _key()
    names = default_names()
    _write(key, _pem(k), 0o600)
    _write(crt, _cert(names[3] if len(names) > 3 else "Zenith Desk", k, "Zenith Desk (self-signed)", k, names, False, 825))
    return str(crt), str(key), True


def make_pg_certs(folder: str | Path, names: list[str] | None = None, owner_uid: int | None = 70) -> None:
    """CA + server certificate for PostgreSQL (host «db» in docker compose); kept if they already exist."""
    folder = Path(folder)
    if (folder / "ca.crt").exists() and (folder / "db.crt").exists() and (folder / "db.key").exists():
        return
    ca_key = _key()
    ca = _cert("Zenith Desk database CA", ca_key, "Zenith Desk database CA", ca_key, [], True, 3650)
    k = _key()
    crt = _cert("db", k, "Zenith Desk database CA", ca_key, names or ["db", "localhost", "127.0.0.1"], False, 3650)
    _write(folder / "ca.crt", ca)
    _write(folder / "db.crt", crt)
    _write(folder / "db.key", _pem(k), 0o600)
    # only encrypted connections from the network; inside the container (health check, set-up) the local socket
    _write(folder / "pg_hba.conf", b"local all all trust\nhostssl all all all scram-sha-256\nhostnossl all all all reject\n")
    # PostgreSQL only accepts a key that belongs to it (uid 70 in the alpine image) and nobody else can read
    if owner_uid is not None and hasattr(os, "chown"):
        try:
            for f in ("db.key", "db.crt", "pg_hba.conf"):
                os.chown(folder / f, owner_uid, owner_uid)
        except PermissionError:
            pass


# ------------------------------------------------------------------ v3.18: the certificate moves with a backup
SERVING: list[ssl.SSLContext] = []  # the contexts app.serve is answering with (to swap the certificate without a restart)


def own_cert_paths() -> tuple[Path, Path] | None:
    """The self-signed certificate Zenith Desk made itself (None when a certificate of the company is configured)."""
    if os.environ.get("TLS_CERT_FILE") or os.environ.get("TLS_KEY_FILE"):
        return None
    folder = Path(os.environ.get("TLS_DIR", "tls"))
    return folder / "server.crt", folder / "server.key"


def export_cert() -> dict | None:
    """The server's own certificate for a backup, so a new installation answers with the very same one."""
    paths = own_cert_paths()
    if not paths or not (paths[0].is_file() and paths[1].is_file()):
        return None
    try:
        return {"cert": paths[0].read_text(), "key": paths[1].read_text()}
    except OSError:
        return None


def import_cert(data: dict | None) -> bool:
    """Put the certificate of a backup in place and start answering with it at once. False when not applicable."""
    paths = own_cert_paths()
    if not data or not paths or not data.get("cert") or not data.get("key"):
        return False
    cert, key = str(data["cert"]), str(data["key"])
    try:
        x509 = ssl.PEM_cert_to_DER_cert(cert)
    except ValueError:
        return False
    if paths[0].is_file():
        try:
            if ssl.PEM_cert_to_DER_cert(paths[0].read_text()) == x509:
                return False  # already the same certificate
        except (OSError, ValueError):
            pass
    try:
        _write(paths[1], key.encode(), 0o600)
        _write(paths[0], cert.encode())
    except OSError:
        return False
    for ctx in SERVING:
        try:
            ctx.load_cert_chain(str(paths[0]), str(paths[1]))  # new handshakes use it, open connections stay
        except (ssl.SSLError, OSError):
            return False
    return True


def server_context(cert: str, key: str) -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(cert, key)
    return ctx


# ------------------------------------------------------------------ what would travel unencrypted
URL_SETTINGS = {  # setting -> schemes that are encrypted
    "zammad_url": ("https",), "phone_wss_url": ("wss",), "public_url": ("https",), "admin_alert_webhook_url": ("https",),
    "telegram_api_base": ("https",), "whatsapp_api_base": ("https",), "recording_url_template": ("https",),
}


def url_problem(key: str, url: str) -> str | None:
    url = (url or "").strip()
    if not url:
        return None
    parts = urlsplit(url.replace("{", "").replace("}", ""))
    if parts.scheme.lower() in URL_SETTINGS.get(key, ("https",)):
        return None
    if is_local(parts.hostname or ""):
        return None  # loopback: never on the network
    return f"{key}: {parts.scheme or '?'}:// sends data unencrypted — use {URL_SETTINGS.get(key, ('https',))[0]}://"


def plain_problems(cfg) -> list[dict]:
    """Every configured connection that is not encrypted (or encrypted but not verified)."""
    out: list[dict] = []
    for key in URL_SETTINGS:
        p = url_problem(key, getattr(cfg, key, ""))
        if p:
            out.append({"key": key, "level": "error", "text": p})
    if getattr(cfg, "ami_secret", "") and not getattr(cfg, "ami_tls", False) and not is_local(cfg.ami_host):
        out.append({"key": "ami_tls", "level": "error", "text": f"AMI {cfg.ami_host}:{cfg.ami_port}: login and call events travel unencrypted — turn on AMI over TLS"})
    if getattr(cfg, "mail_enabled", False):
        for key, host in (("mail_in_security", cfg.mail_in_host), ("mail_smtp_security", cfg.mail_smtp_host)):
            if getattr(cfg, key) == "none" and not is_local(host):
                out.append({"key": key, "level": "error", "text": f"{key}: mail and passwords travel unencrypted — use ssl or starttls"})
    for key, on, what in (("zammad_verify_tls", "zammad_url", "Zammad"), ("mail_verify_tls", "mail_enabled", "mail server")):
        if getattr(cfg, on, None) and not getattr(cfg, key, True):
            out.append({"key": key, "level": "warning", "text": f"{what}: encrypted, but the certificate is not checked (a man in the middle could read it)"})
    if getattr(cfg, "ami_tls", False) and not getattr(cfg, "ami_tls_verify", True) and not getattr(cfg, "ami_tls_fingerprint", ""):
        out.append({"key": "ami_tls_verify", "level": "warning", "text": "AMI: encrypted, but the certificate is not checked — set its fingerprint"})
    db = getattr(cfg, "database_url", "")
    if db.startswith("postgresql"):
        host = urlsplit(db.split("+", 1)[-1] if "://" in db else db).hostname or ""
        if not is_local(host) and "ssl=" not in db and "sslmode=" not in db:
            out.append({"key": "database_url", "level": "error", "text": f"PostgreSQL {host}: the database connection is not encrypted — add ?ssl=verify-full"})
    return out


def main(argv: list[str]) -> int:
    if len(argv) < 3 or argv[1] not in ("pg", "server"):
        print(__doc__)
        return 2
    if argv[1] == "pg":
        make_pg_certs(argv[2])
        print(f"PostgreSQL certificates in {argv[2]}")
    else:
        crt, _, made = server_cert(argv[2])
        print(("made " if made else "kept ") + crt)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
