"""v3.15 shift schedule: who works when, and the attendance computed from the presence history.

Present = signed in to Zenith Desk and not "Offline" (any of Ready / Busy / Break / Wrap-up). The presence history is
the `availability_changed` audit trail that the state engine already writes on every change.

For every shift:
* late         — first came in more than `shift_grace_min` minutes after the start (or still not in);
* absent       — not in at all `shift_absent_min` minutes after the start (or during the whole shift);
* early_leave  — went offline more than `shift_grace_min` minutes before the end and did not come back.
Managers get a notification (and an audit row) for each problem once.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import func, select

from .audit import audit
from .db import as_utc, utcnow
from .models import AgentMapping, AuditLog, Shift

log = logging.getLogger("shifts")

LOOK = timedelta(hours=3)  # coming in up to 3 h before the start still counts for this shift
HHMM = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def tzinfo(name: str):
    try:
        return ZoneInfo(name)
    except Exception:  # noqa: BLE001
        return timezone.utc


def parse_hhmm(v: str) -> time:
    m = HHMM.match((v or "").strip())
    if not m:
        raise ValueError("time must be HH:MM")
    return time(int(m.group(1)), int(m.group(2)))


def local_span(day: date, start: str, end: str, tz_name: str) -> tuple[datetime, datetime]:
    """Shift of `day` from `start` to `end` local time (an end not after the start = the next day), in UTC."""
    tz = tzinfo(tz_name)
    a, b = parse_hhmm(start), parse_hhmm(end)
    s = datetime.combine(day, a, tzinfo=tz)
    e = datetime.combine(day + timedelta(days=1) if b <= a else day, b, tzinfo=tz)
    return s.astimezone(timezone.utc), e.astimezone(timezone.utc)


def intervals(events: list[tuple[datetime, bool]], online_before: bool, start: datetime, now: datetime) -> list[list[datetime]]:
    """Online intervals from `start` until now, from (time, online) change events sorted by time."""
    out: list[list[datetime]] = []
    cur = start if online_before else None
    for ts, on in events:
        ts = as_utc(ts)
        if ts < start:
            continue
        if on and cur is None:
            cur = ts
        elif not on and cur is not None:
            if ts > cur:
                out.append([cur, ts])
            cur = None
    if cur is not None and now > cur:
        out.append([cur, now])
    return out


@dataclass
class Attendance:
    status: str            # upcoming | waiting | working | away | done | absent
    late_min: int = 0
    early_min: int = 0
    absent: bool = False
    first_in: datetime | None = None
    last_out: datetime | None = None  # None while still online
    worked_min: int = 0
    online: bool = False

    @property
    def problems(self) -> list[str]:
        return [p for p, on in (("absent", self.absent), ("late", self.late_min > 0), ("early_leave", self.early_min > 0)) if on]

    def view(self) -> dict:
        return {"status": self.status, "late_min": self.late_min, "early_min": self.early_min, "absent": self.absent,
                "first_in": self.first_in, "last_out": self.last_out, "worked_min": self.worked_min, "online": self.online,
                "problems": self.problems}


def attendance(s0: datetime, s1: datetime, online: list[list[datetime]], now: datetime, grace_min: int, absent_min: int) -> Attendance:
    s0, s1, now = as_utc(s0), as_utc(s1), as_utc(now)
    grace = timedelta(minutes=max(0, grace_min))
    absent_after = timedelta(minutes=max(grace_min, absent_min))
    online_now = bool(online) and online[-1][1] >= now
    if now < s0:
        return Attendance("upcoming", online=online_now)
    upto = min(now, s1)
    during = [iv for iv in online if iv[1] > s0 - LOOK and iv[0] < upto]
    worked = sum(max(0.0, (min(b, s1) - max(a, s0)).total_seconds()) for a, b in online)
    att = Attendance("working", online=online_now, worked_min=int(worked // 60))
    if not during:
        missing = now - s0
        if now >= s1 or missing >= absent_after:
            att.status, att.absent = "absent", True
        else:
            att.status = "waiting"
            if missing > grace:
                att.late_min = int(missing.total_seconds() // 60)
        return att
    first = max(during[0][0], s0 - LOOK)
    att.first_in = first
    if first - s0 > grace:
        att.late_min = int((first - s0).total_seconds() // 60)
    last = max(b for a, b in online if a < s1)
    att.last_out = None if online_now and last >= now else last
    if now < s1:
        att.status = "working" if online_now else "away"
        return att
    att.status = "done"
    if att.last_out is not None and s1 - att.last_out > grace:
        att.early_min = int((s1 - att.last_out).total_seconds() // 60)
    return att


async def presence_history(s, agent_ids: list[int], start: datetime, end: datetime) -> dict[int, tuple[bool, list]]:
    """Per agent: (online right before `start`, [(time, online), …] until `end`)."""
    rows = (await s.execute(select(AuditLog).where(
        AuditLog.action == "availability_changed", AuditLog.agent_id.in_(agent_ids),
        AuditLog.ts >= start, AuditLog.ts < end).order_by(AuditLog.ts, AuditLog.id))).scalars().all() if agent_ids else []
    last_ids = select(func.max(AuditLog.id)).where(
        AuditLog.action == "availability_changed", AuditLog.ts < start, AuditLog.agent_id.in_(agent_ids)
    ).group_by(AuditLog.agent_id)
    before = (await s.execute(select(AuditLog).where(AuditLog.id.in_(last_ids)))).scalars().all() if agent_ids else []
    out: dict[int, tuple[bool, list]] = {a: (False, []) for a in agent_ids}
    for e in before:
        out[e.agent_id] = ((e.details or {}).get("new", "offline") != "offline", [])
    for e in rows:
        out[e.agent_id][1].append((e.ts, (e.details or {}).get("new", "offline") != "offline"))
    return out


async def with_attendance(s, shifts: list[Shift], cfg, now: datetime | None = None) -> dict[int, Attendance]:
    now = now or utcnow()
    if not shifts:
        return {}
    start = min(as_utc(x.starts_at) for x in shifts) - LOOK
    end = max(as_utc(x.ends_at) for x in shifts) + LOOK
    hist = await presence_history(s, sorted({x.agent_id for x in shifts}), start, min(end, now))
    out = {}
    for x in shifts:
        before, events = hist.get(x.agent_id, (False, []))
        out[x.id] = attendance(x.starts_at, x.ends_at, intervals(events, before, start, now), now,
                               cfg.shift_grace_min, cfg.shift_absent_min)
    return out


def shift_view(x: Shift, att: Attendance | None) -> dict:
    return {"id": x.id, "agent_id": x.agent_id, "starts_at": as_utc(x.starts_at), "ends_at": as_utc(x.ends_at), "note": x.note,
            "attendance": att.view() if att else None}


class ShiftWatch:
    """Background check: tells the managers once about every late arrival, absence and early leave."""

    def __init__(self, services):
        self.sv = services
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="shift-watch")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None

    async def _loop(self) -> None:
        while True:
            await asyncio.sleep(60)
            try:
                await self.check()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("shift check failed")

    async def check(self, now: datetime | None = None) -> int:
        cfg = self.sv.settings
        if not cfg.shift_alerts:
            return 0
        now = now or utcnow()
        sent = 0
        async with self.sv.db.sessionmaker() as s:
            shifts = (await s.execute(select(Shift).where(Shift.starts_at <= now, Shift.ends_at > now - LOOK))).scalars().all()
            names = {m.id: m.display_name for m in (await s.execute(select(AgentMapping))).scalars().all()}
            atts = await with_attendance(s, shifts, cfg, now)
            for x in shifts:
                att, done = atts[x.id], list(x.alerts or [])
                for p in att.problems:
                    if p in done or (p == "late" and "absent" in done):
                        continue
                    done.append(p)
                    audit(s, "shift_" + p, agent_id=x.agent_id, level="warning", shift_id=x.id, name=names.get(x.agent_id, ""),
                          starts_at=as_utc(x.starts_at).isoformat(), ends_at=as_utc(x.ends_at).isoformat(),
                          minutes=att.late_min if p == "late" else att.early_min if p == "early_leave" else None,
                          arrived=bool(att.first_in))
                    sent += 1
                if done != list(x.alerts or []):
                    x.alerts = done
            await s.commit()
        return sent
