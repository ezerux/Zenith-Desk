"""v3.3: read-only directory of Zammad people (customers and staff).

People are created and edited in Zammad only. Zenith Desk keeps a local copy so that its lists, cards, names and
the "transfer to" picker are instant and keep working for a moment even if Zammad is slow.

Sync
* incremental every DIRECTORY_SYNC_SEC: the most recently changed people first, until we reach what we
  already have (two minutes of overlap so nothing slips between two runs);
* full on start and every six hours: also removes people who were deleted in Zammad;
* "Sync now" button in the UI, and right after a Zammad webhook.
A commit to `zammad_user` is pushed to every browser by the live layer (topic `directory`); genuinely new
people additionally raise a `directory_new` event, so operators see "New customer: …" immediately.
"""
from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timedelta

from sqlalchemy import delete, func, or_, select

from .db import as_utc, utcnow
from .models import ZammadUser

log = logging.getLogger("directory")

PAGE = 200  # Zammad's maximum for search endpoints
MAX_PAGES = 1000
FULL_EVERY = timedelta(hours=6)
DEFAULT_ROLE_IDS = {1: "Admin", 2: "Agent", 3: "Customer"}


def parse_ts(v) -> datetime | None:
    if not v or not isinstance(v, str):
        return None
    try:
        return as_utc(datetime.fromisoformat(v.replace("Z", "+00:00")))
    except ValueError:
        return None


def digits(v: str | None) -> str:
    return re.sub(r"\D", "", v or "")


def full_name(u) -> str:
    first = (u.get("firstname") if isinstance(u, dict) else u.firstname) or ""
    last = (u.get("lastname") if isinstance(u, dict) else u.lastname) or ""
    name = f"{first} {last}".strip()
    if name:
        return name
    if isinstance(u, dict):
        return u.get("email") or u.get("login") or f"#{u.get('id')}"
    return u.email or u.login or f"#{u.id}"


def user_view(u: ZammadUser) -> dict:
    return {
        "id": u.id, "name": full_name(u), "firstname": u.firstname, "lastname": u.lastname, "login": u.login,
        "email": u.email, "phone": u.phone, "mobile": u.mobile, "organization": u.organization, "note": u.note,
        "active": u.active, "is_agent": u.is_agent, "is_customer": u.is_customer, "roles": u.roles or [],
        "groups": u.groups or {}, "created_at": u.z_created_at, "updated_at": u.z_updated_at,
    }


def _roles(u: dict) -> list[str]:
    roles = u.get("roles")
    if isinstance(roles, list) and roles and all(isinstance(r, str) for r in roles):
        return roles
    return [DEFAULT_ROLE_IDS[i] for i in (u.get("role_ids") or []) if i in DEFAULT_ROLE_IDS]


def _groups(u: dict) -> dict:
    g = u.get("groups")
    if isinstance(g, dict):
        return {str(k): v if isinstance(v, list) else [v] for k, v in g.items()}
    ids = u.get("group_ids")
    if isinstance(ids, dict):  # older Zammad: ids only
        return {f"id:{k}": v if isinstance(v, list) else [v] for k, v in ids.items()}
    return {}


def _org(u: dict) -> str:
    org = u.get("organization")
    if isinstance(org, dict):
        return org.get("name") or ""
    return org if isinstance(org, str) else ""


def has_full_access(groups: dict, group_name: str, group_id: int | None) -> bool:
    for key in (group_name, f"id:{group_id}" if group_id else None):
        if key and key in (groups or {}):
            if "full" in (groups[key] or []):  # Zammad: an owner needs "full" access to the ticket's group
                return True
    return False


class Directory:
    def __init__(self, services):
        self.sv = services
        self._lock = asyncio.Lock()
        self._task: asyncio.Task | None = None
        self._last_full: datetime | None = None
        self.last_sync: datetime | None = None
        self.last_error: str = ""
        self._kick = asyncio.Event()

    # ------------------------------------------------------------------ sync
    def _apply(self, row: ZammadUser, u: dict) -> None:
        roles = _roles(u)
        row.login = str(u.get("login") or "")[:255]
        row.firstname = str(u.get("firstname") or "")[:150]
        row.lastname = str(u.get("lastname") or "")[:150]
        row.email = str(u.get("email") or "")[:255]
        row.phone = str(u.get("phone") or "")[:100]
        row.mobile = str(u.get("mobile") or "")[:100]
        row.organization = _org(u)[:255]
        row.note = str(u.get("note") or "")[:4000]
        row.active = u.get("active", True) is not False
        row.roles = roles
        row.is_agent = "Agent" in roles
        row.is_customer = "Customer" in roles
        row.groups = _groups(u)
        row.z_created_at = parse_ts(u.get("created_at"))
        row.z_updated_at = parse_ts(u.get("updated_at"))
        row.synced_at = utcnow()
        row.search_text = " ".join(filter(None, [
            full_name(u).lower(), row.login.lower(), row.email.lower(), row.organization.lower(),
            digits(row.phone), digits(row.mobile)]))

    async def sync(self, full: bool = False) -> dict:
        """Bring the local copy up to date. Returns {"added", "updated", "removed", "full"}."""
        async with self._lock:
            async with self.sv.db.sessionmaker() as s:
                count = (await s.execute(select(func.count(ZammadUser.id)))).scalar() or 0
                watermark = None if full or not count else (await s.execute(select(func.max(ZammadUser.z_updated_at)))).scalar()
            if watermark is None:
                full = True
            first_fill = count == 0
            added: list[dict] = []
            updated = removed = 0
            seen: set[int] = set()
            complete = False
            page = 1
            try:
                while page <= MAX_PAGES:
                    rows = await self.sv.zammad.users_page(page, PAGE)
                    if not rows:
                        complete = True
                        break
                    stop = False
                    batch = []
                    for u in rows:
                        if not isinstance(u, dict) or not u.get("id"):
                            continue
                        upd = parse_ts(u.get("updated_at"))
                        if not full and watermark and upd and upd < as_utc(watermark) - timedelta(minutes=2):
                            stop = True
                            break
                        batch.append(u)
                    if batch:
                        a, n = await self._upsert(batch)
                        added += a
                        updated += n
                        seen.update(int(u["id"]) for u in batch)
                    if stop:
                        break
                    if len(rows) < PAGE:
                        complete = True
                        break
                    page += 1
            except Exception as exc:  # noqa: BLE001
                self.last_error = str(exc)[:300]
                log.warning("directory sync failed: %s", exc)
                raise
            if full and complete and seen:
                async with self.sv.db.sessionmaker() as s:
                    res = await s.execute(delete(ZammadUser).where(ZammadUser.id.not_in(seen)))
                    removed = res.rowcount or 0
                    await s.commit()
            if full:
                self._last_full = utcnow()
            self.last_sync, self.last_error = utcnow(), ""
        if added and not first_fill:
            self.sv.broker.publish_all("directory_new", {"items": added[:20], "count": len(added)})
        if added or updated or removed:
            log.info("directory: +%s ~%s -%s%s", len(added), updated, removed, " (full)" if full else "")
        return {"added": len(added), "updated": updated, "removed": removed, "full": full}

    async def _upsert(self, users: list[dict]) -> tuple[list[dict], int]:
        added: list[dict] = []
        changed = 0
        ids = [int(u["id"]) for u in users]
        async with self.sv.db.sessionmaker() as s:
            existing = {r.id: r for r in (await s.execute(select(ZammadUser).where(ZammadUser.id.in_(ids)))).scalars().all()}
            for u in users:
                uid = int(u["id"])
                row = existing.get(uid)
                if row is None:
                    row = ZammadUser(id=uid)
                    self._apply(row, u)
                    s.add(row)
                    existing[uid] = row
                    added.append({"id": uid, "name": full_name(u), "kind": "staff" if row.is_agent else "customer"})
                else:
                    before = (as_utc(row.z_updated_at) if row.z_updated_at else None, row.firstname, row.lastname, row.email, row.phone, row.mobile,
                              row.active, row.roles, row.groups, row.organization, row.note)
                    self._apply(row, u)
                    after = (row.z_updated_at, row.firstname, row.lastname, row.email, row.phone, row.mobile,
                             row.active, row.roles, row.groups, row.organization, row.note)
                    if before != after:
                        changed += 1
                    else:
                        s.expunge(row)  # nothing new: do not write (and do not wake every browser)
            await s.commit()
        return added, changed

    async def upsert_one(self, u: dict) -> None:
        """A fresh copy of one person (e.g. from a webhook payload or after a lookup)."""
        if isinstance(u, dict) and u.get("id"):
            await self._upsert([u])

    async def refresh_user(self, uid: int) -> None:
        """v3.11: read one person again right now (after the administrator changed his group access)."""
        await self.upsert_one(await self.sv.zammad.get_user_expanded(uid))

    def kick(self) -> None:
        """Run an incremental sync soon (e.g. a webhook said something changed)."""
        self._kick.set()

    # ------------------------------------------------------------------ queries
    async def names(self, ids) -> dict[int, str]:
        ids = {int(i) for i in ids if i}
        if not ids:
            return {}
        async with self.sv.db.sessionmaker() as s:
            rows = (await s.execute(select(ZammadUser).where(ZammadUser.id.in_(ids)))).scalars().all()
        return {r.id: full_name(r) for r in rows}

    async def get(self, uid: int) -> ZammadUser | None:
        async with self.sv.db.sessionmaker() as s:
            return await s.get(ZammadUser, uid)

    async def search(self, kind: str, q: str = "", offset: int = 0, limit: int = 50, active_only: bool = False) -> dict:
        cond = [ZammadUser.is_agent.is_(True)] if kind == "staff" else [ZammadUser.is_customer.is_(True)]
        if active_only:
            cond.append(ZammadUser.active.is_(True))
        q = (q or "").strip().lower()
        if q:
            parts = []
            for word in q.split():
                d = digits(word)
                like = f"%{d}%" if d and len(d) >= 3 and d == word.replace("+", "").replace("-", "") else f"%{word}%"
                parts.append(ZammadUser.search_text.like(like))
            cond.extend(parts)
        async with self.sv.db.sessionmaker() as s:
            total = (await s.execute(select(func.count(ZammadUser.id)).where(*cond))).scalar() or 0
            rows = (await s.execute(select(ZammadUser).where(*cond)
                                    .order_by(ZammadUser.z_created_at.desc().nulls_last(), ZammadUser.id.desc())
                                    .offset(max(0, offset)).limit(max(1, min(limit, 200))))).scalars().all()
            counts = {
                "customers": (await s.execute(select(func.count(ZammadUser.id)).where(ZammadUser.is_customer.is_(True)))).scalar() or 0,
                "staff": (await s.execute(select(func.count(ZammadUser.id)).where(ZammadUser.is_agent.is_(True)))).scalar() or 0,
            }
        return {"items": [user_view(r) for r in rows], "total": total, "counts": counts,
                "synced_at": self.last_sync, "error": self.last_error}

    async def agents_for_group(self, group_name: str, group_id: int | None) -> list[ZammadUser]:
        async with self.sv.db.sessionmaker() as s:
            rows = (await s.execute(select(ZammadUser).where(ZammadUser.is_agent.is_(True), ZammadUser.active.is_(True))
                                    .order_by(ZammadUser.firstname, ZammadUser.lastname))).scalars().all()
        return [r for r in rows if has_full_access(r.groups or {}, group_name, group_id)]

    async def find_by_text(self, q: str, limit: int = 10) -> list[ZammadUser]:
        q = (q or "").strip().lower()
        if not q:
            return []
        async with self.sv.db.sessionmaker() as s:
            return (await s.execute(select(ZammadUser).where(or_(
                ZammadUser.search_text.like(f"%{q}%"), ZammadUser.search_text.like(f"%{digits(q) or q}%")))
                .limit(limit))).scalars().all()

    # ------------------------------------------------------------------ loop
    def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="directory-sync")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _loop(self) -> None:
        await asyncio.sleep(1)
        while True:
            every = self.sv.settings.directory_sync_sec
            try:
                if every > 0 or self._kick.is_set():
                    full = self._last_full is None or utcnow() - self._last_full > FULL_EVERY
                    self._kick.clear()
                    await self.sync(full=full)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                pass  # logged in sync(); try again next round
            try:
                await asyncio.wait_for(self._kick.wait(), timeout=max(every, 5) if every > 0 else 3600)
                await asyncio.sleep(1)  # collect a burst of webhooks into one run
            except asyncio.TimeoutError:
                pass
