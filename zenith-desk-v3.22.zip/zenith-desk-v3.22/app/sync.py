"""State engine: recompute availability and bring Asterisk queues in line with it.

Guarantees (ТЗ FR-04, FR-07, FR-13, FR-14, сценарий D):
* availability is always computed from ALL active sessions of the agent;
* commands are serialised per agent (asyncio lock) — no races between webhook/UI/timers;
* a command counts as done only after QueueStatus confirms it;
* on any failure the agent is marked sync_status=error and retried with exponential backoff;
* the service never unpauses a member when the current queue state could not be read,
  and (optionally) never unpauses a member paused by someone else (phone *46, other tools).
"""
import asyncio
import logging
from collections import defaultdict
from datetime import timedelta

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .ami import AMINotConnected
from .audit import audit
from .availability import compute_availability
from .config import Settings
from .db import Database, as_utc, utcnow
from .events import EventBroker
from .i18n import t as tr
from .models import AgentMapping, AgentState, PauseInterval, WorkSession
from .pbx import Pbx
from .views import agent_state_view

log = logging.getLogger("sync")


class SyncProblem(Exception):
    pass


class StateEngine:
    def __init__(self, db: Database, pbx: Pbx, broker: EventBroker, settings: Settings):
        self.db = db
        self.pbx = pbx
        self.broker = broker
        self.settings = settings
        self._locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._tasks: list[asyncio.Task] = []
        self.boost = None  # v3.18 overflow: (person, queue) -> True while he rings in the first line of that queue

    # ------------------------------------------------------------------ helpers
    async def ensure_state(self, s: AsyncSession, agent_id: int) -> AgentState:
        st = await s.get(AgentState, agent_id)
        if st is None:
            st = AgentState(agent_id=agent_id, manual_state="offline", computed_state="offline", sync_status="pending")
            s.add(st)
            await s.flush()
        return st

    async def blocking_tickets(self, s: AsyncSession, agent_id: int) -> list[str]:
        rows = await s.execute(
            select(WorkSession.ticket_number, WorkSession.ticket_id).where(
                WorkSession.agent_id == agent_id, WorkSession.state == "active", WorkSession.work_mode == "blocking"
            ).order_by(WorkSession.started_at)
        )
        return [num or str(tid) for num, tid in rows.all()]

    async def _recompute_in_tx(self, s: AsyncSession, agent_id: int, cause: str) -> AgentState:
        st = await self.ensure_state(s, agent_id)
        wrap_up_active = bool(st.wrap_up_until and as_utc(st.wrap_up_until) > utcnow())
        if st.wrap_up_until and not wrap_up_active:
            st.wrap_up_until = None
        av = compute_availability(
            st.manual_state, await self.blocking_tickets(s, agent_id),
            override_ready=st.override_ready, wrap_up_active=wrap_up_active, dnd=bool(st.dnd),
        )
        if (av.state, av.reason) != (st.computed_state, st.reason):
            audit(s, "availability_changed", agent_id=agent_id, cause=cause,
                  old=st.computed_state, new=av.state, reason=av.reason)
            st.computed_state, st.reason = av.state, av.reason
        return st

    # ------------------------------------------------------------------ public API
    async def recompute(self, agent_id: int, cause: str, *, sync: bool = True) -> dict:
        """Recompute availability from DB, persist it, then push it to Asterisk."""
        async with self._locks[agent_id]:
            async with self.db.sessionmaker() as s:
                await self._recompute_in_tx(s, agent_id, cause)
                await s.commit()
            if sync:
                await self._sync_locked(agent_id, cause)
        return await self.publish(agent_id)

    async def reconcile(self, agent_id: int, cause: str = "reconcile") -> dict:
        return await self.recompute(agent_id, cause)

    async def reconcile_all(self, cause: str = "reconcile_all") -> None:
        async with self.db.sessionmaker() as s:
            ids = (await s.execute(select(AgentMapping.id))).scalars().all()
        for agent_id in ids:
            try:
                await self.recompute(agent_id, cause)
            except Exception:  # noqa: BLE001
                log.exception("reconcile failed for agent %s", agent_id)

    async def state_view(self, agent_id: int) -> dict:
        async with self.db.sessionmaker() as s:
            m = await s.get(AgentMapping, agent_id)
            st = await self.ensure_state(s, agent_id)
            await s.commit()
            return agent_state_view(m, st, self.settings.queues)

    async def publish(self, agent_id: int) -> dict:
        view = await self.state_view(agent_id)
        self.broker.publish_agent(agent_id, "agent_state", view)
        self.broker.publish_supervisors("agent_state", view)
        return view

    # ------------------------------------------------------------------ PBX sync
    async def _sync_locked(self, agent_id: int, cause: str) -> None:
        queues = self.settings.queues
        async with self.db.sessionmaker() as s:
            m = await s.get(AgentMapping, agent_id)
            st = await self.ensure_state(s, agent_id)
            if m is None or not m.enabled or not m.asterisk_interface or not queues:
                st.sync_status, st.sync_error, st.retry_count, st.next_retry_at = "ok", "", 0, None
                await s.commit()
                if m is not None and m.asterisk_interface and queues and not m.enabled:
                    await self._penalty_only(agent_id, m.asterisk_interface, queues, self.penalties_for(m, queues), cause)
                return
            interface = m.asterisk_interface
            desired_penalty = self.penalties_for(m, queues)
            desired_paused = st.computed_state != "ready"
            if desired_paused and st.computed_state == "busy_task" and self.boost is not None:
                # v3.18 overflow: in an overloaded queue a person busy with a ticket takes calls too
                help_in = [q for q in queues if self.boost(m, q)]
                if help_in:
                    desired_paused = {q: q not in help_in for q in queues}
            prev_status = st.sync_status
            simple = desired_paused if isinstance(desired_paused, bool) else all(desired_paused.values())
            if st.queue_paused is None or st.queue_paused != simple or st.sync_status != "ok":
                st.sync_status = "pending" if st.sync_status == "ok" else st.sync_status
                await s.commit()
                await self.publish(agent_id)

        try:
            actual_paused, external, changed, missing, penalties = await self._apply(interface, queues, desired_paused, desired_penalty)
        except Exception as exc:  # noqa: BLE001
            await self._mark_failure(agent_id, exc, cause)
            return

        async with self.db.sessionmaker() as s:
            st = await self.ensure_state(s, agent_id)
            st.queue_paused = actual_paused
            st.external_pause = external
            st.sync_status = "ok"
            st.sync_error = tr("sync.missing_queues", queues=", ".join(missing)) if missing else ""
            st.retry_count = 0
            st.next_retry_at = None
            st.last_asterisk_sync_at = utcnow()
            if changed:
                if isinstance(desired_paused, bool):
                    audit(s, "queue_pause" if desired_paused else "queue_unpause", agent_id=agent_id,
                          cause=cause, queues=changed, state=st.computed_state)
                else:  # v3.18 overflow: helping in some queues only
                    for want, act in ((True, "queue_pause"), (False, "queue_unpause")):
                        qs = [q for q in changed if desired_paused.get(q, True) == want]
                        if qs:
                            audit(s, act, agent_id=agent_id, cause=cause, queues=qs, state=st.computed_state)
            if penalties:
                audit(s, "queue_penalty", agent_id=agent_id, cause=cause, queues=penalties,
                      penalty=desired_penalty[penalties[0]] if len({desired_penalty[q] for q in penalties}) == 1 else
                      {q: desired_penalty[q] for q in penalties})
            if prev_status == "error":
                audit(s, "sync_restored", agent_id=agent_id, cause=cause)
            await self._track_pause_interval(s, agent_id, actual_paused, "external" if external and st.computed_state == "ready" else st.computed_state)
            await s.commit()

    async def _penalty_only(self, agent_id: int, interface: str, queues: list[str], penalty: dict[str, int] | None, cause: str) -> None:
        """v3.11: pauses are not automated for this person, but call routing by level still needs the right penalty."""
        if penalty is None or not self.pbx.connected:
            return
        try:
            status = await self.pbx.member_status(interface, queues)
            fix = [q for q, ms in status.items() if ms.present and ms.penalty is not None and ms.penalty != penalty.get(q, ms.penalty)]
            for q in fix:
                await self.pbx.set_penalty(interface, q, penalty[q])
        except Exception as exc:  # noqa: BLE001
            log.warning("penalty for agent %s not set: %s", agent_id, exc)
            return
        if fix:
            async with self.db.sessionmaker() as s:
                audit(s, "queue_penalty", agent_id=agent_id, cause=cause, queues=fix, penalty=penalty[fix[0]] if len({penalty[q] for q in fix}) == 1 else {q: penalty[q] for q in fix})
                await s.commit()

    def desired_penalty(self, m: AgentMapping) -> int | None:
        """v3.11: Level 1 → lowest penalty (rung first), Level 2 / 3 only when every lower level is busy."""
        cfg = self.settings
        if not cfg.level_routing:
            return None
        return {"level1": cfg.penalty_level1, "level2": cfg.penalty_level2, "level3": cfg.penalty_level3}.get(
            m.level or "", cfg.penalty_manager)

    def penalty_for(self, m: AgentMapping, queue: str) -> int | None:
        """The penalty this person should have in this queue now (his level; the first line during an overflow)."""
        base = self.desired_penalty(m)
        if base is None:
            return None
        if self.boost is not None and self.boost(m, queue):
            return min(base, self.settings.penalty_level1)
        return base

    def penalties_for(self, m: AgentMapping, queues: list[str]) -> dict[str, int] | None:
        if self.desired_penalty(m) is None:
            return None
        return {q: self.penalty_for(m, q) for q in queues}

    async def _apply(self, interface: str, queues: list[str], desired_paused: bool | dict[str, bool],
                     desired_penalty: dict[str, int] | None = None):
        if not self.pbx.connected:
            raise AMINotConnected(tr("sync.ami_down"))
        status = await self.pbx.member_status(interface, queues)
        present = {q: ms for q, ms in status.items() if ms.present}
        missing = [q for q, ms in status.items() if not ms.present]
        if not present:
            raise SyncProblem(tr("sync.no_member", interface=interface))

        our = self.settings.pause_reason
        mixed = not isinstance(desired_paused, bool)
        want_of = (lambda q: desired_paused.get(q, True)) if mixed else (lambda q: desired_paused)
        changed: list[str] = []
        for q, ms in present.items():
            want = want_of(q)
            if want and not ms.paused:
                await self.pbx.set_paused(interface, q, True, our)
                changed.append(q)
            elif not want and ms.paused:
                foreign = ms.paused_reason not in ("", our)
                if foreign and self.settings.respect_external_pause:
                    continue  # paused by the operator's phone or another tool — leave it
                await self.pbx.set_paused(interface, q, False, our)
                changed.append(q)

        if changed:  # verify by re-reading state, not by trusting the command
            verify = await self.pbx.member_status(interface, changed)
            bad = [q for q in changed if not verify[q].present or verify[q].paused != want_of(q)]
            if bad:
                raise SyncProblem(tr("sync.not_confirmed_pause" if want_of(bad[0]) else "sync.not_confirmed_unpause", queues=", ".join(bad)))
            present.update(verify)

        penalties: list[str] = []
        if desired_penalty is not None:
            for q, ms in present.items():
                want = desired_penalty.get(q)
                if want is not None and ms.penalty is not None and ms.penalty != want:
                    await self.pbx.set_penalty(interface, q, want)
                    penalties.append(q)
            if penalties:
                verify = await self.pbx.member_status(interface, penalties)
                bad = [q for q in penalties if not verify[q].present or (verify[q].penalty is not None and verify[q].penalty != desired_penalty.get(q))]
                if bad:
                    raise SyncProblem(tr("sync.not_confirmed_penalty", queues=", ".join(bad)))

        # paused = no calls at all; during an overflow a person may take calls in one queue only
        actual_paused = all(ms.paused for ms in present.values()) if mixed else any(ms.paused for ms in present.values())
        external = any(ms.paused and ms.paused_reason not in ("", our) for ms in present.values())
        return actual_paused, external, changed, missing, penalties

    async def _mark_failure(self, agent_id: int, exc: Exception, cause: str) -> None:
        msg = str(exc) or exc.__class__.__name__
        async with self.db.sessionmaker() as s:
            st = await self.ensure_state(s, agent_id)
            first = st.sync_status != "error"
            st.sync_status = "error"
            st.sync_error = msg[:500]
            st.retry_count += 1
            delay = min(self.settings.retry_base_sec * 2 ** (st.retry_count - 1), self.settings.retry_max_sec)
            st.next_retry_at = utcnow() + timedelta(seconds=delay)
            # queue_paused is kept as the last CONFIRMED value; UI shows "не подтверждено".
            if first:
                audit(s, "sync_error", agent_id=agent_id, level="error", cause=cause, error=msg[:500])
            await s.commit()
        log.warning("sync failed for agent %s (%s): %s", agent_id, cause, msg)
        if first:
            await self.alert(tr("sync.alert", agent_id=agent_id, error=msg), agent_id=agent_id)

    async def _track_pause_interval(self, s: AsyncSession, agent_id: int, paused: bool, reason: str) -> None:
        open_iv = (await s.execute(
            select(PauseInterval).where(PauseInterval.agent_id == agent_id, PauseInterval.ended_at.is_(None))
        )).scalars().first()
        now = utcnow()
        if paused and open_iv is None:
            s.add(PauseInterval(agent_id=agent_id, reason=reason, started_at=now))
        elif paused and open_iv is not None and open_iv.reason != reason:
            open_iv.ended_at = now
            s.add(PauseInterval(agent_id=agent_id, reason=reason, started_at=now))
        elif not paused and open_iv is not None:
            open_iv.ended_at = now

    # ------------------------------------------------------------------ alerts
    async def alert(self, text: str, agent_id: int | None = None) -> None:
        self.broker.publish_supervisors("alert", {"text": text, "agent_id": agent_id, "ts": utcnow()})
        if agent_id is not None:
            self.broker.publish_agent(agent_id, "alert", {"text": text, "ts": utcnow()})
        url = self.settings.admin_alert_webhook_url
        if url:
            try:
                async with httpx.AsyncClient(timeout=5) as c:
                    await c.post(url, json={"text": text, "agent_id": agent_id})
            except httpx.HTTPError:
                log.warning("admin alert webhook failed")

    # ------------------------------------------------------------------ AMI hooks
    async def on_ami_connect(self) -> None:
        log.info("AMI (re)connected — reconciling all agents")
        await self.reconcile_all("ami_connected")

    async def on_ami_disconnect(self) -> None:
        async with self.db.sessionmaker() as s:
            ids = (await s.execute(select(AgentMapping.id).where(
                AgentMapping.enabled.is_(True), AgentMapping.asterisk_interface != ""))).scalars().all()
        if not self.settings.queues:
            return
        for agent_id in ids:
            async with self._locks[agent_id]:
                await self._mark_failure(agent_id, AMINotConnected(tr("sync.ami_lost")), "ami_disconnected")
            await self.publish(agent_id)

    # ------------------------------------------------------------------ background loops
    def start(self) -> None:
        self._tasks.append(asyncio.create_task(self._tick_loop(), name="sync-tick"))

    async def stop(self) -> None:
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self._tasks.clear()

    async def _tick_loop(self) -> None:
        last_full = 0.0
        loop = asyncio.get_running_loop()
        while True:
            await asyncio.sleep(2)
            try:
                if loop.time() - last_full >= self.settings.reconcile_interval_sec:
                    last_full = loop.time()
                    await self.reconcile_all("periodic")
                    continue
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("sync tick failed")

    async def tick(self) -> None:
        """Retries due now + expired wrap-up timers."""
        now = utcnow()
        async with self.db.sessionmaker() as s:
            rows = (await s.execute(select(AgentState))).scalars().all()
            due = [
                st.agent_id for st in rows
                if (st.sync_status == "error" and st.next_retry_at and as_utc(st.next_retry_at) <= now)
                or (st.wrap_up_until and as_utc(st.wrap_up_until) <= now)
            ]
        for agent_id in due:
            await self.recompute(agent_id, "retry")
