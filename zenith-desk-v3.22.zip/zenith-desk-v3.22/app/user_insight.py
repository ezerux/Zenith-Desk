"""v3.21: what the administrator sees about each user — presence, connections, sign-ins, lock, groups, access.

Everything here is read-only and built from data the server already has (sign-in attempts, live connections,
agent state, the Zammad directory copy). Nothing is fetched from Zammad.
"""
from collections import Counter
from datetime import timedelta

from sqlalchemy import func, select

from .db import as_utc, utcnow
from .models import (AgentMapping, AgentState, ApiKey, AuditLog, ChatGroup, ChatGroupMember, LoginAttempt, WorkSession,
                     ZammadUser)

ATTEMPTS_KEEP_DAYS = 30
USUAL_DAYS = 30

# the sections each role opens (mirrors the side menu of the web app)
SECTIONS = [("work", "op"), ("tickets", "op"), ("contacts", "all"), ("chat", "all"), ("mail", "op"),
            ("whatsapp", "op"), ("telegram", "op"), ("sup", "sup"), ("overview", "sup"), ("mtools", "sup"), ("admin", "admin")]


def access_for(role: str) -> list[dict]:
    allowed = {"all": True, "op": role != "admin", "sup": role in ("supervisor", "admin"), "admin": role == "admin"}
    return [{"key": k, "allowed": allowed[w]} for k, w in SECTIONS]


def device(ua: str) -> str:
    """A short, human description of a browser user-agent: «Chrome · Windows», «Safari · iPhone»."""
    ua = ua or ""
    if not ua:
        return ""
    low = ua.lower()
    if "zenithdesk" in low or "zenith desk" in low:
        app = "Zenith Desk app"
    elif "edg/" in low:
        app = "Edge"
    elif "opr/" in low or "opera" in low:
        app = "Opera"
    elif "firefox/" in low:
        app = "Firefox"
    elif "chrome/" in low or "crios/" in low:
        app = "Chrome"
    elif "safari/" in low:
        app = "Safari"
    elif "python" in low or "httpx" in low or "curl" in low:
        app = "Script"
    else:
        app = "Browser"
    if "iphone" in low:
        os_ = "iPhone"
    elif "ipad" in low:
        os_ = "iPad"
    elif "android" in low:
        os_ = "Android"
    elif "windows" in low:
        os_ = "Windows"
    elif "mac os" in low or "macintosh" in low:
        os_ = "macOS"
    elif "linux" in low:
        os_ = "Linux"
    else:
        os_ = ""
    return f"{app} · {os_}" if os_ else app


def _usual(ips: list[str]) -> str:
    return Counter(ips).most_common(1)[0][0] if ips else ""


async def summaries(s, broker, users: list[AgentMapping]) -> dict[int, dict]:
    """The extra columns of the users table, for every user at once (a few queries, no per-user loop)."""
    from .api.auth_routes import lock_info  # noqa: PLC0415
    now = utcnow()
    ids = [u.id for u in users]
    states = {st.agent_id: st for st in (await s.execute(select(AgentState).where(AgentState.agent_id.in_(ids)))).scalars().all()}
    last_ok = select(func.max(LoginAttempt.id)).where(LoginAttempt.result == "ok", LoginAttempt.agent_id.in_(ids)).group_by(LoginAttempt.agent_id)
    last_ip = {a: ip for a, ip in (await s.execute(select(LoginAttempt.agent_id, LoginAttempt.ip).where(LoginAttempt.id.in_(last_ok)))).all()}
    failed = dict((await s.execute(select(LoginAttempt.agent_id, func.count()).where(
        LoginAttempt.agent_id.in_(ids), LoginAttempt.result.in_(("bad_password", "locked")),
        LoginAttempt.ts >= now - timedelta(hours=24)).group_by(LoginAttempt.agent_id))).all())
    out = {}
    for u in users:
        st = states.get(u.id)
        conns = broker.connections(u.id)
        lock = lock_info(u.username or "") if u.username else None
        out[u.id] = {
            "online": conns > 0,
            "connections": conns,
            "state": (st.computed_state if st else "offline") if conns else "offline",
            "manual_state": st.manual_state if st else "offline",
            "locked": {"until": lock["until"], "failures": lock["failures"]} if lock else None,
            "last_login_ip": last_ip.get(u.id, ""),
            "failed_24h": int(failed.get(u.id, 0)),
        }
    return out


async def details(s, services, u: AgentMapping) -> dict:
    """Everything shown when the administrator opens one user's row."""
    from .api.auth_routes import lock_info  # noqa: PLC0415
    from .team import state_since  # noqa: PLC0415
    now = utcnow()
    st = await s.get(AgentState, u.id)
    conns = services.broker.connections_info(u.id)
    since = (await state_since(s, [u.id], now)).get(u.id)
    tasks = (await s.execute(select(func.count()).select_from(WorkSession).where(
        WorkSession.agent_id == u.id, WorkSession.state == "active"))).scalar() or 0
    from .team import live_calls  # noqa: PLC0415
    call = (await live_calls(s, now)).get(u.id)

    ok_ips = [ip for (ip,) in (await s.execute(select(LoginAttempt.ip).where(
        LoginAttempt.agent_id == u.id, LoginAttempt.result == "ok", LoginAttempt.ts >= now - timedelta(days=USUAL_DAYS))
        .order_by(LoginAttempt.id.desc()).limit(200))).all()]
    usual = _usual(ok_ips)
    attempts = (await s.execute(select(LoginAttempt).where(
        LoginAttempt.agent_id == u.id, LoginAttempt.ts >= now - timedelta(days=7)).order_by(LoginAttempt.id.desc()).limit(30))).scalars().all()
    last_ok = next((a for a in attempts if a.result == "ok"), None)
    if last_ok is None:
        last_ok = (await s.execute(select(LoginAttempt).where(LoginAttempt.agent_id == u.id, LoginAttempt.result == "ok")
                                   .order_by(LoginAttempt.id.desc()).limit(1))).scalars().first()
    failed_24h = sum(1 for a in attempts if a.result in ("bad_password", "locked") and as_utc(a.ts) >= now - timedelta(hours=24))
    pw = (await s.execute(select(AuditLog.ts).where(AuditLog.agent_id == u.id, AuditLog.action.in_(
        ("password_changed", "password_reset"))).order_by(AuditLog.id.desc()).limit(1))).scalar()

    lock = lock_info(u.username or "") if u.username else None
    lock_view = None
    if lock:
        bad = [a for a in attempts if a.result in ("bad_password", "locked")]
        ips = Counter(a.ip for a in bad)
        main_ip = ips.most_common(1)[0][0] if ips else ""
        other = None
        if main_ip:  # who last signed in successfully from that address (another employee?)
            row = (await s.execute(select(LoginAttempt).where(LoginAttempt.ip == main_ip, LoginAttempt.result == "ok")
                                   .order_by(LoginAttempt.id.desc()).limit(1))).scalars().first()
            if row is not None and row.agent_id:
                who = await s.get(AgentMapping, row.agent_id)
                other = {"id": row.agent_id, "name": who.display_name if who else "", "at": as_utc(row.ts),
                         "same_user": row.agent_id == u.id}
        wrong = [a for a in attempts if a.result == "bad_password"]  # newest first
        lock_view = {"until": lock["until"], "failures": lock["failures"],
                     "locked_at": as_utc(wrong[0].ts) if wrong else None,
                     "first_at": as_utc(wrong[min(len(wrong), lock["failures"]) - 1].ts) if wrong else None,
                     "ip": main_ip, "ips": sorted(ips), "usual_ip": usual,
                     "foreign": bool(main_ip and usual and main_ip != usual), "last_user_on_ip": other}

    member = []
    zu = await s.get(ZammadUser, u.zammad_user_id) if u.zammad_user_id else None
    if zu is not None:
        for key, rights in sorted((zu.groups or {}).items()):
            rights = rights if isinstance(rights, list) else [rights]
            member.append({"name": key[3:] if key.startswith("id:") else key, "by_id": key.startswith("id:"),
                           "access": "full" if "full" in rights else ",".join(str(r) for r in rights)})
    chats = [n for (n,) in (await s.execute(select(ChatGroup.name).join(ChatGroupMember, ChatGroupMember.group_id == ChatGroup.id)
                                            .where(ChatGroupMember.user_id == u.id).order_by(ChatGroup.name))).all()]
    keys = (await s.execute(select(func.count()).select_from(ApiKey).where(ApiKey.agent_id == u.id, ApiKey.revoked_at.is_(None)))).scalar() or 0
    queues = list(services.settings.queues) if (u.enabled and u.asterisk_interface) else []

    return {
        "now": {"online": bool(conns), "state": (st.computed_state if st else "offline") if conns else "offline",
                "manual_state": st.manual_state if st else "offline", "since": since,
                "online_since": min((c["since"] for c in conns if c.get("since")), default=None),
                "call": {"number": call.caller_number, "state": call.state} if call else None, "tasks": tasks},
        "signin": {"last_at": as_utc(last_ok.ts) if last_ok else as_utc(u.last_login_at), "last_ip": last_ok.ip if last_ok else "",
                   "last_device": device(last_ok.user_agent) if last_ok else "", "usual_ip": usual,
                   "usual": bool(last_ok and usual and last_ok.ip == usual), "password_changed_at": as_utc(pw),
                   "failed_24h": failed_24h, "must_change_password": u.must_change_password},
        "connections": [{"ip": c.get("ip", ""), "device": device(c.get("ua", "")), "since": c.get("since")} for c in conns],
        "lock": lock_view,
        "attempts": [{"ts": as_utc(a.ts), "ip": a.ip, "result": a.result, "device": device(a.user_agent)} for a in attempts],
        "member_of": member, "chat_groups": chats,
        "access": access_for(u.role),
        "telephony": {"extension": u.extension, "sip_user": u.sip_user or u.extension, "interface": u.asterisk_interface,
                      "queues": queues, "automation": u.enabled},
        "account": {"zammad_user_id": u.zammad_user_id, "zammad_name": f"{zu.firstname or ''} {zu.lastname or ''}".strip() if zu else "",
                    "created_at": as_utc(u.created_at), "api_keys": keys, "sessions_valid_after": as_utc(u.sessions_valid_after)},
    }


async def cleanup(s) -> int:
    """Sign-in attempts older than 30 days are deleted (retention job)."""
    from sqlalchemy import delete  # noqa: PLC0415
    r = await s.execute(delete(LoginAttempt).where(LoginAttempt.ts < utcnow() - timedelta(days=ATTEMPTS_KEEP_DAYS)))
    return r.rowcount or 0
