"""v3.17 — Zenith Desk with HTTPS built in: nothing between the browser and the server travels as plain text.

    python -m app.serve

* HTTPS on HTTPS_PORT (default 8443) with TLS 1.2 / 1.3 only and modern ciphers;
* the certificate: TLS_CERT_FILE + TLS_KEY_FILE (e.g. from Let's Encrypt or the company CA), otherwise a self-signed one
  is made once in TLS_DIR (default ./tls; in Docker /srv/tls) — the desktop client pins its fingerprint;
* plain HTTP on HTTP_PORT (default 8000; 0 = off) only answers with a redirect to HTTPS — no page, no data.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import ssl
import sys

import uvicorn

from .tls import fingerprint, server_cert

log = logging.getLogger("serve")
CIPHERS = "ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!3DES"


def redirect_app(https_port: int, public_port: int | None = None):
    """Plain HTTP: every request goes to the same address over HTTPS (308 keeps the method)."""
    port = public_port or https_port

    async def app(scope, receive, send):
        if scope["type"] == "lifespan":
            while True:
                message = await receive()
                if message["type"] == "lifespan.startup":
                    await send({"type": "lifespan.startup.complete"})
                elif message["type"] == "lifespan.shutdown":
                    await send({"type": "lifespan.shutdown.complete"})
                    return
        if scope["type"] != "http":
            return
        headers = dict(scope.get("headers") or [])
        host = headers.get(b"host", b"localhost").decode("latin-1").split(":")[0].strip("[]") or "localhost"
        if any(c in host for c in "/\\@ \t\r\n"):
            host = "localhost"
        if ":" in host:
            host = f"[{host}]"
        path = scope.get("raw_path", scope.get("path", "/").encode()).decode("latin-1") or "/"
        query = scope.get("query_string", b"").decode("latin-1")
        target = f"https://{host}{'' if port == 443 else ':' + str(port)}{path}" + (f"?{query}" if query else "")
        await send({"type": "http.response.start", "status": 308,
                    "headers": [(b"location", target.encode("latin-1")), (b"content-length", b"0"), (b"cache-control", b"no-store")]})
        await send({"type": "http.response.body", "body": b""})
    return app


def _ssl_factory(config, default):
    from .tls import SERVING  # noqa: PLC0415
    ctx = default()
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.set_ciphers(CIPHERS)
    ctx.options |= ssl.OP_NO_COMPRESSION
    SERVING.append(ctx)  # v3.18: a restored backup can bring back the certificate without a restart
    return ctx


async def run() -> None:
    host = os.environ.get("HOST", "0.0.0.0")  # nosec B104 — a server: every interface, but HTTPS only
    https_port = int(os.environ.get("HTTPS_PORT", "8443"))
    http_port = int(os.environ.get("HTTP_PORT", "8000"))
    public_port = int(os.environ.get("PUBLIC_HTTPS_PORT", "0") or 0) or None  # e.g. 443 when Docker maps 443:8443
    cert, key, made = server_cert(os.environ.get("TLS_DIR", "tls"), os.environ.get("TLS_CERT_FILE", ""), os.environ.get("TLS_KEY_FILE", ""))
    with open(cert, "rb") as f:
        der = ssl.PEM_cert_to_DER_cert(f.read().decode())
    print(f"Zenith Desk HTTPS on {host}:{https_port} — certificate {cert}"
          f"{' (self-signed, made now)' if made else ''}, SHA-256 {fingerprint(der)}", flush=True)
    os.environ.setdefault("FORCE_HTTPS", "true")
    main = uvicorn.Server(uvicorn.Config(
        "app.main:get_app", factory=True, host=host, port=https_port, ssl_certfile=cert, ssl_keyfile=key,
        ssl_context_factory=_ssl_factory, proxy_headers=os.environ.get("PROXY_HEADERS", "false").lower() == "true",
        forwarded_allow_ips=os.environ.get("FORWARDED_ALLOW_IPS", "127.0.0.1"), server_header=False))
    servers = [main.serve()]
    if http_port:
        plain = uvicorn.Server(uvicorn.Config(redirect_app(https_port, public_port), host=host, port=http_port,
                                              lifespan="off", access_log=False, server_header=False))
        plain.capture_signals = contextlib.nullcontext  # the HTTPS server handles Ctrl+C / SIGTERM for both
        servers.append(_stop_with(plain, main))
    await asyncio.gather(*servers)


async def _stop_with(plain: uvicorn.Server, main: uvicorn.Server) -> None:
    task = asyncio.create_task(plain.serve())
    while not main.should_exit and not task.done():
        await asyncio.sleep(0.3)
    plain.should_exit = True
    await task


def main() -> int:
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
