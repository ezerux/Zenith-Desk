"""Queue-member control on top of AMI (ТЗ 7.2).

The service manages ONLY the queues listed in MANAGED_QUEUES and ONLY members that are
mapped in agent_mapping. Success of a command is verified by re-reading QueueStatus,
not by the fact that the command was sent.
"""
from dataclasses import dataclass
from typing import Protocol

from .ami import AMIClient, AMIError


@dataclass
class MemberStatus:
    queue: str
    present: bool
    paused: bool = False
    paused_reason: str = ""
    in_call: bool = False
    device_status: str = ""  # Asterisk device state code as string
    penalty: int | None = None  # v3.11


@dataclass
class QueueMember:
    """v3.11: one member as Asterisk sees it (routing panel)."""
    interface: str
    name: str = ""
    state_interface: str = ""
    penalty: int = 0
    paused: bool = False
    paused_reason: str = ""
    in_call: bool = False
    status: str = ""  # device state code: 1 not in use, 2 in use, 3 busy, 4 invalid, 5 unavailable, 6 ringing, 7 ringinuse, 8 on hold
    calls_taken: int = 0
    last_call: int = 0


@dataclass
class QueueInfo:
    queue: str
    strategy: str = ""
    calls: int = 0
    completed: int = 0
    abandoned: int = 0
    members: list = None  # list[QueueMember]


class Pbx(Protocol):
    @property
    def connected(self) -> bool: ...

    async def member_status(self, interface: str, queues: list[str]) -> dict[str, MemberStatus]: ...

    async def set_paused(self, interface: str, queue: str, paused: bool, reason: str) -> None: ...

    async def set_penalty(self, interface: str, queue: str, penalty: int) -> None: ...

    async def queue_info(self, queues: list[str]) -> list[QueueInfo]: ...

    async def spy(self, dial: str, target: str, mode: str, caller_id: str, channel_id: str) -> None: ...

    async def hangup(self, channel: str) -> None: ...

    async def redirect(self, channel: str, context: str, exten: str, priority: int = 1) -> None: ...

    async def set_strategy(self, queue: str, strategy: str, filename: str) -> None: ...


# v3.15 call supervision: ChanSpy options. q = no beep, d = keys 4/5/6 switch listen/whisper/barge during the call,
# E = end when the operator's call ends; w = whisper (only the operator hears the manager), B = barge (both hear him)
SPY_OPTIONS = {"listen": "qdE", "whisper": "qdEw", "barge": "qdEB"}
SPY_DIGITS = {"listen": "4", "whisper": "5", "barge": "6"}
SPY_PREFIX = "zspy"  # unique id of the manager's channel: the call tracker ignores these calls


def _int(v) -> int:
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return 0


def _same_interface(a: str, b: str) -> bool:
    return a.strip().lower() == b.strip().lower()


class AmiPbx:
    def __init__(self, ami: AMIClient):
        self.ami = ami

    @property
    def connected(self) -> bool:
        return self.ami.connected

    async def member_status(self, interface: str, queues: list[str]) -> dict[str, MemberStatus]:
        result: dict[str, MemberStatus] = {}
        for queue in queues:
            resp, events = await self.ami.action_list("QueueStatus", "QueueStatusComplete", Queue=queue, Member=interface)
            if resp.get("Response") != "Success":
                raise AMIError(f"QueueStatus {queue}: {resp.get('Message', 'error')}")
            status = MemberStatus(queue=queue, present=False)
            for ev in events:
                if ev.get("Event") != "QueueMember" or ev.get("Queue") != queue:
                    continue
                candidates = [ev.get("Location", ""), ev.get("Interface", ""), ev.get("StateInterface", "")]
                if any(c and _same_interface(c, interface) for c in candidates):
                    status = MemberStatus(
                        queue=queue,
                        present=True,
                        paused=ev.get("Paused", "0") in ("1", "true", "yes"),
                        paused_reason=ev.get("PausedReason", ""),
                        in_call=ev.get("InCall", "0") == "1",
                        device_status=ev.get("Status", ""),
                        penalty=_int(ev.get("Penalty")) if ev.get("Penalty") not in (None, "") else None,
                    )
                    break
            result[queue] = status
        return result

    async def set_paused(self, interface: str, queue: str, paused: bool, reason: str) -> None:
        fields = {"Interface": interface, "Queue": queue, "Paused": "true" if paused else "false"}
        if paused and reason:
            fields["Reason"] = reason
        resp = await self.ami.action("QueuePause", **fields)
        if resp.get("Response") != "Success":
            raise AMIError(f"QueuePause {queue}/{interface}: {resp.get('Message', 'error')}")

    async def set_penalty(self, interface: str, queue: str, penalty: int) -> None:
        """v3.11: AMI QueuePenalty (needs the same `agent` write permission as QueuePause)."""
        resp = await self.ami.action("QueuePenalty", Interface=interface, Penalty=str(int(penalty)), Queue=queue)
        if resp.get("Response") != "Success":
            raise AMIError(f"QueuePenalty {queue}/{interface}: {resp.get('Message', 'error')}")

    async def spy(self, dial: str, target: str, mode: str, caller_id: str, channel_id: str) -> None:
        """Ring the manager's phone; when he answers, ChanSpy connects him to the operator's call (needs write=originate)."""
        resp = await self.ami.action("Originate", Channel=dial, Application="ChanSpy", Data=f"{target},{SPY_OPTIONS[mode]}",
                                     CallerID=caller_id, Timeout="30000", Async="true", ChannelId=channel_id)
        if resp.get("Response") != "Success":
            raise AMIError(f"Originate {dial}: {resp.get('Message', 'error')}")

    async def hangup(self, channel: str) -> None:
        """End the manager's listening channel (by its unique id; needs write=call)."""
        resp = await self.ami.action("Hangup", Channel=channel)
        if resp.get("Response") != "Success":
            raise AMIError(f"Hangup {channel}: {resp.get('Message', 'error')}")

    async def redirect(self, channel: str, context: str, exten: str, priority: int = 1) -> None:
        """v3.18 VIP routing: move a waiting customer to an employee's phone (or back into a queue). AMI write = call."""
        resp = await self.ami.action("Redirect", Channel=channel, Context=context, Exten=exten, Priority=str(priority))
        if resp.get("Response") != "Success":
            raise AMIError(f"Redirect {channel}: {resp.get('Message', 'error')}")

    async def set_strategy(self, queue: str, strategy: str, filename: str) -> None:
        """v3.18: the ring strategy of a queue — written into the queues file and the queue's parameters reloaded
        (its members, pauses and penalties stay as they are). AMI write = config."""
        resp = await self.ami.action("UpdateConfig", SrcFilename=filename, DstFilename=filename, **{
            "Action-000000": "Update", "Cat-000000": queue, "Var-000000": "strategy", "Value-000000": strategy})
        if resp.get("Response") != "Success":
            resp = await self.ami.action("UpdateConfig", SrcFilename=filename, DstFilename=filename, **{
                "Action-000000": "Append", "Cat-000000": queue, "Var-000000": "strategy", "Value-000000": strategy})
        if resp.get("Response") != "Success":
            raise AMIError(f"UpdateConfig {filename} [{queue}]: {resp.get('Message', 'error')}")
        resp = await self.ami.action("QueueReload", Queue=queue, Members="no", Rules="no", Parameters="yes")
        if resp.get("Response") != "Success":
            raise AMIError(f"QueueReload {queue}: {resp.get('Message', 'error')}")

    async def queue_info(self, queues: list[str]) -> list[QueueInfo]:
        out = []
        for queue in queues:
            resp, events = await self.ami.action_list("QueueStatus", "QueueStatusComplete", Queue=queue)
            if resp.get("Response") != "Success":
                raise AMIError(f"QueueStatus {queue}: {resp.get('Message', 'error')}")
            info = QueueInfo(queue=queue, members=[])
            for ev in events:
                if ev.get("Queue") != queue:
                    continue
                if ev.get("Event") == "QueueParams":
                    info.strategy = ev.get("Strategy", "")
                    info.calls, info.completed, info.abandoned = _int(ev.get("Calls")), _int(ev.get("Completed")), _int(ev.get("Abandoned"))
                elif ev.get("Event") == "QueueMember":
                    info.members.append(QueueMember(
                        interface=ev.get("Location") or ev.get("Interface", ""), name=ev.get("Name") or ev.get("MemberName", ""),
                        state_interface=ev.get("StateInterface", ""), penalty=_int(ev.get("Penalty")),
                        paused=ev.get("Paused", "0") in ("1", "true", "yes"), paused_reason=ev.get("PausedReason", ""),
                        in_call=ev.get("InCall", "0") == "1", status=ev.get("Status", ""), calls_taken=_int(ev.get("CallsTaken")),
                        last_call=_int(ev.get("LastCall"))))
            out.append(info)
        return out
