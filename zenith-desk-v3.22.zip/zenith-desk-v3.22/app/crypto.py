"""Password hashing (scrypt, stdlib) and encryption of secret settings (Fernet)."""
import base64
import hashlib
import hmac
import os
import weakref

from cryptography.fernet import Fernet, InvalidToken

# SEC-08: p raised from 1 to 5 (OWASP: scrypt N=2^14, r=8, p=5 — same 16 MiB memory, 5x the work per guess).
# Older hashes stay valid and are upgraded at the next successful sign-in (needs_rehash).
_N, _R, _P = 2**14, 8, 5
_MAX = {"n": 2**17, "r": 16, "p": 16}  # a stored hash asking for more is refused instead of exhausting memory / CPU
_slots: "weakref.WeakKeyDictionary" = weakref.WeakKeyDictionary()


def _limits():
    import asyncio  # noqa: PLC0415
    loop = asyncio.get_running_loop()
    if loop not in _slots:
        _slots[loop] = asyncio.Semaphore(4)
    return _slots[loop]


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P, dklen=32)
    return f"scrypt${_N}${_R}${_P}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, n, r, p, salt, dk = stored.split("$")
        if algo != "scrypt":
            return False
        n, r, p = int(n), int(r), int(p)
        if not (1 < n <= _MAX["n"] and 0 < r <= _MAX["r"] and 0 < p <= _MAX["p"]):
            return False
        calc = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=n, r=r, p=p, dklen=32, maxmem=256 * 1024 * 1024)
        return hmac.compare_digest(calc, base64.b64decode(dk))
    except (ValueError, TypeError, MemoryError):
        return False


def needs_rehash(stored: str) -> bool:
    """SEC-08: True for a hash made with weaker parameters than today's."""
    try:
        algo, n, r, p, _salt, _dk = stored.split("$")
        return algo != "scrypt" or (int(n), int(r), int(p)) != (_N, _R, _P)
    except ValueError:
        return True


async def verify_password_async(password: str, stored: str) -> bool:
    """SEC-08/09: the hash runs in a worker thread (the server keeps answering everyone else meanwhile) and at most
    four at a time, so a burst of sign-in attempts cannot take all CPU / memory."""
    import asyncio  # noqa: PLC0415
    async with _limits():
        return await asyncio.to_thread(verify_password, password, stored)


async def hash_password_async(password: str) -> str:
    import asyncio  # noqa: PLC0415
    async with _limits():
        return await asyncio.to_thread(hash_password, password)


class MessageCipher:
    """Chat messages are encrypted at rest (v3.1): a database dump or backup does not reveal conversations.
    Key derived from the server's secret (JWT_SECRET), separate from the settings key."""
    PREFIX = "v1:"

    def __init__(self, master_key: str):
        key = hashlib.sha256(b"agentix-chat:" + master_key.encode()).digest()
        self._f = Fernet(base64.urlsafe_b64encode(key))

    def seal(self, text: str) -> str:
        return self.PREFIX + self._f.encrypt(text.encode()).decode()

    BIN = b"ZDX1:"  # v3.17: files (messenger photos, documents) are encrypted at rest too

    def seal_bytes(self, data: bytes) -> bytes:
        return self.BIN + self._f.encrypt(data)

    def open_bytes(self, stored: bytes) -> bytes:
        stored = bytes(stored or b"")
        if not stored.startswith(self.BIN):
            return stored  # stored before v3.17 (encrypted by the start-up migration)
        try:
            return self._f.decrypt(stored[len(self.BIN):])
        except (InvalidToken, ValueError):
            return b""

    def open(self, stored: str) -> str:
        if not stored.startswith(self.PREFIX):
            return stored  # written before v3.1; encrypted by the start-up migration
        try:
            return self._f.decrypt(stored[len(self.PREFIX):].encode()).decode()
        except (InvalidToken, ValueError):
            return ""


class SecretBox:
    """Encrypts secrets with a key derived from the server's SECRET_KEY (JWT_SECRET)."""

    def __init__(self, master_key: str):
        key = hashlib.sha256(b"agentix-settings:" + master_key.encode()).digest()
        self._f = Fernet(base64.urlsafe_b64encode(key))

    def encrypt(self, value: str) -> str:
        return self._f.encrypt(value.encode()).decode()

    def decrypt(self, token: str) -> str | None:
        try:
            return self._f.decrypt(token.encode()).decode()
        except (InvalidToken, ValueError):
            return None
