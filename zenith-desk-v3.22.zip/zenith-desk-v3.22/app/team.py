"""v3.18 the team right now — what a manager sees about his people this second.

* the live board: for every employee the phase of his call (ringing / dialing / talking / on hold / wrap-up) with the
  number, customer and queue, how long he is in his state, the ticket he works on and for how long;
* the queues: customers waiting now (and for how long), free operators, today's numbers per queue;
* the call feed: the last calls of the whole team (who, which number, how long, the result), live;
* one person's day: a timeline of states and calls, the day's numbers and his calls;
* alerts for managers (thresholds in Settings → Manager tools): long call, long break, a call not answered by the
  operator (RONA), too many customers waiting, a missed customer call;
* everything for the wallboard (a TV in the office).

Built only from what Zenith Desk records already: call_record, queue_call, the availability_changed audit trail and
work sessions — plus the hold state reported by Asterisk (AMI Hold / Unhold), kept in memory.
"""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from datetime import datetime, timedelta

from sqlalchemy import func, or_, select

from .audit import audit
from .db import as_utc, utcnow
from .i18n import t as tr
from .metrics import RONA_TOLERANCE, STALE_WAIT, call_summary, customer_calls, state_intervals
from .models import AgentMapping, AgentState, AuditLog, CallRecord, QueueCall, WorkSession

log = logging.getLogger("team")

RING_STALE = timedelta(minutes=10)   # a ring without an end after this long is a lost event, not a ringing phone
TALK_STALE = timedelta(hours=12)
SINCE_LOOKBACK = timedelta(days=14)  # the state change we look for is never older than this
ALERT_EVERY = 15                     # seconds between alert checks
RONA_SETTLE = timedelta(seconds=5)   # wait so a colleague's answer of the same call is recorded first
PHASES = ("ringing", "dialing", "talking", "hold", "wrap_up")


# ====================================================================== the live board
async def state_since(s, agent_ids: list[int], now: datetime) -> dict[int, datetime]:
    """When each employee's current state began (his last availability_changed)."""
    if not agent_ids:
        return {}
    last_ids = (select(func.max(AuditLog.id)).where(
        AuditLog.action == "availability_changed", AuditLog.agent_id.in_(agent_ids), AuditLog.ts >= now - SINCE_LOOKBACK)
        .group_by(AuditLog.agent_id))
    rows = (await s.execute(select(AuditLog.agent_id, AuditLog.ts).where(AuditLog.id.in_(last_ids)))).all()
    return {a: as_utc(ts) for a, ts in rows}


async def live_calls(s, now: datetime) -> dict[int, CallRecord]:
    """The call each employee is in right now: a conversation wins over a ring (the newest of each)."""
    rows = (await s.execute(select(CallRecord).where(
        CallRecord.agent_id.is_not(None), CallRecord.ended_at.is_(None), CallRecord.state.in_(("ringing", "answered")),
        CallRecord.started_at >= now - TALK_STALE).order_by(CallRecord.started_at))).scalars().all()
    out: dict[int, CallRecord] = {}
    for r in rows:
        if r.state == "ringing" and now - as_utc(r.started_at) > RING_STALE:
            continue
        cur = out.get(r.agent_id)
        if cur is None or r.state == "answered" or cur.state != "answered":
            out[r.agent_id] = r
    return out


def phase_of(st: AgentState | None, call: CallRecord | None, hold_since: datetime | None, since: datetime | None) -> dict:
    if call is not None and call.state == "answered":
        if hold_since:
            return {"phase": "hold", "phase_since": hold_since}
        return {"phase": "talking", "phase_since": as_utc(call.answered_at)}
    if call is not None:
        return {"phase": "ringing" if call.direction == "in" else "dialing", "phase_since": as_utc(call.started_at)}
    if st is not None and st.computed_state == "wrap_up":
        return {"phase": "wrap_up", "phase_since": since}
    return {"phase": None, "phase_since": None}


def call_brief(c: CallRecord | None) -> dict | None:
    if c is None:
        return None
    return {"id": c.id, "number": c.caller_number, "name": c.caller_name, "direction": c.direction, "queue": c.queue,
            "started_at": as_utc(c.started_at), "answered_at": as_utc(c.answered_at), "ticket_id": c.ticket_id}


def enrich(view: dict, st: AgentState | None, call: CallRecord | None, hold_since: datetime | None,
           since: datetime | None, blocking: list[dict]) -> dict:
    """Adds the live fields of v3.18 to an agent_state_view of the manager panel."""
    view["state_since"] = since
    view.update(phase_of(st, call, hold_since, since))
    view["live_call"] = call_brief(call)
    w = blocking[0] if blocking else None
    view["work"] = {"ticket_id": w["ticket_id"], "number": w["ticket_number"], "title": w["ticket_title"],
                    "started_at": w["started_at"]} if w else None
    # the filter groups of the board
    if view["phase"] in ("ringing", "dialing", "talking", "hold"):
        view["group"] = "call"
    elif view["computed_state"] == "offline":
        view["group"] = "offline"
    elif view["computed_state"] == "break":
        view["group"] = "break"
    elif view["computed_state"] == "ready" and not view.get("dnd"):
        view["group"] = "free"
    else:
        view["group"] = "busy"  # a blocking task, wrap-up, do-not-disturb
    return view


# ====================================================================== queues and today
def _waiting_by_queue(qcalls, now: datetime) -> dict[str, list[QueueCall]]:
    out: dict[str, list[QueueCall]] = defaultdict(list)
    for q in qcalls:
        if q.outcome == "waiting" and q.answered_at is None and q.left_at is None and now - as_utc(q.joined_at) < STALE_WAIT:
            out[q.queue or "?"].append(q)
    return out


async def team_live(s, sv, start: datetime, now: datetime, feed_limit: int = 50) -> dict:
    """Queues now + today's numbers + the call feed (one query set for the manager panel and the wallboard)."""
    cfg = sv.settings
    feed_from = min(start, now - timedelta(hours=24))
    qcalls = (await s.execute(select(QueueCall).where(QueueCall.joined_at >= min(feed_from, now - STALE_WAIT))))\
        .scalars().all()
    records = (await s.execute(select(CallRecord).where(CallRecord.started_at >= feed_from - timedelta(hours=1)))).scalars().all()
    agents = (await s.execute(select(AgentMapping))).scalars().all()
    names = {a.id: a.display_name or a.username or "" for a in agents}
    states = {x.agent_id: x for x in (await s.execute(select(AgentState))).scalars().all()}
    talking = await live_calls(s, now)

    today_calls = customer_calls(qcalls, records, start, now + timedelta(seconds=1), now)
    summary = call_summary(today_calls, cfg.sla_answer_seconds, cfg.short_abandon_seconds)
    summary["outbound"] = len({r.linkedid for r in records if r.direction == "out" and as_utc(r.started_at) >= start})

    # who can take a call now: signed in, Ready, not on a call, not «do not disturb», in the managed queues
    staff = [a for a in agents if a.active and a.role != "admin"]
    free_ids = [a.id for a in staff if a.asterisk_interface and states.get(a.id) and states[a.id].computed_state == "ready"
                and not states[a.id].dnd and a.id not in talking]
    managed = set(cfg.queues)
    waiting = _waiting_by_queue(qcalls, now)
    queue_names = list(dict.fromkeys([*cfg.queues, *sorted({c["queue"] for c in today_calls if c["queue"]}), *sorted(waiting)]))
    queues = []
    for name in queue_names:
        mine = [c for c in today_calls if c["queue"] == name]
        w = sorted(waiting.get(name, []), key=lambda q: as_utc(q.joined_at))
        sm = call_summary(mine, cfg.sla_answer_seconds, cfg.short_abandon_seconds)
        queues.append({
            "queue": name, "managed": name in managed,
            "waiting": len(w),
            "longest_wait_sec": int((now - as_utc(w[0].joined_at)).total_seconds()) if w else 0,
            "callers": [{"number": q.caller_number, "name": q.caller_name, "joined_at": as_utc(q.joined_at),
                         "wait_sec": int((now - as_utc(q.joined_at)).total_seconds())} for q in w[:20]],
            "free": len(free_ids) if name in managed else None,
            "talking": sum(1 for c in talking.values() if c.state == "answered" and c.queue == name),
            "today": {k: sm[k] for k in ("offered", "answered", "missed", "service_level", "asa_sec", "longest_wait_sec", "aht_talk_sec")},
        })

    counts = defaultdict(int)
    for a in staff:
        st = states.get(a.id)
        counts[st.computed_state if st else "offline"] += 1
    in_call = [c for c in talking.values() if c.agent_id in {a.id for a in staff}]
    return {
        "now": now,
        "today": {**summary, "sla_target": cfg.sla_target_percent / 100, "sla_answer_seconds": cfg.sla_answer_seconds},
        "queues": queues,
        "waiting_total": sum(q["waiting"] for q in queues),
        "longest_wait_sec": max((q["longest_wait_sec"] for q in queues), default=0),
        "free_total": len(free_ids),
        "talking_total": sum(1 for c in in_call if c.state == "answered"),
        "ringing_total": sum(1 for c in in_call if c.state == "ringing"),
        "agents": {k: counts.get(k, 0) for k in ("ready", "busy_task", "wrap_up", "break", "offline")},
        "feed": call_feed(qcalls, records, names, feed_from, now, feed_limit),
    }


def raw_numbers(qcalls, records) -> dict[str, str]:
    """linkedid → the caller's number as the PBX gave it (the statistics use the normalized one)."""
    raw = {q.linkedid: q.caller_number for q in qcalls if q.caller_number}
    for r in records:
        if r.direction == "in" and r.caller_number:
            raw.setdefault(r.linkedid, r.caller_number)
    return raw


def call_feed(qcalls, records, names: dict[int, str], since: datetime, now: datetime, limit: int = 50) -> list[dict]:
    """The team's last calls, newest first: one entry per customer call or outgoing call."""
    by_link: dict[str, list[CallRecord]] = defaultdict(list)
    for r in records:
        by_link[r.linkedid].append(r)
    raw = raw_numbers(qcalls, records)
    items = []
    for c in customer_calls(qcalls, records, since, now + timedelta(seconds=1), now):
        rs = by_link.get(c["linkedid"], [])
        live = any(r.answered_at and not r.ended_at for r in rs) and c["outcome"] == "answered"
        ans = next((r for r in rs if r.agent_id == c["agent_id"] and r.answered_at), None)
        rang = sorted({names.get(r.agent_id, "") for r in rs if r.agent_id and r.agent_id != c["agent_id"]} - {""})
        items.append({
            "id": c["linkedid"], "direction": "in", "start": c["start"], "number": raw.get(c["linkedid"], c["number"]), "name": c["name"],
            "queue": c["queue"], "agent_id": c["agent_id"], "agent": names.get(c["agent_id"], ""),
            "result": "talking" if live else c["outcome"],  # answered | abandoned | unanswered | waiting | talking
            "wait_sec": int(c["wait"]), "talk_sec": int(c["talk"]) if c["talk"] is not None else None,
            "ticket_id": ans.ticket_id if ans else None, "rang": rang,
        })
    out_links: dict[str, list[CallRecord]] = defaultdict(list)
    for r in records:
        if r.direction == "out" and as_utc(r.started_at) >= since:
            out_links[r.linkedid].append(r)
    for linkedid, rs in out_links.items():
        r = min(rs, key=lambda x: as_utc(x.started_at))
        answered = as_utc(r.answered_at)
        if r.ended_at is None and r.state in ("ringing", "answered") and now - as_utc(r.started_at) < (TALK_STALE if answered else RING_STALE):
            result = "talking" if answered else "dialing"
        else:
            result = "connected" if answered else "no_answer"
        talk = int(((as_utc(r.ended_at) or now) - answered).total_seconds()) if answered else None
        items.append({
            "id": linkedid, "direction": "out", "start": as_utc(r.started_at), "number": r.caller_number, "name": r.caller_name,
            "queue": "", "agent_id": r.agent_id, "agent": names.get(r.agent_id, ""), "result": result,
            "wait_sec": None, "talk_sec": talk, "ticket_id": r.ticket_id, "rang": [],
        })
    items.sort(key=lambda x: x["start"], reverse=True)
    return items[:limit]


# ====================================================================== one person's day
async def agent_day(s, sv, agent: AgentMapping, start: datetime, end: datetime, now: datetime) -> dict:
    from .metrics import compute_overview  # noqa: PLC0415
    cfg = sv.settings
    eff_end = min(end, now)
    records = (await s.execute(select(CallRecord).where(
        CallRecord.started_at >= start - timedelta(hours=1), CallRecord.started_at < end))).scalars().all()
    qcalls = (await s.execute(select(QueueCall).where(QueueCall.joined_at >= start, QueueCall.joined_at < end))).scalars().all()
    sessions = (await s.execute(select(WorkSession).where(
        WorkSession.agent_id == agent.id, WorkSession.started_at < end,
        or_(WorkSession.ended_at.is_(None), WorkSession.ended_at >= start)))).scalars().all()
    events = (await s.execute(select(AuditLog).where(
        AuditLog.action == "availability_changed", AuditLog.agent_id == agent.id, AuditLog.ts >= start, AuditLog.ts < eff_end)
        .order_by(AuditLog.ts, AuditLog.id))).scalars().all()
    before = (await s.execute(select(AuditLog).where(
        AuditLog.action == "availability_changed", AuditLog.agent_id == agent.id, AuditLog.ts < start)
        .order_by(AuditLog.id.desc()).limit(1))).scalars().first()
    st_now = await s.get(AgentState, agent.id)
    initial = {agent.id: (before.details or {}).get("new", "offline") if before else "offline"}
    ov = compute_overview(start=start, end=end, now=now, tz=cfg.display_timezone, agents=[agent],
                          states_now={agent.id: st_now} if st_now else {}, queue_calls=qcalls, records=records,
                          sessions=sessions, events=events, initial_states=initial, sla_sec=cfg.sla_answer_seconds,
                          short_sec=cfg.short_abandon_seconds, sla_target=cfg.sla_target_percent / 100)
    row = ov["agents"][0]
    mine = sorted((r for r in records if r.agent_id == agent.id and start <= as_utc(r.started_at) < end),
                  key=lambda r: as_utc(r.started_at), reverse=True)
    answered_by_link: dict[str, list] = defaultdict(list)
    for r in records:
        if r.answered_at:
            answered_by_link[r.linkedid].append(r)

    def result(r: CallRecord) -> str:
        if r.answered_at:
            return "talking" if r.ended_at is None else "answered"
        if r.ended_at is None and r.state == "ringing" and now - as_utc(r.started_at) < RING_STALE:
            return "ringing" if r.direction == "in" else "dialing"
        if r.direction == "out":
            return "no_answer"
        ended = as_utc(r.ended_at) or as_utc(r.started_at)
        others = [o for o in answered_by_link.get(r.linkedid, []) if o.agent_id != agent.id]
        return "colleague" if any(as_utc(o.answered_at) <= ended + RONA_TOLERANCE for o in others) else "missed"

    calls = []
    for r in mine:
        answered, ended = as_utc(r.answered_at), as_utc(r.ended_at)
        calls.append({"id": r.id, "start": as_utc(r.started_at), "direction": r.direction, "number": r.caller_number,
                      "name": r.caller_name, "queue": r.queue, "result": result(r),
                      "ring_sec": int(((answered or ended or now) - as_utc(r.started_at)).total_seconds()),
                      "talk_sec": int(((ended or now) - answered).total_seconds()) if answered else None,
                      "ticket_id": r.ticket_id, "recording": bool(r.recording_file)})
    timeline = state_intervals(events, initial, start, eff_end).get(agent.id, {})
    states_lane = sorted(({"state": st, "from": a, "to": b} for st, ivs in timeline.items() for a, b in ivs), key=lambda x: x["from"])
    calls_lane = []
    for r in mine:
        if r.answered_at:
            a, b = max(as_utc(r.answered_at), start), min(as_utc(r.ended_at) or now, eff_end)
            if b > a:
                calls_lane.append({"direction": r.direction, "from": a, "to": b, "number": r.caller_number})
    online = [x for x in states_lane if x["state"] != "offline"]
    return {
        "agent": {"id": agent.id, "name": agent.display_name, "level": agent.level, "position": agent.position,
                  "extension": agent.extension, "avatar_url": agent.avatar_url},
        "from": start, "to": end, "now": now, "timezone": cfg.display_timezone,
        "stats": {
            "inbound_rang": row["calls_rang"], "inbound_answered": row["calls_answered"], "rona": row["rona"],
            "inbound_missed": sum(1 for c in calls if c["direction"] == "in" and c["result"] == "missed"),
            "outbound": row["outbound"], "outbound_connected": len({r.linkedid for r in mine if r.direction == "out" and r.answered_at}),
            "talk_sec": row["talk_sec"], "aht_talk_sec": row["aht_talk_sec"],
            "break_sec": row["break_sec"], "logged_in_sec": row["logged_in_sec"], "ready_sec": row["ready_sec"],
            "busy_task_sec": row["busy_task_sec"], "occupancy": row["occupancy"],
            "tickets_completed": row["tickets_completed"], "tickets_started": row["tickets_started"],
            "first_in": online[0]["from"] if online else None, "last_out": None if (online and online[-1]["to"] >= eff_end) else
            (online[-1]["to"] if online else None),
        },
        "states": states_lane, "calls_lane": calls_lane, "calls": calls[:200],
    }


# ====================================================================== alerts for managers
def alert_text(d: dict) -> str:
    kind = d.get("kind")
    name, number = d.get("name") or "—", d.get("number") or tr("team.unknown_number")
    if kind == "long_call":
        return tr("ntf.team_long_call", name=name, number=number, min=d.get("minutes", 0))
    if kind == "long_break":
        return tr("ntf.team_long_break", name=name, min=d.get("minutes", 0))
    if kind == "rona":
        return tr("ntf.team_rona", name=name, number=number)
    if kind == "queue":
        return tr("ntf.team_queue", n=d.get("waiting", 0), queue=d.get("queue", ""), wait=fmt_sec(d.get("longest_wait_sec", 0)))
    if kind == "missed":
        key = "ntf.team_missed_abandoned" if d.get("outcome") == "abandoned" else "ntf.team_missed_unanswered"
        caller = number + (f" ({d['caller']})" if d.get("caller") else "")
        return tr(key, number=caller, queue=d.get("queue") or "—", wait=fmt_sec(d.get("wait_sec", 0)))
    return kind or ""


def fmt_sec(sec) -> str:
    sec = int(sec or 0)
    return f"{sec // 60}:{sec % 60:02d}"


class TeamWatch:
    """Checks the team every few seconds and tells the managers (bell, toast, push) once per problem."""

    def __init__(self, services):
        self.sv = services
        self._task: asyncio.Task | None = None
        self.started_at: datetime | None = None
        self.sent: dict[str, datetime] = {}
        self.queue_over: set[str] = set()

    def start(self) -> None:
        self.started_at = utcnow()
        self._task = asyncio.create_task(self._loop(), name="team-watch")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None

    async def _loop(self) -> None:
        try:
            await self._load_sent()
        except Exception:  # noqa: BLE001
            log.exception("team alerts: cannot read the sent ones")
        while True:
            await asyncio.sleep(ALERT_EVERY)
            try:
                await self.check()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("team alert check failed")

    async def _load_sent(self) -> None:
        """Alerts sent before a restart are not sent again."""
        since = utcnow() - timedelta(hours=24)
        async with self.sv.db.sessionmaker() as s:
            rows = (await s.execute(select(AuditLog).where(AuditLog.action == "team_alert", AuditLog.ts >= since))).scalars().all()
        for r in rows:
            k = (r.details or {}).get("key")
            if k:
                self.sent[k] = as_utc(r.ts)

    async def check(self, now: datetime | None = None) -> list[dict]:
        cfg = self.sv.settings
        now = now or utcnow()
        started = self.started_at or now
        found: list[dict] = []
        async with self.sv.db.sessionmaker() as s:
            staff = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True), AgentMapping.role != "admin"))).scalars().all()
            names = {a.id: a.display_name or a.username or "" for a in staff}
            ids = list(names)
            if cfg.alert_long_call_min > 0:
                for aid, c in (await live_calls(s, now)).items():
                    if aid in names and c.state == "answered":
                        minutes = int((now - as_utc(c.answered_at)).total_seconds() // 60)
                        if minutes >= cfg.alert_long_call_min:
                            found.append({"kind": "long_call", "key": f"long_call:{c.id}", "agent_id": aid, "name": names[aid],
                                          "number": c.caller_number, "minutes": minutes, "call_id": c.id})
            if cfg.alert_long_break_min > 0 and ids:
                since = await state_since(s, ids, now)
                for st in (await s.execute(select(AgentState).where(AgentState.agent_id.in_(ids)))).scalars().all():
                    t0 = since.get(st.agent_id)
                    if st.computed_state == "break" and t0:
                        minutes = int((now - t0).total_seconds() // 60)
                        if minutes >= cfg.alert_long_break_min:
                            found.append({"kind": "long_break", "key": f"long_break:{st.agent_id}:{t0.isoformat()}",
                                          "agent_id": st.agent_id, "name": names[st.agent_id], "minutes": minutes})
            window = max(started, now - timedelta(hours=2))
            if cfg.alert_rona:
                missed = (await s.execute(select(CallRecord).where(
                    CallRecord.direction == "in", CallRecord.state == "missed", CallRecord.ended_at >= window,
                    CallRecord.ended_at <= now - RONA_SETTLE, CallRecord.agent_id.in_(ids or [0])))).scalars().all()
                links = {r.linkedid for r in missed}
                answered = (await s.execute(select(CallRecord).where(
                    CallRecord.linkedid.in_(links), CallRecord.answered_at.is_not(None)))).scalars().all() if links else []
                for r in missed:
                    ended = as_utc(r.ended_at)
                    if any(o.linkedid == r.linkedid and o.agent_id != r.agent_id and as_utc(o.answered_at) <= ended + RONA_TOLERANCE
                           for o in answered):
                        continue  # a colleague picked it up: not this operator's fault
                    found.append({"kind": "rona", "key": f"rona:{r.id}", "agent_id": r.agent_id, "name": names.get(r.agent_id, ""),
                                  "number": r.caller_number, "call_id": r.id})
            if cfg.alert_queue_waiting > 0 or cfg.alert_missed_calls:
                qcalls = (await s.execute(select(QueueCall).where(QueueCall.joined_at >= now - STALE_WAIT))).scalars().all()
                if cfg.alert_queue_waiting > 0:
                    for q, rows in _waiting_by_queue(qcalls, now).items():
                        if len(rows) >= cfg.alert_queue_waiting:
                            if q not in self.queue_over:
                                self.queue_over.add(q)
                                oldest = min(as_utc(x.joined_at) for x in rows)
                                found.append({"kind": "queue", "key": f"queue:{q}:{now.isoformat()}", "agent_id": None, "queue": q,
                                              "waiting": len(rows), "longest_wait_sec": int((now - oldest).total_seconds())})
                    still = {q for q, rows in _waiting_by_queue(qcalls, now).items() if len(rows) >= cfg.alert_queue_waiting}
                    self.queue_over &= still  # under the threshold again: the next time is a new alert
                if cfg.alert_missed_calls:
                    records = (await s.execute(select(CallRecord).where(CallRecord.started_at >= window - timedelta(hours=1)))).scalars().all()
                    raw = raw_numbers(qcalls, records)
                    for c in customer_calls(qcalls, records, window, now + timedelta(seconds=1), now):
                        if c["outcome"] == "unanswered" or (c["outcome"] == "abandoned" and c["wait"] > cfg.short_abandon_seconds):
                            found.append({"kind": "missed", "key": f"missed:{c['linkedid']}", "agent_id": None,
                                          "number": raw.get(c["linkedid"], c["number"]),
                                          "caller": c["name"], "queue": c["queue"], "outcome": c["outcome"], "wait_sec": int(c["wait"])})
            fresh = [a for a in found if a["key"] not in self.sent]
            for a in fresh:
                self.sent[a["key"]] = now
                audit(s, "team_alert", agent_id=a.get("agent_id"), level="warning", actor_type="system",
                      **{k: v for k, v in a.items() if k != "agent_id"})
            if fresh:
                sups = (await s.execute(select(AgentMapping.id).where(
                    AgentMapping.role.in_(("supervisor", "admin")), AgentMapping.active.is_(True)))).scalars().all()
            await s.commit()
        if len(self.sent) > 5000:
            self.sent = {k: v for k, v in self.sent.items() if now - v < timedelta(hours=24)}
        for a in fresh:
            text = alert_text(a)
            self.sv.broker.publish_supervisors("alert", {"text": text, "kind": "team", "team": a["kind"], "ts": now})
            for sid in sups:
                self.sv.push.notify_later(sid, {"type": "alert", "title": tr("team.push_title"), "body": text[:180], "url": "/#sup"})
        return fresh
