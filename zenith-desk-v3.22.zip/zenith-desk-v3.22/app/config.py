"""Service configuration. All values come from environment variables (or .env).

Secrets (tokens, passwords) are never stored in business tables — only here.
"""
from functools import lru_cache
from typing import Literal
from urllib.parse import unquote, urlsplit

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# SEC-02: values that are published (this repository, its documentation, the demo and the tests) can never protect a
# production server: anybody could sign sessions with them and decrypt the saved secrets.
PUBLIC_SECRETS = {
    "change-me-please-use-32+-random-chars",
    "demo-secret-demo-secret-demo-secret",
    "test-secret-0123456789-abcdefghijklmnop",
    "server-A-secret-0123456789abcdefghijklmnop", "server-B-secret-zyxwvutsrqponmlkjihgfedcba",
    "server-C-secret-0000000000000000000000000",
    "routing-test-secret-0123456789abcdef", "callrouting-test-secret-0123456789abcd",
}
PLACEHOLDER_WORDS = ("change-me", "changeme", "change_me", "example", "your-secret", "your_secret", "secret-here", "<", "xxxxxxxx")
WEAK_DB_PASSWORDS = {"change-me", "changeme", "password", "postgres", "123456", "secret", "aws", "zenith", "admin"}


def secret_problem(value: str) -> str:
    """Why a JWT_SECRET is not good enough for production ("" = fine). The value itself is never logged."""
    v = value or ""
    low = v.lower()
    if not v.strip():
        return "JWT_SECRET is empty"
    if v in PUBLIC_SECRETS:
        return "JWT_SECRET is a published default / demo / test value"
    if any(w in low for w in PLACEHOLDER_WORDS):
        return "JWT_SECRET looks like a placeholder"
    if len(v) < 32:
        return "JWT_SECRET is shorter than 32 characters"
    if len(set(v)) < 8:
        return "JWT_SECRET has too few different characters"
    return ""


def db_password_problem(url: str) -> str:
    try:
        parts = urlsplit(url.replace("+asyncpg", ""))
        pw, user = unquote(parts.password or ""), unquote(parts.username or "")
    except ValueError:
        return ""
    weak = pw.lower() in WEAK_DB_PASSWORDS or (pw and pw == user)  # incl. the built-in default aws:aws
    return "the database password is a placeholder (POSTGRES_PASSWORD)" if weak else ""


def _csv(value: str) -> list[str]:
    return [v.strip() for v in value.split(",") if v.strip()]


class Settings(BaseSettings):
    # SEC-02: hide_input_in_errors — a refused start must never print the secrets it was given into the log
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore", hide_input_in_errors=True)

    # --- Core -------------------------------------------------------------
    database_url: str = "postgresql+asyncpg://aws:aws@localhost:5432/aws"
    jwt_secret: str = Field(default="change-me-please-use-32+-random-chars", min_length=32)
    # SEC-02: «production» (the default) refuses to start with an insecure secret; «development» (the demo, the tests,
    # a developer's laptop) only warns. Set ZD_ENV=development explicitly — never on a server people use.
    zd_env: Literal["production", "development"] = "production"
    jwt_ttl_hours: int = 12
    previous_session_keys: str = ""  # v3.18 (internal, encrypted): keys of the server a backup came from, until its sign-ins expire
    display_timezone: str = "Europe/Moscow"
    ui_language: str = "en"  # en | ru — language of the interface and server messages
    log_level: str = "INFO"
    initial_admin_username: str = "admin"
    initial_admin_password: str = ""  # empty = random password printed to the log on first start

    # --- Zammad -----------------------------------------------------------
    zammad_url: str = "http://zammad.local"
    zammad_token: str = ""  # service token (admin + ticket.agent permissions)
    zammad_verify_tls: bool = True
    zammad_webhook_secret: str = ""  # HMAC-SHA1 token configured on the Zammad webhook
    zammad_timeout_sec: float = 10.0
    # Ticket state names (as configured in your Zammad instance)
    zammad_state_in_progress: str = "open"  # set on "Start"; empty = do not change
    zammad_complete_states: str = "closed"  # allowed targets for "Complete", first = default
    zammad_final_states: str = "closed,merged,removed"  # ticket is finished
    zammad_pending_states: str = "pending reminder,pending close"  # waiting for customer / 3rd party
    # What to do with an active session when the ticket goes to a pending state in Zammad:
    # background | complete | none
    pending_state_action: str = "background"
    zammad_default_group: str = "Users"
    zammad_ticket_type_attribute: str = "type"  # ticket attribute holding the ticket type
    zammad_require_ticket_type: bool = False  # refuse "Start" when the ticket has no type
    zammad_unassigned_owner_id: int = 1  # Zammad "-" system user
    zammad_reconcile_interval_sec: int = 300
    # v3.3 ticketing inside Zenith Desk: how often changes made directly in Zammad are picked up
    zammad_poll_sec: int = 10  # tickets (0 = only webhook)
    directory_sync_sec: int = 60  # customers and staff (0 = off)
    attachment_max_mb: int = 10

    # --- Asterisk / FreePBX (AMI) ------------------------------------------
    ami_host: str = "127.0.0.1"
    ami_port: int = 5038
    ami_user: str = "agent-state"
    ami_secret: str = ""
    ami_action_timeout_sec: float = 5.0
    ami_tls: bool = False  # v3.17: AMI over TLS (Asterisk tlsenable=yes, port 5039)
    ami_tls_verify: bool = True
    ami_tls_fingerprint: str = ""  # SHA-256 of a self-signed Asterisk certificate (pinning)
    managed_queues: str = ""  # comma separated queue numbers, e.g. "400,401"
    pause_reason: str = "agent-state-service"
    respect_external_pause: bool = True  # do not unpause members paused by somebody else
    reconcile_interval_sec: int = 60
    retry_base_sec: int = 5
    retry_max_sec: int = 300
    wrap_up_seconds: int = 0  # 0 = WRAP_UP disabled
    call_auto_ticket: str = "off"  # v3.9 (ТЗ 15): off = ticket by the operator's button | answered = for every answered incoming call
    # v3.11 call routing by level: Asterisk rings the lowest penalty first, higher ones only when all lower are busy
    level_routing: bool = False
    penalty_level1: int = 0
    penalty_level2: int = 1
    penalty_level3: int = 2
    penalty_manager: int = 3  # managers / administrators who are queue members
    # --- v3.18 call routing for managers ------------------------------------------------------------
    routing_strategy_via_ami: bool = False  # Zenith Desk may set the ring strategy of a queue (AMI write = config)
    routing_queues_file: str = "queues_additional.conf"  # the file with the queues (FreePBX); plain Asterisk: queues.conf
    routing_dial_context: str = "from-internal"  # VIP: ring an employee's extension directly in this context
    routing_queue_context: str = "from-internal"  # VIP: put a customer back into a queue (extension = queue number)
    # manager overview (v2.5): service level = share of calls answered within N seconds
    sla_answer_seconds: int = 20
    # v2.8: pause a person who has not used Zenith Desk for N minutes (0 = off)
    idle_timeout_min: int = 60
    # v3.1: redirect plain HTTP to HTTPS (behind a TLS proxy that sets X-Forwarded-Proto)
    force_https: bool = False
    # --- v3.17 encryption in transit ------------------------------------------------------------
    allow_unencrypted: bool = False  # refuse http://, ws://, plain AMI / mail to other computers
    api_docs: bool = False  # /docs, /redoc, /openapi.json — off unless switched on (API_DOCS=true; the demo has them)
    max_request_mb: int = 64  # larger request bodies are refused (backup upload streams separately)
    sse_max_per_user: int = 12  # SEC-05: live-update connections one user may hold open (tabs, phone); more → 429
    sse_max_total: int = 2000  # SEC-05: all live-update connections of the server together; more → 503
    sla_target_percent: int = 80
    short_abandon_seconds: int = 5
    recording_url_template: str = ""
    # --- v3.15 manager tools ---------------------------------------------------------------------
    supervise_enabled: bool = True  # listen / whisper / barge (needs AMI write = originate,call)
    supervise_dial: str = "PJSIP/{ext}"  # how Asterisk rings the manager's own phone
    supervise_spy: str = "PJSIP/{ext}"  # the operator's phone channel ChanSpy listens to
    shift_grace_min: int = 5  # late / early leave only above N minutes
    shift_absent_min: int = 30  # nobody came in N minutes after the start = absent
    shift_alerts: bool = True  # tell the managers about late arrival, absence and early leave
    log_capture_level: str = "WARNING"  # system problems written into the log (WARNING | ERROR | off)
    # --- v3.18 team alerts for managers (0 / false = off) -----------------------------------------
    alert_long_call_min: int = 15  # a conversation runs longer than N minutes
    alert_long_break_min: int = 20  # a break lasts longer than N minutes
    alert_rona: bool = True  # an operator's phone rang and he did not answer (nobody else did either)
    alert_queue_waiting: int = 3  # N or more customers wait in one queue
    alert_missed_calls: bool = True  # a customer's call was not answered (abandoned / nobody picked up)
    # --- v3.5 Zenith Phone: softphone in the browser (WebRTC to FreePBX / Asterisk) -------------
    phone_enabled: bool = False
    phone_mode: str = "webrtc"  # webrtc | demo (demo = simulated calls, used by scripts/demo.py)
    phone_wss_url: str = ""  # e.g. wss://pbx.company.com:8089/ws
    phone_sip_domain: str = ""  # e.g. pbx.company.com (empty = host of the WSS URL)
    phone_ice_servers: str = "stun:stun.l.google.com:19302"  # comma separated stun:/turn: URLs
    phone_turn_username: str = ""
    phone_turn_password: str = ""
    phone_voicemail_number: str = "*97"  # FreePBX: *97 = my voicemail  # e.g. https://pbx/recordings/{date}/{file}

    # --- v3.9 background synchronisation of every integration ---------------------------------
    public_url: str = ""  # how the internet reaches Zenith Desk (webhooks of Telegram / WhatsApp), e.g. https://desk.company.com
    sync_fallback_min: int = 5  # fallback check of every integration (recovers missed webhooks / events)

    # --- v3.9 messengers: one company number / bot for the whole team ----------------------------
    telegram_enabled: bool = False
    telegram_bot_token: str = ""
    telegram_mode: str = "polling"  # polling (no public address needed) | webhook (needs public_url)
    telegram_webhook_secret: str = ""  # generated automatically
    telegram_api_base: str = "https://api.telegram.org"
    whatsapp_enabled: bool = False
    whatsapp_phone_number_id: str = ""
    whatsapp_business_account_id: str = ""
    whatsapp_access_token: str = ""
    whatsapp_app_secret: str = ""  # checks X-Hub-Signature-256 of the webhooks
    whatsapp_verify_token: str = ""  # generated automatically, entered in Meta → Webhooks
    whatsapp_api_version: str = "v21.0"
    whatsapp_api_base: str = "https://graph.facebook.com"
    whatsapp_templates: str = ""  # approved templates for writing after 24 h: "name:language, …"
    messenger_zammad_mirror: bool = True  # every chat is also a Zammad ticket (history, reports)
    messenger_zammad_group: str = ""  # group for chat tickets (empty = default group)
    messenger_quick_replies: str = ""  # one per line: "Title | text"
    messenger_media_max_mb: int = 16
    messenger_auto_close_days: int = 0  # close chats without messages for N days (0 = never)

    # --- v3.9 e-mail: the administrator sets the server, every user only signs in -----------------
    mail_enabled: bool = False
    mail_protocol: str = "imap"  # imap | pop3
    mail_in_host: str = ""
    mail_in_port: int = 993
    mail_in_security: str = "ssl"  # ssl | starttls | none
    mail_smtp_host: str = ""
    mail_smtp_port: int = 465
    mail_smtp_security: str = "ssl"  # ssl | starttls | none
    mail_smtp_auth: bool = True
    mail_login_format: str = "email"  # email (user@company.com) | local (user)
    mail_domain: str = ""  # optional: users may type only the name, @domain is added
    mail_verify_tls: bool = True
    mail_save_sent: bool = True  # put a copy of sent mail into "Sent" (off for servers that do it themselves)
    mail_idle: bool = True  # IMAP IDLE: new mail arrives instantly
    mail_max_attach_mb: int = 20

    # --- v3.9 data protection ----------------------------------------------------------------------
    retention_audit_days: int = 0  # delete audit log older than N days (0 = keep)
    retention_calls_days: int = 0  # delete call records older than N days
    retention_messages_days: int = 0  # delete chat / messenger messages older than N days
    recording_dir: str = ""  # FreePBX recordings mounted here (e.g. /var/spool/asterisk/monitor) → protected playback

    # --- v3.10 backup: the whole system in one encrypted file -------------------------------------
    backup_dir: str = "backups"  # folder for backup files (Docker: /srv/backups, a named volume)
    backup_enabled: bool = False  # automatic backups by the schedule below
    backup_frequency: str = "daily"  # daily | weekly
    backup_time: str = "03:00"  # HH:MM in display_timezone
    backup_weekday: str = "sun"  # for weekly backups: mon … sun
    backup_keep: int = 14  # how many automatic backups to keep (older are deleted)
    backup_upload_max_mb: int = 4096  # SEC-01: the largest backup file that may be uploaded (refused with 413 above it)
    backup_min_free_mb: int = 512     # SEC-01: an upload stops before the disk of the backup folder has less than this free
    backup_password: str = ""  # encrypts the backup files; needed to restore them

    # --- Behaviour ----------------------------------------------------------
    auto_assign_on_start: bool = True  # unassigned ticket gets assigned on "Start"
    login_sets_ready: bool = False  # after login: READY (true) or BREAK (false)
    presence_offline_sec: int = 0  # 0 = disabled; >0: no UI connection for N sec -> OFFLINE
    phone_country_code: str = "7"
    phone_national_prefix: str = "8"
    admin_alert_webhook_url: str = ""  # optional: POST JSON alerts here (e.g. to a chat bot)

    # --- helpers --------------------------------------------------------------
    @property
    def queues(self) -> list[str]:
        return _csv(self.managed_queues)

    @property
    def complete_states(self) -> list[str]:
        return _csv(self.zammad_complete_states)

    @property
    def final_states(self) -> list[str]:
        return [s.lower() for s in _csv(self.zammad_final_states)]

    @property
    def pending_states(self) -> list[str]:
        return [s.lower() for s in _csv(self.zammad_pending_states)]

    @model_validator(mode="after")
    def _fail_closed(self):
        """SEC-02: a production server does not start with a secret that is missing, published, a placeholder or weak,
        nor with a placeholder database password — whatever way the value was given (.env, environment, arguments)."""
        if self.zd_env == "production":
            problems = [p for p in (secret_problem(self.jwt_secret), db_password_problem(self.database_url)) if p]
            if problems:
                raise ValueError("refusing to start in production: " + "; ".join(problems) +
                                 ". Generate a secret with: openssl rand -hex 32 (keep it — never change it later), "
                                 "or set ZD_ENV=development on a test machine.")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
