"""v3.15 the system log: server warnings and errors are kept in the database next to the staff actions.

A logging handler collects WARNING / ERROR records (setting `log_capture_level`) and writes them every few seconds as
`system_log` rows of the audit log. The same problem repeated within 10 minutes becomes one row with a counter, so a
flapping connection never floods the log.
"""
from __future__ import annotations

import asyncio
import logging
import traceback
from datetime import timedelta

from .db import utcnow
from .models import AuditLog

SKIP = ("sqlalchemy", "aiosqlite", "asyncpg", "uvicorn.access", "syslog", "alembic", "multipart", "watchfiles")
SAME = timedelta(minutes=10)
LEVELS = {"WARNING": logging.WARNING, "ERROR": logging.ERROR}
log = logging.getLogger("syslog")


class DbLogHandler(logging.Handler):
    def __init__(self, services):
        super().__init__(level=logging.WARNING)
        self.sv = services
        self.pending: list[dict] = []
        self.recent: dict[tuple, tuple[int, object]] = {}  # fingerprint -> (row id, last time)
        self._task: asyncio.Task | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._wake: asyncio.Event | None = None

    # ------------------------------------------------------------ logging side (any thread)
    def emit(self, record: logging.LogRecord) -> None:
        try:
            threshold = LEVELS.get((self.sv.settings.log_capture_level or "").upper())
            if threshold is None or record.levelno < threshold or record.name.startswith(SKIP) or getattr(record, "no_db", False):
                return
            msg = record.getMessage()
            item = {"level": "error" if record.levelno >= logging.ERROR else "warning", "logger": record.name,
                    "message": msg[:2000], "template": str(record.msg)[:300], "ts": utcnow()}
            if record.exc_info and record.exc_info[1] is not None:
                exc = record.exc_info[1]
                item["error"] = f"{type(exc).__name__}: {exc}"[:500]
                item["trace"] = "".join(traceback.format_exception(*record.exc_info))[-4000:]
            loop = self._loop
            if loop is None or loop.is_closed():
                return
            loop.call_soon_threadsafe(self._add, item)
        except Exception:  # noqa: BLE001 — logging must never break the caller
            pass

    def _add(self, item: dict) -> None:
        if len(self.pending) < 500:
            self.pending.append(item)
        if self._wake:
            self._wake.set()

    # ------------------------------------------------------------ writer
    def start(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._wake = asyncio.Event()
        logging.getLogger().addHandler(self)
        self._task = asyncio.create_task(self._run(), name="system-log")

    async def stop(self) -> None:
        logging.getLogger().removeHandler(self)
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None
        try:
            await self.flush_now()
        except Exception:  # noqa: BLE001
            pass
        self._loop = None

    async def _run(self) -> None:
        while True:
            await self._wake.wait()
            await asyncio.sleep(2)  # collect a burst into one write
            self._wake.clear()
            try:
                await self.flush_now()
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                log.debug("system log write failed: %s", e)

    async def flush_now(self) -> int:
        items, self.pending = self.pending, []
        if not items:
            return 0
        now = utcnow()
        async with self.sv.db.sessionmaker() as s:
            fresh: dict[tuple, AuditLog] = {}
            for it in items:
                fp = (it["logger"], it["level"], it["template"])
                known = self.recent.get(fp)
                row = fresh.get(fp)
                if row is None and known and now - known[1] < SAME:
                    row = await s.get(AuditLog, known[0])
                if row is not None:
                    d = dict(row.details or {})
                    d["count"] = int(d.get("count", 1)) + 1
                    d["last_at"] = it["ts"].isoformat()
                    d["message"] = it["message"]
                    if it.get("error"):
                        d["error"] = it["error"]
                    row.details = d
                    fresh[fp] = row
                    continue
                row = AuditLog(action="system_log", level=it["level"], actor_type="system", ts=it["ts"],
                               details={k: v for k, v in {"logger": it["logger"], "message": it["message"], "count": 1,
                                                          "error": it.get("error"), "trace": it.get("trace")}.items() if v})
                s.add(row)
                fresh[fp] = row
            await s.commit()
            for fp, row in fresh.items():
                self.recent[fp] = (row.id, now)
        if len(self.recent) > 2000:
            self.recent = {k: v for k, v in self.recent.items() if now - v[1] < SAME}
        return len(items)
