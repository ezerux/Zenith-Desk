/* Zenith Desk v3.15 — manager tools: shift schedule, recordings archive, the log. */
window.ZenithManage = (() => {
  const { reactive, computed, watch, onMounted, onBeforeUnmount } = Vue;

  const i18n = {
    en: {
      "nav.shifts": "Shifts", "nav.recordings": "Recordings", "nav.log": "Log", "nav.mtools": "Shifts, recordings, log, routing", "nav.mtools_short": "Manager tools",
      // ---- call supervision (team page)
      "spy.listen": "Listen", "spy.whisper": "Whisper", "spy.barge": "Join", "spy.stop": "Stop",
      "spy.listen_t": "Listen to the call — nobody hears you", "spy.whisper_t": "Whisper — only the operator hears you, the customer does not",
      "spy.barge_t": "Join the call — the operator and the customer hear you",
      "spy.on_call": "on a call", "spy.ringing": "Your phone rings — answer it to hear {name}'s call",
      "spy.active": "{mode}: {name}", "spy.mode.listen": "Listening", "spy.mode.whisper": "Whispering", "spy.mode.barge": "In the call",
      "spy.keys": "Keys on the phone: 4 listen · 5 whisper · 6 join", "spy.no_ext": "Set your own extension (Users) to listen to calls",
      "spy.col": "Call", "spy.ended": "Listening ended",
      // ---- shifts
      "sh.title": "Shift schedule", "sh.this_week": "This week", "sh.prev": "Previous week", "sh.next": "Next week",
      "sh.copy_prev": "Copy previous week here", "sh.copied": "Copied: {n} shifts (skipped {s})", "sh.copy_confirm": "Copy the shifts of {from} to this week?",
      "sh.plan": "Plan shifts", "sh.people": "Who", "sh.days": "Days", "sh.time": "Time", "sh.note": "Note (optional)",
      "sh.all": "All", "sh.none": "None", "sh.weekdays": "Mon–Fri", "sh.replace": "Replace their shifts on these days",
      "sh.add": "Add shifts", "sh.added": "Added: {n} (skipped {s} — already a shift at that time)",
      "sh.templates": "Templates", "sh.save_tpl": "Save as template", "sh.tpl_name": "Template name (e.g. Morning)",
      "sh.person": "Employee", "sh.empty": "No shifts this week — plan them above.", "sh.click_add": "Add a shift",
      "sh.edit": "Shift", "sh.date": "Day", "sh.start": "Start", "sh.end": "End", "sh.save": "Save", "sh.delete": "Remove",
      "sh.cancel": "Cancel", "sh.saved": "Shift saved", "sh.deleted": "Shift removed", "sh.delete_confirm": "Remove this shift?",
      "sh.today": "Today", "sh.came": "Came in", "sh.left": "Left", "sh.worked": "Worked", "sh.status": "Status",
      "sh.st.upcoming": "planned", "sh.st.waiting": "not in yet", "sh.st.working": "working", "sh.st.away": "away now",
      "sh.st.done": "done", "sh.st.absent": "absent", "sh.late": "late {m} min", "sh.early": "left {m} min early",
      "sh.k.late": "Late", "sh.k.absent": "Absent", "sh.k.early": "Left early", "sh.still": "still here",
      "sh.rules": "Late / early leave above {g} min · absent: not in {a} min after the start. Present = signed in and not Offline.",
      "sh.overnight": "ends the next day",
      // ---- recordings
      "rec.title": "Call recordings", "rec.from": "From", "rec.to": "To", "rec.hours": "Hours", "rec.operator": "Operator",
      "rec.anyone": "Everybody", "rec.number": "Number or name", "rec.direction": "Direction", "rec.any": "Any",
      "rec.in": "Incoming", "rec.out": "Outgoing", "rec.queue": "Queue", "rec.min": "At least, sec", "rec.ticket": "Ticket",
      "rec.with": "with a ticket", "rec.without": "without", "rec.today": "Today", "rec.yesterday": "Yesterday", "rec.week": "7 days",
      "rec.month": "30 days", "rec.reset": "Reset", "rec.found": "Recordings: {n}", "rec.none": "No recordings match the filter.",
      "rec.when": "When", "rec.who": "Customer", "rec.talk": "Talk", "rec.play": "Listen", "rec.download": "Download",
      "rec.more": "Show more", "rec.mine": "Only your own conversations are shown.", "rec.external": "opens on the PBX",
      // ---- log
      "lg.title": "Log", "lg.from": "From", "lg.to": "To", "lg.who": "Who did it", "lg.about": "About whom", "lg.everyone": "Everybody",
      "lg.action": "Action", "lg.any": "Any", "lg.search": "Search in the details…", "lg.ticket": "Ticket #", "lg.export": "Export (CSV)",
      "lg.refresh": "Refresh", "lg.found": "Entries: {n}", "lg.none": "Nothing matches the filter.", "lg.more": "Show more",
      "lg.time": "Time", "lg.what": "What", "lg.details": "Details", "lg.auto": "Live", "lg.reset": "Reset", "lg.system": "system",
      "lg.c.system": "System problems", "lg.c.auth": "Sign-in", "lg.c.state": "Status", "lg.c.shifts": "Shifts", "lg.c.calls": "Calls",
      "lg.c.tickets": "Tickets", "lg.c.messages": "Messages", "lg.c.admin": "Administration", "lg.c.other": "Other",
      "lg.l.info": "Info", "lg.l.warning": "Warning", "lg.l.error": "Error",
      "lg.a.system_log": "Server problem", "lg.a.login": "Signed in", "lg.a.logout": "Signed out", "lg.a.login_failed": "Wrong password", "lg.a.login_locked": "Locked out (wrong passwords)", "lg.a.login_unlocked": "Unlocked by the administrator", "lg.a.sessions_revoked": "Signed out everywhere",
      "lg.a.manual_state": "Changed own status", "lg.a.availability_changed": "Availability changed", "lg.a.presence_lost": "Workplace closed",
      "lg.a.idle_offline": "Inactive → offline", "lg.a.idle_returned": "Back after inactivity", "lg.a.dnd": "Do not disturb",
      "lg.a.supervisor_override": "Status set by a manager", "lg.a.queue_pause": "Queue pause", "lg.a.queue_penalty": "Queue penalty",
      "lg.a.work_started": "Started a ticket", "lg.a.work_completed": "Finished a ticket", "lg.a.work_cancelled": "Ticket work cancelled",
      "lg.a.ticket_created": "Created a ticket", "lg.a.ticket_updated": "Changed a ticket", "lg.a.ticket_replied": "Replied in a ticket",
      "lg.a.ticket_reassigned": "Ticket reassigned", "lg.a.recording_played": "Listened to a recording", "lg.a.recording_downloaded": "Downloaded a recording",
      "lg.a.recording_denied": "Recording refused", "lg.a.spy_started": "Started listening to a call", "lg.a.spy_mode": "Listening mode changed",
      "lg.a.spy_stopped": "Stopped listening", "lg.a.spy_failed": "Listening failed", "lg.a.shift_late": "Late for the shift",
      "lg.a.shift_absent": "Absent from the shift", "lg.a.shift_early_leave": "Left the shift early", "lg.a.shift_planned": "Planned shifts",
      "lg.a.shift_changed": "Changed a shift", "lg.a.shift_removed": "Removed a shift", "lg.a.shift_copied": "Copied shifts",
      "lg.a.sync_error": "Telephony sync error", "lg.a.sync_restored": "Telephony sync restored", "lg.a.user_created": "User created",
      "lg.a.user_updated": "User changed", "lg.a.settings_changed": "Settings changed", "lg.a.password_changed": "Password changed",
      "lg.a.password_reset": "Password reset", "lg.a.backup_created": "Backup created", "lg.a.backup_failed": "Backup failed",
      "lg.a.mail_sent": "Sent an e-mail", "lg.a.msg_taken": "Took a chat", "lg.a.log_exported": "Exported the log",
    },
    ru: {
      "nav.shifts": "Смены", "nav.recordings": "Записи", "nav.log": "Журнал", "nav.mtools": "Смены, записи, журнал, маршрутизация", "nav.mtools_short": "Инструменты",
      "spy.listen": "Слушать", "spy.whisper": "Подсказать", "spy.barge": "Подключиться", "spy.stop": "Стоп",
      "spy.listen_t": "Слушать звонок — вас никто не слышит", "spy.whisper_t": "Подсказка — слышит только оператор, клиент не слышит",
      "spy.barge_t": "Подключиться к разговору — вас слышат оператор и клиент",
      "spy.on_call": "разговаривает", "spy.ringing": "Звонит ваш телефон — ответьте, чтобы слышать звонок {name}",
      "spy.active": "{mode}: {name}", "spy.mode.listen": "Прослушивание", "spy.mode.whisper": "Подсказка", "spy.mode.barge": "В разговоре",
      "spy.keys": "Клавиши телефона: 4 слушать · 5 подсказать · 6 подключиться", "spy.no_ext": "Укажите свой внутренний номер (Пользователи), чтобы слушать звонки",
      "spy.col": "Звонок", "spy.ended": "Прослушивание завершено",
      "sh.title": "График смен", "sh.this_week": "Эта неделя", "sh.prev": "Прошлая неделя", "sh.next": "Следующая неделя",
      "sh.copy_prev": "Скопировать прошлую неделю", "sh.copied": "Скопировано смен: {n} (пропущено {s})", "sh.copy_confirm": "Скопировать смены недели {from} на эту неделю?",
      "sh.plan": "Запланировать смены", "sh.people": "Кто", "sh.days": "Дни", "sh.time": "Время", "sh.note": "Заметка (необязательно)",
      "sh.all": "Все", "sh.none": "Никто", "sh.weekdays": "Пн–Пт", "sh.replace": "Заменить их смены в эти дни",
      "sh.add": "Добавить смены", "sh.added": "Добавлено: {n} (пропущено {s} — уже есть смена в это время)",
      "sh.templates": "Шаблоны", "sh.save_tpl": "Сохранить как шаблон", "sh.tpl_name": "Название шаблона (например Утро)",
      "sh.person": "Сотрудник", "sh.empty": "На этой неделе смен нет — запланируйте их выше.", "sh.click_add": "Добавить смену",
      "sh.edit": "Смена", "sh.date": "День", "sh.start": "Начало", "sh.end": "Конец", "sh.save": "Сохранить", "sh.delete": "Удалить",
      "sh.cancel": "Отмена", "sh.saved": "Смена сохранена", "sh.deleted": "Смена удалена", "sh.delete_confirm": "Удалить эту смену?",
      "sh.today": "Сегодня", "sh.came": "Пришёл", "sh.left": "Ушёл", "sh.worked": "Отработал", "sh.status": "Статус",
      "sh.st.upcoming": "запланирована", "sh.st.waiting": "ещё не вошёл", "sh.st.working": "работает", "sh.st.away": "сейчас нет",
      "sh.st.done": "завершена", "sh.st.absent": "отсутствовал", "sh.late": "опоздал на {m} мин", "sh.early": "ушёл на {m} мин раньше",
      "sh.k.late": "Опоздания", "sh.k.absent": "Отсутствия", "sh.k.early": "Ранний уход", "sh.still": "ещё здесь",
      "sh.rules": "Опоздание / ранний уход — больше {g} мин · отсутствие: не вошёл через {a} мин после начала. На месте = вошёл и не «Не в сети».",
      "sh.overnight": "заканчивается на следующий день",
      "rec.title": "Записи разговоров", "rec.from": "С", "rec.to": "По", "rec.hours": "Часы", "rec.operator": "Оператор",
      "rec.anyone": "Все", "rec.number": "Номер или имя", "rec.direction": "Направление", "rec.any": "Любое",
      "rec.in": "Входящие", "rec.out": "Исходящие", "rec.queue": "Очередь", "rec.min": "Не короче, сек", "rec.ticket": "Тикет",
      "rec.with": "с тикетом", "rec.without": "без", "rec.today": "Сегодня", "rec.yesterday": "Вчера", "rec.week": "7 дней",
      "rec.month": "30 дней", "rec.reset": "Сбросить", "rec.found": "Записей: {n}", "rec.none": "Нет записей по этому фильтру.",
      "rec.when": "Когда", "rec.who": "Клиент", "rec.talk": "Разговор", "rec.play": "Слушать", "rec.download": "Скачать",
      "rec.more": "Показать ещё", "rec.mine": "Показаны только ваши разговоры.", "rec.external": "открывается на АТС",
      "lg.title": "Журнал", "lg.from": "С", "lg.to": "По", "lg.who": "Кто сделал", "lg.about": "О ком", "lg.everyone": "Все",
      "lg.action": "Действие", "lg.any": "Любое", "lg.search": "Поиск в подробностях…", "lg.ticket": "Тикет №", "lg.export": "Экспорт (CSV)",
      "lg.refresh": "Обновить", "lg.found": "Записей: {n}", "lg.none": "Ничего не найдено.", "lg.more": "Показать ещё",
      "lg.time": "Время", "lg.what": "Что", "lg.details": "Подробности", "lg.auto": "Онлайн", "lg.reset": "Сбросить", "lg.system": "система",
      "lg.c.system": "Проблемы системы", "lg.c.auth": "Вход", "lg.c.state": "Статус", "lg.c.shifts": "Смены", "lg.c.calls": "Звонки",
      "lg.c.tickets": "Тикеты", "lg.c.messages": "Сообщения", "lg.c.admin": "Администрирование", "lg.c.other": "Другое",
      "lg.l.info": "Инфо", "lg.l.warning": "Предупреждение", "lg.l.error": "Ошибка",
      "lg.a.system_log": "Проблема сервера", "lg.a.login": "Вошёл", "lg.a.logout": "Вышел", "lg.a.login_failed": "Неверный пароль", "lg.a.login_locked": "Заблокирован (неверные пароли)", "lg.a.login_unlocked": "Разблокирован администратором", "lg.a.sessions_revoked": "Выход на всех устройствах",
      "lg.a.manual_state": "Сменил свой статус", "lg.a.availability_changed": "Доступность изменилась", "lg.a.presence_lost": "Закрыл рабочее место",
      "lg.a.idle_offline": "Бездействие → не в сети", "lg.a.idle_returned": "Вернулся после бездействия", "lg.a.dnd": "Не беспокоить",
      "lg.a.supervisor_override": "Статус задан руководителем", "lg.a.queue_pause": "Пауза в очереди", "lg.a.queue_penalty": "Penalty в очереди",
      "lg.a.work_started": "Начал тикет", "lg.a.work_completed": "Завершил тикет", "lg.a.work_cancelled": "Работа над тикетом отменена",
      "lg.a.ticket_created": "Создал тикет", "lg.a.ticket_updated": "Изменил тикет", "lg.a.ticket_replied": "Ответил в тикете",
      "lg.a.ticket_reassigned": "Тикет переназначен", "lg.a.recording_played": "Прослушал запись", "lg.a.recording_downloaded": "Скачал запись",
      "lg.a.recording_denied": "Отказ в доступе к записи", "lg.a.spy_started": "Начал слушать звонок", "lg.a.spy_mode": "Сменил режим прослушивания",
      "lg.a.spy_stopped": "Закончил слушать", "lg.a.spy_failed": "Прослушивание не началось", "lg.a.shift_late": "Опоздал на смену",
      "lg.a.shift_absent": "Отсутствовал на смене", "lg.a.shift_early_leave": "Ушёл со смены раньше", "lg.a.shift_planned": "Запланировал смены",
      "lg.a.shift_changed": "Изменил смену", "lg.a.shift_removed": "Удалил смену", "lg.a.shift_copied": "Скопировал смены",
      "lg.a.sync_error": "Ошибка синхронизации телефонии", "lg.a.sync_restored": "Синхронизация восстановлена", "lg.a.user_created": "Создан пользователь",
      "lg.a.user_updated": "Изменён пользователь", "lg.a.settings_changed": "Изменены настройки", "lg.a.password_changed": "Сменил пароль",
      "lg.a.password_reset": "Сброшен пароль", "lg.a.backup_created": "Создана резервная копия", "lg.a.backup_failed": "Ошибка резервного копирования",
      "lg.a.mail_sent": "Отправил письмо", "lg.a.msg_taken": "Взял чат", "lg.a.log_exported": "Выгрузил журнал",
    },
  };

  // ------------------------------------------------------------ dates in the company's time zone
  const pad = (n) => String(n).padStart(2, "0");
  /** "9" → 09:00, "930" → 09:30, "9:5" → 09:05, "" stays empty; anything else unchanged (the server says what is wrong). */
  function normHM(v) {
    const x = String(v || "").trim();
    if (!x) return "";
    let m = /^(\d{1,2})(?:[:.\s]?(\d{1,2}))?$/.exec(x);
    if (!m && /^\d{3,4}$/.test(x)) m = [x, x.slice(0, x.length - 2), x.slice(-2)];
    if (!m) return x;
    const h = +m[1], mi = m[2] === undefined ? 0 : +m[2];
    return h < 24 && mi < 60 ? `${pad(h)}:${pad(mi)}` : x;
  }
  function setHM(obj, key, ev) { const v = normHM(ev.target.value); obj[key] = v; ev.target.value = v; }
  const HM = { inputmode: "numeric", maxlength: 5, placeholder: "HH:MM", autocomplete: "off" };
  const dayIn = (d, tz) => { try { return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(d); } catch { return d.toISOString().slice(0, 10); } };
  const hmIn = (iso, tz) => { if (!iso) return ""; try { return new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(iso)); } catch { return ""; } };
  const addDays = (ymd, n) => { const d = new Date(ymd + "T12:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  const mondayOf = (ymd) => addDays(ymd, -((new Date(ymd + "T12:00:00Z").getUTCDay() + 6) % 7));
  const mins = (m) => (m >= 60 ? `${Math.floor(m / 60)}:${pad(m % 60)}` : `${m}′`);
  const secs = (x) => (x == null ? "" : `${Math.floor(x / 60)}:${pad(x % 60)}`);
  const fmtDay = (ymd, locale, opts) => { try { return new Intl.DateTimeFormat(locale, { timeZone: "UTC", ...opts }).format(new Date(ymd + "T12:00:00Z")); } catch { return ymd; } };
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* ignore */ } } };

  async function authFetch(url, token) {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error((d && d.detail && (d.detail.message || d.detail)) || `HTTP ${r.status}`); }
    return r;
  }
  function saveBlob(blob, name) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  }
  const fileName = (r, fallback) => { const m = /filename="([^"]+)"/.exec(r.headers.get("content-disposition") || ""); return m ? m[1] : fallback; };

  // ================================================================== shift schedule
  const ShiftsPage = {
    props: { api: Function, t: Function, toast: Function, tz: String, locale: String, live: Number },
    setup(props) {
      const t = props.t;
      const tz = () => props.tz || "UTC";
      const today = () => dayIn(new Date(), tz());
      const s = reactive({ start: mondayOf(today()), data: null, loading: false,
        plan: { people: [], days: [], start: "09:00", end: "18:00", note: "", replace: false, busy: false }, ed: null, tplName: "" });
      async function load() {
        s.loading = true;
        try {
          s.data = await props.api("GET", `/api/sup/shifts?start=${s.start}&days=7`);
          const ids = new Set(s.data.agents.map((a) => a.id));
          s.plan.people = s.plan.people.filter((x) => ids.has(x));
          s.plan.days = s.plan.days.filter((d) => s.data.days.includes(d));
        } catch (e) { props.toast(e.message, "error"); } finally { s.loading = false; }
      }
      function move(n) { s.start = addDays(s.start, n); s.plan.days = []; load(); }
      function goToday() { s.start = mondayOf(today()); s.plan.days = []; load(); }
      const days = computed(() => (s.data ? s.data.days : []));
      const people = computed(() => (s.data ? s.data.agents : []));
      const byCell = computed(() => {
        const m = {};
        for (const x of (s.data ? s.data.shifts : [])) { const k = x.agent_id + "|" + dayIn(new Date(x.starts_at), tz()); (m[k] = m[k] || []).push(x); }
        return m;
      });
      const cell = (pid, d) => byCell.value[pid + "|" + d] || [];
      const hm = (iso) => hmIn(iso, tz());
      const overnight = (x) => dayIn(new Date(x.ends_at), tz()) !== dayIn(new Date(x.starts_at), tz());
      const dayHead = (d) => fmtDay(d, props.locale, { weekday: "short", day: "2-digit", month: "2-digit" });
      const rangeLabel = computed(() => (days.value.length ? `${fmtDay(days.value[0], props.locale, { day: "numeric", month: "short" })} – ${fmtDay(days.value[6], props.locale, { day: "numeric", month: "short", year: "numeric" })}` : ""));
      function chip(x) {
        const a = x.attendance || {};
        if (a.absent) return "absent";
        if (a.late_min || a.early_min) return "late";
        return { upcoming: "plan", waiting: "wait", working: "work", away: "away", done: "ok" }[a.status] || "plan";
      }
      function problems(x) {
        const a = x.attendance || {}, out = [];
        if (a.absent) out.push(t("sh.st.absent"));
        if (a.late_min) out.push(t("sh.late", { m: a.late_min }));
        if (a.early_min) out.push(t("sh.early", { m: a.early_min }));
        return out.join(" · ");
      }
      const statusText = (x) => problems(x) || t("sh.st." + ((x.attendance && x.attendance.status) || "upcoming"));
      const todayRows = computed(() => (s.data ? s.data.shifts.filter((x) => dayIn(new Date(x.starts_at), tz()) === today()) : [])
        .map((x) => ({ ...x, person: people.value.find((p) => p.id === x.agent_id) || { name: "#" + x.agent_id } })));
      // -------- planning
      const togglePerson = (id) => { const i = s.plan.people.indexOf(id); i >= 0 ? s.plan.people.splice(i, 1) : s.plan.people.push(id); };
      const toggleDay = (d) => { const i = s.plan.days.indexOf(d); i >= 0 ? s.plan.days.splice(i, 1) : s.plan.days.push(d); };
      const allPeople = (on) => { s.plan.people = on ? people.value.map((p) => p.id) : []; };
      const weekdays = () => { s.plan.days = days.value.slice(0, 5); };
      const useTpl = (x) => { s.plan.start = x.start; s.plan.end = x.end; };
      const canPlan = computed(() => s.plan.people.length && s.plan.days.length && /^\d\d:\d\d$/.test(s.plan.start) && /^\d\d:\d\d$/.test(s.plan.end) && !s.plan.busy);
      async function addShifts() {
        if (!canPlan.value) return;
        s.plan.busy = true;
        try {
          const r = await props.api("POST", "/api/sup/shifts", { agent_ids: s.plan.people, dates: s.plan.days, start: s.plan.start, end: s.plan.end, note: s.plan.note, replace: s.plan.replace });
          props.toast(t("sh.added", { n: r.created, s: r.skipped }));
          await load();
        } catch (e) { props.toast(e.message, "error"); } finally { s.plan.busy = false; }
      }
      async function saveTpl() {
        const name = (s.tplName || "").trim();
        if (!name) return;
        try { await props.api("POST", "/api/sup/shift-templates", { name, start: s.plan.start, end: s.plan.end }); s.tplName = ""; await load(); }
        catch (e) { props.toast(e.message, "error"); }
      }
      async function dropTpl(x) { try { await props.api("DELETE", `/api/sup/shift-templates/${x.id}`); await load(); } catch (e) { props.toast(e.message, "error"); } }
      async function quickAdd(p, d) {
        try {
          const r = await props.api("POST", "/api/sup/shifts", { agent_ids: [p.id], dates: [d], start: s.plan.start, end: s.plan.end, note: s.plan.note });
          if (!r.created) props.toast(t("sh.added", { n: 0, s: r.skipped }), "error");
          await load();
        } catch (e) { props.toast(e.message, "error"); }
      }
      async function copyPrev() {
        const from = addDays(s.start, -7);
        if (!confirm(t("sh.copy_confirm", { from: fmtDay(from, props.locale, { day: "numeric", month: "short" }) }))) return;
        try { const r = await props.api("POST", "/api/sup/shifts/copy", { source: from, target: s.start, days: 7 }); props.toast(t("sh.copied", { n: r.created, s: r.skipped })); await load(); }
        catch (e) { props.toast(e.message, "error"); }
      }
      // -------- one shift
      function edit(x) { s.ed = { id: x.id, date: dayIn(new Date(x.starts_at), tz()), start: hm(x.starts_at), end: hm(x.ends_at), note: x.note || "",
        name: (people.value.find((p) => p.id === x.agent_id) || {}).name || "" }; }
      async function saveEdit() {
        try { await props.api("PUT", `/api/sup/shifts/${s.ed.id}`, { date: s.ed.date, start: s.ed.start, end: s.ed.end, note: s.ed.note }); s.ed = null; props.toast(t("sh.saved")); await load(); }
        catch (e) { props.toast(e.message, "error"); }
      }
      async function removeEdit() {
        if (!confirm(t("sh.delete_confirm"))) return;
        try { await props.api("DELETE", `/api/sup/shifts/${s.ed.id}`); s.ed = null; props.toast(t("sh.deleted")); await load(); }
        catch (e) { props.toast(e.message, "error"); }
      }
      let timer;
      onMounted(() => { load(); timer = setInterval(() => { if (!document.hidden) load(); }, 60000); });
      onBeforeUnmount(() => clearInterval(timer));
      watch(() => props.live, () => { if (s.data && !s.loading && !s.ed) load(); });
      return { HM, setHM, s, t, days, people, cell, hm, overnight, dayHead, rangeLabel, chip, problems, statusText, todayRows, move, goToday, today,
        togglePerson, toggleDay, allPeople, weekdays, useTpl, canPlan, addShifts, saveTpl, dropTpl, quickAdd, copyPrev, edit, saveEdit, removeEdit, mins };
    },
    template: `
<div class="mg" data-page="shifts">
  <div class="mg-bar">
    <div class="mg-nav">
      <button class="btn sm" data-sh="prev" @click="move(-7)" :title="t('sh.prev')" :aria-label="t('sh.prev')">‹</button>
      <button class="btn sm" data-sh="today" @click="goToday">{{ t('sh.this_week') }}</button>
      <button class="btn sm" data-sh="next" @click="move(7)" :title="t('sh.next')" :aria-label="t('sh.next')">›</button>
      <b class="mg-range">{{ rangeLabel }}</b>
    </div>
    <div class="mg-sum" v-if="s.data">
      <span class="sh-k k-late" :class="{zero: !s.data.summary.late}"><b>{{ s.data.summary.late }}</b> {{ t('sh.k.late') }}</span>
      <span class="sh-k k-absent" :class="{zero: !s.data.summary.absent}"><b>{{ s.data.summary.absent }}</b> {{ t('sh.k.absent') }}</span>
      <span class="sh-k k-early" :class="{zero: !s.data.summary.early_leave}"><b>{{ s.data.summary.early_leave }}</b> {{ t('sh.k.early') }}</span>
    </div>
    <span class="grow"></span>
    <button class="btn sm" data-sh="copy" @click="copyPrev"><ico name="copy"></ico> {{ t('sh.copy_prev') }}</button>
  </div>

  <section class="panel sh-plan" data-sh="plan">
    <h2>{{ t('sh.plan') }}</h2>
    <div class="body">
      <div class="sh-row"><span class="sh-lbl">{{ t('sh.time') }}</span>
        <div class="sh-tpls">
          <span v-for="x in (s.data ? s.data.templates : [])" :key="x.id" class="sh-tpl" :class="{on: s.plan.start===x.start && s.plan.end===x.end}">
            <button @click="useTpl(x)" :data-tpl="x.name">{{ x.name }} <small>{{ x.start }}–{{ x.end }}</small></button><i @click="dropTpl(x)" :aria-label="t('sh.delete')">×</i></span>
        </div>
        <input type="text" class="hm-in sh-time" v-bind="HM" v-model.lazy="s.plan.start" @change="setHM(s.plan, 'start', $event)" data-sh="start"> – <input type="text" class="hm-in sh-time" v-bind="HM" v-model.lazy="s.plan.end" @change="setHM(s.plan, 'end', $event)" data-sh="end">
        <span v-if="s.plan.end && s.plan.end <= s.plan.start" class="empty">{{ t('sh.overnight') }}</span>
        <span class="grow"></span>
        <input v-model="s.tplName" :placeholder="t('sh.tpl_name')" class="sh-tplname" @keydown.enter="saveTpl"><button class="btn sm" :disabled="!s.tplName.trim()" @click="saveTpl">{{ t('sh.save_tpl') }}</button>
      </div>
      <div class="sh-row"><span class="sh-lbl">{{ t('sh.days') }}</span>
        <button v-for="d in days" :key="d" class="sh-day" :class="{on: s.plan.days.includes(d), today: d===today()}" :data-day="d" @click="toggleDay(d)">{{ dayHead(d) }}</button>
        <button class="btn sm ghost" @click="weekdays">{{ t('sh.weekdays') }}</button>
      </div>
      <div class="sh-row"><span class="sh-lbl">{{ t('sh.people') }}</span>
        <button v-for="p in people" :key="p.id" class="sh-who" :class="{on: s.plan.people.includes(p.id)}" :data-person="p.id" @click="togglePerson(p.id)">
          <user-avatar :name="p.name" :url="p.avatar_url"></user-avatar>{{ p.name }}</button>
        <button class="btn sm ghost" @click="allPeople(true)">{{ t('sh.all') }}</button><button class="btn sm ghost" @click="allPeople(false)">{{ t('sh.none') }}</button>
      </div>
      <div class="sh-row"><input v-model="s.plan.note" :placeholder="t('sh.note')" maxlength="200" class="sh-note">
        <label class="check"><input type="checkbox" v-model="s.plan.replace"> {{ t('sh.replace') }}</label>
        <span class="grow"></span>
        <button class="btn primary" data-sh="add" :disabled="!canPlan" @click="addShifts">{{ t('sh.add') }}<span v-if="s.plan.people.length && s.plan.days.length"> · {{ s.plan.people.length * s.plan.days.length }}</span></button>
      </div>
      <div class="empty sh-rules" v-if="s.data">{{ t('sh.rules', {g: s.data.settings.grace_min, a: s.data.settings.absent_min}) }}</div>
    </div>
  </section>

  <section class="panel">
    <div class="table-wrap"><table class="sh-grid">
      <thead><tr><th>{{ t('sh.person') }}</th><th v-for="d in days" :key="d" :class="{today: d===today()}">{{ dayHead(d) }}</th></tr></thead>
      <tbody>
        <tr v-for="p in people" :key="p.id" :data-person="p.id">
          <td class="sh-name"><div class="u-cell"><user-avatar :name="p.name" :url="p.avatar_url"></user-avatar><div><b>{{ p.name }}</b><div class="empty">{{ p.position || p.extension }}</div></div></div></td>
          <td v-for="d in days" :key="d" class="sh-cell" :class="{today: d===today()}" :data-day="d">
            <button v-for="x in cell(p.id, d)" :key="x.id" class="sh-chip" :class="'a-' + chip(x)" :data-shift="x.id" :data-state="chip(x)" @click="edit(x)"
              :title="statusText(x) + (x.note ? ' · ' + x.note : '')">
              <span class="sh-t">{{ hm(x.starts_at) }}–{{ hm(x.ends_at) }}<sup v-if="overnight(x)">+1</sup></span>
              <small>{{ statusText(x) }}</small></button>
            <button class="sh-add" @click="quickAdd(p, d)" :title="t('sh.click_add') + ' ' + s.plan.start + '–' + s.plan.end" :aria-label="t('sh.click_add')">+</button>
          </td>
        </tr>
      </tbody>
    </table></div>
    <div v-if="s.data && !s.data.shifts.length" class="empty" style="padding:12px 16px">{{ t('sh.empty') }}</div>
  </section>

  <section class="panel" v-if="todayRows.length" data-sh="today">
    <h2>{{ t('sh.today') }}</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>{{ t('sh.person') }}</th><th>{{ t('sh.time') }}</th><th>{{ t('sh.came') }}</th><th>{{ t('sh.left') }}</th><th>{{ t('sh.worked') }}</th><th>{{ t('sh.status') }}</th></tr></thead>
      <tbody><tr v-for="x in todayRows" :key="x.id" :data-shift="x.id">
        <td><div class="u-cell"><user-avatar :name="x.person.name" :url="x.person.avatar_url"></user-avatar><b>{{ x.person.name }}</b></div></td>
        <td class="mono">{{ hm(x.starts_at) }}–{{ hm(x.ends_at) }}</td>
        <td class="mono">{{ hm(x.attendance.first_in) || '—' }}</td>
        <td class="mono">{{ x.attendance.first_in ? (x.attendance.last_out ? hm(x.attendance.last_out) : t('sh.still')) : '—' }}</td>
        <td class="mono">{{ mins(x.attendance.worked_min) }}</td>
        <td><span class="sh-st" :class="'a-' + chip(x)">{{ statusText(x) }}</span></td>
      </tr></tbody>
    </table></div>
  </section>

  <div v-if="s.ed" class="overlay" @click.self="s.ed = null">
    <div class="modal panel sh-edit" role="dialog" aria-modal="true">
      <h3>{{ t('sh.edit') }} · {{ s.ed.name }}</h3>
      <label>{{ t('sh.date') }}</label><input type="date" v-model="s.ed.date" data-ed="date">
      <div class="field-row" style="margin-top:10px"><div style="flex:1"><label>{{ t('sh.start') }}</label><input type="text" class="hm-in" v-bind="HM" v-model.lazy="s.ed.start" @change="setHM(s.ed, 'start', $event)" data-ed="start"></div>
        <div style="flex:1"><label>{{ t('sh.end') }}</label><input type="text" class="hm-in" v-bind="HM" v-model.lazy="s.ed.end" @change="setHM(s.ed, 'end', $event)" data-ed="end"></div></div>
      <label>{{ t('sh.note') }}</label><input v-model="s.ed.note" maxlength="200">
      <div class="footer"><button class="btn danger" data-ed="delete" @click="removeEdit">{{ t('sh.delete') }}</button><span class="grow"></span>
        <button class="btn" @click="s.ed = null">{{ t('sh.cancel') }}</button><button class="btn primary" data-ed="save" @click="saveEdit">{{ t('sh.save') }}</button></div>
    </div>
  </div>
</div>`,
  };

  // ================================================================== recordings archive
  const RecordingsPage = {
    props: { api: Function, t: Function, toast: Function, fmt: Function, tz: String, locale: String, token: String, sup: Boolean, live: Number },
    setup(props) {
      const t = props.t;
      const today = () => dayIn(new Date(), props.tz || "UTC");
      const blank = () => ({ date_from: addDays(today(), -6), date_to: today(), time_from: "", time_to: "", agent_id: "", number: "", direction: "", queue: "", min_sec: "", ticket: "" });
      const s = reactive({ f: { ...blank(), ...store.get("zenith_rec_f", {}) }, items: [], total: 0, agents: [], loading: false, playing: null, audio: {}, busy: 0 });
      let seq = 0;
      function query(offset) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(s.f)) if (v !== "" && v != null) q.set(k, v);
        q.set("limit", 50); q.set("offset", offset);
        return q.toString();
      }
      async function load(more) {
        const my = ++seq;
        s.loading = true;
        try {
          const r = await props.api("GET", "/api/recordings?" + query(more ? s.items.length : 0));
          if (my !== seq) return;
          s.items = more ? [...s.items, ...r.items] : r.items; s.total = r.total;
          if (r.agents) s.agents = r.agents;
        } catch (e) { if (my === seq) props.toast(e.message, "error"); } finally { if (my === seq) s.loading = false; }
      }
      let debounce;
      watch(() => ({ ...s.f }), (f) => { store.set("zenith_rec_f", { time_from: f.time_from, time_to: f.time_to, agent_id: f.agent_id, direction: f.direction, ticket: f.ticket });
        clearTimeout(debounce); debounce = setTimeout(() => load(false), 250); }, { deep: true });
      function quick(n) { s.f.date_to = n === 1 ? addDays(today(), -1) : today(); s.f.date_from = n === 1 ? s.f.date_to : addDays(today(), -(n - 1)); }
      function reset() { Object.assign(s.f, blank()); }
      async function play(c) {
        if (!c.protected) { window.open(c.url, "_blank", "noopener"); return; }
        if (s.audio[c.id]) { s.playing = c.id; return; }
        s.busy = c.id;
        try { const r = await authFetch(c.url, props.token); s.audio[c.id] = URL.createObjectURL(await r.blob()); s.playing = c.id; }
        catch (e) { props.toast(e.message, "error"); } finally { s.busy = 0; }
      }
      async function download(c) {
        if (!c.protected) { window.open(c.url, "_blank", "noopener"); return; }
        try { const r = await authFetch(c.url + "?download=1", props.token); saveBlob(await r.blob(), fileName(r, `call-${c.id}.wav`)); }
        catch (e) { props.toast(e.message, "error"); }
      }
      const when = (c) => props.fmt(c.started_at, true);
      onMounted(() => load(false));
      onBeforeUnmount(() => { for (const u of Object.values(s.audio)) URL.revokeObjectURL(u); });
      return { HM, setHM, s, t, load, quick, reset, play, download, when, secs };
    },
    template: `
<div class="mg" data-page="recordings">
  <section class="panel mg-filters" data-rec="filters">
    <div class="body">
      <div class="mg-frow">
        <div class="mg-f"><label>{{ t('rec.from') }}</label><input type="date" v-model="s.f.date_from" data-f="date_from"></div>
        <div class="mg-f"><label>{{ t('rec.to') }}</label><input type="date" v-model="s.f.date_to" data-f="date_to"></div>
        <div class="mg-f"><label>{{ t('rec.hours') }}</label><div class="mg-pair"><input type="text" class="hm-in" v-bind="HM" v-model.lazy="s.f.time_from" @change="setHM(s.f, 'time_from', $event)" data-f="time_from"><span>–</span><input type="text" class="hm-in" v-bind="HM" v-model.lazy="s.f.time_to" @change="setHM(s.f, 'time_to', $event)" data-f="time_to"></div></div>
        <div class="mg-quick"><button class="btn sm" @click="quick(0)" data-q="today">{{ t('rec.today') }}</button><button class="btn sm" @click="quick(1)" data-q="yesterday">{{ t('rec.yesterday') }}</button>
          <button class="btn sm" @click="quick(7)">{{ t('rec.week') }}</button><button class="btn sm" @click="quick(30)">{{ t('rec.month') }}</button></div>
      </div>
      <div class="mg-frow">
        <div class="mg-f grow2"><label>{{ t('rec.number') }}</label><input v-model.trim="s.f.number" data-f="number" inputmode="search"></div>
        <div class="mg-f" v-if="sup"><label>{{ t('rec.operator') }}</label><select v-model="s.f.agent_id" data-f="agent_id"><option value="">{{ t('rec.anyone') }}</option><option v-for="a in s.agents" :key="a.id" :value="a.id">{{ a.name }}</option></select></div>
        <div class="mg-f"><label>{{ t('rec.direction') }}</label><select v-model="s.f.direction" data-f="direction"><option value="">{{ t('rec.any') }}</option><option value="in">{{ t('rec.in') }}</option><option value="out">{{ t('rec.out') }}</option></select></div>
        <div class="mg-f sm"><label>{{ t('rec.queue') }}</label><input v-model.trim="s.f.queue" data-f="queue"></div>
        <div class="mg-f sm"><label>{{ t('rec.min') }}</label><input type="number" min="0" v-model="s.f.min_sec" data-f="min_sec"></div>
        <div class="mg-f"><label>{{ t('rec.ticket') }}</label><select v-model="s.f.ticket" data-f="ticket"><option value="">{{ t('rec.any') }}</option><option value="yes">{{ t('rec.with') }}</option><option value="no">{{ t('rec.without') }}</option></select></div>
        <button class="btn sm ghost mg-reset" @click="reset">{{ t('rec.reset') }}</button>
      </div>
    </div>
  </section>
  <section class="panel">
    <h2>{{ t('rec.found', {n: s.total}) }}<span class="h-actions"><button class="btn sm" @click="load(false)">↻</button></span></h2>
    <div v-if="!sup" class="empty" style="padding:0 16px 8px">{{ t('rec.mine') }}</div>
    <div class="table-wrap"><table class="rec-table">
      <thead><tr><th>{{ t('rec.when') }}</th><th v-if="sup">{{ t('rec.operator') }}</th><th>{{ t('rec.who') }}</th><th>{{ t('rec.queue') }}</th><th>{{ t('rec.talk') }}</th><th>{{ t('rec.ticket') }}</th><th></th></tr></thead>
      <tbody>
        <template v-for="c in s.items" :key="c.id">
          <tr :data-rec="c.id">
            <td class="mono">{{ when(c) }}</td>
            <td v-if="sup">{{ c.agent_name || '—' }}</td>
            <td><span class="rec-dir" :class="c.direction">{{ c.direction === 'out' ? '↗' : '↙' }}</span> <b class="mono">{{ c.number || '—' }}</b> <span class="empty">{{ c.name }}</span></td>
            <td>{{ c.queue || '—' }}</td>
            <td class="mono">{{ secs(c.talk_sec) }}</td>
            <td>{{ c.ticket_id ? '#' + c.ticket_id : '—' }}</td>
            <td class="rec-acts">
              <button class="btn sm" data-act="rec-play" @click="play(c)" :disabled="s.busy === c.id" :title="c.protected ? t('rec.play') : t('rec.external')"><ico name="spk"></ico> {{ t('rec.play') }}</button>
              <button class="btn sm" data-act="rec-download" @click="download(c)" :title="t('rec.download')" :aria-label="t('rec.download')"><ico name="download"></ico></button>
            </td>
          </tr>
          <tr v-if="s.playing === c.id && s.audio[c.id]" class="rec-player"><td :colspan="sup ? 7 : 6"><audio :src="s.audio[c.id]" controls autoplay data-rec-audio></audio></td></tr>
        </template>
      </tbody>
    </table></div>
    <div v-if="!s.loading && !s.items.length" class="empty" style="padding:12px 16px">{{ t('rec.none') }}</div>
    <div v-if="s.items.length < s.total" class="mg-more"><button class="btn" @click="load(true)" :disabled="s.loading">{{ t('rec.more') }} ({{ s.total - s.items.length }})</button></div>
  </section>
</div>`,
  };

  // ================================================================== the log
  const LogPage = {
    props: { api: Function, t: Function, toast: Function, fmt: Function, tz: String, token: String, live: Number },
    setup(props) {
      const t = props.t;
      const today = () => dayIn(new Date(), props.tz || "UTC");
      const blank = () => ({ date_from: today(), time_from: "", date_to: today(), time_to: "", category: [], level: [], actor_id: "", agent_id: "", action: "", q: "", ticket_id: "" });
      const s = reactive({ f: blank(), items: [], total: 0, meta: { categories: [], actions: [], people: [] }, loading: false, open: {}, auto: store.get("zenith_log_auto", true) });
      let seq = 0;
      function query(offset, forCsv) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(s.f)) {
          const val = Array.isArray(v) ? v.join(",") : v;
          if (val !== "" && val != null) q.set(k, val);
        }
        if (!forCsv) { q.set("limit", 100); q.set("offset", offset); }
        return q.toString();
      }
      async function load(more) {
        const my = ++seq;
        s.loading = true;
        try {
          const r = await props.api("GET", "/api/log?" + query(more ? s.items.length : 0));
          if (my !== seq) return;
          s.items = more ? [...s.items, ...r.items] : r.items; s.total = r.total;
        } catch (e) { if (my === seq) props.toast(e.message, "error"); } finally { if (my === seq) s.loading = false; }
      }
      async function loadMeta() { try { s.meta = await props.api("GET", "/api/log/meta"); } catch { /* ignore */ } }
      let debounce;
      watch(() => JSON.stringify(s.f), () => { clearTimeout(debounce); debounce = setTimeout(() => load(false), 250); });
      watch(() => s.auto, (v) => store.set("zenith_log_auto", v));
      watch(() => props.live, () => { if (s.auto && s.items.length <= 100 && !s.loading) load(false); });
      const toggle = (key, v) => { const a = s.f[key], i = a.indexOf(v); i >= 0 ? a.splice(i, 1) : a.push(v); };
      const reset = () => { Object.assign(s.f, blank()); };
      const actionText = (a) => { const k = "lg.a." + a, v = t(k); return v === k ? a.replace(/_/g, " ") : v; };
      const who = (e) => e.actor_name || (e.actor_type === "system" ? t("lg.system") : e.actor_type);
      const HIDE = new Set(["trace", "by", "name"]);
      const summary = (e) => Object.entries(e.details || {}).filter(([k]) => !HIDE.has(k)).map(([k, v]) => `${k}: ${typeof v === "object" ? JSON.stringify(v) : v}`).join(" · ");
      const visibleActions = computed(() => s.meta.actions.filter((a) => !s.f.category.length || s.f.category.includes(a.category)));
      async function exportCsv() {
        try { const r = await authFetch("/api/log.csv?" + query(0, true), props.token); saveBlob(await r.blob(), fileName(r, "zenith-log.csv")); }
        catch (e) { props.toast(e.message, "error"); }
      }
      onMounted(() => { loadMeta(); load(false); });
      return { HM, setHM, s, t, load, toggle, reset, actionText, who, summary, visibleActions, exportCsv };
    },
    template: `
<div class="mg" data-page="log">
  <section class="panel mg-filters" data-log="filters">
    <div class="body">
      <div class="mg-frow">
        <div class="mg-f"><label>{{ t('lg.from') }}</label><div class="mg-pair"><input type="date" v-model="s.f.date_from" data-f="date_from"><input type="text" class="hm-in" v-bind="HM" v-model.lazy="s.f.time_from" @change="setHM(s.f, 'time_from', $event)" data-f="time_from"></div></div>
        <div class="mg-f"><label>{{ t('lg.to') }}</label><div class="mg-pair"><input type="date" v-model="s.f.date_to" data-f="date_to"><input type="text" class="hm-in" v-bind="HM" v-model.lazy="s.f.time_to" @change="setHM(s.f, 'time_to', $event)" data-f="time_to"></div></div>
        <div class="mg-f"><label>{{ t('lg.who') }}</label><select v-model="s.f.actor_id" data-f="actor_id"><option value="">{{ t('lg.everyone') }}</option><option v-for="p in s.meta.people" :key="p.id" :value="p.id">{{ p.name }}</option></select></div>
        <div class="mg-f"><label>{{ t('lg.about') }}</label><select v-model="s.f.agent_id" data-f="agent_id"><option value="">{{ t('lg.everyone') }}</option><option v-for="p in s.meta.people" :key="p.id" :value="p.id">{{ p.name }}</option></select></div>
        <div class="mg-f"><label>{{ t('lg.action') }}</label><select v-model="s.f.action" data-f="action"><option value="">{{ t('lg.any') }}</option><option v-for="a in visibleActions" :key="a.action" :value="a.action">{{ actionText(a.action) }}</option></select></div>
      </div>
      <div class="mg-frow">
        <div class="lg-chips">
          <button v-for="c in s.meta.categories" :key="c" class="lg-chip" :class="['c-' + c, {on: s.f.category.includes(c)}]" :data-cat="c" @click="toggle('category', c)">{{ t('lg.c.' + c) }}</button>
        </div>
        <div class="lg-chips">
          <button v-for="l in ['error','warning','info']" :key="l" class="lg-chip lv" :class="['l-' + l, {on: s.f.level.includes(l)}]" :data-lvl="l" @click="toggle('level', l)"><i class="lg-dot"></i>{{ t('lg.l.' + l) }}</button>
        </div>
      </div>
      <div class="mg-frow">
        <div class="mg-f grow2"><input v-model.trim="s.f.q" :placeholder="t('lg.search')" data-f="q" inputmode="search"></div>
        <div class="mg-f sm"><input v-model.trim="s.f.ticket_id" :placeholder="t('lg.ticket')" data-f="ticket_id" inputmode="numeric"></div>
        <label class="check lg-auto"><input type="checkbox" v-model="s.auto"> {{ t('lg.auto') }}</label>
        <button class="btn sm ghost" @click="reset">{{ t('lg.reset') }}</button>
        <button class="btn sm" data-act="log-csv" @click="exportCsv"><ico name="download"></ico> {{ t('lg.export') }}</button>
      </div>
    </div>
  </section>
  <section class="panel">
    <h2>{{ t('lg.found', {n: s.total}) }}<span class="h-actions"><button class="btn sm" @click="load(false)">{{ t('lg.refresh') }}</button></span></h2>
    <div class="table-wrap"><table class="lg-table">
      <thead><tr><th>{{ t('lg.time') }}</th><th>{{ t('lg.what') }}</th><th>{{ t('lg.who') }}</th><th>{{ t('lg.about') }}</th><th>{{ t('lg.details') }}</th></tr></thead>
      <tbody>
        <template v-for="e in s.items" :key="e.id">
          <tr :data-log="e.id" :data-action="e.action" :class="'lv-' + e.level" @click="s.open[e.id] = !s.open[e.id]">
            <td class="mono lg-ts">{{ fmt(e.ts, true) }}<small>:{{ String(new Date(e.ts).getSeconds()).padStart(2, '0') }}</small></td>
            <td><i class="lg-dot" :class="'l-' + e.level"></i><b>{{ actionText(e.action) }}</b><div class="lg-cat" :class="'c-' + e.category">{{ t('lg.c.' + e.category) }}</div></td>
            <td>{{ who(e) }}</td>
            <td>{{ e.agent_name || '—' }}<span v-if="e.ticket_id" class="empty"> · #{{ e.ticket_id }}</span></td>
            <td class="lg-det">{{ summary(e) }}<span v-if="e.details && e.details.count > 1" class="tag">×{{ e.details.count }}</span></td>
          </tr>
          <tr v-if="s.open[e.id]" class="lg-open"><td colspan="5"><pre>{{ JSON.stringify(e.details, null, 2) }}</pre></td></tr>
        </template>
      </tbody>
    </table></div>
    <div v-if="!s.loading && !s.items.length" class="empty" style="padding:12px 16px">{{ t('lg.none') }}</div>
    <div v-if="s.items.length < s.total" class="mg-more"><button class="btn" @click="load(true)" :disabled="s.loading">{{ t('lg.more') }} ({{ s.total - s.items.length }})</button></div>
  </section>
</div>`,
  };

  return { i18n, ShiftsPage, RecordingsPage, LogPage };
})();
