/* Zenith Desk v3.18 — call routing for managers: overflow, distribution per queue, VIP / the last operator. */
window.ZenithRouting = (() => {
  const { reactive, computed, watch, onMounted } = Vue;

  const i18n = {
    en: {
      "nav.callrouting": "Call routing", "cr.title": "Call routing", "cr.lead": "How customer calls find their way: who rings first, who helps when a queue is full, and which customers go straight to their person. Changes work at once.",
      "cr.levels_off": "Routing by level is off (Administration → Call routing): «overflow» needs it, the rest works.",
      "cr.queue": "Queue {q}", "cr.waiting": "{n} waiting", "cr.over_on": "Overloaded since {t} — the added groups take calls",
      "cr.dist": "Distribution", "cr.mode.": "As set in the PBX", "cr.mode.rrmemory": "One after another (round robin)",
      "cr.mode.leastrecent": "Who has been free the longest", "cr.mode.fewestcalls": "Who has had the fewest calls", "cr.mode.ringall": "Everybody at once",
      "cr.now": "now in Asterisk: {s}", "cr.manual": "Zenith Desk may not change it here — {e}",
      "cr.over": "Overflow", "cr.over_on_l": "When the queue is full, add more people", "cr.over_n": "customers waiting, at least",
      "cr.over_x": "or someone waits, seconds (0 = no)", "cr.over_add": "who helps (rings in the first line; busy with a ticket — takes calls too; on a break — not)", "cr.over_calm": "back to normal after a calm of, seconds",
      "cr.g.level2": "Level 2", "cr.g.level3": "Level 3", "cr.g.manager": "Managers",
      "cr.vip": "VIP customers and the last operator", "cr.vip_on": "Route special customers directly",
      "cr.vip_lead": "A customer on the list goes straight to the chosen person (if free); nobody answers in the given seconds → back into the queue, at the same place in the statistics.",
      "cr.ring": "Ring the person, seconds", "cr.sticky": "Known customers: to the operator who talked to them last (if free)", "cr.sticky_days": "within days",
      "cr.rules": "List", "cr.match": "Number or prefix (+37410*)", "cr.target": "Goes to", "cr.note": "Note", "cr.add_rule": "Add a customer",
      "cr.t.level1": "a free Level 1", "cr.t.level2": "a free Level 2", "cr.t.level3": "a free Level 3", "cr.t.last": "the last operator",
      "cr.test": "Check a number", "cr.test_btn": "Where would it go now?", "cr.r.rule": "→ {name} (by the list)", "cr.r.sticky": "→ {name} (talked to him last)",
      "cr.r.busy": "→ the queue: {who} busy right now", "cr.r.nobody": "→ the queue: nobody fits", "cr.r.no_rule": "→ the queue (not on the list)", "cr.r.off": "→ the queue (routing is off)",
      "cr.save": "Save", "cr.saved": "Routing saved", "cr.unsaved": "Unsaved changes", "cr.recent": "Last decisions", "cr.none": "Nothing yet.",
      "cr.a.callroute_vip": "VIP call", "cr.a.callroute_vip_back": "Back into the queue", "cr.a.callroute_overflow_on": "Overflow on",
      "cr.a.callroute_overflow_off": "Overflow off", "cr.a.callroute_strategy": "Distribution set", "cr.a.callroute_changed": "Rules changed",
      "cr.remove": "Remove",
    },
    ru: {
      "nav.callrouting": "Маршрутизация звонков", "cr.title": "Маршрутизация звонков", "cr.lead": "Как звонки клиентов находят адресата: кому звонит первым, кто помогает при перегрузке очереди и какие клиенты идут сразу к «своему» человеку. Изменения действуют сразу.",
      "cr.levels_off": "Распределение по уровням выключено (Администрирование → Распределение звонков): для «перегрузки» оно нужно, остальное работает.",
      "cr.queue": "Очередь {q}", "cr.waiting": "ждут: {n}", "cr.over_on": "Перегрузка с {t} — добавленные группы принимают звонки",
      "cr.dist": "Распределение", "cr.mode.": "Как настроено в АТС", "cr.mode.rrmemory": "По очереди (round robin)",
      "cr.mode.leastrecent": "Кто дольше всех свободен", "cr.mode.fewestcalls": "У кого меньше всего звонков", "cr.mode.ringall": "Всем одновременно",
      "cr.now": "сейчас в Asterisk: {s}", "cr.manual": "Zenith Desk не может менять это здесь — {e}",
      "cr.over": "Перегрузка", "cr.over_on_l": "Когда очередь переполнена — добавлять людей", "cr.over_n": "ждут клиентов, не меньше",
      "cr.over_x": "или кто-то ждёт, секунд (0 — нет)", "cr.over_add": "кто помогает (звонит в первой линии; занятые тикетом тоже принимают звонки; на перерыве — нет)", "cr.over_calm": "вернуть как было после затишья, секунд",
      "cr.g.level2": "Level 2", "cr.g.level3": "Level 3", "cr.g.manager": "Руководители",
      "cr.vip": "VIP-клиенты и последний оператор", "cr.vip_on": "Направлять особых клиентов напрямую",
      "cr.vip_lead": "Клиент из списка идёт сразу к выбранному человеку (если тот свободен); не ответили за заданные секунды → обратно в очередь, в статистике это тот же звонок.",
      "cr.ring": "Звонить человеку, секунд", "cr.sticky": "Знакомые клиенты — к оператору, который говорил с ними последним (если свободен)", "cr.sticky_days": "за дней",
      "cr.rules": "Список", "cr.match": "Номер или префикс (+37410*)", "cr.target": "Кому", "cr.note": "Заметка", "cr.add_rule": "Добавить клиента",
      "cr.t.level1": "свободному Level 1", "cr.t.level2": "свободному Level 2", "cr.t.level3": "свободному Level 3", "cr.t.last": "последнему оператору",
      "cr.test": "Проверить номер", "cr.test_btn": "Куда пойдёт сейчас?", "cr.r.rule": "→ {name} (по списку)", "cr.r.sticky": "→ {name} (говорил с ним последним)",
      "cr.r.busy": "→ в очередь: {who} сейчас заняты", "cr.r.nobody": "→ в очередь: никто не подходит", "cr.r.no_rule": "→ в очередь (нет в списке)", "cr.r.off": "→ в очередь (маршрутизация выключена)",
      "cr.save": "Сохранить", "cr.saved": "Маршрутизация сохранена", "cr.unsaved": "Есть несохранённые изменения", "cr.recent": "Последние решения", "cr.none": "Пока ничего.",
      "cr.a.callroute_vip": "VIP-звонок", "cr.a.callroute_vip_back": "Обратно в очередь", "cr.a.callroute_overflow_on": "Перегрузка: включено",
      "cr.a.callroute_overflow_off": "Перегрузка: выключено", "cr.a.callroute_strategy": "Распределение задано", "cr.a.callroute_changed": "Правила изменены",
      "cr.remove": "Удалить",
    },
  };

  const clone = (x) => JSON.parse(JSON.stringify(x));

  const RoutingPage = {
    props: { api: Function, t: Function, toast: Function, fmt: Function, live: Number },
    setup(props) {
      const t = props.t;
      const s = reactive({ d: null, form: null, saved: "", busy: false, test: "", testResult: null });
      const toForm = (d) => ({
        queues: Object.fromEntries(d.queues.map((q) => [q.queue, { mode: q.mode, overflow: clone(q.overflow) }])),
        vip: clone(d.vip),
      });
      const dirty = computed(() => s.form && JSON.stringify(s.form) !== s.saved);
      async function load(force) {
        try {
          const d = await props.api("GET", "/api/admin/call-routing");
          s.d = d;
          if (!s.form || force || !dirty.value) { s.form = toForm(d); s.saved = JSON.stringify(s.form); }
        } catch (e) { props.toast(e.message, "error"); }
      }
      async function save() {
        s.busy = true;
        try {
          const d = await props.api("PUT", "/api/admin/call-routing", s.form);
          s.d = d; s.form = toForm(d); s.saved = JSON.stringify(s.form);
          props.toast(t("cr.saved"));
        } catch (e) { props.toast(e.message, "error"); } finally { s.busy = false; }
      }
      function addRule() { s.form.vip.rules.push({ match: "", target: "last", note: "" }); }
      function toggleGroup(o, g) { o.add = o.add.includes(g) ? o.add.filter((x) => x !== g) : [...o.add, g]; }
      async function testNumber() {
        if (!s.test.trim()) return;
        try { s.testResult = await props.api("GET", "/api/admin/call-routing/test?number=" + encodeURIComponent(s.test.trim())); }
        catch (e) { props.toast(e.message, "error"); }
      }
      const testText = computed(() => {
        const r = s.testResult;
        if (!r) return "";
        if (r.agent) return t("cr.r." + r.reason, { name: r.agent.name });
        return t("cr.r." + r.reason, { who: (r.candidates || []).join(", ") || "—" });
      });
      const qInfo = (q) => (s.d ? s.d.queues.find((x) => x.queue === q) : null);
      const targetName = (x) => {
        if (x.startsWith("agent:")) { const a = s.d.agents.find((y) => `agent:${y.id}` === x); return a ? a.name : x; }
        return t("cr.t." + x);
      };
      const recentText = (r) => {
        const d = r.details || {};
        return [d.queue && t("cr.queue", { q: d.queue }), d.number, d.name, d.result, d.reason, d.strategy, d.added && d.added.join(", ")].filter(Boolean).join(" · ");
      };
      watch(() => props.live, () => load(false));
      onMounted(() => load(true));
      return { s, t, dirty, save, addRule, toggleGroup, testNumber, testText, qInfo, targetName, recentText, fmt: props.fmt };
    },
    template: `
<div class="cr-page" data-page="callrouting">
  <section class="panel">
    <h2>{{ t('cr.title') }} <span class="h-actions"><span v-if="dirty" class="tag warn" data-cr="dirty">{{ t('cr.unsaved') }}</span>
      <button class="btn sm primary" :disabled="s.busy || !dirty" @click="save" data-cr="save">{{ t('cr.save') }}</button></span></h2>
    <div class="body"><p class="bk-lead">{{ t('cr.lead') }}</p>
      <div v-if="s.d && !s.d.level_routing" class="banner" data-cr="levels-off">{{ t('cr.levels_off') }}</div></div>
  </section>
  <template v-if="s.d && s.form">
    <div class="cr-queues">
      <section v-for="q in s.d.queues" :key="q.queue" class="panel cr-q" :class="{hot: q.overflow_active_since}" :data-cr-queue="q.queue">
        <h2>{{ t('cr.queue', {q: q.queue}) }} <span class="count" :class="{hot: q.waiting}">{{ t('cr.waiting', {n: q.waiting}) }}</span></h2>
        <div class="body">
          <div v-if="q.overflow_active_since" class="banner warn cr-over-on" data-cr="overflow-on">{{ t('cr.over_on', {t: fmt(q.overflow_active_since)}) }}</div>
          <label>{{ t('cr.dist') }}</label>
          <select v-model="s.form.queues[q.queue].mode" data-cr="mode">
            <option v-for="m in ['', ...s.d.modes]" :key="m" :value="m">{{ t('cr.mode.' + m) }}</option></select>
          <div class="hint">{{ t('cr.now', {s: q.strategy_now || '—'}) }}</div>
          <div v-if="q.strategy_error" class="hint err" data-cr="strategy-error">{{ q.strategy_error }}</div>
          <h4>{{ t('cr.over') }}</h4>
          <label class="check"><input type="checkbox" v-model="s.form.queues[q.queue].overflow.enabled" data-cr="over-enabled"> {{ t('cr.over_on_l') }}</label>
          <div class="cr-row" :class="{off: !s.form.queues[q.queue].overflow.enabled}">
            <div><label>{{ t('cr.over_n') }}</label><input type="number" min="1" max="500" v-model.number="s.form.queues[q.queue].overflow.waiting" data-cr="over-n"></div>
            <div><label>{{ t('cr.over_x') }}</label><input type="number" min="0" max="3600" v-model.number="s.form.queues[q.queue].overflow.wait_sec" data-cr="over-x"></div>
            <div><label>{{ t('cr.over_calm') }}</label><input type="number" min="10" max="3600" v-model.number="s.form.queues[q.queue].overflow.calm_sec"></div>
          </div>
          <label>{{ t('cr.over_add') }}</label>
          <div class="cr-groups"><label v-for="g in s.d.groups" :key="g" class="check"><input type="checkbox" :checked="s.form.queues[q.queue].overflow.add.includes(g)"
              @change="toggleGroup(s.form.queues[q.queue].overflow, g)" :data-cr-group="g"> {{ t('cr.g.' + g) }}</label></div>
        </div>
      </section>
    </div>
    <section class="panel cr-vip" data-cr="vip">
      <h2>{{ t('cr.vip') }}</h2>
      <div class="body">
        <p class="bk-lead">{{ t('cr.vip_lead') }}</p>
        <label class="check"><input type="checkbox" v-model="s.form.vip.enabled" data-cr="vip-enabled"> {{ t('cr.vip_on') }}</label>
        <div class="cr-row">
          <div><label>{{ t('cr.ring') }}</label><input type="number" min="5" max="120" v-model.number="s.form.vip.ring_sec"></div>
          <div class="cr-sticky"><label class="check"><input type="checkbox" v-model="s.form.vip.sticky" data-cr="sticky"> {{ t('cr.sticky') }}</label>
            <span class="cr-days">{{ t('cr.sticky_days') }} <input type="number" min="1" max="365" v-model.number="s.form.vip.sticky_days"></span></div>
        </div>
        <h4>{{ t('cr.rules') }} <span class="count">{{ s.form.vip.rules.length }}</span></h4>
        <div class="table-wrap"><table class="cr-rules">
          <thead><tr><th>{{ t('cr.match') }}</th><th>{{ t('cr.target') }}</th><th>{{ t('cr.note') }}</th><th></th></tr></thead>
          <tbody><tr v-for="(r, i) in s.form.vip.rules" :key="i" :data-cr-rule="i">
            <td><input v-model="r.match" class="mono" placeholder="+37491123456" data-cr="match"></td>
            <td><select v-model="r.target" data-cr="target">
              <optgroup :label="t('cr.target')"><option v-for="k in ['last','level1','level2','level3']" :key="k" :value="k">{{ t('cr.t.' + k) }}</option></optgroup>
              <optgroup label="—"><option v-for="a in s.d.agents" :key="a.id" :value="'agent:' + a.id">{{ a.name }}<template v-if="a.extension"> · {{ a.extension }}</template></option></optgroup>
            </select></td>
            <td><input v-model="r.note" maxlength="100"></td>
            <td><button class="btn sm danger" @click="s.form.vip.rules.splice(i, 1)" :title="t('cr.remove')">✕</button></td>
          </tr></tbody>
        </table></div>
        <button class="btn sm" @click="addRule" data-cr="add-rule">+ {{ t('cr.add_rule') }}</button>
        <div class="cr-test"><label>{{ t('cr.test') }}</label>
          <div class="cr-test-row"><input v-model="s.test" class="mono" placeholder="+37491123456" @keydown.enter="testNumber" data-cr="test-number">
            <button class="btn sm" @click="testNumber" data-cr="test">{{ t('cr.test_btn') }}</button>
            <b v-if="testText" data-cr="test-result">{{ testText }}</b></div></div>
      </div>
    </section>
    <section class="panel cr-recent">
      <h2>{{ t('cr.recent') }}</h2>
      <div class="body">
        <div v-if="!s.d.recent.length" class="empty">{{ t('cr.none') }}</div>
        <div v-for="r in s.d.recent" :key="r.id" class="item" :data-cr-recent="r.action"><b>{{ t('cr.a.' + r.action) }}</b> <span class="empty">{{ fmt(r.ts, true) }}</span>
          <div class="meta">{{ recentText(r) }}</div></div>
      </div>
    </section>
  </template>
</div>`,
  };

  return { i18n, RoutingPage };
})();
