/* Zenith Desk v3.3 — ticketing inside Zenith Desk (Zammad stays the system of record) and the read-only directory
   of Zammad customers and staff. Two components: <tickets-page> and <contacts-page>. */
window.AgentixTickets = (() => {
  const { reactive, computed, watch, onMounted, onBeforeUnmount, nextTick } = Vue;
  const handledNew = { n: 0 };  // v3.14: last «new ticket» request handled (survives the page being closed and opened)

  const i18n = {
    en: {
      "nav.tickets": "Tickets", "nav.contacts": "Customers",
      "tk.views": "Overviews", "tk.open_tabs": "Open", "tk.close_tab": "Close", "tk.refresh": "Refresh", "tk.of": "{n} of {m}",
      "tk.no_records": "No records", "tk.limited": "Zammad returns the first {n} of {m} tickets of this overview — narrow it down with the search or filters.",
      "tk.col.title": "Title", "tk.col.number": "#", "tk.col.customer": "Customer", "tk.col.group": "Group", "tk.col.state": "State",
      "tk.col.priority": "Priority", "tk.col.owner": "Owner", "tk.col.created_at": "Created", "tk.col.organization": "Organization",
      "tk.f.owner": "Any owner", "tk.f.owner_me": "Me", "tk.f.owner_none": "Unassigned (-)", "tk.f.reset": "Reset filters",
      "tk.ticket": "Ticket", "tk.tags": "Tags", "tk.add_tag": "+ Add tag", "tk.update": "Update", "tk.revert": "Discard changes",
      "tk.unsaved": "Changes are not saved yet", "tk.created_short": "created",
      "tk.dr.badge": "draft", "tk.dr.untitled": "New ticket", "tk.dr.saving": "saving…", "tk.dr.saved": "draft saved",
      "tk.dr.caller": "Caller:", "tk.dr.call_back": "Open the phone with this number to call back", "tk.dr.from_call": "from the call · the call details go into the ticket",
      "tk.dr.title_hint": "What is it about?", "tk.dr.body_hint": "What the customer said, what was done…", "tk.dr.channel": "How the request came",
      "tk.dr.kind.phone": "Phone call", "tk.dr.kind.note": "Note", "tk.dr.kind.web": "Web", "tk.dr.change": "Change",
      "tk.dr.discard": "Cancel & go back", "tk.dr.discard_q": "Throw this draft away?", "tk.dr.missing": "Fill in: {f}",
      "tk.dr.owner_dropped": "The owner has no full access to this group in Zammad — the ticket was created without an owner",
      "tk.view.mine": "Mine", "tk.view.unassigned": "Unassigned", "tk.view.all": "All open", "tk.view.closed": "Closed",
      "tk.search": "Search by number, title, text…", "tk.f.state": "Any state", "tk.f.priority": "Any priority", "tk.f.group": "Any group",
      "tk.new": "New ticket", "tk.count": "{n} tickets", "tk.more": "Show more", "tk.none": "No tickets here", "tk.loading": "Loading…",
      "tk.pick": "Select a ticket on the left", "tk.pick_sub": "Everything you do here is saved in Zammad at once — in your name.",
      "tk.cat.new": "new", "tk.cat.open": "open", "tk.cat.pending": "waiting", "tk.cat.closed": "closed",
      "tk.unassigned": "unassigned", "tk.in_work": "in work", "tk.in_bg": "background",
      "tk.state": "State", "tk.priority": "Priority", "tk.group": "Group", "tk.owner": "Owner", "tk.customer": "Customer",
      "tk.created": "Created", "tk.updated": "Updated", "tk.pending_until": "Waiting until", "tk.days": "days",
      "tk.transfer": "Transfer", "tk.take": "Take it", "tk.open_zammad": "Open in Zammad", "tk.props": "Details",
      "tk.work": "Work", "tk.start": "Start", "tk.background": "Background", "tk.complete": "Complete",
      "tk.note": "Internal note", "tk.reply": "Reply to customer", "tk.public_note": "Public note",
      "tk.reply_via": "via {ch}", "tk.reply_to": "to {to}",
      "tk.placeholder.note": "Note for colleagues — the customer does not see it…",
      "tk.placeholder.reply": "Answer to the customer…",
      "tk.attach": "Attach files", "tk.send": "Send", "tk.send_hint": "Ctrl+Enter", "tk.and_state": "and set state",
      "tk.keep_state": "keep state", "tk.sent": "Saved in Zammad", "tk.updated_toast": "Ticket updated",
      "tk.internal": "internal", "tk.empty_thread": "No messages yet",
      "tk.edit_title": "Click to edit the title", "tk.download": "Download",
      "tk.tr.title": "Transfer ticket #{n}", "tk.tr.hint": "Colleagues with full access to the group in Zammad.",
      "tk.tr.search": "Find a colleague…", "tk.tr.nobody": "Unassigned (for the team)", "tk.tr.note": "Comment for the colleague (internal note)",
      "tk.tr.go": "Transfer", "tk.tr.done": "Ticket transferred to {name}", "tk.tr.me": "you", "tk.tr.owner": "owner now",
      "tk.tr.none": "Nobody found. The list comes from Zammad users with access to this group.",
      "tk.tr.group": "Move to group", "tk.tr.keep_group": "keep the group",
      "tk.nw.title": "New ticket", "tk.nw.customer": "Customer", "tk.nw.find": "Name, phone or e-mail…", "tk.nw.subject": "Subject",
      "tk.nw.body": "Description", "tk.nw.assign": "Assign to me", "tk.nw.create": "Create", "tk.nw.create_start": "Create and start",
      "tk.nw.state": "State", "tk.nw.type": "Type", "tk.nw.created": "Ticket #{n} created", "tk.nw.need_customer": "Choose a customer",
      "tk.nw.no_customer": "Nobody found — customers are added in Zammad.",
      "tk.gone": "The ticket moved to a group you have no access to", "tk.owner_reset": "The owner had no access to the new group — the ticket is now unassigned",
      "tk.changed_by_other": "Updated just now",
      "tk.not_linked": "Your account is not linked to a Zammad user — ask the administrator.",
      "tk.assigned_toast": "{by} transferred ticket #{n} to you", "tk.assigned_open": "Open",
      "ct.customers": "Customers", "ct.staff": "Zammad users", "ct.search": "Search by name, phone, e-mail, company…",
      "ct.readonly": "Customers and users are created and edited in Zammad — Zenith Desk shows them automatically.",
      "ct.synced": "Synced {t}", "ct.sync": "Sync now", "ct.syncing": "Syncing…", "ct.never": "not synced yet",
      "ct.pick": "Select a person on the left", "ct.tickets": "Tickets", "ct.no_tickets": "No tickets",
      "ct.new_ticket": "New ticket", "ct.org": "Company", "ct.email": "E-mail", "ct.phone": "Phone", "ct.mobile": "Mobile",
      "ct.note": "Note", "ct.groups": "Groups", "ct.roles": "Roles", "ct.since": "In Zammad since", "ct.inactive": "inactive",
      "ct.new_toast": "New in Zammad: {name}", "ct.none": "Nobody found", "ct.more": "Show more",
    },
    ru: {
      "nav.tickets": "Заявки", "nav.contacts": "Клиенты",
      "tk.views": "Представления", "tk.open_tabs": "Открытые", "tk.close_tab": "Закрыть", "tk.refresh": "Обновить", "tk.of": "{n} из {m}",
      "tk.no_records": "Нет записей", "tk.limited": "Zammad отдаёт первые {n} из {m} заявок этого представления — сузьте список поиском или фильтрами.",
      "tk.col.title": "Заголовок", "tk.col.number": "№", "tk.col.customer": "Клиент", "tk.col.group": "Группа", "tk.col.state": "Состояние",
      "tk.col.priority": "Приоритет", "tk.col.owner": "Владелец", "tk.col.created_at": "Создано", "tk.col.organization": "Организация",
      "tk.f.owner": "Любой владелец", "tk.f.owner_me": "Я", "tk.f.owner_none": "Не назначен (-)", "tk.f.reset": "Сбросить фильтры",
      "tk.ticket": "Заявка", "tk.tags": "Теги", "tk.add_tag": "+ Добавить тег", "tk.update": "Обновить", "tk.revert": "Отменить изменения",
      "tk.unsaved": "Изменения ещё не сохранены", "tk.created_short": "создано",
      "tk.dr.badge": "черновик", "tk.dr.untitled": "Новая заявка", "tk.dr.saving": "сохранение…", "tk.dr.saved": "черновик сохранён",
      "tk.dr.caller": "Звонивший:", "tk.dr.call_back": "Открыть телефон с этим номером, чтобы перезвонить", "tk.dr.from_call": "из звонка · данные звонка попадут в заявку",
      "tk.dr.title_hint": "О чём обращение?", "tk.dr.body_hint": "Что сказал клиент, что сделано…", "tk.dr.channel": "Как пришло обращение",
      "tk.dr.kind.phone": "Звонок", "tk.dr.kind.note": "Заметка", "tk.dr.kind.web": "Веб", "tk.dr.change": "Изменить",
      "tk.dr.discard": "Отмена и возврат", "tk.dr.discard_q": "Удалить этот черновик?", "tk.dr.missing": "Заполните: {f}",
      "tk.dr.owner_dropped": "У владельца нет полного доступа к этой группе в Zammad — заявка создана без владельца",
      "tk.view.mine": "Мои", "tk.view.unassigned": "Свободные", "tk.view.all": "Все открытые", "tk.view.closed": "Закрытые",
      "tk.search": "Поиск по номеру, теме, тексту…", "tk.f.state": "Любой статус", "tk.f.priority": "Любой приоритет", "tk.f.group": "Любая группа",
      "tk.new": "Новая заявка", "tk.count": "Тикетов: {n}", "tk.more": "Показать ещё", "tk.none": "Здесь нет тикетов", "tk.loading": "Загрузка…",
      "tk.pick": "Выберите тикет слева", "tk.pick_sub": "Всё, что вы делаете здесь, сразу сохраняется в Zammad — от вашего имени.",
      "tk.cat.new": "новый", "tk.cat.open": "открыт", "tk.cat.pending": "ожидание", "tk.cat.closed": "закрыт",
      "tk.unassigned": "не назначен", "tk.in_work": "в работе", "tk.in_bg": "фоном",
      "tk.state": "Статус", "tk.priority": "Приоритет", "tk.group": "Группа", "tk.owner": "Ответственный", "tk.customer": "Клиент",
      "tk.created": "Создан", "tk.updated": "Изменён", "tk.pending_until": "Ожидание до", "tk.days": "дн.",
      "tk.transfer": "Передать", "tk.take": "Взять себе", "tk.open_zammad": "Открыть в Zammad", "tk.props": "Свойства",
      "tk.work": "Работа", "tk.start": "Приступить", "tk.background": "Фоновая задача", "tk.complete": "Завершить",
      "tk.note": "Внутренняя заметка", "tk.reply": "Ответ клиенту", "tk.public_note": "Публичная заметка",
      "tk.reply_via": "через {ch}", "tk.reply_to": "кому: {to}",
      "tk.placeholder.note": "Заметка для коллег — клиент её не видит…",
      "tk.placeholder.reply": "Ответ клиенту…",
      "tk.attach": "Прикрепить файлы", "tk.send": "Отправить", "tk.send_hint": "Ctrl+Enter", "tk.and_state": "и сменить статус",
      "tk.keep_state": "не менять статус", "tk.sent": "Сохранено в Zammad", "tk.updated_toast": "Тикет изменён",
      "tk.internal": "внутр.", "tk.empty_thread": "Сообщений пока нет",
      "tk.edit_title": "Нажмите, чтобы изменить тему", "tk.download": "Скачать",
      "tk.tr.title": "Передать тикет #{n}", "tk.tr.hint": "Коллеги с полным доступом к группе в Zammad.",
      "tk.tr.search": "Найти коллегу…", "tk.tr.nobody": "Не назначен (для команды)", "tk.tr.note": "Комментарий коллеге (внутренняя заметка)",
      "tk.tr.go": "Передать", "tk.tr.done": "Тикет передан: {name}", "tk.tr.me": "вы", "tk.tr.owner": "сейчас ответственный",
      "tk.tr.none": "Никого не найдено. Список — это пользователи Zammad с доступом к этой группе.",
      "tk.tr.group": "Перенести в группу", "tk.tr.keep_group": "оставить группу",
      "tk.nw.title": "Новый тикет", "tk.nw.customer": "Клиент", "tk.nw.find": "Имя, телефон или e-mail…", "tk.nw.subject": "Тема",
      "tk.nw.body": "Описание", "tk.nw.assign": "Назначить на меня", "tk.nw.create": "Создать", "tk.nw.create_start": "Создать и приступить",
      "tk.nw.state": "Статус", "tk.nw.type": "Тип", "tk.nw.created": "Тикет #{n} создан", "tk.nw.need_customer": "Выберите клиента",
      "tk.nw.no_customer": "Никого не найдено — клиенты добавляются в Zammad.",
      "tk.gone": "Тикет перенесён в группу, к которой у вас нет доступа", "tk.owner_reset": "У ответственного нет доступа к новой группе — тикет теперь не назначен",
      "tk.changed_by_other": "Только что изменён",
      "tk.not_linked": "Ваша учётная запись не связана с пользователем Zammad — обратитесь к администратору.",
      "tk.assigned_toast": "{by} передал(а) вам тикет #{n}", "tk.assigned_open": "Открыть",
      "ct.customers": "Клиенты", "ct.staff": "Пользователи Zammad", "ct.search": "Поиск по имени, телефону, e-mail, компании…",
      "ct.readonly": "Клиенты и пользователи создаются и редактируются в Zammad — Zenith Desk показывает их автоматически.",
      "ct.synced": "Синхронизировано {t}", "ct.sync": "Синхронизировать", "ct.syncing": "Синхронизация…", "ct.never": "ещё не синхронизировано",
      "ct.pick": "Выберите человека слева", "ct.tickets": "Тикеты", "ct.no_tickets": "Тикетов нет",
      "ct.new_ticket": "Новый тикет", "ct.org": "Компания", "ct.email": "E-mail", "ct.phone": "Телефон", "ct.mobile": "Мобильный",
      "ct.note": "Заметка", "ct.groups": "Группы", "ct.roles": "Роли", "ct.since": "В Zammad с", "ct.inactive": "неактивен",
      "ct.new_toast": "Новый в Zammad: {name}", "ct.none": "Никого не найдено", "ct.more": "Показать ещё",
    },
  };

  const AV = 6;
  const avClass = (id) => "av-" + (Math.abs(+id || 0) % AV);
  const initials = (name) => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase();
  const URL_RE = /(https?:\/\/[^\s<>"')]+|mailto:[^\s<>"')]+)/g;
  /** Text -> [{text}|{url}] so links are clickable without ever rendering HTML from a customer. */
  function linkify(text) {
    const out = []; let last = 0;
    (text || "").replace(URL_RE, (m, _x, i) => { if (i > last) out.push({ text: text.slice(last, i) }); out.push({ url: m }); last = i + m.length; return m; });
    if (last < (text || "").length) out.push({ text: text.slice(last) });
    return out;
  }
  const CH_ICON = { email: "at", phone: "phone", note: "edit", web: "work", sms: "chat", "telegram personal-message": "send",
                    "whatsapp message": "chat", "facebook direct-message": "chat", chat: "chat" };
  const chName = (type) => ({ email: "E-mail", phone: "Phone", note: "Note", web: "Web", sms: "SMS", "telegram personal-message": "Telegram",
                              "whatsapp message": "WhatsApp", "facebook direct-message": "Facebook", chat: "Chat" }[type] || type);
  const dial = (number, name) => window.zenithDial && window.zenithDial(number, name);
  const fileSize = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : n > 1024 ? Math.round(n / 1024) + " KB" : n + " B");
  const readFile = (f) => new Promise((ok, fail) => {
    const r = new FileReader();
    r.onload = () => ok({ filename: f.name, mime: f.type || "application/octet-stream", size: f.size, data: String(r.result).split(",", 2)[1] || "" });
    r.onerror = () => fail(r.error); r.readAsDataURL(f);
  });

  // ==================================================================== <tickets-page>  (v3.11: like the operator's Zammad)
  const TicketsPage = {
    props: ["api", "t", "toast", "fmt", "me", "config", "token", "openReq", "newReq", "stateText", "studio"],
    emits: ["open-customer"],
    setup(props) {
      const t = props.t;
      const s = reactive({
        meta: null, err: "",
        // overviews (from Zammad) and the list of one overview
        ovs: [], ov: "", list: null, f: { q: "", group: "", state: "", priority: "", owner: "" }, sort: "", dir: "", page: 1, per: 50, loading: false,
        // task bar: open tickets and drafts
        tabs: [], view: "overview", tabId: null, navOpen: false, tkCat: {},  // v3.17.1: ticket id → {category, state} for the tab dots
        // one ticket
        sel: null, d: null, dLoading: false, flash: false, form: null, owners: {}, tagQ: "", tagHints: [],
        kind: "note", internal: true, text: "", files: [], sendState: "", pendingDays: 1, sending: false,
        editTitle: false, title: "", tr: null, busy: false, side: false,
        // draft of a new ticket
        dr: null, drSaving: false, drSaved: false, cq: "", cfound: [],
      });
      const api = props.api;
      let lseq = 0, dseq = 0;

      // ---------------------------------------------------------- reference data, overviews, tabs
      async function loadMeta() {
        try { s.meta = await api("GET", "/api/tk/meta"); s.err = ""; }
        catch (e) { s.err = e.status === 409 ? t("tk.not_linked") : e.message; }
      }
      async function loadOverviews() {
        try {
          s.ovs = (await api("GET", "/api/tk/overviews")).overviews;
          if (!s.ov && s.ovs.length) s.ov = (s.ovs.find((o) => o.link === "my_assigned") || s.ovs[0]).link;
        } catch (e) { props.toast(e.message, "error"); }
      }
      function noteCat(id, category, state) { if (id && category) s.tkCat[id] = { category, state: state || "" }; }
      async function loadTabs() {
        try {
          const r = await api("GET", "/api/tk/tabs?with_state=true");
          r.tabs.forEach((x) => noteCat(x.ticket_id, x.category, x.state));
          s.tabs = r.tabs;
        } catch { /* ignore */ }
      }
      // the stage of the ticket behind a tab: new / open / pending / closed (closed = green); drafts have none
      const tabCat = (tb) => (tb.kind === "draft" ? "draft" : ((s.tkCat[tb.ticket_id] || {}).category || tb.category || "unknown"));
      const tabState = (tb) => (s.tkCat[tb.ticket_id] || {}).state || tb.state || "";
      async function loadList(keep, fresh) {
        if (!s.ov) return;
        const my = ++lseq;
        if (!keep) s.loading = true;
        const qs = new URLSearchParams({ ...s.f, sort: s.sort, direction: s.dir, page: String(keep ? s.page : 1), per_page: String(s.per) });
        if (fresh) qs.set("fresh", "true");
        try {
          const r = await api("GET", `/api/tk/overviews/${encodeURIComponent(s.ov)}?` + qs);
          if (my !== lseq) return;
          s.list = r; if (!keep) s.page = 1;
          r.tickets.forEach((x) => noteCat(x.id, x.category, x.state));
        } catch (e) { if (my === lseq) props.toast(e.message, "error"); }
        finally { if (my === lseq) s.loading = false; }
      }
      function pickOverview(link) {
        s.ov = link; s.view = "overview"; s.tabId = null; s.navOpen = false;
        s.f = { q: "", group: "", state: "", priority: "", owner: "" }; s.sort = ""; s.dir = ""; s.list = null;
        loadList();
      }
      let qTimer = null;
      function onFilter() { clearTimeout(qTimer); qTimer = setTimeout(() => loadList(), 250); }
      function sortBy(col) {
        if (s.sort === col) s.dir = s.dir === "asc" ? "desc" : "asc"; else { s.sort = col; s.dir = "asc"; }
        loadList();
      }
      function goPage(n) { s.page = n; loadList(true); }
      const pages = computed(() => (s.list ? Math.max(1, Math.ceil(s.list.total / s.per)) : 1));
      const curOv = computed(() => s.ovs.find((o) => o.link === s.ov));
      const metaGroups = computed(() => (s.meta && s.meta.groups) || []);
      const metaPriorities = computed(() => (s.meta && s.meta.priorities) || []);  // a ticket can be shown before its metadata arrives
      const filtered = computed(() => Object.values(s.f).some(Boolean));

      // ---------------------------------------------------------- one ticket
      async function openTicket(id, silent) {
        if (!id) return;
        const my = ++dseq;
        if (s.sel !== id || s.view !== "ticket") {
          s.kind = "note"; s.internal = true; s.text = ""; s.files = []; s.sendState = ""; s.editTitle = false; s.d = null; s.form = null; s.side = false;
        }
        s.sel = id; s.view = "ticket"; s.navOpen = false;
        if (!silent) s.dLoading = true;
        try {
          const d = await api("GET", `/api/tk/tickets/${id}`);
          if (my !== dseq) return;
          const dirty = s.form && isDirty.value;
          s.d = d;
          noteCat(d.ticket.id, d.ticket.category, d.ticket.state);
          if (!dirty) resetForm();
          if (silent) { s.flash = true; setTimeout(() => { s.flash = false; }, 900); }
          else nextTick(scrollThread);
          const tab = await api("POST", "/api/tk/tabs", { ticket_id: id, number: d.ticket.number, title: d.ticket.title });
          s.tabId = tab.id;
          if (!s.tabs.some((x) => x.id === tab.id)) s.tabs.push(tab); else s.tabs = s.tabs.map((x) => (x.id === tab.id ? tab : x));
        } catch (e) {
          if (my !== dseq) return;
          if (!silent) props.toast(e.message, "error");
          if (e.status === 403 || e.status === 404) { s.sel = null; s.d = null; s.view = "overview"; }
        } finally { if (my === dseq) s.dLoading = false; }
      }
      function scrollThread() { const el = document.querySelector(".tk-thread"); if (el) el.scrollTop = el.scrollHeight; }
      const tk = computed(() => (s.d ? s.d.ticket : null));
      const openStates = computed(() => (s.meta ? s.meta.states : []));
      const replyLabel = computed(() => {
        if (!s.d) return "";
        const r = s.d.reply;
        if (r.type === "note") return t("tk.public_note");
        return t("tk.reply_via", { ch: chName(r.type) }) + (r.to ? " · " + t("tk.reply_to", { to: r.to }) : "");
      });
      const catText = (c) => t("tk.cat." + (c || "open"));
      const isPending = (name) => { const st = openStates.value.find((x) => x.name === name); return st && st.category === "pending"; };

      // the side panel works like Zammad: change the fields, then «Update»
      function resetForm() {
        const x = tk.value; if (!x) { s.form = null; return; }
        s.form = { group: x.group, owner_id: x.owner_id || 0, state: x.state, priority: x.priority, tags: [...(x.tags || [])] };
        loadOwners(x.group);
      }
      const isDirty = computed(() => {
        const x = tk.value, f = s.form; if (!x || !f) return false;
        return f.group !== x.group || (f.owner_id || 0) !== (x.owner_id || 0) || f.state !== x.state || f.priority !== x.priority
          || JSON.stringify(f.tags) !== JSON.stringify(x.tags || []);
      });
      async function loadOwners(group) {
        if (!group || s.owners[group]) return;
        try { s.owners = { ...s.owners, [group]: (await api("GET", `/api/tk/assignees?group=${encodeURIComponent(group)}`)).people }; }
        catch { s.owners = { ...s.owners, [group]: [] }; }
      }
      const ownerList = (group, current, currentName) => {
        const list = (s.owners[group] || []).slice();
        if (current && !list.some((p) => p.id === current)) list.push({ id: current, name: currentName || `#${current}` });
        return list;
      };
      function onGroup(g) { s.form.group = g; loadOwners(g).then(() => { if (s.form.owner_id && !(s.owners[g] || []).some((p) => p.id === s.form.owner_id)) s.form.owner_id = 0; }); }
      async function saveForm() {
        const x = tk.value, f = s.form; if (!x || !f || s.busy) return;
        const body = {};
        if (f.group !== x.group) body.group = f.group;
        if ((f.owner_id || 0) !== (x.owner_id || 0)) body.owner_id = f.owner_id || 0;
        if (f.state !== x.state) { body.state = f.state; if (isPending(f.state)) body.pending_days = 1; }
        if (f.priority !== x.priority) body.priority = f.priority;
        if (JSON.stringify(f.tags) !== JSON.stringify(x.tags || [])) body.tags = f.tags;
        if (!Object.keys(body).length) return;
        s.busy = true;
        try {
          const r = await api("PATCH", `/api/tk/tickets/${s.sel}`, body);
          if (r.gone) { props.toast(t("tk.gone")); closeTabOf(s.sel); }
          else { s.d = r; resetForm(); props.toast(r.owner_reset ? t("tk.owner_reset") : t("tk.updated_toast")); }
          refreshAll();
        } catch (e) { props.toast(e.message, "error"); }
        finally { s.busy = false; }
      }
      // tags (chips with suggestions from Zammad)
      let tagTimer = null;
      function tagInput(target) {
        clearTimeout(tagTimer);
        const q = s.tagQ.trim();
        if (!q) { s.tagHints = []; return; }
        tagTimer = setTimeout(async () => { try { s.tagHints = (await api("GET", `/api/tk/tags?term=${encodeURIComponent(q)}`)).tags.filter((x) => !target.tags.includes(x)); } catch { s.tagHints = []; } }, 200);
      }
      function addTag(target, v) {
        const tag = (v || s.tagQ).trim().replace(/,$/, "");
        if (tag && !target.tags.includes(tag)) target.tags.push(tag);
        s.tagQ = ""; s.tagHints = [];
      }
      function tagKey(target, ev) {
        if (ev.key === "Enter" || ev.key === ",") { ev.preventDefault(); addTag(target); }
        else if (ev.key === "Backspace" && !s.tagQ && target.tags.length) target.tags.pop();
      }

      // ---------------------------------------------------------- writing in the ticket (as before)
      async function addFiles(ev) {
        const max = ((s.meta && s.meta.attachment_max_mb) || 10) * 1048576;
        for (const f of Array.from(ev.target.files || [])) {
          if (f.size > max) { props.toast(`${f.name}: > ${(s.meta && s.meta.attachment_max_mb) || 10} MB`, "error"); continue; }
          try { s.files.push(await readFile(f)); } catch (e) { props.toast(e.message, "error"); }
        }
        ev.target.value = "";
      }
      async function send() {
        if (s.sending || (!s.text.trim() && !s.files.length)) return;
        s.sending = true;
        try {
          s.d = await api("POST", `/api/tk/tickets/${s.sel}/articles`, {
            body: s.text, kind: s.kind, internal: s.kind === "note" ? s.internal : false,
            attachments: s.files.map((f) => ({ filename: f.filename, mime: f.mime, data: f.data })),
            state: s.sendState || null, pending_days: s.sendState && isPending(s.sendState) ? +s.pendingDays || 1 : null,
          });
          if (!isDirty.value) resetForm();
          s.text = ""; s.files = []; s.sendState = "";
          props.toast(t("tk.sent")); nextTick(scrollThread); refreshAll();
        } catch (e) { props.toast(e.message, "error"); }
        finally { s.sending = false; }
      }
      function onKey(ev) { if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); send(); } }
      async function patch(body, okText) {
        if (s.busy) return;
        s.busy = true;
        try {
          const r = await api("PATCH", `/api/tk/tickets/${s.sel}`, body);
          if (r.gone) { props.toast(t("tk.gone")); closeTabOf(s.sel); }
          else { s.d = r; resetForm(); if (r.owner_reset) props.toast(t("tk.owner_reset")); else if (okText) props.toast(okText); }
          refreshAll();
          return r;
        } catch (e) { props.toast(e.message, "error"); if (s.sel) openTicket(s.sel, true); }
        finally { s.busy = false; }
      }
      function startTitle() { s.title = tk.value.title; s.editTitle = true; nextTick(() => { const el = document.querySelector(".tk-title-input"); if (el) el.focus(); }); }
      function saveTitle() { s.editTitle = false; if (s.title.trim() && s.title.trim() !== tk.value.title) patch({ title: s.title.trim() }, t("tk.updated_toast")); }
      const takeIt = () => patch({ owner_id: props.me.zammad_user_id || (s.meta && s.meta.zammad_user_id) }, t("tk.updated_toast"));
      async function openTransfer() {
        s.tr = { people: [], q: "", note: "", group: "", sel: null, loading: true, group_name: tk.value.group };
        await loadAssignees();
      }
      async function loadAssignees() {
        s.tr.loading = true;
        try {
          const r = await api("GET", `/api/tk/tickets/${s.sel}/assignees` + (s.tr.group ? `?group=${encodeURIComponent(s.tr.group)}` : ""));
          s.tr.people = r.people; s.tr.group_name = r.group;
        } catch (e) { props.toast(e.message, "error"); }
        finally { if (s.tr) s.tr.loading = false; }
      }
      const trPeople = computed(() => {
        if (!s.tr) return [];
        const q = s.tr.q.trim().toLowerCase();
        return s.tr.people.filter((p) => !q || (p.name + " " + p.email + " " + (p.position || "")).toLowerCase().includes(q));
      });
      async function doTransfer() {
        const tr = s.tr; if (!tr || tr.sel === null) return;
        const body = { owner_id: tr.sel, note: tr.note || null };
        if (tr.group) body.group = tr.group;
        const who = tr.sel === 0 ? t("tk.tr.nobody") : (tr.people.find((p) => p.id === tr.sel) || {}).name;
        const r = await patch(body, t("tk.tr.done", { name: who }));
        if (r) s.tr = null;
      }
      async function work(mode) {
        try {
          await api("POST", `/api/tickets/${s.sel}/start`, { work_mode: mode }, { idem: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) });
          props.toast(t(mode === "blocking" ? "toast.started_blocking" : "toast.started_background"));
          await openTicket(s.sel, true);
        } catch (e) { props.toast(e.message, "error"); }
      }
      async function download(a, f) {
        try {
          const r = await fetch(`/api/tk/tickets/${s.sel}/articles/${a.id}/attachments/${f.id}`, { headers: { Authorization: `Bearer ${props.token}` } });
          if (!r.ok) throw new Error(r.status);
          const url = URL.createObjectURL(await r.blob());
          const link = document.createElement("a"); link.href = url; link.download = f.filename; document.body.appendChild(link); link.click();
          setTimeout(() => { URL.revokeObjectURL(url); link.remove(); }, 1000);
        } catch (e) { props.toast(e.message, "error"); }
      }

      // ---------------------------------------------------------- tabs
      function openTab(tab) {
        if (tab.kind === "draft") openDraft(tab);
        else openTicket(tab.ticket_id);
      }
      async function closeTab(tab) {
        if (tab.kind === "draft" && (tab.draft || {}).title && !confirm(t("tk.dr.discard_q"))) return;
        try { s.tabs = (await api("DELETE", `/api/tk/tabs/${tab.id}`)).tabs; } catch (e) { props.toast(e.message, "error"); return; }
        if (s.tabId === tab.id) { s.tabId = null; s.sel = null; s.d = null; s.dr = null; s.view = "overview"; loadList(true); }
      }
      function closeTabOf(ticketId) { const tab = s.tabs.find((x) => x.ticket_id === ticketId); if (tab) closeTab(tab); else { s.view = "overview"; s.sel = null; } }
      const tabLabel = (tab) => (tab.kind === "draft" ? ((tab.draft || {}).title || t("tk.dr.untitled")) : (tab.title || `#${tab.number}`));

      // ---------------------------------------------------------- draft of a new ticket
      function draftDefaults(customer) {
        const m = s.meta || { priorities: [], states: [], groups: [] };
        const g = m.groups.find((x) => x.name === m.default_group) || m.groups[0] || {};
        const p = m.priorities.find((x) => x.default) || m.priorities[0] || {};
        const st = m.states.find((x) => x.name === "open") || m.states.find((x) => x.category === "open") || {};
        return { title: "", customer: customer || null, group: g.name || "", owner_id: m.zammad_user_id || 0, state: st.name || "",
                 priority: p.name || "", tags: [], body: "", article_type: "phone", type: "", fields: {}, phone: "", call_id: null };
      }
      async function newDraft(customer, extra) {
        if (!s.meta) await loadMeta();
        try {
          const data = { ...draftDefaults(customer), ...(extra || {}) };
          if (data.phone) data.article_type = "phone";  // v3.14: opened from a call
          const tab = await api("POST", "/api/tk/drafts", { data });
          s.tabs.push(tab); openDraft(tab);
        } catch (e) { props.toast(e.message, "error"); }
      }
      function openDraft(tab) {
        s.view = "draft"; s.tabId = tab.id; s.sel = null; s.d = null; s.navOpen = false; s.cq = ""; s.cfound = [];
        s.dr = { ...draftDefaults(null), ...(tab.draft || {}), tags: [...((tab.draft || {}).tags || [])], fields: { ...((tab.draft || {}).fields || {}) } };
        loadOwners(s.dr.group);
        nextTick(() => { const el = document.querySelector(".dr-title"); if (el && !s.dr.title) el.focus(); });
      }
      let drTimer = null, drSkip = false;
      watch(() => s.dr, () => {
        if (!s.dr || drSkip) { drSkip = false; return; }
        s.drSaved = false; clearTimeout(drTimer);
        const id = s.tabId;
        drTimer = setTimeout(async () => {
          if (!s.dr || s.tabId !== id) return;
          s.drSaving = true;
          try {
            const tab = await api("PUT", `/api/tk/drafts/${id}`, { data: s.dr });
            s.tabs = s.tabs.map((x) => (x.id === tab.id ? tab : x)); s.drSaved = true;
          } catch { /* next change tries again */ }
          finally { s.drSaving = false; }
        }, 600);
      }, { deep: true });
      let cTimer = null;
      function findCustomer() {
        clearTimeout(cTimer);
        cTimer = setTimeout(async () => {
          const q = s.cq.trim(); if (!q) { s.cfound = []; return; }
          try { s.cfound = (await api("GET", `/api/directory?kind=customers&limit=8&q=${encodeURIComponent(q)}`)).items; } catch { s.cfound = []; }
        }, 200);
      }
      function pickCustomer(c) { s.dr.customer = { id: c.id, name: c.name, email: c.email, phone: c.phone || c.mobile, organization: c.organization }; s.cq = ""; s.cfound = []; }
      function onDraftGroup(g) { s.dr.group = g; loadOwners(g).then(() => { if (s.dr.owner_id && !(s.owners[g] || []).some((p) => p.id === s.dr.owner_id)) s.dr.owner_id = 0; }); }
      const drType = computed(() => (s.dr && (props.config.ticket_types || []).find((x) => x.name === s.dr.type)) || null);
      const drMissing = computed(() => {
        const d = s.dr; if (!d) return [];
        return ["title", "customer", "group", "state", "priority"].filter((k) => !d[k] || (k === "title" && !String(d.title).trim()));
      });
      async function createDraft(startMode) {
        if (!s.dr || s.busy) return;
        if (drMissing.value.length) { props.toast(t("tk.dr.missing", { f: drMissing.value.map((k) => t("tk.col." + k)).join(", ") }), "error"); return; }
        clearTimeout(drTimer);
        s.busy = true;
        try {
          await api("PUT", `/api/tk/drafts/${s.tabId}`, { data: s.dr });
          const r = await api("POST", `/api/tk/drafts/${s.tabId}/create`, { start_mode: startMode || null });
          props.toast(t("tk.nw.created", { n: r.ticket.number }));
          if (r.owner_dropped) props.toast(t("tk.dr.owner_dropped"), "error");
          drSkip = true; s.dr = null;
          await loadTabs(); refreshAll();
          await openTicket(r.ticket.id);
        } catch (e) { props.toast(e.message, "error"); }
        finally { s.busy = false; }
      }
      async function discardDraft() {
        const tab = s.tabs.find((x) => x.id === s.tabId);
        if (tab) { drSkip = true; await closeTab({ ...tab, draft: {} }); }
      }

      // ---------------------------------------------------------- live
      let liveTimer = null;
      function refreshAll() { loadOverviews(); if (s.view === "overview" || s.list) loadList(true); }
      function onTicketChanged(ev) {
        const ids = (ev.detail && ev.detail.ids) || [];
        clearTimeout(liveTimer);
        liveTimer = setTimeout(refreshAll, 150);
        if (s.view === "ticket" && s.sel && ids.includes(s.sel) && !s.sending && !s.busy) openTicket(s.sel, true);
      }
      function onChanged(ev) { const tp = (ev.detail && ev.detail.topics) || []; if (tp.includes("tickets")) { clearTimeout(liveTimer); liveTimer = setTimeout(refreshAll, 200); } }
      onMounted(async () => {
        window.addEventListener("agentix:ticket_changed", onTicketChanged);
        window.addEventListener("agentix:changed", onChanged);
        await loadMeta();
        if (s.err) return;
        await Promise.all([loadOverviews(), loadTabs()]);
        if (s.view === "overview") loadList();
      });
      onBeforeUnmount(() => {
        window.removeEventListener("agentix:ticket_changed", onTicketChanged);
        window.removeEventListener("agentix:changed", onChanged);
      });
      // every change of the open ticket (Update, reply, live change from Zammad) recolours its tab at once
      watch(() => s.d && s.d.ticket && [s.d.ticket.id, s.d.ticket.category, s.d.ticket.state], (v) => { if (v) noteCat(v[0], v[1], v[2]); });
      watch(() => props.openReq, (r) => { if (r && r.id) openTicket(r.id); }, { immediate: true });
      // immediate: the request is usually made together with the switch to this page (before it exists);
      // each request is handled once — coming back to the page later must not open another draft
      watch(() => props.newReq, (r) => {
        if (!r || r.n === handledNew.n) return;
        handledNew.n = r.n;
        newDraft(r.customer || null, r.phone ? { phone: r.phone, call_id: r.call_id || null } : null);
      }, { immediate: true });
      // v3.14: the caller's number opens the phone with the number typed; the operator presses Call
      const phoneOn = computed(() => !!(props.config && props.config.phone_enabled));
      function prefill(number) { if (window.zenithPrefill) window.zenithPrefill(number); }

      return { s, t, tk, phoneOn, prefill, metaGroups, metaPriorities, openStates, replyLabel, catText, isPending, loadList, pickOverview, onFilter, sortBy, goPage, pages, curOv, filtered,
        openTicket, resetForm, isDirty, ownerList, onGroup, saveForm, tagInput, addTag, tagKey, addFiles, send, onKey, patch, startTitle,
        saveTitle, takeIt, openTransfer, loadAssignees, trPeople, doTransfer, work, download, openTab, closeTab, tabLabel, tabCat, tabState, newDraft,
        findCustomer, pickCustomer, onDraftGroup, drType, drMissing, createDraft, discardDraft, refreshAll,
        linkify, avClass, initials, CH_ICON, chName, fileSize, dial, fmt: props.fmt };
    },
    template: `
<div class="tk tk2" :class="['v-' + s.view, {'nav-open': s.navOpen, 'nav-out': studio}]">
  <div v-if="s.err" class="tk-err banner">{{ s.err }}</div>
  <!-- column 1: Zammad overviews + open tickets and drafts -->
  <Teleport to="#sn-slot" defer :disabled="!studio">
  <aside class="tkn" v-if="!s.err" :aria-label="t('tk.views')">
    <div class="tkn-head"><b>{{ t('tk.views') }}</b>
      <button class="btn primary sm tk-new" @click="newDraft()" :disabled="!s.meta" data-act="new-draft"><span aria-hidden="true">＋</span> {{ t('tk.new') }}</button></div>
    <nav class="tkn-ovs">
      <button v-for="o in s.ovs" :key="o.link" :data-ov="o.link" :class="{on: s.view==='overview' && s.ov===o.link}" @click="pickOverview(o.link)">
        <span class="tkn-name">{{ o.name }}</span><b>{{ o.count }}</b></button>
      <div v-if="!s.ovs.length" class="tkn-empty">{{ t('tk.loading') }}</div>
    </nav>
    <div class="tkn-title" v-if="s.tabs.length">{{ t('tk.open_tabs') }} <span>{{ s.tabs.length }}</span></div>
    <div class="tkn-tabs">
      <div v-for="tb in s.tabs" :key="tb.id" class="tkn-tab" :class="['c-' + tabCat(tb), {on: s.tabId===tb.id && s.view!=='overview', draft: tb.kind==='draft'}]" :data-tab="tb.kind==='draft' ? 'draft' : tb.ticket_id" :data-cat="tabCat(tb)">
        <button class="tkn-open" @click="openTab(tb)" :title="tabLabel(tb) + (tabState(tb) ? ' — ' + tabState(tb) : '')">
          <i class="tkn-dot" aria-hidden="true"></i><span>{{ tabLabel(tb) }}</span><small v-if="tb.kind==='draft'">{{ t('tk.dr.badge') }}</small></button>
        <button class="tkn-x" @click.stop="closeTab(tb)" :aria-label="t('tk.close_tab')" :title="t('tk.close_tab')">✕</button>
      </div>
    </div>
  </aside>
  </Teleport>

  <section class="tk-main" v-if="!s.err">
    <!-- ======== one overview: table with filters ======== -->
    <template v-if="s.view==='overview'">
      <header class="tko-head">
        <button class="chat-back tkn-toggle" @click="s.navOpen = !s.navOpen" :aria-label="t('tk.views')"><ico name="work"></ico></button>
        <h1>{{ curOv ? curOv.name : '' }}</h1>
        <span class="tko-count" v-if="s.list">{{ filtered ? t('tk.of', {n: s.list.total, m: s.list.overview.count}) : s.list.overview.count }}</span>
        <span v-if="s.loading" class="tk-spin" aria-hidden="true"></span>
        <span class="spacer"></span>
        <button class="ch-btn" @click="loadList(true, true)" :title="t('tk.refresh')" :aria-label="t('tk.refresh')" data-act="refresh"><ico name="pulse"></ico></button>
      </header>
      <div class="tko-filters" v-if="s.list">
        <label class="chat-search tk-search"><ico name="search"></ico><input v-model="s.f.q" @input="onFilter" :placeholder="t('tk.search')" :aria-label="t('tk.search')" name="tk-q"></label>
        <select v-model="s.f.group" @change="loadList()" :aria-label="t('tk.col.group')" name="f-group"><option value="">{{ t('tk.f.group') }}</option>
          <option v-for="g in s.list.facets.groups" :key="g" :value="g">{{ g }}</option></select>
        <select v-model="s.f.state" @change="loadList()" :aria-label="t('tk.col.state')" name="f-state"><option value="">{{ t('tk.f.state') }}</option>
          <option v-for="x in s.list.facets.states" :key="x" :value="x">{{ x }}</option></select>
        <select v-model="s.f.priority" @change="loadList()" :aria-label="t('tk.col.priority')" name="f-priority"><option value="">{{ t('tk.f.priority') }}</option>
          <option v-for="x in s.list.facets.priorities" :key="x" :value="x">{{ x }}</option></select>
        <select v-model="s.f.owner" @change="loadList()" :aria-label="t('tk.col.owner')" name="f-owner"><option value="">{{ t('tk.f.owner') }}</option>
          <option value="me">{{ t('tk.f.owner_me') }}</option><option value="none">{{ t('tk.f.owner_none') }}</option>
          <option v-for="o in s.list.facets.owners" :key="o.id" :value="String(o.id)">{{ o.name }}</option></select>
        <button v-if="filtered" class="btn sm" @click="s.f = {q:'', group:'', state:'', priority:'', owner:''}; loadList()">{{ t('tk.f.reset') }}</button>
      </div>
      <div class="tko-wrap">
        <div v-if="s.list && s.list.limited" class="banner tko-limit">{{ t('tk.limited', {n: s.list.loaded, m: s.list.overview.count}) }}</div>
        <table class="tko" v-if="s.list && s.list.tickets.length">
          <thead><tr>
            <th class="c-dot"></th>
            <th v-for="c in ['title','number','customer','group','state','priority','owner','created_at']" :key="c" :class="'c-' + c">
              <button @click="sortBy(c)" :class="{on: s.sort===c}">{{ t('tk.col.' + c) }}<i v-if="s.sort===c">{{ s.dir==='asc' ? '▲' : '▼' }}</i></button></th>
          </tr></thead>
          <tbody>
            <tr v-for="x in s.list.tickets" :key="x.id" :class="'c-' + x.category" @click="openTicket(x.id)" :data-id="x.id" tabindex="0" @keydown.enter="openTicket(x.id)">
              <td class="c-dot"><i :title="x.state"></i></td>
              <td class="c-title"><a>{{ x.title }}</a></td>
              <td class="c-number">{{ x.number }}</td>
              <td class="c-customer">{{ x.customer }}<small v-if="x.organization"> ({{ x.organization }})</small></td>
              <td class="c-group">{{ x.group }}</td>
              <td class="c-state"><span class="tk-chip" :class="'c-' + x.category">{{ x.state }}</span></td>
              <td class="c-priority" :class="{hi: x.priority && x.priority.startsWith('3')}">{{ x.priority }}</td>
              <td class="c-owner">{{ x.owner || '-' }}</td>
              <td class="c-created_at">{{ fmt(x.created_at, true) }}</td>
            </tr>
          </tbody>
        </table>
        <div v-else-if="s.list && !s.loading" class="tko-none">{{ t('tk.no_records') }}</div>
        <div class="tko-pages" v-if="s.list && pages > 1">
          <button class="btn sm" :disabled="s.page<=1" @click="goPage(s.page-1)">‹</button>
          <span>{{ s.page }} / {{ pages }}</span>
          <button class="btn sm" :disabled="s.page>=pages" @click="goPage(s.page+1)">›</button>
        </div>
      </div>
    </template>

    <!-- ======== draft of a new ticket ======== -->
    <template v-if="s.view==='draft' && s.dr">
      <header class="tk-head">
        <button class="chat-back tkn-toggle" @click="s.navOpen = !s.navOpen" :aria-label="t('tk.views')"><ico name="work"></ico></button>
        <div class="tk-htext"><div class="tk-hnum"><span class="tk-chip c-new">{{ t('tk.dr.badge') }}</span>
          <small class="dr-save">{{ s.drSaving ? t('tk.dr.saving') : s.drSaved ? t('tk.dr.saved') : '' }}</small></div>
          <h1 class="tk-title">{{ s.dr.title || t('tk.dr.untitled') }}</h1></div>
      </header>
      <div class="tk-body dr-body">
        <div class="dr-main">
          <label>{{ t('tk.col.title') }} *</label>
          <input class="dr-title" v-model="s.dr.title" maxlength="250" name="dr-title" :placeholder="t('tk.dr.title_hint')">
          <label>{{ t('tk.col.customer') }} *</label>
          <div v-if="s.dr.customer" class="nw-cust"><span class="av sm" :class="avClass(s.dr.customer.id)">{{ initials(s.dr.customer.name) }}</span>
            <span><b>{{ s.dr.customer.name }}</b><small>{{ [s.dr.customer.organization, s.dr.customer.phone, s.dr.customer.email].filter(Boolean).join(' · ') }}</small></span>
            <button class="btn sm" @click="s.dr.customer=null" :aria-label="t('tk.dr.change')">✕</button></div>
          <template v-else>
            <input v-model="s.cq" @input="findCustomer" :placeholder="t('tk.nw.find')" name="dr-customer-q" autocomplete="off">
            <div class="zresults" v-if="s.cq">
              <div v-for="c in s.cfound" :key="c.id" class="zitem" @click="pickCustomer(c)">{{ c.name }} <span class="empty">{{ [c.organization, c.phone || c.mobile, c.email].filter(Boolean).join(' · ') }}</span></div>
              <div v-if="!s.cfound.length" class="zitem empty">{{ t('tk.nw.no_customer') }}</div>
            </div>
          </template>
          <label>{{ t('tk.dr.channel') }}</label>
          <div class="dr-kinds">
            <button v-for="k in ['phone','note','web']" :key="k" :class="{on: s.dr.article_type===k}" @click="s.dr.article_type=k" :data-kind="k"><ico :name="CH_ICON[k] || 'edit'"></ico>{{ t('tk.dr.kind.' + k) }}</button>
          </div>
          <label>{{ t('tk.nw.body') }}</label>
          <div v-if="s.dr.phone" class="dr-caller" data-caller>
            <ico name="phone"></ico><span>{{ t('tk.dr.caller') }}</span>
            <button v-if="phoneOn" type="button" class="num" data-act="caller-prefill" @click="prefill(s.dr.phone)" :title="t('tk.dr.call_back')">{{ s.dr.phone }}</button>
            <b v-else class="mono">{{ s.dr.phone }}</b>
            <small v-if="s.dr.call_id">{{ t('tk.dr.from_call') }}</small>
          </div>
          <textarea v-model="s.dr.body" rows="8" name="dr-body" :placeholder="t('tk.dr.body_hint')"></textarea>
          <template v-if="(config.ticket_types || []).length">
            <label>{{ t('tk.nw.type') }}</label>
            <select v-model="s.dr.type"><option value="">—</option><option v-for="tt in config.ticket_types" :key="tt.name" :value="tt.name">{{ tt.name }}</option></select>
            <template v-if="drType"><div v-for="f in drType.required_fields" :key="f.name">
              <label>{{ f.label || f.name }} *</label>
              <select v-if="f.type==='select'" v-model="s.dr.fields[f.name]"><option v-for="o in f.options || []" :key="o" :value="o">{{ o }}</option></select>
              <input v-else v-model="s.dr.fields[f.name]"></div></template>
          </template>
        </div>
        <aside class="tk-side tk-form">
          <div class="tf-title">{{ t('tk.ticket') }}</div>
          <label>{{ t('tk.col.group') }} *</label>
          <select :value="s.dr.group" @change="onDraftGroup($event.target.value)" data-f="group"><option value="" disabled>-</option>
            <option v-for="g in metaGroups" :key="g.id" :value="g.name">{{ g.name }}</option></select>
          <label>{{ t('tk.col.owner') }}</label>
          <select v-model.number="s.dr.owner_id" data-f="owner"><option :value="0">-</option>
            <option v-for="p in ownerList(s.dr.group)" :key="p.id" :value="p.id">{{ p.name }}</option></select>
          <label>{{ t('tk.col.state') }} *</label>
          <select v-model="s.dr.state" data-f="state"><option v-for="st in openStates" :key="st.id" :value="st.name">{{ st.name }}</option></select>
          <label>{{ t('tk.col.priority') }} *</label>
          <select v-model="s.dr.priority" data-f="priority"><option v-for="p in metaPriorities" :key="p.id" :value="p.name">{{ p.name }}</option></select>
          <label>{{ t('tk.tags') }}</label>
          <div class="tf-tags" @click="$event.currentTarget.querySelector('input').focus()">
            <span v-for="(g, i) in s.dr.tags" :key="g" class="tf-tag">{{ g }}<button @click.stop="s.dr.tags.splice(i, 1)" aria-label="✕">✕</button></span>
            <input v-model="s.tagQ" @input="tagInput(s.dr)" @keydown="tagKey(s.dr, $event)" @blur="s.tagQ && addTag(s.dr)" :placeholder="t('tk.add_tag')" name="dr-tag">
          </div>
          <div v-if="s.tagHints.length" class="tf-hints"><button v-for="h in s.tagHints" :key="h" @mousedown.prevent="addTag(s.dr, h)">{{ h }}</button></div>
        </aside>
      </div>
      <footer class="tk-bar">
        <button class="linkish" @click="discardDraft" data-act="discard">{{ t('tk.dr.discard') }}</button>
        <span class="spacer"></span>
        <span class="tk-bar-hint" v-if="drMissing.length">{{ t('tk.dr.missing', {f: drMissing.map(k => t('tk.col.' + k)).join(', ')}) }}</span>
        <button class="btn" :disabled="s.busy || drMissing.length > 0" @click="createDraft('blocking')" data-act="create-start">{{ t('tk.nw.create_start') }}</button>
        <button class="btn go" :disabled="s.busy || drMissing.length > 0" @click="createDraft(null)" data-act="create">{{ t('tk.nw.create') }}</button>
      </footer>
    </template>

    <!-- ======== one ticket ======== -->
    <template v-if="s.view==='ticket'">
      <header class="tk-head">
        <button class="chat-back tkn-toggle" @click="s.navOpen = !s.navOpen" :aria-label="t('tk.views')"><ico name="work"></ico></button>
        <div class="tk-htext" v-if="tk">
          <div class="tk-hnum">#{{ tk.number }} <span class="tk-chip" :class="'c-' + tk.category">{{ tk.state }}</span>
            <span v-if="s.d.session" class="tag" :class="s.d.session.work_mode">{{ s.d.session.work_mode==='blocking' ? t('tk.in_work') : t('tk.in_bg') }}</span>
            <span class="tk-created">{{ t('tk.created') }} {{ fmt(tk.created_at, true) }}</span></div>
          <input v-if="s.editTitle" class="tk-title-input" v-model="s.title" @keydown.enter.prevent="saveTitle" @keydown.esc="s.editTitle=false" @blur="saveTitle" maxlength="250">
          <h1 v-else class="tk-title" :title="t('tk.edit_title')" @click="startTitle">{{ tk.title }}</h1>
        </div>
        <span class="spacer"></span>
        <button v-if="s.d" class="ch-btn tk-side-btn" :class="{on: s.side}" @click="s.side = !s.side" :title="t('tk.props')" :aria-label="t('tk.props')" data-act="props"><ico name="sidebar"></ico></button>
        <a v-if="s.d" class="ch-btn" :href="s.d.zammad_url" target="_blank" rel="noopener" :title="t('tk.open_zammad')" :aria-label="t('tk.open_zammad')"><ico name="ext"></ico></a>
      </header>
      <div v-if="s.dLoading && !s.d" class="tk-loading">{{ t('tk.loading') }}</div>
      <div v-if="s.d && s.form" class="tk-body" :class="{flash: s.flash, 'side-open': s.side}">
        <div class="tk-conv">
          <div class="tk-thread">
            <div v-if="!s.d.articles.length" class="chat-none">{{ t('tk.empty_thread') }}</div>
            <article v-for="a in s.d.articles" :key="a.id" class="tk-art" :class="[a.sender === 'customer' ? 'from-cust' : 'from-agent', {internal: a.internal}]" :data-type="a.type">
              <div class="ta-head">
                <span class="av sm" :class="avClass(a.author_id)">{{ initials(a.author) }}</span>
                <div class="ta-who"><b>{{ a.author }}</b>
                  <small><ico :name="CH_ICON[a.type] || 'chat'"></ico>{{ chName(a.type) }}<template v-if="a.to"> → {{ a.to }}</template></small></div>
                <span v-if="a.internal" class="tag ta-int">{{ t('tk.internal') }}</span>
                <time>{{ fmt(a.created_at, true) }}</time>
              </div>
              <div class="ta-body"><template v-for="(p, i) in linkify(a.body)" :key="i"><a v-if="p.url" :href="p.url" target="_blank" rel="noopener noreferrer">{{ p.url }}</a><template v-else>{{ p.text }}</template></template></div>
              <div v-if="a.attachments.length" class="ta-files">
                <button v-for="f in a.attachments" :key="f.id" class="ta-file" @click="download(a, f)" :title="t('tk.download')"><ico name="copy"></ico>{{ f.filename }} <small>{{ fileSize(f.size) }}</small></button>
              </div>
            </article>
          </div>
          <div class="tk-compose" :class="'k-' + s.kind">
            <div class="tc-modes">
              <button :class="{on: s.kind==='note'}" @click="s.kind='note'" data-kind="note"><ico name="edit"></ico>{{ t('tk.note') }}</button>
              <button :class="{on: s.kind==='reply'}" @click="s.kind='reply'" data-kind="reply"><ico :name="CH_ICON[s.d.reply.type] || 'send'"></ico>{{ t('tk.reply') }}</button>
              <span class="tc-target" v-if="s.kind==='reply'">{{ replyLabel }}</span>
            </div>
            <textarea v-model="s.text" @keydown="onKey" :placeholder="s.kind==='note' ? t('tk.placeholder.note') : t('tk.placeholder.reply')" rows="3"></textarea>
            <div v-if="s.files.length" class="tc-files"><span v-for="(f, i) in s.files" :key="i" class="ta-file">{{ f.filename }} <small>{{ fileSize(f.size) }}</small><button @click="s.files.splice(i, 1)" aria-label="✕">✕</button></span></div>
            <div class="tc-bar">
              <label class="btn sm tc-attach" :title="t('tk.attach')"><ico name="copy"></ico><span>{{ t('tk.attach') }}</span><input type="file" multiple @change="addFiles" hidden></label>
              <select v-model="s.sendState" class="tc-state" :aria-label="t('tk.and_state')"><option value="">{{ t('tk.keep_state') }}</option>
                <option v-for="st in openStates" :key="st.id" :value="st.name">→ {{ st.name }}</option></select>
              <input v-if="s.sendState && isPending(s.sendState)" type="number" min="1" max="365" v-model="s.pendingDays" class="tc-days" :title="t('tk.days')">
              <span class="spacer"></span>
              <small class="tc-hint">{{ t('tk.send_hint') }}</small>
              <button class="btn primary tc-send" :disabled="s.sending || (!s.text.trim() && !s.files.length)" @click="send"><ico name="send"></ico>{{ t('tk.send') }}</button>
            </div>
          </div>
        </div>
        <aside class="tk-side tk-form">
          <div class="tf-title">{{ t('tk.ticket') }}</div>
          <label>{{ t('tk.col.group') }} *</label>
          <select :value="s.form.group" @change="onGroup($event.target.value)" :disabled="s.busy" data-f="group">
            <option v-for="g in metaGroups" :key="g.id" :value="g.name">{{ g.name }}</option>
            <option v-if="!metaGroups.some(x => x.name === s.form.group)" :value="s.form.group">{{ s.form.group }}</option></select>
          <label>{{ t('tk.col.owner') }}</label>
          <select v-model.number="s.form.owner_id" :disabled="s.busy" data-f="owner"><option :value="0">-</option>
            <option v-for="p in ownerList(s.form.group, tk.owner_id, tk.owner_name)" :key="p.id" :value="p.id">{{ p.name }}</option></select>
          <label>{{ t('tk.col.state') }} *</label>
          <select v-model="s.form.state" :disabled="s.busy" data-f="state">
            <option v-for="st in openStates" :key="st.id" :value="st.name">{{ st.name }}</option>
            <option v-if="!openStates.some(x => x.name === s.form.state)" :value="s.form.state">{{ s.form.state }}</option></select>
          <div v-if="tk.category==='pending' && tk.pending_time" class="hint">{{ t('tk.pending_until') }} {{ fmt(tk.pending_time, true) }}</div>
          <label>{{ t('tk.col.priority') }} *</label>
          <select v-model="s.form.priority" :disabled="s.busy" data-f="priority">
            <option v-for="p in metaPriorities" :key="p.id" :value="p.name">{{ p.name }}</option></select>
          <label>{{ t('tk.tags') }}</label>
          <div class="tf-tags" @click="$event.currentTarget.querySelector('input').focus()">
            <span v-for="(g, i) in s.form.tags" :key="g" class="tf-tag">{{ g }}<button @click.stop="s.form.tags.splice(i, 1)" aria-label="✕">✕</button></span>
            <input v-model="s.tagQ" @input="tagInput(s.form)" @keydown="tagKey(s.form, $event)" @blur="s.tagQ && addTag(s.form)" :placeholder="t('tk.add_tag')" name="tk-tag">
          </div>
          <div v-if="s.tagHints.length" class="tf-hints"><button v-for="h in s.tagHints" :key="h" @mousedown.prevent="addTag(s.form, h)">{{ h }}</button></div>
          <div class="ts-actions">
            <button class="btn sm" @click="openTransfer" :disabled="s.busy" data-act="transfer">{{ t('tk.transfer') }}</button>
            <button v-if="!tk.mine && tk.category!=='closed'" class="btn sm" @click="takeIt" :disabled="s.busy" data-act="take">{{ t('tk.take') }}</button>
          </div>
          <div class="ts-sec" v-if="tk.category!=='closed' && !s.d.session && (tk.mine || !tk.owner_id)">
            <label>{{ t('tk.work') }}</label>
            <div class="ts-actions"><button class="btn primary sm" @click="work('blocking')" data-act="start">{{ t('tk.start') }}</button>
              <button class="btn sm" @click="work('background')">{{ t('tk.background') }}</button></div>
          </div>
          <div class="ts-sec ts-cust">
            <label>{{ t('tk.customer') }}</label>
            <button class="ts-person" @click="$emit('open-customer', tk.customer.id)">
              <span class="av sm" :class="avClass(tk.customer.id)">{{ initials(tk.customer.name) }}</span>
              <span><b>{{ tk.customer.name }}</b><small v-if="tk.customer.organization">{{ tk.customer.organization }}</small></span></button>
            <div v-if="tk.customer.phone" class="ts-line"><ico name="phone"></ico>{{ tk.customer.phone }}
              <button class="btn sm dial-btn" @click="dial(tk.customer.phone, tk.customer.name)" data-act="dial-customer">{{ t('ph.call') }}</button></div>
            <div v-if="tk.customer.email" class="ts-line"><ico name="at"></ico><a :href="'mailto:' + tk.customer.email">{{ tk.customer.email }}</a></div>
            <div v-if="tk.customer.note" class="ts-note">{{ tk.customer.note }}</div>
          </div>
          <div class="ts-sec ts-dates">
            <div><span>{{ t('tk.created') }}</span><b>{{ fmt(tk.created_at, true) }}</b></div>
            <div><span>{{ t('tk.updated') }}</span><b>{{ fmt(tk.updated_at, true) }}</b></div>
          </div>
        </aside>
      </div>
      <footer class="tk-bar" v-if="s.d && s.form">
        <button class="linkish" v-if="isDirty" @click="resetForm" data-act="revert">{{ t('tk.revert') }}</button>
        <span class="spacer"></span>
        <span class="tk-bar-hint" v-if="isDirty">{{ t('tk.unsaved') }}</span>
        <button class="btn primary" :class="{pulse: isDirty}" :disabled="s.busy || !isDirty" @click="saveForm" data-act="update">{{ t('tk.update') }}</button>
      </footer>
    </template>
  </section>

  <!-- transfer -->
  <div class="overlay" v-if="s.tr" @click.self="s.tr=null">
    <div class="panel modal tk-transfer" role="dialog" aria-modal="true">
      <h3>{{ t('tk.tr.title', {n: tk.number}) }}</h3>
      <div class="hint">{{ t('tk.tr.hint') }}</div>
      <div class="row">
        <div><label>{{ t('tk.tr.group') }}</label>
          <select v-model="s.tr.group" @change="loadAssignees"><option value="">{{ t('tk.tr.keep_group') }} ({{ tk.group }})</option>
            <option v-for="g in metaGroups.filter(x => x.name !== tk.group)" :key="g.id" :value="g.name">{{ g.name }}</option></select></div>
      </div>
      <label class="chat-search tr-search"><ico name="search"></ico><input v-model="s.tr.q" :placeholder="t('tk.tr.search')"></label>
      <div class="tr-list">
        <button class="tr-person" :class="{on: s.tr.sel===0}" @click="s.tr.sel=0"><span class="av sm av-5">—</span><span><b>{{ t('tk.tr.nobody') }}</b></span></button>
        <button v-for="p in trPeople" :key="p.id" class="tr-person" :class="{on: s.tr.sel===p.id}" @click="s.tr.sel=p.id" :data-person="p.id">
          <span class="av sm" :class="avClass(p.id)">{{ initials(p.name) }}<i v-if="p.state" class="tr-dot" :class="'st-' + p.state"></i></span>
          <span class="tr-text"><b>{{ p.name }}<em v-if="p.me"> ({{ t('tk.tr.me') }})</em></b><small>{{ [p.position, p.state ? stateText(p.state) : p.email].filter(Boolean).join(' · ') }}</small></span>
          <span v-if="p.owner" class="tag">{{ t('tk.tr.owner') }}</span>
        </button>
        <div v-if="!s.tr.loading && !trPeople.length" class="empty">{{ t('tk.tr.none') }}</div>
      </div>
      <label>{{ t('tk.tr.note') }}</label><textarea v-model="s.tr.note" rows="2"></textarea>
      <div class="footer"><button class="btn" @click="s.tr=null">{{ t('modal.cancel') }}</button>
        <button class="btn primary" :disabled="s.busy || s.tr.sel===null" @click="doTransfer" data-act="do-transfer">{{ t('tk.tr.go') }}</button></div>
    </div>
  </div>
</div>`,
  };

  // ==================================================================== <contacts-page>
  const ContactsPage = {
    props: ["api", "t", "toast", "fmt", "me", "openReq"],
    emits: ["open-ticket", "new-ticket"],
    setup(props) {
      const t = props.t, api = props.api;
      const s = reactive({ kind: "customers", q: "", items: [], total: 0, counts: { customers: 0, staff: 0 }, synced_at: null, error: "",
                           loading: false, sel: null, card: null, syncing: false });
      let seq = 0;
      async function load(keep) {
        const my = ++seq; if (!keep) s.loading = true;
        try {
          const r = await api("GET", `/api/directory?kind=${s.kind}&limit=${keep ? Math.max(50, s.items.length) : 50}&q=${encodeURIComponent(s.q)}`);
          if (my !== seq) return;
          s.items = r.items; s.total = r.total; s.counts = r.counts; s.synced_at = r.synced_at; s.error = r.error || "";
        } catch (e) { if (my === seq) props.toast(e.message, "error"); }
        finally { if (my === seq) s.loading = false; }
      }
      async function more() {
        try { const r = await api("GET", `/api/directory?kind=${s.kind}&offset=${s.items.length}&limit=50&q=${encodeURIComponent(s.q)}`); s.items = s.items.concat(r.items); }
        catch (e) { props.toast(e.message, "error"); }
      }
      let qt = null;
      const onSearch = () => { clearTimeout(qt); qt = setTimeout(() => load(), 200); };
      function setKind(k) { s.kind = k; s.sel = null; s.card = null; load(); }
      async function open(id) {
        s.sel = id;
        try { s.card = await api("GET", `/api/directory/${id}`); } catch (e) { props.toast(e.message, "error"); }
      }
      async function sync() {
        s.syncing = true;
        try { await api("POST", "/api/directory/sync"); await load(true); } catch (e) { props.toast(e.message, "error"); }
        finally { s.syncing = false; }
      }
      let lt = null;
      function onChanged(ev) {
        const tp = (ev.detail && ev.detail.topics) || [];
        if (tp.includes("directory")) { clearTimeout(lt); lt = setTimeout(() => { load(true); if (s.sel) open(s.sel); }, 150); }
      }
      function onTicket() { if (s.sel && s.card) { clearTimeout(lt); lt = setTimeout(() => open(s.sel), 200); } }
      onMounted(() => { window.addEventListener("agentix:changed", onChanged); window.addEventListener("agentix:ticket_changed", onTicket); load(); });
      onBeforeUnmount(() => { window.removeEventListener("agentix:changed", onChanged); window.removeEventListener("agentix:ticket_changed", onTicket); });
      watch(() => props.openReq, (r) => { if (r && r.id) { if (r.kind && r.kind !== s.kind) { s.kind = r.kind; load(); } open(r.id); } }, { immediate: true });
      const u = computed(() => (s.card ? s.card.user : null));
      return { s, t, u, load, more, onSearch, setKind, open, sync, avClass, initials, dial, fmt: props.fmt };
    },
    template: `
<div class="tk ct" :class="{'has-sel': s.sel}">
  <section class="tk-list">
    <div class="tk-views" role="tablist">
      <button role="tab" data-kind="customers" :class="{on: s.kind==='customers'}" @click="setKind('customers')">{{ t('ct.customers') }} <b>{{ s.counts.customers }}</b></button>
      <button role="tab" data-kind="staff" :class="{on: s.kind==='staff'}" @click="setKind('staff')">{{ t('ct.staff') }} <b>{{ s.counts.staff }}</b></button>
    </div>
    <div class="tk-tools"><label class="chat-search tk-search"><ico name="search"></ico><input v-model="s.q" @input="onSearch" :placeholder="t('ct.search')" :aria-label="t('ct.search')"></label></div>
    <div class="ct-sync">
      <span>{{ s.synced_at ? t('ct.synced', {t: fmt(s.synced_at, true)}) : t('ct.never') }}</span>
      <button class="btn sm" @click="sync" :disabled="s.syncing" data-act="sync">{{ s.syncing ? t('ct.syncing') : t('ct.sync') }}</button>
    </div>
    <div v-if="s.error" class="banner error ct-errline">Zammad: {{ s.error }}</div>
    <div class="tk-items">
      <transition-group name="cl">
        <button v-for="p in s.items" :key="p.id" class="chat-item ct-row" :class="{on: s.sel===p.id, off: !p.active}" @click="open(p.id)" :data-id="p.id">
          <span class="av sm" :class="avClass(p.id)">{{ initials(p.name) }}</span>
          <div class="ci-text"><div class="ci-top"><span class="ci-name">{{ p.name }}</span></div>
            <div class="ci-bottom"><span class="ci-prev">{{ [p.organization, p.phone || p.mobile, p.email].filter(Boolean).join(' · ') }}</span></div></div>
        </button>
      </transition-group>
      <div v-if="!s.loading && !s.items.length" class="chat-none">{{ t('ct.none') }}</div>
      <button v-if="s.items.length < s.total" class="btn sm tk-more" @click="more">{{ t('ct.more') }} ({{ s.total - s.items.length }})</button>
    </div>
    <div class="ct-ro">{{ t('ct.readonly') }}</div>
  </section>
  <section class="tk-main ct-main">
    <div v-if="!s.sel || !u" class="chat-hello tk-hello"><div><ico name="users"></ico><b>{{ t('ct.pick') }}</b><p>{{ t('ct.readonly') }}</p></div></div>
    <template v-else>
      <header class="tk-head"><button class="chat-back" @click="s.sel=null" :aria-label="t('chat.back')"><ico name="back"></ico></button><span class="spacer"></span>
        <button v-if="u.is_customer" class="btn primary sm" @click="$emit('new-ticket', u)" data-act="new-ticket"><span aria-hidden="true">＋</span> {{ t('ct.new_ticket') }}</button></header>
      <div class="ct-card">
        <div class="ct-hero"><span class="av xl" :class="avClass(u.id)">{{ initials(u.name) }}</span>
          <div><h1>{{ u.name }}</h1><div class="hint">{{ u.organization }}<span v-if="!u.active" class="tag off">{{ t('ct.inactive') }}</span></div></div></div>
        <div class="ct-fields">
          <div v-if="u.email"><span>{{ t('ct.email') }}</span><a :href="'mailto:' + u.email">{{ u.email }}</a></div>
          <div v-if="u.phone"><span>{{ t('ct.phone') }}</span><b class="mono">{{ u.phone }} <button class="btn sm dial-btn" @click="dial(u.phone, u.name)" data-act="dial-phone">{{ t('ph.call') }}</button></b></div>
          <div v-if="u.mobile"><span>{{ t('ct.mobile') }}</span><b class="mono">{{ u.mobile }} <button class="btn sm dial-btn" @click="dial(u.mobile, u.name)" data-act="dial-mobile">{{ t('ph.call') }}</button></b></div>
          <div v-if="u.organization"><span>{{ t('ct.org') }}</span><b>{{ u.organization }}</b></div>
          <div v-if="u.roles.length"><span>{{ t('ct.roles') }}</span><b>{{ u.roles.join(', ') }}</b></div>
          <div v-if="u.is_agent && Object.keys(u.groups).length"><span>{{ t('ct.groups') }}</span><b>{{ Object.entries(u.groups).map(([g, a]) => g + ' (' + a.join(', ') + ')').join('; ') }}</b></div>
          <div v-if="u.created_at"><span>{{ t('ct.since') }}</span><b>{{ fmt(u.created_at, true) }}</b></div>
          <div v-if="u.note" class="ct-note"><span>{{ t('ct.note') }}</span><p>{{ u.note }}</p></div>
        </div>
        <h2 class="ct-h">{{ t('ct.tickets') }} <span class="count">{{ s.card.tickets.length }}</span></h2>
        <div v-if="s.card.error" class="hint">{{ s.card.error }}</div>
        <div v-if="!s.card.tickets.length" class="empty">{{ t('ct.no_tickets') }}</div>
        <button v-for="x in s.card.tickets" :key="x.id" class="tk-row" :class="'c-' + x.category" @click="$emit('open-ticket', x.id)">
          <div class="tr-top"><span class="tr-num">#{{ x.number }}</span><span class="tr-title">{{ x.title }}</span><time>{{ fmt(x.updated_at, true) }}</time></div>
          <div class="tr-bot"><span class="tk-chip" :class="'c-' + x.category">{{ x.state }}</span><span class="tr-owner">{{ x.owner_name || t('tk.unassigned') }}</span></div>
        </button>
      </div>
    </template>
  </section>
</div>`,
  };

  return { i18n, TicketsPage, ContactsPage };
})();
