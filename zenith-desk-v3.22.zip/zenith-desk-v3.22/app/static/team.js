/* Zenith Desk v3.18 — the team right now (manager panel): queues, the call feed, one person's day, the wallboard.
   The live board itself is part of the manager panel in app.js and uses the helpers below. */
window.ZenithTeam = (() => {
  const { reactive, computed, watch, onMounted, onBeforeUnmount } = Vue;

  const i18n = {
    en: {
      "tm.title": "Team now", "tm.f.all": "All", "tm.f.call": "On a call", "tm.f.free": "Free", "tm.f.busy": "Busy",
      "tm.f.break": "Break", "tm.f.offline": "Offline", "tm.sort": "Sort", "tm.sort.level": "By level", "tm.sort.name": "By name",
      "tm.sort.long": "Longest in status", "tm.wall": "Wallboard", "tm.wall_t": "Full-screen view for a TV in the office",
      "tm.col.call": "Call", "tm.col.work": "Working on", "tm.col.status": "Status", "tm.for": "for {t}",
      "tm.ph.ringing": "Ringing", "tm.ph.dialing": "Calling out", "tm.ph.talking": "Talking", "tm.ph.hold": "On hold",
      "tm.ph.wrap_up": "Wrap-up", "tm.in": "incoming", "tm.out": "outgoing", "tm.queue": "queue {q}", "tm.no_call": "—",
      "tm.open_ticket": "Open the ticket", "tm.chat": "Write in the messenger", "tm.day": "His / her day",
      "tm.none": "Nobody matches the filter.",
      // queues
      "tm.q.title": "Queues now", "tm.q.waiting": "waiting", "tm.q.longest": "longest wait", "tm.q.free": "free operators",
      "tm.q.talking": "talking", "tm.q.today": "Today", "tm.q.offered": "offered", "tm.q.answered": "answered", "tm.q.missed": "missed",
      "tm.q.sl": "service level", "tm.q.asa": "avg. answer", "tm.q.nobody": "Nobody is waiting", "tm.q.none": "No queues yet",
      "tm.q.unmanaged": "not managed by Zenith Desk",
      // feed
      "tm.feed.title": "Calls of the team", "tm.feed.all": "All", "tm.feed.in": "Incoming", "tm.feed.out": "Outgoing",
      "tm.feed.missed": "Missed", "tm.feed.none": "No calls yet.", "tm.feed.rang": "also rang: {names}",
      "tm.r.answered": "answered", "tm.r.talking": "talking", "tm.r.waiting": "waiting", "tm.r.abandoned": "hung up while waiting",
      "tm.r.unanswered": "nobody answered", "tm.r.connected": "connected", "tm.r.no_answer": "no answer", "tm.r.dialing": "calling",
      "tm.r.missed": "not answered", "tm.r.colleague": "a colleague answered", "tm.r.ringing": "ringing",
      "tm.wait": "wait {t}", "tm.talk": "talk {t}",
      // day card
      "tm.d.title": "Day of {name}", "tm.d.today": "Today", "tm.d.prev": "Previous day", "tm.d.next": "Next day",
      "tm.d.timeline": "Timeline", "tm.d.calls_lane": "calls", "tm.d.states_lane": "status",
      "tm.d.in": "Incoming answered", "tm.d.rang": "of {n} rang", "tm.d.missed": "Not answered (RONA)", "tm.d.out": "Outgoing",
      "tm.d.connected": "{n} connected", "tm.d.talk": "Talk time", "tm.d.aht": "avg. {t}", "tm.d.break": "Break time",
      "tm.d.logged": "Signed in", "tm.d.tickets": "Tickets finished", "tm.d.started": "{n} started", "tm.d.occupancy": "Occupancy",
      "tm.d.first": "Came in", "tm.d.last": "Left", "tm.d.still": "still working", "tm.d.calls": "Calls of the day",
      "tm.d.no_calls": "No calls this day.", "tm.d.no_activity": "No activity this day.", "tm.d.when": "Time", "tm.d.number": "Number",
      "tm.d.result": "Result", "tm.d.length": "Length", "tm.d.close": "Close",
      "tm.st.ready": "Ready", "tm.st.busy_task": "Busy with a task", "tm.st.wrap_up": "Wrap-up", "tm.st.break": "Break", "tm.st.offline": "Offline",
      // wallboard
      "tm.w.waiting": "Waiting now", "tm.w.longest": "Longest wait", "tm.w.talking": "Talking", "tm.w.free": "Free",
      "tm.w.break": "On break", "tm.w.answered": "Answered today", "tm.w.missed": "Missed today", "tm.w.sl": "Service level",
      "tm.w.target": "target {p}%", "tm.w.asa": "Avg. answer", "tm.w.team": "Team", "tm.w.exit": "Exit", "tm.w.full": "Full screen",
      "tm.w.calls": "Last calls", "tm.w.updated": "Live",
    },
    ru: {
      "tm.title": "Команда сейчас", "tm.f.all": "Все", "tm.f.call": "На звонке", "tm.f.free": "Свободны", "tm.f.busy": "Заняты",
      "tm.f.break": "Перерыв", "tm.f.offline": "Не в сети", "tm.sort": "Сортировка", "tm.sort.level": "По уровню", "tm.sort.name": "По имени",
      "tm.sort.long": "Дольше всех в статусе", "tm.wall": "Табло", "tm.wall_t": "Полноэкранный вид для телевизора в офисе",
      "tm.col.call": "Звонок", "tm.col.work": "Работает над", "tm.col.status": "Статус", "tm.for": "уже {t}",
      "tm.ph.ringing": "Звонят ему", "tm.ph.dialing": "Звонит сам", "tm.ph.talking": "Разговаривает", "tm.ph.hold": "На удержании",
      "tm.ph.wrap_up": "Постобработка", "tm.in": "входящий", "tm.out": "исходящий", "tm.queue": "очередь {q}", "tm.no_call": "—",
      "tm.open_ticket": "Открыть тикет", "tm.chat": "Написать в мессенджере", "tm.day": "Его / её день",
      "tm.none": "Никого по этому фильтру.",
      "tm.q.title": "Очереди сейчас", "tm.q.waiting": "ждут", "tm.q.longest": "дольше всех", "tm.q.free": "свободных операторов",
      "tm.q.talking": "говорят", "tm.q.today": "Сегодня", "tm.q.offered": "поступило", "tm.q.answered": "отвечено", "tm.q.missed": "пропущено",
      "tm.q.sl": "уровень сервиса", "tm.q.asa": "ср. ответ", "tm.q.nobody": "Никто не ждёт", "tm.q.none": "Очередей пока нет",
      "tm.q.unmanaged": "не управляется Zenith Desk",
      "tm.feed.title": "Звонки команды", "tm.feed.all": "Все", "tm.feed.in": "Входящие", "tm.feed.out": "Исходящие",
      "tm.feed.missed": "Пропущенные", "tm.feed.none": "Звонков пока нет.", "tm.feed.rang": "звонило также: {names}",
      "tm.r.answered": "отвечен", "tm.r.talking": "идёт разговор", "tm.r.waiting": "ждёт", "tm.r.abandoned": "положил трубку в ожидании",
      "tm.r.unanswered": "никто не ответил", "tm.r.connected": "дозвонился", "tm.r.no_answer": "не ответили", "tm.r.dialing": "звонит",
      "tm.r.missed": "не ответил", "tm.r.colleague": "ответил коллега", "tm.r.ringing": "звонит",
      "tm.wait": "ожидание {t}", "tm.talk": "разговор {t}",
      "tm.d.title": "День: {name}", "tm.d.today": "Сегодня", "tm.d.prev": "Предыдущий день", "tm.d.next": "Следующий день",
      "tm.d.timeline": "Хронология", "tm.d.calls_lane": "звонки", "tm.d.states_lane": "статус",
      "tm.d.in": "Входящие отвечены", "tm.d.rang": "из {n} поступивших", "tm.d.missed": "Не ответил (RONA)", "tm.d.out": "Исходящие",
      "tm.d.connected": "{n} дозвонился", "tm.d.talk": "Время разговоров", "tm.d.aht": "в среднем {t}", "tm.d.break": "Перерывы",
      "tm.d.logged": "В системе", "tm.d.tickets": "Тикетов завершено", "tm.d.started": "начато {n}", "tm.d.occupancy": "Занятость",
      "tm.d.first": "Пришёл", "tm.d.last": "Ушёл", "tm.d.still": "ещё работает", "tm.d.calls": "Звонки за день",
      "tm.d.no_calls": "Звонков в этот день нет.", "tm.d.no_activity": "В этот день активности не было.", "tm.d.when": "Время",
      "tm.d.number": "Номер", "tm.d.result": "Итог", "tm.d.length": "Длительность", "tm.d.close": "Закрыть",
      "tm.st.ready": "Готов", "tm.st.busy_task": "Занят задачей", "tm.st.wrap_up": "Постобработка", "tm.st.break": "Перерыв", "tm.st.offline": "Не в сети",
      "tm.w.waiting": "Ждут сейчас", "tm.w.longest": "Дольше всех ждёт", "tm.w.talking": "Разговаривают", "tm.w.free": "Свободны",
      "tm.w.break": "На перерыве", "tm.w.answered": "Отвечено сегодня", "tm.w.missed": "Пропущено сегодня", "tm.w.sl": "Уровень сервиса",
      "tm.w.target": "цель {p}%", "tm.w.asa": "Ср. время ответа", "tm.w.team": "Команда", "tm.w.exit": "Выход", "tm.w.full": "Во весь экран",
      "tm.w.calls": "Последние звонки", "tm.w.updated": "Онлайн",
    },
  };

  // ------------------------------------------------------------ one clock for every timer on the page
  const tick = reactive({ now: Date.now(), skew: 0 });  // skew: server time − this computer's time
  setInterval(() => { tick.now = Date.now(); }, 1000);
  const pad = (n) => String(n).padStart(2, "0");
  function elapsed(iso) {
    if (!iso) return 0;
    return Math.max(0, Math.floor((tick.now + tick.skew - new Date(iso).getTime()) / 1000));
  }
  function clock(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), x = sec % 60;
    return h ? `${h}:${pad(m)}:${pad(x)}` : `${m}:${pad(x)}`;
  }
  /** "17 min" / "2 h 05 min" for how long somebody is in his status */
  function span(sec, t) {
    sec = Math.max(0, Math.floor(sec || 0));
    if (sec < 60) return `< 1 ${t("dur.min")}`;
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
    return h ? `${h} ${t("dur.h")} ${pad(m)} ${t("dur.min")}` : `${m} ${t("dur.min")}`;
  }
  const PHASE_ICON = { ringing: "bell", dialing: "arrout", talking: "phone", hold: "pause", wrap_up: "edit" };
  const pct = (x) => (x == null ? "—" : `${Math.round(x * 100)}%`);
  const hmIn = (iso, tz) => { if (!iso) return ""; try { return new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(iso)); } catch { return ""; } };
  const dayIn = (d, tz) => { try { return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(d); } catch { return d.toISOString().slice(0, 10); } };
  const addDays = (ymd, n) => { const d = new Date(ymd + "T12:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  const MISSED = ["abandoned", "unanswered", "no_answer", "missed"];

  // ------------------------------------------------------------ queues now
  const TeamQueues = {
    props: { data: Object, t: Function },
    setup(props) {
      const longest = (q) => (q.callers.length ? elapsed(q.callers[0].joined_at) : 0);
      return { t: props.t, clock, pct, elapsed, longest };
    },
    template: `
<section class="panel tm-queues" data-team="queues">
  <h2>{{ t('tm.q.title') }} <span class="count" v-if="data">{{ data.waiting_total }} {{ t('tm.q.waiting') }}</span></h2>
  <div class="body">
    <div v-if="!data || !data.queues.length" class="empty">{{ t('tm.q.none') }}</div>
    <div v-for="q in (data ? data.queues : [])" :key="q.queue" class="tmq" :class="{hot: q.waiting > 0}" :data-queue="q.queue">
      <div class="tmq-head">
        <b class="tmq-name">{{ q.queue }}</b>
        <span v-if="!q.managed" class="empty tmq-un">{{ t('tm.q.unmanaged') }}</span>
        <span class="grow"></span>
        <span class="tmq-big" data-waiting><b>{{ q.waiting }}</b> {{ t('tm.q.waiting') }}</span>
      </div>
      <div class="tmq-row">
        <span><small>{{ t('tm.q.longest') }}</small><b class="mono" :class="{warn: longest(q) >= 60}">{{ q.waiting ? clock(longest(q)) : '—' }}</b></span>
        <span><small>{{ t('tm.q.free') }}</small><b>{{ q.free == null ? '—' : q.free }}</b></span>
        <span><small>{{ t('tm.q.talking') }}</small><b>{{ q.talking }}</b></span>
      </div>
      <div v-if="q.callers.length" class="tmq-callers">
        <div v-for="c in q.callers" :key="c.joined_at + c.number" class="tmq-caller"><i class="tm-pulse"></i>
          <span class="mono">{{ c.number || '—' }}</span><span class="empty">{{ c.name }}</span><span class="grow"></span><b class="mono">{{ clock(elapsed(c.joined_at)) }}</b></div>
      </div>
      <div class="tmq-today">
        <small>{{ t('tm.q.today') }}:</small>
        <span>{{ t('tm.q.offered') }} <b>{{ q.today.offered }}</b></span>
        <span>{{ t('tm.q.answered') }} <b>{{ q.today.answered }}</b></span>
        <span :class="{bad: q.today.missed}">{{ t('tm.q.missed') }} <b>{{ q.today.missed }}</b></span>
        <span>{{ t('tm.q.sl') }} <b>{{ pct(q.today.service_level) }}</b></span>
        <span v-if="q.today.asa_sec != null">{{ t('tm.q.asa') }} <b class="mono">{{ clock(q.today.asa_sec) }}</b></span>
      </div>
    </div>
  </div>
</section>`,
  };

  // ------------------------------------------------------------ the team's call feed
  const TeamFeed = {
    props: { items: Array, t: Function, fmt: Function, compact: Boolean },
    emits: ["open-ticket", "open-day"],
    setup(props) {
      const s = reactive({ f: "all" });
      const shown = computed(() => (props.items || []).filter((x) => s.f === "all" || (s.f === "missed" ? MISSED.includes(x.result) : x.direction === s.f)));
      const length = (x) => {
        if (x.result === "talking" && x.talk_sec != null) return props.t("tm.talk", { t: clock(x.talk_sec + 0) });
        if (x.talk_sec != null) return props.t("tm.talk", { t: clock(x.talk_sec) });
        if (x.wait_sec != null) return props.t("tm.wait", { t: clock(x.wait_sec) });
        return "";
      };
      return { s, shown, length, t: props.t, MISSED };
    },
    template: `
<section class="panel tm-feed" data-team="feed">
  <h2>{{ t('tm.feed.title') }}
    <span class="seg tm-seg" v-if="!compact"><button v-for="f in ['all','in','out','missed']" :key="f" :class="{on: s.f===f}" :data-feed="f" @click="s.f = f">{{ t('tm.feed.' + f) }}</button></span></h2>
  <div class="body tm-feed-body">
    <div v-if="!shown.length" class="empty">{{ t('tm.feed.none') }}</div>
    <div v-for="x in shown" :key="x.id + x.direction" class="tmf" :class="['r-' + x.result, {live: x.result==='talking' || x.result==='waiting' || x.result==='dialing'}]" :data-feed-row="x.result">
      <span class="tmf-dir" :class="x.direction" :title="t(x.direction==='in' ? 'tm.in' : 'tm.out')"><ico :name="x.direction==='in' ? 'arrin' : 'arrout'"></ico></span>
      <span class="tmf-time mono">{{ fmt(x.start) }}</span>
      <span class="tmf-who"><b class="mono">{{ x.number || '—' }}</b><span v-if="x.name" class="empty"> {{ x.name }}</span>
        <small class="empty" v-if="x.queue"> · {{ t('tm.queue', {q: x.queue}) }}</small></span>
      <span class="tmf-agent"><a v-if="x.agent_id" href="#" @click.prevent="$emit('open-day', x.agent_id)">{{ x.agent }}</a><span v-else class="empty">—</span>
        <small v-if="x.rang && x.rang.length" class="empty tmf-rang">{{ t('tm.feed.rang', {names: x.rang.join(', ')}) }}</small></span>
      <span class="tmf-res"><span class="tm-badge" :class="'b-' + x.result">{{ t('tm.r.' + x.result) }}</span></span>
      <span class="tmf-len mono empty">{{ length(x) }}</span>
      <span class="tmf-tk"><a v-if="x.ticket_id" href="#" @click.prevent="$emit('open-ticket', x.ticket_id)">#{{ x.ticket_id }}</a></span>
    </div>
  </div>
</section>`,
  };

  // ------------------------------------------------------------ one employee's day
  const AgentDay = {
    props: { agentId: Number, api: Function, t: Function, fmt: Function, tz: String, toast: Function, live: Number },
    emits: ["close", "open-ticket", "chat"],
    setup(props, { emit }) {
      const today = () => dayIn(new Date(), props.tz || "UTC");
      const s = reactive({ day: today(), d: null, loading: false });
      let seq = 0;
      async function load() {
        const my = ++seq;
        s.loading = true;
        try {
          const d = await props.api("GET", `/api/admin/team/agents/${props.agentId}/day?day=${s.day}`);
          if (my === seq) s.d = d;
        } catch (e) { if (my === seq) props.toast(e.message, "error"); } finally { if (my === seq) s.loading = false; }
      }
      const isToday = computed(() => s.day === today());
      function go(n) { const d = addDays(s.day, n); if (d > today()) return; s.day = d; load(); }
      // the timeline: from the first activity (or 08:00) to the last (or now), whole hours
      const span_ = computed(() => {
        const d = s.d;
        if (!d) return null;
        const from = new Date(d.from).getTime(), to = Math.min(new Date(d.to).getTime(), new Date(d.now).getTime());
        const act = [...d.states.filter((x) => x.state !== "offline"), ...d.calls_lane];
        let a = act.length ? Math.min(...act.map((x) => new Date(x.from).getTime())) : from + 8 * 3600e3;
        let b = act.length ? Math.max(...act.map((x) => new Date(x.to).getTime())) : from + 20 * 3600e3;
        if (isToday.value) b = Math.max(b, to);
        a = Math.max(from, Math.floor(a / 3600e3) * 3600e3); b = Math.min(new Date(d.to).getTime(), Math.ceil(b / 3600e3) * 3600e3);
        if (b - a < 4 * 3600e3) b = Math.min(new Date(d.to).getTime(), a + 4 * 3600e3);
        const hours = [];
        for (let h = a; h <= b; h += 3600e3) hours.push({ x: ((h - a) / (b - a)) * 100, label: hmIn(new Date(h).toISOString(), props.tz) });
        const seg = (x) => {
          const l = Math.max(a, new Date(x.from).getTime()), r = Math.min(b, new Date(x.to).getTime());
          return r > l ? { left: ((l - a) / (b - a)) * 100, width: Math.max(0.25, ((r - l) / (b - a)) * 100) } : null;
        };
        return {
          hours: hours.length > 14 ? hours.filter((_, i) => i % 2 === 0) : hours,
          states: d.states.map((x) => ({ ...x, pos: seg(x) })).filter((x) => x.pos && x.state !== "offline"),
          calls: d.calls_lane.map((x) => ({ ...x, pos: seg(x) })).filter((x) => x.pos),
        };
      });
      const st = computed(() => (s.d ? s.d.stats : null));
      const dur = (sec) => span(sec || 0, props.t);
      const segTitle = (x) => `${props.t("tm.st." + x.state)} · ${hmIn(x.from, props.tz)}–${hmIn(x.to, props.tz)}`;
      const callTitle = (x) => `${x.number || ""} · ${hmIn(x.from, props.tz)}–${hmIn(x.to, props.tz)}`;
      function onKey(e) { if (e.key === "Escape") emit("close"); }
      watch(() => props.agentId, () => { s.day = today(); load(); });
      watch(() => props.live, () => { if (isToday.value) load(); });
      onMounted(() => { load(); window.addEventListener("keydown", onKey); });
      onBeforeUnmount(() => window.removeEventListener("keydown", onKey));
      return { s, t: props.t, go, isToday, span_, st, dur, clock, pct, hmIn, segTitle, callTitle, MISSED };
    },
    template: `
<div class="overlay tm-day-ov" @click.self="$emit('close')">
  <div class="panel modal tm-day" role="dialog" aria-modal="true" data-agent-day>
    <header class="tm-day-head" v-if="s.d">
      <user-avatar :name="s.d.agent.name" :url="s.d.agent.avatar_url"></user-avatar>
      <div class="grow"><h3>{{ t('tm.d.title', {name: s.d.agent.name}) }}</h3>
        <div class="empty">{{ s.d.agent.position }} · {{ t('ext') }} {{ s.d.agent.extension || '—' }}</div></div>
      <div class="tm-day-nav">
        <button class="btn sm" @click="go(-1)" :title="t('tm.d.prev')" data-day-prev>‹</button>
        <span class="mono" data-day>{{ s.day }}</span>
        <button class="btn sm" @click="go(1)" :disabled="isToday" :title="t('tm.d.next')">›</button>
      </div>
      <button class="btn sm" @click="$emit('chat', s.d.agent.id)" :title="t('tm.chat')"><ico name="chat"></ico></button>
      <button class="btn sm" @click="$emit('close')" :aria-label="t('tm.d.close')"><ico name="close"></ico></button>
    </header>
    <div v-if="!s.d" class="empty" style="padding:24px">…</div>
    <template v-else>
      <div class="tm-stats" data-day-stats>
        <div><small>{{ t('tm.d.in') }}</small><b>{{ st.inbound_answered }}</b><span class="empty">{{ t('tm.d.rang', {n: st.inbound_rang}) }}</span></div>
        <div :class="{bad: st.rona}"><small>{{ t('tm.d.missed') }}</small><b>{{ st.rona }}</b></div>
        <div><small>{{ t('tm.d.out') }}</small><b>{{ st.outbound }}</b><span class="empty">{{ t('tm.d.connected', {n: st.outbound_connected}) }}</span></div>
        <div><small>{{ t('tm.d.talk') }}</small><b>{{ dur(st.talk_sec) }}</b><span class="empty" v-if="st.aht_talk_sec != null">{{ t('tm.d.aht', {t: clock(st.aht_talk_sec)}) }}</span></div>
        <div><small>{{ t('tm.d.break') }}</small><b>{{ dur(st.break_sec) }}</b></div>
        <div><small>{{ t('tm.d.logged') }}</small><b>{{ dur(st.logged_in_sec) }}</b>
          <span class="empty" v-if="st.first_in">{{ t('tm.d.first') }} {{ hmIn(st.first_in, $props.tz) }} · {{ st.last_out ? t('tm.d.last') + ' ' + hmIn(st.last_out, $props.tz) : t('tm.d.still') }}</span></div>
        <div><small>{{ t('tm.d.tickets') }}</small><b>{{ st.tickets_completed }}</b><span class="empty">{{ t('tm.d.started', {n: st.tickets_started}) }}</span></div>
        <div><small>{{ t('tm.d.occupancy') }}</small><b>{{ pct(st.occupancy) }}</b></div>
      </div>
      <h4>{{ t('tm.d.timeline') }}</h4>
      <div v-if="!span_.states.length && !span_.calls.length" class="empty">{{ t('tm.d.no_activity') }}</div>
      <div v-else class="tm-tl" data-timeline>
        <div class="tm-lane"><small>{{ t('tm.d.states_lane') }}</small>
          <div class="tm-bar"><i v-for="(x, i) in span_.states" :key="'s' + i" :class="'st-' + x.state" :style="{left: x.pos.left + '%', width: x.pos.width + '%'}" :title="segTitle(x)"></i></div></div>
        <div class="tm-lane"><small>{{ t('tm.d.calls_lane') }}</small>
          <div class="tm-bar calls"><i v-for="(x, i) in span_.calls" :key="'c' + i" :class="x.direction" :style="{left: x.pos.left + '%', width: x.pos.width + '%'}" :title="callTitle(x)"></i></div></div>
        <div class="tm-hours"><span v-for="h in span_.hours" :key="h.x" :style="{left: h.x + '%'}">{{ h.label }}</span></div>
        <div class="tm-legend"><span v-for="k in ['ready','busy_task','wrap_up','break']" :key="k"><i :class="'st-' + k"></i>{{ t('tm.st.' + k) }}</span>
          <span><i class="lg-in"></i>{{ t('tm.in') }}</span><span><i class="lg-out"></i>{{ t('tm.out') }}</span></div>
      </div>
      <h4>{{ t('tm.d.calls') }} <span class="count">{{ s.d.calls.length }}</span></h4>
      <div v-if="!s.d.calls.length" class="empty">{{ t('tm.d.no_calls') }}</div>
      <div v-else class="table-wrap tm-day-calls"><table>
        <thead><tr><th>{{ t('tm.d.when') }}</th><th></th><th>{{ t('tm.d.number') }}</th><th>{{ t('tm.d.result') }}</th><th>{{ t('tm.d.length') }}</th><th></th></tr></thead>
        <tbody><tr v-for="c in s.d.calls" :key="c.id" :data-day-call="c.result">
          <td class="mono">{{ hmIn(c.start, $props.tz) }}</td>
          <td><span class="tmf-dir" :class="c.direction"><ico :name="c.direction==='in' ? 'arrin' : 'arrout'"></ico></span></td>
          <td><b class="mono">{{ c.number || '—' }}</b> <span class="empty">{{ c.name }}</span><small class="empty" v-if="c.queue"> · {{ t('tm.queue', {q: c.queue}) }}</small></td>
          <td><span class="tm-badge" :class="'b-' + c.result">{{ t('tm.r.' + c.result) }}</span></td>
          <td class="mono">{{ c.talk_sec != null ? clock(c.talk_sec) : '—' }}</td>
          <td><a v-if="c.ticket_id" href="#" @click.prevent="$emit('open-ticket', c.ticket_id)">#{{ c.ticket_id }}</a></td>
        </tr></tbody>
      </table></div>
    </template>
  </div>
</div>`,
  };

  // ------------------------------------------------------------ the wallboard (TV mode)
  const TeamWall = {
    props: { api: Function, t: Function, fmt: Function, tz: String, live: Number, stateText: Function },
    emits: ["exit"],
    setup(props) {
      const s = reactive({ agents: [], d: null, err: "", full: false });
      let seq = 0;
      async function load() {
        const my = ++seq;
        try {
          const [a, d] = await Promise.all([props.api("GET", "/api/admin/agents"), props.api("GET", "/api/admin/team/live?feed=12")]);
          if (my !== seq) return;
          tick.skew = new Date(a.now).getTime() - Date.now();
          s.agents = a.agents; s.d = d; s.err = "";
        } catch (e) { if (my === seq) s.err = e.message; }
      }
      const order = { call: 0, free: 1, busy: 2, break: 3, offline: 4 };
      const people = computed(() => s.agents.slice().sort((x, y) => (order[x.group] ?? 9) - (order[y.group] ?? 9) || x.name.localeCompare(y.name)));
      const counts = computed(() => {
        const c = { call: 0, free: 0, busy: 0, break: 0, offline: 0 };
        for (const a of s.agents) c[a.group] = (c[a.group] || 0) + 1;
        return c;
      });
      const longest = computed(() => {
        if (!s.d) return 0;
        const all = s.d.queues.flatMap((q) => q.callers.map((c) => c.joined_at)).sort();
        return all.length ? elapsed(all[0]) : 0;
      });
      const slBad = computed(() => s.d && s.d.today.service_level != null && s.d.today.service_level < s.d.today.sla_target);
      function full() {
        const el = document.documentElement;
        if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
        else if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
      }
      const clockNow = computed(() => hmIn(new Date(tick.now + tick.skew).toISOString(), props.tz));
      const phaseTime = (a) => (a.phase_since ? clock(elapsed(a.phase_since)) : a.state_since ? clock(elapsed(a.state_since)) : "");
      watch(() => props.live, load);
      let timer;
      onMounted(() => { load(); timer = setInterval(load, 30000); document.documentElement.classList.add("wall-on"); });
      onBeforeUnmount(() => { clearInterval(timer); document.documentElement.classList.remove("wall-on"); });
      return { s, t: props.t, people, counts, longest, slBad, full, clockNow, phaseTime, clock, pct, elapsed, PHASE_ICON };
    },
    template: `
<div class="wall" data-wall>
  <header class="wall-head">
    <brand-word class="wall-brand"></brand-word><span class="wall-live"><i></i>{{ t('tm.w.updated') }}</span>
    <span class="grow"></span><span class="wall-clock mono">{{ clockNow }}</span>
    <button class="btn sm" @click="full" :title="t('tm.w.full')"><ico name="expand"></ico></button>
    <button class="btn sm" @click="$emit('exit')" data-wall-exit>{{ t('tm.w.exit') }}</button>
  </header>
  <div v-if="s.err" class="banner error">{{ s.err }}</div>
  <div class="wall-tiles" v-if="s.d">
    <div class="wt" :class="{alarm: s.d.waiting_total > 0}" data-wt="waiting"><small>{{ t('tm.w.waiting') }}</small><b>{{ s.d.waiting_total }}</b>
      <span>{{ t('tm.w.longest') }} <b class="mono">{{ s.d.waiting_total ? clock(longest) : '—' }}</b></span></div>
    <div class="wt" data-wt="talking"><small>{{ t('tm.w.talking') }}</small><b>{{ s.d.talking_total }}</b></div>
    <div class="wt good" data-wt="free"><small>{{ t('tm.w.free') }}</small><b>{{ s.d.free_total }}</b></div>
    <div class="wt" data-wt="break"><small>{{ t('tm.w.break') }}</small><b>{{ counts.break }}</b></div>
    <div class="wt" data-wt="answered"><small>{{ t('tm.w.answered') }}</small><b>{{ s.d.today.answered }}</b></div>
    <div class="wt" :class="{alarm: s.d.today.missed}" data-wt="missed"><small>{{ t('tm.w.missed') }}</small><b>{{ s.d.today.missed }}</b></div>
    <div class="wt" :class="slBad ? 'alarm' : 'good'" data-wt="sl"><small>{{ t('tm.w.sl') }}</small><b>{{ pct(s.d.today.service_level) }}</b>
      <span>{{ t('tm.w.target', {p: Math.round(s.d.today.sla_target * 100)}) }}</span></div>
    <div class="wt" data-wt="asa"><small>{{ t('tm.w.asa') }}</small><b class="mono">{{ s.d.today.asa_sec != null ? clock(s.d.today.asa_sec) : '—' }}</b></div>
  </div>
  <div class="wall-queues" v-if="s.d && s.d.queues.length">
    <div v-for="q in s.d.queues" :key="q.queue" class="wq" :class="{alarm: q.waiting}" :data-wq="q.queue">
      <b class="wq-name">{{ q.queue }}</b><span class="wq-n"><b>{{ q.waiting }}</b> {{ t('tm.q.waiting') }}</span>
      <span class="mono" v-if="q.callers.length">{{ clock(elapsed(q.callers[0].joined_at)) }}</span>
      <span class="empty">{{ t('tm.q.answered') }} {{ q.today.answered }} · {{ t('tm.q.missed') }} {{ q.today.missed }} · {{ pct(q.today.service_level) }}</span>
    </div>
  </div>
  <div class="wall-main">
    <div class="wall-people">
      <div v-for="a in people" :key="a.agent_id" class="wp" :class="['g-' + a.group, a.phase ? 'ph-' + a.phase : '']" :data-wp="a.agent_id">
        <div class="wp-name">{{ a.name }}</div>
        <div class="wp-state"><ico v-if="a.phase" :name="PHASE_ICON[a.phase]"></ico>{{ a.phase ? t('tm.ph.' + a.phase) : stateText(a.display_state) }}</div>
        <div class="wp-num mono" v-if="a.live_call">{{ a.live_call.number || '—' }}<span v-if="a.live_call.name"> · {{ a.live_call.name }}</span></div>
        <div class="wp-time mono">{{ phaseTime(a) }}</div>
      </div>
    </div>
    <div class="wall-feed" v-if="s.d">
      <h3>{{ t('tm.w.calls') }}</h3>
      <div v-for="x in s.d.feed" :key="x.id + x.direction" class="wf" :class="'r-' + x.result">
        <ico :name="x.direction==='in' ? 'arrin' : 'arrout'"></ico><span class="mono">{{ fmt(x.start) }}</span>
        <b class="mono">{{ x.number || '—' }}</b><span class="grow empty wf-agent">{{ x.agent }}</span>
        <span class="tm-badge" :class="'b-' + x.result">{{ t('tm.r.' + x.result) }}</span>
      </div>
    </div>
  </div>
</div>`,
  };

  return { i18n, tick, elapsed, clock, span, PHASE_ICON, TeamQueues, TeamFeed, AgentDay, TeamWall };
})();
