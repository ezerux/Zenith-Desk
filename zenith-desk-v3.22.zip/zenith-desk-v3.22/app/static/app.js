/* Operator workplace — build-free SPA (Vue 3). Language: UI_LANGUAGE on the server (en | ru). */
const { createApp, reactive, computed, onMounted, h, nextTick, watch } = Vue;

const I18N = {
  en: {
    "app.title": "Zenith Desk",
    "app.subtitle": "Operator Workplace",
    "nav.settings": "Settings", "nav.menu": "Menu", "nav.chat": "Messages",
    "nav.whatsapp": "WhatsApp", "nav.telegram": "Telegram", "msg.soon": "Being prepared",
    "msg.soon_t": "{ch} chats with customers will be here",
    "msg.soon_d": "Customers write to the company's {ch}; Zammad receives the messages through its {ch} channel and keeps them as tickets. Zenith Desk will show them here as live chats: the list of conversations, the history, quick replies and files — your answer goes back to the customer in {ch}.",
    "msg.soon_n": "The look of this page is being agreed. Until then, these chats are in Tickets.", "msg.open_tickets": "Open Tickets",
    "chat.search_results": "Chats and colleagues", "chat.no_chats": "No chats yet — search a colleague by name to start one",
    "chat.edited": "edited", "chat.actions": "Message actions", "chat.copy": "Copy text", "chat.copied": "Copied",
    "chat.edit": "Edit", "chat.editing": "Editing", "chat.save": "Save", "chat.delete": "Delete", "chat.delete_q": "Delete this message?",
    "chat.delete_all": "Also delete for {name}", "chat.delete_me_only": "It will disappear only for you.",
    "push.title": "Notifications when Zenith Desk is closed", "push.hint": "New messages pop up on this computer even with every Zenith Desk tab closed (the browser must be running).",
    "push.enable": "Turn on", "push.disable": "Turn off", "push.enabled": "Background notifications are on for this browser",
    "push.failed": "Could not turn on notifications", "push.banner": "Turn on notifications so you don't miss messages",
    "push.unsupported": "not supported by this browser", "push.insecure": "needs HTTPS", "push.denied": "blocked in browser settings",
    "chat.typing_one": "{name} is typing…", "chat.typing_many": "{names} are typing…", "chat.members": "{n} members",
    "chat.attach": "Attach files", "chat.emoji": "Emoji", "chat.files_max": "Up to {n} files in one message", "chat.file_big": "{name} is larger than {mb} MB",
    "chat.bad_file": "{name} could not be read", "chat.file_gone": "The file is no longer available", "chat.drop": "Drop the files here to send them",
    "chat.em.recent": "Recent", "chat.em.smileys": "Smileys", "chat.em.gestures": "Gestures", "chat.em.hearts": "Hearts", "chat.em.work": "Work",
    "chat.new_group": "New group", "chat.group_name": "Group name", "chat.group_people": "Members", "chat.group_create": "Create group",
    "chat.group_name_need": "Give the group a name", "chat.group_members_need": "Add at least one colleague", "chat.picked": "{n} selected",
    "chat.search_people": "Search colleagues", "chat.rename": "Rename", "chat.add_people": "Add people", "chat.add": "Add", "chat.remove": "Remove from the group",
    "chat.leave": "Leave the group", "chat.leave_q": "Leave «{name}»? You will no longer see its messages.", "chat.owner": "owner",
    "chat.group_hello": "«{name}» is ready. Write the first message — everybody in the group will see it.", "chat.group": "Group",
    "chat.search": "Search", "chat.you": "You", "chat.typing": "typing…", "chat.online": "online", "chat.away": "away",
    "chat.last_seen": "last seen {t}", "chat.long_ago": "last seen a long time ago", "chat.today": "Today", "chat.yesterday": "Yesterday",
    "chat.write": "Write a message…", "chat.send": "Send", "chat.pick": "Select a chat to start messaging", "chat.back": "Back",
    "chat.info": "User info", "chat.nobody": "Nobody found", "chat.no_people": "No colleagues yet",
    "chat.hello_title": "No messages here yet…", "chat.hello_text": "Say hello to {name}. Messages are saved and stay private between the two of you.",
    "chat.messages_total": "messages together · {w} this week", "chat.member_since": "in Zenith Desk since",
    "idle.title": "Paused — you were away", "idle.text": "Nobody used Zenith Desk for more than {min} minutes, so calls were stopped and your manager sees you as offline. Your tasks are kept.",
    "idle.since": "Away since", "idle.since_short": "since", "idle.back": "I'm back", "idle.tag": "Away",
    "idle.warn": "No activity — you will be paused in {t}. Move the mouse to stay online.",
    "live.on": "Live", "live.lost": "Reconnecting…", "live.connecting": "Connecting…",
    "live.on_hint": "Connected: every change appears here the moment the server receives it",
    "live.lost_hint": "Connection lost — reconnecting automatically; the screen is refreshed as soon as it is back",
    "set.zoom": "Interface size", "set.zoom_auto": "Auto",
    "set.zoom_hint": "How large everything is drawn. Auto fits the screen: 80–85 % on laptops, 90 % on big screens. Saved to your account; on a phone the page always stays at 100 %.",
    "set.motion": "Animations and smooth transitions", "set.motion_hint": "Turn off on slow computers. Also off automatically when “reduce motion” is enabled in the operating system.",
    "ws.customize": "Customize",
    "rail.tools": "Tools", "rail.pins": "Quick access", "rail.pins_add": "Add sections to quick access",
    "rail.pins_hint": "Pin up to {max} sections you open most often. They stay in the top menu as well.",
    "rail.pins_full": "Quick access holds up to {max} sections — unpin one first", "rail.pins_count": "{n} of {max}",
    "rail.me": "My settings",
    "ws.editing": "Editing your workspace",
    "ws.hint": "Drag blocks to reorder them, or use ◀ ▶. ⅓ ⅔ ▭ change the width, ↕ the height, ✕ hides a block. Changes are saved automatically.",
    "ws.preset": "Layout",
    "ws.hidden": "Hidden blocks",
    "ws.reset": "Reset to default",
    "ws.done": "Done",
    "ws.drag": "Drag to move", "ws.left": "Move left / up", "ws.right": "Move right / down",
    "ws.width": "Width", "ws.height": "Height", "ws.hide": "Hide block",
    "ws.saved": "Workspace saved",
    "h.auto": "auto", "h.s": "S", "h.m": "M", "h.l": "L",
    "wg.kpis": "Summary cards", "wg.active": "Active tasks", "wg.background": "Background tasks",
    "wg.notifications": "Notifications", "wg.new": "New requests", "wg.mine": "Assigned to me",
    "wg.pending": "Pending", "wg.calls": "Recent calls",
    "preset.default": "Default", "preset.calls": "Calls focus", "preset.tickets": "Tickets focus",
    "preset.compact": "Compact", "preset.focus": "Minimal", "preset.custom": "My layout",
    "preset.default_d": "Command Center: summary strip on top, your work on the left, notifications and calls on the right.",
    "preset.calls_d": "For call-heavy shifts: large recent calls and notifications next to tasks.",
    "preset.tickets_d": "For email / messenger work: wide task and request lists, calls small.",
    "preset.compact_d": "Everything on one screen: dense spacing, short blocks.",
    "preset.focus_d": "Only what you work on now: active tasks, new requests, notifications.",
    "set.title": "My settings",
    "set.appearance": "Appearance",
    "set.theme": "Theme",
    "set.theme_system": "Like the system", "set.theme_light": "Light", "set.theme_dark": "Dark (default)",
    "set.compact": "Compact density (smaller spacing)",
    "set.workspace": "Workspace layout",
    "set.workspace_hint": "Pick a ready layout or arrange the blocks yourself. Saved to your account — the same on any computer.",
    "set.current": "current",
    "set.alerts": "Calls and notifications",
    "set.sound": "Sound signal on an incoming call",
    "set.account": "Account",
    "set.name": "Name", "set.username": "Login", "set.level": "Level", "set.position": "Position", "set.role": "Role",
    "set.interface": "Interface", "set.interface_hint": "Everything about how Zenith Desk looks and how your home screen is arranged — in one place. Saved to your account: the same on any computer.",
    "set.look": "Style", "set.theme_motion": "Theme and motion", "set.home": "Home screen (My workplace)",
    "set.home_hint": "How your work is shown on «My workplace». All functions are the same in every layout.",
    "dash.standard": "Blocks", "dash.standard_d": "The blocks you arrange yourself (Customize): tasks, requests, notifications, calls.",
    "dash.focus": "Focus", "dash.focus_d": "One big card with the next thing to do; the queue and my tickets on the side.",
    "dash.board": "Board", "dash.board_d": "Columns by stage: new, in work, assigned to me, pending.",
    "dash.inbox": "Inbox", "dash.inbox_d": "Everything in one list with filters by kind and channel; today, notifications and calls on the side.",
    "dash.table": "Table", "dash.table_d": "A dense table of all your work, one ticket per row.",
    "sn.layout": "Layout",
    "dl.now": "Now working on", "dl.next": "Next request", "dl.oldest_first": "oldest first", "dl.nothing": "Nothing here — all done",
    "dl.waiting": "waiting", "dl.assigned": "assigned to me", "dl.start_blocks": "Start — blocks calls", "dl.skip": "Skip",
    "dl.queue": "Queue", "dl.in_work": "In work", "dl.no_work": "Nothing in work", "dl.today": "Today", "dl.answered": "Answered", "dl.d": "d",
    "dl.f.all": "All", "dl.f.new": "New", "dl.f.mine": "Mine", "dl.f.work": "In work", "dl.f.pending": "Pending",
    "dl.k.active": "In work · blocks calls", "dl.k.background": "Background", "dl.k.new": "New", "dl.k.mine": "Assigned to me", "dl.k.pending": "Pending",
    "dl.col.title": "Title", "dl.col.channel": "Channel", "dl.col.group": "Group", "dl.col.status": "Status", "dl.col.age": "Waiting",
    "btn.bg_short": "Background",
    "set.style": "Interface style", "set.style_hint": "Only the look changes: every function works the same and the icons on the left stay in their places. Saved to your account — the same on any computer.",
    "set.style_classic": "Classic", "set.style_classic_d": "The Command Center look: top bar, joined summary strip, list panels, blue accents.",
    "set.style_studio": "Studio", "set.style_studio_d": "Section panel with counters, framed workspace, greeting, separate number cards, work as cards with status pills, amber accents.",
    "set.style_flow": "Flow", "set.style_flow_d": "The default look. Sections as pills at the top (the active one slides), your tools on a rail at the left — status, phone, Customize and up to 5 sections you pin for quick access — big titles, rounded cards, smooth motion.",
    "set.new": "new",
    "av.title": "Account picture", "av.hint": "Your photo or the first letters of your first and last name. Colleagues see it in the messenger and the manager panel.",
    "av.upload": "Upload photo", "av.change": "Change photo", "av.delete": "Delete photo", "av.use_photo": "Photo", "av.use_initials": "Initials",
    "av.saved": "Picture saved", "av.deleted": "Photo deleted — the initials are shown", "av.type": "Choose a JPEG, PNG or WebP picture", "av.busy": "Uploading…",
    "st.morning": "Good morning, {name}", "st.afternoon": "Good afternoon, {name}", "st.evening": "Good evening, {name}",
    "sn.channels": "Channels", "sn.comm": "Communication", "sn.period": "Period", "sn.level": "Level", "sn.state": "State", "sn.team": "Team",
    "sn.shift": "Start of shift", "sn.shift_close": "Hide for today",
    "sn.ck_phone": "Phone online", "sn.ck_phone_d": "Zenith Phone · ext. {ext}", "sn.ck_mail": "Sign in to your mailbox", "sn.ck_mail_d": "Mail → e-mail and password",
    "sn.ck_ready": "Go Ready", "sn.ck_ready_d": "Calls from the queues come to you", "sn.my_settings": "My settings",
    "sn.hide": "Hide the panel (it opens from the active icon or the button in the top bar)", "sn.pin": "Pin the panel next to the icons",
    "set.panel": "Section panel (Studio)", "set.panel_docked": "Next to the icons", "set.panel_docked_d": "Compact panel always open next to the icons; « hides it.",
    "set.panel_popup": "Pop-up", "set.panel_popup_d": "The page uses the whole width; the sections open over it from the active icon or the button in the top bar.",
    "theme.dark": "Dark theme",
    "theme.light": "Light theme",
    "kpi.blocking": "Active tasks",
    "kpi.background": "Background",
    "kpi.done": "Completed today",
    "kpi.calls": "Calls today",
    "kpi.calls_sub": "{a} answered · {m} missed",
    "kpi.busy": "Busy with tasks today",
    "kpi.busy_sub": "calls paused",
    "ntf.title": "Notifications",
    "ntf.empty": "No notifications",
    "ntf.mark_read": "Mark as read",
    "ntf.desktop": "Desktop alerts",
    "ntf.desktop_on": "Desktop alerts are on",
    "sup.assign": "Assign ticket",
    "sup.assign_title": "Assign / reassign a ticket",
    "sup.ticket_number": "Ticket number",
    "sup.assign_to": "Operator",
    "sup.mode": "Start work",
    "sup.mode_none": "No — only assign",
    "sup.k.online": "Online",
    "sup.k.ready": "Ready",
    "sup.k.busy": "Busy",
    "sup.k.break": "On break",
    "sup.k.offline": "Offline",
    "sup.k.sync": "Sync problems",
    "toast.assigned": "Ticket assigned",
    "call.desktop_title": "Incoming call",
    "login.hint": "Sign in with the login issued by your administrator",
    "login.login": "Login",
    "nav.work": "My workplace",
    "nav.sup": "Manager panel",
    "team.all": "All",
    "btn.change_password": "Change password",
    "pw.title": "Change password",
    "pw.forced": "Your administrator asks you to set your own password before you start.",
    "pw.current": "Current password",
    "pw.new": "New password (at least 8 characters)",
    "pw.repeat": "Repeat the new password",
    "pw.mismatch": "Passwords do not match",
    "pw.changed": "Password changed",
    "login.password": "Password",
    "login.submit": "Sign in",
    "ext": "ext.",
    "btn.ready": "Ready",
    "btn.break": "Break",
    "btn.logout": "Sign out",
    "tab.work": "My work",
    "tab.sup": "Supervisor",
    "state.ready": "Ready",
    "state.busy_task": "Busy with a task",
    "state.break": "On break",
    "state.offline": "Offline",
    "state.wrap_up": "Wrap-up",
    "state.ready_unconfirmed": "Ready — not confirmed",
    "state.external_pause": "Paused on the phone",
    "src.phone": "Phone", "src.email": "Email", "src.telegram": "Telegram", "src.whatsapp": "WhatsApp", "src.web": "Web", "src.internal": "Internal",
    "call.ringing": "ringing", "call.answered": "in call", "call.ended": "ended", "call.missed": "missed",
    "banner.sse": "No connection to the server. The state may be outdated — you are not treated as ready until the connection is restored.",
    "banner.sync_error": "Telephony sync error",
    "banner.sync_pending": "Syncing with telephony…",
    "banner.retry_at": "retry at",
    "call.incoming": "Incoming call",
    "call.outgoing": "Outgoing call",
    "call.hidden": "hidden number",
    "call.queue": "queue",
    "call.several": "Several customers found:",
    "call.no_tickets": "No tickets",
    "call.not_found": "Customer not found by this number.",
    "call.create_ticket": "Create ticket from call",
    "call.open_ticket": "Open the call's ticket",
    "call.create_customer": "Create customer",
    "call.hide": "Hide",
    "panel.active": "Active tasks",
    "panel.active_empty": "No blocking tasks — calls come in when you are ready.",
    "panel.background": "My background tasks",
    "panel.background_empty": "No background tasks",
    "panel.new": "New requests",
    "panel.new_empty": "No unassigned tickets",
    "panel.mine": "Assigned to me",
    "panel.mine_empty": "No tickets without active work",
    "panel.pending": "Pending",
    "panel.pending_empty": "No pending tickets",
    "panel.calls": "Recent calls",
    "panel.calls_empty": "No calls yet",
    "tag.blocking": "blocks calls",
    "tag.background": "does not block",
    "since": "since",
    "btn.start": "Start",
    "btn.background": "Background task",
    "btn.complete": "Complete",
    "btn.postpone": "Postpone",
    "btn.remove": "Remove",
    "btn.card": "Card / ticket",
    "link.ticket": "ticket",
    "link.recording": "recording",
    "hidden": "hidden",
    "sup.ami_down": "No connection to Asterisk (AMI). Queue pauses are not managed.",
    "sup.operators": "Operators",
    "sup.refresh": "Refresh",
    "sup.col.operator": "Operator",
    "sup.col.state": "State",
    "sup.col.phone": "Telephony",
    "sup.col.tasks": "Tasks",
    "sup.synced": "synced",
    "sup.cancel": "cancel",
    "sup.reconcile": "Reconcile",
    "sup.override": "Override",
    "sup.report": "Last 24 hours",
    "sup.col.completed": "Completed",
    "sup.col.blocking": "Blocking work",
    "sup.col.background": "Background",
    "sup.col.paused": "Queue paused",
    "sup.col.errors": "Errors",
    "sup.audit": "Audit log",
    "sup.all": "all",
    "sup.operator": "operator",
    "sup.ticket": "ticket",
    "modal.complete": "Complete task",
    "modal.zammad_state": "Ticket state in Zammad",
    "modal.note": "Internal note (optional)",
    "modal.cancel": "Cancel",
    "modal.new_customer": "New customer",
    "modal.firstname": "First name",
    "modal.lastname": "Last name",
    "modal.phone": "Phone",
    "modal.email": "Email",
    "modal.notes": "Note",
    "modal.create": "Create",
    "modal.new_ticket": "New ticket",
    "modal.call_note": "Call details (number, time, call ID, recording) will be added automatically.",
    "modal.customer": "Customer",
    "modal.choose": "— choose —",
    "modal.type": "Type",
    "modal.priority": "Priority",
    "prio.low": "low", "prio.normal": "normal", "prio.high": "high",
    "modal.subject": "Subject",
    "modal.description": "Description",
    "modal.save": "Save",
    "modal.save_bg": "Save as background",
    "modal.save_start": "Save and start",
    "modal.override": "Override",
    "modal.audit_note": "This action is recorded in the audit log.",
    "modal.state": "State",
    "modal.ignore_blocking": "Return to the queue despite blocking tasks",
    "modal.reason": "Reason",
    "modal.apply": "Apply",
    "toast.started_blocking": "Work started — incoming calls are paused",
    "toast.started_background": "Added to background tasks",
    "toast.released": "Stopped working on the ticket",
    "toast.completed": "Task completed",
    "toast.customer_created": "Customer created",
    "toast.ticket_created": "Ticket created",
    "toast.reconciled": "Reconciliation done",
    "toast.override": "Override applied",
    "toast.session_cancelled": "Session cancelled",
    "err.session_expired": "Session expired",
    "err.status": "Error {status}",
    "err.choose_customer": "Choose or create a customer",
    "prompt.cancel": "Cancel work on ticket #{n}? Enter a reason:",
    "dur.h": "h", "dur.min": "min",
  },
  ru: {
    "app.title": "Zenith Desk",
    "app.subtitle": "Рабочее место оператора",
    "nav.settings": "Настройки", "nav.menu": "Меню", "nav.chat": "Сообщения",
    "nav.whatsapp": "WhatsApp", "nav.telegram": "Telegram", "msg.soon": "Готовится",
    "msg.soon_t": "Здесь будут чаты с клиентами в {ch}",
    "msg.soon_d": "Клиенты пишут в {ch} компании; Zammad принимает сообщения через свой канал {ch} и хранит их как тикеты. Zenith Desk покажет их здесь как живые чаты: список диалогов, история, быстрые ответы и файлы — ваш ответ уйдёт клиенту в {ch}.",
    "msg.soon_n": "Вид этой страницы согласовывается. Пока эти чаты доступны в разделе «Тикеты».", "msg.open_tickets": "Открыть тикеты",
    "chat.search_results": "Чаты и коллеги", "chat.no_chats": "Пока нет чатов — найдите коллегу по имени, чтобы начать",
    "chat.edited": "изменено", "chat.actions": "Действия", "chat.copy": "Копировать текст", "chat.copied": "Скопировано",
    "chat.edit": "Изменить", "chat.editing": "Редактирование", "chat.save": "Сохранить", "chat.delete": "Удалить", "chat.delete_q": "Удалить сообщение?",
    "chat.delete_all": "Удалить также у {name}", "chat.delete_me_only": "Сообщение исчезнет только у вас.",
    "push.title": "Уведомления, когда Zenith Desk закрыт", "push.hint": "Новые сообщения появятся на этом компьютере, даже если все вкладки Zenith Desk закрыты (браузер должен быть запущен).",
    "push.enable": "Включить", "push.disable": "Выключить", "push.enabled": "Фоновые уведомления включены для этого браузера",
    "push.failed": "Не удалось включить уведомления", "push.banner": "Включите уведомления, чтобы не пропускать сообщения",
    "push.unsupported": "браузер не поддерживает", "push.insecure": "нужен HTTPS", "push.denied": "запрещены в настройках браузера",
    "chat.typing_one": "{name} печатает…", "chat.typing_many": "{names} печатают…", "chat.members": "участников: {n}",
    "chat.attach": "Прикрепить файлы", "chat.emoji": "Эмодзи", "chat.files_max": "Не больше {n} файлов в одном сообщении", "chat.file_big": "{name} больше {mb} МБ",
    "chat.bad_file": "Не удалось прочитать {name}", "chat.file_gone": "Файл больше недоступен", "chat.drop": "Отпустите файлы здесь, чтобы отправить",
    "chat.em.recent": "Недавние", "chat.em.smileys": "Смайлы", "chat.em.gestures": "Жесты", "chat.em.hearts": "Сердца", "chat.em.work": "Работа",
    "chat.new_group": "Новая группа", "chat.group_name": "Название группы", "chat.group_people": "Участники", "chat.group_create": "Создать группу",
    "chat.group_name_need": "Дайте группе название", "chat.group_members_need": "Добавьте хотя бы одного коллегу", "chat.picked": "выбрано: {n}",
    "chat.search_people": "Поиск коллег", "chat.rename": "Переименовать", "chat.add_people": "Добавить людей", "chat.add": "Добавить", "chat.remove": "Удалить из группы",
    "chat.leave": "Выйти из группы", "chat.leave_q": "Выйти из «{name}»? Вы больше не будете видеть её сообщения.", "chat.owner": "создатель",
    "chat.group_hello": "«{name}» готова. Напишите первое сообщение — его увидят все в группе.", "chat.group": "Группа",
    "chat.search": "Поиск", "chat.you": "Вы", "chat.typing": "печатает…", "chat.online": "в сети", "chat.away": "отошёл",
    "chat.last_seen": "был(а) {t}", "chat.long_ago": "был(а) давно", "chat.today": "Сегодня", "chat.yesterday": "Вчера",
    "chat.write": "Написать сообщение…", "chat.send": "Отправить", "chat.pick": "Выберите, кому хотите написать", "chat.back": "Назад",
    "chat.info": "Информация", "chat.nobody": "Никого не найдено", "chat.no_people": "Пока нет коллег",
    "chat.hello_title": "Здесь пока нет сообщений…", "chat.hello_text": "Напишите {name}. Сообщения сохраняются и видны только вам двоим.",
    "chat.messages_total": "сообщений вместе · {w} за неделю", "chat.member_since": "в Zenith Desk с",
    "idle.title": "Пауза — вы отошли", "idle.text": "Zenith Desk не использовали больше {min} минут, поэтому звонки остановлены, а руководитель видит вас «не в сети». Ваши задачи сохранены.",
    "idle.since": "Нет на месте с", "idle.since_short": "с", "idle.back": "Я вернулся", "idle.tag": "Отошёл",
    "idle.warn": "Нет активности — пауза через {t}. Пошевелите мышью, чтобы остаться в сети.",
    "live.on": "Онлайн", "live.lost": "Переподключение…", "live.connecting": "Подключение…",
    "live.on_hint": "Подключено: любое изменение появляется здесь в момент, когда его получает сервер",
    "live.lost_hint": "Связь потеряна — переподключаемся автоматически; экран обновится сразу после восстановления",
    "set.zoom": "Размер интерфейса", "set.zoom_auto": "Авто",
    "set.zoom_hint": "Насколько крупно всё показано. «Авто» подбирает под экран: 80–85 % на ноутбуках, 90 % на больших экранах. Сохраняется в учётной записи; на телефоне страница всегда 100 %.",
    "set.motion": "Анимации и плавные переходы", "set.motion_hint": "Отключите на медленных компьютерах. Отключаются автоматически, если в системе включено «уменьшение движения».",
    "ws.customize": "Настроить",
    "rail.tools": "Инструменты", "rail.pins": "Быстрый доступ", "rail.pins_add": "Добавить разделы в быстрый доступ",
    "rail.pins_hint": "Закрепите до {max} разделов, которые открываете чаще всего. В верхнем меню они тоже остаются.",
    "rail.pins_full": "В быстром доступе не больше {max} разделов — сначала открепите один", "rail.pins_count": "{n} из {max}",
    "rail.me": "Мои настройки",
    "ws.editing": "Настройка рабочего места",
    "ws.hint": "Перетаскивайте блоки или используйте ◀ ▶. ⅓ ⅔ ▭ — ширина, ↕ — высота, ✕ — скрыть блок. Изменения сохраняются автоматически.",
    "ws.preset": "Раскладка",
    "ws.hidden": "Скрытые блоки",
    "ws.reset": "Сбросить по умолчанию",
    "ws.done": "Готово",
    "ws.drag": "Перетащите, чтобы переместить", "ws.left": "Влево / выше", "ws.right": "Вправо / ниже",
    "ws.width": "Ширина", "ws.height": "Высота", "ws.hide": "Скрыть блок",
    "ws.saved": "Рабочее место сохранено",
    "h.auto": "авто", "h.s": "S", "h.m": "M", "h.l": "L",
    "wg.kpis": "Сводные карточки", "wg.active": "Активные задачи", "wg.background": "Фоновые задачи",
    "wg.notifications": "Уведомления", "wg.new": "Новые обращения", "wg.mine": "Назначены мне",
    "wg.pending": "В ожидании", "wg.calls": "Последние звонки",
    "preset.default": "По умолчанию", "preset.calls": "Фокус на звонках", "preset.tickets": "Фокус на тикетах",
    "preset.compact": "Компактный", "preset.focus": "Минимальный", "preset.custom": "Моя раскладка",
    "preset.default_d": "Командный центр: сводка сверху, работа слева, уведомления и звонки справа.",
    "preset.calls_d": "Для смен с большим потоком звонков: крупные звонки и уведомления рядом с задачами.",
    "preset.tickets_d": "Для работы с почтой и мессенджерами: широкие списки задач и обращений.",
    "preset.compact_d": "Всё на одном экране: плотные отступы, короткие блоки.",
    "preset.focus_d": "Только текущая работа: активные задачи, новые обращения, уведомления.",
    "set.title": "Мои настройки",
    "set.appearance": "Внешний вид",
    "set.theme": "Тема",
    "set.theme_system": "Как в системе", "set.theme_light": "Светлая", "set.theme_dark": "Тёмная (по умолчанию)",
    "set.compact": "Компактный режим (меньше отступов)",
    "set.workspace": "Раскладка рабочего места",
    "set.workspace_hint": "Выберите готовую раскладку или расставьте блоки сами. Сохраняется в учётной записи — одинаково на любом компьютере.",
    "set.current": "текущая",
    "set.alerts": "Звонки и уведомления",
    "set.sound": "Звуковой сигнал при входящем звонке",
    "set.account": "Учётная запись",
    "set.name": "Имя", "set.username": "Логин", "set.level": "Уровень", "set.position": "Должность", "set.role": "Роль",
    "set.interface": "Интерфейс", "set.interface_hint": "Всё о том, как выглядит Zenith Desk и как устроен ваш главный экран, — в одном месте. Сохраняется в учётной записи: одинаково на любом компьютере.",
    "set.look": "Стиль", "set.theme_motion": "Тема и анимация", "set.home": "Главный экран (Моё рабочее место)",
    "set.home_hint": "Как показывается ваша работа на «Моём рабочем месте». Во всех вариантах функции одинаковые.",
    "dash.standard": "Блоки", "dash.standard_d": "Блоки, которые вы расставляете сами («Настроить»): задачи, обращения, уведомления, звонки.",
    "dash.focus": "Фокус", "dash.focus_d": "Одна большая карточка со следующим делом; очередь и мои заявки сбоку.",
    "dash.board": "Доска", "dash.board_d": "Колонки по этапам: новые, в работе, назначены мне, в ожидании.",
    "dash.inbox": "Входящие", "dash.inbox_d": "Всё одним списком с фильтрами по виду и каналу; сегодня, уведомления и звонки сбоку.",
    "dash.table": "Таблица", "dash.table_d": "Плотная таблица всей вашей работы, одна заявка — одна строка.",
    "sn.layout": "Вид",
    "dl.now": "Сейчас в работе", "dl.next": "Следующее обращение", "dl.oldest_first": "сначала старые", "dl.nothing": "Здесь пусто — всё сделано",
    "dl.waiting": "ждёт", "dl.assigned": "назначено мне", "dl.start_blocks": "Приступить — звонки на паузе", "dl.skip": "Пропустить",
    "dl.queue": "Очередь", "dl.in_work": "В работе", "dl.no_work": "Ничего в работе", "dl.today": "Сегодня", "dl.answered": "Отвечено", "dl.d": "дн",
    "dl.f.all": "Все", "dl.f.new": "Новые", "dl.f.mine": "Мои", "dl.f.work": "В работе", "dl.f.pending": "В ожидании",
    "dl.k.active": "В работе · звонки на паузе", "dl.k.background": "Фоновая", "dl.k.new": "Новая", "dl.k.mine": "Назначена мне", "dl.k.pending": "В ожидании",
    "dl.col.title": "Заголовок", "dl.col.channel": "Канал", "dl.col.group": "Группа", "dl.col.status": "Статус", "dl.col.age": "Ждёт",
    "btn.bg_short": "Фоном",
    "set.style": "Стиль интерфейса", "set.style_hint": "Меняется только внешний вид: все функции работают так же, значки слева остаются на своих местах. Сохраняется в учётной записи — одинаково на любом компьютере.",
    "set.style_classic": "Классический", "set.style_classic_d": "Вид Command Center: верхняя панель, общая полоса показателей, списки, синие акценты.",
    "set.style_studio": "Studio", "set.style_studio_d": "Панель разделов со счётчиками, рабочая область в рамке, приветствие, отдельные карточки показателей, работа карточками со статусами, янтарные акценты.",
    "set.style_flow": "Flow", "set.style_flow_d": "Вид по умолчанию. Разделы — «таблетки» сверху (активная плавно переезжает), ваши инструменты на панели слева — статус, телефон, «Настроить» и до 5 разделов, закреплённых для быстрого доступа, — крупные заголовки, скруглённые карточки, плавная анимация.",
    "set.new": "новое",
    "av.title": "Фото профиля", "av.hint": "Ваше фото или первые буквы имени и фамилии. Коллеги видят его в мессенджере и в панели руководителя.",
    "av.upload": "Загрузить фото", "av.change": "Сменить фото", "av.delete": "Удалить фото", "av.use_photo": "Фото", "av.use_initials": "Инициалы",
    "av.saved": "Фото сохранено", "av.deleted": "Фото удалено — показываются инициалы", "av.type": "Выберите изображение JPEG, PNG или WebP", "av.busy": "Загрузка…",
    "st.morning": "Доброе утро, {name}", "st.afternoon": "Добрый день, {name}", "st.evening": "Добрый вечер, {name}",
    "sn.channels": "Каналы", "sn.comm": "Общение", "sn.period": "Период", "sn.level": "Уровень", "sn.state": "Состояние", "sn.team": "Команда",
    "sn.shift": "Начало смены", "sn.shift_close": "Скрыть на сегодня",
    "sn.ck_phone": "Телефон в сети", "sn.ck_phone_d": "Zenith Phone · вн. {ext}", "sn.ck_mail": "Войдите в почту", "sn.ck_mail_d": "Почта → e-mail и пароль",
    "sn.ck_ready": "Станьте «Готов»", "sn.ck_ready_d": "Звонки из очередей приходят вам", "sn.my_settings": "Мои настройки",
    "sn.hide": "Скрыть панель (открывается активным значком или кнопкой в верхней панели)", "sn.pin": "Закрепить панель рядом со значками",
    "set.panel": "Панель разделов (Studio)", "set.panel_docked": "Рядом со значками", "set.panel_docked_d": "Компактная панель всегда открыта рядом со значками; « скрывает её.",
    "set.panel_popup": "Всплывающая", "set.panel_popup_d": "Страница занимает всю ширину; разделы открываются поверх неё активным значком или кнопкой в верхней панели.",
    "theme.dark": "Тёмная тема",
    "theme.light": "Светлая тема",
    "kpi.blocking": "Активные задачи",
    "kpi.background": "Фоновые",
    "kpi.done": "Завершено сегодня",
    "kpi.calls": "Звонки сегодня",
    "kpi.calls_sub": "{a} принято · {m} пропущено",
    "kpi.busy": "Занят задачами сегодня",
    "kpi.busy_sub": "звонки на паузе",
    "ntf.title": "Уведомления",
    "ntf.empty": "Уведомлений нет",
    "ntf.mark_read": "Прочитано",
    "ntf.desktop": "Уведомления на рабочем столе",
    "ntf.desktop_on": "Уведомления на рабочем столе включены",
    "sup.assign": "Назначить тикет",
    "sup.assign_title": "Назначить / переназначить тикет",
    "sup.ticket_number": "Номер тикета",
    "sup.assign_to": "Оператор",
    "sup.mode": "Начать работу",
    "sup.mode_none": "Нет — только назначить",
    "sup.k.online": "Онлайн",
    "sup.k.ready": "Готовы",
    "sup.k.busy": "Заняты",
    "sup.k.break": "Перерыв",
    "sup.k.offline": "Не в системе",
    "sup.k.sync": "Ошибки синхронизации",
    "toast.assigned": "Тикет назначен",
    "call.desktop_title": "Входящий звонок",
    "login.hint": "Войдите с логином, который выдал администратор",
    "login.login": "Логин",
    "nav.work": "Моё рабочее место",
    "nav.sup": "Панель руководителя",
    "team.all": "Все",
    "btn.change_password": "Сменить пароль",
    "pw.title": "Смена пароля",
    "pw.forced": "Администратор просит задать собственный пароль перед началом работы.",
    "pw.current": "Текущий пароль",
    "pw.new": "Новый пароль (не менее 8 символов)",
    "pw.repeat": "Повторите новый пароль",
    "pw.mismatch": "Пароли не совпадают",
    "pw.changed": "Пароль изменён",
    "login.password": "Пароль",
    "login.submit": "Войти",
    "ext": "вн.",
    "btn.ready": "Готов",
    "btn.break": "Перерыв",
    "btn.logout": "Выход",
    "tab.work": "Моя работа",
    "tab.sup": "Руководитель",
    "state.ready": "Готов",
    "state.busy_task": "Занят задачей",
    "state.break": "Перерыв",
    "state.offline": "Не в системе",
    "state.wrap_up": "Постобработка",
    "state.ready_unconfirmed": "Готов — не подтверждено",
    "state.external_pause": "Пауза на телефоне",
    "src.phone": "Телефон", "src.email": "Email", "src.telegram": "Telegram", "src.whatsapp": "WhatsApp", "src.web": "Веб", "src.internal": "Внутр.",
    "call.ringing": "звонит", "call.answered": "разговор", "call.ended": "завершён", "call.missed": "пропущен",
    "banner.sse": "Нет связи с сервером. Состояние может быть неактуальным — система не считает вас готовым, пока связь не восстановится.",
    "banner.sync_error": "Ошибка синхронизации с телефонией",
    "banner.sync_pending": "Синхронизация с телефонией…",
    "banner.retry_at": "повтор в",
    "call.incoming": "Входящий звонок",
    "call.outgoing": "Исходящий звонок",
    "call.hidden": "скрытый номер",
    "call.queue": "очередь",
    "call.several": "Найдено несколько клиентов:",
    "call.no_tickets": "Тикетов нет",
    "call.not_found": "Клиент не найден по номеру.",
    "call.create_ticket": "Создать тикет по звонку",
    "call.open_ticket": "Открыть тикет звонка",
    "call.create_customer": "Создать клиента",
    "call.hide": "Скрыть",
    "panel.active": "Активные задачи",
    "panel.active_empty": "Нет блокирующих задач — звонки поступают, если вы готовы.",
    "panel.background": "Мои фоновые задачи",
    "panel.background_empty": "Нет фоновых задач",
    "panel.new": "Новые обращения",
    "panel.new_empty": "Нет неназначенных тикетов",
    "panel.mine": "Назначены мне",
    "panel.mine_empty": "Нет тикетов без активной работы",
    "panel.pending": "В ожидании",
    "panel.pending_empty": "Нет тикетов в ожидании",
    "panel.calls": "Последние звонки",
    "panel.calls_empty": "Звонков пока нет",
    "tag.blocking": "блокирует звонки",
    "tag.background": "не блокирует",
    "since": "с",
    "btn.start": "Приступить",
    "btn.background": "Фоновая задача",
    "btn.complete": "Завершить",
    "btn.postpone": "Отложить",
    "btn.remove": "Убрать",
    "btn.card": "Карточка / тикет",
    "link.ticket": "тикет",
    "link.recording": "запись",
    "hidden": "скрытый",
    "sup.ami_down": "Нет соединения с Asterisk (AMI). Паузы в очередях не управляются.",
    "sup.operators": "Операторы",
    "sup.refresh": "Обновить",
    "sup.col.operator": "Оператор",
    "sup.col.state": "Состояние",
    "sup.col.phone": "Телефония",
    "sup.col.tasks": "Задачи",
    "sup.synced": "сверка",
    "sup.cancel": "снять",
    "sup.reconcile": "Сверка",
    "sup.override": "Override",
    "sup.report": "Сводка за 24 часа",
    "sup.col.completed": "Завершено",
    "sup.col.blocking": "Блок. работа",
    "sup.col.background": "Фоновая",
    "sup.col.paused": "Пауза в очереди",
    "sup.col.errors": "Ошибки",
    "sup.audit": "Журнал событий",
    "sup.all": "все",
    "sup.operator": "оператор",
    "sup.ticket": "тикет",
    "modal.complete": "Завершить задачу",
    "modal.zammad_state": "Статус тикета в Zammad",
    "modal.note": "Внутренняя заметка (необязательно)",
    "modal.cancel": "Отмена",
    "modal.new_customer": "Новый клиент",
    "modal.firstname": "Имя",
    "modal.lastname": "Фамилия",
    "modal.phone": "Телефон",
    "modal.email": "Email",
    "modal.notes": "Заметка",
    "modal.create": "Создать",
    "modal.new_ticket": "Новый тикет",
    "modal.call_note": "Данные звонка (номер, время, call ID, запись) будут добавлены автоматически.",
    "modal.customer": "Клиент",
    "modal.choose": "— выберите —",
    "modal.type": "Тип",
    "modal.priority": "Приоритет",
    "prio.low": "низкий", "prio.normal": "обычный", "prio.high": "высокий",
    "modal.subject": "Тема",
    "modal.description": "Описание",
    "modal.save": "Сохранить",
    "modal.save_bg": "Сохранить как фоновую",
    "modal.save_start": "Сохранить и приступить",
    "modal.override": "Override",
    "modal.audit_note": "Действие записывается в журнал аудита.",
    "modal.state": "Состояние",
    "modal.ignore_blocking": "Вернуть в очередь, несмотря на блокирующие задачи",
    "modal.reason": "Причина",
    "modal.apply": "Применить",
    "toast.started_blocking": "Работа начата — входящие звонки приостановлены",
    "toast.started_background": "Добавлено в фоновые задачи",
    "toast.released": "Работа по тикету остановлена",
    "toast.completed": "Задача завершена",
    "toast.customer_created": "Клиент создан",
    "toast.ticket_created": "Тикет создан",
    "toast.reconciled": "Сверка выполнена",
    "toast.override": "Override применён",
    "toast.session_cancelled": "Сессия снята",
    "err.session_expired": "Сессия истекла",
    "err.status": "Ошибка {status}",
    "err.choose_customer": "Выберите или создайте клиента",
    "prompt.cancel": "Снять работу по тикету #{n}? Укажите причину:",
    "dur.h": "ч", "dur.min": "мин",
  },
};

for (const mod of [window.ZenithInbox, window.ZenithMail, window.ZenithManage, window.ZenithTeam, window.ZenithRouting]) if (mod) { Object.assign(I18N.en, mod.i18n.en); Object.assign(I18N.ru, mod.i18n.ru); }
if (window.ZenithPhone) {
  Object.assign(I18N.en, window.ZenithPhone.i18n.en);
  Object.assign(I18N.ru, window.ZenithPhone.i18n.ru);
}
if (window.AgentixTickets) {
  Object.assign(I18N.en, window.AgentixTickets.i18n.en);
  Object.assign(I18N.ru, window.AgentixTickets.i18n.ru);
}
if (window.AgentixAdmin) {
  Object.assign(I18N.en, window.AgentixAdmin.i18n.en);
  Object.assign(I18N.ru, window.AgentixAdmin.i18n.ru);
}


// ---------------- manager overview (v2.5)
Object.assign(I18N.en, {
  "nav.overview": "Overview",
  "ov.today": "Today", "ov.yesterday": "Yesterday", "ov.7d": "7 days", "ov.30d": "30 days",
  "ov.updated": "updated", "ov.refresh": "Refresh", "ov.loading": "Loading…",
  "ov.offered": "Incoming calls", "ov.answered": "answered", "ov.missed": "missed", "ov.missed_calls": "Missed calls",
  "ov.missed_sub": "{a} abandoned · {u} not answered", "ov.short": "+{n} short abandons (≤{s} s, not counted)",
  "ov.answer_rate": "Answer rate", "ov.abandon_rate": "abandon rate {p}",
  "ov.sl": "Service level", "ov.sl_sub": "answered within {s} s · target {p}",
  "ov.asa": "Avg speed of answer", "ov.longest": "longest wait {v}",
  "ov.aht": "Avg talk time", "ov.talk_total": "total talk {v}",
  "ov.outbound": "Outbound", "ov.outbound_sub": "{c} connected",
  "ov.live": "Right now", "ov.waiting": "waiting in queue", "ov.longest_now": "longest {v}", "ov.talking": "on a call",
  "ov.ready": "ready", "ov.busy": "busy", "ov.break": "on break", "ov.offline": "offline",
  "ov.calls_chart": "Calls by hour", "ov.calls_chart_day": "Calls by day", "ov.peak": "Peak: {l} · {n} calls",
  "ov.load_chart": "Staffing vs workload", "ov.load_agents": "Operators logged in", "ov.load_erl": "Talk load (Erlang)",
  "ov.load_hint": "Average number of operators logged in vs average number of calls in progress. When the two lines meet, everyone is on the phone.",
  "ov.team": "Team", "ov.occupancy": "occupancy", "ov.worked": "{n} operators worked", "ov.logged": "logged in {v}",
  "ov.top_calls": "Most calls answered", "ov.top_tickets": "Most tickets completed", "ov.none_yet": "No data yet",
  "ov.tickets": "Tickets", "ov.t_started": "taken into work", "ov.t_done": "completed", "ov.t_avg": "avg work time",
  "ov.t_active": "in work now: {b} blocking · {g} background",
  "ov.unreturned": "Missed callers not called back", "ov.unreturned_none": "Every missed caller was reached",
  "ov.attempts": "attempts: {n}", "ov.ago": "{n} min ago",
  "ov.agents": "Operators", "ov.sort": "Sort",
  "ov.col.operator": "Operator", "ov.col.now": "Now", "ov.col.logged": "Logged in", "ov.col.ready": "Ready",
  "ov.col.break": "Break", "ov.col.occ": "Occupancy", "ov.col.calls": "Calls", "ov.col.rona": "Not picked up",
  "ov.col.talk": "Talk · avg", "ov.col.tickets": "Tickets", "ov.col.score": "Engagement",
  "ov.calls_fmt": "{a} of {r}",
  "flag.rona": "Does not pick up", "flag.long_breaks": "Long breaks", "flag.low_occupancy": "Low load",
  "flag.rona_d": "The phone rang and the operator did not answer (no colleague had answered yet)",
  "flag.long_breaks_d": "Breaks take more than 20% of logged-in time",
  "flag.low_occupancy_d": "Less than 30% of available time spent on calls and tasks",
  "ov.legend.answered": "Answered", "ov.legend.missed": "Missed",
  "ov.how": "How the numbers are calculated",
  "ov.how.offered": "Incoming calls — customer calls that finished in the period (answered + abandoned + not answered). A call ringing several operators is counted once.",
  "ov.how.short": "Short abandon — the caller hung up within {s} seconds; excluded from all rates (most likely a wrong number).",
  "ov.how.rates": "Answer rate = answered ÷ (calls − short abandons). Service level = answered within {sl} s ÷ (calls − short abandons).",
  "ov.how.asa": "Average speed of answer — mean waiting time in the queue of answered calls. Talk time — from pick-up to hang-up.",
  "ov.how.rona": "Not picked up — the operator's phone rang and the operator did not answer while no colleague had answered yet (a ring cancelled because a colleague answered first is not counted).",
  "ov.how.time": "Logged in / Ready / Break — exact time in each state from the operator's state history. Occupancy = (talk + blocking tasks + wrap-up) ÷ (logged in − break).",
  "ov.how.score": "Engagement = 50% answer reliability (answered ÷ (answered + not picked up)) + 30% presence (1 − break share) + 20% occupancy against an 85% target. Shown after 10 minutes of work.",
  "ov.how.unreturned": "Missed callers not called back — numbers whose missed call was neither answered later nor called back.",
  "ov.how.load": "Workload — average operators logged in per hour vs talk load in Erlang (average number of calls in progress).",
  "dur.s": "s",
});
Object.assign(I18N.ru, {
  "nav.overview": "Обзор",
  "ov.today": "Сегодня", "ov.yesterday": "Вчера", "ov.7d": "7 дней", "ov.30d": "30 дней",
  "ov.updated": "обновлено", "ov.refresh": "Обновить", "ov.loading": "Загрузка…",
  "ov.offered": "Входящие звонки", "ov.answered": "принято", "ov.missed": "пропущено", "ov.missed_calls": "Пропущенные",
  "ov.missed_sub": "{a} сброшено · {u} без ответа", "ov.short": "+{n} коротких сбросов (≤{s} с, не учитываются)",
  "ov.answer_rate": "Доля принятых", "ov.abandon_rate": "доля сбросов {p}",
  "ov.sl": "Уровень сервиса", "ov.sl_sub": "ответ за {s} с · цель {p}",
  "ov.asa": "Среднее время ответа", "ov.longest": "макс. ожидание {v}",
  "ov.aht": "Средний разговор", "ov.talk_total": "всего разговоров {v}",
  "ov.outbound": "Исходящие", "ov.outbound_sub": "{c} дозвонились",
  "ov.live": "Сейчас", "ov.waiting": "ждут в очереди", "ov.longest_now": "дольше всех {v}", "ov.talking": "разговаривают",
  "ov.ready": "готовы", "ov.busy": "заняты", "ov.break": "на перерыве", "ov.offline": "не в сети",
  "ov.calls_chart": "Звонки по часам", "ov.calls_chart_day": "Звонки по дням", "ov.peak": "Пик: {l} · {n} звонков",
  "ov.load_chart": "Операторы и нагрузка", "ov.load_agents": "Операторов в сети", "ov.load_erl": "Нагрузка (Эрланг)",
  "ov.load_hint": "Среднее число операторов в сети и среднее число одновременных разговоров. Когда линии сходятся — заняты все.",
  "ov.team": "Команда", "ov.occupancy": "загрузка", "ov.worked": "работали {n} операторов", "ov.logged": "в сети {v}",
  "ov.top_calls": "Больше всех принял звонков", "ov.top_tickets": "Больше всех закрыл тикетов", "ov.none_yet": "Пока нет данных",
  "ov.tickets": "Тикеты", "ov.t_started": "взято в работу", "ov.t_done": "завершено", "ov.t_avg": "среднее время работы",
  "ov.t_active": "в работе сейчас: {b} blocking · {g} фоновых",
  "ov.unreturned": "Не перезвонили пропущенным", "ov.unreturned_none": "Со всеми пропущенными связались",
  "ov.attempts": "попыток: {n}", "ov.ago": "{n} мин назад",
  "ov.agents": "Операторы", "ov.sort": "Сортировка",
  "ov.col.operator": "Оператор", "ov.col.now": "Сейчас", "ov.col.logged": "В сети", "ov.col.ready": "Готов",
  "ov.col.break": "Перерыв", "ov.col.occ": "Загрузка", "ov.col.calls": "Звонки", "ov.col.rona": "Не взял трубку",
  "ov.col.talk": "Разговор · ср.", "ov.col.tickets": "Тикеты", "ov.col.score": "Вовлечённость",
  "ov.calls_fmt": "{a} из {r}",
  "flag.rona": "Не берёт трубку", "flag.long_breaks": "Долгие перерывы", "flag.low_occupancy": "Мало работы",
  "flag.rona_d": "Телефон звонил, оператор не ответил (коллеги ещё не ответили)",
  "flag.long_breaks_d": "Перерывы занимают больше 20% времени в сети",
  "flag.low_occupancy_d": "Меньше 30% доступного времени — звонки и задачи",
  "ov.legend.answered": "Принято", "ov.legend.missed": "Пропущено",
  "ov.how": "Как считаются показатели",
  "ov.how.offered": "Входящие звонки — звонки клиентов, завершившиеся в периоде (принятые + сброшенные + без ответа). Звонок, который звонил нескольким операторам, считается один раз.",
  "ov.how.short": "Короткий сброс — клиент положил трубку в течение {s} секунд; не учитывается в долях (скорее всего, ошибся номером).",
  "ov.how.rates": "Доля принятых = принятые ÷ (звонки − короткие сбросы). Уровень сервиса = принятые за {sl} с ÷ (звонки − короткие сбросы).",
  "ov.how.asa": "Среднее время ответа — среднее ожидание в очереди у принятых звонков. Разговор — от ответа до завершения.",
  "ov.how.rona": "Не взял трубку — телефон оператора звонил, а он не ответил, пока никто из коллег ещё не ответил (звонок, прерванный из-за ответа коллеги, не считается).",
  "ov.how.time": "В сети / Готов / Перерыв — точное время в каждом состоянии по истории статусов. Загрузка = (разговоры + blocking-задачи + постобработка) ÷ (в сети − перерыв).",
  "ov.how.score": "Вовлечённость = 50% надёжность ответа (принятые ÷ (принятые + не взял трубку)) + 30% присутствие (1 − доля перерывов) + 20% загрузка относительно цели 85%. Считается после 10 минут работы.",
  "ov.how.unreturned": "Не перезвонили — номера, чей пропущенный звонок не был принят позже и по которым не было исходящего звонка.",
  "ov.how.load": "Нагрузка — среднее число операторов в сети за час и нагрузка разговорами в Эрлангах (среднее число одновременных разговоров).",
  "dur.s": "с",
});

let LANG = "en";
let VERSION = "";
function t(key, params) {
  let s = (I18N[LANG] && I18N[LANG][key]) || I18N.en[key] || key;
  if (params) for (const [k, v] of Object.entries(params)) s = s.split(`{${k}}`).join(v);
  return s;
}

function uuid() {
  return (crypto.randomUUID && crypto.randomUUID()) || String(Date.now()) + Math.random().toString(16).slice(2);
}
const WIDGETS = ["kpis", "active", "background", "notifications", "new", "mine", "pending", "calls"];
const W = (id, w, h = "auto", hidden = false) => ({ id, w, h, hidden });
const PRESETS = {
  // Command Center: KPI strip, work column on the left (⅔), live side column on the right (⅓)
  default: { compact: false, layout: [W("kpis", 3), W("active", 2), W("notifications", 1, "m"), W("background", 2), W("calls", 1, "m"), W("new", 2), W("mine", 1), W("pending", 1)] },
  calls: { compact: false, layout: [W("kpis", 3), W("calls", 2, "l"), W("notifications", 1, "l"), W("active", 1, "m"), W("background", 1, "m"), W("new", 1, "m"), W("mine", 1, "s"), W("pending", 1, "s")] },
  tickets: { compact: false, layout: [W("kpis", 3), W("active", 2), W("notifications", 1, "m"), W("new", 2, "l"), W("mine", 1, "l"), W("background", 1), W("pending", 1), W("calls", 1, "s")] },
  compact: { compact: true, layout: [W("kpis", 3), W("active", 1, "s"), W("background", 1, "s"), W("notifications", 1, "s"), W("new", 1, "s"), W("mine", 1, "s"), W("pending", 1, "s"), W("calls", 1, "s")] },
  focus: { compact: false, layout: [W("active", 2), W("notifications", 1, "m"), W("new", 2, "m"), W("background", 1, "m"), W("kpis", 3, "auto", true), W("mine", 1, "auto", true), W("pending", 1, "auto", true), W("calls", 1, "auto", true)] },
};
const clone = (x) => JSON.parse(JSON.stringify(x));
const ICONS = {
  work: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  team: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0"/><circle cx="17" cy="9" r="2.4"/><path d="M15.5 14.2A5 5 0 0 1 21 19"/>',
  users: '<circle cx="12" cy="8" r="3.6"/><path d="M5 20.5a7 7 0 0 1 14 0"/>',
  plug: '<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0zM12 17v4"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.3"/>',
  pulse: '<path d="M3 12h4l3-7 4 14 3-7h4"/>',
  route: '<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="12" r="2.5"/><circle cx="6" cy="18" r="2.5"/><path d="M8.5 6H12a3 3 0 0 1 3 3v.5M8.5 18H12a3 3 0 0 0 3-3v-.5"/>',
  rec: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.2" fill="currentColor" stroke="none"/>',
  logs: '<path d="M8 6h12M8 12h12M8 18h12"/><circle cx="4" cy="6" r=".9" fill="currentColor"/><circle cx="4" cy="12" r=".9" fill="currentColor"/><circle cx="4" cy="18" r=".9" fill="currentColor"/>',
  ear: '<path d="M6 9.5a6 6 0 1 1 12 0c0 3.2-2.4 4.4-3.4 5.6-.9 1.1-.9 2.2-.9 3a2.9 2.9 0 0 1-5.4 1.5"/><path d="M9.5 9.5a2.5 2.5 0 0 1 5 0c0 1.4-1.2 2-1.8 2.8"/>',
  whisper: '<path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v7a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 4v-4h0A2.5 2.5 0 0 1 3 13.5"/><path d="M8.5 10h.01M12 10h.01M15.5 10h.01"/>',
  join: '<circle cx="8" cy="9" r="3"/><path d="M2.5 19a5.5 5.5 0 0 1 11 0"/><path d="M18 8v6M15 11h6"/>',
  download: '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5"/><path d="M5 19.5h14"/>',
  archive: '<rect x="3" y="4" width="18" height="5" rx="1.5"/><path d="M5 9v9.5A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5V9"/><path d="M12 12v5M9.5 14.5 12 17l2.5-2.5"/>',
  // gear: Lucide "settings" icon (ISC licence)
  gear: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
  out: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9.5h8M8 12.5h5"/>',
  send: '<path d="M4 12l16-8-6 16-2.5-6.5z"/><path d="M11.5 13.5L20 4"/>',
  check: '<path d="M5 12.5l4 4 10-10"/>',
  checks: '<path d="M2 12.5l4 4 10-10"/><path d="M11 16.5l1 0 10-10"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  sidebar: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M15 4v16"/>',
  panel: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M5.5 8h1M5.5 11h1M5.5 14h1"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  dnd: '<circle cx="12" cy="12" r="9"/><path d="M7.5 12h9"/>',
  // generic messenger glyphs (not brand logos): a round speech bubble and a paper plane
  wa: '<path d="M12 3.5a8.5 8.5 0 0 1 0 17 8.6 8.6 0 0 1-3.9-.9L3.5 20.5l1.2-4.2A8.5 8.5 0 0 1 12 3.5z"/><circle cx="8.6" cy="12" r=".6"/><circle cx="12" cy="12" r=".6"/><circle cx="15.4" cy="12" r=".6"/>',
  tg: '<path d="M21 4L3 11l6 2.2L18 7l-7.2 7.6.2 5.4 3-3.6 4 3z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5l8.5 6.5 8.5-6.5"/>',
  inbox: '<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1.5 2.5h5L16 13h5"/>',
  clip: '<path d="M20 11l-8.5 8.5a5 5 0 0 1-7-7L13 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L14 7"/>',
  note: '<path d="M5 4h14v12l-4 4H5z"/><path d="M15 20v-4h4"/>',
  reply: '<path d="M10 7L4 12l6 5"/><path d="M4 12h10a6 6 0 0 1 6 6"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="M6 6l12 12"/>',
  folder: '<path d="M3 6h6l2 2h10v11H3z"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
  briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5h6v2M3 13h18"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  at: '<circle cx="12" cy="12" r="4"/><path d="M16 12v1.5a2.5 2.5 0 0 0 5 0V12a9 9 0 1 0-4 7.5"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  popout: '<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1"/>',
  popin: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M14 9l-5 5M9 10v4h4"/>',
  minus: '<path d="M5 12h14"/>',
  spk: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  spkoff: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 10l4 4M21 10l-4 4"/>',
  voicemail: '<circle cx="6.5" cy="12" r="3.5"/><circle cx="17.5" cy="12" r="3.5"/><path d="M6.5 15.5h11"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  micoff: '<path d="M4 4l16 16"/><path d="M9 9v2a3 3 0 0 0 5 2.2M15 9.5V6a3 3 0 0 0-5.7-1.3"/><path d="M5 11a7 7 0 0 0 11.5 5.3M19 11a7 7 0 0 1-.6 2.8M12 18v3"/>',
  pause: '<path d="M9 5v14M15 5v14"/>',
  arrin: '<path d="M17 7 7 17M7 9v8h8"/>',
  arrout: '<path d="M7 17 17 7M9 7h8v8"/>',
  expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  tv: '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>',
  fwd: '<path d="M14 5l7 7-7 7M21 12H9a6 6 0 0 0-6 6"/>',
  grid: '<circle cx="6" cy="6" r="1.3"/><circle cx="12" cy="6" r="1.3"/><circle cx="18" cy="6" r="1.3"/><circle cx="6" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="18" cy="12" r="1.3"/><circle cx="6" cy="18" r="1.3"/><circle cx="12" cy="18" r="1.3"/><circle cx="18" cy="18" r="1.3"/>',
  ticket: '<path d="M4 6h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4z"/><path d="M14 6v2M14 11v2M14 16v2"/>',
  coffee: '<path d="M4 9h13v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 11h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 3.5v2.5M12 3.5v2.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/><circle cx="12" cy="8.5" r="1.8"/>',
};
// v3.19: the ZENITH. wordmark (drawn, not a font) — follows the text colour; the dot is the brand green.
const BRAND_PATH = "M0,0 L110,0 L110,24 L46,76 L110,76 L110,100 L0,100 L0,76 L64,24 L0,24Z M124,0 L216,0 L216,24 L164,24 L164,38 L208,38 L208,62 L164,62 L164,76 L216,76 L216,100 L124,100 L139,50Z M230,0 L258,0 L312,60 L312,0 L340,0 L340,100 L312,100 L258,40 L258,100 L230,100Z M354,0 L382,0 L382,100 L354,100Z M396,0 L502,0 L502,24 L463,24 L463,100 L435,100 L435,24 L396,24Z M516,0 L544,0 L544,38 L598,38 L598,0 L626,0 L626,100 L598,100 L598,62 L544,62 L544,100 L516,100Z";
const BrandWord = {
  props: { sub: { type: Boolean, default: true }, stack: { type: Boolean, default: false } },
  setup() { return { BRAND_PATH }; },
  template: `<span class="brand-word" :class="{stack}" role="img" aria-label="Zenith Desk"><svg class="bw-mark" viewBox="0 0 672 100" aria-hidden="true"><path fill="currentColor" :d="BRAND_PATH"/><circle class="bw-dot" cx="658" cy="86" r="14"/></svg><span v-if="sub" class="bw-sub" aria-hidden="true">DESK</span></span>`,
};

const Ico = {
  props: { name: String },
  setup(props) { return () => h("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 1.8,
    "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", innerHTML: ICONS[props.name] || "" }); },
};
function normalizeLayout(layout) {
  const seen = new Set(), out = [];
  for (const w of layout || []) if (WIDGETS.includes(w.id) && !seen.has(w.id)) { seen.add(w.id); out.push({ ...W(w.id, 1), ...w }); }
  for (const d of PRESETS.default.layout) if (!seen.has(d.id)) out.push(clone(d));  // blocks added in newer versions
  return out;
}

function loadTheme() { try { return localStorage.getItem("agentix_theme") || ""; } catch { return ""; } }
function applyTheme(theme) {
  document.documentElement.dataset.theme = effectiveTheme(theme);
  try { theme ? localStorage.setItem("agentix_theme", theme) : localStorage.removeItem("agentix_theme"); } catch { /* ignore */ }
}
function effectiveTheme(theme) {
  if (theme === "light" || theme === "dark") return theme;
  if (theme === "system") return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  return "dark";  // default look: dark console
}
applyTheme(loadTheme());

// ---------------- v3.12 interface style: "classic" (the Command Center look) or "studio"
const STYLES = ["classic", "studio", "flow"];  // v3.16: + "flow"
// v3.19 Flow: sections of the top menu a person may pin to the left tool rail (they stay in the top menu too)
const NAV_KEYS = ["work", "tickets", "contacts", "chat", "mail", "whatsapp", "telegram", "sup", "overview", "mtools", "admin"];
const PIN_MAX = 5;
const okStyle = (x) => (STYLES.includes(x) ? x : "flow");  // v3.19: Flow is the default look
function loadStyle() { try { return okStyle(localStorage.getItem("zenith_style")); } catch { return "flow"; } }
function applyStyle(style) {
  style = okStyle(style);
  document.documentElement.dataset.style = style;
  try { localStorage.setItem("zenith_style", style); } catch { /* ignore */ }
}
applyStyle(loadStyle());

// ---------------- v3.22 interface size: the whole page is zoomed («auto» fits the screen; phones stay at 100 %)
const ZOOMS = ["auto", "80", "90", "100", "110", "125"];
let zoomPref = (() => { try { const z = localStorage.getItem("zenith_zoom"); return ZOOMS.includes(z) ? z : "auto"; } catch { return "auto"; } })();
function autoZoom() {
  if (innerWidth <= 900) return 1;                         // phone / small tablet: the layout is made for it
  if (innerWidth < 1360) return 0.8;                        // small laptops (1280 × 720, 1366 at 125 %)
  if (innerWidth < 1600 || innerHeight < 860) return 0.85;  // laptops: more fits on the screen
  return 0.9;                                              // big screens: a little smaller than the browser's 100 %
}
function currentZoom() { return zoomPref === "auto" ? autoZoom() : (innerWidth <= 900 ? 1 : Number(zoomPref) / 100); }
function applyZoom(pref) {
  if (pref !== undefined) zoomPref = ZOOMS.includes(String(pref)) ? String(pref) : "auto";
  const z = currentZoom(), root = document.documentElement;
  root.style.zoom = z === 1 ? "" : String(z);
  root.style.setProperty("--z", String(z));  // 100vh / 100vw in the CSS are divided by it (they do not follow zoom)
  // media queries see the real window, not the zoomed page: the one-row Flow header needs ≥ 1361 page pixels
  root.classList.toggle("zd-wide", innerWidth > 900 && innerWidth / z >= 1361);
  try { localStorage.setItem("zenith_zoom", zoomPref); } catch { /* ignore */ }
}
// pointer coordinates and getBoundingClientRect() are screen pixels; style lengths are page pixels (÷ zoom)
window.zdZoom = () => parseFloat(document.documentElement.style.getPropertyValue("--z")) || 1;
applyZoom();
window.addEventListener("resize", () => { const before = window.zdZoom(); applyZoom(); if (window.zdZoom() !== before) window.dispatchEvent(new Event("zd-zoom")); });
const DASH_LAYOUTS = ["standard", "focus", "board", "inbox", "table"];  // v3.14: layouts of «My workplace»

// ---------------- v3.12 account picture: the photo, or the first letters of the first and last name
const nameInitials = (name) => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase() || "?";
const UserAvatar = {
  props: { name: String, url: String, cls: { type: [String, Array, Object], default: "" } },
  setup(props) {
    return () => h("span", { class: ["avatar", props.cls, { photo: !!props.url }], "aria-hidden": "true" },
      props.url ? [h("img", { src: props.url, alt: "", loading: "lazy", decoding: "async" })] : nameInitials(props.name));
  },
};
/** Cut the middle square of the chosen picture and shrink it to 256x256 in the browser (small upload, no EXIF). */
function squarePicture(file, size = 256) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const side = Math.min(img.naturalWidth, img.naturalHeight);
      if (!side) return reject(new Error("empty"));
      const c = document.createElement("canvas"); c.width = c.height = size;
      const g = c.getContext("2d"); g.imageSmoothingQuality = "high";
      g.drawImage(img, (img.naturalWidth - side) / 2, (img.naturalHeight - side) / 2, side, side, 0, 0, size, size);
      c.toBlob((b) => (b && b.type === "image/webp" ? resolve(b) : c.toBlob((j) => (j ? resolve(j) : reject(new Error("encode"))), "image/jpeg", 0.88)), "image/webp", 0.88);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("decode")); };
    img.src = url;
  });
}

// ---------------- motion (v2.6)
const reduceMotion = () => document.documentElement.dataset.motion === "off" ||
  (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
const canViewTransition = () => typeof document.startViewTransition === "function" && !reduceMotion();
if (typeof document.startViewTransition !== "function") document.documentElement.classList.add("no-vt");
/** Run a DOM change inside a View Transition (visual only: data and DOM change immediately). */
function withTransition(kind, change, opts = {}) {
  if (!canViewTransition()) { change(); return; }
  const root = document.documentElement;
  root.dataset.vt = kind;
  if (opts.dir) root.dataset.dir = opts.dir;
  if (opts.x !== undefined) { root.style.setProperty("--vx", opts.x + "px"); root.style.setProperty("--vy", opts.y + "px"); }
  try {
    let done = false;
    const run = () => { if (!done) { done = true; change(); } };
    const vt = document.startViewTransition(async () => { run(); await nextTick(); });
    vt.ready.catch(() => {}); vt.updateCallbackDone.catch(() => {});  // a skipped transition is not an error
    // the browser may hold the transition back (e.g. while the page is still being rendered right after loading):
    // the change itself must never wait for an animation
    setTimeout(() => { if (!done) { try { vt.skipTransition(); } catch { /* ignore */ } run(); } }, 250);
    vt.finished.catch(() => {}).finally(() => { delete root.dataset.vt; delete root.dataset.dir; });
  } catch { change(); delete root.dataset.vt; }
}
function applyMotion(on) { if (on === false) document.documentElement.dataset.motion = "off"; else delete document.documentElement.dataset.motion; }
/** Ripple + press feedback for buttons: the touch point becomes the centre of the wave. */
document.addEventListener("pointerdown", (ev) => {
  const el = ev.target.closest && ev.target.closest(".btn, .seg button, .level-filter button, .preset, .wt");
  if (!el || el.disabled || reduceMotion()) return;
  const r = el.getBoundingClientRect();
  const z = window.zdZoom ? window.zdZoom() : 1;  // v3.22: screen pixels → page pixels
  el.style.setProperty("--rx", (ev.clientX - r.left) / z + "px");
  el.style.setProperty("--ry", (ev.clientY - r.top) / z + "px");
  // a data attribute, not a class: Vue rewrites `class` when e.g. the pressed chip becomes active
  el.removeAttribute("data-ripple"); void el.offsetWidth; el.setAttribute("data-ripple", "");
  clearTimeout(el._rip); el._rip = setTimeout(() => el.removeAttribute("data-ripple"), 650);
}, { passive: true });
/** v-flash: a value that changes briefly lights up, so live numbers feel alive without moving. */
const flashDirective = {
  mounted(el) { el._txt = el.textContent; },
  updated(el) {
    if (el.textContent === el._txt) return;
    el._txt = el.textContent;
    if (reduceMotion()) return;
    el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
    clearTimeout(el._fl); el._fl = setTimeout(() => el.classList.remove("flash"), 900);
  },
};

function loadToken() { try { return localStorage.getItem("aws_token") || ""; } catch { return ""; } }
function saveToken(v) { try { v ? localStorage.setItem("aws_token", v) : localStorage.removeItem("aws_token"); } catch { /* ignore */ } }

const App = {
  setup() {
    const s = reactive({
      token: loadToken(), me: null, tab: "work", busy: false,
      login: { username: "", password: "" }, loginError: "", pw: { current_password: "", new_password: "", repeat: "", error: "" },
      config: { timezone: "Europe/Moscow", complete_states: ["closed"], ticket_types: [] },
      state: null, tasks: { blocking: [], background: [] }, mine: { active: [], pending: [] }, unassigned: [],
      calls: [], call: null, customers: [], customerCard: null, ticketsError: "",
      toasts: [], modal: null, form: {},
      sup: { agents: [], ami: true, audit: [], report: null, auditAgent: "", level: "", spy: null, spyEnabled: true, myExt: "", spyBusy: false,
             live: null, f: "all", sort: "level", day: null, dayLive: 0 },  // v3.18: queues + feed, board filter / sort, day card
      mgLive: 0, wallLive: 0,
      chat: { contacts: [], unread: 0, q: "", peer: null, gid: null, msgs: [], hasMore: false, loading: false, sending: false,
              info: false, profile: null, typing: {}, drafts: {}, text: "", menu: null, editing: null, del: null,
              files: [], emoji: false, emojiRecent: [], blobs: {}, drag: false, newGroup: null, addPeople: null, renaming: null, leaveAsk: false },
      push: "off", phoneOpen: false, phone: { status: "off", call: "idle", startedAt: 0, name: "" },
      msgCounts: {}, inOpen: null, mailUnseen: 0, mailOn: false, tkOpen: null, tkNew: null, ctOpen: null,
      ov: { data: null, period: "today", loading: false, updated: null, sort: "engagement", hover: -1, cw: 720 },
      sse: "connecting", liveAt: null, clock: Date.now(), navOpen: false, idleLocal: false, idleWarn: 0, idleSince: null, theme: loadTheme(),
      prefs: { theme: loadTheme(), style: loadStyle(), panel: "docked", dash: "standard", sound: true, compact: false, motion: true, preset: "default", layout: clone(PRESETS.default.layout), pins: [] },
      narrow: !!(window.matchMedia && window.matchMedia("(max-width: 900px)").matches), mailConnected: false, avatarBusy: false, shiftHidden: false, snOpen: false, shiftOpen: false, focusSkip: 0, dlKind: "all", dlCh: "", dlTable: "all",
      editing: false, dragId: null, overId: null,
      dash: null, ntf: { items: [], unread: 0, seen_at: null }, ntfOpen: false, pinOpen: false, navWrap: false,
      desktop: (window.Notification && Notification.permission) || "unsupported",
    });
    let es = null;
    const locale = LANG === "ru" ? "ru-RU" : "en-GB";

    const stateText = (st) => t(`state.${st}`);
    const srcText = (src) => (src ? t(`src.${src}`) : "");
    const SRC_ICON = { phone: "phone", email: "mail", telegram: "tg", whatsapp: "wa", web: "chat", internal: "users" };
    const srcIcon = (src) => SRC_ICON[src] || "ticket";
    const callText = (st) => t(`call.${st}`);

    const fmt = (iso, withDate) => {
      if (!iso) return "";
      try {
        return new Intl.DateTimeFormat(locale, {
          timeZone: s.config.timezone, hour: "2-digit", minute: "2-digit",
          ...(withDate ? { day: "2-digit", month: "2-digit" } : {}),
        }).format(new Date(iso));
      } catch { return iso; }
    };
    const dur = (sec) => {
      sec = Math.max(0, Math.round(sec || 0));
      const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
      return h ? `${h} ${t("dur.h")} ${m} ${t("dur.min")}` : `${m} ${t("dur.min")}`;
    };
    const toast = (text, kind = "", onClick = null) => {
      const item = { id: uuid(), text, kind, onClick };
      s.toasts.push(item);
      setTimeout(() => { s.toasts = s.toasts.filter((x) => x.id !== item.id); }, kind === "error" ? 8000 : kind === "chat" ? 6000 : 4000);
    };
    const toastClick = (x) => { if (x.onClick) { x.onClick(); s.toasts = s.toasts.filter((y) => y.id !== x.id); } };

    let signingOut = false;  // v3.20.2: set while logout() revokes the token
    async function api(method, path, body, opts = {}) {
      const headers = { "Content-Type": "application/json" };
      if (s.token) headers.Authorization = `Bearer ${s.token}`;
      if (opts.idem) headers["Idempotency-Key"] = opts.idem;
      const r = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
      let data = null, broken = false;
      const text = await r.text().catch(() => { broken = true; return ""; });
      if (text) { try { data = JSON.parse(text); } catch { broken = true; } }
      // v3.20.2: while this page signs out, its own late requests meet the revoked token — they just never finish
      if (r.status === 401 && signingOut) return new Promise(() => {});
      if (r.status === 401 && path !== "/api/auth/login") { logoutLocal(); throw new Error(t("err.session_expired")); }
      // a cut / unreadable answer is an error, never «no data» (the page would otherwise lose its lists)
      if (r.ok && broken) { const err = new Error(t("err.status", { status: r.status })); err.status = r.status; throw err; }
      if (!r.ok) {
        const d = data && data.detail;
        const msg = typeof d === "string" ? d : (d && d.message) || (Array.isArray(d) ? d.map((x) => x.msg).join("; ") : t("err.status", { status: r.status }));
        const err = new Error(msg); err.status = r.status; err.detail = d; throw err;
      }
      return data;
    }
    // v3.10: upload a big file as the raw request body (with progress) — backups
    function uploadFile(path, file, onProgress) {
      return new Promise((resolve, reject) => {
        const x = new XMLHttpRequest();
        x.open("PUT", path);
        if (s.token) x.setRequestHeader("Authorization", `Bearer ${s.token}`);
        x.setRequestHeader("Content-Type", "application/octet-stream");
        x.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100)); };
        x.onload = () => {
          let data = null;
          try { data = JSON.parse(x.responseText); } catch { /* empty */ }
          if (x.status >= 200 && x.status < 300) resolve(data);
          else { const d = data && data.detail; reject(new Error(typeof d === "string" ? d : (d && d.message) || t("err.status", { status: x.status }))); }
        };
        x.onerror = () => reject(new Error(t("err.status", { status: 0 })));
        x.send(file);
      });
    }
    async function act(fn, okKey) {
      if (s.busy) return;
      s.busy = true;
      try { const res = await fn(); if (okKey) toast(t(okKey)); return res; }
      catch (e) { toast(e.message, "error"); }
      finally { s.busy = false; }
    }

    // ------------------------------------------------------------ auth
    async function doLogin() {
      s.loginError = "";
      try {
        const r = await api("POST", "/api/auth/login", s.login);
        s.token = r.token; saveToken(r.token); s.login.password = "";
        await boot();
      } catch (e) { s.loginError = e.message; }
    }
    function logoutLocal() { s.token = ""; s.me = null; saveToken(""); if (es) es.close(); }
    // v3.20.2 (SEC-07): sign-out revokes the token on the server. The live stream is closed first; requests of this
    // page that still meet the revoked token are dropped quietly (see api()), not shown as «Session expired».
    async function logout() {
      signingOut = true;
      if (es) es.close();  // no live events (and no refreshes they would start) while the token is revoked
      try { await api("POST", "/api/auth/logout"); } catch { /* offline: the token still ends at its normal expiry */ }
      logoutLocal();
      signingOut = false;
    }

    // ------------------------------------------------------------ data
    async function refreshState() { s.state = await api("GET", "/api/agents/me/state"); }
    async function refreshTasks() {
      s.tasks = await api("GET", "/api/agents/me/tasks");
      api("GET", "/api/agents/me/dashboard").then((d) => { s.dash = d; }).catch(() => {});
    }
    async function refreshNotifications() {
      try { const r = await api("GET", "/api/agents/me/notifications?limit=30"); if (r && Array.isArray(r.items)) s.ntf = r; } catch { /* ignore */ }  // never replace the list with an empty answer
    }
    async function markRead() {
      try { await api("POST", "/api/agents/me/notifications/seen"); } catch { /* ignore */ }
      s.ntf.seen_at = new Date().toISOString(); s.ntf.unread = 0;
    }
    function toggleNtf() {
      s.ntfOpen = !s.ntfOpen;
      if (s.ntfOpen && s.ntf.unread) markRead();
    }
    const isUnread = (n) => !s.ntf.seen_at || n.ts > s.ntf.seen_at;
    const ntfIcon = (n) => ({ sync: "SY", ticket: "#", override: "MG", call: "CL", account: "AC", backup: "BK", shift: "SH" }[n.kind] || "•");
    async function enableDesktop() {
      if (!window.Notification) return;
      s.desktop = await Notification.requestPermission();
    }
    function ring(call) {
      if (s.prefs.sound) try {  // short two-tone beep, no audio files needed
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [0, 0.25].forEach((at, i) => {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.frequency.value = i ? 660 : 880; o.connect(g); g.connect(ctx.destination);
          g.gain.setValueAtTime(0.15, ctx.currentTime + at); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + at + 0.2);
          o.start(ctx.currentTime + at); o.stop(ctx.currentTime + at + 0.21);
        });
      } catch { /* audio not allowed */ }
      if (document.hidden && window.Notification && Notification.permission === "granted") {
        try { new Notification(t("call.desktop_title"), { body: call.caller_number || "", tag: "agentix-call" }); } catch { /* ignore */ }
      }
    }
    function toggleTheme(ev) {
      const next = effectiveTheme(s.theme) === "dark" ? "light" : "dark";
      const r = ev && ev.currentTarget && ev.currentTarget.getBoundingClientRect ? ev.currentTarget.getBoundingClientRect() : null;
      withTransition("theme", () => setTheme(next), r ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : { x: 36, y: innerHeight - 160 });
    }
    function setTheme(theme) {
      s.theme = theme; s.prefs.theme = theme; applyTheme(theme);
      if (s.me) savePrefs(true);  // at once: a reload right after the switch must not bring the old theme back
    }
    function setZoom(z) { s.prefs.zoom = z; applyZoom(z); savePrefs(true); window.dispatchEvent(new Event("zd-zoom")); }
    function toggleMotion() { s.prefs.motion = !s.prefs.motion; applyMotion(s.prefs.motion); savePrefs(); }
    // ---------------- personal preferences & workspace layout
    let saveTimer = null;
    function savePrefs(immediate) {
      clearTimeout(saveTimer);
      const run = () => api("PUT", "/api/agents/me/preferences", s.prefs).catch((e) => toast(e.message, "error"));
      if (immediate) return run();
      saveTimer = setTimeout(run, 500);
    }
    function loadPrefs(p) {
      p = p || {};
      const base = p.layout && p.layout.length ? p.layout : (PRESETS[p.preset] || PRESETS.default).layout;
      s.prefs = { theme: p.theme !== undefined ? p.theme : s.theme, style: okStyle(p.style), panel: p.panel === "popup" ? "popup" : "docked",
                  dash: DASH_LAYOUTS.includes(p.dash) ? p.dash : "standard", sound: p.sound !== false, compact: !!p.compact,
                  motion: p.motion !== false, preset: p.preset || "default", layout: normalizeLayout(clone(base)),
                  pins: Array.isArray(p.pins) ? p.pins.filter((k) => NAV_KEYS.includes(k)).slice(0, PIN_MAX) : [],
                  zoom: ZOOMS.includes(p.zoom) ? p.zoom : "auto" };
      applyZoom(s.prefs.zoom);
      applyMotion(s.prefs.motion);
      applyStyle(s.prefs.style);
      if (p.theme !== undefined) { s.theme = s.prefs.theme; applyTheme(s.theme); }
    }
    const presetIds = Object.keys(PRESETS);
    const visibleLayout = computed(() => s.prefs.layout.filter((w) => !w.hidden));
    const hiddenWidgets = computed(() => s.prefs.layout.filter((w) => w.hidden));
    const widgetName = (id) => t(`wg.${id}`);
    function changed() { s.prefs.preset = "custom"; savePrefs(); }
    function applyPreset(name) {
      if (!PRESETS[name]) return;
      s.prefs.layout = normalizeLayout(clone(PRESETS[name].layout));
      s.prefs.compact = PRESETS[name].compact; s.prefs.preset = name;
      savePrefs();
    }
    function moveW(i, dir) {
      const vis = visibleLayout.value, a = vis[i], b = vis[i + dir];
      if (!b) return;
      const L = s.prefs.layout, ia = L.indexOf(a), ib = L.indexOf(b);
      [L[ia], L[ib]] = [L[ib], L[ia]]; changed();
    }
    function setW(w, n) { w.w = n; changed(); }
    function cycleH(w) { const o = ["auto", "s", "m", "l"]; w.h = o[(o.indexOf(w.h) + 1) % o.length]; changed(); }
    function hideW(w) { w.hidden = true; changed(); }
    function showW(w) { w.hidden = false; const L = s.prefs.layout; L.splice(L.indexOf(w), 1); L.push(w); changed(); }
    function dragStart(w, e) { if (!s.editing) return; s.dragId = w.id; try { e.dataTransfer.setData("text/plain", w.id); e.dataTransfer.effectAllowed = "move"; } catch { /* ignore */ } }
    function dropOn(target) {
      const L = s.prefs.layout, from = L.findIndex((x) => x.id === s.dragId), to = L.indexOf(target);
      s.dragId = null; s.overId = null;
      if (from < 0 || to < 0 || from === to) return;
      const [item] = L.splice(from, 1); L.splice(to, 0, item); changed();
    }
    function startEditing() { s.tab = "work"; s.editing = true; s.navOpen = false; }
    function finishEditing() { s.editing = false; savePrefs(true); toast(t("ws.saved")); }
    function toggleSound() { s.prefs.sound = !s.prefs.sound; savePrefs(); }
    function toggleCompact() { s.prefs.compact = !s.prefs.compact; savePrefs(); }
    const levelText = (l) => (l ? t(`level.${l}`) : "");
    async function refreshTickets() {
      const [mine, un] = await Promise.all([api("GET", "/api/agents/me/tickets"), api("GET", "/api/tickets/unassigned")]);
      s.ticketsError = mine.error || un.error || "";
      s.mine = mine; s.unassigned = un.tickets || [];
    }
    async function refreshCalls() { s.calls = await api("GET", "/api/agents/me/calls?limit=15"); }
    async function refreshAll() {
      await Promise.allSettled([refreshState(), refreshTasks(), refreshTickets(), refreshCalls(), refreshNotifications()]);
      if (isSup.value && s.tab === "sup") await refreshSup();
    }
    async function refreshSup() {
      const [a, audit, rep, live] = await Promise.all([
        api("GET", "/api/admin/agents"),
        api("GET", "/api/admin/audit?limit=60" + (s.sup.auditAgent ? `&agent_id=${s.sup.auditAgent}` : "")),
        api("GET", "/api/admin/reports/summary"),
        api("GET", "/api/admin/team/live?feed=50").catch(() => null),
      ]);
      if (a.now && window.ZenithTeam) window.ZenithTeam.tick.skew = new Date(a.now).getTime() - Date.now();  // timers follow the server's clock
      s.sup.agents = a.agents; s.sup.ami = a.ami_connected; s.sup.audit = audit; s.sup.report = rep; s.sup.live = live;
      s.sup.spy = a.spy || null; s.sup.spyEnabled = a.spy_enabled !== false; s.sup.myExt = a.my_extension || "";
    }

    // ---------------- live mode (v2.7): the server pushes `changed` after every commit
    const live = { last: Date.now(), timers: {}, backoff: 1000, wasLost: false };
    /** Coalesce a burst of events into one refresh; the first event fixes the moment (bounded delay). */
    function soon(key, fn, ms) {
      if (live.timers[key]) return;
      live.timers[key] = setTimeout(() => { delete live.timers[key]; Promise.resolve().then(fn).catch(() => {}); }, ms);
    }
    async function refreshMe() {
      const m = await api("GET", "/api/auth/me");
      const { prefs, ...rest } = m;  // keep the layout the user may be editing right now
      Object.assign(s.me, rest);
      if (m.must_change_password) s.modal = "password";
      const allowed = { work: isOperatorView.value, tickets: isOperatorView.value, sup: isSup.value, overview: isSup.value,
                        shifts: isSup.value, log: isSup.value, recordings: isSup.value, wallboard: isSup.value, callrouting: isSup.value };  // v3.17.1: recordings — managers and admins only
      if (s.tab in allowed && !allowed[s.tab]) s.tab = isOperatorView.value ? "work" : "users";
    }
    async function refreshConfig() { s.config = await api("GET", "/api/config"); applyPhoneFlag(); }
    function applyPhoneFlag() { document.documentElement.classList.toggle("phone-on", !!(s.config.phone_enabled && isOperatorView.value)); }

    // ---------------- inactivity pause (v2.8)
    // Any mouse / keyboard / touch / scroll in any Zenith Desk tab counts. The server keeps the last moment and is the
    // final judge (it pauses people even if their browser is asleep); the browser just reacts at the exact second.
    const idle = { lastAct: Date.now(), lastSent: 0, lastShared: 0 };
    const IDLE_KEY = "agentix_last_activity";
    function idleTimeoutMs() {
      try { const test = +localStorage.getItem("agentix_idle_test_ms"); if (test > 0) return test; } catch { /* ignore */ }
      return Math.max(0, (s.config.idle_timeout_min || 0) * 60000);
    }
    const isFrozen = computed(() => !!(s.me && (s.idleLocal || (s.state && s.state.idle_since))));
    function markActive() {
      if (!s.me || isFrozen.value) return;
      const now = Date.now();
      idle.lastAct = now; s.idleWarn = 0;
      if (now - idle.lastShared > 5000) { idle.lastShared = now; try { localStorage.setItem(IDLE_KEY, String(now)); } catch { /* ignore */ } }
      if (now - idle.lastSent > 60000) { idle.lastSent = now; api("POST", "/api/agents/me/activity").catch(() => {}); }
    }
    let moveT = 0;
    for (const evName of ["pointerdown", "keydown", "wheel", "touchstart"]) window.addEventListener(evName, markActive, { passive: true });
    window.addEventListener("pointermove", () => { const n = Date.now(); if (n - moveT > 1000) { moveT = n; markActive(); } }, { passive: true });
    setInterval(async () => {
      const limit = idleTimeoutMs();
      if (!s.me || !limit || isFrozen.value || s.modal === "password") { s.idleWarn = 0; return; }
      let last = idle.lastAct;
      try { last = Math.max(last, +localStorage.getItem(IDLE_KEY) || 0); } catch { /* ignore */ }
      const left = limit - (Date.now() - last);
      const warnWindow = Math.min(120000, limit / 2);
      s.idleWarn = left > 0 && left <= warnWindow ? Math.ceil(left / 1000) : 0;
      if (left <= 0) {
        s.idleLocal = true; s.idleSince = new Date().toISOString();
        try { const r = await api("POST", "/api/agents/me/idle"); if (r && r.agent_id === s.me.id) s.state = r; } catch { /* server will do it */ }
      }
    }, 1000);
    async function resumeIdle() {
      try {
        const r = await api("POST", "/api/agents/me/resume");
        s.idleLocal = false; s.idleWarn = 0;
        if (r && r.agent_id === s.me.id) s.state = r; else if (s.state) s.state = { ...s.state, idle_since: null };
        idle.lastAct = idle.lastSent = Date.now();
        try { localStorage.setItem(IDLE_KEY, String(Date.now())); } catch { /* ignore */ }
        if (!isAdmin.value) refreshAll();
      } catch (err) { toast(err.message, "error"); }
    }
    const idleSinceText = computed(() => fmt((s.state && s.state.idle_since) || s.idleSince));
    function onChanged(topics) {
      s.liveAt = new Date().toISOString();
      const op = s.me && !isAdmin.value;
      for (const tp of topics) {
        if (tp === "tasks" && op) soon("tasks", refreshTasks, 30);
        else if (tp === "calls" && op) soon("calls", refreshCalls, 30);
        else if (tp === "notifications" && s.me) soon("ntf", refreshNotifications, 60);  // v3.10: admins too (backup)
        else if (tp === "tickets" && op) soon("tickets", refreshTickets, 80);
        else if (tp === "me") soon("me", refreshMe, 30);
        else if (tp === "config") soon("config", refreshConfig, 80);
        else if (tp === "team") {
          if (s.tab === "sup") { soon("sup", refreshSup, 100); soon("day", () => { s.sup.dayLive++; }, 600); }
          if (s.tab === "wallboard") soon("wall", () => { s.wallLive++; }, 400);  // v3.18 TV mode
          if (s.tab === "overview") soon("ov", () => refreshOverview(true), 250);
          if (["shifts", "recordings", "log", "callrouting"].includes(s.tab)) soon("mg", () => { s.mgLive++; }, 1500);  // v3.15 manager tools
        }
      }
      window.dispatchEvent(new CustomEvent("agentix:changed", { detail: { topics } }));  // admin pages listen too
    }
    function resyncAfterReconnect() {
      refreshChatUnread();
      if (s.tab === "chat") { loadContacts().catch(() => {}); if (s.chat.peer) openChat({ id: s.chat.peer }); }
      if (!isAdmin.value) refreshAll(); else refreshNotifications();
      if (s.tab === "sup") refreshSup().catch(() => {});
      if (s.tab === "overview") refreshOverview(true);
      window.dispatchEvent(new CustomEvent("agentix:changed", { detail: { topics: ["team", "users", "config"] } }));
    }
    // watchdog: the server sends `ping` every 15 s; silence for 35 s means a dead connection -> reconnect
    setInterval(() => {
      if (s.me && es && Date.now() - live.last > 35000) { s.sse = "lost"; live.wasLost = true; connectSSE(); }
    }, 5000);
    const wake = () => { if (s.me && es && (Date.now() - live.last > 20000 || es.readyState === 2)) { live.wasLost = true; connectSSE(); } };
    window.addEventListener("online", wake);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) wake(); });

    let sseSeq = 0;
    async function connectSSE() {
      if (es) es.close();
      s.sse = s.sse === "ok" ? "connecting" : s.sse;
      live.last = Date.now();
      const my = ++sseSeq;
      // v3.17: the stream is opened with a 60-second ticket, never with the session token in the address
      let ticket;
      try { ticket = (await api("POST", "/api/auth/stream-token")).token; }
      catch { if (my === sseSeq && s.me) { s.sse = "lost"; setTimeout(() => { if (s.me && my === sseSeq) connectSSE(); }, Math.min(live.backoff *= 2, 15000)); } return; }
      if (my !== sseSeq || !s.me) return;
      if (es) es.close();
      es = new EventSource(`/api/events/stream?token=${encodeURIComponent(ticket)}`);
      const alive = () => { live.last = Date.now(); };
      es.onopen = () => {
        alive(); s.sse = "ok"; live.backoff = 1000;
        resyncAfterReconnect();  // anything that happened while disconnected is loaded now
        live.wasLost = false;
      };
      es.onerror = () => {
        s.sse = "lost"; live.wasLost = true;
        if (es.readyState === 2) {  // the browser gave up (e.g. the session ended): check, then retry with backoff
          api("GET", "/api/auth/me").then(() => {
            const wait = live.backoff; live.backoff = Math.min(live.backoff * 2, 15000);
            setTimeout(() => { if (s.me) connectSSE(); }, wait);
          }).catch(() => {});
        }
      };
      es.addEventListener("hello", alive);
      es.addEventListener("ping", alive);
      es.addEventListener("changed", (ev) => { alive(); onChanged(JSON.parse(ev.data).topics || []); });
      es.addEventListener("me_changed", (ev) => { alive(); if (s.me) Object.assign(s.me, JSON.parse(ev.data)); });
      es.addEventListener("chat", (ev) => { alive(); onChatEvent(JSON.parse(ev.data)); });
      es.addEventListener("chat_read", (ev) => { alive(); onChatRead(JSON.parse(ev.data)); });
      es.addEventListener("chat_update", (ev) => { alive(); onChatUpdate(JSON.parse(ev.data)); });
      es.addEventListener("chat_typing", (ev) => { alive(); onChatTyping(JSON.parse(ev.data)); });
      es.addEventListener("chat_group", (ev) => { alive(); onChatGroup(JSON.parse(ev.data)); });  // v3.20
      es.addEventListener("chat_group_read", () => { alive(); soon("chatUnread", refreshChatUnread, 60); });
      es.addEventListener("agent_state", (e) => {
        live.last = Date.now();
        const d = JSON.parse(e.data);
        if (s.me && d.agent_id === s.me.id) { s.state = d; refreshTasks(); refreshNotifications(); }
        const i = s.sup.agents.findIndex((a) => a.agent_id === d.agent_id);
        if (i >= 0) s.sup.agents[i] = { ...s.sup.agents[i], ...d };
      });
      es.addEventListener("spy", (e) => { alive(); onSpyEvent(JSON.parse(e.data)); });  // v3.15 call supervision
      es.addEventListener("phone_demo", (e) => { alive(); window.dispatchEvent(new CustomEvent("zenith:phone_demo", { detail: JSON.parse(e.data) })); });
      es.addEventListener("call_ringing", (e) => {
        const d = JSON.parse(e.data);
        if (d.call && d.call.direction === "out") { refreshCalls(); return; }  // own call from Zenith Phone: no call card
        s.call = d.call; s.customers = d.customers || []; s.customerCard = null; s.tab = "work";
        if (s.customers.length === 1) openCustomer(s.customers[0].id);
        ring(d.call);
        refreshCalls();
      });
      for (const ev of ["call_answered", "call_ended", "call_missed", "call_updated"]) {
        es.addEventListener(ev, (e) => {
          const d = JSON.parse(e.data);
          window.dispatchEvent(new CustomEvent("zenith:call_update", { detail: d.call }));  // demo phone stops ringing
          if (s.call && s.call.id === d.call.id) s.call = d.call;
          refreshCalls();
          if (ev === "call_missed" || ev === "call_ended") { refreshNotifications(); refreshTasks(); }
        });
      }
      es.addEventListener("alert", (e) => { toast(JSON.parse(e.data).text, "error"); refreshNotifications(); });
      // v3.10: the whole system was restored from a backup — users, settings and data are different now
      es.addEventListener("system_restored", () => { toast(t("bk.restored_reload")); setTimeout(() => location.reload(), 2500); });
      es.addEventListener("ticket_changed", (e) => {
        alive(); const d = JSON.parse(e.data);
        window.dispatchEvent(new CustomEvent("agentix:ticket_changed", { detail: d }));
        if (!isAdmin.value) soon("tickets", refreshTickets, 150);
      });
      es.addEventListener("ticket_assigned", (e) => {
        alive(); const d = JSON.parse(e.data);
        toast(t("tk.assigned_toast", { by: d.by || "Zammad", n: d.number }), "chat", () => openTicket(d.ticket_id));
        ring({ caller_number: "#" + d.number });
        refreshNotifications();
      });
      // v3.9 chats (Telegram / WhatsApp) and e-mail
      es.addEventListener("msg", (e) => {
        alive(); const d = JSON.parse(e.data);
        window.dispatchEvent(new CustomEvent("zenith:msg", { detail: d }));
        soon("msgcounts", refreshMsgCounts, 300);
      });
      es.addEventListener("msg_new", (e) => {
        alive(); const d = JSON.parse(e.data);
        const here = (s.tab === "whatsapp" || s.tab === "telegram") && !document.hidden;
        if (!here) {
          toast(d.assigned_by ? t("in.tr_done", { name: s.me.name }) + " · " + d.name : t("in.new_msg", { ch: d.channel === "whatsapp" ? "WhatsApp" : "Telegram", name: d.name }) + (d.text ? ": " + d.text : ""),
                "chat", () => openConversation(d.conversation_id, d.channel));
          ring({ caller_number: d.name });
        }
        soon("msgcounts", refreshMsgCounts, 300);
      });
      es.addEventListener("mail", (e) => {
        alive(); const d = JSON.parse(e.data);
        s.mailUnseen = d.unseen || 0;
        window.dispatchEvent(new CustomEvent("zenith:mail", { detail: d }));
      });
      es.addEventListener("mail_new", (e) => {
        alive(); const d = JSON.parse(e.data);
        s.mailUnseen = d.unseen || s.mailUnseen;
        if (s.tab !== "mail" || document.hidden) toast(t("ml.new_mail", { from: d.from || "?" }) + (d.subject ? ": " + d.subject : ""), "chat", () => setTab("mail"));
        window.dispatchEvent(new CustomEvent("zenith:mail", { detail: d }));
      });
      es.addEventListener("directory_new", (e) => {
        alive(); const d = JSON.parse(e.data);
        for (const p of (d.items || []).slice(0, 3)) toast(t("ct.new_toast", { name: p.name }), "chat", () => openContact(p.id, p.kind === "staff" ? "staff" : "customers"));
      });
    }

    async function boot() {
      try {
        s.me = await api("GET", "/api/auth/me");
        loadPrefs(s.me.prefs);
        if (s.me.must_change_password) { s.modal = "password"; return; }
        s.config = await api("GET", "/api/config");
        applyPhoneFlag();
        refreshChatUnread();
        refreshMsgCounts();
        refreshMail();
        registerSW().then(refreshPushState);
        const openId = +new URLSearchParams(location.search).get("chat");
        if (openId) { history.replaceState(null, "", "/"); setTab("chat"); openChat({ id: openId }); }
        if (new URLSearchParams(location.search).get("wall") && isSup.value) s.tab = "wallboard";  // v3.18: a TV opens /?wall=1
        const openTk = +new URLSearchParams(location.search).get("ticket");
        if (openTk) { history.replaceState(null, "", "/"); if (s.me.role !== "admin") openTicket(openTk); }
        if (s.me.role === "admin" && ["work"].includes(s.tab)) s.tab = "users";
        if (s.me.role !== "admin") await refreshAll(); else refreshNotifications();
        connectSSE();
      } catch (e) { if (s.token) toast(e.message, "error"); }
    }

    // ------------------------------------------------------------ operator actions
    const goReady = () => act(async () => { s.state = await api("POST", "/api/agents/me/ready", undefined, { idem: uuid() }); });
    const goBreak = () => act(async () => { s.state = await api("POST", "/api/agents/me/break", { reason: "" }, { idem: uuid() }); });

    function startTicket(tk, mode) {
      return act(async () => {
        const r = await api("POST", `/api/tickets/${tk.id || tk.ticket_id}/start`, { work_mode: mode }, { idem: uuid() });
        if (r.agent_state) s.state = r.agent_state;
        await Promise.all([refreshTasks(), refreshTickets()]);
      }, mode === "blocking" ? "toast.started_blocking" : "toast.started_background");
    }
    const changeMode = (sess, mode) => act(async () => {
      const r = await api("POST", `/api/tickets/${sess.ticket_id}/mode`, { work_mode: mode }, { idem: uuid() });
      if (r.agent_state) s.state = r.agent_state;
      await refreshTasks();
    });
    const release = (sess) => act(async () => {
      const r = await api("POST", `/api/tickets/${sess.ticket_id}/release`, { reason: "released" });
      s.state = r.agent_state; await Promise.all([refreshTasks(), refreshTickets()]);
    }, "toast.released");

    function openComplete(sess) {
      s.form = { ticket_id: sess.ticket_id, title: `#${sess.ticket_number} ${sess.ticket_title}`, ticket_state: s.config.complete_states[0], note: "", idem: uuid() };
      s.modal = "complete";
    }
    const submitComplete = () => act(async () => {
      const f = s.form;
      const r = await api("POST", `/api/tickets/${f.ticket_id}/complete`, { ticket_state: f.ticket_state, note: f.note || null }, { idem: f.idem });
      s.state = r.agent_state; s.modal = null;
      await Promise.all([refreshTasks(), refreshTickets()]);
    }, "toast.completed");

    // ------------------------------------------------------------ calls / customers / tickets
    async function openCustomer(id) {
      try { s.customerCard = await api("GET", `/api/customers/${id}`); } catch (e) { toast(e.message, "error"); }
    }
    function openNewCustomer() {
      s.form = { firstname: "", lastname: "", phone: s.call ? s.call.caller_number : "", email: "", note: "" };
      s.modal = "customer";
    }
    const submitCustomer = () => act(async () => {
      const r = await api("POST", "/api/customers", s.form);
      s.customers = [{ id: r.customer.id, name: [r.customer.firstname, r.customer.lastname].filter(Boolean).join(" "), phone: r.customer.phone, email: r.customer.email }];
      s.modal = null; await openCustomer(r.customer.id);
    }, "toast.customer_created");

    function openTicketForm(fromCall) {
      const cust = s.customerCard ? s.customerCard.customer.id : (s.customers[0] && s.customers[0].id) || "";
      s.form = { title: "", body: "", customer_id: cust, ticket_type: "", fields: {}, priority: "2 normal",
                 call_id: fromCall && s.call ? s.call.id : null, idem: uuid() };
      s.modal = "ticket";
    }
    const currentType = computed(() => s.config.ticket_types.find((x) => x.name === s.form.ticket_type));
    const submitTicket = (startMode) => act(async () => {
      const f = s.form;
      if (!f.customer_id) throw new Error(t("err.choose_customer"));
      const r = await api("POST", "/api/tickets", {
        title: f.title, body: f.body, customer_id: Number(f.customer_id), priority: f.priority,
        ticket_type: f.ticket_type || null, fields: f.fields, call_id: f.call_id, start_mode: startMode || null,
      }, { idem: f.idem + (startMode || "") });
      if (r.agent_state) s.state = r.agent_state;
      s.modal = null;
      if (f.call_id) { s.call = null; s.customerCard = null; }
      await Promise.all([refreshTasks(), refreshTickets(), refreshCalls()]);
      return r;
    }, "toast.ticket_created");
    const dismissCall = () => { s.call = null; s.customers = []; s.customerCard = null; };
    const reopenCall = (c) => { s.call = c; s.customers = []; s.customerCard = null;
      api("GET", `/api/customers/lookup?phone=${encodeURIComponent(c.caller_number)}`).then((r) => {
        s.customers = r.customers; if (r.customers.length === 1) openCustomer(r.customers[0].id);
      }); };

    // ------------------------------------------------------------ supervisor
    const isSup = computed(() => s.me && (s.me.role === "supervisor" || s.me.role === "admin"));
    const reconcile = (a) => act(async () => { await api("POST", `/api/admin/agents/${a.agent_id}/reconcile`); await refreshSup(); }, "toast.reconciled");
    function openOverride(a) { s.form = { agent: a, manual_state: "ready", ignore_blocking: false, reason: "" }; s.modal = "override"; }
    const submitOverride = () => act(async () => {
      const f = s.form;
      await api("POST", `/api/admin/agents/${f.agent.agent_id}/override`, { manual_state: f.manual_state, ignore_blocking: f.ignore_blocking, reason: f.reason });
      s.modal = null; await refreshSup();
    }, "toast.override");
    const cancelSession = (w) => {
      const reason = prompt(t("prompt.cancel", { n: w.ticket_number }));
      if (!reason) return;
      act(async () => { await api("POST", `/api/admin/sessions/${w.id}/cancel`, { reason }); await refreshSup(); }, "toast.session_cancelled");
    };
    const showStatus = computed(() => isOperatorView.value && ["work", "tickets", "contacts", "sup", "chat"].includes(s.tab));
    const pageTitle = computed(() => t({ tickets: "nav.tickets", contacts: "nav.contacts", chat: "nav.chat", mail: "nav.mail", whatsapp: "nav.whatsapp", telegram: "nav.telegram", overview: "nav.overview", sup: "nav.sup", shifts: "nav.shifts", recordings: "nav.recordings", log: "nav.log", wallboard: "tm.wall", callrouting: "nav.callrouting", users: "nav.users", integrations: "nav.integrations", settings: "nav.sys_settings",
      types: "nav.types", system: "nav.system", backup: "nav.backup", routing: "nav.routing", groups: "nav.groups", apikeys: "nav.apikeys", mysettings: "nav.settings", work: "nav.work" }[s.tab] || "app.title"));
    const initials = computed(() => ((s.me && s.me.name) || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase());
    // ---------------- manager overview (v2.5)
    async function refreshOverview(silent) {
      if (!silent) s.ov.loading = true;
      try { s.ov.data = await api("GET", `/api/admin/overview?period=${s.ov.period}`); s.ov.updated = new Date().toISOString(); watchChartWidth(); }
      catch (e) { if (!silent) toast(e.message, "error"); }
      finally { s.ov.loading = false; }
    }
    function setPeriod(p) { s.ov.period = p; s.ov.hover = -1; refreshOverview(); }
    setInterval(() => { if (s.tab === "overview" && s.me && !document.hidden) refreshOverview(true); }, 30000);  // safety net
    setInterval(() => { if (s.tab === "overview" && s.ov.data && s.ov.data.live.waiting) s.clock = Date.now(); }, 1000);
    const liveWait = computed(() => {
      const d = s.ov.data; if (!d || !d.live.waiting) return 0;
      return d.live.longest_wait_sec + Math.max(0, (s.clock - new Date(s.ov.updated).getTime()) / 1000);
    });
    const pct = (x) => (x === null || x === undefined ? "—" : Math.round(x * 100) + "%");
    const secs = (x) => {
      if (x === null || x === undefined) return "—";
      x = Math.round(x);
      return x < 60 ? `${x} ${t("dur.s")}` : `${Math.floor(x / 60)}:${String(x % 60).padStart(2, "0")}`;
    };
    const ovAgents = computed(() => {
      const d = s.ov.data; if (!d) return [];
      const k = s.ov.sort;
      return d.agents.filter((x) => !s.sup.level || x.level === s.sup.level).slice()
        .sort((x, y) => ((y[k] ?? -1) - (x[k] ?? -1)) || x.name.localeCompare(y.name));
    });
    const scoreClass = (v) => (v === null || v === undefined ? "" : v >= 80 ? "good" : v >= 60 ? "mid" : "low");
    const slClass = computed(() => {
      const d = s.ov.data; if (!d || d.calls.service_level === null) return "";
      return d.calls.service_level >= d.settings.sla_target ? "good" : d.calls.service_level >= d.settings.sla_target * 0.75 ? "mid" : "low";
    });
    // half-circle gauge: 0..100 % mapped to 180°..0°
    const gauge = computed(() => {
      const d = s.ov.data; const v = d && d.calls.service_level !== null ? d.calls.service_level : 0;
      const pt = (f, r) => { const a = Math.PI * (1 - f); return [90 + r * Math.cos(a), 90 - r * Math.sin(a)]; };
      const arc = (f) => { const [x, y] = pt(Math.max(0.0001, Math.min(f, 1)), 70); return `M 20 90 A 70 70 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)}`; };
      const tg = d ? d.settings.sla_target : 0.8;
      const [t1x, t1y] = pt(tg, 60), [t2x, t2y] = pt(tg, 82);
      return { track: "M 20 90 A 70 70 0 0 1 160 90", value: arc(v), empty: !d || d.calls.service_level === null,
               target: { x1: t1x, y1: t1y, x2: t2x, y2: t2y } };
    });
    // hourly view: hide the empty night hours (always keep 08:00–20:00)
    const ovSeries = computed(() => {
      const d = s.ov.data; if (!d) return [];
      if (d.bucket !== "hour") return d.series;
      const busy = (x) => x.offered || x.agents_avg || x.tickets_completed;
      const idx = d.series.map((x, i) => (busy(x) ? i : -1)).filter((i) => i >= 0);
      const lo = Math.min(idx.length ? idx[0] : 8, 8), hi = Math.max(idx.length ? idx[idx.length - 1] : 19, 19);
      return d.series.slice(Math.max(0, lo), Math.min(d.series.length, hi + 1));
    });
    // charts are drawn at their real pixel width, so labels keep the same size on a phone and on a 4K monitor
    const CH = { h: 220, l: 36, r: 10, t: 12, b: 26 };
    let chartRO = null;
    function watchChartWidth() {
      nextTick(() => {
        const el = document.querySelector(".ov-chart .chart-box");
        if (!el || !window.ResizeObserver) return;
        if (chartRO) chartRO.disconnect();
        chartRO = new ResizeObserver(([en]) => { const w = Math.round(en.contentRect.width); if (w > 100 && Math.abs(w - s.ov.cw) > 2) s.ov.cw = w; });
        chartRO.observe(el);
      });
    }
    // axis maximum = 4 round steps (1, 2, 5 × 10^n), so every grid line has a whole, readable value
    function niceMax(m) {
      const raw = Math.max(1, m) / 4, p = Math.pow(10, Math.floor(Math.log10(raw)));
      const step = [1, 2, 5, 10].map((k) => k * p).find((v) => v >= raw);
      return step * 4;
    }
    const callChart = computed(() => {
      const d = s.ov.data; if (!d) return null;
      const W = s.ov.cw, H = Math.round(Math.min(300, Math.max(200, W * 0.3)));
      const se = ovSeries.value, n = se.length, iw = W - CH.l - CH.r, ih = H - CH.t - CH.b;
      const max = niceMax(Math.max(4, ...se.map((x) => x.offered))), bw = iw / n, w = Math.max(2, Math.min(34, bw * 0.6));
      const y = (v) => CH.t + ih - (v / max) * ih;
      const every = n > 16 ? 3 : n > 10 ? 2 : 1;
      const bars = se.map((x, i) => {
        const cx = CH.l + bw * i + bw / 2, ya = y(x.answered), ym = y(x.answered + x.missed);
        return { i, x: cx - w / 2, w, cx, label: x.label, showLabel: i % every === 0, future: x.future,
                 ans: { y: ya, h: Math.max(0, CH.t + ih - ya) }, mis: { y: ym, h: Math.max(0, ya - ym - (x.answered ? 2 : 0)) },
                 hit: { x: CH.l + bw * i, w: bw }, d: x };
      });
      const grid = [0, 0.25, 0.5, 0.75, 1].map((f) => ({ y: y(max * f), v: Math.round(max * f) }));
      return { bars, grid, base: CH.t + ih, ...CH, w: W, h: H };
    });
    const loadChart = computed(() => {
      const d = s.ov.data; if (!d) return null;
      const W = s.ov.cw, h = Math.round(Math.min(200, Math.max(150, W * 0.2)));
      const se = ovSeries.value, n = se.length, iw = W - CH.l - CH.r, ih = h - CH.t - CH.b;
      const max = niceMax(Math.max(1, ...se.map((x) => Math.max(x.agents_avg || 0, x.erlangs || 0))));
      const X = (i) => CH.l + (iw / n) * i + iw / n / 2, Y = (v) => CH.t + ih - (v / max) * ih;
      const line = (k) => se.map((x, i) => (x.future || x[k] === null ? null : [X(i), Y(x[k])])).filter(Boolean)
        .map((p, j) => `${j ? "L" : "M"} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");
      const every = n > 16 ? 3 : n > 10 ? 2 : 1;
      return { h, agents: line("agents_avg"), erl: line("erlangs"), base: CH.t + ih, l: CH.l, r: CH.r, w: W,
               grid: [0, 0.5, 1].map((f) => ({ y: Y(max * f), v: +(max * f).toFixed(1) })),
               labels: se.map((x, i) => ({ x: X(i), label: x.label, show: i % every === 0 })) };
    });
    const ovHover = computed(() => (callChart.value && s.ov.hover >= 0 ? callChart.value.bars[s.ov.hover] : null));
    // ---------------- messenger (v3.0)
    // v3.20: a conversation is a person ("u<id>") or a group ("g<id>")
    const convKey = (c) => (c.kind === "group" ? "g" : "u") + c.id;
    const chatKey = computed(() => (s.chat.gid ? "g" + s.chat.gid : s.chat.peer ? "u" + s.chat.peer : null));
    const convUrl = () => (s.chat.gid ? `/api/chat/groups/${s.chat.gid}` : `/api/chat/${s.chat.peer}`);
    const chatPeer = computed(() => s.chat.contacts.find((c) => convKey(c) === chatKey.value)
      || (s.chat.gid && s.chat.profile && s.chat.profile.kind === "group" ? { ...s.chat.profile, members: s.chat.profile.members.length } : null));
    const isGroup = computed(() => !!s.chat.gid);
    /** «Anna is typing…» / «Anna, Boris are typing…» — "" when nobody types in that conversation. */
    function typingText(key) {
      const box = key && s.chat.typing[key];
      if (!box) return "";
      const names = Object.values(box).filter((x) => x.until > s.clock).map((x) => x.name);
      if (!names.length) return "";
      return names.length === 1 ? t("chat.typing_one", { name: names[0] }) : t("chat.typing_many", { names: names.slice(0, 3).join(", ") });
    }
    const AV = 6;
    const avClass = (id) => "av-" + (Math.abs(+id || 0) % AV);
    const initials2 = (name) => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase();
    const dayKey = (iso) => { try { return new Intl.DateTimeFormat("en-CA", { timeZone: s.config.timezone }).format(new Date(iso)); } catch { return iso.slice(0, 10); } };
    function dayLabel(iso) {
      const k = dayKey(iso), today = dayKey(new Date().toISOString()), yest = dayKey(new Date(Date.now() - 86400000).toISOString());
      if (k === today) return t("chat.today");
      if (k === yest) return t("chat.yesterday");
      try { return new Intl.DateTimeFormat(locale, { timeZone: s.config.timezone, day: "numeric", month: "long", year: "numeric" }).format(new Date(iso)); } catch { return k; }
    }
    function shortTime(iso) {
      if (!iso) return "";
      if (dayKey(iso) === dayKey(new Date().toISOString())) return fmt(iso);
      try { return new Intl.DateTimeFormat(locale, { timeZone: s.config.timezone, day: "2-digit", month: "2-digit" }).format(new Date(iso)); } catch { return ""; }
    }
    function lastSeen(c) {
      if (!c) return "";
      const tt = typingText(convKey(c));
      if (tt) return tt;
      if (c.kind === "group") return t("chat.members", { n: c.members });
      if (c.online) return t("chat.online");
      if (c.away) return t("chat.away");
      return c.last_seen ? t("chat.last_seen", { t: (dayKey(c.last_seen) === dayKey(new Date().toISOString()) ? "" : shortTime(c.last_seen) + " ") + fmt(c.last_seen) }) : t("chat.long_ago");
    }
    // messages grouped like Telegram: day separators, consecutive messages of one person within 5 min form a group
    const chatItems = computed(() => {
      const out = []; let prevDay = "", prev = null;
      s.chat.msgs.forEach((m, i) => {
        const d = dayKey(m.at);
        if (d !== prevDay) { out.push({ kind: "day", key: "d" + d, label: dayLabel(m.at) }); prevDay = d; prev = null; }
        const next = s.chat.msgs[i + 1];
        const joinPrev = prev && prev.from === m.from && new Date(m.at) - new Date(prev.at) < 300000;
        const joinNext = next && next.from === m.from && dayKey(next.at) === d && new Date(next.at) - new Date(m.at) < 300000;
        out.push({ kind: "msg", key: "m" + m.id, m, mine: m.from === s.me.id, first: !joinPrev, last: !joinNext,
                   who: s.chat.gid && m.from !== s.me.id && !joinPrev ? memberName(m.from) : "" });
        prev = m;
      });
      return out;
    });
    function memberName(id) {
      const p = s.chat.profile && s.chat.profile.kind === "group" ? s.chat.profile.members.find((x) => x.id === id) : null;
      if (p) return p.name;
      const c = s.chat.contacts.find((x) => x.kind !== "group" && x.id === id);
      return c ? c.name : "#" + id;
    }
    let contactsTimer = null;
    let contactsSeq = 0;
    async function loadContacts() {
      const seq = ++contactsSeq;  // only the newest answer is shown (a slow older request must not overwrite a search)
      const r = await api("GET", "/api/chat/contacts" + (s.chat.q.trim() ? "?q=" + encodeURIComponent(s.chat.q.trim()) : ""));
      if (seq !== contactsSeq) return;
      s.chat.contacts = r.contacts; s.chat.unread = r.unread_total;
    }
    function searchContacts() { clearTimeout(contactsTimer); contactsTimer = setTimeout(() => loadContacts().catch(() => {}), 160); }
    async function refreshChatUnread() { try { s.chat.unread = (await api("GET", "/api/chat/unread")).unread; } catch { /* ignore */ } }
    const chatScroller = () => document.querySelector(".chat-scroll");
    function scrollChatBottom(smooth) {
      nextTick(() => { const el = chatScroller(); if (el) el.scrollTo({ top: el.scrollHeight, behavior: smooth && !reduceMotion() ? "smooth" : "auto" }); });
    }
    const nearBottom = () => { const el = chatScroller(); return !el || el.scrollHeight - el.scrollTop - el.clientHeight < 120; };
    async function openChat(c) {
      const key = convKey(c);
      if (chatKey.value && chatKey.value !== key) s.chat.drafts[chatKey.value] = s.chat.text;
      if (c.kind === "group") { s.chat.gid = c.id; s.chat.peer = null; } else { s.chat.peer = c.id; s.chat.gid = null; }
      s.chat.editing = null; s.chat.menu = null; s.chat.text = s.chat.drafts[key] || ""; s.chat.msgs = []; s.chat.hasMore = false; s.chat.profile = null;
      s.chat.files = []; s.chat.emoji = false; s.chat.addPeople = null;
      s.chat.loading = true;
      try {
        if (c.kind === "group") loadProfile();  // the members: names over the bubbles
        const r = await api("GET", convUrl() + "/messages");
        if (chatKey.value !== key) return;
        s.chat.msgs = r.messages; s.chat.hasMore = r.has_more;
        scrollChatBottom(false);
        markChatRead(true);  // opening a conversation = reading it
        if (s.chat.info && c.kind !== "group") loadProfile();
        nextTick(() => { const ta = document.querySelector(".chat-compose textarea"); if (ta && innerWidth > 900) ta.focus(); autoGrow(); });
      } catch (e) { toast(e.message, "error"); } finally { s.chat.loading = false; }
    }
    async function markChatRead(opening) {
      const key = chatKey.value, peer = s.chat.peer;
      if (!key || document.hidden || (!opening && s.tab !== "chat")) return;
      const c = s.chat.contacts.find((x) => convKey(x) === key);
      if (s.chat.gid) {
        if (!(c && c.unread) && !opening) return;
      } else if (!s.chat.msgs.some((m) => m.from === peer && !m.read_at) && !(c && c.unread)) return;
      try {
        await api("POST", convUrl() + "/read");
        if (c) c.unread = 0;
        if (!s.chat.gid) s.chat.msgs.forEach((m) => { if (m.from === peer && !m.read_at) m.read_at = new Date().toISOString(); });
        refreshChatUnread();
      } catch { /* ignore */ }
    }
    async function loadOlder() {
      if (!s.chat.hasMore || s.chat.loading || !s.chat.msgs.length) return;
      const el = chatScroller(), before = el ? el.scrollHeight - el.scrollTop : 0;
      s.chat.loading = true;
      try {
        const r = await api("GET", `${convUrl()}/messages?before_id=${s.chat.msgs[0].id}`);
        s.chat.msgs = [...r.messages, ...s.chat.msgs]; s.chat.hasMore = r.has_more;
        nextTick(() => { if (el) el.scrollTop = el.scrollHeight - before; });  // keep the reading position
      } finally { s.chat.loading = false; }
    }
    function onChatScroll(ev) { if (ev.target.scrollTop < 60) loadOlder(); }
    function autoGrow() {
      const ta = document.querySelector(".chat-compose textarea");
      if (ta) { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 180) + "px"; }
    }
    let typingSent = 0;
    function onType() {
      autoGrow();
      // the first key sends «typing…» at once (the other side shows it with my name), then every 2.5 s while I type
      if (chatKey.value && Date.now() - typingSent > 2500 && s.chat.text.trim()) { typingSent = Date.now(); api("POST", convUrl() + "/typing").catch(() => {}); }
    }
    async function sendChat() {
      if (s.chat.editing) return saveEdit();
      const body = s.chat.text.trim(), key = chatKey.value, url = convUrl();
      const files = s.chat.files.filter((f) => f.data);
      if ((!body && !files.length) || !key || s.chat.sending || s.chat.files.some((f) => f.reading)) return;
      s.chat.sending = true;
      try {
        const m = await api("POST", url + "/messages", { body, files: files.map((f) => ({ name: f.name, mime: f.mime, data: f.data })) });
        s.chat.text = ""; s.chat.drafts[key] = ""; typingSent = 0; s.chat.files = []; s.chat.emoji = false;
        if (chatKey.value === key && !s.chat.msgs.some((x) => x.id === m.id)) s.chat.msgs.push(m);
        bumpContact(m);
        scrollChatBottom(true);
        nextTick(autoGrow);
      } catch (e) { toast(e.message, "error"); } finally { s.chat.sending = false; }
    }
    async function loadProfile() {
      const key = chatKey.value;
      if (!key) return;
      try {
        const p = await api("GET", s.chat.gid ? `/api/chat/groups/${s.chat.gid}` : `/api/chat/${s.chat.peer}/profile`);
        if (chatKey.value === key) s.chat.profile = p;
      } catch (e) { if (s.chat.gid && e.status === 404) { s.chat.gid = null; loadContacts().catch(() => {}); } }
    }
    function toggleChatInfo() { s.chat.info = !s.chat.info; if (s.chat.info) loadProfile(); }
    function chatBack() { if (chatKey.value) s.chat.drafts[chatKey.value] = s.chat.text; s.chat.peer = null; s.chat.gid = null; s.chat.info = false; s.chat.files = []; }
    function chime() {
      if (!s.prefs.sound) return;
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)(), o = ctx.createOscillator(), g = ctx.createGain();
        o.type = "sine"; o.frequency.setValueAtTime(740, ctx.currentTime); o.frequency.exponentialRampToValueAtTime(1180, ctx.currentTime + 0.12);
        g.gain.setValueAtTime(0.06, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
        o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.3);
      } catch { /* audio not allowed */ }
    }
    function onChatEvent(d) {
      const m = d.message, mine = m.from === s.me.id, peerId = mine ? m.to : m.from;
      const key = m.group ? "g" + m.group : "u" + peerId;
      const viewing = (s.tab === "chat" || document.documentElement.dataset.vt === "page") && chatKey.value === key;
      if (viewing && !s.chat.msgs.some((x) => x.id === m.id)) {
        const stick = nearBottom() || mine;
        s.chat.msgs.push(m);
        if (stick) scrollChatBottom(true);
      }
      if (!mine) {
        if (s.chat.typing[key]) delete s.chat.typing[key][m.from];
        if (viewing && !document.hidden) markChatRead();
        else {
          s.chat.unread += 1; chime();
          const text = msgPreview(m), who = d.group ? `${d.sender.name} · ${d.group.name}` : d.sender.name;
          const go = () => { setTab("chat"); openChat(d.group ? { id: d.group.id, kind: "group" } : { id: m.from }); };
          toast(`${who}: ${text.length > 90 ? text.slice(0, 90) + "…" : text}`, "chat", go);
          if (document.hidden && window.Notification && Notification.permission === "granted") {
            try { new Notification(who, { body: text.slice(0, 140), tag: "agentix-chat-" + key }); } catch { /* ignore */ }
          }
        }
      }
      bumpContact(m, d.sender);
    }
    function onChatRead(d) {
      if (d.reader === s.me.id) { soon("chatUnread", refreshChatUnread, 60); if (s.tab === "chat") soon("chatContacts", loadContacts, 120); return; }
      if (s.chat.peer === d.reader) s.chat.msgs.forEach((m) => { if (m.from === s.me.id && m.id <= d.up_to && !m.read_at) m.read_at = d.at; });
      const c = s.chat.contacts.find((x) => x.id === d.reader);
      if (c && c.last && c.last.from === s.me.id && c.last.id <= d.up_to) c.last.read_at = d.at;
    }
    function onChatTyping(d) {
      const key = d.group ? "g" + d.group : "u" + d.from;
      s.chat.typing[key] = { ...(s.chat.typing[key] || {}), [d.from]: { name: d.name || memberName(d.from), until: Date.now() + 4500 } };
      s.clock = Date.now();
    }
    setInterval(() => {
      if (!Object.keys(s.chat.typing).length) return;
      s.clock = Date.now();
      for (const [k, box] of Object.entries(s.chat.typing)) if (!Object.values(box).some((x) => x.until > s.clock)) delete s.chat.typing[k];
    }, 1000);
    // v3.20: a group was created / renamed / its members changed — refresh the list (and the open group)
    function onChatGroup(d) {
      if (s.tab === "chat" || s.chat.contacts.length) soon("chatContacts", loadContacts, 80);
      soon("chatUnread", refreshChatUnread, 120);
      if (s.chat.gid === d.group) {
        if ((d.change === "removed" || d.change === "left") && d.user === s.me.id) { chatBack(); return; }
        loadProfile();
      }
    }
    // ---------------- v3.20 messenger: files, emoji, groups
    const CHAT_FILE_MB = 20, CHAT_FILES = 10;
    function addChatFiles(list) {
      for (const file of [...(list || [])]) {
        if (s.chat.files.length >= CHAT_FILES) { toast(t("chat.files_max", { n: CHAT_FILES }), "error"); break; }
        if (file.size > CHAT_FILE_MB * 1024 * 1024) { toast(t("chat.file_big", { name: file.name, mb: CHAT_FILE_MB }), "error"); continue; }
        const f = reactive({ id: uuid(), name: file.name || "file", mime: file.type || "application/octet-stream", size: file.size, data: "", reading: true,
                             url: /^image\/(png|jpeg|gif|webp)$/.test(file.type) ? URL.createObjectURL(file) : "" });
        s.chat.files.push(f);
        const rd = new FileReader();
        rd.onload = () => { f.data = String(rd.result).split(",", 2)[1] || ""; f.reading = false; };
        rd.onerror = () => { removeChatFile(f); toast(t("chat.bad_file", { name: f.name }), "error"); };
        rd.readAsDataURL(file);
      }
      nextTick(() => { const ta = document.querySelector(".chat-compose textarea"); if (ta) ta.focus(); });
    }
    function removeChatFile(f) { if (f.url) URL.revokeObjectURL(f.url); s.chat.files = s.chat.files.filter((x) => x !== f); }
    function pickChatFiles() { const i = document.querySelector("#chat-file-input"); if (i) { i.value = ""; i.click(); } }
    function onChatPaste(ev) {
      const files = [...((ev.clipboardData && ev.clipboardData.files) || [])];
      if (files.length) { ev.preventDefault(); addChatFiles(files); }
    }
    function onChatDrop(ev) { s.chat.drag = false; if (ev.dataTransfer && ev.dataTransfer.files.length) addChatFiles(ev.dataTransfer.files); }
    const fileSize = (n) => (n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : n >= 1024 ? Math.round(n / 1024) + " KB" : n + " B");
    const isImage = (f) => /^image\/(png|jpeg|gif|webp)$/.test(f.mime || "");
    async function chatBlob(f) {  // pictures in the conversation: fetched with the sign-in (the file URL is not public)
      if (!isImage(f) || s.chat.blobs[f.key]) return;
      s.chat.blobs[f.key] = "loading";
      try {
        const r = await fetch(`/api/chat/files/${f.key}`, { headers: { Authorization: "Bearer " + localStorage.getItem("aws_token") } });
        if (!r.ok) throw new Error(String(r.status));
        s.chat.blobs[f.key] = URL.createObjectURL(await r.blob());
      } catch { delete s.chat.blobs[f.key]; }
    }
    watch(() => s.chat.msgs.map((m) => (m.files || []).map((f) => f.key).join()).join(), () => {
      for (const m of s.chat.msgs) for (const f of m.files || []) chatBlob(f);
    });
    async function downloadChatFile(f) {
      try {
        const r = await fetch(`/api/chat/files/${f.key}?download=1`, { headers: { Authorization: "Bearer " + localStorage.getItem("aws_token") } });
        if (!r.ok) throw new Error(r.status === 404 ? t("chat.file_gone") : String(r.status));
        const url = URL.createObjectURL(await r.blob()), a = document.createElement("a");
        a.href = url; a.download = f.name; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
      } catch (e) { toast(e.message, "error"); }
    }
    const EMOJI = {
      smileys: "😀 😃 😄 😁 😆 😅 😂 🤣 😊 🙂 😉 😍 🥰 😘 😎 🤩 🤔 🤨 😐 😑 😶 🙄 😏 😴 😌 😛 😜 🤪 😝 🤗 🤭 🤫 😬 😮 😯 😲 😳 🥺 😢 😭 😤 😠 😡 🤯 😱 😨 😰 😓 🤒 🤕 🤧 😷 🥳 🥱 😇".split(" "),
      gestures: "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👋 🤚 ✋ 🖐️ 👏 🙌 👐 🤝 🙏 💪 👀 🫶 ✍️ 👉 👈 👆 👇 ☝️".split(" "),
      hearts: "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 ❣️ 💕 💯 ✨ ⭐ 🔥 🎉 🎊 🎁 🏆 🥇".split(" "),
      work: "✅ ☑️ ❌ ⚠️ ❗ ❓ 📞 ☎️ 📱 💻 🖥️ ⌨️ 🖨️ 📧 📨 📩 📎 📌 📍 📝 📋 📁 📂 📅 📆 ⏰ ⏳ ⌛ 🕐 🔔 🔕 🔒 🔑 💡 🛠️ ⚙️ 📊 📈 📉 💬 🗨️ 🚀 ☕ 🍕".split(" "),
    };
    const EMOJI_TABS = Object.keys(EMOJI);
    function recentEmoji() { try { return JSON.parse(localStorage.getItem("zenith_emoji") || "[]").slice(0, 16); } catch { return []; } }
    function insertEmoji(em) {
      const ta = document.querySelector(".chat-compose textarea");
      const start = ta ? ta.selectionStart : s.chat.text.length, end = ta ? ta.selectionEnd : s.chat.text.length;
      s.chat.text = s.chat.text.slice(0, start) + em + s.chat.text.slice(end);
      try { localStorage.setItem("zenith_emoji", JSON.stringify([em, ...recentEmoji().filter((x) => x !== em)].slice(0, 16))); } catch { /* ignore */ }
      s.chat.emojiRecent = recentEmoji();
      nextTick(() => { if (ta) { ta.focus(); const p = start + em.length; ta.setSelectionRange(p, p); autoGrow(); } });
    }
    function toggleEmoji() { s.chat.emoji = s.chat.emoji ? false : (recentEmoji().length ? "recent" : "smileys"); s.chat.emojiRecent = recentEmoji(); }
    document.addEventListener("click", (e) => { if (s.chat.emoji && !e.target.closest(".emoji-pop, .em-btn")) s.chat.emoji = false; });
    // groups: create, rename, members, leave
    let peopleSeq = 0;
    async function searchPeople(box) {  // an empty box lists every active colleague, typing searches by name / position / ext.
      const seq = ++peopleSeq, q = (box.q || "").trim();
      try {
        const list = q ? (await api("GET", "/api/chat/contacts?q=" + encodeURIComponent(q))).contacts.filter((c) => c.kind !== "group" && c.active !== false)
                       : (await api("GET", "/api/msg/agents")).agents.filter((a) => !a.me);
        if (seq !== peopleSeq) return;
        const inGroup = new Set(box === s.chat.addPeople && s.chat.profile && s.chat.profile.members ? s.chat.profile.members.map((m) => m.id) : []);
        box.results = list.filter((c) => !inGroup.has(c.id)).slice(0, 60);
      } catch { /* ignore */ }
    }
    function openNewGroup() {
      s.chat.newGroup = reactive({ name: "", q: "", picked: [], results: [], busy: false, error: "" });
      searchPeople(s.chat.newGroup);
      nextTick(() => { const i = document.querySelector(".ng-name"); if (i) i.focus(); });
    }
    function togglePick(box, c) {
      const i = box.picked.findIndex((x) => x.id === c.id);
      if (i >= 0) box.picked.splice(i, 1); else box.picked.push({ id: c.id, name: c.name });
    }
    async function createGroup() {
      const g = s.chat.newGroup;
      if (!g || g.busy) return;
      if (!g.name.trim()) { g.error = t("chat.group_name_need"); return; }
      if (!g.picked.length) { g.error = t("chat.group_members_need"); return; }
      g.busy = true; g.error = "";
      try {
        const r = await api("POST", "/api/chat/groups", { name: g.name.trim(), members: g.picked.map((x) => x.id) });
        s.chat.newGroup = null; s.chat.q = "";
        await loadContacts();
        openChat({ id: r.id, kind: "group" });
      } catch (e) { g.error = e.message; } finally { if (s.chat.newGroup) g.busy = false; }
    }
    async function renameGroup() {
      const p = s.chat.profile; if (!p || p.kind !== "group") return;
      const name = (s.chat.renaming || "").trim();
      if (!name || name === p.name) { s.chat.renaming = null; return; }
      try { s.chat.profile = await api("PATCH", `/api/chat/groups/${p.id}`, { name }); s.chat.renaming = null; loadContacts().catch(() => {}); }
      catch (e) { toast(e.message, "error"); }
    }
    function openAddPeople() { s.chat.addPeople = reactive({ q: "", picked: [], results: [], busy: false }); searchPeople(s.chat.addPeople); }
    async function addPeople() {
      const box = s.chat.addPeople, p = s.chat.profile;
      if (!box || !box.picked.length || !p) return;
      box.busy = true;
      try { s.chat.profile = await api("POST", `/api/chat/groups/${p.id}/members`, { user_ids: box.picked.map((x) => x.id) }); s.chat.addPeople = null; loadContacts().catch(() => {}); }
      catch (e) { toast(e.message, "error"); box.busy = false; }
    }
    async function removeMember(u) {
      const p = s.chat.profile; if (!p) return;
      try { await api("DELETE", `/api/chat/groups/${p.id}/members/${u.id}`); loadProfile(); loadContacts().catch(() => {}); }
      catch (e) { toast(e.message, "error"); }
    }
    async function leaveGroup() {
      const p = s.chat.profile; if (!p) return;
      s.chat.leaveAsk = false;
      try { await api("DELETE", `/api/chat/groups/${p.id}/members/${s.me.id}`); chatBack(); loadContacts().catch(() => {}); }
      catch (e) { toast(e.message, "error"); }
    }
    const msgPreview = (m) => m.body || (m.files && m.files.length ? "📎 " + m.files.map((f) => f.name).join(", ") : "");
    setInterval(() => { if (s.phone.startedAt) s.clock = Date.now(); }, 1000);  // call timer on the phone button
    setInterval(() => { if (s.me && s.tab === "chat" && !document.hidden) loadContacts().catch(() => {}); }, 30000);  // presence
    document.addEventListener("visibilitychange", () => { if (!document.hidden) markChatRead(); });
    // ---------------- messenger v3.1: live list order, reactions, edit / delete, background notifications
    const REACTIONS = ["❤️", "👍", "😂", "😮", "😢", "🔥", "👏", "🙏"];
    /** A message arrived or was sent: update that chat's time / preview at once and move it to the top. */
    function bumpContact(m, sender) {
      const mine = m.from === s.me.id, peerId = mine ? m.to : m.from;
      const key = m.group ? "g" + m.group : "u" + peerId;
      let c = s.chat.contacts.find((x) => convKey(x) === key);
      if (!c) { if (s.tab === "chat" || s.chat.contacts.length) soon("chatContacts", loadContacts, 60); return; }
      c.last = m.group ? { ...m, sender_name: sender ? sender.name : (mine ? s.me.name : memberName(m.from)) } : m;
      const viewing = chatKey.value === key && (s.tab === "chat" || document.documentElement.dataset.vt === "page") && !document.hidden;
      if (!mine && !viewing) c.unread = (c.unread || 0) + 1;
      if (sender && !c.name && !m.group) c.name = sender.name;
      s.chat.contacts = [c, ...s.chat.contacts.filter((x) => x !== c)];
    }
    function reactionsOf(m) {
      return (m.reactions || []).map((r) => ({ emoji: r.emoji, n: r.users.length, mine: r.users.includes(s.me.id) }));
    }
    async function react(m, emoji) {
      s.chat.menu = null;
      try { const v = await api("POST", `/api/chat/messages/${m.id}/react`, { emoji }); applyUpdate(v); } catch (e) { toast(e.message, "error"); }
    }
    function applyUpdate(v) {
      const i = s.chat.msgs.findIndex((x) => x.id === v.id);
      if (i >= 0) s.chat.msgs[i] = { ...s.chat.msgs[i], ...v };
      const c = s.chat.contacts.find((x) => x.last && x.last.id === v.id);
      if (c) c.last = { ...c.last, ...v };
    }
    function removeLocal(id) {
      s.chat.msgs = s.chat.msgs.filter((x) => x.id !== id);
      const c = s.chat.contacts.find((x) => x.last && x.last.id === id);
      if (c) soon("chatContacts", loadContacts, 80);
    }
    function onChatUpdate(d) {
      if (d.deleted) { removeLocal(d.deleted); soon("chatUnread", refreshChatUnread, 80); return; }
      applyUpdate(d.message);
    }
    // context menu: right click / long press / the "⋯" button on a bubble
    function openMenu(ev, it) {
      const el = ev.currentTarget.closest(".bubble-row").querySelector(".bubble").getBoundingClientRect();
      const box = document.querySelector(".chat-main").getBoundingClientRect();
      const x = ev.type === "contextmenu" ? ev.clientX : (it.mine ? el.left : el.right);
      const y = ev.type === "contextmenu" ? ev.clientY : el.bottom;
      const z = window.zdZoom();  // v3.22: the menu is placed in page pixels
      s.chat.menu = { m: it.m, mine: it.mine,
        x: Math.max(8, Math.min((x - box.left) / z, box.width / z - 236)), y: Math.max(8, Math.min((y - box.top) / z, box.height / z - 260)) };
    }
    let pressT = null;
    function pressStart(ev, it) { clearTimeout(pressT); pressT = setTimeout(() => { navigator.vibrate && navigator.vibrate(15); openMenu({ ...ev, currentTarget: ev.currentTarget, type: "press" }, it); }, 480); }
    function pressEnd() { clearTimeout(pressT); }
    const canEdit = (m) => m.from === s.me.id && Date.now() - new Date(m.at).getTime() < 48 * 3600 * 1000;
    function startEdit(m) {
      s.chat.menu = null; s.chat.editing = m; s.chat.text = m.body;
      nextTick(() => { const ta = document.querySelector(".chat-compose textarea"); if (ta) { ta.focus(); autoGrow(); } });
    }
    function cancelEdit() { s.chat.editing = null; s.chat.text = s.chat.drafts[chatKey.value] || ""; nextTick(autoGrow); }
    async function saveEdit() {
      const m = s.chat.editing, body = s.chat.text.trim();
      if (!m || !body) return;
      try {
        const v = await api("PATCH", `/api/chat/messages/${m.id}`, { body });
        applyUpdate(v); s.chat.editing = null; s.chat.text = ""; nextTick(autoGrow);
      } catch (e) { toast(e.message, "error"); }
    }
    function editLast(ev) {  // ↑ in an empty box edits my last message, like Telegram
      if (s.chat.text || s.chat.editing) return;
      const last = [...s.chat.msgs].reverse().find((m) => m.from === s.me.id);
      if (last && canEdit(last)) { ev.preventDefault(); startEdit(last); }
    }
    async function copyMsg(m) {
      s.chat.menu = null;
      try { await navigator.clipboard.writeText(m.body); toast(t("chat.copied")); } catch { /* clipboard blocked */ }
    }
    function askDelete(m) { s.chat.menu = null; s.chat.del = { m, all: m.from === s.me.id || !!m.group }; }
    async function confirmDelete() {
      const d = s.chat.del; if (!d) return;
      try {
        await api("DELETE", `/api/chat/messages/${d.m.id}?scope=${d.all ? "all" : "me"}`);
        removeLocal(d.m.id); s.chat.del = null;
      } catch (e) { toast(e.message, "error"); }
    }
    document.addEventListener("click", (e) => { if (s.chat.menu && !e.target.closest(".msg-menu, .b-more")) s.chat.menu = null; });
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      if (s.chat.menu) s.chat.menu = null; else if (s.chat.del) s.chat.del = null; else if (s.chat.editing) cancelEdit();
    });
    // background notifications (Web Push) — work even when every Zenith Desk tab is closed
    const pushSupported = () => "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
    async function registerSW() {
      if (!("serviceWorker" in navigator)) return null;
      try { return await navigator.serviceWorker.register("/sw.js", { scope: "/" }); } catch { return null; }
    }
    async function refreshPushState() {
      if (!pushSupported()) { s.push = "unsupported"; return; }
      if (!window.isSecureContext) { s.push = "insecure"; return; }
      if (Notification.permission === "denied") { s.push = "denied"; return; }
      const reg = await navigator.serviceWorker.getRegistration("/");
      const sub = reg && await reg.pushManager.getSubscription();
      s.push = sub ? "on" : "off";
    }
    async function enablePush() {
      try {
        if (await Notification.requestPermission() !== "granted") { s.push = "denied"; return; }
        s.desktop = "granted";
        const reg = await registerSW(); await navigator.serviceWorker.ready;
        const { key } = await api("GET", "/api/push/key");
        const raw = Uint8Array.from(atob(key.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((key.length + 3) % 4)), (c) => c.charCodeAt(0));
        const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: raw });
        await api("POST", "/api/push/subscribe", sub.toJSON());
        s.push = "on"; toast(t("push.enabled"));
      } catch (e) { toast(t("push.failed") + (e && e.message ? ": " + e.message : ""), "error"); refreshPushState(); }
    }
    async function disablePush() {
      try {
        const reg = await navigator.serviceWorker.getRegistration("/");
        const sub = reg && await reg.pushManager.getSubscription();
        if (sub) { await api("POST", "/api/push/unsubscribe", sub.toJSON()).catch(() => {}); await sub.unsubscribe(); }
      } finally { refreshPushState(); }
    }
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.addEventListener("message", (ev) => {
        if (ev.data && ev.data.type === "open-chat" && s.me) { setTab("chat"); openChat({ id: ev.data.from }); }
        if (ev.data && ev.data.type === "open-ticket" && s.me) openTicket(ev.data.ticket);
      });
    }
    const LEVEL_ORDER = { level1: 1, level2: 2, level3: 3, manager: 4, admin: 5 };
    const teamLevels = computed(() => ["level1", "level2", "level3", "manager"].map((l) => ({ id: l, n: s.sup.agents.filter((a) => a.level === l).length })));
    const teamAgents = computed(() => s.sup.agents
      .filter((a) => !s.sup.level || a.level === s.sup.level)
      .slice().sort((x, y) => (LEVEL_ORDER[x.level] || 9) - (LEVEL_ORDER[y.level] || 9) || x.name.localeCompare(y.name)));
    // v3.18 «Team now»: filter by what people do, sort, live timers
    const TEAM_GROUPS = ["all", "call", "free", "busy", "break", "offline"];
    const teamGroupCount = (g) => (g === "all" ? teamAgents.value.length : teamAgents.value.filter((a) => a.group === g).length);
    const teamBoard = computed(() => {
      const zt = window.ZenithTeam;
      let list = teamAgents.value.filter((a) => s.sup.f === "all" || a.group === s.sup.f);
      if (s.sup.sort === "name") list = list.slice().sort((x, y) => x.name.localeCompare(y.name));
      else if (s.sup.sort === "long") {
        const since = (a) => new Date(a.phase_since || a.state_since || Date.now()).getTime();
        list = list.slice().sort((x, y) => since(x) - since(y));
      }
      void (zt && zt.tick.now);
      return list;
    });
    const tmElapsed = (iso) => (window.ZenithTeam ? window.ZenithTeam.elapsed(iso) : 0);
    const tmClock = (sec) => (window.ZenithTeam ? window.ZenithTeam.clock(sec) : "");
    const tmSpan = (iso) => (iso && window.ZenithTeam ? window.ZenithTeam.span(window.ZenithTeam.elapsed(iso), t) : "");
    const TM_ICON = { ringing: "bell", dialing: "arrout", talking: "phone", hold: "pause", wrap_up: "edit" };
    function openWall() { window.open("/?wall=1", "_blank", "noopener"); }
    function exitWall() {
      if (location.search) history.replaceState(null, "", "/");
      if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
      setTab("sup");
    }
    function chatWith(id) { s.sup.day = null; setTab("chat"); openChat({ id }); }
    const teamReport = computed(() => {
      const r = (s.sup.report && s.sup.report.agents) || [];
      if (!s.sup.level) return r;
      const ids = new Set(teamAgents.value.map((a) => a.agent_id));
      return r.filter((x) => ids.has(x.agent_id));
    });
    const supCounts = computed(() => {
      const a = teamAgents.value, c = (f) => a.filter(f).length;
      return {
        online: c((x) => x.manual_state !== "offline"), ready: c((x) => x.display_state === "ready"),
        busy: c((x) => ["busy_task", "wrap_up"].includes(x.computed_state)), brk: c((x) => x.computed_state === "break"),
        offline: c((x) => x.computed_state === "offline"), sync: c((x) => x.sync_status === "error"),
      };
    });
    function openAssign() { s.form = { ticket: "", agent_id: "", work_mode: "" }; s.modal = "assign"; }
    const submitAssign = () => act(async () => {
      await api("POST", "/api/admin/assign", { ticket: String(s.form.ticket), agent_id: Number(s.form.agent_id), work_mode: s.form.work_mode || null });
      s.modal = null; await refreshSup();
    }, "toast.assigned");
    const TAB_ORDER = ["work", "tickets", "contacts", "chat", "mail", "whatsapp", "telegram", "sup", "overview", "shifts", "recordings", "log", "users", "integrations", "settings", "groups", "types", "routing", "system", "backup", "apikeys", "callrouting", "wallboard", "mysettings"];
    const setTab = (tab) => {
      if (tab === s.tab) { s.navOpen = false; if (snPopup.value && !subnav.value.slot) s.snOpen = !s.snOpen; return; }  // Studio pop-up: the active icon opens the sections
      s.snOpen = false;
      if (tab !== "work" && s.editing) finishEditing();
      const dir = TAB_ORDER.indexOf(tab) >= TAB_ORDER.indexOf(s.tab) ? "fwd" : "back";
      withTransition("page", () => { s.tab = tab; s.navOpen = false; window.scrollTo(0, 0); }, { dir });  // a new page starts at its top
      if (tab === "sup") refreshSup().catch((e) => toast(e.message, "error"));
      if (tab === "overview") refreshOverview();
      if (tab === "chat") { loadContacts().catch((e) => toast(e.message, "error")); if (s.chat.peer) nextTick(() => { scrollChatBottom(false); markChatRead(); }); }
    };
    const isAdmin = computed(() => s.me && s.me.role === "admin");
    const isOperatorView = computed(() => s.me && s.me.role !== "admin");
    const roleText = (r) => t(`role.${r}`);
    function openPassword() { s.pw = { current_password: "", new_password: "", repeat: "", error: "" }; s.modal = "password"; }
    async function submitPassword() {
      s.pw.error = "";
      if (s.pw.new_password !== s.pw.repeat) { s.pw.error = t("pw.mismatch"); return; }
      try {
        const r = await api("POST", "/api/auth/change-password", { current_password: s.pw.current_password, new_password: s.pw.new_password });
        s.token = r.token; saveToken(r.token); s.modal = null; toast(t("pw.changed"));
        await boot();
      } catch (e) { s.pw.error = e.message; }
    }

    const freeMine = computed(() => s.mine.active.filter((x) => !x.session));

    // ------------------------------------------------------------ v3.14 layouts of «My workplace»
    const dashLayout = computed(() => (isOperatorView.value ? s.prefs.dash || "standard" : "standard"));
    function setDash(layout) {
      if (!DASH_LAYOUTS.includes(layout) || s.prefs.dash === layout) return;
      if (s.editing) finishEditing();
      s.prefs.dash = layout; s.focusSkip = 0;
      savePrefs(true);
    }
    const ago = (iso) => {
      void s.clock;
      if (!iso) return "";
      const sec = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
      if (sec < 3600) return Math.max(1, Math.round(sec / 60)) + " " + t("dur.min");
      if (sec < 86400) return Math.round(sec / 3600) + " " + t("dur.h");
      return Math.round(sec / 86400) + " " + t("dl.d");
    };
    const byOldest = (a, b) => String(a.created_at || "").localeCompare(String(b.created_at || ""));
    const sortedNew = computed(() => [...s.unassigned].sort(byOldest));
    // Focus: the oldest new request first, then my assigned tickets; «Skip» shows the next one
    const focusQueue = computed(() => [...sortedNew.value.map((tk) => ({ ...tk, kind: "new" })), ...freeMine.value.map((tk) => ({ ...tk, kind: "mine" }))]);
    const focusItem = computed(() => (focusQueue.value.length ? focusQueue.value[s.focusSkip % focusQueue.value.length] : null));
    // one list of all my work (Board, Inbox, Table)
    const workItems = computed(() => {
      const out = [];
      for (const w of s.tasks.blocking) out.push({ key: "a" + w.id, kind: "active", id: w.ticket_id, number: w.ticket_number, title: w.ticket_title, source: w.source,
        w, label: t("dl.k.active"), tagCls: "blocking", note: t("since") + " " + fmt(w.started_at), age: ago(w.started_at) });
      for (const w of s.tasks.background) out.push({ key: "b" + w.id, kind: "background", id: w.ticket_id, number: w.ticket_number, title: w.ticket_title, source: w.source,
        w, label: t("dl.k.background"), tagCls: "background", note: t("since") + " " + fmt(w.started_at, true), age: ago(w.started_at) });
      for (const tk of sortedNew.value) out.push({ key: "n" + tk.id, kind: "new", id: tk.id, number: tk.number, title: tk.title, source: tk.source, group: tk.group,
        tk, label: t("dl.k.new"), tagCls: "off", note: (tk.group || "") + " · " + t("dl.waiting") + " " + ago(tk.created_at), age: ago(tk.created_at) });
      for (const tk of freeMine.value) out.push({ key: "m" + tk.id, kind: "mine", id: tk.id, number: tk.number, title: tk.title, source: tk.source, group: tk.group,
        tk, label: t("dl.k.mine"), tagCls: "ok", note: tk.state, age: "" });
      for (const tk of s.mine.pending) out.push({ key: "p" + tk.id, kind: "pending", id: tk.id, number: tk.number, title: tk.title, source: tk.source, group: tk.group,
        tk, session: tk.session, label: t("dl.k.pending"), tagCls: "", note: tk.state + " · " + fmt(tk.updated_at, true), age: "" });
      return out;
    });
    const boardCols = computed(() => {
      const of = (...k) => workItems.value.filter((x) => k.includes(x.kind));
      return [{ id: "new", title: t("dl.k.new"), items: of("new"), empty: t("panel.new_empty") },
              { id: "work", title: t("dl.in_work"), items: of("active", "background"), empty: t("dl.no_work") },
              { id: "mine", title: t("panel.mine"), items: of("mine"), empty: t("panel.mine_empty") },
              { id: "pending", title: t("panel.pending"), items: of("pending"), empty: t("panel.pending_empty") }];
    });
    const KIND_OF = { all: null, new: ["new"], mine: ["mine"], work: ["active", "background"], pending: ["pending"] };
    const inboxKinds = computed(() => ["all", "new", "mine", "work", "pending"].map((id) => ({
      id, label: t("dl.f." + id), n: KIND_OF[id] ? workItems.value.filter((x) => KIND_OF[id].includes(x.kind)).length : workItems.value.length })));
    const inboxChannels = computed(() => ["email", "telegram", "whatsapp", "phone", "web"].map((id) => ({ id, n: workItems.value.filter((x) => x.source === id).length })).filter((c) => c.n));
    const inboxItems = computed(() => workItems.value.filter((x) => (!KIND_OF[s.dlKind] || KIND_OF[s.dlKind].includes(x.kind)) && (!s.dlCh || x.source === s.dlCh)));
    const tableKinds = computed(() => ["all", "new", "mine", "work"].map((id) => ({
      id, label: t("dl.f." + id), n: KIND_OF[id] ? workItems.value.filter((x) => KIND_OF[id].includes(x.kind)).length : workItems.value.length })));
    const tableItems = computed(() => workItems.value.filter((x) => !KIND_OF[s.dlTable] || KIND_OF[s.dlTable].includes(x.kind)));
    const answeredPct = computed(() => (s.dash && s.dash.calls_today ? Math.round(100 * s.dash.calls_answered / s.dash.calls_today) + "%" : "—"));

    // ------------------------------------------------------------ v3.12 interface style "Studio"
    if (window.matchMedia) {
      const mq = window.matchMedia("(max-width: 900px)");
      const onMq = () => { s.narrow = mq.matches; };
      mq.addEventListener ? mq.addEventListener("change", onMq) : mq.addListener(onMq);
    }
    const studio = computed(() => s.prefs.style === "studio");
    const flow = computed(() => s.prefs.style === "flow");
    // v3.16 Flow: the active section pill slides along the top navigation (measured from the active button)
    function moveNavInd() {
      nextTick(() => requestAnimationFrame(() => {
        const nav = document.querySelector(".side-nav");
        if (!nav) return;
        const on = nav.querySelector("button.on");
        if (!on || !flow.value) { nav.style.setProperty("--ind-o", "0"); return; }
        nav.style.setProperty("--ind-x", on.offsetLeft + "px");
        nav.style.setProperty("--ind-w", on.offsetWidth + "px");
        nav.style.setProperty("--ind-y", on.offsetTop + "px");  // v3.17: the pills may wrap onto a second line
        nav.style.setProperty("--ind-h", on.offsetHeight + "px");
        nav.style.setProperty("--ind-o", "1");
        nav.classList.add("ind-ready");
        fitNav(nav);
        const l = on.offsetLeft, r = l + on.offsetWidth;  // keep the active section visible when the bar scrolls
        if (l < nav.scrollLeft || r > nav.scrollLeft + nav.clientWidth) nav.scrollTo({ left: Math.max(0, l - 24), behavior: reduceMotion() ? "auto" : "smooth" });
      }));
    }
    // v3.19: on one row the menu shares the header with the logo and the bell / LIVE / account cluster; when the
    // sections do not fit there (a laptop, a manager with many sections) the menu takes its own row under the logo
    function fitNav(nav) {
      const bar = nav && nav.closest(".sidebar"), head = bar && bar.querySelector(".side-head");
      if (!bar || !head || !railOn.value) { s.navWrap = false; return; }
      const cs = getComputedStyle(bar);
      // the logo's own width: once the menu has its own row the header row is stretched, so its width would keep it there
      const logo = head.querySelector(".logo-mark"), headW = logo ? logo.offsetWidth + 16 : head.offsetWidth;
      const room = bar.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - headW - 210 - 36;
      // v3.22: before the menu takes a row of its own, its pills get tighter (smaller gaps and letters)
      nav.classList.remove("nav-compact");
      const full = nav.scrollWidth;
      nav.classList.add("nav-compact");
      const tight = nav.scrollWidth;
      nav.classList.toggle("nav-compact", full > room);
      s.navWrap = full > room && tight > room;
    }
    watch(() => [s.tab, s.prefs.style, s.me && s.me.id, s.chat.unread, s.mailUnseen, s.msgCounts.whatsapp, s.msgCounts.telegram, s.narrow], moveNavInd);
    window.addEventListener("resize", () => { if (flow.value) moveNavInd(); });
    window.addEventListener("zd-zoom", () => { if (flow.value) moveNavInd(); });
    // v3.17: the docked phone changes the room for the pills without resizing the window
    if (window.ResizeObserver) {
      let navRo = null;
      watch(() => flow.value && s.me && s.me.id, () => nextTick(() => {
        if (navRo) navRo.disconnect();
        const nav = document.querySelector(".side-nav");
        if (!flow.value || !nav) return;
        navRo = new ResizeObserver(() => moveNavInd());
        navRo.observe(nav);
      }), { immediate: true });
    }
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveNavInd);
    const studioWide = computed(() => studio.value && !s.narrow);  // the section panel needs a wide screen
    // ------------------------------------------------------------ v3.19 Flow: tools on the left rail, menu on top
    const railOn = computed(() => flow.value && !s.narrow);
    const navItems = computed(() => {
      const op = isOperatorView.value, sup = isSup.value, adm = isAdmin.value, c = s.msgCounts || {};
      return [
        op && { key: "work", icon: "work", on: s.tab === "work", go: () => setTab("work") },
        op && { key: "tickets", icon: "ticket", on: s.tab === "tickets", go: () => setTab("tickets") },
        { key: "contacts", icon: "book", on: s.tab === "contacts", go: () => setTab("contacts") },
        { key: "chat", icon: "chat", on: s.tab === "chat", badge: s.chat.unread, go: () => setTab("chat") },
        op && { key: "mail", icon: "mail", on: s.tab === "mail", badge: s.mailUnseen, go: () => setTab("mail") },
        op && { key: "whatsapp", icon: "wa", on: s.tab === "whatsapp", badge: c.whatsapp, go: () => setTab("whatsapp") },
        op && { key: "telegram", icon: "tg", on: s.tab === "telegram", badge: c.telegram, go: () => setTab("telegram") },
        sup && { key: "sup", icon: "team", on: s.tab === "sup", go: () => setTab("sup") },
        sup && { key: "overview", icon: "chart", on: s.tab === "overview", go: () => setTab("overview") },
        sup && { key: "mtools", icon: "calendar", on: MT_TABS.includes(s.tab), go: () => openGroup("mtools") },
        adm && { key: "admin", icon: "sliders", on: ADMIN_KEYS.includes(s.tab), go: () => openGroup("admin") },
      ].filter(Boolean).map((x) => ({ ...x, label: t("nav." + x.key), pinned: (s.prefs.pins || []).includes(x.key) }));
    });
    // v3.19: in the header only the picture is shown — the name, level and position are in its tooltip
    const meTitle = computed(() => s.me ? [s.me.name, s.me.level ? levelText(s.me.level) : roleText(s.me.role), s.me.position, t("rail.me")].filter(Boolean).join(" · ") : "");
    const pinItems = computed(() => (s.prefs.pins || []).map((k) => navItems.value.find((x) => x.key === k)).filter(Boolean));
    function togglePin(key) {
      // sections this person no longer has (e.g. after a role change) do not take a place among the 5
      const pins = (s.prefs.pins || []).filter((k) => navItems.value.some((x) => x.key === k));
      const i = pins.indexOf(key);
      if (i >= 0) pins.splice(i, 1);
      else if (pins.length >= PIN_MAX) { toast(t("rail.pins_full", { max: PIN_MAX }), "error"); return; }
      else pins.push(key);
      s.prefs.pins = pins;
      savePrefs(true);
    }
    document.addEventListener("click", () => { if (s.pinOpen) s.pinOpen = false; });
    window.addEventListener("keydown", (e) => { if (e.key === "Escape" && s.pinOpen) s.pinOpen = false; });
    // v3.13: the section panel is docked next to the rail (can be hidden with «) or pops up over the page
    const snDocked = computed(() => studioWide.value && s.prefs.panel !== "popup");
    const snPopup = computed(() => studioWide.value && s.prefs.panel === "popup");
    function setPanel(mode) {
      if (s.prefs.panel === mode) return;
      s.prefs.panel = mode; s.snOpen = false;
      savePrefs(true);
    }
    function snAct(it) { if (!it.act) return; it.act(); if (snPopup.value) s.snOpen = false; }
    window.addEventListener("keydown", (e) => { if (e.key === "Escape" && s.snOpen) s.snOpen = false; });
    function setStyle(style) {
      if (s.prefs.style === style) return;
      s.prefs.style = style;  // data first: the save below must carry the new style
      savePrefs(true);
      withTransition("theme", () => applyStyle(style));
    }
    const firstName = computed(() => (s.me && (s.me.first_name || (s.me.name || "").split(/\s+/)[0])) || "");
    const greeting = computed(() => {
      void s.clock;
      let hour = new Date().getHours();
      try { hour = +new Intl.DateTimeFormat("en-GB", { timeZone: s.config.timezone, hour: "2-digit", hourCycle: "h23" }).format(new Date()); } catch { /* local time */ }
      const part = hour >= 5 && hour < 12 ? "morning" : hour >= 12 && hour < 18 ? "afternoon" : "evening";
      return t("st." + part, { name: firstName.value });
    });
    const todayIso = computed(() => {
      void s.clock;
      try { return new Intl.DateTimeFormat("en-CA", { timeZone: s.config.timezone, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()); }
      catch { return new Date().toISOString().slice(0, 10); }
    });
    const greetSub = computed(() => {
      if (!s.me) return "";
      const parts = [s.me.position || roleText(s.me.role)];
      if (s.me.level && s.me.level !== "admin") parts.push(levelText(s.me.level));
      if (s.me.extension) parts.push(t("ext") + " " + s.me.extension);
      parts.push(todayIso.value);
      return parts.filter(Boolean).join(" · ");
    });
    const showGreeting = computed(() => studio.value && ((s.tab === "work" && isOperatorView.value) || ((s.tab === "sup" || s.tab === "overview") && isSup.value)));
    const DASH_ICON = { standard: "work", focus: "check", board: "layers", inbox: "inbox", table: "sliders" };
    const WIDGET_ICON = { active: "layers", background: "inbox", notifications: "bell", new: "ticket", mine: "users", pending: "calendar", calls: "phone" };
    function widgetCount(id) {
      return { active: s.tasks.blocking.length, background: s.tasks.background.length, notifications: s.ntf.unread, new: s.unassigned.length,
               mine: freeMine.value.length, pending: s.mine.pending.length, calls: s.calls.length }[id];
    }
    function scrollToEl(sel) {
      const el = document.querySelector(sel);
      if (!el) return;
      el.scrollIntoView({ behavior: reduceMotion() ? "auto" : "smooth", block: "start" });
      el.classList.remove("sn-flash"); void el.offsetWidth; el.classList.add("sn-flash");
    }
    const ADMIN_TABS = [["users", "users", "nav.users"], ["integrations", "plug", "nav.integrations"], ["settings", "sliders", "nav.sys_settings"],
      ["groups", "team", "nav.groups"], ["types", "tag", "nav.types"], ["routing", "route", "nav.routing"], ["system", "pulse", "nav.system"], ["backup", "archive", "nav.backup"], ["apikeys", "key", "nav.apikeys"]];
    const COMM_TABS = ["contacts", "chat", "mail", "whatsapp", "telegram"];
    // v3.15.1: the 8 administration pages and the manager tools are ONE icon each on the rail (the rail always fits
    // the screen); inside a group the pages are tabs at the top of the page (Studio: the section panel)
    const ADMIN_KEYS = ADMIN_TABS.map((a) => a[0]);
    const MT_TABS = ["shifts", "recordings", "log", "callrouting"];
    const MT_DEF = [["shifts", "calendar", "nav.shifts"], ["recordings", "rec", "nav.recordings"], ["log", "logs", "nav.log"], ["callrouting", "route", "nav.callrouting"]];
    const GROUPS = { admin: { keys: ADMIN_KEYS, first: "users" }, mtools: { keys: MT_TABS, first: "shifts" } };
    const lastIn = (g) => { try { const v = localStorage.getItem("zenith_last_" + g); return GROUPS[g].keys.includes(v) ? v : GROUPS[g].first; } catch { return GROUPS[g].first; } };
    function openGroup(g) { setTab(GROUPS[g].keys.includes(s.tab) ? s.tab : lastIn(g)); }
    watch(() => s.tab, (tab) => { for (const [g, d] of Object.entries(GROUPS)) if (d.keys.includes(tab)) try { localStorage.setItem("zenith_last_" + g, tab); } catch { /* ignore */ } });
    const secTabs = computed(() => {
      if (isAdmin.value && ADMIN_KEYS.includes(s.tab)) return { title: t("nav.admin"), items: ADMIN_TABS };
      if (isSup.value && MT_TABS.includes(s.tab)) return { title: t("nav.mtools"), items: MT_DEF };
      return null;
    });
    const subnav = computed(() => {
      const tab = s.tab, go = (x) => () => setTab(x);
      if (tab === "work" && isOperatorView.value) {
        const sections = visibleLayout.value.filter((w) => w.id !== "kpis").map((w) => ({
          key: "w-" + w.id, label: widgetName(w.id), icon: WIDGET_ICON[w.id] || "work", count: widgetCount(w.id), act: () => scrollToEl(`.widget[data-w="${w.id}"]`) }));
        const layouts = DASH_LAYOUTS.map((id) => ({ key: "d-" + id, label: t("dash." + id), icon: DASH_ICON[id], on: dashLayout.value === id, act: () => setDash(id) }));
        return { title: t("nav.work"), groups: [...(dashLayout.value === "standard" ? [{ items: sections }] : []),
          { title: t("sn.layout"), items: layouts }, { title: t("sn.channels"), items: commItems(false) }], shift: true };
      }
      if (tab === "tickets") return { title: t("nav.tickets"), slot: true, groups: [] };
      if (COMM_TABS.includes(tab)) return { title: t("sn.comm"), groups: [{ items: commItems(true) }] };
      if (["sup", "overview", "shifts", "recordings", "log", "callrouting"].includes(tab) && isSup.value) {
        const groups = [{ items: [
          { key: "sup", label: t("nav.sup"), icon: "team", on: tab === "sup", act: go("sup") },
          { key: "overview", label: t("nav.overview"), icon: "chart", on: tab === "overview", act: go("overview") },
          { key: "shifts", label: t("nav.shifts"), icon: "calendar", on: tab === "shifts", act: go("shifts") },
          { key: "recordings", label: t("nav.recordings"), icon: "rec", on: tab === "recordings", act: go("recordings") },
          { key: "log", label: t("nav.log"), icon: "logs", on: tab === "log", act: go("log") },
          { key: "callrouting", label: t("nav.callrouting"), icon: "route", on: tab === "callrouting", act: go("callrouting") }] }];
        if (tab === "sup") groups.push({ title: t("sn.state"), items: [
          { key: "c-ready", label: t("sup.k.ready"), dot: "st-ready", count: supCounts.value.ready },
          { key: "c-busy", label: t("sup.k.busy"), dot: "st-busy_task", count: supCounts.value.busy },
          { key: "c-break", label: t("sup.k.break"), dot: "st-break", count: supCounts.value.brk },
          { key: "c-off", label: t("sup.k.offline"), dot: "st-offline", count: supCounts.value.offline }] });
        return { title: t("sn.team"), groups };
      }
      if (ADMIN_TABS.some((a) => a[0] === tab) && isAdmin.value) {
        return { title: t("nav.admin"), groups: [{ items: ADMIN_TABS.map(([id, icon, key]) => ({ key: id, label: t(key), icon, on: tab === id, act: go(id), })) }] };
      }
      if (tab === "mysettings") {
        const secs = [["interface", "layers", "set.interface", true],
          ["alerts", "bell", "set.alerts", isOperatorView.value], ["phone", "phone", "ph.set.title", phoneOn.value], ["account", "users", "set.account", true]];
        return { title: t("nav.settings"), groups: [{ items: secs.filter((x) => x[3]).map(([id, icon, key]) => ({
          key: "s-" + id, label: t(key), icon, act: () => scrollToEl(`[data-sec="${id}"]`) })) }] };
      }
      return { title: pageTitle.value, groups: [] };
    });
    function commItems(withOn) {
      const on = (x) => withOn && s.tab === x;
      const items = [{ key: "contacts", label: t("nav.contacts"), icon: "book", on: on("contacts"), act: () => setTab("contacts") },
        { key: "chat", label: t("nav.chat"), icon: "chat", count: s.chat.unread, on: on("chat"), act: () => setTab("chat") }];
      if (isOperatorView.value) {
        items.push({ key: "mail", label: t("nav.mail"), icon: "mail", count: s.mailUnseen, on: on("mail"), act: () => setTab("mail") },
          { key: "whatsapp", label: t("nav.whatsapp"), icon: "wa", cls: "wa", count: s.msgCounts.whatsapp, on: on("whatsapp"), act: () => setTab("whatsapp") },
          { key: "telegram", label: t("nav.telegram"), icon: "tg", cls: "tg", count: s.msgCounts.telegram, on: on("telegram"), act: () => setTab("telegram") });
      }
      return withOn ? items : items.filter((x) => x.key !== "contacts");
    }
    // "Start of shift" checklist (like "Get started"): disappears when everything is done or when closed for today
    const shiftKey = () => "zenith_shift_" + todayIso.value + "_" + (s.me ? s.me.id : "");
    function loadShiftHidden() { try { s.shiftHidden = localStorage.getItem(shiftKey()) === "1"; } catch { s.shiftHidden = false; } }
    function hideShift() { s.shiftHidden = true; try { localStorage.setItem(shiftKey(), "1"); } catch { /* ignore */ } }
    const shiftItems = computed(() => {
      if (!s.me || !isOperatorView.value) return [];
      const out = [];
      if (phoneOn.value) out.push({ key: "phone", done: s.phone.status === "registered" || s.phone.status === "dnd", label: t("sn.ck_phone"),
        sub: s.me.extension ? t("sn.ck_phone_d", { ext: s.me.extension }) : "", act: () => { s.phoneOpen = true; } });
      if (s.mailOn) out.push({ key: "mail", done: s.mailConnected, label: t("sn.ck_mail"), sub: t("sn.ck_mail_d"), act: () => setTab("mail") });
      out.push({ key: "ready", done: !!(s.state && s.state.manual_state === "ready"), label: t("sn.ck_ready"), sub: t("sn.ck_ready_d"), act: goReady });
      return out;
    });
    const shiftDone = computed(() => shiftItems.value.filter((x) => x.done).length);
    const showShift = computed(() => !s.shiftHidden && shiftItems.value.length > 0 && shiftDone.value < shiftItems.value.length);
    watch(() => (s.me ? s.me.id + todayIso.value : ""), loadShiftHidden, { immediate: true });
    // ------------------------------------------------------------ v3.12 account picture
    function pickAvatar() {
      const inp = document.createElement("input");
      inp.type = "file"; inp.accept = "image/jpeg,image/png,image/webp";
      inp.onchange = () => { if (inp.files && inp.files[0]) uploadAvatar(inp.files[0]); };
      inp.click();
    }
    async function uploadAvatar(file) {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { toast(t("av.type"), "error"); return; }
      s.avatarBusy = true;
      try {
        const blob = await squarePicture(file);
        const r = await fetch("/api/agents/me/avatar", { method: "PUT", body: blob,
          headers: { "Content-Type": blob.type, Authorization: `Bearer ${s.token}` } });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error((d.detail && (d.detail.message || d.detail)) || r.statusText);
        Object.assign(s.me, d);
        toast(t("av.saved"));
      } catch (e) { toast(e.message === "decode" ? t("av.type") : e.message, "error"); }
      finally { s.avatarBusy = false; }
    }
    async function setAvatarMode(mode) {
      try { Object.assign(s.me, await api("PUT", "/api/agents/me/avatar/mode", { mode })); } catch (e) { toast(e.message, "error"); }
    }
    async function deleteAvatar() {
      try { Object.assign(s.me, await api("DELETE", "/api/agents/me/avatar")); toast(t("av.deleted")); } catch (e) { toast(e.message, "error"); }
    }
    // ---------------- v3.3: tickets and customers inside Zenith Desk
    let reqN = 0;
    function openTicket(id) {
      if (!id) return;
      if (!isOperatorView.value) { window.open(zLink(id), "_blank", "noopener"); return; }  // admins work in Zammad itself
      setTab("tickets"); s.tkOpen = { id: +id, n: ++reqN };
    }
    function openContact(id, kind) { if (!id) return; setTab("contacts"); s.ctOpen = { id: +id, kind: kind || null, n: ++reqN }; }
    function dialNumber(number, name) { if (number) window.dispatchEvent(new CustomEvent("zenith:dial", { detail: { number, name } })); }
    window.zenithDial = dialNumber;  // used by the ticket and customer pages
    // v3.14: open the phone with the number typed (no call yet) — the number links of ticket drafts use it
    window.zenithPrefill = (number) => { if (number) window.dispatchEvent(new CustomEvent("zenith:prefill", { detail: { number } })); };
    // v3.14: «New ticket» on a call — a ticket draft with the caller's number, the caller (if known) and the call record
    const digits = (x) => String(x || "").replace(/\D/g, "").slice(-9);
    window.addEventListener("zenith:call-ticket", async (e) => {
      const d = e.detail || {};
      if (!s.me || !isOperatorView.value) return;
      const want = digits(d.number);
      let call = s.call && digits(s.call.caller_number) === want ? s.call : null;
      if (!call) {
        try { await refreshCalls(); } catch { /* keep the list we have */ }
        call = (s.calls || []).find((c) => digits(c.caller_number) === want && c.state !== "missed") || null;
      }
      let customer = d.customer || null;
      if (!customer && want) {
        try {
          const r = await api("GET", `/api/customers/lookup?phone=${encodeURIComponent(d.number)}`);
          if (r.customers && r.customers.length === 1) customer = { id: r.customers[0].id, name: r.customers[0].name, phone: r.customers[0].phone, email: r.customers[0].email };
        } catch { /* the operator picks the customer */ }
      }
      setTab("tickets");
      s.tkNew = { customer, phone: d.number, call_id: call ? call.id : null, n: ++reqN };
    });
    window.addEventListener("zenith:chat", (e) => { const id = e.detail && e.detail.id; if (id) { setTab("chat"); openChat({ id }); } });  // phone → messenger
    const phoneOn = computed(() => !!(s.me && isOperatorView.value && s.config.phone_enabled));
    async function refreshMsgCounts() { if (!s.me || !isOperatorView.value) return; try { s.msgCounts = await api("GET", "/api/msg/counts"); } catch { /* ignore */ } }
    async function refreshMail() {
      if (!s.me || !isOperatorView.value) return;
      try { const a = await api("GET", "/api/mail/account"); s.mailOn = a.enabled; s.mailConnected = !!a.connected; s.mailUnseen = a.connected ? a.unseen : 0; } catch { /* ignore */ }
    }
    // ------------------------------------------------------------ v3.15 call supervision: listen / whisper / barge
    const announceSpy = (x) => window.dispatchEvent(new CustomEvent("zenith:spy", { detail: x }));
    function onSpyEvent(d) {
      if (d.active && d.session) { s.sup.spy = d.session; announceSpy(d.session); return; }
      if (s.sup.spy && d.session && s.sup.spy.id !== d.session.id) return;  // an older session ended
      if (s.sup.spy) toast(t("spy.ended"));
      s.sup.spy = null;
      window.dispatchEvent(new CustomEvent("zenith:spy-end", { detail: d.session || null }));
    }
    async function startSpy(a, mode) {
      // the same call in another mode: switch (keys 4 / 5 / 6); the same mode again: ring the manager's phone again
      if (s.sup.spy && s.sup.spy.agent_id === a.agent_id && s.sup.spy.mode !== mode) return setSpyMode(mode);
      s.sup.spyBusy = true;
      try {
        const r = await api("POST", "/api/sup/spy", { agent_id: a.agent_id, mode });
        s.sup.spy = r.session; announceSpy(r.session);  // Zenith Phone answers the manager's call by itself
        toast(t("spy.ringing", { name: a.name }));
      } catch (e) { toast(e.message, "error"); } finally { s.sup.spyBusy = false; }
    }
    async function setSpyMode(mode) {
      try { const r = await api("POST", "/api/sup/spy/mode", { mode }); s.sup.spy = r.session; announceSpy(r.session); }
      catch (e) { toast(e.message, "error"); }
    }
    async function stopSpy() {
      const old = s.sup.spy;
      s.sup.spy = null;
      window.dispatchEvent(new CustomEvent("zenith:spy-end", { detail: old }));
      try { await api("DELETE", "/api/sup/spy"); } catch (e) { toast(e.message, "error"); }
    }
    const SPY_MODES = [["listen", "ear"], ["whisper", "whisper"], ["barge", "join"]];
    async function playRecording(ev, c) {  // v3.9: recordings served by Zenith Desk need the token
      if (!c.recording_url.startsWith("/api/")) return;
      ev.preventDefault();
      try {
        const r = await fetch(c.recording_url, { headers: { Authorization: `Bearer ${s.token}` } });
        if (!r.ok) { toast((await r.json().catch(() => ({}))).detail || t("err.status", { status: r.status }), "error"); return; }
        window.open(URL.createObjectURL(await r.blob()), "_blank", "noopener");
      } catch (e) { toast(e.message, "error"); }
    }
    function openConversation(id, channel) { setTab(channel === "telegram" ? "telegram" : "whatsapp"); s.inOpen = { id, n: Date.now() }; }
    // v3.8 Windows desktop client (WebView2): tell the window about calls and unread messages, so it can flash the
    // taskbar / show a tray balloon when it is minimized. Nothing happens in a normal browser.
    const host = window.chrome && window.chrome.webview;
    if (host) {
      const post = (m) => { try { host.postMessage(m); } catch { /* ignore */ } };
      watch(() => [s.phone.call, s.phone.name], ([call, name]) => post({ type: "call", state: call || "idle", name: name || "" }));
      watch(() => s.chat.unread, (n) => post({ type: "unread", n: n || 0 }));
      watch(() => (s.me ? s.me.name : ""), (name) => post({ type: "user", name: name || "" }), { immediate: true });
    }
    window.addEventListener("zenith:agent_state", (e) => { if (e.detail && s.me && e.detail.agent_id === s.me.id) s.state = e.detail; });  // DND from the phone
    const phoneTimer = computed(() => {
      if (!s.phone.startedAt) return "";
      const sec = Math.max(0, Math.floor((s.clock - s.phone.startedAt) / 1000));
      return `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;
    });
    function newTicketFor(customer) { setTab("tickets"); s.tkNew = { customer, n: ++reqN }; }
    const zLink = (id) => `${s.config.zammad_url || ""}/#ticket/zoom/${id}`;

    onMounted(() => {
      document.title = `${t("app.title")} — ${t("app.subtitle")}`;
      if (s.token) boot();
      setInterval(() => { if (s.me && !isAdmin.value && !s.me.must_change_password) { refreshTickets().catch(() => {}); refreshNotifications(); } }, 30000);
      document.addEventListener("click", (e) => { if (s.ntfOpen && !e.target.closest(".ntf-wrap")) s.ntfOpen = false; });
      setInterval(() => { if (s.me && s.tab === "sup") refreshSup().catch(() => {}); }, 15000);
    });

    return { s, t, version: VERSION, setZoom, zoomOpts: ZOOMS, uploadFile, stateText, srcText, callText, fmt, dur, doLogin, logout, goReady, goBreak, startTicket, changeMode, release,
      openComplete, submitComplete, openCustomer, openNewCustomer, submitCustomer, openTicketForm, submitTicket,
      currentType, dismissCall, reopenCall, isSup, reconcile, openOverride, submitOverride, cancelSession, setTab,
      freeMine, zLink, dialNumber, phoneTimer, phoneOn, openConversation, playRecording, openTicket, openContact, newTicketFor, refreshSup, isAdmin, isOperatorView, roleText, openPassword, submitPassword, api, toast,
      toggleNtf, markRead, isUnread, ntfIcon, enableDesktop, toggleTheme, effectiveTheme, supCounts, openAssign, submitAssign,
      PRESETS_PREVIEW: Object.fromEntries(Object.entries(PRESETS).map(([k, v]) => [k, v.layout.filter((w) => !w.hidden)])),
      teamLevels, teamAgents, teamReport, showStatus, pageTitle, initials,
      refreshOverview, setPeriod, liveWait, isFrozen, resumeIdle, idleSinceText,
      toastClick, dayLabel, chatPeer, avClass, initials2, shortTime, lastSeen, chatItems, searchContacts, openChat, onChatScroll, onType, sendChat,
      convKey, chatKey, isGroup, typingText, msgPreview, addChatFiles, removeChatFile, pickChatFiles, onChatPaste, onChatDrop, fileSize, isImage,
      downloadChatFile, EMOJI, EMOJI_TABS, insertEmoji, toggleEmoji, searchPeople, openNewGroup, togglePick, createGroup, renameGroup, openAddPeople,
      addPeople, removeMember, leaveGroup,
      toggleChatInfo, chatBack, REACTIONS, reactionsOf, react, openMenu, pressStart, pressEnd, canEdit, startEdit, cancelEdit,
      editLast, copyMsg, askDelete, confirmDelete, enablePush, disablePush, pushSupported, pct, secs, ovAgents, scoreClass, slClass, gauge, callChart, loadChart, ovHover,
      setTheme, toggleMotion, presetIds, visibleLayout, hiddenWidgets, widgetName, applyPreset, moveW, setW, cycleH, hideW, showW,
      dragStart, dropOn, startEditing, finishEditing, toggleSound, toggleCompact, levelText,
      dashLayout, setDash, ago, sortedNew, focusQueue, focusItem, boardCols, inboxKinds, inboxChannels, inboxItems, tableKinds, tableItems, answeredPct,
      studio, flow, studioWide, snDocked, snPopup, setPanel, snAct, setStyle, greeting, greetSub, showGreeting, subnav, shiftItems, shiftDone, showShift, hideShift,
      pickAvatar, setAvatarMode, deleteAvatar, nameInitials, srcIcon, locale, openGroup, secTabs, ADMIN_KEYS, MT_TABS, startSpy, setSpyMode, stopSpy, SPY_MODES,
      TEAM_GROUPS, teamGroupCount, teamBoard, tmElapsed, tmClock, tmSpan, TM_ICON, openWall, exitWall, chatWith, BRAND_PATH,
      railOn, navItems, pinItems, togglePin, PIN_MAX, meTitle };
  },

  template: `
<div v-if="!s.me" class="login-page">
  <!-- v3.19: a soft grid with a green light behind the card -->
  <div class="login-glow" aria-hidden="true"></div><div class="login-grid" aria-hidden="true"></div>
  <button class="theme-btn" @click="toggleTheme" :aria-label="effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark')" :title="effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark')"><ico :name="effectiveTheme(s.theme)==='dark' ? 'sun' : 'moon'"></ico></button>
  <div class="panel login">
  <h1 class="logo"><img src="/static/logo.svg" alt="" class="logo-img"><brand-word stack></brand-word></h1>
  <form @submit.prevent="doLogin">
    <label>{{ t('login.login') }}</label><input v-model="s.login.username" autocomplete="username" autocapitalize="off" required>
    <label>{{ t('login.password') }}</label><input v-model="s.login.password" type="password" autocomplete="current-password" required>
    <p v-if="s.loginError" style="color:var(--danger)">{{ s.loginError }}</p>
    <div style="margin-top:16px"><button class="btn primary" style="width:100%">{{ t('login.submit') }}</button></div>
  </form>
  <div class="version" v-if="version">v{{ version }}</div>
  </div>
</div>

<template v-else>
<div class="layout" :class="{frozen: isFrozen}" :inert="isFrozen || null" :aria-hidden="isFrozen ? 'true' : null">
  <aside class="sidebar" :class="{open: s.navOpen, 'nav-wrap': s.navWrap && railOn}">
    <div class="side-head">
      <div class="logo-mark" :title="t('app.title')"><img src="/static/logo.svg" alt="" class="logo-img"><brand-word class="full"></brand-word></div>
      <button class="burger" @click="s.navOpen = !s.navOpen" :aria-label="t('nav.menu')">☰</button>
    </div>
    <nav class="side-nav" :aria-label="t('nav.menu')">
      <button v-if="isOperatorView" data-nav="work" :class="{on: s.tab==='work'}" @click="setTab('work')" :aria-label="t('nav.work')"><ico name="work"></ico><span class="lbl">{{ t('nav.work') }}</span></button>
      <button v-if="isOperatorView" data-nav="tickets" :class="{on: s.tab==='tickets'}" @click="setTab('tickets')" :aria-label="t('nav.tickets')"><ico name="ticket"></ico><span class="lbl">{{ t('nav.tickets') }}</span></button>
      <button data-nav="contacts" :class="{on: s.tab==='contacts'}" @click="setTab('contacts')" :aria-label="t('nav.contacts')"><ico name="book"></ico><span class="lbl">{{ t('nav.contacts') }}</span></button>
      <button data-nav="chat" class="chat-nav" :class="{on: s.tab==='chat'}" @click="setTab('chat')" :aria-label="t('nav.chat')"><ico name="chat"></ico><span v-if="s.chat.unread" class="nav-badge">{{ s.chat.unread > 99 ? '99+' : s.chat.unread }}</span><span class="lbl">{{ t('nav.chat') }}</span></button>
      <button v-if="isOperatorView" data-nav="mail" class="msg-nav ml-nav" :class="{on: s.tab==='mail'}" @click="setTab('mail')" :aria-label="t('nav.mail')"><ico name="mail"></ico><span v-if="s.mailUnseen" class="nav-badge">{{ s.mailUnseen > 99 ? '99+' : s.mailUnseen }}</span><span class="lbl">{{ t('nav.mail') }}</span></button>
      <button v-if="isOperatorView" data-nav="whatsapp" class="msg-nav wa" :class="{on: s.tab==='whatsapp'}" @click="setTab('whatsapp')" :aria-label="t('nav.whatsapp')"><ico name="wa"></ico><span v-if="s.msgCounts.whatsapp" class="nav-badge">{{ s.msgCounts.whatsapp }}</span><span class="lbl">{{ t('nav.whatsapp') }}</span></button>
      <button v-if="isOperatorView" data-nav="telegram" class="msg-nav tg" :class="{on: s.tab==='telegram'}" @click="setTab('telegram')" :aria-label="t('nav.telegram')"><ico name="tg"></ico><span v-if="s.msgCounts.telegram" class="nav-badge">{{ s.msgCounts.telegram }}</span><span class="lbl">{{ t('nav.telegram') }}</span></button>
      <button v-if="isSup" data-nav="sup" :class="{on: s.tab==='sup'}" @click="setTab('sup')" :aria-label="t('nav.sup')"><ico name="team"></ico><span class="lbl">{{ t('nav.sup') }}</span></button>
      <button v-if="isSup" data-nav="overview" class="ov-nav" :class="{on: s.tab==='overview'}" @click="setTab('overview')" :aria-label="t('nav.overview')"><ico name="chart"></ico><span class="lbl">{{ t('nav.overview') }}</span></button>
      <button v-if="isSup" data-nav="mtools" class="mt-nav" :class="{on: MT_TABS.includes(s.tab)}" @click="openGroup('mtools')" :aria-label="t('nav.mtools')"><ico name="calendar"></ico><span class="lbl lbl-full">{{ t('nav.mtools') }}</span><span class="lbl lbl-short">{{ t('nav.mtools_short') }}</span></button>
      <template v-if="isAdmin">
        <div class="side-title" v-if="isOperatorView || isSup">{{ t('nav.admin') }}</div>
        <button data-nav="admin" class="adm-nav" :class="{on: ADMIN_KEYS.includes(s.tab)}" @click="openGroup('admin')" :aria-label="t('nav.admin')"><ico name="sliders"></ico><span class="lbl">{{ t('nav.admin') }}</span></button>
      </template>
    </nav>
    <div class="side-foot" :class="{rail: railOn}">
      <!-- v3.19 Flow: the tool rail — status, phone, customize, pinned sections, then the account buttons -->
      <template v-if="railOn">
        <div v-if="isOperatorView" class="sf-grp sf-status" role="group" :aria-label="t('rail.tools')">
          <button class="rail-btn st-ready" data-rail="ready" :class="{on: s.state && s.state.manual_state==='ready'}" @click="goReady"
                  :disabled="s.busy || (s.state && s.state.manual_state==='ready' && s.state.computed_state!=='wrap_up')" :aria-label="t('btn.ready')"><ico name="check"></ico><span class="lbl">{{ t('btn.ready') }}</span></button>
          <button class="rail-btn st-break" data-rail="break" :class="{on: s.state && s.state.manual_state==='break'}" @click="goBreak"
                  :disabled="s.busy || (s.state && s.state.manual_state==='break')" :aria-label="t('btn.break')"><ico name="coffee"></ico><span class="lbl">{{ t('btn.break') }}</span></button>
        </div>
        <div v-if="phoneOn || (isOperatorView && dashLayout==='standard')" class="sf-grp sf-phone">
          <div v-if="phoneOn" id="ph-rail-slot" class="ph-rail-slot"></div>
          <button v-if="isOperatorView && dashLayout==='standard'" class="rail-btn" data-rail="customize" :class="{on: s.editing}" @click="startEditing" :aria-label="t('ws.customize')"><ico name="edit"></ico><span class="lbl">{{ t('ws.customize') }}</span></button>
        </div>
        <div class="sf-grp sf-pins">
          <button v-for="p in pinItems" :key="p.key" class="rail-btn" :class="{on: p.on}" :data-pin="p.key" @click="p.go" :aria-label="p.label">
            <ico :name="p.icon"></ico><span v-if="p.badge" class="rail-badge">{{ p.badge > 99 ? '99+' : p.badge }}</span><span class="lbl">{{ p.label }}</span></button>
          <button class="rail-btn rail-add" data-rail="pins" :class="{on: s.pinOpen}" @click.stop="s.pinOpen = !s.pinOpen" :aria-expanded="s.pinOpen ? 'true' : 'false'"
                  :aria-label="t('rail.pins_add')"><ico name="plus"></ico><span class="lbl">{{ t('rail.pins') }}</span></button>
          <div v-if="s.pinOpen" class="pin-pop" @click.stop role="dialog" :aria-label="t('rail.pins')">
            <div class="pin-head"><b>{{ t('rail.pins') }}</b><span class="pin-count" :class="{full: pinItems.length >= PIN_MAX}">{{ t('rail.pins_count', {n: pinItems.length, max: PIN_MAX}) }}</span></div>
            <p class="pin-hint">{{ t('rail.pins_hint', {max: PIN_MAX}) }}</p>
            <button v-for="n in navItems" :key="n.key" class="pin-row" :class="{on: n.pinned}" :data-pin-opt="n.key" @click="togglePin(n.key)"
                    :disabled="!n.pinned && pinItems.length >= PIN_MAX" role="checkbox" :aria-checked="n.pinned ? 'true' : 'false'">
              <ico :name="n.icon"></ico><span>{{ n.label }}</span><i class="pin-box"><ico v-if="n.pinned" name="check"></ico></i></button>
          </div>
        </div>
      </template>
      <div class="sf-grp sf-foot">
      <button class="settings-btn" :class="{on: s.tab==='mysettings'}" @click="setTab('mysettings')" :aria-label="t('nav.settings')"><ico name="gear"></ico><span class="lbl">{{ t('nav.settings') }}</span></button>
      <button class="theme-toggle" @click="toggleTheme" :aria-label="effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark')"><ico :name="effectiveTheme(s.theme)==='dark' ? 'sun' : 'moon'"></ico><span class="lbl">{{ effectiveTheme(s.theme)==='dark' ? t('theme.light') : t('theme.dark') }}</span></button>
      <button @click="openPassword" :aria-label="t('btn.change_password')"><ico name="key"></ico><span class="lbl">{{ t('btn.change_password') }}</span></button>
      <button class="logout" @click="logout" :aria-label="t('btn.logout')"><ico name="out"></ico><span class="lbl">{{ t('btn.logout') }}</span></button>
      </div>
      <div class="version" v-if="version">v{{ version }}</div>
    </div>
  </aside>
  <div v-if="snPopup && s.snOpen" class="sn-dim" @click="s.snOpen = false"></div>
  <aside v-if="studioWide" class="subnav" :class="{popup: snPopup, open: s.snOpen}" :data-sn-tab="s.tab" :aria-label="subnav.title" :aria-hidden="snPopup && !s.snOpen ? 'true' : null" :inert="snPopup && !s.snOpen ? true : null">
    <div class="sn-head"><b>{{ subnav.title }}</b>
      <button v-if="snDocked" class="sn-hb" data-panel="hide" @click="setPanel('popup')" :title="t('sn.hide')" :aria-label="t('sn.hide')">«</button>
      <button v-else class="sn-hb" data-panel="pin" @click="setPanel('docked')" :title="t('sn.pin')" :aria-label="t('sn.pin')"><ico name="panel"></ico></button></div>
    <div class="sn-scroll">
      <div v-if="subnav.slot" id="sn-slot" class="sn-slot"></div>
      <div v-for="(g, gi) in subnav.groups" :key="gi" class="sn-group">
        <div v-if="g.title" class="sn-title">{{ g.title }}</div>
        <component :is="it.act ? 'button' : 'div'" v-for="it in g.items" :key="it.key" class="sn-item" :class="[it.cls, {on: it.on, info: !it.act}]"
                   :data-sn="it.key" @click="snAct(it)">
          <i v-if="it.dot" class="sn-dot" :class="it.dot"></i><ico v-else-if="it.icon" :name="it.icon"></ico>
          <span class="sn-label">{{ it.label }}</span><b v-if="it.count !== undefined && it.count !== null" class="sn-count" :class="{hot: it.count > 0 && it.cls !== undefined}">{{ it.count }}</b>
        </component>
      </div>
    </div>
    <div v-if="subnav.shift && showShift" class="sn-shift" :class="{open: s.shiftOpen}" role="region" :aria-label="t('sn.shift')">
      <div class="sn-shift-h"><button class="sn-shift-t" data-act="shift" @click="s.shiftOpen = !s.shiftOpen" :aria-expanded="s.shiftOpen ? 'true' : 'false'">
          <b>{{ t('sn.shift') }}</b><i class="sn-bar"><i :style="{width: (100 * shiftDone / shiftItems.length) + '%'}"></i></i><span class="mono">{{ shiftDone }}/{{ shiftItems.length }}</span></button>
        <button class="sn-x" @click="hideShift" :title="t('sn.shift_close')" :aria-label="t('sn.shift_close')"><ico name="close"></ico></button></div>
      <button v-for="c in shiftItems" v-show="s.shiftOpen" :key="c.key" class="sn-ck" :class="{done: c.done}" :data-ck="c.key" @click="!c.done && c.act()">
        <span class="sn-box"><ico v-if="c.done" name="check"></ico></span><span><b>{{ c.label }}</b><small v-if="c.sub">{{ c.sub }}</small></span>
      </button>
    </div>
    <button v-if="snDocked" class="sn-me" @click="setTab('mysettings')" :title="t('sn.my_settings')">
      <user-avatar :name="s.me.name" :url="s.me.avatar_url"></user-avatar>
      <span class="sn-me-t"><b>{{ s.me.name }}</b><small>{{ s.me.level && s.me.level !== 'admin' ? levelText(s.me.level) : roleText(s.me.role) }}<template v-if="s.me.extension"> · {{ t('ext') }} {{ s.me.extension }}</template></small></span>
      <i v-if="showStatus && s.state" class="sn-st" :class="'st-' + s.state.display_state" :title="stateText(s.state.display_state)"></i>
    </button>
  </aside>
  <div class="content">
  <header class="topbar">
    <button v-if="snPopup && !subnav.slot" class="sn-open" data-panel="open" @click="s.snOpen = !s.snOpen" :title="subnav.title" :aria-label="subnav.title" :aria-expanded="s.snOpen ? 'true' : 'false'"><ico name="panel"></ico></button>
    <div v-if="showStatus && s.state" class="status" :class="'st-' + s.state.display_state" :key="'st-' + s.state.display_state">
      <span class="dot"></span>
      <div>{{ stateText(s.state.display_state) }}
        <small>{{ s.state.reason }} · {{ s.state.phone_label }}</small></div>
    </div>
    <div v-if="!showStatus" class="page-title">{{ pageTitle }}<small>{{ t('app.title') }}</small></div>
    <button v-if="showStatus && !railOn" class="btn go" @click="goReady" :disabled="s.busy || (s.state && s.state.manual_state==='ready' && s.state.computed_state!=='wrap_up')">{{ t('btn.ready') }}</button>
    <button v-if="showStatus && !railOn" class="btn" @click="goBreak" :disabled="s.busy || (s.state && s.state.manual_state==='break')">{{ t('btn.break') }}</button>
    <div class="spacer"></div>
    <button v-if="showStatus && !railOn && s.tab==='work' && !s.editing && dashLayout==='standard'" class="btn sm customize-btn" @click="startEditing"><ico name="edit" style="width:15px;height:15px"></ico> {{ t('ws.customize') }}</button>
    <div v-if="phoneOn" id="ph-bar-slot" class="ph-bar-slot"></div>
    <div class="top-right">
    <div class="ntf-wrap" v-if="showStatus || isAdmin">
      <button class="bell" @click.stop="toggleNtf" :title="t('ntf.title')" :aria-label="t('ntf.title')"><ico name="bell"></ico><span v-if="s.ntf.unread" class="badge" v-flash>{{ s.ntf.unread }}</span></button>
      <div v-if="s.ntfOpen" class="panel ntf-pop">
        <h2>{{ t('ntf.title') }}</h2>
        <div class="body">
          <div v-if="!s.ntf.items.length" class="empty">{{ t('ntf.empty') }}</div>
          <div v-for="n in s.ntf.items.slice(0, 15)" :key="n.id" class="ntf-item" :class="[n.level, {clickable: n.ticket_id && isOperatorView}]" @click="n.ticket_id && isOperatorView && (s.ntfOpen = false, openTicket(n.ticket_id))">
            <span class="ico">{{ ntfIcon(n) }}</span><div class="txt">{{ n.text }}<div class="when">{{ fmt(n.ts, true) }}</div></div>
          </div>
        </div>
      </div>
    </div>
    <div class="live-pill" :class="'lv-' + s.sse" role="status" :title="s.sse==='ok' ? t('live.on_hint') : t('live.lost_hint')">
      <span class="lv-dot" aria-hidden="true"></span>{{ s.sse==='ok' ? t('live.on') : s.sse==='lost' ? t('live.lost') : t('live.connecting') }}
    </div>
    <div class="me" @click="railOn && setTab('mysettings')" :title="railOn ? meTitle : null">
      <user-avatar :name="s.me.name" :url="s.me.avatar_url"></user-avatar>
      <div>
        <div class="me-name">{{ s.me.name }}</div>
        <div class="me-level" v-if="s.me.level">{{ levelText(s.me.level) }}<span v-if="s.me.position" class="me-pos"> · {{ s.me.position }}</span></div>
        <div class="me-meta" v-else>{{ s.me.position || roleText(s.me.role) }}</div>
      </div>
    </div>
    </div>
    <div v-if="phoneOn" id="ph-strip-slot" class="ph-strip-slot"></div>
  </header>

  <main>
    <div v-if="s.sse==='lost'" class="banner error">{{ t('banner.sse') }}</div>
    <div v-if="isOperatorView && s.state && s.state.sync_status!=='ok'" class="banner" :class="{error: s.state.sync_status==='error'}">
      {{ s.state.sync_status==='error' ? t('banner.sync_error') : t('banner.sync_pending') }}
      <span v-if="s.state.sync_error">: {{ s.state.sync_error }}</span>
      <span v-if="s.state.next_retry_at"> · {{ t('banner.retry_at') }} {{ fmt(s.state.next_retry_at) }}</span>
    </div>
    <div v-if="s.ticketsError && s.tab==='work'" class="banner">Zammad: {{ s.ticketsError }}</div>
    <div v-if="showGreeting" class="st-hello">
      <div><h1>{{ greeting }}</h1><p class="mono">{{ greetSub }}</p></div>
    </div>
    <nav v-if="secTabs && !snDocked" class="sec-tabs" :aria-label="secTabs.title">
      <button v-for="x in secTabs.items" :key="x[0]" :data-sec-tab="x[0]" :class="{on: s.tab === x[0]}" @click="setTab(x[0])"><ico :name="x[1]"></ico><span>{{ t(x[2]) }}</span></button>
    </nav>
    <div class="page" :key="s.tab" :data-page="s.tab">

    <!-- ===================== OPERATOR ===================== -->
    <template v-if="s.tab==='work' && isOperatorView">
      <section v-if="s.call" class="panel call" :class="{ringing: s.call.state==='ringing'}">
        <h2>{{ s.call.direction==='out' ? t('call.outgoing') : t('call.incoming') }} <span class="count">{{ callText(s.call.state) }}</span></h2>
        <div class="body">
          <div class="number">{{ s.call.caller_number || t('call.hidden') }}</div>
          <div class="meta empty">{{ [s.call.caller_name, s.call.queue ? t('call.queue') + ' ' + s.call.queue : '', fmt(s.call.started_at)].filter(Boolean).join(' · ') }}</div>
          <div v-if="s.customers.length > 1" class="customer">
            {{ t('call.several') }}
            <div v-for="c in s.customers" :key="c.id"><a href="#" @click.prevent="openCustomer(c.id)">{{ c.name }}</a> <span class="empty">{{ c.email }}</span></div>
          </div>
          <div v-if="s.customerCard" class="customer">
            <div class="title"><b>{{ [s.customerCard.customer.firstname, s.customerCard.customer.lastname].filter(Boolean).join(' ') }}</b></div>
            <div class="meta empty">{{ [s.customerCard.customer.phone || s.customerCard.customer.mobile, s.customerCard.customer.email, s.customerCard.customer.organization].filter(Boolean).join(' · ') }}</div>
            <div v-if="s.customerCard.customer.note" style="margin-top:4px">{{ s.customerCard.customer.note }}</div>
            <div style="margin-top:8px" v-if="s.customerCard.tickets.length">
              <div v-for="tk in s.customerCard.tickets" :key="tk.id" class="meta">
                <a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }} <span class="tag">{{ tk.state }}</span>
              </div>
            </div>
            <div v-else class="empty">{{ t('call.no_tickets') }}</div>
          </div>
          <div v-if="!s.customers.length" class="customer">{{ t('call.not_found') }}</div>
          <div class="item actions" style="border:0">
            <button v-if="s.call.ticket_id" class="btn primary" @click="openTicket(s.call.ticket_id)" data-act="call-open-ticket">{{ t('call.open_ticket') }}</button>
            <button v-else class="btn primary" @click="openTicketForm(true)">{{ t('call.create_ticket') }}</button>
            <button v-if="!s.customers.length" class="btn" @click="openNewCustomer">{{ t('call.create_customer') }}</button>
            <button class="btn" @click="dismissCall">{{ t('call.hide') }}</button>
          </div>
        </div>
      </section>

      <template v-if="dashLayout === 'standard'">
      <div v-if="s.editing" class="panel edit-bar">
        <div class="edit-title">{{ t('ws.editing') }}</div>
        <div class="edit-hint">{{ t('ws.hint') }}</div>
        <div class="edit-row">
          <label class="inline">{{ t('ws.preset') }}
            <select :value="s.prefs.preset" @change="applyPreset($event.target.value)">
              <option v-for="p in presetIds" :key="p" :value="p">{{ t('preset.' + p) }}</option>
              <option v-if="s.prefs.preset==='custom'" value="custom">{{ t('preset.custom') }}</option>
            </select></label>
          <span v-if="hiddenWidgets.length" class="hidden-list">{{ t('ws.hidden') }}:
            <button v-for="w in hiddenWidgets" :key="w.id" class="btn sm" @click="showW(w)">+ {{ widgetName(w.id) }}</button></span>
          <span class="spacer"></span>
          <button class="btn sm" @click="applyPreset('default')">{{ t('ws.reset') }}</button>
          <button class="btn sm primary ws-done" @click="finishEditing">{{ t('ws.done') }}</button>
        </div>
      </div>

      <div class="dash" :class="{editing: s.editing, compact: s.prefs.compact}">
        <div v-for="(w, i) in visibleLayout" :key="w.id" class="widget" :data-w="w.id" :style="{'--i': i}"
             :class="['w' + w.w, 'h-' + w.h, {dragging: s.dragId === w.id, over: s.overId === w.id && s.dragId !== w.id}]"
             :draggable="s.editing" @dragstart="dragStart(w, $event)" @dragover.prevent="s.editing && (s.overId = w.id)"
             @drop.prevent="dropOn(w)" @dragend="s.dragId = null; s.overId = null">
          <div v-if="s.editing" class="widget-tools">
            <span class="grip" :title="t('ws.drag')">⠿</span><b>{{ widgetName(w.id) }}</b>
            <span class="spacer"></span>
            <button class="wt" :title="t('ws.left')" @click="moveW(i, -1)">◀</button>
            <button class="wt" :title="t('ws.right')" @click="moveW(i, 1)">▶</button>
            <button v-for="n in [1, 2, 3]" :key="n" class="wt" :class="{on: w.w === n}" :title="t('ws.width')" @click="setW(w, n)">{{ ['⅓', '⅔', '▭'][n - 1] }}</button>
            <button class="wt" :title="t('ws.height')" @click="cycleH(w)">↕ {{ t('h.' + w.h) }}</button>
            <button class="wt hide" :title="t('ws.hide')" @click="hideW(w)">✕</button>
          </div>
          <template v-if="w.id==='kpis'">
          <div class="kpis">
            <div class="panel kpi blocking"><div class="k">{{ t('kpi.blocking') }}</div><div class="v" v-flash>{{ s.tasks.blocking.length }}</div>
              <div class="sub">{{ s.tasks.blocking.length ? t('tag.blocking') : t('state.ready') }}</div></div>
            <div class="panel kpi background"><div class="k">{{ t('kpi.background') }}</div><div class="v" v-flash>{{ s.tasks.background.length }}</div>
              <div class="sub">{{ t('tag.background') }}</div></div>
            <div class="panel kpi done"><div class="k">{{ t('kpi.done') }}</div><div class="v" v-flash>{{ s.dash ? s.dash.completed_today : '—' }}</div></div>
            <div class="panel kpi calls"><div class="k">{{ t('kpi.calls') }}</div><div class="v" v-flash>{{ s.dash ? s.dash.calls_today : '—' }}</div>
              <div class="sub" v-if="s.dash">{{ t('kpi.calls_sub', {a: s.dash.calls_answered, m: s.dash.calls_missed}) }}</div></div>
            <div class="panel kpi time"><div class="k">{{ t('kpi.busy') }}</div><div class="v">{{ s.dash ? dur(s.dash.busy_sec_today) : '—' }}</div>
              <div class="sub">{{ t('kpi.busy_sub') }}</div></div>
          </div>
          </template>
          <template v-else-if="w.id==='active'">
          <section class="panel">
            <h2>{{ t('panel.active') }} <span class="count">{{ s.tasks.blocking.length }}</span></h2>
            <div class="body">
              <div v-if="!s.tasks.blocking.length" class="empty">{{ t('panel.active_empty') }}</div>
              <div v-for="w in s.tasks.blocking" :key="w.id" class="item">
                <span class="it-ico" :class="'src-' + (w.source || 'x')"><ico :name="srcIcon(w.source)"></ico></span>
                <div class="title"><a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a> {{ w.ticket_title }}</div>
                <div class="meta"><span class="tag blocking">{{ t('tag.blocking') }}</span><span v-if="w.source">{{ srcText(w.source) }}</span><span>{{ t('since') }} {{ fmt(w.started_at) }}</span></div>
                <div class="actions">
                  <button class="btn go sm" @click="openComplete(w)">{{ t('btn.complete') }}</button>
                  <button :disabled="s.busy" class="btn sm" @click="changeMode(w, 'background')">{{ t('btn.background') }}</button>
                  <button :disabled="s.busy" class="btn sm" @click="release(w)">{{ t('btn.postpone') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='background'">
          <section class="panel">
            <h2>{{ t('panel.background') }} <span class="count">{{ s.tasks.background.length }}</span></h2>
            <div class="body">
              <div v-if="!s.tasks.background.length" class="empty">{{ t('panel.background_empty') }}</div>
              <div v-for="w in s.tasks.background" :key="w.id" class="item">
                <span class="it-ico" :class="'src-' + (w.source || 'x')"><ico :name="srcIcon(w.source)"></ico></span>
                <div class="title"><a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a> {{ w.ticket_title }}</div>
                <div class="meta"><span class="tag background">{{ t('tag.background') }}</span><span v-if="w.source">{{ srcText(w.source) }}</span><span>{{ t('since') }} {{ fmt(w.started_at, true) }}</span></div>
                <div class="actions">
                  <button :disabled="s.busy" class="btn primary sm" @click="changeMode(w, 'blocking')">{{ t('btn.start') }}</button>
                  <button class="btn go sm" @click="openComplete(w)">{{ t('btn.complete') }}</button>
                  <button :disabled="s.busy" class="btn sm" @click="release(w)">{{ t('btn.remove') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='notifications'">
          <section class="panel ntf-panel">
            <h2>{{ t('ntf.title') }} <span class="h-actions">
              <button v-if="s.ntf.unread" class="btn sm" @click="markRead">{{ t('ntf.mark_read') }}</button>
              <button v-if="s.desktop==='default'" class="btn sm" @click="enableDesktop">{{ t('ntf.desktop') }}</button>
            </span></h2>
            <div class="body">
              <div v-if="!s.ntf.items.length" class="empty">{{ t('ntf.empty') }}</div>
              <div v-for="n in s.ntf.items" :key="n.id" class="ntf-item" :class="[n.level, {unread: isUnread(n), clickable: n.ticket_id}]" @click="n.ticket_id && openTicket(n.ticket_id)">
                <span class="ico">{{ ntfIcon(n) }}</span><div class="txt">{{ n.text }}<div class="when">{{ fmt(n.ts, true) }}</div></div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='new'">
          <section class="panel">
            <h2>{{ t('panel.new') }} <span class="count">{{ s.unassigned.length }}</span></h2>
            <div class="body">
              <div v-if="!s.unassigned.length" class="empty">{{ t('panel.new_empty') }}</div>
              <div v-for="tk in s.unassigned" :key="tk.id" class="item">
                <span class="it-ico" :class="'src-' + (tk.source || 'x')"><ico :name="srcIcon(tk.source)"></ico></span>
                <div class="title"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }}</div>
                <div class="meta"><span class="tag">{{ srcText(tk.source) || '—' }}</span><span>{{ tk.group }}</span><span>{{ fmt(tk.created_at, true) }}</span></div>
                <div class="actions">
                  <button :disabled="s.busy" class="btn primary sm" @click="startTicket(tk, 'blocking')">{{ t('btn.start') }}</button>
                  <button :disabled="s.busy" class="btn sm" @click="startTicket(tk, 'background')">{{ t('btn.background') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='mine'">
          <section class="panel">
            <h2>{{ t('panel.mine') }} <span class="count">{{ freeMine.length }}</span></h2>
            <div class="body">
              <div v-if="!freeMine.length" class="empty">{{ t('panel.mine_empty') }}</div>
              <div v-for="tk in freeMine" :key="tk.id" class="item">
                <span class="it-ico" :class="'src-' + (tk.source || 'x')"><ico :name="srcIcon(tk.source)"></ico></span>
                <div class="title"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }}</div>
                <div class="meta"><span class="tag">{{ tk.state }}</span><span>{{ srcText(tk.source) }}</span><span>{{ fmt(tk.updated_at, true) }}</span></div>
                <div class="actions">
                  <button :disabled="s.busy" class="btn primary sm" @click="startTicket(tk, 'blocking')">{{ t('btn.start') }}</button>
                  <button :disabled="s.busy" class="btn sm" @click="startTicket(tk, 'background')">{{ t('btn.background') }}</button>
                </div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='pending'">
          <section class="panel">
            <h2>{{ t('panel.pending') }} <span class="count">{{ s.mine.pending.length }}</span></h2>
            <div class="body">
              <div v-if="!s.mine.pending.length" class="empty">{{ t('panel.pending_empty') }}</div>
              <div v-for="tk in s.mine.pending" :key="tk.id" class="item">
                <span class="it-ico" :class="'src-' + (tk.source || 'x')"><ico :name="srcIcon(tk.source)"></ico></span>
                <div class="title"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)">#{{ tk.number }}</a> {{ tk.title }}</div>
                <div class="meta"><span class="tag">{{ tk.state }}</span><span>{{ fmt(tk.updated_at, true) }}</span></div>
                <div class="actions" v-if="!tk.session"><button :disabled="s.busy" class="btn sm" @click="startTicket(tk, 'blocking')">{{ t('btn.start') }}</button></div>
              </div>
            </div>
          </section>
          </template>
          <template v-else-if="w.id==='calls'">
          <section class="panel">
            <h2>{{ t('panel.calls') }} <span class="count">{{ s.calls.length }}</span></h2>
            <div class="body">
              <div v-if="!s.calls.length" class="empty">{{ t('panel.calls_empty') }}</div>
              <div v-for="c in s.calls" :key="c.id" class="item">
                <div class="title">{{ c.direction==='out' ? '↗' : '↙' }} {{ c.caller_number || t('hidden') }} <span class="empty">{{ c.caller_name }}</span></div>
                <div class="meta">
                  <span class="tag">{{ callText(c.state) }}</span>
                  <span>{{ fmt(c.started_at, true) }}</span><span v-if="c.queue">{{ t('call.queue') }} {{ c.queue }}</span>
                  <a v-if="c.ticket_id" :href="zLink(c.ticket_id)" @click.prevent="openTicket(c.ticket_id)">{{ t('link.ticket') }}</a>
                  <a v-if="c.recording_url" :href="c.recording_url" target="_blank" @click="playRecording($event, c)">{{ t('link.recording') }}</a>
                </div>
                <div class="actions"><button v-if="!c.ticket_id" class="btn sm" @click="reopenCall(c)">{{ t('btn.card') }}</button>
                  <button v-if="c.caller_number" class="btn sm dial-btn" @click="dialNumber(c.caller_number, c.caller_name)" data-act="call-back"><ico name="phone"></ico> {{ t('ph.call') }}</button></div>
              </div>
            </div>
          </section>
          </template>
        </div>
      </div>
      </template>

      <!-- v3.14: other layouts of «My workplace» (chosen in My settings → Interface) — same data and actions -->
      <div v-else class="dl" :class="'dlv-' + dashLayout" :data-dash="dashLayout">
        <div v-if="dashLayout !== 'inbox'" class="dl-strip">
          <div><span>{{ t('kpi.blocking') }}</span><b v-flash>{{ s.tasks.blocking.length }}</b></div>
          <div><span>{{ t('kpi.background') }}</span><b v-flash>{{ s.tasks.background.length }}</b></div>
          <div><span>{{ t('kpi.done') }}</span><b v-flash>{{ s.dash ? s.dash.completed_today : '—' }}</b></div>
          <div><span>{{ t('kpi.calls') }}</span><b v-flash>{{ s.dash ? s.dash.calls_today : '—' }}</b><small v-if="s.dash">{{ t('kpi.calls_sub', {a: s.dash.calls_answered, m: s.dash.calls_missed}) }}</small></div>
          <div><span>{{ t('kpi.busy') }}</span><b>{{ s.dash ? dur(s.dash.busy_sec_today) : '—' }}</b></div>
        </div>

        <!-- ===== Focus: the next thing to do ===== -->
        <div v-if="dashLayout === 'focus'" class="dl-focus">
          <div class="dl-col">
            <section v-if="s.tasks.blocking.length" class="dl-box dl-now active" data-focus="active">
              <h3><span class="tag blocking">{{ t('tag.blocking') }}</span>{{ t('dl.now') }}</h3>
              <div class="dl-hero" v-for="w in s.tasks.blocking.slice(0, 1)" :key="w.id">
                <span class="dl-ico" :class="'src-' + (w.source || 'x')"><ico :name="srcIcon(w.source)"></ico></span>
                <div class="dl-hero-t"><div class="mono dl-meta">#{{ w.ticket_number }} · {{ srcText(w.source) || '—' }} · {{ t('since') }} {{ fmt(w.started_at) }}</div>
                  <a class="dl-big" :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">{{ w.ticket_title }}</a>
                  <div class="dl-acts"><button class="btn go" @click="openComplete(w)">{{ t('btn.complete') }}</button>
                    <button :disabled="s.busy" class="btn" @click="changeMode(w, 'background')">{{ t('btn.background') }}</button><button :disabled="s.busy" class="btn" @click="release(w)">{{ t('btn.postpone') }}</button></div></div>
              </div>
            </section>
            <section v-else class="dl-box dl-now" data-focus="next">
              <h3><span class="tag ok">{{ t('state.ready') }}</span>{{ t('dl.next') }}<small>{{ t('dl.oldest_first') }}</small></h3>
              <div v-if="!focusItem" class="empty">{{ t('dl.nothing') }}</div>
              <div v-else class="dl-hero">
                <span class="dl-ico" :class="'src-' + (focusItem.source || 'x')"><ico :name="srcIcon(focusItem.source)"></ico></span>
                <div class="dl-hero-t"><div class="mono dl-meta">#{{ focusItem.number }} · {{ srcText(focusItem.source) || '—' }} · {{ focusItem.kind === 'new' ? t('dl.waiting') + ' ' + ago(focusItem.created_at) : t('dl.assigned') }}</div>
                  <a class="dl-big" :href="zLink(focusItem.id)" @click.prevent="openTicket(focusItem.id)">{{ focusItem.title }}</a>
                  <div class="dl-sub">{{ focusItem.group }}</div>
                  <div class="dl-acts"><button :disabled="s.busy" class="btn primary" data-act="focus-start" @click="startTicket(focusItem, 'blocking')">{{ t('dl.start_blocks') }}</button>
                    <button :disabled="s.busy" class="btn" @click="startTicket(focusItem, 'background')">{{ t('btn.background') }}</button>
                    <button v-if="focusQueue.length > 1" class="btn dl-skip" data-act="focus-skip" @click="s.focusSkip++">{{ t('dl.skip') }} ›</button></div></div>
              </div>
            </section>
            <section class="dl-box">
              <h3>{{ t('panel.background') }} <b class="dl-c">{{ s.tasks.background.length }}</b></h3>
              <div v-if="!s.tasks.background.length" class="empty">{{ t('panel.background_empty') }}</div>
              <div v-for="w in s.tasks.background" :key="w.id" class="dl-row">
                <span class="dl-ico sm" :class="'src-' + (w.source || 'x')"><ico :name="srcIcon(w.source)"></ico></span>
                <div class="dl-t"><a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)"><span class="mono">#{{ w.ticket_number }}</span> {{ w.ticket_title }}</a><small>{{ t('since') }} {{ fmt(w.started_at, true) }}</small></div>
                <button :disabled="s.busy" class="btn sm primary" @click="changeMode(w, 'blocking')">{{ t('btn.start') }}</button><button class="btn sm go" @click="openComplete(w)">{{ t('btn.complete') }}</button>
              </div>
            </section>
          </div>
          <div class="dl-col">
            <section class="dl-box" data-list="queue">
              <h3>{{ t('dl.queue') }} <b class="dl-c">{{ s.unassigned.length }}</b></h3>
              <div v-if="!s.unassigned.length" class="empty">{{ t('panel.new_empty') }}</div>
              <div v-for="tk in sortedNew" :key="tk.id" class="dl-row" :class="{cur: focusItem && focusItem.id === tk.id}">
                <span class="dl-ico sm" :class="'src-' + (tk.source || 'x')"><ico :name="srcIcon(tk.source)"></ico></span>
                <div class="dl-t"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)"><span class="mono">#{{ tk.number }}</span> {{ tk.title }}</a><small>{{ tk.group }} · {{ t('dl.waiting') }} {{ ago(tk.created_at) }}</small></div>
              </div>
            </section>
            <section class="dl-box">
              <h3>{{ t('panel.mine') }} <b class="dl-c">{{ freeMine.length }}</b></h3>
              <div v-if="!freeMine.length" class="empty">{{ t('panel.mine_empty') }}</div>
              <div v-for="tk in freeMine" :key="tk.id" class="dl-row">
                <span class="dl-ico sm" :class="'src-' + (tk.source || 'x')"><ico :name="srcIcon(tk.source)"></ico></span>
                <div class="dl-t"><a :href="zLink(tk.id)" @click.prevent="openTicket(tk.id)"><span class="mono">#{{ tk.number }}</span> {{ tk.title }}</a><small>{{ tk.state }}</small></div>
                <button :disabled="s.busy" class="btn sm primary" @click="startTicket(tk, 'blocking')">{{ t('btn.start') }}</button>
              </div>
            </section>
          </div>
        </div>

        <!-- ===== Board: columns by stage ===== -->
        <div v-else-if="dashLayout === 'board'" class="dl-board">
          <section v-for="col in boardCols" :key="col.id" class="dl-colb" :data-col="col.id">
            <h3><i :class="'dot-' + col.id"></i>{{ col.title }} <b class="dl-c">{{ col.items.length }}</b></h3>
            <div v-if="!col.items.length" class="empty">{{ col.empty }}</div>
            <div v-for="it in col.items" :key="it.key" class="dl-card" :class="{hot: it.kind === 'active'}">
              <a :href="zLink(it.id)" @click.prevent="openTicket(it.id)">{{ it.title }}</a>
              <div class="dl-mm"><span class="mono">#{{ it.number }}</span><ico :name="srcIcon(it.source)"></ico><span>{{ it.note }}</span></div>
              <div class="dl-cacts">
                <template v-if="it.kind === 'active'"><button class="btn sm go" @click="openComplete(it.w)">{{ t('btn.complete') }}</button><button :disabled="s.busy" class="btn sm" @click="changeMode(it.w, 'background')">{{ t('btn.background') }}</button></template>
                <template v-else-if="it.kind === 'background'"><button :disabled="s.busy" class="btn sm primary" @click="changeMode(it.w, 'blocking')">{{ t('btn.start') }}</button><button class="btn sm go" @click="openComplete(it.w)">{{ t('btn.complete') }}</button></template>
                <template v-else-if="!it.session"><button :disabled="s.busy" class="btn sm primary" @click="startTicket(it.tk, 'blocking')">{{ t('btn.start') }}</button><button :disabled="s.busy" v-if="it.kind !== 'pending'" class="btn sm" @click="startTicket(it.tk, 'background')">{{ t('btn.bg_short') }}</button></template>
              </div>
            </div>
          </section>
        </div>

        <!-- ===== Inbox: everything in one list ===== -->
        <div v-else-if="dashLayout === 'inbox'" class="dl-inbox">
          <section class="dl-box">
            <div class="dl-chips">
              <button v-for="f in inboxKinds" :key="f.id" class="dl-chip" :class="{on: s.dlKind === f.id}" :data-kind="f.id" @click="s.dlKind = f.id">{{ f.label }} <b>{{ f.n }}</b></button>
              <span class="dl-sep"></span>
              <button v-for="c in inboxChannels" :key="c.id" class="dl-chip" :class="{on: s.dlCh === c.id}" :data-ch="c.id" @click="s.dlCh = s.dlCh === c.id ? '' : c.id" :title="srcText(c.id)"><ico :name="srcIcon(c.id)"></ico><b>{{ c.n }}</b></button>
            </div>
            <div v-if="!inboxItems.length" class="empty">{{ t('dl.nothing') }}</div>
            <div v-for="it in inboxItems" :key="it.key" class="dl-row" :data-kind="it.kind">
              <span class="dl-ico sm" :class="'src-' + (it.source || 'x')"><ico :name="srcIcon(it.source)"></ico></span>
              <div class="dl-t"><a :href="zLink(it.id)" @click.prevent="openTicket(it.id)"><span class="mono">#{{ it.number }}</span> {{ it.title }}</a><small>{{ it.label }} · {{ it.note }}</small></div>
              <template v-if="it.kind === 'active'"><button class="btn sm go" @click="openComplete(it.w)">{{ t('btn.complete') }}</button></template>
              <template v-else-if="it.kind === 'background'"><button :disabled="s.busy" class="btn sm primary" @click="changeMode(it.w, 'blocking')">{{ t('btn.start') }}</button></template>
              <template v-else-if="!it.session"><button :disabled="s.busy" class="btn sm primary" @click="startTicket(it.tk, 'blocking')">{{ t('btn.start') }}</button><button :disabled="s.busy" v-if="it.kind !== 'pending'" class="btn sm" @click="startTicket(it.tk, 'background')">{{ t('btn.background') }}</button></template>
            </div>
          </section>
          <div class="dl-col">
            <section class="dl-box dl-today">
              <h3>{{ t('dl.today') }}</h3>
              <div class="dl-tg">
                <div><span>{{ t('kpi.calls') }}</span><b>{{ s.dash ? s.dash.calls_today : '—' }}</b></div>
                <div><span>{{ t('kpi.done') }}</span><b>{{ s.dash ? s.dash.completed_today : '—' }}</b></div>
                <div><span>{{ t('dl.answered') }}</span><b>{{ answeredPct }}</b><i class="dl-gauge"><i :style="{width: answeredPct}"></i></i></div>
                <div><span>{{ t('kpi.busy') }}</span><b>{{ s.dash ? dur(s.dash.busy_sec_today) : '—' }}</b></div>
              </div>
            </section>
            <section class="dl-box">
              <h3>{{ t('ntf.title') }} <b class="dl-c">{{ s.ntf.unread }}</b></h3>
              <div v-if="!s.ntf.items.length" class="empty">{{ t('ntf.empty') }}</div>
              <div v-for="n in s.ntf.items.slice(0, 5)" :key="n.id" class="ntf-item" :class="[n.level, {unread: isUnread(n), clickable: n.ticket_id}]" @click="n.ticket_id && openTicket(n.ticket_id)">
                <span class="ico">{{ ntfIcon(n) }}</span><div class="txt">{{ n.text }}<div class="when">{{ fmt(n.ts, true) }}</div></div>
              </div>
            </section>
            <section class="dl-box">
              <h3>{{ t('panel.calls') }} <b class="dl-c">{{ s.calls.length }}</b></h3>
              <div v-if="!s.calls.length" class="empty">{{ t('panel.calls_empty') }}</div>
              <div v-for="c in s.calls.slice(0, 5)" :key="c.id" class="dl-row">
                <span class="dl-ico sm src-phone"><ico name="phone"></ico></span>
                <div class="dl-t"><b>{{ c.caller_name || c.caller_number || '—' }}</b><small class="mono">{{ c.caller_number }} · {{ fmt(c.started_at) }}</small></div>
                <span class="dl-cs" :class="c.state">{{ callText(c.state) }}</span>
                <button v-if="c.caller_number" class="btn sm" @click="dialNumber(c.caller_number, c.caller_name)" :title="t('ph.call')"><ico name="phone" style="width:14px;height:14px"></ico></button>
              </div>
            </section>
          </div>
        </div>

        <!-- ===== Table: dense ===== -->
        <div v-else-if="dashLayout === 'table'" class="dl-tablewrap">
          <div class="dl-chips" style="margin-bottom:10px">
            <button v-for="f in tableKinds" :key="f.id" class="dl-chip" :class="{on: s.dlTable === f.id}" :data-tkind="f.id" @click="s.dlTable = f.id">{{ f.label }} <b>{{ f.n }}</b></button>
          </div>
          <div class="panel table-wrap"><table class="dl-table">
            <thead><tr><th></th><th>#</th><th>{{ t('dl.col.title') }}</th><th>{{ t('dl.col.channel') }}</th><th>{{ t('dl.col.group') }}</th><th>{{ t('dl.col.status') }}</th><th>{{ t('dl.col.age') }}</th><th></th></tr></thead>
            <tbody>
              <tr v-if="!tableItems.length"><td colspan="8" class="empty">{{ t('dl.nothing') }}</td></tr>
              <tr v-for="it in tableItems" :key="it.key" :class="{hl: it.kind === 'active'}" :data-kind="it.kind">
                <td><span class="dl-ico xs" :class="'src-' + (it.source || 'x')"><ico :name="srcIcon(it.source)"></ico></span></td>
                <td class="mono"><a :href="zLink(it.id)" @click.prevent="openTicket(it.id)">{{ it.number }}</a></td>
                <td class="dl-ti"><a :href="zLink(it.id)" @click.prevent="openTicket(it.id)">{{ it.title }}</a></td>
                <td>{{ srcText(it.source) || '—' }}</td><td>{{ it.group || '—' }}</td>
                <td><span class="tag" :class="it.tagCls">{{ it.label }}</span></td>
                <td class="mono">{{ it.age || '—' }}</td>
                <td class="nowrap">
                  <template v-if="it.kind === 'active'"><button class="btn sm go" @click="openComplete(it.w)">{{ t('btn.complete') }}</button></template>
                  <template v-else-if="it.kind === 'background'"><button :disabled="s.busy" class="btn sm primary" @click="changeMode(it.w, 'blocking')">{{ t('btn.start') }}</button></template>
                  <template v-else-if="!it.session"><button :disabled="s.busy" class="btn sm primary" @click="startTicket(it.tk, 'blocking')">{{ t('btn.start') }}</button> <button :disabled="s.busy" v-if="it.kind !== 'pending'" class="btn sm" @click="startTicket(it.tk, 'background')">{{ t('btn.bg_short') }}</button></template>
                </td>
              </tr>
            </tbody>
          </table></div>
        </div>
      </div>
    </template>

    <!-- ===================== TICKETS & CUSTOMERS (v3.3) ===================== -->
    <tickets-page v-if="s.tab==='tickets' && isOperatorView" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :config="s.config"
                  :token="s.token" :open-req="s.tkOpen" :new-req="s.tkNew" :state-text="stateText" :studio="snDocked"
                  @open-customer="(id) => openContact(id, 'customers')"></tickets-page>
    <contacts-page v-if="s.tab==='contacts'" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :open-req="s.ctOpen"
                   @open-ticket="openTicket" @new-ticket="newTicketFor"></contacts-page>

    <!-- ===================== WHATSAPP / TELEGRAM (v3.9) and MAIL ===================== -->
    <inbox-page v-if="(s.tab==='whatsapp' || s.tab==='telegram') && isOperatorView" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :token="s.token"
                :channel="s.tab" :open-req="s.inOpen" @open-ticket="openTicket" @open-customer="(id) => openContact(id, 'customers')"
                @counts="(c) => s.msgCounts = c"></inbox-page>
    <mail-page v-if="s.tab==='mail' && isOperatorView" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :token="s.token"
               @open-ticket="openTicket" @unseen="(n) => s.mailUnseen = n"></mail-page>

    <!-- ===================== v3.15 MANAGER TOOLS ===================== -->
    <shifts-page v-if="s.tab==='shifts' && isSup" :api="api" :t="t" :toast="toast" :tz="s.config.timezone" :locale="locale" :live="s.mgLive"></shifts-page>
    <recordings-page v-if="s.tab==='recordings' && isSup" :api="api" :t="t" :toast="toast" :fmt="fmt" :tz="s.config.timezone"
                     :locale="locale" :token="s.token" :sup="isSup" :live="s.mgLive"></recordings-page>
    <log-page v-if="s.tab==='log' && isSup" :api="api" :t="t" :toast="toast" :fmt="fmt" :tz="s.config.timezone" :token="s.token" :live="s.mgLive"></log-page>

    <!-- ===================== MY SETTINGS ===================== -->
    <div v-if="s.tab==='mysettings'" class="my-settings">
      <section class="panel if-sec" data-sec="interface">
        <h2>{{ t('set.interface') }}</h2>
        <div class="body">
          <div class="hint if-lead">{{ t('set.interface_hint') }}</div>
          <div class="if-grid">
            <div class="if-group" data-group="look">
              <h3>{{ t('set.look') }}</h3>
          <label>{{ t('set.style') }}</label>
          <div class="styles" role="radiogroup" :aria-label="t('set.style')">
            <button class="preset style-opt" role="radio" :aria-checked="s.prefs.style==='classic'" :class="{on: s.prefs.style==='classic'}" data-style-opt="classic" @click="setStyle('classic')">
              <div class="style-mini sm-classic"><i class="r"></i><div><i class="k"></i><i class="a"></i><i class="b"></i></div></div>
              <b>{{ t('set.style_classic') }}</b> <span v-if="s.prefs.style==='classic'" class="tag ok">{{ t('set.current') }}</span>
              <div class="hint">{{ t('set.style_classic_d') }}</div>
            </button>
            <button class="preset style-opt" role="radio" :aria-checked="studio" :class="{on: studio}" data-style-opt="studio" @click="setStyle('studio')">
              <div class="style-mini sm-studio"><i class="r"></i><i class="sn"></i><div><i class="k"></i><i class="a"></i><i class="b"></i></div></div>
              <b>{{ t('set.style_studio') }}</b> <span v-if="studio" class="tag ok">{{ t('set.current') }}</span>
              <div class="hint">{{ t('set.style_studio_d') }}</div>
            </button>
            <button class="preset style-opt" role="radio" :aria-checked="flow" :class="{on: flow}" data-style-opt="flow" @click="setStyle('flow')">
              <div class="style-mini sm-flow"><div><i class="nv"></i><i class="k"></i><i class="a"></i><i class="b"></i></div><i class="tb"></i></div>
              <b>{{ t('set.style_flow') }}</b> <span v-if="flow" class="tag ok">{{ t('set.current') }}</span><span v-else class="tag background">{{ t('set.new') }}</span>
              <div class="hint">{{ t('set.style_flow_d') }}</div>
            </button>
          </div>
          <div class="hint">{{ t('set.style_hint') }}</div>
          <template v-if="studio">
            <label>{{ t('set.panel') }}</label>
            <div class="styles" role="radiogroup" :aria-label="t('set.panel')">
              <button class="preset style-opt" role="radio" :aria-checked="s.prefs.panel !== 'popup'" :class="{on: s.prefs.panel !== 'popup'}" data-panel-opt="docked" @click="setPanel('docked')">
                <div class="style-mini sm-studio pm-docked"><i class="r"></i><i class="sn"></i><div><i class="k"></i><i class="a"></i><i class="b"></i></div></div>
                <b>{{ t('set.panel_docked') }}</b> <span v-if="s.prefs.panel !== 'popup'" class="tag ok">{{ t('set.current') }}</span>
                <div class="hint">{{ t('set.panel_docked_d') }}</div>
              </button>
              <button class="preset style-opt" role="radio" :aria-checked="s.prefs.panel === 'popup'" :class="{on: s.prefs.panel === 'popup'}" data-panel-opt="popup" @click="setPanel('popup')">
                <div class="style-mini sm-studio pm-popup"><i class="r"></i><div><i class="k"></i><i class="a"></i><i class="b"></i></div><i class="fl"></i></div>
                <b>{{ t('set.panel_popup') }}</b> <span v-if="s.prefs.panel === 'popup'" class="tag ok">{{ t('set.current') }}</span>
                <div class="hint">{{ t('set.panel_popup_d') }}</div>
              </button>
            </div>
          </template>
            </div>
            <div class="if-group" data-group="theme">
              <h3>{{ t('set.theme_motion') }}</h3>
          <label>{{ t('set.theme') }}</label>
          <div class="seg">
            <button :class="{on: !s.theme || s.theme==='dark'}" data-theme-opt="dark" @click="setTheme('dark')">{{ t('set.theme_dark') }}</button>
            <button :class="{on: s.theme==='light'}" data-theme-opt="light" @click="setTheme('light')">{{ t('set.theme_light') }}</button>
            <button :class="{on: s.theme==='system'}" data-theme-opt="system" @click="setTheme('system')">{{ t('set.theme_system') }}</button>
          </div>
          <label class="check" v-if="isOperatorView"><input type="checkbox" name="compact" :checked="s.prefs.compact" @change="toggleCompact"> {{ t('set.compact') }}</label>
          <label class="check"><input type="checkbox" name="motion" :checked="s.prefs.motion" @change="toggleMotion"> {{ t('set.motion') }}</label>
          <div class="hint">{{ t('set.motion_hint') }}</div>
          <label>{{ t('set.zoom') }}</label>
          <div class="seg zoom-seg" data-zoom-opts>
            <button v-for="z in zoomOpts" :key="z" :class="{on: (s.prefs.zoom || 'auto') === z}" :data-zoom-opt="z" @click="setZoom(z)">{{ z === 'auto' ? t('set.zoom_auto') : z + ' %' }}</button>
          </div>
          <div class="hint">{{ t('set.zoom_hint') }}</div>
            </div>
          </div>
          <div v-if="isOperatorView" class="if-group" data-group="home">
            <h3>{{ t('set.home') }}</h3>
            <div class="hint">{{ t('set.home_hint') }}</div>
            <div class="dash-opts" role="radiogroup" :aria-label="t('set.home')">
              <button v-for="d in ['standard','focus','board','inbox','table']" :key="d" class="preset dash-opt" role="radio" :aria-checked="dashLayout === d" :class="{on: dashLayout === d}" :data-dash-opt="d" @click="setDash(d)">
                <div class="dash-mini" :class="'dm-' + d"><i></i><i></i><i></i><i></i><i></i><i></i></div>
                <b>{{ t('dash.' + d) }}</b> <span v-if="dashLayout === d" class="tag ok">{{ t('set.current') }}</span>
                <div class="hint">{{ t('dash.' + d + '_d') }}</div>
              </button>
            </div>
            <template v-if="dashLayout === 'standard'">
              <div class="if-sub"><b>{{ t('set.workspace') }}</b><span class="hint">{{ t('set.workspace_hint') }}</span>
                <button class="btn sm primary" @click="startEditing"><ico name="edit" style="width:15px;height:15px"></ico> {{ t('ws.customize') }}</button></div>
          <div class="presets">
            <button v-for="p in presetIds" :key="p" class="preset" :class="{on: s.prefs.preset===p}" :data-preset="p" @click="applyPreset(p)">
              <div class="mini"><span v-for="w in PRESETS_PREVIEW[p]" :key="w.id" :class="'m' + w.w + ' mh-' + w.h"></span></div>
              <b>{{ t('preset.' + p) }}</b> <span v-if="s.prefs.preset===p" class="tag ok">{{ t('set.current') }}</span>
              <div class="hint">{{ t('preset.' + p + '_d') }}</div>
            </button>
            <div v-if="s.prefs.preset==='custom'" class="preset on"><div class="mini"><span v-for="w in visibleLayout" :key="w.id" :class="'m' + w.w + ' mh-' + w.h"></span></div>
              <b>{{ t('preset.custom') }}</b> <span class="tag ok">{{ t('set.current') }}</span></div>
          </div>
            </template>
          </div>
        </div>
      </section>

      <section class="panel" v-if="isOperatorView" data-sec="alerts">
        <h2>{{ t('set.alerts') }}</h2>
        <div class="body">
          <label class="check"><input type="checkbox" name="sound" :checked="s.prefs.sound" @change="toggleSound"> {{ t('set.sound') }}</label>
          <div class="push-row">
            <div><b>{{ t('push.title') }}</b><div class="hint">{{ t('push.hint') }}</div></div>
            <button v-if="s.push === 'off'" class="btn sm primary push-on" @click="enablePush">{{ t('push.enable') }}</button>
            <button v-else-if="s.push === 'on'" class="btn sm push-off" @click="disablePush">{{ t('push.disable') }}</button>
            <span v-else class="tag off">{{ t('push.' + s.push) }}</span>
          </div>
          <div style="margin-top:10px">
            <button v-if="s.desktop==='default'" class="btn sm" @click="enableDesktop">{{ t('ntf.desktop') }}</button>
            <span v-else-if="s.desktop==='granted'" class="tag ok">{{ t('ntf.desktop_on') }}</span>
          </div>
        </div>
      </section>

      <phone-settings v-if="phoneOn" data-sec="phone" :t="t" :me="s.me" :api="api" :dnd="!!(s.state && s.state.dnd)"></phone-settings>

      <section class="panel" data-sec="account">
        <h2>{{ t('set.account') }} <span class="h-actions"><button class="btn sm" @click="openPassword"><ico name="key" style="width:15px;height:15px"></ico> {{ t('btn.change_password') }}</button></span></h2>
        <div class="body av-set">
          <user-avatar :name="s.me.name" :url="s.me.avatar_url" cls="xl"></user-avatar>
          <div class="av-ctl">
            <b>{{ t('av.title') }}</b>
            <div class="hint">{{ t('av.hint') }}</div>
            <div class="av-row">
              <div class="seg av-mode" v-if="s.me.has_photo">
                <button :class="{on: s.me.avatar_mode==='photo'}" data-av="photo" @click="setAvatarMode('photo')">{{ t('av.use_photo') }}</button>
                <button :class="{on: s.me.avatar_mode!=='photo'}" data-av="initials" @click="setAvatarMode('initials')">{{ t('av.use_initials') }} · {{ nameInitials(s.me.name) }}</button>
              </div>
              <button class="btn sm primary" data-av="upload" :disabled="s.avatarBusy" @click="pickAvatar">{{ s.avatarBusy ? t('av.busy') : s.me.has_photo ? t('av.change') : t('av.upload') }}</button>
              <button v-if="s.me.has_photo" class="btn sm danger" data-av="delete" @click="deleteAvatar">{{ t('av.delete') }}</button>
            </div>
          </div>
        </div>
        <div class="body account">
          <div><span>{{ t('set.name') }}</span><b>{{ s.me.name }}</b></div>
          <div><span>{{ t('set.username') }}</span><b>{{ s.me.username }}</b></div>
          <div><span>{{ t('set.level') }}</span><b>{{ levelText(s.me.level) }}</b></div>
          <div><span>{{ t('set.position') }}</span><b>{{ s.me.position || '—' }}</b></div>
          <div><span>{{ t('set.role') }}</span><b>{{ roleText(s.me.role) }}</b></div>
          <div v-if="s.me.extension"><span>{{ t('ext') }}</span><b>{{ s.me.extension }}</b></div>
        </div>
      </section>
    </div>

    <!-- ===================== ADMIN ===================== -->
    <admin-panel v-if="isAdmin && ['users','integrations','settings','groups','types','routing','system','backup','apikeys'].includes(s.tab)"
                 :view="s.tab" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :upload="uploadFile"></admin-panel>

    <!-- ===================== MESSENGER (v3.0) ===================== -->
    <div v-if="s.tab==='chat'" class="chat" :class="{'has-peer': chatKey, 'info-open': s.chat.info && chatPeer}">
      <aside class="chat-list" :aria-label="t('nav.chat')">
        <div class="chat-tools">
          <label class="chat-search">
            <ico name="search"></ico>
            <input v-model="s.chat.q" @input="searchContacts" name="chat-search" type="search" :placeholder="t('chat.search')" autocomplete="off">
          </label>
          <button class="ch-btn new-group" data-act="new-group" @click="openNewGroup" :title="t('chat.new_group')" :aria-label="t('chat.new_group')"><ico name="team"></ico><b>+</b></button>
        </div>
        <button v-if="s.push === 'off'" class="push-banner" @click="enablePush"><ico name="bell"></ico><span>{{ t('push.banner') }}</span></button>
        <div v-if="s.chat.q.trim()" class="chat-sec">{{ t('chat.search_results') }}</div>
        <transition-group name="cl" tag="div" class="chat-items">
          <button v-for="c in s.chat.contacts" :key="convKey(c)" class="chat-item" :class="{on: convKey(c) === chatKey, group: c.kind === 'group'}"
                  :data-user="c.kind === 'group' ? null : c.id" :data-group="c.kind === 'group' ? c.id : null" @click="openChat(c)">
            <span class="av" :class="[avClass(c.id), {grp: c.kind === 'group'}]"><ico v-if="c.kind === 'group'" name="team"></ico><img v-else-if="c.avatar_url" :src="c.avatar_url" alt=""><template v-else>{{ initials2(c.name) }}</template><i v-if="c.online" class="av-online" aria-hidden="true"></i></span>
            <span class="ci-main">
              <span class="ci-top"><b class="ci-name">{{ c.name }}</b><time v-if="c.last">{{ shortTime(c.last.at) }}</time></span>
              <span class="ci-bottom">
                <span v-if="typingText(convKey(c))" class="ci-prev typing"><i class="typing-dots" aria-hidden="true"><i></i><i></i><i></i></i>{{ typingText(convKey(c)) }}</span>
                <span v-else-if="c.last" class="ci-prev"><span v-if="c.last.from === s.me.id" class="you">{{ t('chat.you') }}: </span><span v-else-if="c.kind === 'group' && c.last.sender_name" class="you">{{ c.last.sender_name }}: </span>{{ msgPreview(c.last) }}</span>
                <span v-else-if="c.kind === 'group'" class="ci-prev muted">{{ t('chat.members', {n: c.members}) }}</span>
                <span v-else class="ci-prev muted">{{ c.position || levelText(c.level) || roleText(c.role) }}</span>
                <span v-if="c.unread" class="ci-badge">{{ c.unread }}</span>
                <ico v-else-if="c.kind !== 'group' && c.last && c.last.from === s.me.id" :name="c.last.read_at ? 'checks' : 'check'" class="tick" :class="{read: c.last.read_at}"></ico>
              </span>
            </span>
          </button>
          <div v-if="!s.chat.contacts.length" key="none" class="chat-none">{{ s.chat.q ? t('chat.nobody') : t('chat.no_chats') }}</div>
        </transition-group>
      </aside>

      <section class="chat-main" :class="{dragging: s.chat.drag}" @dragover.prevent="chatKey && (s.chat.drag = true)" @dragleave.self="s.chat.drag = false" @drop.prevent="chatKey && onChatDrop($event)">
        <template v-if="chatKey">
          <header class="chat-head">
            <button class="chat-back" @click="chatBack" :aria-label="t('chat.back')"><ico name="back"></ico></button>
            <button class="ch-person" @click="toggleChatInfo" :title="t('chat.info')">
              <span class="av sm" :class="[avClass(s.chat.peer || s.chat.gid), {grp: isGroup}]"><ico v-if="isGroup" name="team"></ico><img v-else-if="chatPeer && chatPeer.avatar_url" :src="chatPeer.avatar_url" alt=""><template v-else>{{ initials2(chatPeer && chatPeer.name) }}</template><i v-if="chatPeer && chatPeer.online" class="av-online" aria-hidden="true"></i></span>
              <span class="ch-text"><b>{{ chatPeer ? chatPeer.name : '' }}</b>
                <small :class="{on: chatPeer && (chatPeer.online || typingText(chatKey))}" data-chat-status>{{ lastSeen(chatPeer) }}</small></span>
            </button>
            <span class="spacer"></span>
            <button class="ch-btn" :class="{on: s.chat.info}" @click="toggleChatInfo" :aria-label="t('chat.info')" :title="t('chat.info')"><ico name="sidebar"></ico></button>
          </header>
          <div class="chat-scroll" @scroll.passive="onChatScroll">
            <div class="chat-msgs">
              <div v-if="s.chat.hasMore" class="chat-more">{{ t('ov.loading') }}</div>
              <div v-if="!s.chat.loading && !s.chat.msgs.length" class="chat-hello">
                <div class="hello-card"><b>{{ t('chat.hello_title') }}</b><span>{{ isGroup ? t('chat.group_hello', {name: chatPeer ? chatPeer.name : ''}) : t('chat.hello_text', {name: chatPeer ? chatPeer.name : ''}) }}</span></div>
              </div>
              <template v-for="it in chatItems" :key="it.key">
                <div v-if="it.kind === 'day'" class="chat-day"><span>{{ it.label }}</span></div>
                <div v-else class="bubble-row" :class="{mine: it.mine, first: it.first, last: it.last, menu: s.chat.menu && s.chat.menu.m.id === it.m.id}">
                  <div class="bubble" :class="{'only-files': !it.m.body && it.m.files && it.m.files.length}" :data-msg="it.m.id" @contextmenu.prevent="openMenu($event, it)"
                       @touchstart.passive="pressStart($event, it)" @touchend="pressEnd" @touchmove.passive="pressEnd">
                    <span v-if="it.who" class="b-who" :class="avClass(it.m.from)">{{ it.who }}</span>
                    <div v-if="it.m.files && it.m.files.length" class="b-files">
                      <template v-for="f in it.m.files" :key="f.key">
                        <button v-if="isImage(f) && s.chat.blobs[f.key] && s.chat.blobs[f.key] !== 'loading'" class="b-img" @click="downloadChatFile(f)" :title="f.name" :data-file="f.key">
                          <img :src="s.chat.blobs[f.key]" :alt="f.name"></button>
                        <button v-else class="b-file" @click="downloadChatFile(f)" :title="f.name" :data-file="f.key">
                          <span class="bf-ico"><ico name="clip"></ico></span><span class="bf-t"><b>{{ f.name }}</b><small>{{ fileSize(f.size) }}</small></span><ico name="download" class="bf-dl"></ico></button>
                      </template>
                    </div>
                    <span v-if="it.m.body" class="b-text">{{ it.m.body }}</span>
                    <span class="b-meta"><span v-if="it.m.edited_at" class="b-edited">{{ t('chat.edited') }}</span><time>{{ fmt(it.m.at) }}</time>
                      <ico v-if="it.mine" :name="!isGroup && it.m.read_at ? 'checks' : 'check'" class="tick" :class="{read: !isGroup && it.m.read_at}"></ico></span>
                    <div v-if="it.m.reactions && it.m.reactions.length" class="b-reacts">
                      <button v-for="r in reactionsOf(it.m)" :key="r.emoji" class="react-chip" :class="{mine: r.mine}" @click="react(it.m, r.emoji)"
                              :aria-pressed="r.mine">{{ r.emoji }}<b v-if="r.n > 1">{{ r.n }}</b></button>
                    </div>
                  </div>
                  <button class="b-more" @click.stop="openMenu($event, it)" :aria-label="t('chat.actions')"><ico name="more"></ico></button>
                </div>
              </template>
              <div v-if="typingText(chatKey)" class="bubble-row typing-row first last" data-typing role="status">
                <div class="bubble typing-bubble"><i class="typing-dots" aria-hidden="true"><i></i><i></i><i></i></i><span>{{ typingText(chatKey) }}</span></div>
              </div>
            </div>
          </div>
          <div v-if="s.chat.drag" class="chat-drop" aria-hidden="true"><ico name="clip"></ico><b>{{ t('chat.drop') }}</b></div>
          <div v-if="s.chat.menu" class="msg-menu" :style="{left: s.chat.menu.x + 'px', top: s.chat.menu.y + 'px'}" role="menu">
            <div class="mm-reacts">
              <button v-for="em in REACTIONS" :key="em" class="mm-react" :data-emoji="em" @click="react(s.chat.menu.m, em)">{{ em }}</button>
            </div>
            <button v-if="s.chat.menu.m.body" class="mm-item" role="menuitem" @click="copyMsg(s.chat.menu.m)"><ico name="copy"></ico>{{ t('chat.copy') }}</button>
            <button v-if="canEdit(s.chat.menu.m) && s.chat.menu.m.body" class="mm-item mm-edit" role="menuitem" @click="startEdit(s.chat.menu.m)"><ico name="edit"></ico>{{ t('chat.edit') }}</button>
            <button v-if="!isGroup || s.chat.menu.mine" class="mm-item danger mm-delete" role="menuitem" @click="askDelete(s.chat.menu.m)"><ico name="trash"></ico>{{ t('chat.delete') }}</button>
          </div>
          <div v-if="s.chat.del" class="chat-dialog-wrap" @click.self="s.chat.del = null">
            <div class="chat-dialog" role="dialog" aria-modal="true">
              <b>{{ t('chat.delete_q') }}</b>
              <p>{{ msgPreview(s.chat.del.m).length > 120 ? msgPreview(s.chat.del.m).slice(0, 120) + '…' : msgPreview(s.chat.del.m) }}</p>
              <label v-if="s.chat.del.m.from === s.me.id && !isGroup" class="check"><input type="checkbox" name="del-all" v-model="s.chat.del.all"> {{ t('chat.delete_all', {name: chatPeer ? chatPeer.name : ''}) }}</label>
              <div v-else-if="!isGroup" class="hint">{{ t('chat.delete_me_only') }}</div>
              <div class="cd-actions"><button class="btn" @click="s.chat.del = null">{{ t('modal.cancel') }}</button>
                <button class="btn danger cd-confirm" @click="confirmDelete">{{ t('chat.delete') }}</button></div>
            </div>
          </div>
          <div v-if="s.chat.editing" class="edit-strip"><ico name="edit"></ico>
            <div><b>{{ t('chat.editing') }}</b><span>{{ s.chat.editing.body }}</span></div>
            <button class="ch-btn" @click="cancelEdit" :aria-label="t('modal.cancel')"><ico name="close"></ico></button></div>
          <div v-if="s.chat.files.length && !s.chat.editing" class="chat-pending" data-pending>
            <div v-for="f in s.chat.files" :key="f.id" class="cp-file" :class="{reading: f.reading}">
              <img v-if="f.url" :src="f.url" alt=""><span v-else class="bf-ico"><ico name="clip"></ico></span>
              <span class="bf-t"><b>{{ f.name }}</b><small>{{ fileSize(f.size) }}</small></span>
              <button type="button" class="cp-x" @click="removeChatFile(f)" :aria-label="t('modal.cancel')"><ico name="close"></ico></button>
            </div>
          </div>
          <div v-if="s.chat.emoji" class="emoji-pop" role="dialog" :aria-label="t('chat.emoji')">
            <div class="em-tabs">
              <button v-if="s.chat.emojiRecent.length" type="button" :class="{on: s.chat.emoji === 'recent'}" @click="s.chat.emoji = 'recent'">{{ t('chat.em.recent') }}</button>
              <button v-for="k in EMOJI_TABS" :key="k" type="button" :class="{on: s.chat.emoji === k}" :data-em-tab="k" @click="s.chat.emoji = k">{{ t('chat.em.' + k) }}</button>
            </div>
            <div class="em-grid">
              <button v-for="em in (s.chat.emoji === 'recent' ? s.chat.emojiRecent : EMOJI[s.chat.emoji])" :key="em" type="button" class="em" :data-em="em" @click="insertEmoji(em)">{{ em }}</button>
            </div>
          </div>
          <form class="chat-compose" @submit.prevent="sendChat">
            <input id="chat-file-input" type="file" multiple hidden @change="addChatFiles($event.target.files)">
            <button v-if="!s.chat.editing" type="button" class="cc-btn" data-act="attach" @click="pickChatFiles" :title="t('chat.attach')" :aria-label="t('chat.attach')"><ico name="clip"></ico></button>
            <textarea v-model="s.chat.text" name="chat-text" rows="1" maxlength="4000" :placeholder="t('chat.write')"
                      @keydown.enter.exact.prevent="sendChat" @keydown.up="editLast" @input="onType" @paste="onChatPaste"></textarea>
            <button type="button" class="cc-btn em-btn" :class="{on: s.chat.emoji}" data-act="emoji" @click.stop="toggleEmoji" :title="t('chat.emoji')" :aria-label="t('chat.emoji')"><span aria-hidden="true">🙂</span></button>
            <button class="send-btn" type="submit" :disabled="(!s.chat.text.trim() && !s.chat.files.length) || s.chat.sending || s.chat.files.some((f) => f.reading)" :aria-label="s.chat.editing ? t('chat.save') : t('chat.send')"><ico :name="s.chat.editing ? 'check' : 'send'"></ico></button>
          </form>
        </template>
        <div v-else class="chat-empty"><span>{{ t('chat.pick') }}</span></div>
      </section>

      <aside v-if="s.chat.info && chatPeer && !isGroup" class="chat-info" :aria-label="t('chat.info')">
        <div class="ci-head">
          <span class="ci-title">{{ t('chat.info') }}</span>
          <button class="ch-btn" @click="s.chat.info = false" :aria-label="t('modal.cancel')"><ico name="close"></ico></button>
        </div>
        <div class="ci-hero">
          <span class="av xl" :class="avClass(chatPeer.id)"><img v-if="chatPeer.avatar_url" :src="chatPeer.avatar_url" alt=""><template v-else>{{ initials2(chatPeer.name) }}</template><i v-if="chatPeer.online" class="av-online" aria-hidden="true"></i></span>
          <b>{{ chatPeer.name }}</b>
          <small :class="{on: chatPeer.online}">{{ lastSeen(chatPeer) }}</small>
        </div>
        <div class="ci-rows" v-if="s.chat.profile && s.chat.profile.kind !== 'group'">
          <div class="ci-row" v-if="s.chat.profile.position"><ico name="briefcase"></ico><div><b>{{ s.chat.profile.position }}</b><span>{{ t('set.position') }}</span></div></div>
          <div class="ci-row"><ico name="layers"></ico><div><b>{{ levelText(s.chat.profile.level) || roleText(s.chat.profile.role) }}</b><span>{{ t('set.level') }}</span></div></div>
          <div class="ci-row" v-if="s.chat.profile.extension"><ico name="phone"></ico><div><b class="mono">{{ s.chat.profile.extension }}</b><span>{{ t('ext') }}</span></div></div>
          <div class="ci-row" v-if="s.chat.profile.username"><ico name="at"></ico><div><b>@{{ s.chat.profile.username }}</b><span>{{ t('set.username') }}</span></div></div>
          <div class="ci-row"><span class="status" :class="'st-' + s.chat.profile.state"><span class="dot"></span>{{ s.chat.profile.state_label }}</span>
            <div><span>{{ s.chat.profile.reason }}</span></div></div>
          <div class="ci-sep"></div>
          <div class="ci-row"><ico name="chat"></ico><div><b>{{ s.chat.profile.messages_total }}</b><span>{{ t('chat.messages_total', {w: s.chat.profile.messages_week}) }}</span></div></div>
          <div class="ci-row" v-if="s.chat.profile.member_since"><ico name="calendar"></ico><div><b>{{ dayLabel(s.chat.profile.member_since) }}</b><span>{{ t('chat.member_since') }}</span></div></div>
        </div>
      </aside>
      <!-- v3.20: a group — its name, the members, add / remove (the owner), leave -->
      <aside v-if="s.chat.info && isGroup && s.chat.profile && s.chat.profile.kind === 'group'" class="chat-info group-info" :aria-label="t('chat.info')" data-group-info>
        <div class="ci-head">
          <span class="ci-title">{{ t('chat.group') }}</span>
          <button class="ch-btn" @click="s.chat.info = false" :aria-label="t('modal.cancel')"><ico name="close"></ico></button>
        </div>
        <div class="ci-hero">
          <span class="av xl grp" :class="avClass(s.chat.profile.id)"><ico name="team"></ico></span>
          <template v-if="s.chat.renaming !== null">
            <form class="gi-rename" @submit.prevent="renameGroup"><input v-model="s.chat.renaming" name="group-name" maxlength="100" data-group-rename>
              <button class="btn sm primary" type="submit">{{ t('chat.save') }}</button></form>
          </template>
          <b v-else>{{ s.chat.profile.name }}</b>
          <small>{{ t('chat.members', {n: s.chat.profile.members.length}) }}</small>
          <button v-if="s.chat.profile.role === 'owner' && s.chat.renaming === null" class="btn sm ghost" data-act="group-rename" @click="s.chat.renaming = s.chat.profile.name"><ico name="edit"></ico> {{ t('chat.rename') }}</button>
        </div>
        <div class="gi-head"><b>{{ t('chat.group_people') }}</b>
          <button v-if="s.chat.profile.role === 'owner'" class="btn sm" data-act="group-add" @click="openAddPeople"><ico name="plus"></ico> {{ t('chat.add_people') }}</button></div>
        <div v-if="s.chat.addPeople" class="gi-add">
          <input v-model="s.chat.addPeople.q" @input="searchPeople(s.chat.addPeople)" name="group-add-search" :placeholder="t('chat.search_people')" autocomplete="off">
          <div class="pick-list">
            <button v-for="c in s.chat.addPeople.results" :key="c.id" type="button" class="pick-row" :class="{on: s.chat.addPeople.picked.some((x) => x.id === c.id)}" :data-pick="c.id" @click="togglePick(s.chat.addPeople, c)">
              <span class="av sm" :class="avClass(c.id)"><img v-if="c.avatar_url" :src="c.avatar_url" alt=""><template v-else>{{ initials2(c.name) }}</template></span>
              <span class="pr-t"><b>{{ c.name }}</b><small>{{ c.position || levelText(c.level) || '' }}</small></span><i class="pin-box"><ico v-if="s.chat.addPeople.picked.some((x) => x.id === c.id)" name="check"></ico></i></button>
          </div>
          <div class="gi-actions"><button class="btn sm" @click="s.chat.addPeople = null">{{ t('modal.cancel') }}</button>
            <button class="btn sm primary" data-act="group-add-save" :disabled="!s.chat.addPeople.picked.length || s.chat.addPeople.busy" @click="addPeople">{{ t('chat.add') }} ({{ s.chat.addPeople.picked.length }})</button></div>
        </div>
        <div class="gi-members">
          <div v-for="u in s.chat.profile.members" :key="u.id" class="gi-member" :data-member="u.id">
            <span class="av sm" :class="avClass(u.id)"><img v-if="u.avatar_url" :src="u.avatar_url" alt=""><template v-else>{{ initials2(u.name) }}</template><i v-if="u.online" class="av-online" aria-hidden="true"></i></span>
            <span class="pr-t"><b>{{ u.name }}<template v-if="u.id === s.me.id"> ({{ t('chat.you') }})</template></b><small>{{ u.group_role === 'owner' ? t('chat.owner') : (u.position || levelText(u.level) || roleText(u.role)) }}</small></span>
            <button v-if="s.chat.profile.role === 'owner' && u.id !== s.me.id" class="ch-btn gi-x" @click="removeMember(u)" :title="t('chat.remove')" :aria-label="t('chat.remove')"><ico name="close"></ico></button>
          </div>
        </div>
        <div class="gi-leave">
          <template v-if="s.chat.leaveAsk">
            <p>{{ t('chat.leave_q', {name: s.chat.profile.name}) }}</p>
            <div class="gi-actions"><button class="btn sm" @click="s.chat.leaveAsk = false">{{ t('modal.cancel') }}</button>
              <button class="btn sm danger" data-act="group-leave-yes" @click="leaveGroup">{{ t('chat.leave') }}</button></div>
          </template>
          <button v-else class="btn sm ghost danger" data-act="group-leave" @click="s.chat.leaveAsk = true"><ico name="out"></ico> {{ t('chat.leave') }}</button>
        </div>
      </aside>

      <!-- v3.20: create a group -->
      <div v-if="s.chat.newGroup" class="chat-dialog-wrap" @click.self="s.chat.newGroup = null">
        <form class="chat-dialog new-group-dialog" role="dialog" aria-modal="true" @submit.prevent="createGroup" data-new-group>
          <b>{{ t('chat.new_group') }}</b>
          <label class="ng-l">{{ t('chat.group_name') }}<input v-model="s.chat.newGroup.name" class="ng-name" name="group-name" maxlength="100" autocomplete="off"></label>
          <label class="ng-l"><span>{{ t('chat.group_people') }}<small v-if="s.chat.newGroup.picked.length" class="ng-n">{{ t('chat.picked', {n: s.chat.newGroup.picked.length}) }}</small></span>
            <input v-model="s.chat.newGroup.q" @input="searchPeople(s.chat.newGroup)" name="group-people-search" :placeholder="t('chat.search_people')" autocomplete="off"></label>
          <div v-if="s.chat.newGroup.picked.length" class="ng-chips">
            <button v-for="c in s.chat.newGroup.picked" :key="c.id" type="button" class="ng-chip" @click="togglePick(s.chat.newGroup, c)">{{ c.name }} <ico name="close"></ico></button>
          </div>
          <div class="pick-list">
            <button v-for="c in s.chat.newGroup.results" :key="c.id" type="button" class="pick-row" :class="{on: s.chat.newGroup.picked.some((x) => x.id === c.id)}" :data-pick="c.id" @click="togglePick(s.chat.newGroup, c)">
              <span class="av sm" :class="avClass(c.id)"><img v-if="c.avatar_url" :src="c.avatar_url" alt=""><template v-else>{{ initials2(c.name) }}</template></span>
              <span class="pr-t"><b>{{ c.name }}</b><small>{{ c.position || levelText(c.level) || '' }}</small></span><i class="pin-box"><ico v-if="s.chat.newGroup.picked.some((x) => x.id === c.id)" name="check"></ico></i></button>
            <div v-if="!s.chat.newGroup.results.length" class="chat-none">{{ t('chat.nobody') }}</div>
          </div>
          <p v-if="s.chat.newGroup.error" class="ng-err">{{ s.chat.newGroup.error }}</p>
          <div class="cd-actions"><button type="button" class="btn" @click="s.chat.newGroup = null">{{ t('modal.cancel') }}</button>
            <button type="submit" class="btn primary" data-act="group-create" :disabled="s.chat.newGroup.busy">{{ t('chat.group_create') }}</button></div>
        </form>
      </div>
    </div>

    <!-- ===================== MANAGER OVERVIEW (v2.5) ===================== -->
    <div v-if="s.tab==='overview' && isSup" class="ov">
      <div class="ov-bar">
        <div class="seg ov-period">
          <button v-for="p in ['today','yesterday','7d','30d']" :key="p" :data-period="p" :class="{on: s.ov.period===p}" @click="setPeriod(p)">{{ t('ov.' + p) }}</button>
        </div>
        <div class="level-filter ov-levels">
          <button :class="{on: !s.sup.level}" @click="s.sup.level = ''">{{ t('team.all') }}</button>
          <button v-for="l in ['level1','level2','level3','manager']" :key="l" :data-level="l" :class="{on: s.sup.level === l}" @click="s.sup.level = l">{{ levelText(l) }}</button>
        </div>
        <span class="spacer"></span>
        <span class="ov-updated" v-if="s.ov.updated">{{ t('ov.updated') }} {{ fmt(s.ov.updated) }}</span>
        <button class="btn sm" @click="refreshOverview()" :disabled="s.ov.loading">{{ s.ov.loading ? t('ov.loading') : t('ov.refresh') }}</button>
      </div>

      <div v-if="!s.ov.data" class="skeleton-grid" aria-busy="true" :aria-label="t('ov.loading')">
        <div v-for="n in 5" :key="n" class="skeleton sk-tile"></div><div class="skeleton sk-wide"></div><div class="skeleton sk-side"></div>
      </div>
      <template v-else>
      <!-- tiles -->
      <div class="ov-tiles">
        <section class="panel tile tile-calls">
          <h2>{{ t('ov.offered') }}</h2>
          <div class="big" v-flash>{{ s.ov.data.calls.offered }}</div>
          <div class="tile-sub"><b class="ok-ink">{{ s.ov.data.calls.answered }}</b> {{ t('ov.answered') }}</div>
          <div class="tile-alert" :class="{on: s.ov.data.calls.missed > 0}">
            <div class="mid">{{ s.ov.data.calls.missed }}</div>
            <div><b>{{ t('ov.missed_calls') }}</b>
              <div class="tile-sub">{{ t('ov.missed_sub', {a: s.ov.data.calls.abandoned, u: s.ov.data.calls.unanswered}) }}</div>
              <div class="tile-sub muted" v-if="s.ov.data.calls.short_abandoned">{{ t('ov.short', {n: s.ov.data.calls.short_abandoned, s: s.ov.data.settings.short_abandon_seconds}) }}</div></div>
          </div>
        </section>
        <section class="panel tile tile-sl" :class="slClass">
          <h2>{{ t('ov.sl') }}</h2>
          <svg viewBox="0 0 180 104" class="gauge" role="img" :aria-label="t('ov.sl') + ' ' + pct(s.ov.data.calls.service_level)">
            <path :d="gauge.track" class="g-track"></path>
            <path v-if="!gauge.empty" :d="gauge.value" class="g-value" pathLength="1"></path>
            <line :x1="gauge.target.x1" :y1="gauge.target.y1" :x2="gauge.target.x2" :y2="gauge.target.y2" class="g-target"></line>
            <text x="20" y="103" class="g-axis">0</text><text x="160" y="103" class="g-axis" text-anchor="end">100</text>
          </svg>
          <div class="gauge-val">{{ pct(s.ov.data.calls.service_level) }}</div>
          <div class="tile-sub center">{{ t('ov.sl_sub', {s: s.ov.data.settings.sla_answer_seconds, p: pct(s.ov.data.settings.sla_target)}) }}</div>
        </section>
        <section class="panel tile">
          <h2>{{ t('ov.answer_rate') }}</h2>
          <div class="big">{{ pct(s.ov.data.calls.answer_rate) }}</div>
          <div class="tile-sub">{{ t('ov.abandon_rate', {p: pct(s.ov.data.calls.abandon_rate)}) }}</div>
          <h2 class="h-inner">{{ t('ov.asa') }}</h2>
          <div class="mid">{{ secs(s.ov.data.calls.asa_sec) }}</div>
          <div class="tile-sub">{{ t('ov.longest', {v: secs(s.ov.data.calls.longest_wait_sec)}) }}</div>
        </section>
        <section class="panel tile">
          <h2>{{ t('ov.aht') }}</h2>
          <div class="big">{{ secs(s.ov.data.calls.aht_talk_sec) }}</div>
          <div class="tile-sub">{{ t('ov.talk_total', {v: dur(s.ov.data.calls.talk_sec)}) }}</div>
          <h2 class="h-inner">{{ t('ov.outbound') }}</h2>
          <div class="mid">{{ s.ov.data.calls.outbound }}</div>
          <div class="tile-sub">{{ t('ov.outbound_sub', {c: s.ov.data.calls.outbound_connected}) }}</div>
        </section>
        <section class="panel tile tile-live" :class="{alert: s.ov.data.live.waiting > 0}">
          <h2>{{ t('ov.live') }} <span class="live-dot" aria-hidden="true"></span></h2>
          <div class="big" v-flash>{{ s.ov.data.live.waiting }}</div>
          <div class="tile-sub">{{ t('ov.waiting') }}<span v-if="s.ov.data.live.waiting"> · {{ t('ov.longest_now', {v: secs(liveWait)}) }}</span></div>
          <div class="live-grid">
            <div><b>{{ s.ov.data.live.talking }}</b><span>{{ t('ov.talking') }}</span></div>
            <div><b class="st-c st-ready">{{ s.ov.data.live.agents.ready }}</b><span>{{ t('ov.ready') }}</span></div>
            <div><b class="st-c st-busy_task">{{ s.ov.data.live.agents.busy_task + s.ov.data.live.agents.wrap_up }}</b><span>{{ t('ov.busy') }}</span></div>
            <div><b class="st-c st-break">{{ s.ov.data.live.agents.break }}</b><span>{{ t('ov.break') }}</span></div>
          </div>
        </section>
      </div>

      <!-- charts + leaders -->
      <div class="ov-row">
        <section class="panel ov-chart">
          <h2>{{ s.ov.data.bucket==='hour' ? t('ov.calls_chart') : t('ov.calls_chart_day') }}
            <span class="h-actions legend"><span><i class="sw sw-ans"></i>{{ t('ov.legend.answered') }}</span><span><i class="sw sw-mis"></i>{{ t('ov.legend.missed') }}</span></span></h2>
          <div class="body chart-box" @mouseleave="s.ov.hover = -1">
            <svg :key="'c' + s.ov.period" :viewBox="'0 0 ' + callChart.w + ' ' + callChart.h" class="chart" role="img" :aria-label="t('ov.calls_chart')">
              <g v-for="g in callChart.grid" :key="g.y"><line :x1="callChart.l" :x2="callChart.w - callChart.r" :y1="g.y" :y2="g.y" class="grid-line"></line>
                <text :x="callChart.l - 6" :y="g.y + 4" text-anchor="end" class="axis-t">{{ g.v }}</text></g>
              <g v-for="b in callChart.bars" :key="b.i" :class="{dim: b.future, hov: s.ov.hover === b.i}" :style="{'--i': b.i}">
                <rect v-if="b.ans.h > 0" :x="b.x" :y="b.ans.y" :width="b.w" :height="b.ans.h" rx="3" class="bar-ans"></rect>
                <rect v-if="b.mis.h > 0" :x="b.x" :y="b.mis.y" :width="b.w" :height="b.mis.h" rx="3" class="bar-mis"></rect>
                <text v-if="b.showLabel" :x="b.cx" :y="callChart.base + 17" text-anchor="middle" class="axis-t">{{ b.label }}</text>
                <rect :x="b.hit.x" :y="callChart.t" :width="b.hit.w" :height="callChart.base - callChart.t" class="hit" @mouseenter="s.ov.hover = b.i"></rect>
              </g>
              <line :x1="callChart.l" :x2="callChart.w - callChart.r" :y1="callChart.base" :y2="callChart.base" class="base-line"></line>
            </svg>
            <div v-if="ovHover" class="chart-tip" :style="{left: (ovHover.cx / callChart.w * 100) + '%'}">
              <b>{{ ovHover.label }}</b>
              <div><i class="sw sw-ans"></i>{{ t('ov.legend.answered') }}: {{ ovHover.d.answered }}</div>
              <div><i class="sw sw-mis"></i>{{ t('ov.legend.missed') }}: {{ ovHover.d.missed }}</div>
              <div class="muted">{{ t('ov.sl') }}: {{ pct(ovHover.d.service_level) }}</div>
            </div>
          </div>
          <div class="chart-foot" v-if="s.ov.data.peak">{{ t('ov.peak', {l: s.ov.data.peak.label, n: s.ov.data.peak.offered}) }}</div>
        </section>
        <section class="panel ov-leaders">
          <h2>{{ t('ov.top_calls') }}</h2>
          <div class="body">
            <div v-if="!s.ov.data.leaders.answered.length" class="empty">{{ t('ov.none_yet') }}</div>
            <div v-for="(x, i) in s.ov.data.leaders.answered" :key="x.agent_id" class="lead"><span class="rank">{{ i + 1 }}</span><span class="nm">{{ x.name }}</span><b>{{ x.value }}</b></div>
          </div>
          <h2>{{ t('ov.top_tickets') }}</h2>
          <div class="body">
            <div v-if="!s.ov.data.leaders.tickets.length" class="empty">{{ t('ov.none_yet') }}</div>
            <div v-for="(x, i) in s.ov.data.leaders.tickets" :key="x.agent_id" class="lead"><span class="rank">{{ i + 1 }}</span><span class="nm">{{ x.name }}</span><b>{{ x.value }}</b></div>
          </div>
        </section>
      </div>

      <div class="ov-row">
        <section class="panel ov-chart">
          <h2>{{ t('ov.load_chart') }}
            <span class="h-actions legend"><span><i class="ln ln-ag"></i>{{ t('ov.load_agents') }}</span><span><i class="ln ln-erl"></i>{{ t('ov.load_erl') }}</span></span></h2>
          <div class="body">
            <svg :key="'l' + s.ov.period" :viewBox="'0 0 ' + loadChart.w + ' ' + loadChart.h" class="chart" role="img" :aria-label="t('ov.load_chart')">
              <g v-for="g in loadChart.grid" :key="g.y"><line :x1="loadChart.l" :x2="loadChart.w - loadChart.r" :y1="g.y" :y2="g.y" class="grid-line"></line>
                <text :x="loadChart.l - 6" :y="g.y + 4" text-anchor="end" class="axis-t">{{ g.v }}</text></g>
              <path :d="loadChart.agents" class="line-ag" pathLength="1"></path>
              <path :d="loadChart.erl" class="line-erl"></path>
              <g v-for="(x, i) in loadChart.labels" :key="i"><text v-if="x.show" :x="x.x" :y="loadChart.base + 17" text-anchor="middle" class="axis-t">{{ x.label }}</text></g>
            </svg>
            <div class="hint">{{ t('ov.load_hint') }}</div>
          </div>
        </section>
        <section class="panel tile">
          <h2>{{ t('ov.team') }}</h2>
          <div class="big">{{ pct(s.ov.data.team.occupancy) }}</div>
          <div class="tile-sub">{{ t('ov.occupancy') }} · {{ t('ov.worked', {n: s.ov.data.team.agents_worked}) }}</div>
          <div class="tile-sub">{{ t('ov.logged', {v: dur(s.ov.data.team.logged_in_sec)}) }}</div>
          <h2 class="h-inner">{{ t('ov.tickets') }}</h2>
          <div class="kv"><span>{{ t('ov.t_started') }}</span><b>{{ s.ov.data.tickets.started }}</b></div>
          <div class="kv"><span>{{ t('ov.t_done') }}</span><b>{{ s.ov.data.tickets.completed }}</b></div>
          <div class="kv"><span>{{ t('ov.t_avg') }}</span><b>{{ s.ov.data.tickets.avg_work_sec === null ? '—' : dur(s.ov.data.tickets.avg_work_sec) }}</b></div>
          <div class="chips"><span v-for="(n, ch) in s.ov.data.tickets.by_channel" :key="ch" class="tag">{{ srcText(ch) || ch }} {{ n }}</span></div>
          <div class="tile-sub">{{ t('ov.t_active', {b: s.ov.data.tickets.active_blocking, g: s.ov.data.tickets.active_background}) }}</div>
        </section>
      </div>

        <section class="panel ov-unret" :class="{alert: s.ov.data.unreturned_count > 0}">
          <h2><span>{{ t('ov.unreturned') }} <span class="count">{{ s.ov.data.unreturned_count }}</span></span></h2>
          <div class="body unret-grid">
            <div v-if="!s.ov.data.unreturned.length" class="empty">{{ t('ov.unreturned_none') }}</div>
            <div v-for="u in s.ov.data.unreturned" :key="u.number" class="item unret">
              <div class="title mono">{{ u.number }} <span class="empty" v-if="u.name">{{ u.name }}</span></div>
              <div class="meta"><span>{{ fmt(u.last_missed_at, s.ov.period !== 'today') }}</span><span>{{ t('ov.attempts', {n: u.attempts}) }}</span>
                <span class="warn-ink">{{ t('ov.ago', {n: u.waiting_min}) }}</span></div>
            </div>
          </div>
        </section>

      <!-- operators -->
      <section class="panel ov-agents">
        <h2><span>{{ t('ov.agents') }} <span class="count">{{ ovAgents.length }}</span></span>
          <span class="h-actions"><label class="inline">{{ t('ov.sort') }}
            <select v-model="s.ov.sort" name="ov-sort">
              <option value="engagement">{{ t('ov.col.score') }}</option><option value="calls_answered">{{ t('ov.col.calls') }}</option>
              <option value="tickets_completed">{{ t('ov.col.tickets') }}</option><option value="occupancy">{{ t('ov.col.occ') }}</option>
              <option value="rona">{{ t('ov.col.rona') }}</option><option value="break_sec">{{ t('ov.col.break') }}</option>
              <option value="logged_in_sec">{{ t('ov.col.logged') }}</option></select></label></span></h2>
        <div class="table-wrap"><table class="ov-table">
          <thead><tr><th>{{ t('ov.col.operator') }}</th><th>{{ t('ov.col.now') }}</th><th>{{ t('ov.col.logged') }}</th><th>{{ t('ov.col.ready') }}</th>
            <th>{{ t('ov.col.break') }}</th><th>{{ t('ov.col.occ') }}</th><th>{{ t('ov.col.calls') }}</th><th>{{ t('ov.col.rona') }}</th>
            <th>{{ t('ov.col.talk') }}</th><th>{{ t('ov.col.tickets') }}</th><th>{{ t('ov.col.score') }}</th></tr></thead>
          <tbody>
            <tr v-for="a in ovAgents" :key="a.agent_id" :data-agent="a.agent_id">
              <td><b>{{ a.name }}</b><div class="lvl">{{ levelText(a.level) }}</div>
                <div class="flags"><span v-for="f in a.flags" :key="f" class="flag" :class="'f-' + f" :title="t('flag.' + f + '_d')">{{ t('flag.' + f) }}</span></div></td>
              <td><span class="status" :class="'st-' + a.state_now"><span class="dot"></span>{{ stateText(a.state_now) }}</span></td>
              <td class="num">{{ dur(a.logged_in_sec) }}</td>
              <td class="num">{{ pct(a.ready_share) }}</td>
              <td class="num">{{ dur(a.break_sec) }}<div class="sub">{{ pct(a.break_share) }}</div></td>
              <td><div class="meter" :title="pct(a.occupancy)"><i :style="{width: Math.round((a.occupancy || 0) * 100) + '%'}"></i></div><span class="num">{{ pct(a.occupancy) }}</span></td>
              <td class="num">{{ t('ov.calls_fmt', {a: a.calls_answered, r: a.calls_rang}) }}<div class="sub" v-if="a.outbound">↗ {{ a.outbound }}</div></td>
              <td class="num" :class="{bad: a.rona > 0}">{{ a.rona }}</td>
              <td class="num">{{ dur(a.talk_sec) }}<div class="sub">{{ secs(a.aht_talk_sec) }}</div></td>
              <td class="num">{{ a.tickets_completed }}<div class="sub" v-if="a.avg_ticket_work_sec">{{ dur(a.avg_ticket_work_sec) }}</div></td>
              <td><span class="score" :class="scoreClass(a.engagement)">{{ a.engagement === null ? '—' : a.engagement }}</span></td>
            </tr>
          </tbody>
        </table></div>
      </section>

      <details class="panel ov-how">
        <summary>{{ t('ov.how') }}</summary>
        <ul>
          <li>{{ t('ov.how.offered') }}</li>
          <li>{{ t('ov.how.short', {s: s.ov.data.settings.short_abandon_seconds}) }}</li>
          <li>{{ t('ov.how.rates', {sl: s.ov.data.settings.sla_answer_seconds}) }}</li>
          <li>{{ t('ov.how.asa') }}</li><li>{{ t('ov.how.rona') }}</li><li>{{ t('ov.how.time') }}</li>
          <li>{{ t('ov.how.score') }}</li><li>{{ t('ov.how.unreturned') }}</li><li>{{ t('ov.how.load') }}</li>
        </ul>
      </details>
      </template>
    </div>

    <!-- ===================== SUPERVISOR ===================== -->
    <template v-if="s.tab==='sup' && isSup">
      <div v-if="!s.sup.ami" class="banner error">{{ t('sup.ami_down') }}</div>
      <div class="level-filter">
        <button :class="{on: !s.sup.level}" @click="s.sup.level = ''">{{ t('team.all') }} <span class="count">{{ s.sup.agents.length }}</span></button>
        <button v-for="l in teamLevels" :key="l.id" :data-level="l.id" :class="{on: s.sup.level === l.id}" @click="s.sup.level = l.id">
          {{ levelText(l.id) }} <span class="count">{{ l.n }}</span></button>
      </div>
      <div class="kpis sup-kpis">
        <div class="panel kpi k-online"><div class="k">{{ t('sup.k.online') }}</div><div class="v">{{ supCounts.online }}</div></div>
        <div class="panel kpi k-ready"><div class="k">{{ t('sup.k.ready') }}</div><div class="v" v-flash>{{ supCounts.ready }}</div></div>
        <div class="panel kpi k-busy"><div class="k">{{ t('sup.k.busy') }}</div><div class="v" v-flash>{{ supCounts.busy }}</div></div>
        <div class="panel kpi k-break"><div class="k">{{ t('sup.k.break') }}</div><div class="v">{{ supCounts.brk }}</div></div>
        <div class="panel kpi k-off"><div class="k">{{ t('sup.k.offline') }}</div><div class="v">{{ supCounts.offline }}</div></div>
        <div class="panel kpi k-err"><div class="k">{{ t('sup.k.sync') }}</div><div class="v" :class="{warn: supCounts.sync}">{{ supCounts.sync }}</div></div>
      </div>
      <div v-if="s.sup.spy" class="spy-bar" data-spy-bar role="status">
        <span class="spy-live"><i></i>{{ t('spy.active', {mode: t('spy.mode.' + s.sup.spy.mode), name: s.sup.spy.agent_name}) }}</span>
        <span class="mono spy-num">{{ s.sup.spy.number }}</span>
        <span class="grow"></span>
        <span class="seg spy-seg"><button v-for="m in SPY_MODES" :key="m[0]" :class="{on: s.sup.spy.mode===m[0]}" :data-spy-mode="m[0]" @click="setSpyMode(m[0])" :title="t('spy.' + m[0] + '_t')"><ico :name="m[1]"></ico> {{ t('spy.' + m[0]) }}</button></span>
        <button class="btn sm danger" data-spy-stop @click="stopSpy">{{ t('spy.stop') }}</button>
        <div class="spy-keys empty">{{ t('spy.keys') }}</div>
      </div>
      <section class="panel tm-board" style="margin-bottom:16px" data-team="board">
        <h2>{{ t('tm.title') }} <span class="h-actions">
          <button class="btn sm" @click="openWall" :title="t('tm.wall_t')" data-act="wallboard"><ico name="tv"></ico> {{ t('tm.wall') }}</button>
          <button class="btn sm primary assign-btn" @click="openAssign">{{ t('sup.assign') }}</button>
          <button class="btn sm" @click="refreshSup">{{ t('sup.refresh') }}</button></span></h2>
        <div class="tm-tools">
          <span class="seg tm-seg"><button v-for="g in TEAM_GROUPS" :key="g" :class="{on: s.sup.f===g}" :data-tm-filter="g" @click="s.sup.f = g">{{ t('tm.f.' + g) }} <span class="count">{{ teamGroupCount(g) }}</span></button></span>
          <span class="grow"></span>
          <label class="tm-sort">{{ t('tm.sort') }} <select v-model="s.sup.sort" data-tm-sort>
            <option value="level">{{ t('tm.sort.level') }}</option><option value="name">{{ t('tm.sort.name') }}</option><option value="long">{{ t('tm.sort.long') }}</option></select></label>
        </div>
        <div class="table-wrap"><table class="tm-table">
          <thead><tr><th>{{ t('sup.col.operator') }}</th><th>{{ t('tm.col.status') }}</th><th>{{ t('tm.col.call') }}</th><th>{{ t('tm.col.work') }}</th><th>{{ t('sup.col.phone') }}</th><th></th></tr></thead>
          <tbody>
            <tr v-if="!teamBoard.length"><td colspan="6" class="empty">{{ t('tm.none') }}</td></tr>
            <tr v-for="a in teamBoard" :key="a.agent_id" :class="['g-' + a.group, a.phase ? 'ph-' + a.phase : '']" :data-agent="a.agent_id" :data-group="a.group">
              <td><div class="u-cell"><user-avatar :name="a.name" :url="a.avatar_url"></user-avatar><div><a href="#" class="tm-name" @click.prevent="s.sup.day = a.agent_id" :title="t('tm.day')"><b>{{ a.name }}</b></a><div class="lvl">{{ levelText(a.level) }}</div><div class="empty">{{ a.position || roleText(a.role) }} · {{ t('ext') }} {{ a.extension || '—' }}</div></div></div></td>
              <td><span class="status" :class="'st-' + a.display_state" style="display:inline-flex"><span class="dot"></span>{{ stateText(a.display_state) }}</span>
                <div v-if="a.state_since" class="tm-since mono" :data-since="a.agent_id">{{ t('tm.for', {t: tmSpan(a.state_since)}) }}</div>
                <div class="empty" style="margin-top:4px">{{ a.reason }}<span v-if="a.idle_since"> · {{ t('idle.since_short') }} {{ fmt(a.idle_since) }}</span><span v-if="a.override_ready"> · override: {{ a.override_reason }}</span></div>
                <span v-if="a.idle_since" class="tag idle-tag">{{ t('idle.tag') }}</span></td>
              <td class="spy-cell" :data-call="a.call ? a.call.id : null" :data-phase="a.phase || ''">
                <div v-if="a.phase" class="tm-phase" :class="'ph-' + a.phase"><ico :name="TM_ICON[a.phase]"></ico><b>{{ t('tm.ph.' + a.phase) }}</b>
                  <span class="mono tm-timer" v-if="a.phase_since">{{ tmClock(tmElapsed(a.phase_since)) }}</span></div>
                <div v-if="a.live_call" class="tm-callinfo"><span class="tmf-dir" :class="a.live_call.direction"><ico :name="a.live_call.direction==='in' ? 'arrin' : 'arrout'"></ico></span>
                  <b class="mono" data-number>{{ a.live_call.number || '—' }}</b> <span class="empty">{{ a.live_call.name }}</span>
                  <small class="empty" v-if="a.live_call.queue"> · {{ t('tm.queue', {q: a.live_call.queue}) }}</small></div>
                <template v-if="a.call">
                  <div v-if="s.sup.spyEnabled && a.agent_id !== s.me.id" class="spy-btns">
                    <button v-for="m in SPY_MODES" :key="m[0]" class="btn sm spy-b" :class="{on: s.sup.spy && s.sup.spy.agent_id===a.agent_id && s.sup.spy.mode===m[0]}"
                            :data-spy="m[0]" :disabled="s.sup.spyBusy || !s.sup.myExt" @click="startSpy(a, m[0])" :title="s.sup.myExt ? t('spy.' + m[0] + '_t') : t('spy.no_ext')"><ico :name="m[1]"></ico><span>{{ t('spy.' + m[0]) }}</span></button>
                    <button v-if="s.sup.spy && s.sup.spy.agent_id===a.agent_id" class="btn sm danger" @click="stopSpy">{{ t('spy.stop') }}</button>
                  </div>
                </template>
                <span v-if="!a.phase && !a.call" class="empty">—</span>
              </td>
              <td class="tm-work">
                <div v-for="w in a.blocking" :key="w.id"><span class="tag blocking">B</span> <a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a>
                  <span class="tm-wtitle">{{ w.ticket_title }}</span> <span class="mono empty tm-timer">{{ tmClock(tmElapsed(w.started_at)) }}</span>
                  <a href="#" class="empty" @click.prevent="cancelSession(w)">{{ t('sup.cancel') }}</a></div>
                <div v-for="w in a.background" :key="w.id"><span class="tag background">F</span> <a :href="zLink(w.ticket_id)" @click.prevent="openTicket(w.ticket_id)">#{{ w.ticket_number }}</a> <span class="tm-wtitle empty">{{ w.ticket_title }}</span></div>
                <span v-if="!a.blocking.length && !a.background.length" class="empty">—</span>
              </td>
              <td>{{ a.phone_label }}<div v-if="a.sync_status!=='ok'" style="color:var(--danger)">{{ a.sync_status }}: {{ a.sync_error }}</div>
                <div class="empty" v-if="a.last_asterisk_sync_at">{{ t('sup.synced') }} {{ fmt(a.last_asterisk_sync_at) }}</div></td>
              <td class="tm-acts">
                <button v-if="a.work" class="btn sm tm-ib" @click="openTicket(a.work.ticket_id)" :title="t('tm.open_ticket')" :aria-label="t('tm.open_ticket')" data-act="open-ticket"><ico name="ticket"></ico></button>
                <button v-if="a.agent_id !== s.me.id" class="btn sm tm-ib" @click="chatWith(a.agent_id)" :title="t('tm.chat')" :aria-label="t('tm.chat')" data-act="chat"><ico name="chat"></ico></button>
                <button class="btn sm tm-ib" @click="s.sup.day = a.agent_id" :title="t('tm.day')" :aria-label="t('tm.day')" data-act="day"><ico name="calendar"></ico></button>
                <button class="btn sm" @click="reconcile(a)">{{ t('sup.reconcile') }}</button> <button class="btn sm warn" @click="openOverride(a)">{{ t('sup.override') }}</button></td>
            </tr>
          </tbody>
        </table></div>
      </section>

      <div class="grid tm-grid">
        <team-queues :data="s.sup.live" :t="t"></team-queues>
        <team-feed :items="s.sup.live ? s.sup.live.feed : []" :t="t" :fmt="fmt" @open-ticket="openTicket" @open-day="(id) => { s.sup.day = id; }"></team-feed>
      </div>
      <agent-day v-if="s.sup.day" :agent-id="s.sup.day" :api="api" :t="t" :fmt="fmt" :tz="s.config.timezone" :toast="toast" :live="s.sup.dayLive"
                 @close="s.sup.day = null" @open-ticket="(id) => { s.sup.day = null; openTicket(id); }" @chat="chatWith"></agent-day>

      <div class="grid sup-bottom" style="grid-template-columns: minmax(0,1fr) minmax(0,1fr)">
        <section class="panel sup-report" v-if="s.sup.report">
          <h2>{{ t('sup.report') }}</h2>
          <div class="table-wrap"><table>
            <thead><tr><th>{{ t('sup.col.operator') }}</th><th>{{ t('sup.col.completed') }}</th><th>{{ t('sup.col.blocking') }}</th><th>{{ t('sup.col.background') }}</th><th>{{ t('sup.col.paused') }}</th><th>{{ t('sup.col.errors') }}</th></tr></thead>
            <tbody><tr v-for="r in teamReport" :key="r.agent_id">
              <td>{{ r.name }}</td><td>{{ r.sessions_completed }}</td><td>{{ dur(r.blocking_work_sec) }}</td>
              <td>{{ dur(r.background_work_sec) }}</td><td>{{ dur(r.queue_paused_sec) }}</td><td>{{ r.sync_errors }}</td>
            </tr></tbody>
          </table></div>
        </section>
        <section class="panel sup-audit">
          <h2>{{ t('sup.audit') }}
            <select v-model="s.sup.auditAgent" @change="refreshSup" style="width:auto;padding:2px 6px;text-transform:none">
              <option value="">{{ t('sup.all') }}</option><option v-for="a in s.sup.agents" :key="a.agent_id" :value="a.agent_id">{{ a.name }}</option>
            </select></h2>
          <div class="body sup-audit-body">
            <div v-for="e in s.sup.audit" :key="e.id" class="item">
              <div><b :style="e.level==='error' ? 'color:var(--danger)' : e.level==='warning' ? 'color:var(--busy)' : ''">{{ e.action }}</b>
                <span class="empty"> · {{ fmt(e.ts, true) }} · {{ e.actor_type }}<span v-if="e.agent_id"> · {{ t('sup.operator') }} {{ e.agent_id }}</span><span v-if="e.ticket_id"> · {{ t('sup.ticket') }} {{ e.ticket_id }}</span></span></div>
              <div class="meta">{{ Object.entries(e.details || {}).map(([k,v]) => k + ': ' + (typeof v === 'object' ? JSON.stringify(v) : v)).join(' · ') }}</div>
            </div>
          </div>
        </section>
      </div>
    </template>
    <routing-page v-if="s.tab==='callrouting' && isSup" :api="api" :t="t" :toast="toast" :fmt="fmt" :live="s.mgLive"></routing-page>
    <team-wall v-if="s.tab==='wallboard' && isSup" :api="api" :t="t" :fmt="fmt" :tz="s.config.timezone" :live="s.wallLive" :state-text="stateText" @exit="exitWall"></team-wall>
    </div>
  </main>
  </div>
</div>

  <!-- ===================== INACTIVITY (v2.8) ===================== -->
  <transition name="idle">
    <div v-if="isFrozen" class="idle-overlay" role="dialog" aria-modal="true" aria-labelledby="idle-title">
      <div class="idle-card">
        <div class="idle-ico" aria-hidden="true"><ico name="moon"></ico></div>
        <h2 id="idle-title">{{ t('idle.title') }}</h2>
        <p>{{ t('idle.text', {min: s.config.idle_timeout_min || 60}) }}</p>
        <div class="idle-since">{{ t('idle.since') }} <b>{{ idleSinceText }}</b></div>
        <div class="idle-actions">
          <button class="btn primary idle-back" @click="resumeIdle">{{ t('idle.back') }}</button>
          <button class="btn" @click="logout">{{ t('btn.logout') }}</button>
        </div>
      </div>
    </div>
  </transition>
  <transition name="toast">
    <div v-if="s.idleWarn && !isFrozen" class="idle-warn" role="status">
      <ico name="moon"></ico><span>{{ t('idle.warn', {t: Math.floor(s.idleWarn / 60) + ':' + String(s.idleWarn % 60).padStart(2, '0')}) }}</span>
    </div>
  </transition>

  <!-- ===================== MODALS ===================== -->
  <div v-if="s.modal" class="overlay" @click.self="!s.me.must_change_password && (s.modal = null)">
    <div class="panel modal" v-if="s.modal==='password'">
      <h3>{{ t('pw.title') }}</h3>
      <div class="banner" v-if="s.me.must_change_password">{{ t('pw.forced') }}</div>
      <form @submit.prevent="submitPassword">
        <label>{{ t('pw.current') }}</label><input type="password" v-model="s.pw.current_password" autocomplete="current-password" required>
        <label>{{ t('pw.new') }}</label><input type="password" v-model="s.pw.new_password" autocomplete="new-password" minlength="8" required>
        <label>{{ t('pw.repeat') }}</label><input type="password" v-model="s.pw.repeat" autocomplete="new-password" minlength="8" required>
        <p v-if="s.pw.error" style="color:var(--danger)">{{ s.pw.error }}</p>
        <div class="footer"><button type="button" class="btn" v-if="!s.me.must_change_password" @click="s.modal=null">{{ t('modal.cancel') }}</button>
          <button class="btn primary">{{ t('modal.apply') }}</button></div>
      </form>
    </div>
    <div class="panel modal" v-if="s.modal==='complete'">
      <h3>{{ t('modal.complete') }}</h3><div class="empty">{{ s.form.title }}</div>
      <label>{{ t('modal.zammad_state') }}</label>
      <select v-model="s.form.ticket_state"><option v-for="st in s.config.complete_states" :key="st" :value="st">{{ st }}</option></select>
      <label>{{ t('modal.note') }}</label><textarea v-model="s.form.note"></textarea>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button><button class="btn go" :disabled="s.busy" @click="submitComplete">{{ t('btn.complete') }}</button></div>
    </div>

    <div class="panel modal" v-if="s.modal==='customer'">
      <h3>{{ t('modal.new_customer') }}</h3>
      <div class="row"><div><label>{{ t('modal.firstname') }}</label><input v-model="s.form.firstname"></div><div><label>{{ t('modal.lastname') }}</label><input v-model="s.form.lastname"></div></div>
      <label>{{ t('modal.phone') }}</label><input v-model="s.form.phone">
      <label>{{ t('modal.email') }}</label><input v-model="s.form.email" type="email">
      <label>{{ t('modal.notes') }}</label><textarea v-model="s.form.note"></textarea>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button><button class="btn primary" :disabled="s.busy" @click="submitCustomer">{{ t('modal.create') }}</button></div>
    </div>

    <div class="panel modal" v-if="s.modal==='ticket'">
      <h3>{{ t('modal.new_ticket') }}</h3>
      <div class="empty" v-if="s.form.call_id">{{ t('modal.call_note') }}</div>
      <label>{{ t('modal.customer') }}</label>
      <select v-model="s.form.customer_id">
        <option value="">{{ t('modal.choose') }}</option>
        <option v-for="c in s.customers" :key="c.id" :value="c.id">{{ c.name }} {{ c.phone }}</option>
        <option v-if="s.customerCard && !s.customers.find(c => c.id === s.customerCard.customer.id)" :value="s.customerCard.customer.id">{{ s.customerCard.customer.firstname }} {{ s.customerCard.customer.lastname }}</option>
      </select>
      <div class="row">
        <div><label>{{ t('modal.type') }}</label><select v-model="s.form.ticket_type"><option value="">—</option><option v-for="tt in s.config.ticket_types" :key="tt.name" :value="tt.name">{{ tt.name }}</option></select></div>
        <div><label>{{ t('modal.priority') }}</label><select v-model="s.form.priority"><option value="1 low">{{ t('prio.low') }}</option><option value="2 normal">{{ t('prio.normal') }}</option><option value="3 high">{{ t('prio.high') }}</option></select></div>
      </div>
      <template v-if="currentType">
        <div v-for="f in currentType.required_fields" :key="f.name">
          <label>{{ f.label || f.name }} *</label>
          <select v-if="f.type==='select'" v-model="s.form.fields[f.name]"><option v-for="o in f.options || []" :key="o" :value="o">{{ o }}</option></select>
          <textarea v-else-if="f.type==='textarea'" v-model="s.form.fields[f.name]"></textarea>
          <input v-else v-model="s.form.fields[f.name]">
        </div>
      </template>
      <label>{{ t('modal.subject') }} *</label><input v-model="s.form.title" required>
      <label>{{ t('modal.description') }}</label><textarea v-model="s.form.body"></textarea>
      <div class="footer">
        <button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button>
        <button class="btn" :disabled="s.busy || !s.form.title" @click="submitTicket(null)">{{ t('modal.save') }}</button>
        <button class="btn" :disabled="s.busy || !s.form.title" @click="submitTicket('background')">{{ t('modal.save_bg') }}</button>
        <button class="btn primary" :disabled="s.busy || !s.form.title" @click="submitTicket('blocking')">{{ t('modal.save_start') }}</button>
      </div>
    </div>

    <div class="panel modal" v-if="s.modal==='assign'">
      <h3>{{ t('sup.assign_title') }}</h3>
      <label>{{ t('sup.ticket_number') }} *</label><input name="ticket" v-model="s.form.ticket" placeholder="31103">
      <label>{{ t('sup.assign_to') }} *</label>
      <select name="agent" v-model="s.form.agent_id"><option value="">{{ t('modal.choose') }}</option>
        <option v-for="a in s.sup.agents.filter(x => x.zammad_user_id)" :key="a.agent_id" :value="a.agent_id">{{ a.name }} — {{ stateText(a.display_state) }}</option></select>
      <label>{{ t('sup.mode') }}</label>
      <select name="mode" v-model="s.form.work_mode"><option value="">{{ t('sup.mode_none') }}</option>
        <option value="blocking">{{ t('btn.start') }} (blocking)</option><option value="background">{{ t('btn.background') }}</option></select>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button>
        <button class="btn primary" :disabled="s.busy || !s.form.ticket || !s.form.agent_id" @click="submitAssign">{{ t('modal.apply') }}</button></div>
    </div>

    <div class="panel modal" v-if="s.modal==='override'">
      <h3>{{ t('modal.override') }}: {{ s.form.agent.name }}</h3>
      <div class="empty">{{ t('modal.audit_note') }}</div>
      <label>{{ t('modal.state') }}</label>
      <select v-model="s.form.manual_state"><option value="ready">{{ t('state.ready') }}</option><option value="break">{{ t('state.break') }}</option><option value="offline">{{ t('state.offline') }}</option></select>
      <label v-if="s.form.manual_state==='ready'" style="display:flex;gap:8px;align-items:center;color:var(--ink)">
        <input type="checkbox" v-model="s.form.ignore_blocking" style="width:auto"> {{ t('modal.ignore_blocking') }}</label>
      <label>{{ t('modal.reason') }} *</label><textarea v-model="s.form.reason"></textarea>
      <div class="footer"><button class="btn" @click="s.modal=null">{{ t('modal.cancel') }}</button><button class="btn warn" :disabled="s.busy || s.form.reason.trim().length < 3" @click="submitOverride">{{ t('modal.apply') }}</button></div>
    </div>
  </div>

  <zenith-phone v-if="phoneOn" v-model:open="s.phoneOpen" :rail="railOn" :bar-to="railOn ? '#ph-rail-slot' : '#ph-bar-slot'" :api="api" :t="t" :toast="toast" :fmt="fmt" :me="s.me" :dnd="!!(s.state && s.state.dnd)"
                @state="(x) => { s.phone = x; s.clock = Date.now(); }"></zenith-phone>
  <transition-group name="toast" tag="div" class="toasts"><div v-for="x in s.toasts" :key="x.id" class="toast" :class="[x.kind, {clickable: x.onClick}]" @click="toastClick(x)">{{ x.text }}</div></transition-group>
</template>`,
};

(async () => {
  try {
    const r = await fetch("/api/ui-language");
    if (r.ok) { const j = await r.json(); LANG = j.language || "en"; VERSION = j.version || ""; }
  } catch { /* default en */ }
  document.documentElement.lang = LANG;
  const app = createApp(App);
  app.component("ico", Ico);
  app.component("brand-word", BrandWord);
  app.component("user-avatar", UserAvatar);
  app.directive("flash", flashDirective);
  if (window.AgentixAdmin) app.component("admin-panel", window.AgentixAdmin.component);
  if (window.ZenithPhone) { app.component("zenith-phone", window.ZenithPhone.PhoneWidget); app.component("phone-settings", window.ZenithPhone.PhoneSettings); }
  if (window.ZenithInbox) app.component("inbox-page", window.ZenithInbox.InboxPage);
  if (window.ZenithMail) app.component("mail-page", window.ZenithMail.MailPage);
  if (window.ZenithRouting) app.component("routing-page", window.ZenithRouting.RoutingPage);  // v3.18
  if (window.ZenithTeam) {  // v3.18 the team right now
    const z = window.ZenithTeam;
    app.component("team-queues", z.TeamQueues); app.component("team-feed", z.TeamFeed); app.component("agent-day", z.AgentDay); app.component("team-wall", z.TeamWall);
  }
  if (window.ZenithManage) { app.component("shifts-page", window.ZenithManage.ShiftsPage); app.component("recordings-page", window.ZenithManage.RecordingsPage); app.component("log-page", window.ZenithManage.LogPage); }
  if (window.AgentixTickets) { app.component("tickets-page", window.AgentixTickets.TicketsPage); app.component("contacts-page", window.AgentixTickets.ContactsPage); }
  app.mount("#app");
})();
