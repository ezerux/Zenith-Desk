"""Live mode (v2.7): every committed change reaches the browsers that show it, immediately.

Instead of remembering to publish an event in every code path, the service watches the database itself:
after each successful COMMIT it looks at which tables were written and pushes one small `changed` event
over SSE to the right audience. The browser then reloads exactly the parts of the screen that depend on
those topics (debounced by a few dozen milliseconds, so a burst of writes becomes one refresh).

Topics
    tasks          the operator's own work sessions (blocking / background)
    calls          the operator's own calls
    notifications  something for the operator's notification center
    me             the operator's own account (name, level, disabled, password reset)
    tickets        ticket lists (new / assigned / pending) — a Zammad webhook arrived or a ticket was taken
    team           anything on the manager panel / overview: states, sessions, calls, queue, audit
    users          the user list in the administration
    config         system settings or ticket types changed
    directory      customers / Zammad staff copied from Zammad (v3.3)

Nothing is published for a rolled-back transaction.
"""
from __future__ import annotations

import logging
import weakref

from sqlalchemy import event, inspect
from sqlalchemy.orm import Session

log = logging.getLogger("live")

_brokers: "weakref.WeakKeyDictionary" = weakref.WeakKeyDictionary()  # sync engine -> EventBroker


def register(sync_engine, broker) -> None:
    _brokers[sync_engine] = broker


def _only_changed(obj, names: set[str]) -> bool:
    try:
        st = inspect(obj)
        if st.pending or st.deleted:
            return False
        changed = {a.key for a in st.attrs if a.history.has_changes()}
        return bool(changed) and changed <= names
    except Exception:  # noqa: BLE001
        return False


def _collect(session: Session, objs) -> None:
    acc = session.info.setdefault("live", {"agent": {}, "team": False, "tickets": False, "users": False, "config": False,
                                          "directory": False})
    for obj in objs:
        table = getattr(obj, "__tablename__", "")
        agent_id = getattr(obj, "agent_id", None)
        if table == "agent_mapping":
            agent_id = obj.id
        mine = acc["agent"].setdefault(agent_id, set()) if agent_id else None
        if table == "work_session":
            acc["team"] = acc["tickets"] = True
            mine is not None and mine.update(("tasks", "notifications"))
        elif table == "agent_state":
            if _only_changed(obj, {"last_activity_at", "updated_at"}):
                continue  # an activity heartbeat is not news for anybody
            acc["team"] = True
        elif table == "call_record":
            acc["team"] = True
            mine is not None and mine.add("calls")
        elif table == "queue_call":
            acc["team"] = True
        elif table == "audit_log":
            acc["team"] = True
            mine is not None and mine.add("notifications")
        elif table == "agent_mapping":
            acc["users"] = acc["team"] = True
            mine is not None and mine.add("me")
        elif table == "integration_event":
            source = getattr(obj, "source", "")
            if source == "zammad":
                acc["tickets"] = acc["team"] = True
        elif table in ("system_setting", "ticket_type"):
            acc["config"] = True
        elif table == "zammad_user":
            acc["directory"] = True
        elif table == "login_attempt":  # v3.21: the administrator's users table (last sign-in, failures, lock)
            acc["users"] = True
        elif table == "pause_interval":
            acc["team"] = True


@event.listens_for(Session, "after_flush")
def _after_flush(session: Session, flush_context) -> None:  # noqa: ARG001
    try:
        _collect(session, list(session.new) + list(session.dirty) + list(session.deleted))
    except Exception:  # noqa: BLE001 — live updates must never break a transaction
        log.exception("live: collect failed")


@event.listens_for(Session, "after_commit")
def _after_commit(session: Session) -> None:
    acc = session.info.pop("live", None)
    if not acc:
        return
    try:
        bind = session.get_bind()
        broker = _brokers.get(getattr(bind, "engine", bind))
        if broker is None:
            return
        publish(broker, acc)
    except Exception:  # noqa: BLE001
        log.exception("live: publish failed")


@event.listens_for(Session, "after_rollback")
def _after_rollback(session: Session) -> None:
    session.info.pop("live", None)


def publish(broker, acc: dict) -> None:
    for agent_id, topics in acc["agent"].items():
        if topics:
            broker.publish_agent(agent_id, "changed", {"topics": sorted(topics)})
    every = [t for t in ("tickets", "config", "directory") if acc.get(t)]
    if every:
        broker.publish_all("changed", {"topics": every})
    team = [t for t in ("team", "users") if acc.get(t)]
    if team:
        broker.publish_supervisors("changed", {"topics": team})
