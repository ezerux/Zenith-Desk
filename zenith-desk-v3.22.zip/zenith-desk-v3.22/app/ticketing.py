"""v3.3: full ticket work inside Zenith Desk — Zammad stays the system of record.

Everything an operator does here is sent to Zammad at once, **in the operator's own name** (`From` header):
Zammad checks his group permissions exactly as in its own UI and its history shows who did what.

* lists: mine / unassigned / all open / closed, text search, filters (state, priority, group), paging
* ticket page: conversation (e-mails, calls, chats, notes), reply in the ticket's channel or internal note,
  attachments both ways, state (open / waiting / closed), priority, group, title, transfer to a colleague
* changes made in Zammad come back by webhook (instant) and by a light poll every ZAMMAD_POLL_SEC:
  every open screen updates by itself, and the new owner of a transferred ticket is notified (also by push).
"""
from __future__ import annotations

import asyncio
import base64
import html
import logging
import re
from datetime import timedelta
from html.parser import HTMLParser

from sqlalchemy import select

from .audit import audit
from .db import utcnow
from .directory import full_name
from .i18n import t as tr
from .models import AgentMapping, AgentState, WorkSession
from .views import session_view
from .workflow import ticket_source
from .zammad import ZammadError

log = logging.getLogger("ticketing")

CLOSED_TYPES = {"closed", "merged", "removed"}
REPLY_CHANNELS = {"email", "telegram personal-message", "whatsapp message", "sms", "facebook direct-message"}
CHANNEL_LABEL = {"email": "email", "telegram personal-message": "telegram", "whatsapp message": "whatsapp",
                 "sms": "sms", "facebook direct-message": "facebook", "note": "note"}


class TicketError(Exception):
    def __init__(self, status: int, message: str, details: dict | None = None):
        super().__init__(message)
        self.status, self.message, self.details = status, message, details or {}


def category(state_type: str) -> str:
    t = (state_type or "").lower()
    if t in CLOSED_TYPES:
        return "closed"
    if t.startswith("pending"):
        return "pending"
    return "new" if t == "new" else "open"


# ---------------------------------------------------------------- e-mail HTML -> safe text
class _Text(HTMLParser):
    BLOCK = {"p", "div", "br", "tr", "li", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "pre", "table", "hr"}
    SKIP = {"script", "style", "head", "title"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: list[str] = []
        self.skip = 0
        self.href: list[str | None] = []

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.out.append("\n")
        if tag == "li":
            self.out.append("• ")
        if tag == "a":
            self.href.append(dict(attrs).get("href"))

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.out.append("\n")
        if tag == "a" and self.href:
            href = self.href.pop()
            if href and href.startswith(("http://", "https://", "mailto:")) and href.split(":", 1)[-1].strip("/") not in "".join(self.out[-3:]):
                self.out.append(f" ({href})")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


def html_to_text(raw: str) -> str:
    p = _Text()
    try:
        p.feed(raw or "")
        p.close()
        text = "".join(p.out)
    except Exception:  # noqa: BLE001 — broken markup: drop the tags
        text = re.sub(r"<[^>]+>", " ", raw or "")
    text = text.replace("\xa0", " ")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def article_text(a: dict) -> str:
    body = a.get("body") or ""
    if "html" in str(a.get("content_type") or "").lower():
        body = html_to_text(body)
    return body[:30000]


def text_to_html(text: str) -> str:
    return "<div>" + "<br>".join(html.escape(line) for line in (text or "").split("\n")) + "</div>"


class TicketDesk:
    def __init__(self, services):
        self.sv = services
        self._task: asyncio.Task | None = None
        self._seen: dict[int, tuple[str, int | None]] = {}  # ticket id -> (updated_at, owner_id)
        self._baseline = False
        self._ours: dict[int, float] = {}  # tickets we changed ourselves a moment ago (not "changed in Zammad")
        self._kick = asyncio.Event()

    @property
    def z(self):
        return self.sv.zammad

    @staticmethod
    def _need_link(agent: AgentMapping) -> int:
        if not agent.zammad_user_id:
            raise TicketError(409, tr("err.not_linked"))
        return agent.zammad_user_id

    @staticmethod
    def _zerr(exc: ZammadError) -> TicketError:
        if exc.status in (401, 403):
            return TicketError(403, tr("tk.no_access"))
        if exc.status == 404:
            return TicketError(404, tr("err.ticket_not_found"))
        if exc.status == 422:
            return TicketError(422, str(exc).split(": ", 1)[-1][:400])
        return TicketError(502, str(exc))

    # ------------------------------------------------------------------ reference data
    async def meta(self, agent: AgentMapping) -> dict:
        uid = self._need_link(agent)
        try:
            states = await self.z.state_list()
            priorities = await self.z.priorities()
            groups = await self.z.groups(uid)
        except ZammadError as exc:
            raise self._zerr(exc) from exc
        return {
            "states": [{**st, "category": category(st["type"])} for st in states if st["active"] and st["type"] not in ("merged", "removed")],
            "priorities": [p for p in priorities if p["active"]],
            "groups": [g for g in groups if g["active"]],
            "default_group": self.sv.settings.zammad_default_group,
            "zammad_user_id": uid,
            "attachment_max_mb": self.sv.settings.attachment_max_mb,
        }

    async def _state_maps(self) -> tuple[dict[int, dict], dict[str, dict]]:
        states = await self.z.state_list()
        return {s["id"]: s for s in states}, {s["name"].lower(): s for s in states}

    # ------------------------------------------------------------------ lists
    async def list(self, agent: AgentMapping, view: str = "mine", q: str = "", state: str = "", priority: str = "",
                   group: str = "", page: int = 1, per_page: int = 50, sort: str = "updated") -> dict:
        uid = self._need_link(agent)
        per_page = max(5, min(per_page, 100))
        try:
            by_id, by_name = await self._state_maps()
            open_ids = [str(i) for i, s in by_id.items() if s["type"] not in CLOSED_TYPES]
            closed_ids = [str(i) for i, s in by_id.items() if s["type"] == "closed"]
            cond: dict = {}
            if view == "mine":
                cond["ticket.owner_id"] = {"operator": "is", "pre_condition": "specific", "value": [str(uid)]}
                state_ids = open_ids
            elif view == "unassigned":
                cond["ticket.owner_id"] = {"operator": "is", "pre_condition": "not_set"}
                state_ids = open_ids
            elif view == "closed":
                state_ids = closed_ids
            else:
                state_ids = open_ids
            if state:
                st = by_name.get(state.lower())
                if st is None:
                    raise TicketError(422, tr("tk.bad_state", state=state))
                state_ids = [str(st["id"])]
            cond["ticket.state_id"] = {"operator": "is", "value": state_ids or ["0"]}
            if priority:
                pr = next((p for p in await self.z.priorities() if p["name"] == priority), None)
                cond["ticket.priority_id"] = {"operator": "is", "value": [str(pr["id"]) if pr else "0"]}
            if group:
                gr = next((g for g in await self.z.groups(uid) if group in (g["name"], g["full_name"])), None)
                cond["ticket.group_id"] = {"operator": "is", "value": [str(gr["id"]) if gr else "0"]}
            records, total = await self.z.search_tickets_page(
                cond, query=q.strip(), page=max(1, page), per_page=per_page, on_behalf_of=uid,
                sort_by="created_at" if sort == "created" else "updated_at")
        except ZammadError as exc:
            raise self._zerr(exc) from exc
        briefs = await self._briefs(records, by_id, agent)
        return {"tickets": briefs, "total": total, "page": max(1, page), "per_page": per_page}

    async def _briefs(self, records: list[dict], by_id: dict[int, dict], agent: AgentMapping | None = None) -> list[dict]:
        names = await self.sv.directory.names([r.get("customer_id") for r in records] + [r.get("owner_id") for r in records])
        tids = [r.get("id") for r in records if r.get("id")]
        sessions: dict[int, dict] = {}
        if tids:
            async with self.sv.db.sessionmaker() as s:
                for w in (await s.execute(select(WorkSession).where(WorkSession.ticket_id.in_(tids),
                                                                    WorkSession.state == "active"))).scalars().all():
                    sessions[w.ticket_id] = session_view(w)
        out = []
        for t in records:
            st = by_id.get(int(t.get("state_id") or 0)) or {}
            state_name = t.get("state") if isinstance(t.get("state"), str) else st.get("name", "")
            stype = st.get("type") or str(state_name).lower()
            owner_id = t.get("owner_id")
            out.append({
                "id": t.get("id"), "number": str(t.get("number") or ""), "title": t.get("title") or "",
                "state": state_name, "state_type": stype, "category": category(stype),
                "priority": t.get("priority") if isinstance(t.get("priority"), str) else "",
                "group": t.get("group") if isinstance(t.get("group"), str) else "",
                "group_id": t.get("group_id"),
                "owner_id": None if owner_id in (None, self.sv.settings.zammad_unassigned_owner_id) else owner_id,
                "owner_name": names.get(owner_id or 0, "") if owner_id not in (None, self.sv.settings.zammad_unassigned_owner_id) else "",
                "customer_id": t.get("customer_id"),
                "customer_name": names.get(t.get("customer_id") or 0) or (t.get("customer") if isinstance(t.get("customer"), str) else ""),
                "source": ticket_source(t), "created_at": t.get("created_at"), "updated_at": t.get("updated_at"),
                "pending_time": t.get("pending_time"),
                "article_count": t.get("article_count"),
                "session": sessions.get(t.get("id")),
                "mine": bool(agent and agent.zammad_user_id and owner_id == agent.zammad_user_id),
            })
        return out

    # ------------------------------------------------------------------ one ticket
    async def detail(self, agent: AgentMapping, ticket_id: int) -> dict:
        uid = self._need_link(agent)
        try:
            t = await self.z.get_ticket(ticket_id, uid)
            arts = await self.z.articles(ticket_id, uid)
            by_id, _ = await self._state_maps()
            try:
                tags = await self.z.tags(ticket_id, uid)
            except ZammadError:
                tags = []  # tags are optional: never block the ticket page
        except ZammadError as exc:
            raise self._zerr(exc) from exc
        brief = (await self._briefs([t], by_id, agent))[0]
        brief["tags"] = tags
        people = await self.sv.directory.names([a.get("created_by_id") for a in arts] + [t.get("customer_id")])
        cust = await self.sv.directory.get(int(t.get("customer_id") or 0)) if t.get("customer_id") else None
        articles = []
        for a in arts:
            if not isinstance(a, dict):
                continue
            atts = []
            for f in a.get("attachments") or []:
                prefs = f.get("preferences") or {}
                disp = str(prefs.get("Content-Disposition") or "").lower()
                if prefs.get("Content-ID") and disp.startswith("inline"):
                    continue  # pictures inside the e-mail text
                atts.append({"id": f.get("id"), "filename": f.get("filename") or "file", "size": int(f.get("size") or 0),
                             "mime": prefs.get("Content-Type") or prefs.get("Mime-Type") or "application/octet-stream"})
            sender = str(a.get("sender") or "").lower()
            articles.append({
                "id": a.get("id"), "type": a.get("type") or "note", "sender": sender, "internal": bool(a.get("internal")),
                "from": a.get("from") or "", "to": a.get("to") or "", "subject": a.get("subject") or "",
                "body": article_text(a), "created_at": a.get("created_at"),
                "author": people.get(a.get("created_by_id") or 0) or a.get("from") or a.get("created_by") or "",
                "author_id": a.get("created_by_id"), "attachments": atts,
            })
        articles.sort(key=lambda x: (str(x["created_at"] or ""), x["id"] or 0))
        session = brief.pop("session")
        return {
            "ticket": {**brief, "pending_time": t.get("pending_time"), "customer": {
                "id": t.get("customer_id"), "name": brief["customer_name"],
                "email": cust.email if cust else "", "phone": (cust.phone or cust.mobile) if cust else "",
                "organization": cust.organization if cust else "", "note": cust.note if cust else ""}},
            "articles": articles,
            "reply": self._reply_target(t, arts, cust),
            "session": session,
            "zammad_url": f"{self.sv.settings.zammad_url.rstrip('/')}/#ticket/zoom/{ticket_id}",
        }

    @staticmethod
    def _reply_target(ticket: dict, arts: list[dict], cust) -> dict:
        """Answer the customer the way he wrote to us (like Zammad's own reply button)."""
        for a in reversed(arts):
            if not isinstance(a, dict) or str(a.get("sender") or "").lower() != "customer":
                continue
            typ = str(a.get("type") or "").lower()
            if typ in REPLY_CHANNELS:
                to = a.get("reply_to") or a.get("from") or ""
                if typ == "email" and not to and cust is not None:
                    to = cust.email
                return {"type": typ, "channel": CHANNEL_LABEL.get(typ, typ), "to": to, "in_reply_to": a.get("message_id") or ""}
            break
        return {"type": "note", "channel": "note", "to": "", "in_reply_to": ""}

    # ------------------------------------------------------------------ writing
    def _attachments(self, files: list[dict]) -> list[dict]:
        limit = self.sv.settings.attachment_max_mb * 1024 * 1024
        out = []
        for f in files or []:
            data = str(f.get("data") or "")
            if "," in data[:100] and data.startswith("data:"):
                data = data.split(",", 1)[1]
            try:
                size = len(base64.b64decode(data, validate=True))
            except Exception as exc:  # noqa: BLE001
                raise TicketError(422, tr("tk.bad_file", name=f.get("filename", "?"))) from exc
            if size > limit:
                raise TicketError(413, tr("tk.file_too_big", name=f.get("filename", "?"), mb=self.sv.settings.attachment_max_mb))
            out.append({"filename": str(f.get("filename") or "file")[:200], "data": data,
                        "mime-type": str(f.get("mime") or "application/octet-stream")[:100]})
        return out

    async def reply(self, agent: AgentMapping, ticket_id: int, *, body: str, kind: str = "note", internal: bool = True,
                    attachments: list[dict] | None = None, state: str | None = None, pending_days: int | None = None) -> dict:
        """kind: note (internal or public note) | reply (to the customer in the ticket's channel)."""
        uid = self._need_link(agent)
        if not (body or "").strip() and not attachments:
            raise TicketError(422, tr("tk.empty"))
        files = self._attachments(attachments or [])
        try:
            t = await self.z.get_ticket(ticket_id, uid)
            article: dict = {"ticket_id": ticket_id, "body": body.strip(), "content_type": "text/plain", "type": "note",
                             "internal": bool(internal), "sender": "Agent"}
            if kind == "reply":
                arts = await self.z.articles(ticket_id, uid)
                cust = await self.sv.directory.get(int(t.get("customer_id") or 0)) if t.get("customer_id") else None
                target = self._reply_target(t, arts, cust)
                article.update(type=target["type"], internal=False)
                if target["type"] == "email":
                    if not target["to"]:
                        raise TicketError(422, tr("tk.no_email"))
                    article.update(to=target["to"], subject=t.get("title") or "", content_type="text/html",
                                   body=text_to_html(body.strip()))
                    if target["in_reply_to"]:
                        article["in_reply_to"] = target["in_reply_to"]
                elif target["type"] in ("sms",):
                    article["to"] = target["to"]
            if files:
                article["attachments"] = files
            if state:
                update = await self._state_update(state, pending_days)
                update["article"] = {k: v for k, v in article.items() if k != "ticket_id"}
                self._mark_ours(ticket_id)
                await self.z.update_ticket(ticket_id, update, on_behalf_of=uid)
            else:
                self._mark_ours(ticket_id)
                await self.z.add_article(article, on_behalf_of=uid)
        except ZammadError as exc:
            raise self._zerr(exc) from exc
        async with self.sv.db.sessionmaker() as s:
            audit(s, "ticket_replied" if kind == "reply" else "ticket_note", agent_id=agent.id, ticket_id=ticket_id,
                  actor_type="agent", actor_id=agent.id, number=str(t.get("number") or ""), channel=article["type"],
                  internal=article["internal"], files=len(files), state=state or None)
            await s.commit()
        await self._after_change(ticket_id, agent)
        return await self.detail(agent, ticket_id)

    async def _state_update(self, state: str, pending_days: int | None) -> dict:
        _, by_name = await self._state_maps()
        st = by_name.get(state.lower())
        if st is None:
            raise TicketError(422, tr("tk.bad_state", state=state))
        update: dict = {"state": st["name"]}
        if st["type"].startswith("pending"):
            update["pending_time"] = (utcnow() + timedelta(days=max(1, pending_days or 1))).replace(microsecond=0).isoformat()
        return update

    async def update(self, agent: AgentMapping, ticket_id: int, *, title: str | None = None, state: str | None = None,
                     pending_days: int | None = None, priority: str | None = None, group: str | None = None,
                     owner_id: int | None = None, note: str | None = None, tags: list[str] | None = None) -> dict:
        """Change the ticket. owner_id: a Zammad user id, 0 = nobody (unassigned), None = keep.
        tags (v3.11): the wanted list of tags (None = keep)."""
        uid = self._need_link(agent)
        unassigned = self.sv.settings.zammad_unassigned_owner_id
        try:
            before = await self.z.get_ticket(ticket_id, uid)
            data: dict = {}
            if title is not None and title.strip() and title.strip() != before.get("title"):
                data["title"] = title.strip()[:250]
            if state:
                data.update(await self._state_update(state, pending_days))
            if priority:
                data["priority"] = priority
            if group and group != before.get("group"):
                data["group"] = group
            if owner_id is not None:
                data["owner_id"] = owner_id or unassigned
            if note and note.strip():
                data["article"] = {"body": note.strip(), "type": "note", "internal": True, "content_type": "text/plain", "sender": "Agent"}
            if tags is not None:
                have = await self.z.tags(ticket_id, uid)
                wanted = [x.strip()[:100] for x in tags if x and x.strip()]
                for x in wanted:
                    if x not in have:
                        await self.z.tag_add(ticket_id, x, uid)
                for x in have:
                    if x not in wanted:
                        await self.z.tag_remove(ticket_id, x, uid)
                if have != wanted and not data:
                    self._mark_ours(ticket_id)
                    async with self.sv.db.sessionmaker() as s:
                        audit(s, "ticket_updated", agent_id=agent.id, ticket_id=ticket_id, actor_type="agent", actor_id=agent.id,
                              number=str(before.get("number") or ""), changes={"tags": wanted})
                        await s.commit()
                    await self._after_change(ticket_id, agent)
            if not data:
                return await self.detail(agent, ticket_id)
            self._mark_ours(ticket_id)
            after = await self.z.update_ticket(ticket_id, data, on_behalf_of=uid)
        except ZammadError as exc:
            raise self._zerr(exc) from exc

        owner_reset = False
        if owner_id:  # Zammad silently drops an owner without full access to the group: tell the truth and undo
            if after.get("owner_id") != owner_id:
                prev = before.get("owner_id")
                if prev and prev != unassigned:
                    try:
                        await self.z.update_ticket(ticket_id, {"owner_id": prev}, on_behalf_of=uid)
                    except ZammadError:
                        log.warning("could not restore owner of ticket %s", ticket_id)
                who = (await self.sv.directory.names([owner_id])).get(owner_id, f"#{owner_id}")
                await self._after_change(ticket_id, agent)
                raise TicketError(409, tr("tk.owner_no_access", name=who, group=after.get("group") or before.get("group") or ""))
        elif group and before.get("owner_id") not in (None, unassigned) and after.get("owner_id") in (None, unassigned):
            owner_reset = True

        number = str(after.get("number") or before.get("number") or "")
        changes = {k: (v if k != "article" else "note") for k, v in data.items() if k != "pending_time"}
        if tags is not None:
            changes["tags"] = tags
        target: AgentMapping | None = None
        async with self.sv.db.sessionmaker() as s:
            audit(s, "ticket_updated", agent_id=agent.id, ticket_id=ticket_id, actor_type="agent", actor_id=agent.id,
                  number=number, changes=changes)
            if owner_id and owner_id != uid and owner_id != before.get("owner_id"):
                target = (await s.execute(select(AgentMapping).where(AgentMapping.zammad_user_id == owner_id,
                                                                     AgentMapping.active.is_(True)))).scalars().first()
                if target is not None:
                    audit(s, "ticket_reassigned", agent_id=target.id, ticket_id=ticket_id, actor_type="agent",
                          actor_id=agent.id, number=number, by=agent.display_name, title=after.get("title", ""))
            await s.commit()
        if target is not None:
            self._notify_assigned(target.id, ticket_id, number, after.get("title", ""), agent.display_name)
        await self._after_change(ticket_id, agent)
        try:
            res = await self.detail(agent, ticket_id)
        except TicketError as exc:  # e.g. moved to a group the operator cannot see
            if exc.status not in (403, 404):
                raise
            res = {"ticket": None, "gone": True}
        res["owner_reset"] = owner_reset
        return res

    async def create(self, agent: AgentMapping, payload: dict) -> dict:
        """Used by POST /api/tickets: create in the operator's name when he is linked."""
        uid = agent.zammad_user_id
        try:
            ticket = await self.z.create_ticket(payload, on_behalf_of=uid)
        except ZammadError as exc:
            raise self._zerr(exc) from exc
        self._mark_ours(int(ticket["id"]))
        self._forget_views()
        self.sv.broker.publish_all("ticket_changed", {"ids": [ticket["id"]], "by": agent.id})
        return ticket

    async def assignees(self, agent: AgentMapping, ticket_id: int, group: str | None = None) -> dict:
        """Colleagues the ticket can be transferred to: Zammad staff with full access to the group,
        with their Zenith Desk status (ready / busy / break / offline) when they use Zenith Desk."""
        uid = self._need_link(agent)
        try:
            t = await self.z.get_ticket(ticket_id, uid)
            groups = await self.z.groups(uid)
        except ZammadError as exc:
            raise self._zerr(exc) from exc
        gname = group or (t.get("group") if isinstance(t.get("group"), str) else "")
        gid = next((g["id"] for g in groups if gname in (g["name"], g["full_name"])), t.get("group_id"))
        people = await self.sv.directory.agents_for_group(gname, gid)
        async with self.sv.db.sessionmaker() as s:
            links = {m.zammad_user_id: m for m in (await s.execute(select(AgentMapping).where(
                AgentMapping.zammad_user_id.is_not(None), AgentMapping.active.is_(True)))).scalars().all()}
            states = {st.agent_id: st for st in (await s.execute(select(AgentState))).scalars().all()}
        out = []
        for p in people:
            m = links.get(p.id)
            st = states.get(m.id) if m else None
            out.append({"id": p.id, "name": m.display_name if m else full_name(p), "email": p.email,
                        "position": m.position if m else "", "agentix_id": m.id if m else None,
                        "state": (st.computed_state if st else "offline") if m else None,
                        "me": p.id == uid, "owner": p.id == t.get("owner_id")})
        rank = {"ready": 0, "wrap_up": 1, "busy_task": 2, "break": 3, "offline": 4, None: 5}
        out.sort(key=lambda x: (x["me"], rank.get(x["state"], 5), x["name"].lower()))
        return {"group": gname, "people": out, "directory_ready": bool(people) or self.sv.directory.last_sync is not None}

    async def attachment(self, agent: AgentMapping, ticket_id: int, article_id: int, att_id: int):
        uid = self._need_link(agent)
        try:
            return await self.z.attachment(ticket_id, article_id, att_id, uid)
        except ZammadError as exc:
            raise self._zerr(exc) from exc

    async def customer_tickets(self, agent: AgentMapping, customer_id: int, staff: bool = False) -> list[dict]:
        uid = self._need_link(agent)
        field = "ticket.owner_id" if staff else "ticket.customer_id"
        try:
            by_id, _ = await self._state_maps()
            records, _total = await self.z.search_tickets_page(
                {field: {"operator": "is", "pre_condition": "specific", "value": [str(customer_id)]}},
                per_page=30, on_behalf_of=uid)
        except ZammadError as exc:
            raise self._zerr(exc) from exc
        return await self._briefs(records, by_id, agent)

    # ------------------------------------------------------------------ live
    def _mark_ours(self, ticket_id: int) -> None:
        self._ours[ticket_id] = asyncio.get_running_loop().time()

    def _notify_assigned(self, agentix_id: int, ticket_id: int, number: str, title: str, by: str) -> None:
        data = {"ticket_id": ticket_id, "number": number, "title": title, "by": by}
        self.sv.broker.publish_agent(agentix_id, "ticket_assigned", data)
        try:
            if self.sv.broker.connections(agentix_id) == 0:  # no Zenith Desk window open -> background notification
                self.sv.push.notify_later(agentix_id, {
                    "type": "ticket", "ticket_id": ticket_id, "title": tr("tk.push_title", number=number),
                    "body": f"{title}" + (f" — {by}" if by else "")})
        except RuntimeError:
            pass

    def _forget_views(self) -> None:
        views = getattr(self.sv, "views", None)
        if views is not None:
            views.forget()

    async def _after_change(self, ticket_id: int, agent: AgentMapping | None) -> None:
        self._forget_views()
        self.sv.broker.publish_all("ticket_changed", {"ids": [ticket_id], "by": agent.id if agent else None})
        try:
            await self.sv.workflow.on_ticket_changed(ticket_id, "agentix")
        except Exception:  # noqa: BLE001
            log.exception("work sessions not updated for ticket %s", ticket_id)

    def kick(self) -> None:
        self._kick.set()

    async def poll(self) -> list[int]:
        """Find tickets changed in Zammad since the last look; update every screen and every work session."""
        by_id, _ = await self._state_maps()
        records, _ = await self.z.search_tickets_page(
            {"ticket.state_id": {"operator": "is", "value": [str(i) for i in by_id]}}, per_page=50)
        changed: list[int] = []
        reassigned: list[tuple[int, dict]] = []
        loop_now = asyncio.get_running_loop().time()
        for t in records:
            tid = t.get("id")
            if not tid:
                continue
            key = (str(t.get("updated_at") or ""), t.get("owner_id"))
            old = self._seen.get(tid)
            self._seen[tid] = key
            if not self._baseline or old == key:
                continue
            changed.append(tid)
            ours = loop_now - self._ours.get(tid, -1e9) < 30
            fresh = old is not None or self._is_new(t)  # never seen: only a brand-new ticket counts
            if not ours and fresh and (old is None or old[1] != key[1]) and key[1] not in (None, self.sv.settings.zammad_unassigned_owner_id):
                reassigned.append((tid, t))
        if len(self._seen) > 5000:  # keep memory small: forget the oldest half
            for k in list(self._seen)[:2500]:
                self._seen.pop(k, None)
        for k in [k for k, v in self._ours.items() if loop_now - v > 120]:
            self._ours.pop(k, None)
        self._baseline = True
        if changed:
            self._forget_views()
            self.sv.broker.publish_all("ticket_changed", {"ids": changed, "by": None})
            self.sv.broker.publish_all("changed", {"topics": ["tickets"]})
            for tid in changed:
                try:
                    await self.sv.workflow.on_ticket_changed(tid, "poll")
                except Exception:  # noqa: BLE001
                    log.exception("work sessions not updated for ticket %s", tid)
        for tid, t in reassigned:  # transferred in Zammad itself: tell the new owner
            async with self.sv.db.sessionmaker() as s:
                target = (await s.execute(select(AgentMapping).where(AgentMapping.zammad_user_id == t.get("owner_id"),
                                                                     AgentMapping.active.is_(True)))).scalars().first()
                if target is None:
                    continue
                audit(s, "ticket_reassigned", agent_id=target.id, ticket_id=tid, actor_type="zammad",
                      number=str(t.get("number") or ""), title=t.get("title", ""))
                await s.commit()
            self._notify_assigned(target.id, tid, str(t.get("number") or ""), t.get("title", ""), "Zammad")
        return changed

    @staticmethod
    def _is_new(t: dict) -> bool:
        from .directory import parse_ts
        created = parse_ts(t.get("created_at"))
        return bool(created and utcnow() - created < timedelta(minutes=10))

    def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="ticket-poll")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _loop(self) -> None:
        while True:
            every = self.sv.settings.zammad_poll_sec
            try:
                if every > 0 or self._kick.is_set():
                    self._kick.clear()
                    await self.poll()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.debug("ticket poll failed: %s", exc)
            try:
                await asyncio.wait_for(self._kick.wait(), timeout=max(every, 2) if every > 0 else 3600)
            except asyncio.TimeoutError:
                pass
