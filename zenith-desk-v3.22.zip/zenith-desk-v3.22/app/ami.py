"""Minimal asyncio Asterisk Manager Interface client.

* one persistent TCP connection, automatic reconnect with backoff
* actions are correlated by ActionID; list actions (QueueStatus) collect their events
* every unsolicited event is passed to `on_event`
* `on_connect` is awaited after each successful login (used to trigger a full reconcile)
"""
import asyncio
import itertools
import logging
from collections.abc import Awaitable, Callable

log = logging.getLogger("ami")

Message = dict[str, str]


class AMIError(Exception):
    pass


class AMIUnsafeField(AMIError, ValueError):
    """SEC-04: a key or value would break the AMI framing (CR / LF / NUL)."""


class AMINotConnected(AMIError):
    pass


def parse_message(raw: str) -> Message:
    msg: Message = {}
    for line in raw.split("\r\n"):
        if not line or ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        # Duplicate keys (rare, e.g. ChanVariable) are joined with "|"
        msg[key] = f"{msg[key]}|{value}" if key in msg else value
    return msg


_BAD = ("\r", "\n", "\0")


def build_message(fields: Message) -> bytes:
    # SEC-04: a CR/LF inside a key or value would end the header early and smuggle a second AMI action
    # (e.g. Originate / Command) into the same write — refuse instead of sending anything.
    for k, v in fields.items():
        if any(c in str(k) for c in _BAD) or any(c in str(v) for c in _BAD) or ":" in str(k):
            raise AMIUnsafeField(f"AMI field {str(k)[:20]!r} contains a forbidden control character")
    return ("".join(f"{k}: {v}\r\n" for k, v in fields.items()) + "\r\n").encode()


class _Pending:
    def __init__(self, complete_event: str | None):
        self.complete_event = complete_event
        self.response: Message | None = None
        self.events: list[Message] = []
        self.future: asyncio.Future = asyncio.get_running_loop().create_future()


class AMIClient:
    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        secret: str,
        *,
        on_event: Callable[[Message], Awaitable[None]] | None = None,
        on_connect: Callable[[], Awaitable[None]] | None = None,
        on_disconnect: Callable[[], Awaitable[None]] | None = None,
        action_timeout: float = 5.0,
        tls: bool = False,
        tls_verify: bool = True,
        tls_fingerprint: str = "",
    ):
        self.host, self.port, self.username, self.secret = host, port, username, secret
        # v3.17: AMI over TLS (Asterisk manager.conf tlsenable=yes, port 5039) — the login and every call event encrypted
        self.tls, self.tls_verify, self.tls_fingerprint = tls, tls_verify, tls_fingerprint
        self.on_event = on_event
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect
        self.action_timeout = action_timeout
        self._ids = itertools.count(1)
        self._pending: dict[str, _Pending] = {}
        self._writer: asyncio.StreamWriter | None = None
        self._connected = asyncio.Event()
        self._stopping = False
        self._task: asyncio.Task | None = None
        self.last_error: str = ""

    # ------------------------------------------------------------------ lifecycle
    @property
    def connected(self) -> bool:
        return self._connected.is_set()

    def start(self) -> None:
        self._stopping = False
        self._task = asyncio.create_task(self._run_forever(), name="ami-client")

    async def stop(self) -> None:
        self._stopping = True
        if self._writer:
            self._writer.close()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def wait_connected(self, timeout: float) -> bool:
        try:
            await asyncio.wait_for(self._connected.wait(), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    async def _run_forever(self) -> None:
        delay = 1.0
        while not self._stopping:
            try:
                await self._session()
                delay = 1.0
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 — any network error -> reconnect
                self.last_error = str(exc) or exc.__class__.__name__
                log.warning("AMI connection error: %s", self.last_error)
            finally:
                was_connected = self._connected.is_set()
                self._connected.clear()
                self._fail_pending(AMINotConnected("AMI connection lost"))
                if was_connected and self.on_disconnect:
                    try:
                        await self.on_disconnect()
                    except Exception:  # noqa: BLE001
                        log.exception("on_disconnect failed")
            if self._stopping:
                break
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30.0)

    async def _session(self) -> None:
        ctx = None
        if self.tls:
            from .tls import client_context  # noqa: PLC0415
            ctx = client_context(self.tls_verify, self.tls_fingerprint)
        reader, writer = await asyncio.wait_for(asyncio.open_connection(
            self.host, self.port, ssl=ctx, server_hostname=self.host if ctx else None), 10)
        if ctx is not None:
            from .tls import check_pin  # noqa: PLC0415
            try:
                check_pin(writer.get_extra_info("ssl_object"), self.tls_fingerprint)
            except Exception:
                writer.close()
                raise
        self._writer = writer
        banner = await asyncio.wait_for(reader.readline(), 10)
        log.info("AMI connected: %s", banner.decode(errors="replace").strip())
        reader_task = asyncio.create_task(self._read_loop(reader))
        try:
            resp = await self._send({"Action": "Login", "Username": self.username, "Secret": self.secret, "Events": "on"})
            if resp.get("Response") != "Success":
                raise AMIError(f"AMI login failed: {resp.get('Message', resp)}")
            self._connected.set()
            self.last_error = ""
            if self.on_connect:
                asyncio.create_task(self.on_connect())
            await reader_task  # returns when the connection closes
        finally:
            reader_task.cancel()
            writer.close()
            self._writer = None

    async def _read_loop(self, reader: asyncio.StreamReader) -> None:
        buf = ""
        while True:
            chunk = await reader.read(65536)
            if not chunk:
                raise ConnectionError("AMI closed the connection")
            buf += chunk.decode(errors="replace")
            while "\r\n\r\n" in buf:
                raw, buf = buf.split("\r\n\r\n", 1)
                msg = parse_message(raw)
                if msg:
                    await self._dispatch(msg)

    def _fail_pending(self, exc: Exception) -> None:
        for p in self._pending.values():
            if not p.future.done():
                p.future.set_exception(exc)
        self._pending.clear()

    # ------------------------------------------------------------------ dispatch
    async def _dispatch(self, msg: Message) -> None:
        action_id = msg.get("ActionID")
        pending = self._pending.get(action_id) if action_id else None
        if pending is not None:
            if "Response" in msg:
                pending.response = msg
                list_follows = msg.get("EventList", "").lower() == "start" or "will follow" in msg.get("Message", "").lower()
                if pending.complete_event is None or msg.get("Response") != "Success" or not list_follows:
                    self._resolve(action_id, pending)
                return
            if "Event" in msg:
                if msg["Event"] == pending.complete_event or msg.get("EventList", "").lower() == "complete":
                    self._resolve(action_id, pending)
                else:
                    pending.events.append(msg)
                return
        if "Event" in msg and self.on_event:
            try:
                await self.on_event(msg)
            except Exception:  # noqa: BLE001
                log.exception("AMI event handler failed for %s", msg.get("Event"))

    def _resolve(self, action_id: str, pending: _Pending) -> None:
        self._pending.pop(action_id, None)
        if not pending.future.done():
            pending.future.set_result((pending.response or {}, pending.events))

    # ------------------------------------------------------------------ actions
    async def _send(self, fields: Message, complete_event: str | None = None) -> Message:
        resp, _ = await self._send_list(fields, complete_event)
        return resp

    async def _send_list(self, fields: Message, complete_event: str | None) -> tuple[Message, list[Message]]:
        if self._writer is None:
            raise AMINotConnected("AMI is not connected")
        action_id = f"aws-{next(self._ids)}"
        data = build_message({**fields, "ActionID": action_id})  # SEC-04: refused before anything is queued
        pending = _Pending(complete_event)
        self._pending[action_id] = pending
        self._writer.write(data)
        await self._writer.drain()
        try:
            return await asyncio.wait_for(pending.future, self.action_timeout)
        except asyncio.TimeoutError as exc:
            self._pending.pop(action_id, None)
            raise AMIError(f"AMI action {fields.get('Action')} timed out") from exc

    async def action(self, name: str, **fields: str) -> Message:
        if not self.connected:
            raise AMINotConnected("AMI is not connected")
        return await self._send({"Action": name, **{k: str(v) for k, v in fields.items()}})

    async def action_list(self, name: str, complete_event: str, **fields: str) -> tuple[Message, list[Message]]:
        if not self.connected:
            raise AMINotConnected("AMI is not connected")
        return await self._send_list({"Action": name, **{k: str(v) for k, v in fields.items()}}, complete_event)
