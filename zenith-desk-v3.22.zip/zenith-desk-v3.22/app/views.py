"""JSON views shared by the API and SSE events."""
from .db import as_utc
from .i18n import t as tr
from .models import AgentMapping, AgentState, CallRecord, WorkSession

def state_label(state: str) -> str:
    return tr(f"state.{state}") if state in ("ready", "busy_task", "break", "offline", "wrap_up") else state


def agent_state_view(m: AgentMapping, st: AgentState, managed_queues: list[str]) -> dict:
    managed = bool(m.enabled and m.asterisk_interface and managed_queues)
    confirmed = (not managed) or (st.sync_status == "ok" and st.queue_paused is not None)
    # What the operator effectively is for incoming calls, as far as we KNOW.
    if not managed:
        phone_status, phone_label = "unmanaged", tr("phone.unmanaged")
    elif not confirmed:
        phone_status = "unknown"
        phone_label = tr("phone.unknown") + (f": {st.sync_error}" if st.sync_error else "")
    elif st.queue_paused:
        phone_status = "paused"
        phone_label = tr("phone.external") if st.external_pause else tr("phone.paused")
    else:
        phone_status = "receiving"
        phone_label = tr("phone.receiving")

    # Never show READY as confirmed if the real queue state is unknown (FR-14).
    display_state = st.computed_state
    if st.computed_state == "ready" and phone_status in ("unknown", "paused"):
        display_state = "ready_unconfirmed" if phone_status == "unknown" else "external_pause"

    idle = as_utc(st.idle_since) if st.computed_state == "offline" else None
    return {
        "agent_id": m.id,
        "zammad_user_id": m.zammad_user_id,
        "name": m.display_name,
        "extension": m.extension,
        "role": m.role,
        "level": m.level,
        "position": m.position,
        "avatar_url": m.avatar_url,
        "enabled": m.enabled,
        "manual_state": st.manual_state,
        "dnd": bool(st.dnd),
        "computed_state": st.computed_state,
        "computed_label": state_label(st.computed_state),
        "display_state": display_state,
        "reason": tr("reason.idle") if idle else st.reason,
        "idle_since": idle,
        "last_activity_at": as_utc(st.last_activity_at),
        "override_ready": st.override_ready,
        "override_reason": st.override_reason,
        "wrap_up_until": as_utc(st.wrap_up_until),
        "phone_status": phone_status,
        "phone_label": phone_label,
        "queue_paused": st.queue_paused,
        "external_pause": st.external_pause,
        "sync_status": st.sync_status,
        "sync_error": st.sync_error,
        "confirmed": confirmed,
        "next_retry_at": as_utc(st.next_retry_at),
        "last_asterisk_sync_at": as_utc(st.last_asterisk_sync_at),
        "updated_at": as_utc(st.updated_at),
    }


def session_view(ws: WorkSession) -> dict:
    return {
        "id": ws.id,
        "ticket_id": ws.ticket_id,
        "ticket_number": ws.ticket_number,
        "ticket_title": ws.ticket_title,
        "source": ws.source,
        "agent_id": ws.agent_id,
        "work_mode": ws.work_mode,
        "state": ws.state,
        "started_at": as_utc(ws.started_at),
        "ended_at": as_utc(ws.ended_at),
        "end_reason": ws.end_reason,
    }


def call_view(c: CallRecord, recording_url: str = "") -> dict:
    return {
        "id": c.id,
        "linkedid": c.linkedid,
        "uniqueid": c.uniqueid,
        "agent_id": c.agent_id,
        "direction": c.direction,
        "queue": c.queue,
        "extension": c.extension,
        "caller_number": c.caller_number,
        "caller_normalized": c.caller_normalized,
        "caller_name": c.caller_name,
        "state": c.state,
        "started_at": as_utc(c.started_at),
        "answered_at": as_utc(c.answered_at),
        "ended_at": as_utc(c.ended_at),
        "recording_file": c.recording_file,
        "recording_url": recording_url,
        "ticket_id": c.ticket_id,
    }
