"""v3.15 call supervision: a manager listens to an operator's call, whispers to him or joins the call.

Asterisk does the audio (ChanSpy). Zenith Desk asks it over AMI to ring the manager's own phone; when he answers,
he hears the operator's call:
* listen  — nobody hears the manager;
* whisper — only the operator hears him (the customer does not);
* barge   — both hear him (a three-way call).
During the call the mode can change with the keys 4 / 5 / 6 (Zenith Phone sends them by itself).
Every session is in the audit log: who listened to whom, when, in which mode and for how long.
"""
from __future__ import annotations

import logging
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import select

from .ami import AMIError
from .audit import audit
from .db import as_utc, utcnow
from .i18n import t as tr
from .models import AgentMapping, CallRecord
from .pbx import SPY_DIGITS, SPY_OPTIONS, SPY_PREFIX

log = logging.getLogger("supervise")
MAX_AGE = timedelta(hours=4)


@dataclass
class SpySession:
    id: str
    supervisor_id: int
    agent_id: int
    agent_name: str
    mode: str
    call_id: int | None
    number: str
    started_at: datetime = field(default_factory=utcnow)

    @property
    def channel_id(self) -> str:
        return f"{SPY_PREFIX}-{self.id}"

    @property
    def caller(self) -> str:
        return f"{SPY_PREFIX}{self.id}"  # caller number on the manager's phone: Zenith Phone answers it by itself

    def view(self) -> dict:
        return {"id": self.id, "agent_id": self.agent_id, "agent_name": self.agent_name, "mode": self.mode, "call_id": self.call_id,
                "number": self.number, "caller": self.caller, "digit": SPY_DIGITS[self.mode], "started_at": self.started_at}


async def active_calls(s) -> dict[int, CallRecord]:
    """The answered, still running call of every operator (the newest one)."""
    since = utcnow() - timedelta(hours=12)
    rows = (await s.execute(select(CallRecord).where(
        CallRecord.state == "answered", CallRecord.ended_at.is_(None), CallRecord.agent_id.is_not(None),
        CallRecord.started_at >= since).order_by(CallRecord.started_at))).scalars().all()
    return {c.agent_id: c for c in rows}


class Supervision:
    def __init__(self, services):
        self.sv = services
        self.sessions: dict[int, SpySession] = {}  # by manager

    def current(self, supervisor_id: int) -> SpySession | None:
        x = self.sessions.get(supervisor_id)
        if x and utcnow() - x.started_at > MAX_AGE:
            self.sessions.pop(supervisor_id, None)
            return None
        return x

    async def start(self, sup: AgentMapping, agent_id: int, mode: str) -> dict:
        cfg = self.sv.settings
        if not cfg.supervise_enabled:
            raise HTTPException(403, tr("spy.disabled"))
        if mode not in SPY_OPTIONS:
            raise HTTPException(422, "mode must be listen, whisper or barge")
        if not (sup.extension or "").strip():
            raise HTTPException(409, tr("spy.no_extension"))
        if agent_id == sup.id:
            raise HTTPException(409, tr("spy.self"))
        async with self.sv.db.sessionmaker() as s:
            target = await s.get(AgentMapping, agent_id)
            if target is None or not target.active:
                raise HTTPException(404, tr("err.agent_not_found"))
            if target.role == "admin" and sup.role != "admin":
                raise HTTPException(403, tr("err.forbidden"))
            if not (target.extension or "").strip():
                raise HTTPException(409, tr("spy.no_target_extension"))
            call = (await active_calls(s)).get(target.id)
            if call is None:
                raise HTTPException(409, tr("spy.not_on_call"))
        if not self.sv.pbx.connected:
            raise HTTPException(503, tr("spy.no_pbx"))
        if self.current(sup.id):
            await self.stop(sup, reason="replaced")
        x = SpySession(id=secrets.token_hex(5), supervisor_id=sup.id, agent_id=target.id,
                       agent_name=target.display_name or target.username or "", mode=mode, call_id=call.id,
                       number=call.caller_number)
        dial = cfg.supervise_dial.format(ext=sup.extension.strip())
        spy = cfg.supervise_spy.format(ext=target.extension.strip())
        if not spy.endswith("-"):
            spy += "-"  # PJSIP/101- : never also the channels of 1011, 1012…
        label = tr("spy.caller_name", name=x.agent_name).replace('"', "'")
        try:
            await self.sv.pbx.spy(dial, spy, mode, f'"{label}" <{x.caller}>', x.channel_id)
        except AMIError as e:
            async with self.sv.db.sessionmaker() as s:
                audit(s, "spy_failed", agent_id=target.id, actor_type="supervisor", actor_id=sup.id, level="error", mode=mode, error=str(e))
                await s.commit()
            raise HTTPException(502, tr("spy.failed", error=str(e))) from e
        self.sessions[sup.id] = x
        async with self.sv.db.sessionmaker() as s:
            audit(s, "spy_started", agent_id=target.id, actor_type="supervisor", actor_id=sup.id, mode=mode, session=x.id,
                  call_id=call.id, number=call.caller_number, by=sup.display_name)
            await s.commit()
        v = x.view()
        self.sv.broker.publish_agent(sup.id, "spy", {"active": True, "session": v})
        return v

    async def set_mode(self, sup: AgentMapping, mode: str) -> dict:
        if mode not in SPY_OPTIONS:
            raise HTTPException(422, "mode must be listen, whisper or barge")
        x = self.current(sup.id)
        if x is None:
            raise HTTPException(404, tr("spy.none"))
        if x.mode != mode:
            old, x.mode = x.mode, mode
            async with self.sv.db.sessionmaker() as s:
                audit(s, "spy_mode", agent_id=x.agent_id, actor_type="supervisor", actor_id=sup.id, session=x.id, old=old, new=mode,
                      by=sup.display_name)
                await s.commit()
        v = x.view()
        self.sv.broker.publish_agent(sup.id, "spy", {"active": True, "session": v})
        return v

    async def stop(self, sup: AgentMapping, reason: str = "stopped") -> dict:
        x = self.sessions.pop(sup.id, None)
        if x is None:
            return {"active": False}
        try:
            await self.sv.pbx.hangup(x.channel_id)
        except AMIError as e:  # already gone, or the AMI user may not hang up: the phone ends it itself
            log.info("spy hangup %s: %s", x.channel_id, e)
        await self._ended(x, sup.id, reason)
        return {"active": False}

    async def _ended(self, x: SpySession, actor_id: int | None, reason: str) -> None:
        async with self.sv.db.sessionmaker() as s:
            audit(s, "spy_stopped", agent_id=x.agent_id, actor_type="supervisor" if actor_id else "asterisk", actor_id=actor_id,
                  session=x.id, mode=x.mode, reason=reason, seconds=int((utcnow() - as_utc(x.started_at)).total_seconds()))
            await s.commit()
        self.sv.broker.publish_agent(x.supervisor_id, "spy", {"active": False, "session": x.view()})

    async def on_event(self, ev: dict) -> None:
        """AMI: the manager's listening channel hung up (he put the phone down, or the operator's call ended)."""
        if ev.get("Event") not in ("Hangup", "OriginateResponse"):
            return
        if ev.get("Event") == "OriginateResponse" and ev.get("Response") == "Success":
            return
        ids = {str(ev.get(k, "")) for k in ("Uniqueid", "Linkedid", "DestUniqueid", "ChannelId")}
        for sup_id, x in list(self.sessions.items()):
            if x.channel_id in ids:
                self.sessions.pop(sup_id, None)
                await self._ended(x, None, "hangup" if ev.get("Event") == "Hangup" else "not_answered")
