"""Sign-in with a login and password created by the administrator. The service issues its own JWT.
Roles: operator / supervisor / admin (agent_mapping.role)."""
import hashlib
import secrets
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .db import as_utc, utcnow
from .i18n import t as tr
from .models import AgentMapping, RevokedToken
from .services import Services
from .sessions import previous_session_keys
from . import api_keys

bearer = HTTPBearer(auto_error=False)
ROLE_LEVEL = {"operator": 1, "supervisor": 2, "admin": 3}
# endpoints reachable while the user still has to change the password
PASSWORD_CHANGE_ALLOWED = {"/api/auth/me", "/api/auth/change-password", "/api/auth/logout", "/api/config"}


def get_services(request: Request) -> Services:
    return request.app.state.services


def password_version(agent: AgentMapping) -> str:
    """Changes whenever the password changes -> old sessions become invalid."""
    return hashlib.sha256((agent.password_hash or "").encode()).hexdigest()[:16]


def _now_ms() -> int:
    return int(utcnow().timestamp() * 1000)


def signed_out_everywhere(agent: AgentMapping, payload: dict) -> bool:
    """v3.21: the administrator pressed «sign out everywhere» after this token was issued (tokens without "ia" are
    from before v3.21 — they end too)."""
    if agent.sessions_valid_after is None:
        return False
    ia = payload.get("ia")
    cut = int(as_utc(agent.sessions_valid_after).timestamp() * 1000)
    return not isinstance(ia, int) or ia <= cut


def issue_token(services: Services, agent: AgentMapping) -> str:
    s = services.settings
    payload = {"sub": str(agent.id), "role": agent.role, "pv": password_version(agent), "typ": "session",
               "jti": secrets.token_hex(16),  # SEC-07: lets sign-out revoke exactly this session
               "ia": _now_ms(),  # v3.21: issued-at in ms — «sign out everywhere» ends every older token
               "exp": utcnow() + timedelta(hours=s.jwt_ttl_hours)}
    return jwt.encode(payload, s.jwt_secret, algorithm="HS256")


STREAM_PATH = "/api/events/stream"


def decode_token(services: Services, token: str, stream: bool = False) -> dict:
    """This server's key; v3.18: a session signed by the server a restored backup came from is valid until it expires."""
    opts = {"require": ["exp", "sub"]}
    try:
        return jwt.decode(token, services.settings.jwt_secret, algorithms=["HS256"], options=opts)
    except jwt.InvalidSignatureError:
        if stream:
            raise  # stream tickets are always issued by this server
        for k in previous_session_keys(services.settings):
            try:
                return jwt.decode(token, k["k"], algorithms=["HS256"], options=opts)
            except jwt.InvalidSignatureError:
                continue
        raise


async def revoke_session(services: Services, token: str) -> bool:
    """SEC-07: sign-out — this session token is refused from now on (other devices of the user stay signed in)."""
    try:
        payload = decode_token(services, token)
    except jwt.PyJWTError:
        return False
    jti, sub = payload.get("jti"), str(payload.get("sub", ""))
    if payload.get("typ", "session") != "session" or not isinstance(jti, str) or not sub.isdigit():
        return False  # sessions from before SEC-07 carry no id: they end with their normal expiry
    exp = datetime.fromtimestamp(int(payload["exp"]), tz=timezone.utc)
    async with services.db.sessionmaker() as s:
        if await s.get(RevokedToken, jti) is None:
            s.add(RevokedToken(jti=jti, agent_id=int(sub), expires_at=exp))
            await s.commit()
    return True


def issue_stream_token(services: Services, agent: AgentMapping) -> str:
    """v3.17: a 60-second ticket for the live stream. EventSource cannot send headers, so the stream is opened with
    ?token=… in the address — that address may end up in proxy logs, so it never carries the real session token."""
    payload = {"sub": str(agent.id), "pv": password_version(agent), "typ": "stream", "ia": _now_ms(),
               "exp": utcnow() + timedelta(seconds=60)}
    return jwt.encode(payload, services.settings.jwt_secret, algorithm="HS256")


async def current_agent(
    request: Request,
    creds: HTTPAuthorizationCredentials | None = Depends(bearer),
    services: Services = Depends(get_services),
) -> AgentMapping:
    # v3.17: a token in the address is accepted only for the live stream, and only a short stream ticket
    stream = request.url.path == STREAM_PATH and not creds
    token = creds.credentials if creds else (request.query_params.get("token") if stream else None)
    header_key = request.headers.get("x-api-key")
    if header_key and not creds:
        token, stream = header_key, False
    if api_keys.is_key(token) and not stream:  # v3.18: another program with an API key
        return await _agent_by_key(request, services, token)
    if not token:
        raise HTTPException(401, tr("err.auth_required"))
    try:
        payload = decode_token(services, token, stream)
    except jwt.PyJWTError as exc:
        raise HTTPException(401, tr("err.session_expired")) from exc
    kind = payload.get("typ", "session")  # tokens issued before v3.17 have no typ: sessions
    if kind != ("stream" if stream else "session") or not str(payload.get("sub", "")).isdigit():
        raise HTTPException(401, tr("err.session_expired"))
    jti = payload.get("jti")
    async with services.db.sessionmaker() as s:
        agent = await s.get(AgentMapping, int(payload["sub"]))
        revoked = isinstance(jti, str) and await s.get(RevokedToken, jti) is not None  # SEC-07: signed out
    if agent is None or not agent.active or payload.get("pv") != password_version(agent) or revoked \
            or signed_out_everywhere(agent, payload):
        raise HTTPException(401, tr("err.session_expired"))
    if agent.must_change_password and request.url.path not in PASSWORD_CHANGE_ALLOWED:
        raise HTTPException(403, tr("err.password_change_required"))
    return agent


async def _agent_by_key(request: Request, services: Services, token: str) -> AgentMapping:
    ip = request.client.host if request.client else ""
    try:
        key = await api_keys.check(services, token, request.method, request.url.path, ip)
    except api_keys.KeyRefused as exc:
        raise HTTPException(exc.status, tr(exc.code)) from exc
    async with services.db.sessionmaker() as s:
        agent = await s.get(AgentMapping, key.agent_id)
    if agent is None or not agent.active:
        raise HTTPException(401, tr("api.user_disabled"))
    request.state.api_key = key.id
    return agent


def require_role(role: str):
    async def dep(agent: AgentMapping = Depends(current_agent)) -> AgentMapping:
        if ROLE_LEVEL.get(agent.role, 0) < ROLE_LEVEL[role]:
            raise HTTPException(403, tr("err.forbidden"))
        return agent
    return dep
