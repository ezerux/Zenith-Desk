"""Internal messenger between employees (v3.0, extended in v3.1 and v3.20).

Direct 1:1 conversations and (v3.20) group conversations, kept in `chat_message` (bodies and files encrypted at rest).
Every user can write to any active colleague; nobody — administrators included — can read conversations they are not
part of: direct messages only by the two people, group messages and files only by the current members of the group.

Live over SSE: `chat` (new message), `chat_update` (edited / reacted / deleted), `chat_read` (✓✓), `chat_typing`,
`chat_group` (a group was created / renamed / its members changed) and `chat_group_read`.
When the recipient has no Zenith Desk window open, a Web Push notification is sent to their subscribed browsers.
"""
import base64
import binascii
import re
import secrets
import time
from datetime import timedelta
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import and_, delete, func, not_, or_, select, update

from ..auth import current_agent, get_services
from ..db import as_utc, utcnow
from ..i18n import t as tr
from ..models import (AgentMapping, AgentState, ChatFile, ChatGroup, ChatGroupMember, ChatMessage, ChatReaction,
                      PushSubscription)
from ..services import Services
from ..views import state_label

router = APIRouter(prefix="/api/chat", tags=["messenger"])
push_router = APIRouter(prefix="/api/push", tags=["messenger"])
MAX_BODY = 4000
EDIT_WINDOW = timedelta(hours=48)
REACTIONS = ("❤️", "👍", "😂", "😮", "😢", "🔥", "👏", "🙏")
MAX_FILES = 10           # v3.20: files in one message
MAX_FILE_MB = 20         # one file
MAX_FILES_MB = 40        # all files of one message (the request stays under the 64 MB body limit even as base64)
MAX_GROUP = 200          # members of one group
TYPING_EVERY = 1.5       # seconds: at most one «typing…» event per sender and conversation
INLINE = re.compile(r"^(image/(png|jpeg|gif|webp)|audio/[\w.+-]+|video/[\w.+-]+)$")  # shown in the page; never SVG / HTML
_typing_sent: dict[tuple[int, str], float] = {}


class FileIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    mime: str = Field("", max_length=150)
    data: str  # base64


class MessageIn(BaseModel):
    """A new message: text, files or both (v3.20)."""
    body: str = Field("", max_length=MAX_BODY)
    files: list[FileIn] = Field(default_factory=list, max_length=MAX_FILES)

    @field_validator("body")
    @classmethod
    def tidy(cls, v: str) -> str:
        return v.strip("\n\r ").replace("\r\n", "\n")


class EditIn(BaseModel):
    body: str = Field(min_length=1, max_length=MAX_BODY)

    @field_validator("body")
    @classmethod
    def not_blank(cls, v: str) -> str:
        v = v.strip("\n\r ").replace("\r\n", "\n")
        if not v.strip():
            raise ValueError("empty message")
        return v


class ReactionIn(BaseModel):
    emoji: str = Field(max_length=16)


class SubscriptionIn(BaseModel):
    endpoint: str = Field(min_length=10, max_length=1000)
    keys: dict[str, str]


class GroupIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    members: list[int] = Field(default_factory=list, max_length=MAX_GROUP)

    @field_validator("name")
    @classmethod
    def clean_name(cls, v: str) -> str:
        v = " ".join(v.split())
        if not v:
            raise ValueError("empty name")
        return v


class GroupEditIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)

    @field_validator("name")
    @classmethod
    def clean_name(cls, v: str) -> str:
        v = " ".join(v.split())
        if not v:
            raise ValueError("empty name")
        return v


class MembersIn(BaseModel):
    user_ids: list[int] = Field(min_length=1, max_length=MAX_GROUP)


# ------------------------------------------------------------------ helpers
def _pair(a: int, b: int):
    return or_(and_(ChatMessage.sender_id == a, ChatMessage.recipient_id == b),
               and_(ChatMessage.sender_id == b, ChatMessage.recipient_id == a))


def _visible_to(me: int):
    """Not deleted for everyone, and not deleted "for me" by `me`."""
    return and_(ChatMessage.deleted_at.is_(None),
                not_(and_(ChatMessage.sender_id == me, ChatMessage.hidden_sender)),
                not_(and_(ChatMessage.recipient_id == me, ChatMessage.hidden_recipient)))


async def _reactions(s, ids: list[int]) -> dict[int, list[dict]]:
    out: dict[int, dict[str, list[int]]] = {}
    if ids:
        for r in (await s.execute(select(ChatReaction).where(ChatReaction.message_id.in_(ids))
                                  .order_by(ChatReaction.created_at))).scalars():
            out.setdefault(r.message_id, {}).setdefault(r.emoji, []).append(r.user_id)
    return {mid: [{"emoji": e, "users": u} for e, u in em.items()] for mid, em in out.items()}


def _file_view(f: ChatFile) -> dict:
    return {"key": f.key, "name": f.name, "mime": f.mime, "size": f.size}


async def _files(s, ids: list[int]) -> dict[int, list[dict]]:
    out: dict[int, list[dict]] = {}
    if ids:
        rows = (await s.execute(select(ChatFile.id, ChatFile.key, ChatFile.name, ChatFile.mime, ChatFile.size, ChatFile.message_id)
                                .where(ChatFile.message_id.in_(ids)).order_by(ChatFile.id))).all()
        for r in rows:
            out.setdefault(r.message_id, []).append({"key": r.key, "name": r.name, "mime": r.mime, "size": r.size})
    return out


def message_view(services: Services, m: ChatMessage, reactions: list[dict] | None = None, files: list[dict] | None = None) -> dict:
    return {"id": m.id, "from": m.sender_id, "to": m.recipient_id, "group": m.group_id, "body": services.cipher.open(m.body),
            "at": as_utc(m.created_at), "read_at": as_utc(m.read_at), "edited_at": as_utc(m.edited_at),
            "reactions": reactions or [], "files": files or []}


async def _views(s, services: Services, rows: list[ChatMessage]) -> list[dict]:
    ids = [m.id for m in rows]
    reacts, files = await _reactions(s, ids), await _files(s, ids)
    return [message_view(services, m, reacts.get(m.id), files.get(m.id)) for m in rows]


async def _peer(s, me: AgentMapping, user_id: int) -> AgentMapping:
    if user_id == me.id:
        raise HTTPException(400, tr("chat.self"))
    peer = await s.get(AgentMapping, user_id)
    if peer is None:
        raise HTTPException(404, tr("chat.no_user"))
    return peer


async def _membership(s, me: AgentMapping, group_id: int) -> tuple[ChatGroup, ChatGroupMember]:
    """The group and my place in it; a group I am not in looks exactly like one that does not exist."""
    member = (await s.execute(select(ChatGroupMember).where(
        ChatGroupMember.group_id == group_id, ChatGroupMember.user_id == me.id))).scalars().first()
    group = await s.get(ChatGroup, group_id) if member else None
    if member is None or group is None:
        raise HTTPException(404, tr("chat.no_group"))
    return group, member


async def _member_ids(s, group_id: int) -> list[int]:
    return list((await s.execute(select(ChatGroupMember.user_id).where(ChatGroupMember.group_id == group_id))).scalars())


async def _own_message(s, me: AgentMapping, message_id: int) -> ChatMessage:
    m = await s.get(ChatMessage, message_id)
    if m is None or m.deleted_at is not None:
        raise HTTPException(404, tr("chat.no_message"))
    if m.group_id is not None:
        if (await s.execute(select(ChatGroupMember.id).where(
                ChatGroupMember.group_id == m.group_id, ChatGroupMember.user_id == me.id))).first() is None:
            raise HTTPException(404, tr("chat.no_message"))
    elif me.id not in (m.sender_id, m.recipient_id):
        raise HTTPException(404, tr("chat.no_message"))
    return m


async def _audience(s, m: ChatMessage) -> set[int]:
    if m.group_id is not None:
        return set(await _member_ids(s, m.group_id))
    return {m.sender_id, m.recipient_id}


def _presence(services: Services, m: AgentMapping, st: AgentState | None) -> dict:
    online = services.broker.connections(m.id) > 0
    idle = bool(st and st.idle_since)
    last = as_utc(st.last_activity_at) if st and st.last_activity_at else as_utc(m.last_login_at)
    return {"online": online and not idle, "away": online and idle, "last_seen": last,
            "state": st.computed_state if st else "offline"}


def _person(services: Services, m: AgentMapping, st: AgentState | None) -> dict:
    return {"id": m.id, "kind": "user", "name": m.display_name or m.username, "username": m.username, "position": m.position,
            "level": m.level, "role": m.role, "extension": m.extension, "active": m.active,
            "avatar_url": m.avatar_url, **_presence(services, m, st)}


def _publish(services: Services, people, event: str, data: dict) -> None:
    for uid in set(people):
        services.broker.publish_agent(uid, event, data)


def _clean_name(name: str) -> str:
    """A file name without folders or control characters (it is only ever shown and offered as the download name)."""
    name = name.replace("\\", "/").rsplit("/", 1)[-1]
    name = "".join(ch for ch in name if ch.isprintable() and ch not in '<>:"|?*').strip(" .")
    return (name or "file")[:200]


def _clean_mime(mime: str) -> str:
    mime = (mime or "").strip().lower()
    return mime if re.fullmatch(r"[a-z0-9][\w.+-]*/[\w.+-]+", mime) else "application/octet-stream"


def _decode_files(files: list[FileIn]) -> list[tuple[str, str, bytes]]:
    out, total = [], 0
    for f in files:
        name = _clean_name(f.name)
        try:
            data = base64.b64decode(f.data.split(",", 1)[-1] if f.data.startswith("data:") else f.data, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, tr("chat.bad_file", name=name)) from exc
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(413, tr("chat.file_big", name=name, mb=MAX_FILE_MB))
        total += len(data)
        if total > MAX_FILES_MB * 1024 * 1024:
            raise HTTPException(413, tr("chat.files_big", mb=MAX_FILES_MB))
        out.append((name, _clean_mime(f.mime), data))
    return out


def _typing_allowed(sender: int, target: str) -> bool:
    """Throttle: one «typing…» per sender and conversation every TYPING_EVERY seconds (more are dropped quietly)."""
    now = time.monotonic()
    key = (sender, target)
    if now - _typing_sent.get(key, -1e9) < TYPING_EVERY:
        return False
    _typing_sent[key] = now
    if len(_typing_sent) > 5000:  # forget old entries
        for k in [k for k, v in _typing_sent.items() if now - v > 60]:
            _typing_sent.pop(k, None)
    return True


async def _store(s, services: Services, me: AgentMapping, body: MessageIn, *, recipient_id: int | None = None,
                 group_id: int | None = None) -> tuple[ChatMessage, list[dict]]:
    files = _decode_files(body.files)
    if not body.body.strip() and not files:
        raise HTTPException(422, tr("chat.empty"))
    msg = ChatMessage(sender_id=me.id, recipient_id=recipient_id, group_id=group_id,
                      body=services.cipher.seal(body.body), created_at=utcnow())
    s.add(msg)
    await s.flush()
    rows = [ChatFile(key=secrets.token_urlsafe(24), message_id=msg.id, name=name, mime=mime, size=len(data),
                     data=services.cipher.seal_bytes(data), created_at=utcnow()) for name, mime, data in files]
    s.add_all(rows)
    await s.commit()
    return msg, [_file_view(f) for f in rows]


def _preview(services: Services, body: str, files: list[dict]) -> str:
    if body:
        return body[:180]
    return "📎 " + ", ".join(f["name"] for f in files)[:170]


# ------------------------------------------------------------------ contacts & conversations
@router.get("/contacts", summary="Chats (people and groups), newest first; with q: search all colleagues and my groups")
async def contacts(q: str = "", me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        people = (await s.execute(select(AgentMapping).where(AgentMapping.id != me.id))).scalars().all()
        names = {m.id: m.display_name or m.username for m in people} | {me.id: me.display_name or me.username}
        states = {st.agent_id: st for st in (await s.execute(select(AgentState))).scalars().all()}
        peer = func.coalesce(func.nullif(ChatMessage.sender_id, me.id), ChatMessage.recipient_id).label("peer")
        last_ids = (await s.execute(select(peer, func.max(ChatMessage.id)).where(
            ChatMessage.group_id.is_(None), or_(ChatMessage.sender_id == me.id, ChatMessage.recipient_id == me.id),
            _visible_to(me.id)).group_by(peer))).all()
        lasts = {}
        if last_ids:
            rows = (await s.execute(select(ChatMessage).where(ChatMessage.id.in_([i for _, i in last_ids])))).scalars().all()
            lasts = {(r.recipient_id if r.sender_id == me.id else r.sender_id): r for r in rows}
        unread = dict((await s.execute(select(ChatMessage.sender_id, func.count()).where(
            ChatMessage.group_id.is_(None), ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None), _visible_to(me.id))
            .group_by(ChatMessage.sender_id))).all())
        # v3.20: my groups with their newest message and how many I have not read
        mine = (await s.execute(select(ChatGroup, ChatGroupMember).join(ChatGroupMember, ChatGroupMember.group_id == ChatGroup.id)
                                .where(ChatGroupMember.user_id == me.id))).all()
        gids = [g.id for g, _ in mine]
        counts = dict((await s.execute(select(ChatGroupMember.group_id, func.count()).where(
            ChatGroupMember.group_id.in_(gids)).group_by(ChatGroupMember.group_id))).all()) if gids else {}
        glast_ids = dict((await s.execute(select(ChatMessage.group_id, func.max(ChatMessage.id)).where(
            ChatMessage.group_id.in_(gids), _visible_to(me.id)).group_by(ChatMessage.group_id))).all()) if gids else {}
        glasts = {r.group_id: r for r in (await s.execute(select(ChatMessage).where(
            ChatMessage.id.in_(list(glast_ids.values()))))).scalars().all()} if glast_ids else {}
        gunread = {}
        for g, mem in mine:
            gunread[g.id] = (await s.execute(select(func.count()).where(
                ChatMessage.group_id == g.id, ChatMessage.id > (mem.last_read_id or 0), ChatMessage.sender_id != me.id,
                ChatMessage.deleted_at.is_(None)))).scalar_one()
        file_ids = [m.id for m in list(lasts.values()) + list(glasts.values())]
        files = await _files(s, file_ids)
    ql = q.strip().lower()
    out = []
    for m in people:
        last = lasts.get(m.id)
        if ql:
            if not m.active and not last:
                continue
            if not any(ql in (x or "").lower() for x in (m.display_name, m.username, m.position, m.extension)):
                continue
        elif not last:
            continue  # the list shows only conversations; search finds everybody else
        out.append({**_person(services, m, states.get(m.id)),
                    "last": message_view(services, last, files=files.get(last.id)) if last else None, "unread": unread.get(m.id, 0)})
    for g, mem in mine:
        if ql and ql not in g.name.lower():
            continue
        last = glasts.get(g.id)
        view = message_view(services, last, files=files.get(last.id)) if last else None
        if view:
            view["sender_name"] = names.get(last.sender_id, "")
        out.append({"id": g.id, "kind": "group", "name": g.name, "members": counts.get(g.id, 0), "role": mem.role,
                    "last": view, "unread": gunread.get(g.id, 0), "created_at": as_utc(g.created_at)})
    def order(c):
        newest = c["last"]["id"] if c["last"] else 0
        return (c["last"] is None and c.get("kind") != "group", -newest, c["name"].lower())
    out.sort(key=order)
    return {"contacts": out, "unread_total": sum(unread.values()) + sum(gunread.values())}


async def _group_unread(s, me_id: int) -> int:
    total = 0
    for mem in (await s.execute(select(ChatGroupMember).where(ChatGroupMember.user_id == me_id))).scalars():
        total += (await s.execute(select(func.count()).where(
            ChatMessage.group_id == mem.group_id, ChatMessage.id > (mem.last_read_id or 0), ChatMessage.sender_id != me_id,
            ChatMessage.deleted_at.is_(None)))).scalar_one()
    return total


@router.get("/unread", summary="Number of unread messages (badge in the menu)")
async def unread(me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        n = (await s.execute(select(func.count()).where(
            ChatMessage.group_id.is_(None), ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None),
            _visible_to(me.id)))).scalar_one()
        n += await _group_unread(s, me.id)
    return {"unread": n}


# ------------------------------------------------------------------ files (v3.20)
@router.get("/files/{key}", summary="A file of a chat message (only for the people of that conversation)")
async def chat_file(key: str, download: bool = False, me: AgentMapping = Depends(current_agent),
                    services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        f = (await s.execute(select(ChatFile).where(ChatFile.key == key))).scalars().first()
        if f is None:
            raise HTTPException(404, tr("chat.no_message"))
        m = await _own_message(s, me, f.message_id)  # the same rule as reading the message: a stranger gets 404
        if m.group_id is None and ((m.sender_id == me.id and m.hidden_sender) or (m.recipient_id == me.id and m.hidden_recipient)):
            raise HTTPException(404, tr("chat.no_message"))
        data = services.cipher.open_bytes(f.data)
    inline = not download and bool(INLINE.match(f.mime))
    disp = ("inline" if inline else "attachment") + f"; filename*=UTF-8''{quote(f.name)}"
    return Response(data, media_type=f.mime if inline else "application/octet-stream",
                    headers={"Content-Disposition": disp, "Cache-Control": "private, no-store",
                             "Content-Security-Policy": "sandbox; default-src 'none'"})  # nosniff comes from the security headers


# ------------------------------------------------------------------ groups (v3.20)
async def _group_view(s, services: Services, g: ChatGroup, me_id: int) -> dict:
    rows = (await s.execute(select(ChatGroupMember, AgentMapping).join(AgentMapping, AgentMapping.id == ChatGroupMember.user_id)
                            .where(ChatGroupMember.group_id == g.id).order_by(ChatGroupMember.joined_at, ChatGroupMember.id))).all()
    states = {st.agent_id: st for st in (await s.execute(select(AgentState).where(
        AgentState.agent_id.in_([a.id for _, a in rows])))).scalars().all()} if rows else {}
    members = [{**_person(services, a, states.get(a.id)), "group_role": mem.role} for mem, a in rows]
    total = (await s.execute(select(func.count()).where(ChatMessage.group_id == g.id, ChatMessage.deleted_at.is_(None)))).scalar_one()
    me_role = next((mem.role for mem, a in rows if a.id == me_id), None)
    return {"id": g.id, "kind": "group", "name": g.name, "created_by": g.created_by, "created_at": as_utc(g.created_at),
            "members": members, "role": me_role, "messages_total": total}


async def _active_people(s, me: AgentMapping, ids: list[int]) -> list[AgentMapping]:
    ids = [i for i in dict.fromkeys(ids) if i != me.id]
    if not ids:
        return []
    people = (await s.execute(select(AgentMapping).where(AgentMapping.id.in_(ids), AgentMapping.active.is_(True)))).scalars().all()
    if len(people) != len(ids):
        raise HTTPException(404, tr("chat.no_user"))
    return people


@router.post("/groups", summary="Create a group conversation (you become its owner)")
async def create_group(body: GroupIn, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        people = await _active_people(s, me, body.members)
        if not people:
            raise HTTPException(422, tr("chat.group_members"))
        if len(people) + 1 > MAX_GROUP:
            raise HTTPException(422, tr("chat.group_too_big", n=MAX_GROUP))
        g = ChatGroup(name=body.name, created_by=me.id, created_at=utcnow())
        s.add(g)
        await s.flush()
        s.add(ChatGroupMember(group_id=g.id, user_id=me.id, role="owner", joined_at=utcnow()))
        s.add_all([ChatGroupMember(group_id=g.id, user_id=p.id, role="member", joined_at=utcnow()) for p in people])
        await s.commit()
        view = await _group_view(s, services, g, me.id)
    _publish(services, [me.id] + [p.id for p in people], "chat_group", {"group": g.id, "change": "created", "by": me.id})
    return view


@router.get("/groups/{group_id}", summary="A group: name and members (only for its members)")
async def group_info(group_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        g, _ = await _membership(s, me, group_id)
        return await _group_view(s, services, g, me.id)


@router.patch("/groups/{group_id}", summary="Rename a group (its owner)")
async def rename_group(group_id: int, body: GroupEditIn, me: AgentMapping = Depends(current_agent),
                       services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        g, mem = await _membership(s, me, group_id)
        if mem.role != "owner":
            raise HTTPException(403, tr("chat.not_owner"))
        g.name = body.name
        await s.commit()
        view = await _group_view(s, services, g, me.id)
        people = await _member_ids(s, g.id)
    _publish(services, people, "chat_group", {"group": g.id, "change": "renamed", "by": me.id})
    return view


@router.post("/groups/{group_id}/members", summary="Add colleagues to a group (its owner)")
async def add_members(group_id: int, body: MembersIn, me: AgentMapping = Depends(current_agent),
                      services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        g, mem = await _membership(s, me, group_id)
        if mem.role != "owner":
            raise HTTPException(403, tr("chat.not_owner"))
        people = await _active_people(s, me, body.user_ids)
        have = set(await _member_ids(s, g.id))
        new = [p for p in people if p.id not in have]
        if len(have) + len(new) > MAX_GROUP:
            raise HTTPException(422, tr("chat.group_too_big", n=MAX_GROUP))
        top = (await s.execute(select(func.max(ChatMessage.id)).where(ChatMessage.group_id == g.id))).scalar() or 0
        # a newcomer sees the history, but the old messages do not count as unread for him
        s.add_all([ChatGroupMember(group_id=g.id, user_id=p.id, role="member", joined_at=utcnow(), last_read_id=top) for p in new])
        await s.commit()
        view = await _group_view(s, services, g, me.id)
    _publish(services, have | {p.id for p in new}, "chat_group", {"group": g.id, "change": "members", "by": me.id})
    return view


@router.delete("/groups/{group_id}/members/{user_id}", summary="Remove a member (the owner), or leave the group (yourself)")
async def remove_member(group_id: int, user_id: int, me: AgentMapping = Depends(current_agent),
                        services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        g, mem = await _membership(s, me, group_id)
        if user_id != me.id and mem.role != "owner":
            raise HTTPException(403, tr("chat.not_owner"))
        target = (await s.execute(select(ChatGroupMember).where(
            ChatGroupMember.group_id == g.id, ChatGroupMember.user_id == user_id))).scalars().first()
        if target is None:
            raise HTTPException(404, tr("chat.no_user"))
        before = set(await _member_ids(s, g.id))
        await s.delete(target)
        await s.flush()
        if target.role == "owner":  # the owner left: the longest member takes over
            heir = (await s.execute(select(ChatGroupMember).where(ChatGroupMember.group_id == g.id)
                                    .order_by(ChatGroupMember.joined_at, ChatGroupMember.id))).scalars().first()
            if heir:
                heir.role = "owner"
        await s.commit()
    _publish(services, before, "chat_group", {"group": g.id, "change": "left" if user_id == me.id else "removed",
                                              "user": user_id, "by": me.id})
    return {"ok": True}


@router.get("/groups/{group_id}/messages", summary="Messages of a group (newest page; older with before_id)")
async def group_messages(group_id: int, before_id: int | None = None, limit: int = 60,
                         me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    limit = max(1, min(limit, 200))
    async with services.db.sessionmaker() as s:
        await _membership(s, me, group_id)
        q = select(ChatMessage).where(ChatMessage.group_id == group_id, _visible_to(me.id))
        if before_id:
            q = q.where(ChatMessage.id < before_id)
        rows = (await s.execute(q.order_by(ChatMessage.id.desc()).limit(limit + 1))).scalars().all()
        page = list(reversed(rows[:limit]))
        return {"messages": await _views(s, services, page), "has_more": len(rows) > limit}


@router.post("/groups/{group_id}/messages", summary="Write to a group (text and / or files)")
async def group_send(group_id: int, body: MessageIn, me: AgentMapping = Depends(current_agent),
                     services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        g, mem = await _membership(s, me, group_id)
        msg, files = await _store(s, services, me, body, group_id=g.id)
        mem.last_read_id = msg.id
        await s.commit()
        people = await _member_ids(s, g.id)
        view = message_view(services, msg, files=files)
    sender = {"id": me.id, "name": me.display_name or me.username}
    _publish(services, people, "chat", {"message": view, "sender": sender, "group": {"id": g.id, "name": g.name}})
    for uid in people:
        if uid != me.id and services.broker.connections(uid) == 0:
            services.push.notify_later(uid, {"type": "chat", "title": f"{sender['name']} · {g.name}",
                                             "body": _preview(services, body.body, files), "group": g.id, "id": msg.id})
    return view


@router.post("/groups/{group_id}/read", summary="Mark a group as read")
async def group_read(group_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        _, mem = await _membership(s, me, group_id)
        top = (await s.execute(select(func.max(ChatMessage.id)).where(ChatMessage.group_id == group_id))).scalar() or 0
        changed = top > (mem.last_read_id or 0)
        if changed:
            mem.last_read_id = top
            await s.commit()
    if changed:
        services.broker.publish_agent(me.id, "chat_group_read", {"group": group_id, "up_to": top})
    return {"read": top if changed else 0}


@router.post("/groups/{group_id}/typing", summary="“typing…” in a group (to its other members; not stored)")
async def group_typing(group_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        await _membership(s, me, group_id)
        people = await _member_ids(s, group_id)
    if _typing_allowed(me.id, f"g{group_id}"):
        _publish(services, [p for p in people if p != me.id], "chat_typing",
                 {"from": me.id, "name": me.display_name or me.username, "group": group_id})
    return {"ok": True}


# ------------------------------------------------------------------ direct conversations
@router.get("/{user_id}/messages", summary="Conversation with a colleague (newest page; older with before_id)")
async def messages(user_id: int, before_id: int | None = None, limit: int = 60,
                   me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    limit = max(1, min(limit, 200))
    async with services.db.sessionmaker() as s:
        await _peer(s, me, user_id)
        q = select(ChatMessage).where(_pair(me.id, user_id), _visible_to(me.id))
        if before_id:
            q = q.where(ChatMessage.id < before_id)
        rows = (await s.execute(q.order_by(ChatMessage.id.desc()).limit(limit + 1))).scalars().all()
        page = list(reversed(rows[:limit]))
        return {"messages": await _views(s, services, page), "has_more": len(rows) > limit}


@router.post("/{user_id}/messages", summary="Send a message (text and / or files)")
async def send(user_id: int, body: MessageIn, me: AgentMapping = Depends(current_agent),
               services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        peer = await _peer(s, me, user_id)
        if not peer.active:
            raise HTTPException(409, tr("chat.inactive"))
        msg, files = await _store(s, services, me, body, recipient_id=peer.id)
        view = message_view(services, msg, files=files)
    sender = {"id": me.id, "name": me.display_name or me.username}
    _publish(services, {me.id, peer.id}, "chat", {"message": view, "sender": sender})
    if services.broker.connections(peer.id) == 0:  # no Zenith Desk window open -> background notification
        services.push.notify_later(peer.id, {"type": "chat", "title": sender["name"], "body": _preview(services, body.body, files),
                                             "from": me.id, "id": msg.id})
    return view


@router.post("/{user_id}/read", summary="Mark the conversation as read (sends read receipts)")
async def mark_read(user_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    now = utcnow()
    async with services.db.sessionmaker() as s:
        await _peer(s, me, user_id)
        top = (await s.execute(select(func.max(ChatMessage.id)).where(
            ChatMessage.sender_id == user_id, ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None)))).scalar()
        if top is None:
            return {"read": 0}
        res = await s.execute(update(ChatMessage).where(
            ChatMessage.sender_id == user_id, ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None),
            ChatMessage.id <= top).values(read_at=now))
        await s.commit()
    data = {"reader": me.id, "peer": user_id, "up_to": top, "at": now}
    services.broker.publish_agent(user_id, "chat_read", data)
    services.broker.publish_agent(me.id, "chat_read", data)
    return {"read": res.rowcount}


@router.post("/{user_id}/typing", summary="“typing…” indicator for the colleague (not stored)")
async def typing(user_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    # v3.20: the same rules as writing — an existing, active colleague (not yourself); throttled
    async with services.db.sessionmaker() as s:
        peer = await _peer(s, me, user_id)
        if not peer.active:
            raise HTTPException(409, tr("chat.inactive"))
    if _typing_allowed(me.id, f"u{user_id}"):
        services.broker.publish_agent(user_id, "chat_typing", {"from": me.id, "name": me.display_name or me.username})
    return {"ok": True}


# ------------------------------------------------------------------ reactions, edit, delete (v3.1)
@router.post("/messages/{message_id}/react", summary="React with an emoji (same emoji again removes it)")
async def react(message_id: int, body: ReactionIn, me: AgentMapping = Depends(current_agent),
                services: Services = Depends(get_services)):
    if body.emoji not in REACTIONS:
        raise HTTPException(422, tr("chat.bad_reaction"))
    async with services.db.sessionmaker() as s:
        m = await _own_message(s, me, message_id)
        mine = (await s.execute(select(ChatReaction).where(
            ChatReaction.message_id == m.id, ChatReaction.user_id == me.id))).scalars().first()
        if mine and mine.emoji == body.emoji:
            await s.delete(mine)
        elif mine:
            mine.emoji, mine.created_at = body.emoji, utcnow()
        else:
            s.add(ChatReaction(message_id=m.id, user_id=me.id, emoji=body.emoji, created_at=utcnow()))
        await s.commit()
        view = (await _views(s, services, [m]))[0]
        people = await _audience(s, m)
    _publish(services, people, "chat_update", {"message": view})
    return view


@router.patch("/messages/{message_id}", summary="Edit your own message (within 48 hours)")
async def edit(message_id: int, body: EditIn, me: AgentMapping = Depends(current_agent),
               services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        m = await _own_message(s, me, message_id)
        if m.sender_id != me.id:
            raise HTTPException(403, tr("chat.not_yours"))
        if utcnow() - as_utc(m.created_at) > EDIT_WINDOW:
            raise HTTPException(409, tr("chat.too_old"))
        if services.cipher.open(m.body) != body.body:
            m.body, m.edited_at = services.cipher.seal(body.body), utcnow()
            await s.commit()
        view = (await _views(s, services, [m]))[0]
        people = await _audience(s, m)
    _publish(services, people, "chat_update", {"message": view})
    return view


@router.delete("/messages/{message_id}", summary="Delete a message: for me, or for everyone (own messages)")
async def remove(message_id: int, scope: str = "me", me: AgentMapping = Depends(current_agent),
                 services: Services = Depends(get_services)):
    if scope not in ("me", "all"):
        raise HTTPException(422, "scope must be 'me' or 'all'")
    async with services.db.sessionmaker() as s:
        m = await _own_message(s, me, message_id)
        if m.group_id is not None and (scope != "all" or m.sender_id != me.id):
            raise HTTPException(403, tr("chat.group_hide"))
        if scope == "all":
            if m.sender_id != me.id:
                raise HTTPException(403, tr("chat.not_yours"))
            m.deleted_at, m.body = utcnow(), services.cipher.seal("")  # the text is gone from the database too
            await s.execute(delete(ChatReaction).where(ChatReaction.message_id == m.id))
            await s.execute(delete(ChatFile).where(ChatFile.message_id == m.id))  # v3.20: and its files
        elif m.sender_id == me.id:
            m.hidden_sender = True
        else:
            m.hidden_recipient = True
            if m.read_at is None:
                m.read_at = utcnow()  # a hidden message is not "unread" any more
        await s.commit()
        people = await _audience(s, m)
    data = {"deleted": message_id, "peer": m.recipient_id if m.sender_id == me.id else m.sender_id, "group": m.group_id,
            "by": me.id, "scope": scope}
    if scope == "all":
        _publish(services, people, "chat_update", data)
    else:
        services.broker.publish_agent(me.id, "chat_update", data)  # only my other tabs
    return {"ok": True}


@router.get("/{user_id}/profile", summary="Colleague's card: position, level, extension, state, shared history")
async def profile(user_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        peer = await _peer(s, me, user_id)
        st = await s.get(AgentState, peer.id)
        total, first = (await s.execute(select(func.count(), func.min(ChatMessage.created_at)).where(
            _pair(me.id, peer.id), _visible_to(me.id)))).one()
        week = (await s.execute(select(func.count()).where(
            _pair(me.id, peer.id), _visible_to(me.id), ChatMessage.created_at >= utcnow() - timedelta(days=7)))).scalar_one()
    return {**_person(services, peer, st), "state_label": state_label(st.computed_state) if st else state_label("offline"),
            "reason": (tr("reason.idle") if st and st.idle_since else st.reason) if st else "",
            "member_since": as_utc(peer.created_at), "messages_total": total, "messages_week": week,
            "first_message_at": as_utc(first)}


# ------------------------------------------------------------------ Web Push subscriptions (v3.1)
@push_router.get("/key", summary="Public VAPID key for subscribing this browser")
async def push_key(me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return {"key": await services.push.public_key()}


@push_router.post("/subscribe", summary="Receive notifications in this browser even when Zenith Desk is closed")
async def subscribe(body: SubscriptionIn, request: Request, me: AgentMapping = Depends(current_agent),
                    services: Services = Depends(get_services)):
    if not body.endpoint.startswith("https://") or not body.keys.get("p256dh") or not body.keys.get("auth"):
        raise HTTPException(422, "invalid subscription")
    async with services.db.sessionmaker() as s:
        row = (await s.execute(select(PushSubscription).where(PushSubscription.endpoint == body.endpoint))).scalars().first()
        if row is None:
            row = PushSubscription(endpoint=body.endpoint, created_at=utcnow())
            s.add(row)
        row.agent_id, row.p256dh, row.auth = me.id, body.keys["p256dh"], body.keys["auth"]
        row.user_agent = (request.headers.get("user-agent") or "")[:300]
        await s.commit()
    return {"ok": True}


@push_router.post("/unsubscribe", summary="Stop background notifications in this browser")
async def unsubscribe(body: SubscriptionIn, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        await s.execute(delete(PushSubscription).where(PushSubscription.endpoint == body.endpoint,
                                                       PushSubscription.agent_id == me.id))
        await s.commit()
    return {"ok": True}


@push_router.get("/status", summary="How many browsers of mine receive background notifications")
async def push_status(me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        n = (await s.execute(select(func.count()).where(PushSubscription.agent_id == me.id))).scalar_one()
    return {"subscriptions": n}
