"""Operator dashboard: today's numbers and the notification center (FR-09)."""
from datetime import datetime, time, timezone
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import or_, select

from ..auth import ROLE_LEVEL, current_agent, get_services, require_role
from ..db import as_utc, utcnow
from ..i18n import t as tr
from ..models import AgentMapping, AuditLog, CallRecord, PauseInterval, WorkSession
from ..services import Services
from ..workflow import Actor
from ..zammad import ZammadError

router = APIRouter(prefix="/api", tags=["dashboard"])

NOTIFY_ACTIONS = ("sync_error", "sync_restored", "work_cancelled", "ticket_reassigned", "supervisor_override",
                  "mode_changed", "work_completed", "password_reset", "backup_failed", "backup_restored",
                  "shift_late", "shift_absent", "shift_early_leave", "team_alert", "login_locked")
SHIFT_ACTIONS = ("shift_late", "shift_absent", "shift_early_leave")  # v3.15: every manager is told
MANAGER_ACTIONS = (*SHIFT_ACTIONS, "team_alert")  # v3.18: team alerts too
ADMIN_ACTIONS = ("backup_failed", "backup_restored", "login_locked")  # v3.10: seen by every administrator (v3.21: locks)


def _zone(name: str):
    try:
        return ZoneInfo(name)
    except Exception:  # noqa: BLE001
        return timezone.utc


def day_start(tz_name: str) -> datetime:
    try:
        tz = ZoneInfo(tz_name)
    except Exception:  # noqa: BLE001
        tz = timezone.utc
    local_midnight = datetime.combine(datetime.now(tz).date(), time.min, tzinfo=tz)
    return local_midnight.astimezone(timezone.utc)


@router.get("/agents/me/dashboard", summary="Today's numbers for the operator dashboard")
async def dashboard(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    start, now = day_start(services.settings.display_timezone), utcnow()

    def overlap(a, b) -> float:
        a, b = as_utc(a), as_utc(b) or now
        return max(0.0, (min(b, now) - max(a, start)).total_seconds())

    async with services.db.sessionmaker() as s:
        sessions = (await s.execute(select(WorkSession).where(
            WorkSession.agent_id == agent.id,
            or_(WorkSession.ended_at.is_(None), WorkSession.ended_at >= start)))).scalars().all()
        calls = (await s.execute(select(CallRecord).where(
            CallRecord.agent_id == agent.id, CallRecord.started_at >= start))).scalars().all()
        pauses = (await s.execute(select(PauseInterval).where(
            PauseInterval.agent_id == agent.id,
            or_(PauseInterval.ended_at.is_(None), PauseInterval.ended_at >= start)))).scalars().all()
    return {
        "completed_today": sum(1 for w in sessions if w.state == "completed" and w.ended_at and as_utc(w.ended_at) >= start),
        "started_today": sum(1 for w in sessions if as_utc(w.started_at) >= start),
        "calls_today": len(calls),
        "calls_answered": sum(1 for c in calls if c.answered_at),
        "calls_missed": sum(1 for c in calls if c.state == "missed"),
        "busy_sec_today": int(sum(overlap(p.started_at, p.ended_at) for p in pauses if p.reason == "busy_task")),
        "paused_sec_today": int(sum(overlap(p.started_at, p.ended_at) for p in pauses)),
    }


def _text(row: AuditLog, numbers: dict[int, str], names: dict[int, str], me: int, sup: bool = False,
          tz=timezone.utc) -> tuple[str, str, str] | None:
    d = row.details or {}
    ticket = f"#{numbers.get(row.ticket_id) or d.get('number') or row.ticket_id}" if row.ticket_id else ""
    who = names.get(row.agent_id, "")
    if row.action == "sync_error":
        prefix = "" if row.agent_id == me else f"{who}: "
        return "sync", "error", prefix + tr("ntf.sync_error", error=d.get("error", ""))
    if row.action == "sync_restored":
        return ("sync", "info", tr("ntf.sync_restored")) if row.agent_id == me else None
    if row.action == "work_cancelled":
        if d.get("reason") == "reassigned" or row.actor_type == "zammad":
            return "ticket", "warning", tr("ntf.reassigned_away", ticket=ticket)
        if row.actor_type == "supervisor":
            return "ticket", "warning", tr("ntf.cancelled_by_supervisor", ticket=ticket, reason=str(d.get("reason", "")).replace("supervisor: ", ""))
        return None
    if row.action == "ticket_reassigned":
        if d.get("by") and row.actor_type == "agent":
            return "ticket", "info", tr("ntf.assigned_by", who=d["by"], ticket=ticket)
        return "ticket", "info", tr("ntf.assigned_to_you", ticket=ticket)
    if row.action == "supervisor_override":
        return "override", "warning", tr("ntf.override", state=d.get("new", ""), reason=d.get("reason", ""))
    if row.action == "mode_changed" and row.actor_type == "zammad":
        return "ticket", "info", tr("ntf.to_background", ticket=ticket, state=d.get("zammad_state", ""))
    if row.action == "work_completed" and row.actor_type == "zammad":
        return "ticket", "info", tr("ntf.closed_in_zammad", ticket=ticket, state=d.get("zammad_state", ""))
    if row.action == "backup_failed":
        return "backup", "error", tr("ntf.backup_failed", error=d.get("error", ""))
    if row.action == "backup_restored":
        return "backup", "warning", tr("ntf.backup_restored", name=d.get("name", ""), by=d.get("by", ""))
    if row.action in SHIFT_ACTIONS:
        if not sup:  # managers are told, not the operator himself
            return None

        def hm(v):
            try:
                return datetime.fromisoformat(v).astimezone(tz).strftime("%H:%M")
            except (TypeError, ValueError):
                return "?"
        name = d.get("name") or who
        if row.action == "shift_late":
            key = "ntf.shift_late" if d.get("arrived") else "ntf.shift_late_missing"
            return "shift", "warning", tr(key, name=name, start=hm(d.get("starts_at")), minutes=d.get("minutes", 0))
        if row.action == "shift_absent":
            return "shift", "error", tr("ntf.shift_absent", name=name, start=f'{hm(d.get("starts_at"))}–{hm(d.get("ends_at"))}')
        return "shift", "warning", tr("ntf.shift_early_leave", name=name, minutes=d.get("minutes", 0), end=hm(d.get("ends_at")))
    if row.action == "team_alert":  # v3.18: for the managers only
        if not sup:
            return None
        from ..team import alert_text  # noqa: PLC0415
        return "team", "error" if d.get("kind") in ("missed", "queue") else "warning", alert_text(d)
    if row.action == "login_locked":  # v3.21: every administrator, and the user himself once he is back in
        return "account", "error", tr("ntf.login_locked", name=names.get(row.agent_id) or d.get("username", ""), n=5, ip=d.get("ip", "?"))
    if row.action == "password_reset":
        return "account", "info", tr("ntf.password_reset")
    return None


@router.get("/agents/me/notifications", summary="Notification center: sync problems, reassignments, overrides, missed calls")
async def notifications(limit: int = 30, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    limit = max(1, min(limit, 100))
    supervisor = ROLE_LEVEL.get(agent.role, 0) >= ROLE_LEVEL["supervisor"]
    async with services.db.sessionmaker() as s:
        cond = AuditLog.agent_id == agent.id
        if supervisor:  # supervisors also see telephony problems of every operator
            cond = or_(cond, AuditLog.action == "sync_error", AuditLog.action.in_(MANAGER_ACTIONS))
        if agent.role == "admin":
            cond = or_(cond, AuditLog.action.in_(ADMIN_ACTIONS))
        rows = (await s.execute(select(AuditLog).where(cond, AuditLog.action.in_(NOTIFY_ACTIONS))
                                .order_by(AuditLog.id.desc()).limit(limit * 2))).scalars().all()
        missed = (await s.execute(select(CallRecord).where(CallRecord.agent_id == agent.id, CallRecord.state == "missed")
                                  .order_by(CallRecord.started_at.desc()).limit(limit))).scalars().all()
        ticket_ids = {r.ticket_id for r in rows if r.ticket_id}
        numbers = {}
        if ticket_ids:
            for w in (await s.execute(select(WorkSession).where(WorkSession.ticket_id.in_(ticket_ids)))).scalars().all():
                numbers[w.ticket_id] = w.ticket_number or str(w.ticket_id)
        names = {m.id: m.display_name for m in (await s.execute(select(AgentMapping))).scalars().all()}
    items = []
    for r in rows:
        res = _text(r, numbers, names, agent.id, supervisor, _zone(services.settings.display_timezone))
        if res:
            kind, level, text = res
            items.append({"id": f"a{r.id}", "ts": as_utc(r.ts), "kind": kind, "level": level, "text": text, "ticket_id": r.ticket_id})
    for c in missed:
        items.append({"id": f"c{c.id}", "ts": as_utc(c.ended_at or c.started_at), "kind": "call", "level": "warning",
                      "text": tr("ntf.missed_call", number=c.caller_number or "?"), "ticket_id": None})
    items.sort(key=lambda x: x["ts"], reverse=True)
    items = items[:limit]
    seen = as_utc(agent.notifications_seen_at)
    unread = sum(1 for i in items if seen is None or i["ts"] > seen)
    return {"items": items, "unread": unread, "seen_at": seen}


@router.post("/agents/me/notifications/seen", summary="Mark notifications as read")
async def notifications_seen(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        m = await s.get(AgentMapping, agent.id)
        m.notifications_seen_at = utcnow()
        await s.commit()
    return {"unread": 0}


# ------------------------------------------------------------------ supervisor: assign by ticket number
class AssignByNumberIn(BaseModel):
    ticket: str = Field(min_length=1, max_length=40)  # ticket number as operators see it (or internal id)
    agent_id: int
    work_mode: str | None = Field(default=None, pattern="^(blocking|background)$")


@router.post("/admin/assign", summary="Assign / reassign a ticket by its number (supervisor)")
async def assign_by_number(body: AssignByNumberIn, user: AgentMapping = Depends(require_role("supervisor")),
                           services: Services = Depends(get_services)):
    ref = body.ticket.strip().lstrip("#")
    try:
        found = await services.zammad.search_tickets({"ticket.number": {"operator": "is", "value": [ref]}}, limit=1)
    except ZammadError as exc:
        raise HTTPException(502, str(exc)) from exc
    ticket_id = found[0]["id"] if found else (int(ref) if ref.isdigit() else None)
    if ticket_id is None:
        raise HTTPException(404, tr("err.ticket_not_found"))
    async with services.db.sessionmaker() as s:
        target = await s.get(AgentMapping, body.agent_id)
    if target is None or not target.active:
        raise HTTPException(404, tr("err.agent_not_found"))
    if not target.zammad_user_id:
        raise HTTPException(409, tr("err.target_not_linked", name=target.display_name))
    return await services.workflow.supervisor_assign(ticket_id, target, body.work_mode, Actor("supervisor", user.id))
