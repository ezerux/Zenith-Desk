"""v3.9 E-mail API: the employee signs in with e-mail + password; the server is set by the administrator."""
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

from ..auth import current_agent, get_services
from ..mail.service import MailUserError, folder_from_url
from ..models import AgentMapping
from ..services import Services
from ..zammad import ZammadError

router = APIRouter(prefix="/api/mail", tags=["mail"])


def _err(exc: MailUserError) -> HTTPException:
    return HTTPException(exc.status, str(exc))


async def _call(coro):
    try:
        return await coro
    except MailUserError as exc:
        raise _err(exc) from exc


@router.get("/account", summary="Is mail set up (server by the administrator, mailbox by the employee)")
async def account(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.mail.account(agent)


class ConnectIn(BaseModel):
    email: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1, max_length=500)


@router.post("/account", summary="Sign in to the own mailbox (checked on the mail server before saving)")
async def connect(body: ConnectIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await _call(services.mail.connect(agent, body.email, body.password))


@router.delete("/account", summary="Sign out of the mailbox (the password is deleted)")
async def disconnect(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.mail.disconnect(agent)


@router.get("/folders", summary="Folders with unread counts")
async def folders(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return {"folders": await _call(services.mail.folders(agent))}


@router.get("/folders/{folder}/messages", summary="Messages of a folder (newest first), search")
async def messages(folder: str, page: int = 1, q: str = "", agent: AgentMapping = Depends(current_agent),
                   services: Services = Depends(get_services)):
    return await _call(services.mail.messages(agent, folder_from_url(folder), max(1, page), q))


@router.get("/messages/{folder}/{uid}", summary="Read a message (safe HTML, attachments, prepared reply / forward)")
async def read(folder: str, uid: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await _call(services.mail.read(agent, folder_from_url(folder), uid))


@router.get("/messages/{folder}/{uid}/attachments/{idx}", summary="Download an attachment")
async def attachment(folder: str, uid: int, idx: int, inline: bool = False, agent: AgentMapping = Depends(current_agent),
                     services: Services = Depends(get_services)):
    name, mime, data = await _call(services.mail.attachment(agent, folder_from_url(folder), uid, idx))
    show = inline and mime.split("/")[0] == "image" and mime != "image/svg+xml"
    return Response(data, media_type=mime if show else "application/octet-stream",
                    headers={"Content-Disposition": ("inline" if show else "attachment") + f"; filename*=UTF-8''{quote(name)}",
                             "X-Content-Type-Options": "nosniff", "Cache-Control": "private, no-store"})


class FlagsIn(BaseModel):
    folder: str
    uids: list[int] = Field(min_length=1, max_length=500)
    seen: bool | None = None
    flagged: bool | None = None


@router.post("/flags", summary="Mark read / unread, flag")
async def flags(body: FlagsIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await _call(services.mail.flags(agent, folder_from_url(body.folder), body.uids, body.seen, body.flagged))


class MoveIn(BaseModel):
    folder: str
    uids: list[int] = Field(min_length=1, max_length=500)
    target: str = ""


@router.post("/move", summary="Move to another folder")
async def move(body: MoveIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await _call(services.mail.move(agent, folder_from_url(body.folder), body.uids, folder_from_url(body.target)))


@router.post("/delete", summary="Delete (to Trash; from Trash — for good)")
async def delete(body: MoveIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await _call(services.mail.delete(agent, folder_from_url(body.folder), body.uids))


class FileIn(BaseModel):
    name: str = Field(max_length=200)
    mime: str = ""
    data: str  # base64


class ComposeIn(BaseModel):
    to: list[dict] | str = Field(default_factory=list)
    cc: list[dict] | str = Field(default_factory=list)
    bcc: list[dict] | str = Field(default_factory=list)
    subject: str = Field("", max_length=998)
    text: str = Field("", max_length=1_000_000)
    files: list[FileIn] = Field(default_factory=list, max_length=20)
    forward_files: list[dict] = Field(default_factory=list, max_length=20)  # {folder, uid, idx} of the original message
    in_reply_to: str = ""
    references: str = ""
    draft_uid: int | None = None


def _compose(body: ComposeIn) -> dict:
    d = body.model_dump()
    d["files"] = [f.model_dump() for f in body.files]
    d["forward_files"] = [{**f, "folder": folder_from_url(str(f.get("folder", "")))} for f in body.forward_files]
    return d


@router.post("/send", summary="Send (SMTP with the employee's login; a copy goes to Sent)")
async def send(body: ComposeIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await _call(services.mail.send(agent, _compose(body)))


@router.post("/draft", summary="Save as a draft")
async def draft(body: ComposeIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await _call(services.mail.send(agent, _compose(body), draft=True))


@router.post("/messages/{folder}/{uid}/ticket", summary="Create a Zammad ticket from this e-mail")
async def ticket(folder: str, uid: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await _call(services.mail.ticket_from_mail(agent, folder_from_url(folder), uid))
    except HTTPException:
        raise
    except ZammadError as exc:
        raise HTTPException(502, str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 — TicketError etc.
        raise HTTPException(getattr(exc, "status", 502), str(getattr(exc, "message", exc))) from exc
