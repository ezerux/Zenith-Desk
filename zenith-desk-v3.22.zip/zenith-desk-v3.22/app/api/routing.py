"""v3.11 — call routing by level: who is in which queue with which penalty, who is free right now, who gets the next call.

Asterisk rings the members with the LOWEST penalty first and a higher penalty only when every member with a lower
penalty is busy (on a call — ringinuse=no — paused or unavailable). Zenith Desk sets the penalty from the user's level
(Level 1 = 0, Level 2 = 1, Level 3 = 2 by default) and pauses everybody busy with a blocking ticket, so a call goes
Level 1 → the next free Level 1 → … → Level 2 → … → Level 3.
"""
from fastapi import APIRouter, Depends
from sqlalchemy import select

from ..auth import get_services, require_role
from ..i18n import t as tr
from ..models import AgentMapping, AgentState
from ..services import Services

router = APIRouter(prefix="/api/admin", tags=["call routing"])
supervisor = require_role("supervisor")
ONE_BY_ONE = {"rrmemory", "rrordered", "leastrecent", "fewestcalls", "linear", "random", "wrandom"}
BUSY = {"2", "3", "6", "7", "8"}  # in use, busy, ringing, ring+in use, on hold
OFF = {"0", "4", "5"}  # unknown, invalid, unavailable


def member_state(m) -> str:
    if m.paused:
        return "paused"
    if m.in_call or m.status in BUSY:
        return "busy"
    if m.status in OFF:
        return "unavailable"
    return "free"


@router.get("/routing", summary="Call routing by level: members, penalties, who is free, who gets the next call")
async def routing(_: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    cfg = services.settings
    async with services.db.sessionmaker() as s:
        users = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True)))).scalars().all()
        states = {st.agent_id: st for st in (await s.execute(select(AgentState))).scalars().all()}
    by_iface = {u.asterisk_interface.strip().lower(): u for u in users if u.asterisk_interface}
    levels = {"level1": cfg.penalty_level1, "level2": cfg.penalty_level2, "level3": cfg.penalty_level3}
    out = {"enabled": cfg.level_routing, "penalties": {**levels, "manager": cfg.penalty_manager}, "queues": [],
           "connected": services.pbx.connected, "error": ""}
    if not cfg.queues:
        out["error"] = tr("rt.no_queues")
        return out
    try:
        infos = await services.pbx.queue_info(cfg.queues)
    except Exception as exc:  # noqa: BLE001
        out["error"] = str(exc) or tr("rt.not_connected")
        return out
    for info in infos:
        members, warnings = [], []
        seen = set()
        for m in info.members or []:
            u = by_iface.get((m.interface or "").strip().lower())
            if u is not None:
                seen.add(u.id)
            expected = services.engine.penalty_for(u, info.queue) if u is not None else None  # v3.18: overflow included
            st = states.get(u.id) if u is not None else None
            members.append({
                "interface": m.interface, "name": (u.display_name if u else m.name) or m.interface,
                "user_id": u.id if u else None, "level": u.level if u else None, "penalty": m.penalty, "expected_penalty": expected,
                "state": member_state(m), "paused_reason": m.paused_reason, "calls_taken": m.calls_taken,
                "zenith_state": st.computed_state if st else None, "extension": u.extension if u else "",
            })
            if u is None:
                warnings.append({"kind": "unknown_member", "text": tr("rt.unknown_member", member=m.name or m.interface)})
            elif expected is not None and m.penalty != expected:
                warnings.append({"kind": "penalty", "text": tr("rt.penalty_mismatch", name=u.display_name, have=m.penalty, want=expected)})
        for u in users:
            if u.id not in seen and u.asterisk_interface and u.enabled and u.level in levels:
                warnings.append({"kind": "missing", "text": tr("rt.not_member", name=u.display_name, queue=info.queue)})
        if cfg.level_routing and info.strategy and info.strategy.lower() not in ONE_BY_ONE:
            warnings.append({"kind": "strategy", "text": tr("rt.strategy", strategy=info.strategy)})
        free = [m for m in members if m["state"] == "free"]
        nxt = min((m["penalty"] for m in free), default=None)
        members.sort(key=lambda m: (m["penalty"], m["state"] != "free", m["name"].lower()))
        out["queues"].append({
            "queue": info.queue, "strategy": info.strategy, "waiting": info.calls, "completed": info.completed,
            "abandoned": info.abandoned, "members": members, "warnings": warnings,
            "next_penalty": nxt, "next_members": [m["name"] for m in free if m["penalty"] == nxt],
            "free_by_level": {lv: sum(1 for m in free if m["level"] == lv) for lv in levels},
        })
    return out
