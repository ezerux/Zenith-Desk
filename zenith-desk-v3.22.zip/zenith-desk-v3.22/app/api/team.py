"""v3.18 the team right now: queues, today's numbers, the call feed, one person's day (managers and administrators)."""
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query

from ..auth import get_services, require_role
from ..db import utcnow
from ..i18n import t as tr
from ..models import AgentMapping
from ..services import Services
from ..team import agent_day, team_live
from .overview import period_bounds

router = APIRouter(prefix="/api/admin/team", tags=["supervisor / admin"])
supervisor = require_role("supervisor")


@router.get("/live", summary="Queues now (waiting customers, free operators), today's numbers and the team's call feed")
async def live(feed: int = Query(50, ge=0, le=200), user: AgentMapping = Depends(supervisor),
               services: Services = Depends(get_services)):
    now = utcnow()
    start, _ = period_bounds("today", None, services.settings.display_timezone)
    async with services.db.sessionmaker() as s:
        return await team_live(s, services, start, now, feed)


@router.get("/agents/{agent_id}/day", summary="One employee's day: timeline of states and calls, numbers, his calls")
async def day(agent_id: int, day: date | None = None, user: AgentMapping = Depends(supervisor),
              services: Services = Depends(get_services)):
    now = utcnow()
    start, end = period_bounds("today", day, services.settings.display_timezone)
    if start > now:
        raise HTTPException(422, tr("team.future_day"))
    async with services.db.sessionmaker() as s:
        agent = await s.get(AgentMapping, agent_id)
        if agent is None:
            raise HTTPException(404, tr("err.not_found"))
        return await agent_day(s, services, agent, start, end, now)
