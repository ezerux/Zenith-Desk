"""v3.9 Telegram / WhatsApp chats: operator API and the webhooks of Telegram and Meta."""
import hmac
import json
import logging
from typing import Literal
from urllib.parse import quote

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import PlainTextResponse, Response
from pydantic import BaseModel, Field

from ..auth import current_agent, get_services
from ..messengers.service import MsgError
from ..messengers.whatsapp import verify_signature
from ..models import AgentMapping
from ..services import Services

router = APIRouter(prefix="/api/msg", tags=["messengers"])
hooks = APIRouter(prefix="/api/integrations", tags=["integrations"])
log = logging.getLogger("messengers")


def _err(exc: MsgError) -> HTTPException:
    return HTTPException(exc.status, str(exc))


@router.get("/conversations", summary="Chats of the company number (open / mine / unassigned / closed), search")
async def conversations(view: Literal["open", "mine", "unassigned", "closed"] = "open", channel: str = "", q: str = "",
                        agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.messengers.list(agent, view, channel, q)


@router.get("/counts", summary="Unread chats per messenger (side menu badges)")
async def counts(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.messengers.counts(agent)


@router.get("/conversations/{conv_id}", summary="One chat with its messages (older ones with ?before=)")
async def conversation(conv_id: int, before: int | None = None, agent: AgentMapping = Depends(current_agent),
                       services: Services = Depends(get_services)):
    try:
        return await services.messengers.detail(agent, conv_id, before)
    except MsgError as exc:
        raise _err(exc) from exc


class FileIn(BaseModel):
    name: str = Field(max_length=200)
    mime: str = ""
    data: str  # base64


class SendIn(BaseModel):
    text: str = Field("", max_length=4096)
    files: list[FileIn] = Field(default_factory=list, max_length=10)
    note: bool = False
    template: str = Field("", max_length=200)


@router.post("/conversations/{conv_id}/messages", summary="Answer the customer (or an internal note)")
async def send(conv_id: int, body: SendIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await services.messengers.send(agent, conv_id, body.text, [f.model_dump() for f in body.files], body.note, body.template)
    except MsgError as exc:
        raise _err(exc) from exc


@router.post("/messages/{msg_id}/resend", summary="Send a failed message again")
async def resend(msg_id: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await services.messengers.resend(agent, msg_id)
    except MsgError as exc:
        raise _err(exc) from exc


@router.post("/conversations/{conv_id}/read", summary="The chat was read")
async def read(conv_id: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    await services.messengers.mark_read(agent, conv_id)
    return {"ok": True}


class AssignIn(BaseModel):
    agent_id: int | None = None  # None = nobody (back to the team)


@router.post("/conversations/{conv_id}/assign", summary="Take the chat / pass it to a colleague / give it back")
async def assign(conv_id: int, body: AssignIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await services.messengers.assign(agent, conv_id, body.agent_id)
    except MsgError as exc:
        raise _err(exc) from exc


class StatusIn(BaseModel):
    status: Literal["open", "closed"]


@router.post("/conversations/{conv_id}/status", summary="Close / reopen the chat (closing also finishes its Zammad ticket)")
async def status(conv_id: int, body: StatusIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await services.messengers.set_status(agent, conv_id, body.status)
    except MsgError as exc:
        raise _err(exc) from exc


@router.get("/files/{key}", summary="A file of a chat message")
async def file(key: str, download: bool = False, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    f = await services.messengers.file(key)
    if f is None:
        raise HTTPException(404, "not found")
    inline = not download and f.mime.split("/")[0] in ("image", "audio", "video")
    disp = ("inline" if inline else "attachment") + f"; filename*=UTF-8''{quote(f.name)}"
    return Response(services.cipher.open_bytes(f.data), media_type=f.mime if inline else "application/octet-stream",
                    headers={"Content-Disposition": disp, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"})


@router.get("/agents", summary="Colleagues a chat can be passed to (with their live state)")
async def agents(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    from sqlalchemy import select  # noqa: PLC0415
    from ..models import AgentState  # noqa: PLC0415
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True), AgentMapping.role != "admin")
                                .order_by(AgentMapping.display_name))).scalars().all()
        states = {st.agent_id: st.computed_state for st in (await s.execute(select(AgentState))).scalars().all()}
    return {"agents": [{"id": m.id, "name": m.display_name or m.username, "position": m.position, "state": states.get(m.id, "offline"),
                        "me": m.id == agent.id} for m in rows]}


# ---------------------------------------------------------------- webhooks (Telegram, Meta)
@hooks.post("/telegram/webhook", summary="Telegram bot webhook (secret token header)")
async def telegram_webhook(request: Request, services: Services = Depends(get_services),
                           x_telegram_bot_api_secret_token: str | None = Header(None)):
    secret = services.settings.telegram_webhook_secret
    if not secret or not hmac.compare_digest(secret, x_telegram_bot_api_secret_token or ""):
        raise HTTPException(401, "bad secret")
    if not services.messengers.tg_ready():
        return {"ok": True, "ignored": "telegram disabled"}
    try:
        update = json.loads(await request.body() or b"{}")
    except ValueError as exc:
        raise HTTPException(400, "bad json") from exc
    await services.messengers.handle_telegram_update(update)
    return {"ok": True}


@hooks.get("/whatsapp/webhook", summary="Meta webhook verification (hub.challenge)")
async def whatsapp_verify(request: Request, services: Services = Depends(get_services)):
    p = request.query_params
    token = services.settings.whatsapp_verify_token
    if p.get("hub.mode") == "subscribe" and token and hmac.compare_digest(token, p.get("hub.verify_token") or ""):
        return PlainTextResponse(p.get("hub.challenge") or "")
    raise HTTPException(403, "verification failed")


@hooks.post("/whatsapp/webhook", summary="WhatsApp Cloud API webhook (X-Hub-Signature-256)")
async def whatsapp_webhook(request: Request, services: Services = Depends(get_services),
                           x_hub_signature_256: str | None = Header(None)):
    raw = await request.body()
    secret = services.settings.whatsapp_app_secret
    if not secret or not verify_signature(secret, raw, x_hub_signature_256 or ""):
        raise HTTPException(401, "bad signature")
    if not services.messengers.wa_ready():
        return {"ok": True, "ignored": "whatsapp disabled"}
    try:
        body = json.loads(raw or b"{}")
    except ValueError as exc:
        raise HTTPException(400, "bad json") from exc
    await services.messengers.handle_whatsapp(body)
    return {"ok": True}
