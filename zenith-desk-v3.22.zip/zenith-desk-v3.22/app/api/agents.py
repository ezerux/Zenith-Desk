from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select

from ..audit import audit
from ..auth import ROLE_LEVEL, current_agent, get_services
from ..db import utcnow
from ..i18n import t as tr
from ..models import AgentMapping, WorkSession
from ..services import Services
from ..views import session_view
from ..workflow import Actor, ticket_source
from ..zammad import ZammadError
from .common import run_idempotent

router = APIRouter(prefix="/api", tags=["operator"])


class ReasonIn(BaseModel):
    reason: str = ""


@router.get("/agents/me/state", summary="Computed operator state and reason")
async def my_state(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.engine.state_view(agent.id)


@router.get("/agents/me/tasks", summary="Operator's blocking and background tasks")
async def my_tasks(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(WorkSession).where(
            WorkSession.agent_id == agent.id, WorkSession.state == "active").order_by(WorkSession.started_at))).scalars().all()
    sessions = [session_view(r) for r in rows]
    return {
        "blocking": [x for x in sessions if x["work_mode"] == "blocking"],
        "background": [x for x in sessions if x["work_mode"] == "background"],
    }


@router.post("/agents/me/break", summary="Go on break")
async def go_break(body: ReasonIn | None = None, agent: AgentMapping = Depends(current_agent),
                   services: Services = Depends(get_services), idempotency_key: str | None = Header(None)):
    reason = body.reason if body else ""
    return await run_idempotent(services, agent.id, idempotency_key, "break", {"reason": reason},
                                lambda: services.workflow.set_manual_state(agent.id, "break", Actor("agent", agent.id), reason))


@router.post("/agents/me/ready", summary="Request Ready (refused while blocking tasks exist)")
async def go_ready(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services),
                   idempotency_key: str | None = Header(None)):
    return await run_idempotent(services, agent.id, idempotency_key, "ready", {},
                                lambda: services.workflow.set_manual_state(agent.id, "ready", Actor("agent", agent.id)))


class DndIn(BaseModel):
    on: bool


@router.post("/agents/me/dnd", summary="Do not disturb: no calls at all (queues paused, browser phone rejects)")
async def set_dnd(body: DndIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        st = await services.engine.ensure_state(s, agent.id)
        if bool(st.dnd) != body.on:
            st.dnd = body.on
            audit(s, "dnd", agent_id=agent.id, actor_type="agent", actor_id=agent.id, on=body.on)
        await s.commit()
    return await services.engine.recompute(agent.id, "dnd")


@router.post("/agents/me/activity", summary="The person is using Zenith Desk (sent at most once a minute)")
async def activity(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        st = await services.engine.ensure_state(s, agent.id)
        st.last_activity_at = utcnow()
        idle = st.idle_since is not None
        await s.commit()
    return {"ok": True, "idle": idle}


@router.post("/agents/me/idle", summary="The browser saw no activity for the configured time: pause the person")
async def go_idle(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    minutes = services.settings.idle_timeout_min
    if minutes <= 0:
        raise HTTPException(409, "inactivity pause is switched off")
    view = await services.workflow.go_idle(agent.id, minutes, "browser")
    return view or await services.engine.state_view(agent.id)


@router.post("/agents/me/resume", summary="Back after an inactivity pause")
async def resume(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.workflow.resume_from_idle(agent)


@router.get("/agents/me/calls", summary="Operator's recent calls")
async def my_calls(limit: int = 20, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.calls.recent(agent.id, min(limit, 100))


def _ticket_brief(t: dict, session: dict | None = None) -> dict:
    return {
        "id": t.get("id"), "number": t.get("number"), "title": t.get("title"), "state": t.get("state"),
        "priority": t.get("priority"), "group": t.get("group"), "customer": t.get("customer"),
        "customer_id": t.get("customer_id"), "owner_id": t.get("owner_id"), "source": ticket_source(t),
        "updated_at": t.get("updated_at"), "created_at": t.get("created_at"), "session": session,
    }


@router.get("/agents/me/tickets", summary="Operator's open tickets from Zammad (+ pending)")
async def my_tickets(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    z, cfg = services.zammad, services.settings
    if not agent.zammad_user_id:
        return {"error": tr("err.not_linked"), "active": [], "pending": []}
    try:
        states = await z.ticket_states()
        open_ids = [str(i) for i, n in states.items() if n.lower() not in cfg.final_states]
        tickets = await z.search_tickets({
            "ticket.owner_id": {"operator": "is", "pre_condition": "specific", "value": [str(agent.zammad_user_id)]},
            "ticket.state_id": {"operator": "is", "value": open_ids},
        }, limit=100, on_behalf_of=agent.zammad_user_id)
    except ZammadError as exc:
        return {"error": str(exc), "active": [], "pending": []}
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(WorkSession).where(
            WorkSession.agent_id == agent.id, WorkSession.state == "active"))).scalars().all()
    by_ticket = {r.ticket_id: session_view(r) for r in rows}
    briefs = []
    for t in tickets:
        if isinstance(t.get("state"), int) or not t.get("state"):
            t["state"] = states.get(int(t.get("state_id", 0)), "")
        briefs.append(_ticket_brief(t, by_ticket.get(t.get("id"))))
    pending = [b for b in briefs if str(b["state"]).lower() in cfg.pending_states]
    active = [b for b in briefs if b not in pending]
    return {"active": active, "pending": pending}


@router.get("/tickets/unassigned", summary="New unassigned tickets in the operator's groups")
async def unassigned(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    z = services.zammad
    if not agent.zammad_user_id:
        return {"error": "", "tickets": []}
    try:
        new_ids = [str(i) for i in await z.state_ids(["new", "open"])]
        tickets = await z.search_tickets({
            "ticket.owner_id": {"operator": "is", "pre_condition": "not_set"},
            "ticket.state_id": {"operator": "is", "value": new_ids},
        }, limit=50, on_behalf_of=agent.zammad_user_id)
        states = await z.ticket_states()
    except ZammadError as exc:
        return {"error": str(exc), "tickets": []}
    for t in tickets:
        if not isinstance(t.get("state"), str):
            t["state"] = states.get(int(t.get("state_id", 0)), "")
    return {"tickets": [_ticket_brief(t) for t in tickets]}


@router.get("/events/stream", summary="SSE event stream (state, calls, alerts)")
async def stream(request: Request, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    supervisor = ROLE_LEVEL.get(agent.role, 0) >= ROLE_LEVEL["supervisor"]
    why = services.broker.refusal(agent.id)  # SEC-05: one user cannot hold the server's memory / sockets open
    if why:
        raise HTTPException(429 if why == "user" else 503, tr("err.too_many_streams"), headers={"Retry-After": "15"})
    return StreamingResponse(
        services.broker.stream(agent.id, supervisor, meta={  # v3.21: shown to the administrator (Users → details)
            "ip": request.client.host if request.client else "", "ua": (request.headers.get("user-agent") or "")[:300],
            "since": utcnow()}),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
