"""Personal settings of the signed-in user (theme, interface style, sound, dashboard layout, account picture).
Stored on the server, so the workplace looks the same on any computer the user signs in from."""
import secrets
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select

from ..audit import audit
from ..auth import current_agent, get_services
from ..i18n import t as tr
from ..models import AgentAvatar, AgentMapping
from ..services import Services

router = APIRouter(prefix="/api/agents/me", tags=["preferences"])
public = APIRouter(tags=["preferences"])

AVATAR_MAX = 1024 * 1024  # the browser sends a 256x256 picture (~20-60 KB); anything far bigger is refused
AVATAR_TYPES = {"image/jpeg", "image/png", "image/webp"}

WIDGETS = ("kpis", "active", "background", "notifications", "new", "mine", "pending", "calls")
PRESETS = ("default", "calls", "tickets", "compact", "focus", "custom")
# v3.19: sections of the top menu a person may pin to the left tool rail (Flow); they stay in the top menu as well
NAV_KEYS = ("work", "tickets", "contacts", "chat", "mail", "whatsapp", "telegram", "sup", "overview", "mtools", "admin")
PIN_MAX = 5


class Widget(BaseModel):
    id: str
    w: int = Field(ge=1, le=3)  # columns out of 3
    h: Literal["auto", "s", "m", "l"] = "auto"
    hidden: bool = False

    @field_validator("id")
    @classmethod
    def known(cls, v: str) -> str:
        if v not in WIDGETS:
            raise ValueError(f"unknown widget {v}")
        return v


class Preferences(BaseModel):
    theme: Literal["", "light", "dark", "system"] = ""  # "" = default dark console
    sound: bool = True
    compact: bool = False
    motion: bool = True  # v2.6: page transitions and micro-animations
    style: Literal["classic", "studio", "flow"] = "flow"  # v3.12: interface style (only the look changes); v3.16: flow; v3.19: the default
    panel: Literal["docked", "popup"] = "docked"  # v3.13 Studio section panel: docked (can be hidden) or pop-up
    dash: Literal["standard", "focus", "board", "inbox", "table"] = "standard"  # v3.14: layout of «My workplace»
    preset: Literal[PRESETS] = "default"  # type: ignore[valid-type]
    layout: list[Widget] = Field(default_factory=list, max_length=len(WIDGETS))
    zoom: Literal["auto", "80", "90", "100", "110", "125"] = "auto"  # v3.22: interface size (auto = fits the screen)
    pins: list[str] = Field(default_factory=list, max_length=PIN_MAX)  # v3.19: quick access on the left rail (at most 5)

    @field_validator("pins")
    @classmethod
    def known_pins(cls, v: list[str]) -> list[str]:
        for k in v:
            if k not in NAV_KEYS:
                raise ValueError(f"unknown section {k}")
        if len(v) != len(set(v)):
            raise ValueError("duplicate sections")
        return v

    @field_validator("layout")
    @classmethod
    def unique(cls, v: list[Widget]) -> list[Widget]:
        ids = [w.id for w in v]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate widgets")
        return v


@router.get("/preferences", summary="Personal settings (theme, sound, dashboard layout)")
async def get_preferences(agent: AgentMapping = Depends(current_agent)):
    return Preferences(**(agent.ui_prefs or {})).model_dump()


@router.put("/preferences", summary="Save personal settings")
async def put_preferences(body: Preferences, agent: AgentMapping = Depends(current_agent),
                          services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, agent.id)
        user.ui_prefs = body.model_dump()
        await s.commit()
    return body.model_dump()


# ------------------------------------------------------------------ v3.12 account picture
def sniff_image(data: bytes) -> str | None:
    """The real type of the picture from its first bytes (the Content-Type header alone is not trusted).
    Only raster photos: no SVG (it may carry scripts)."""
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def avatar_view(agent: AgentMapping) -> dict:
    return {"avatar_mode": agent.avatar_mode, "avatar_url": agent.avatar_url,
            "has_photo": bool(agent.avatar_key)}


class AvatarModeIn(BaseModel):
    mode: Literal["initials", "photo"]


@router.put("/avatar", summary="Upload the account picture (raw image body: JPEG, PNG or WebP, up to 1 MB)")
async def put_avatar(request: Request, agent: AgentMapping = Depends(current_agent),
                     services: Services = Depends(get_services)):
    data = bytearray()
    async for chunk in request.stream():
        data += chunk
        if len(data) > AVATAR_MAX:
            raise HTTPException(413, tr("avatar.too_big"))
    mime = sniff_image(bytes(data))
    if not data or mime is None:
        raise HTTPException(415, tr("avatar.bad_type"))
    key = secrets.token_hex(16)
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, agent.id)
        row = await s.get(AgentAvatar, agent.id)
        if row is None:
            s.add(AgentAvatar(agent_id=agent.id, key=key, mime=mime, data=bytes(data)))
        else:
            row.key, row.mime, row.data = key, mime, bytes(data)
        user.avatar_key, user.avatar_mode = key, "photo"
        audit(s, "avatar_changed", agent_id=agent.id, actor_type="agent", actor_id=agent.id, mode="photo")
        await s.commit()
        view = avatar_view(user)
    services.broker.publish_agent(agent.id, "me_changed", view)
    return view


@router.put("/avatar/mode", summary="Show the photo or the initials of the first and last name")
async def put_avatar_mode(body: AvatarModeIn, agent: AgentMapping = Depends(current_agent),
                          services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, agent.id)
        if body.mode == "photo" and not user.avatar_key:
            raise HTTPException(409, tr("avatar.no_photo"))
        user.avatar_mode = body.mode
        audit(s, "avatar_changed", agent_id=agent.id, actor_type="agent", actor_id=agent.id, mode=body.mode)
        await s.commit()
        view = avatar_view(user)
    services.broker.publish_agent(agent.id, "me_changed", view)
    return view


@router.delete("/avatar", summary="Delete the photo; the initials are shown again")
async def delete_avatar(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, agent.id)
        row = await s.get(AgentAvatar, agent.id)
        if row is not None:
            await s.delete(row)
        user.avatar_key, user.avatar_mode = "", "initials"
        audit(s, "avatar_changed", agent_id=agent.id, actor_type="agent", actor_id=agent.id, mode="deleted")
        await s.commit()
        view = avatar_view(user)
    services.broker.publish_agent(agent.id, "me_changed", view)
    return view


@public.get("/api/avatars/{key}", summary="An account picture (the key is random and changes with every upload)",
            response_class=Response)
async def get_avatar(key: str, services: Services = Depends(get_services)):
    if not (len(key) == 32 and all(c in "0123456789abcdef" for c in key)):
        raise HTTPException(404, tr("avatar.not_found"))
    async with services.db.sessionmaker() as s:
        row = (await s.execute(select(AgentAvatar).where(AgentAvatar.key == key))).scalars().first()
    if row is None:
        raise HTTPException(404, tr("avatar.not_found"))
    return Response(row.data, media_type=row.mime, headers={
        "Cache-Control": "private, max-age=31536000, immutable",
        "Content-Security-Policy": "default-src 'none'"})
