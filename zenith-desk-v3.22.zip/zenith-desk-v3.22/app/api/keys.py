"""v3.18 API keys for other programs (administrators only)."""
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import select

from .. import api_keys
from ..audit import audit
from ..auth import get_services, require_role
from ..db import utcnow
from ..i18n import t as tr
from ..models import AgentMapping, ApiKey
from ..services import Services

router = APIRouter(prefix="/api/admin/api-keys", tags=["API keys"])
admin = require_role("admin")


class KeyIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    agent_id: int
    read_only: bool = False
    expires_days: int | None = Field(default=None, ge=1, le=3650)  # empty = never
    allowed_ips: str = Field(default="", max_length=500)


async def _list(services: Services) -> dict:
    async with services.db.sessionmaker() as s:
        keys = (await s.execute(select(ApiKey).order_by(ApiKey.id.desc()))).scalars().all()
        users = (await s.execute(select(AgentMapping))).scalars().all()
    names = {u.id: u.display_name or u.username or "" for u in users}
    return {"keys": [api_keys.view(k, names) for k in keys],
            "users": [{"id": u.id, "name": names[u.id], "role": u.role, "level": u.level} for u in users if u.active and u.username],
            "rate_per_minute": api_keys.RATE}


@router.get("", summary="API keys of other programs (the keys themselves are never shown again)")
async def list_keys(_: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    return await _list(services)


@router.post("", summary="Create an API key — the answer holds the key; it is shown only this once")
async def create_key(body: KeyIn, me: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    try:
        api_keys.parse_networks(body.allowed_ips)
    except ValueError as exc:
        raise HTTPException(422, tr("api.bad_ips")) from exc
    full, prefix, digest = api_keys.new_key()
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, body.agent_id)
        if user is None or not user.active:
            raise HTTPException(404, tr("err.not_found"))
        k = ApiKey(name=body.name.strip(), prefix=prefix, secret_hash=digest, agent_id=user.id, read_only=body.read_only,
                   allowed_ips=body.allowed_ips.strip(), expires_at=api_keys.expiry(body.expires_days), created_by=me.id,
                   last_used_ip="", uses=0)
        s.add(k)
        await s.flush()
        audit(s, "api_key_created", actor_type="admin", actor_id=me.id, key_id=k.id, name=k.name, user=user.username,
              read_only=k.read_only, expires_at=k.expires_at.isoformat() if k.expires_at else None, allowed_ips=k.allowed_ips)
        await s.commit()
        kid = k.id
    out = await _list(services)
    return {**out, "created": {"id": kid, "key": full}}


@router.delete("/{key_id}", summary="Revoke an API key (the program using it is refused at once)")
async def revoke_key(key_id: int, me: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        k = await s.get(ApiKey, key_id)
        if k is None:
            raise HTTPException(404, tr("err.not_found"))
        if k.revoked_at is None:
            k.revoked_at = utcnow()
            audit(s, "api_key_revoked", level="warning", actor_type="admin", actor_id=me.id, key_id=k.id, name=k.name)
            await s.commit()
    return await _list(services)


@router.get("/openapi.json", summary="The description of the whole API (OpenAPI 3) for the program's developers")
async def openapi(request: Request, _: AgentMapping = Depends(admin)):
    spec = request.app.openapi()
    spec = {**spec, "components": {**spec.get("components", {}), "securitySchemes": {
        "apiKey": {"type": "apiKey", "in": "header", "name": "X-API-Key"},
        "bearer": {"type": "http", "scheme": "bearer"}}}, "security": [{"apiKey": []}, {"bearer": []}]}
    return JSONResponse(spec, headers={"Content-Disposition": 'attachment; filename="zenith-desk-openapi.json"'})
