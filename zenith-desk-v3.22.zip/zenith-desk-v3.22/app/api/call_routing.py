"""v3.18 call routing for managers: overflow, ring strategy per queue, VIP / the last operator."""
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select

from ..auth import get_services, require_role
from ..call_routing import RoutingError
from ..db import as_utc
from ..models import AgentMapping, AuditLog
from ..services import Services

router = APIRouter(prefix="/api/admin/call-routing", tags=["call routing"])
supervisor = require_role("supervisor")


class RoutingIn(BaseModel):
    queues: dict = {}
    vip: dict = {}


async def _recent(services: Services) -> list[dict]:
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(AuditLog).where(AuditLog.action.like("callroute_%")).order_by(AuditLog.id.desc()).limit(30))).scalars().all()
    return [{"id": r.id, "ts": as_utc(r.ts), "action": r.action, "agent_id": r.agent_id, "details": r.details} for r in rows]


@router.get("", summary="Call routing rules, what is happening now and the last decisions")
async def get_routing(_: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    return {**await services.routing.view(), "recent": await _recent(services)}


@router.put("", summary="Save the call routing rules (applied at once)")
async def save_routing(body: RoutingIn, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    try:
        await services.routing.save({"queues": body.queues, "vip": body.vip}, user)
    except RoutingError as exc:
        raise HTTPException(422, str(exc)) from exc
    return {**await services.routing.view(), "recent": await _recent(services)}


@router.get("/test", summary="Where a call from this number would go right now (nothing is changed)")
async def test_number(number: str = Query(min_length=3, max_length=40), _: AgentMapping = Depends(supervisor),
                      services: Services = Depends(get_services)):
    d = await services.routing.decide(number)
    a = d.get("agent")
    return {"number": number, "reason": d["reason"], "target": d.get("target"), "rule": d.get("rule"),
            "agent": {"id": a.id, "name": a.display_name, "extension": a.extension} if a else None,
            "candidates": d.get("candidates", [])}
