import time
from collections import defaultdict, deque
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..audit import audit
from ..auth import current_agent, get_services, issue_stream_token, issue_token, revoke_session
from ..crypto import hash_password, hash_password_async, needs_rehash, verify_password_async
from ..db import utcnow
from ..i18n import t as tr
from ..models import AgentMapping, LoginAttempt
from ..services import Services
from ..workflow import Actor
from sqlalchemy import func, select

router = APIRouter(prefix="/api/auth", tags=["auth"])

_failures: dict[str, deque] = defaultdict(deque)
MAX_FAILURES, WINDOW_SEC = 5, 300
MAX_IP_FAILURES = 20  # v3.17: one address trying many logins (password spraying) is stopped too
# v3.17: an unknown login costs the same time as a wrong password (nobody can find out which logins exist)
_DUMMY_HASH = hash_password("zenith-desk-timing-equaliser")


def _recent(key: str, now: float) -> deque:
    fails = _failures[key]
    while fails and now - fails[0] > WINDOW_SEC:
        fails.popleft()
    if len(_failures) > 10000:  # never grows without limit (many invented logins)
        for k in [k for k, v in _failures.items() if not v or now - v[-1] > WINDOW_SEC]:
            _failures.pop(k, None)
    return fails


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=1, max_length=200)


def user_view(agent: AgentMapping) -> dict:
    return {"id": agent.id, "name": agent.display_name, "username": agent.username, "role": agent.role,
            "position": agent.position, "level": agent.level, "extension": agent.extension,
            "zammad_user_id": agent.zammad_user_id, "must_change_password": agent.must_change_password,
            "prefs": agent.ui_prefs or {}, "first_name": agent.first_name, "last_name": agent.last_name,
            "avatar_mode": agent.avatar_mode, "avatar_url": agent.avatar_url, "has_photo": bool(agent.avatar_key)}


def lock_info(username: str) -> dict | None:
    """v3.21: is this login locked right now (too many wrong passwords) — until when (UTC) and after how many."""
    now = time.monotonic()
    fails = _failures.get((username or "").lower())
    if not fails:
        return None
    while fails and now - fails[0] > WINDOW_SEC:
        fails.popleft()
    if len(fails) < MAX_FAILURES:
        return None
    left = fails[-MAX_FAILURES] + WINDOW_SEC - now
    return {"until": utcnow() + timedelta(seconds=max(0.0, left)), "failures": len(fails)}


def unlock(username: str) -> bool:
    """v3.21: the administrator lifts the lock of one login (the per-address limit stays)."""
    return _failures.pop((username or "").lower(), None) is not None


_locked_noted: dict[tuple[str, str], float] = {}


def _note_locked_attempt(username: str, ip: str, now: float) -> bool:
    """Attempts while locked are recorded at most once a minute per login + address (a flood fills nothing)."""
    key = (username, ip)
    if now - _locked_noted.get(key, -1e9) < 60:
        return False
    if len(_locked_noted) > 5000:
        _locked_noted.clear()
    _locked_noted[key] = now
    return True


def _client(request: Request) -> tuple[str, str]:
    return (request.client.host if request.client else "?"), (request.headers.get("user-agent") or "")[:300]


@router.post("/login", summary="Sign in with the login and password issued by the administrator")
async def login(body: LoginIn, request: Request, services: Services = Depends(get_services)):
    username = body.username.strip().lower()
    now = time.monotonic()
    addr, ua = _client(request)
    ip = "ip:" + addr
    fails, ip_fails = _recent(username, now), _recent(ip, now)
    if len(fails) >= MAX_FAILURES or len(ip_fails) >= MAX_IP_FAILURES:
        if _note_locked_attempt(username[:100], addr, now):
            async with services.db.sessionmaker() as s:
                agent_id = (await s.execute(select(AgentMapping.id).where(func.lower(AgentMapping.username) == username))).scalar()
                s.add(LoginAttempt(username=username[:100], agent_id=agent_id, ip=addr[:64], user_agent=ua, result="locked"))
                await s.commit()
        raise HTTPException(429, tr("err.too_many_attempts"))
    async with services.db.sessionmaker() as s:
        agent = (await s.execute(select(AgentMapping).where(func.lower(AgentMapping.username) == username))).scalars().first()
        ok = await verify_password_async(body.password, agent.password_hash if agent is not None and agent.password_hash else _DUMMY_HASH)
        if agent is None or not agent.password_hash or not ok:
            fails.append(now)
            ip_fails.append(now)
            audit(s, "login_failed", agent_id=agent.id if agent else None, level="warning", username=username[:100],
                  ip=addr, known=agent is not None)
            s.add(LoginAttempt(username=username[:100], agent_id=agent.id if agent else None, ip=addr[:64], user_agent=ua,
                               result="bad_password" if agent is not None else "unknown_user"))
            if agent is not None and len(fails) == MAX_FAILURES:  # v3.21: this attempt locked the login
                audit(s, "login_locked", agent_id=agent.id, level="warning", username=username[:100], ip=addr,
                      minutes=WINDOW_SEC // 60)
            await s.commit()
            raise HTTPException(401, tr("err.bad_credentials"))
        if not agent.active:
            s.add(LoginAttempt(username=username[:100], agent_id=agent.id, ip=addr[:64], user_agent=ua, result="disabled"))
            await s.commit()
            raise HTTPException(403, tr("err.user_disabled"))
        fails.clear()
        if needs_rehash(agent.password_hash):  # SEC-08: upgrade an older hash now that we have the password
            agent.password_hash = await hash_password_async(body.password)
        agent.last_login_at = utcnow()
        s.add(LoginAttempt(username=username[:100], agent_id=agent.id, ip=addr[:64], user_agent=ua, result="ok"))
        st = await services.engine.ensure_state(s, agent.id)
        was_offline = st.manual_state == "offline"
        audit(s, "login", agent_id=agent.id, actor_type="agent", actor_id=agent.id, ip=addr)
        st = await services.engine.ensure_state(s, agent.id)
        st.last_activity_at, st.idle_since = utcnow(), None
        await s.commit()
    if was_offline and agent.role != "admin":
        target = "ready" if services.settings.login_sets_ready else "break"
        await services.workflow.set_manual_state(agent.id, target, Actor("system", agent.id), "login")
    return {"token": issue_token(services, agent), "agent": user_view(agent)}


@router.post("/stream-token", summary="A 60-second ticket for opening the live event stream (EventSource)")
async def stream_token(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return {"token": issue_stream_token(services, agent)}


@router.get("/me")
async def me(agent: AgentMapping = Depends(current_agent)):
    return user_view(agent)


class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=200)


@router.post("/change-password", summary="Change own password")
async def change_password(body: PasswordChangeIn, agent: AgentMapping = Depends(current_agent),
                          services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, agent.id)
        if not await verify_password_async(body.current_password, user.password_hash):
            raise HTTPException(400, tr("err.wrong_current_password"))
        if body.current_password == body.new_password:
            raise HTTPException(400, tr("err.same_password"))
        user.password_hash = await hash_password_async(body.new_password)
        user.must_change_password = False
        audit(s, "password_changed", agent_id=user.id, actor_type="agent", actor_id=user.id)
        await s.commit()
        return {"token": issue_token(services, user), "agent": user_view(user)}


@router.post("/logout", summary="Sign out (operator goes OFFLINE; this session token stops working)")
async def logout(request: Request, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    result = await services.workflow.set_manual_state(agent.id, "offline", Actor("agent", agent.id), "logout")
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        await revoke_session(services, auth[7:].strip())  # SEC-07
    # SEC-07: open live streams were opened with this or another session; they reconnect if still allowed
    services.broker.close_agent(agent.id)
    return result
