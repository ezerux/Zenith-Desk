"""v3.15 manager tools: call supervision, shift schedule, recordings archive and the log."""
from __future__ import annotations

import csv
import io
from datetime import date, datetime, time, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import String, and_, cast, false, func, or_, select

from ..audit import audit
from ..auth import ROLE_LEVEL, current_agent, get_services, require_role
from ..db import as_utc, utcnow
from ..i18n import t as tr
from ..models import AgentMapping, AuditLog, CallRecord, Shift, ShiftTemplate
from ..services import Services
from ..shifts import local_span, parse_hhmm, shift_view, tzinfo, with_attendance

router = APIRouter(prefix="/api", tags=["manager tools"])
supervisor = require_role("supervisor")


def is_sup(a: AgentMapping) -> bool:
    return ROLE_LEVEL.get(a.role, 0) >= ROLE_LEVEL["supervisor"]


# ====================================================================== call supervision
class SpyIn(BaseModel):
    agent_id: int
    mode: str = Field("listen", pattern="^(listen|whisper|barge)$")


class SpyMode(BaseModel):
    mode: str = Field(pattern="^(listen|whisper|barge)$")


@router.get("/sup/spy", summary="My current listening session (call supervision)")
async def spy_current(user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    x = services.supervision.current(user.id)
    return {"active": bool(x), "session": x.view() if x else None, "enabled": services.settings.supervise_enabled}


@router.post("/sup/spy", summary="Listen to / whisper to / join an operator's call: Asterisk rings my phone")
async def spy_start(body: SpyIn, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    return {"active": True, "session": await services.supervision.start(user, body.agent_id, body.mode)}


@router.post("/sup/spy/mode", summary="Switch listen / whisper / barge (the phone sends key 4 / 5 / 6)")
async def spy_mode(body: SpyMode, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    return {"active": True, "session": await services.supervision.set_mode(user, body.mode)}


@router.delete("/sup/spy", summary="Stop listening")
async def spy_stop(user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    return await services.supervision.stop(user)


# ====================================================================== shift schedule
class ShiftsIn(BaseModel):
    agent_ids: list[int] = Field(min_length=1, max_length=500)
    dates: list[date] = Field(min_length=1, max_length=62)
    start: str
    end: str
    note: str = Field("", max_length=200)
    replace: bool = False  # remove the shifts these people already have on these days


class ShiftEdit(BaseModel):
    date: date
    start: str
    end: str
    note: str = Field("", max_length=200)


class CopyIn(BaseModel):
    source: date  # first day of the copied period
    target: date  # first day it is copied to
    days: int = Field(7, ge=1, le=31)
    agent_ids: list[int] | None = None


class TemplateIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    start: str
    end: str
    color: str = Field("", max_length=20)


def _times(start: str, end: str) -> None:
    try:
        parse_hhmm(start), parse_hhmm(end)
    except ValueError as e:
        raise HTTPException(422, tr("sh.bad_time")) from e
    if start == end:
        raise HTTPException(422, tr("sh.bad_time"))


def _day_bounds(day: date, days: int, tz_name: str) -> tuple[datetime, datetime]:
    tz = tzinfo(tz_name)
    a = datetime.combine(day, time.min, tzinfo=tz).astimezone(timezone.utc)
    b = datetime.combine(day + timedelta(days=days), time.min, tzinfo=tz).astimezone(timezone.utc)
    return a, b


async def _overlaps(s, agent_id: int, a: datetime, b: datetime, skip: int | None = None) -> list[Shift]:
    q = select(Shift).where(Shift.agent_id == agent_id, Shift.starts_at < b, Shift.ends_at > a)
    if skip:
        q = q.where(Shift.id != skip)
    return (await s.execute(q)).scalars().all()


def _template_view(x: ShiftTemplate) -> dict:
    return {"id": x.id, "name": x.name, "start": x.start, "end": x.end, "color": x.color}


def _person(m: AgentMapping) -> dict:
    return {"id": m.id, "name": m.display_name or m.username or "", "level": m.level, "role": m.role, "extension": m.extension,
            "position": m.position, "avatar_url": m.avatar_url}


@router.get("/sup/shifts", summary="Shift schedule with attendance (late, absent, early leave)")
async def shifts_list(start: date | None = None, days: int = Query(7, ge=1, le=31), user: AgentMapping = Depends(supervisor),
                      services: Services = Depends(get_services)):
    cfg = services.settings
    tz = tzinfo(cfg.display_timezone)
    start = start or datetime.now(tz).date()
    a, b = _day_bounds(start, days, cfg.display_timezone)
    async with services.db.sessionmaker() as s:
        people = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True), AgentMapping.role != "admin")
                                  .order_by(AgentMapping.display_name))).scalars().all()
        rows = (await s.execute(select(Shift).where(Shift.starts_at >= a, Shift.starts_at < b)
                                .order_by(Shift.starts_at))).scalars().all()
        templates = (await s.execute(select(ShiftTemplate).order_by(ShiftTemplate.start, ShiftTemplate.id))).scalars().all()
        atts = await with_attendance(s, rows, cfg)
        known = {p.id for p in people}
        extra = {r.agent_id for r in rows} - known  # switched off since, but had shifts in this period
        if extra:
            people = [*people, *(await s.execute(select(AgentMapping).where(AgentMapping.id.in_(extra)))).scalars().all()]
    out = [shift_view(r, atts.get(r.id)) for r in rows]
    summary = {k: sum(1 for x in out if k in x["attendance"]["problems"]) for k in ("late", "absent", "early_leave")}
    return {"start": start, "days": [start + timedelta(days=i) for i in range(days)], "timezone": cfg.display_timezone,
            "now": utcnow(), "agents": [_person(p) for p in people], "shifts": out, "templates": [_template_view(t) for t in templates],
            "summary": summary, "settings": {"grace_min": cfg.shift_grace_min, "absent_min": cfg.shift_absent_min, "alerts": cfg.shift_alerts}}


@router.post("/sup/shifts", summary="Plan shifts: several people × several days at once")
async def shifts_create(body: ShiftsIn, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    _times(body.start, body.end)
    tzn = services.settings.display_timezone
    created, skipped, removed = [], 0, 0
    async with services.db.sessionmaker() as s:
        people = {m.id: m for m in (await s.execute(select(AgentMapping).where(AgentMapping.id.in_(body.agent_ids)))).scalars().all()}
        if len(people) != len(set(body.agent_ids)):
            raise HTTPException(404, tr("err.agent_not_found"))
        for aid in dict.fromkeys(body.agent_ids):
            for day in dict.fromkeys(body.dates):
                a, b = local_span(day, body.start, body.end, tzn)
                if body.replace:
                    da, db_ = _day_bounds(day, 1, tzn)
                    for old in (await s.execute(select(Shift).where(Shift.agent_id == aid, Shift.starts_at >= da,
                                                                     Shift.starts_at < db_))).scalars().all():
                        await s.delete(old)
                        removed += 1
                    await s.flush()
                if await _overlaps(s, aid, a, b):
                    skipped += 1
                    continue
                x = Shift(agent_id=aid, starts_at=a, ends_at=b, note=body.note.strip(), created_by=user.id)
                s.add(x)
                await s.flush()
                created.append(x.id)
        audit(s, "shift_planned", actor_type="supervisor", actor_id=user.id, people=len(people), days=len(set(body.dates)),
              start=body.start, end=body.end, created=len(created), skipped=skipped, removed=removed or None, by=user.display_name)
        await s.commit()
    return {"created": len(created), "skipped": skipped, "removed": removed, "ids": created}


@router.put("/sup/shifts/{shift_id}", summary="Change one shift")
async def shift_edit(shift_id: int, body: ShiftEdit, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    _times(body.start, body.end)
    async with services.db.sessionmaker() as s:
        x = await s.get(Shift, shift_id)
        if x is None:
            raise HTTPException(404, tr("err.not_found"))
        a, b = local_span(body.date, body.start, body.end, services.settings.display_timezone)
        if await _overlaps(s, x.agent_id, a, b, skip=x.id):
            raise HTTPException(409, tr("sh.overlap"))
        old = (as_utc(x.starts_at).isoformat(), as_utc(x.ends_at).isoformat())
        x.starts_at, x.ends_at, x.note = a, b, body.note.strip()
        x.alerts = None  # check the new times again
        audit(s, "shift_changed", agent_id=x.agent_id, actor_type="supervisor", actor_id=user.id, shift_id=x.id,
              old=f"{old[0]} – {old[1]}", new=f"{a.isoformat()} – {b.isoformat()}", by=user.display_name)
        await s.commit()
        atts = await with_attendance(s, [x], services.settings)
        return shift_view(x, atts.get(x.id))


@router.delete("/sup/shifts/{shift_id}", summary="Remove one shift")
async def shift_delete(shift_id: int, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        x = await s.get(Shift, shift_id)
        if x is None:
            raise HTTPException(404, tr("err.not_found"))
        audit(s, "shift_removed", agent_id=x.agent_id, actor_type="supervisor", actor_id=user.id, shift_id=x.id,
              starts_at=as_utc(x.starts_at).isoformat(), ends_at=as_utc(x.ends_at).isoformat(), by=user.display_name)
        await s.delete(x)
        await s.commit()
    return {"ok": True}


@router.post("/sup/shifts/copy", summary="Copy the shifts of a period (e.g. last week) to another period")
async def shifts_copy(body: CopyIn, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    tzn = services.settings.display_timezone
    tz = tzinfo(tzn)
    a, b = _day_bounds(body.source, body.days, tzn)
    shift_days = (body.target - body.source).days
    if shift_days == 0:
        raise HTTPException(422, tr("sh.same_period"))
    created = skipped = 0
    async with services.db.sessionmaker() as s:
        q = select(Shift).where(Shift.starts_at >= a, Shift.starts_at < b)
        if body.agent_ids:
            q = q.where(Shift.agent_id.in_(body.agent_ids))
        for x in (await s.execute(q.order_by(Shift.starts_at))).scalars().all():
            # the same local time on the new day (daylight saving changes keep the wall-clock time)
            ls, le = as_utc(x.starts_at).astimezone(tz), as_utc(x.ends_at).astimezone(tz)
            na = local_span(ls.date() + timedelta(days=shift_days), ls.strftime("%H:%M"), le.strftime("%H:%M"), tzn)
            if await _overlaps(s, x.agent_id, *na):
                skipped += 1
                continue
            s.add(Shift(agent_id=x.agent_id, starts_at=na[0], ends_at=na[1], note=x.note, created_by=user.id))
            await s.flush()
            created += 1
        audit(s, "shift_copied", actor_type="supervisor", actor_id=user.id, source=body.source.isoformat(), target=body.target.isoformat(),
              days=body.days, created=created, skipped=skipped, by=user.display_name)
        await s.commit()
    return {"created": created, "skipped": skipped}


@router.post("/sup/shift-templates", summary="Save a shift template (e.g. Morning 09:00–18:00)")
async def template_create(body: TemplateIn, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    _times(body.start, body.end)
    async with services.db.sessionmaker() as s:
        x = ShiftTemplate(name=body.name.strip(), start=body.start, end=body.end, color=body.color.strip())
        s.add(x)
        await s.commit()
        return _template_view(x)


@router.delete("/sup/shift-templates/{template_id}", summary="Remove a shift template")
async def template_delete(template_id: int, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        x = await s.get(ShiftTemplate, template_id)
        if x is None:
            raise HTTPException(404, tr("err.not_found"))
        await s.delete(x)
        await s.commit()
    return {"ok": True}


@router.get("/agents/me/shifts", summary="My shifts (today and the coming days)")
async def my_shifts(days: int = Query(7, ge=1, le=31), agent: AgentMapping = Depends(current_agent),
                    services: Services = Depends(get_services)):
    cfg = services.settings
    today = datetime.now(tzinfo(cfg.display_timezone)).date()
    a, b = _day_bounds(today, days, cfg.display_timezone)
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(Shift).where(Shift.agent_id == agent.id, Shift.ends_at > a, Shift.starts_at < b)
                                .order_by(Shift.starts_at))).scalars().all()
        atts = await with_attendance(s, rows, cfg)
    return {"shifts": [shift_view(r, atts.get(r.id)) for r in rows], "timezone": cfg.display_timezone}


# ====================================================================== recordings archive
def _tod(v: str | None) -> time | None:
    if not v:
        return None
    try:
        return parse_hhmm(v)
    except ValueError as e:
        raise HTTPException(422, tr("sh.bad_time")) from e


@router.get("/recordings", summary="Call recordings: find a conversation by day, hour, operator, number…")
async def recordings(date_from: date | None = None, date_to: date | None = None, time_from: str | None = None,
                     time_to: str | None = None, agent_id: int | None = None, number: str = "", direction: str = "",
                     queue: str = "", min_sec: int = 0, ticket: str = "", limit: int = Query(50, ge=1, le=500),
                     offset: int = Query(0, ge=0), agent: AgentMapping = Depends(supervisor),
                     services: Services = Depends(get_services)):
    """v3.17.1: the recordings archive is for managers and administrators only (operators: 403)."""
    cfg = services.settings
    tz = tzinfo(cfg.display_timezone)
    today = datetime.now(tz).date()
    date_to = date_to or today
    date_from = date_from or (date_to - timedelta(days=6))
    if date_from > date_to:
        date_from, date_to = date_to, date_from
    if (date_to - date_from).days > 366:
        raise HTTPException(422, tr("rec.range"))
    a, b = _day_bounds(date_from, (date_to - date_from).days + 1, cfg.display_timezone)
    tf, tt = _tod(time_from), _tod(time_to)
    q = select(CallRecord).where(CallRecord.recording_file != "", CallRecord.started_at >= a, CallRecord.started_at < b)
    if agent_id:
        q = q.where(CallRecord.agent_id == agent_id)
    digits = "".join(ch for ch in number if ch.isdigit())
    if number.strip():
        cond = [CallRecord.caller_name.ilike(f"%{number.strip()}%")]
        if digits:
            cond += [CallRecord.caller_normalized.contains(digits[-9:] if len(digits) > 9 else digits),
                     CallRecord.caller_number.contains(digits)]
        q = q.where(or_(*cond))
    if direction in ("in", "out"):
        q = q.where(CallRecord.direction == direction)
    if queue.strip():
        q = q.where(CallRecord.queue == queue.strip())
    if ticket == "yes":
        q = q.where(CallRecord.ticket_id.is_not(None))
    elif ticket == "no":
        q = q.where(CallRecord.ticket_id.is_(None))
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(q.order_by(CallRecord.started_at.desc()).limit(20000))).scalars().all()
        names = {m.id: m.display_name or m.username or "" for m in (await s.execute(select(AgentMapping))).scalars().all()}

    def talk(c: CallRecord) -> int:
        if not c.answered_at:
            return 0
        return int(((as_utc(c.ended_at) or utcnow()) - as_utc(c.answered_at)).total_seconds())

    def in_hours(c: CallRecord) -> bool:
        lt = as_utc(c.started_at).astimezone(tz).time()
        if tf and tt and tf > tt:  # e.g. 22:00 – 06:00
            return lt >= tf or lt < tt
        return (not tf or lt >= tf) and (not tt or lt < tt)

    hits = [c for c in rows if in_hours(c) and talk(c) >= max(0, min_sec)]
    page = hits[offset:offset + limit]
    items = []
    for c in page:
        url = services.calls.recording_url(c)
        items.append({"id": c.id, "started_at": as_utc(c.started_at), "answered_at": as_utc(c.answered_at), "ended_at": as_utc(c.ended_at),
                      "talk_sec": talk(c), "agent_id": c.agent_id, "agent_name": names.get(c.agent_id, ""), "direction": c.direction,
                      "queue": c.queue, "extension": c.extension, "number": c.caller_number, "name": c.caller_name,
                      "state": c.state, "ticket_id": c.ticket_id, "url": url, "protected": url.startswith("/api/")})
    out = {"items": items, "total": len(hits), "date_from": date_from, "date_to": date_to, "timezone": cfg.display_timezone,
           "truncated": len(rows) >= 20000}
    if is_sup(agent):
        out["agents"] = [{"id": i, "name": n} for i, n in sorted(names.items(), key=lambda x: x[1].lower())]
    return out


# ====================================================================== the log
CATEGORIES: list[tuple[str, tuple[str, ...], tuple[str, ...]]] = [
    # (category, exact actions, action prefixes)
    ("system", ("system_log", "sync_error", "sync_restored", "sync_poll", "auto_ticket_failed", "retention_cleanup"), ()),
    ("auth", ("login", "logout", "login_failed", "password_changed", "password_reset", "admin_bootstrap",
              "login_locked", "login_unlocked", "sessions_revoked"), ()),
    ("state", ("manual_state", "availability_changed", "presence_lost", "idle_offline", "idle_returned", "dnd", "supervisor_override",
               "wrap_up_started", "manual_reconcile", "queue_pause", "queue_penalty"), ()),
    ("shifts", (), ("shift_",)),
    ("calls", ("call_answered", "team_alert"), ("recording_", "spy_", "call_", "callroute_")),
    ("tickets", ("mode_changed", "customer_created"), ("work_", "ticket_")),
    ("messages", (), ("msg_", "mail_", "chat_")),
    ("admin", ("settings_changed",), ("user_", "zammad_", "backup_", "avatar_", "routing_", "api_key_")),
]
STAFF_CATEGORIES = ("auth", "state", "shifts", "calls", "tickets", "messages")  # what a manager (not admin) sees


def category_of(action: str) -> str:
    for cat, exact, prefixes in CATEGORIES:
        if action in exact or action.startswith(prefixes or ("\0",)):
            return cat
    return "other"


def _cat_cond(cat: str):
    for c, exact, prefixes in CATEGORIES:
        if c == cat:
            # the same order as category_of: an action belongs to the first category that names it
            earlier = CATEGORIES[:CATEGORIES.index((c, exact, prefixes))]
            mine = or_(AuditLog.action.in_(exact) if exact else false(), *[AuditLog.action.startswith(p, autoescape=True) for p in prefixes])
            others = [_raw_cond(e, p) for _, e, p in earlier]
            return and_(mine, *[~o for o in others]) if others else mine
    if cat == "other":
        return ~or_(*[_raw_cond(e, p) for _, e, p in CATEGORIES])
    raise HTTPException(422, "unknown category")


def _raw_cond(exact, prefixes):
    return or_(AuditLog.action.in_(exact) if exact else false(), *[AuditLog.action.startswith(p, autoescape=True) for p in prefixes])


def _dt(v: str | None) -> datetime | None:
    if not v:
        return None
    try:
        d = datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError as e:
        raise HTTPException(422, "date/time must be ISO 8601") from e
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def _log_query(user: AgentMapping, since, until, level, category, actor_id, agent_id, action, q, ticket_id):
    stmt = select(AuditLog)
    cats = None if user.role == "admin" else STAFF_CATEGORIES
    if category:
        wanted = [c for c in category.split(",") if c]
        if cats is not None:
            wanted = [c for c in wanted if c in cats]
            if not wanted:
                raise HTTPException(403, tr("err.forbidden"))
        stmt = stmt.where(or_(*[_cat_cond(c) for c in wanted]))
    elif cats is not None:
        stmt = stmt.where(or_(*[_cat_cond(c) for c in cats]))
    if since:
        stmt = stmt.where(AuditLog.ts >= since)
    if until:
        stmt = stmt.where(AuditLog.ts < until)
    if level:
        levels = [x for x in level.split(",") if x in ("info", "warning", "error")]
        stmt = stmt.where(AuditLog.level.in_(levels or ["-"]))
    if actor_id:
        stmt = stmt.where(AuditLog.actor_id == actor_id)
    if agent_id:
        stmt = stmt.where(AuditLog.agent_id == agent_id)
    if action:
        stmt = stmt.where(AuditLog.action.in_([a for a in action.split(",") if a]))
    if ticket_id:
        stmt = stmt.where(AuditLog.ticket_id == ticket_id)
    if q.strip():
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(AuditLog.action.ilike(like), cast(AuditLog.details, String).ilike(like)))
    return stmt


def _row(r: AuditLog, names: dict[int, str]) -> dict:
    return {"id": r.id, "ts": as_utc(r.ts), "level": r.level, "category": category_of(r.action), "action": r.action,
            "actor_type": r.actor_type, "actor_id": r.actor_id, "actor_name": names.get(r.actor_id, "") if r.actor_id else "",
            "agent_id": r.agent_id, "agent_name": names.get(r.agent_id, "") if r.agent_id else "", "ticket_id": r.ticket_id,
            "details": r.details or {}}


LogFilters = dict


async def _filters(since: str | None = None, until: str | None = None, date_from: date | None = None, date_to: date | None = None,
                   time_from: str | None = None, time_to: str | None = None, level: str = "", category: str = "",
                   actor_id: int | None = None, agent_id: int | None = None, action: str = "", q: str = "",
                   ticket_id: int | None = None, services: Services = Depends(get_services)) -> LogFilters:
    """From / to as ISO times, or as a day (+ hour) in the company's time zone: 2026-03-02 09:00 … 2026-03-02 12:00."""
    tz = tzinfo(services.settings.display_timezone)
    a, b = _dt(since), _dt(until)
    if date_from:
        a = datetime.combine(date_from, _tod(time_from) or time.min, tzinfo=tz).astimezone(timezone.utc)
    if date_to or time_to:
        day = date_to or date_from or datetime.now(tz).date()
        tt = _tod(time_to)
        b = (datetime.combine(day, tt, tzinfo=tz) if tt else datetime.combine(day + timedelta(days=1), time.min, tzinfo=tz)).astimezone(timezone.utc)
    return {"since": a, "until": b, "level": level, "category": category, "actor_id": actor_id,
            "agent_id": agent_id, "action": action, "q": q, "ticket_id": ticket_id}


@router.get("/log", summary="The log: staff actions and system problems, with filters")
async def log_list(f: LogFilters = Depends(_filters), limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0),
                   user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    stmt = _log_query(user, **f)
    async with services.db.sessionmaker() as s:
        total = (await s.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
        rows = (await s.execute(stmt.order_by(AuditLog.ts.desc(), AuditLog.id.desc()).offset(offset).limit(limit))).scalars().all()
        names = {m.id: m.display_name or m.username or "" for m in (await s.execute(select(AgentMapping))).scalars().all()}
    return {"items": [_row(r, names) for r in rows], "total": total}


@router.get("/log/meta", summary="What the log can be filtered by")
async def log_meta(user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    cats = [c for c, _, _ in CATEGORIES] + ["other"] if user.role == "admin" else list(STAFF_CATEGORIES)
    async with services.db.sessionmaker() as s:
        acts = (await s.execute(select(AuditLog.action).distinct())).scalars().all()
        people = (await s.execute(select(AgentMapping).order_by(AgentMapping.display_name))).scalars().all()
    actions = sorted(a for a in acts if category_of(a) in cats)
    return {"categories": cats, "actions": [{"action": a, "category": category_of(a)} for a in actions],
            "people": [{"id": p.id, "name": p.display_name or p.username or "", "role": p.role} for p in people]}


def _cell(v) -> str:
    """SEC-10: a cell that starts with = + - @ (or a tab / CR) is run as a formula by Excel / LibreOffice — prefix it
    with ' so a name or a logged value is always shown as text (CWE-1236)."""
    v = "" if v is None else str(v)
    return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


@router.get("/log.csv", summary="The filtered log as a CSV file (Excel)")
async def log_csv(f: LogFilters = Depends(_filters), user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    stmt = _log_query(user, **f)
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(stmt.order_by(AuditLog.ts.desc(), AuditLog.id.desc()).limit(50000))).scalars().all()
        names = {m.id: m.display_name or m.username or "" for m in (await s.execute(select(AgentMapping))).scalars().all()}
        audit(s, "log_exported", actor_type="supervisor" if user.role != "admin" else "admin", actor_id=user.id, rows=len(rows))
        await s.commit()
    tz = tzinfo(services.settings.display_timezone)
    buf = io.StringIO()
    buf.write("﻿")  # Excel opens UTF-8 correctly
    w = csv.writer(buf, delimiter=";")
    w.writerow(["time", "level", "category", "action", "who", "about", "ticket", "details"])
    for r in rows:
        x = _row(r, names)
        d = {k: v for k, v in x["details"].items() if k != "trace"}
        w.writerow([_cell(c) for c in (as_utc(r.ts).astimezone(tz).strftime("%Y-%m-%d %H:%M:%S"), x["level"], x["category"],
                    x["action"], x["actor_name"] or x["actor_type"], x["agent_name"], x["ticket_id"] or "",
                    "; ".join(f"{k}={v}" for k, v in d.items()))])
    stamp = datetime.now(tz).strftime("%Y%m%d-%H%M")
    return Response(buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="zenith-log-{stamp}.csv"', "Cache-Control": "no-store"})
