"""v3.18 call routing for managers — on top of the routing by level (v3.11):

* overflow (C)   — a queue gets too full (N customers waiting, or one waits X seconds): the chosen groups (Level 2,
                   Level 3, managers) get the first-line penalty in that queue, so Asterisk rings them as well; when the
                   queue is calm again for a while, everything goes back by itself;
* distribution (E) — per queue: round robin / longest idle / fewest calls / all at once (Asterisk ring strategy);
                   applied over AMI (UpdateConfig + QueueReload, needs write = config) when the administrator allows it,
                   and kept: if FreePBX writes its own configuration again, Zenith Desk puts the strategy back;
* VIP / sticky (F) — a customer from a list (a number or a prefix) goes straight to a chosen employee, a free person
                   of a level, or to the operator who talked to him last time (if free): Zenith Desk takes the call
                   out of the queue (AMI Redirect) and rings that person's phone; nobody answers in N seconds → the
                   customer is put back into the queue, he never gets lost.

The rules are kept in the database (system_setting «call_routing», so a backup carries them). Every decision is in the
log (callroute_*).
"""
from __future__ import annotations

import asyncio
import copy
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta

from sqlalchemy import select

from .audit import audit
from .db import as_utc, utcnow
from .i18n import t as tr
from .metrics import STALE_WAIT
from .models import AgentMapping, AgentState, CallRecord, QueueCall, SystemSetting
from .phone import normalize_phone

log = logging.getLogger("call_routing")
KEY = "call_routing"
MODES = ("rrmemory", "leastrecent", "fewestcalls", "ringall")  # «linear» cannot be switched without a restart
GROUPS = ("level2", "level3", "manager")
TARGETS_LEVEL = ("level1", "level2", "level3")
TICK = 2.0           # seconds between checks (overflow, VIP ring timeouts)
STRATEGY_EVERY = 60  # seconds between checks that the strategy in Asterisk is still the chosen one

DEFAULT_QUEUE = {"mode": "", "overflow": {"enabled": False, "waiting": 3, "wait_sec": 60, "add": ["level2"], "calm_sec": 60}}
DEFAULT = {"queues": {}, "vip": {"enabled": False, "ring_sec": 20, "sticky": False, "sticky_days": 30, "rules": []}}


class RoutingError(ValueError):
    pass


def group_of(m: AgentMapping) -> str:
    return m.level if m.level in ("level1", "level2", "level3") else "manager"


def _int(v, lo: int, hi: int, name: str) -> int:
    try:
        x = int(v)
    except (TypeError, ValueError) as exc:
        raise RoutingError(tr("cr.bad_number", name=name)) from exc
    if not lo <= x <= hi:
        raise RoutingError(tr("cr.range", name=name, lo=lo, hi=hi))
    return x


def clean(cfg: dict, queues: list[str], agent_ids: set[int]) -> dict:
    """A validated copy of what the manager sent."""
    out = copy.deepcopy(DEFAULT)
    for q, qc in (cfg.get("queues") or {}).items():
        q = str(q).strip()
        if q not in queues:
            raise RoutingError(tr("cr.unknown_queue", queue=q))
        mode = (qc or {}).get("mode") or ""
        if mode and mode not in MODES:
            raise RoutingError(tr("cr.bad_mode", mode=mode))
        o = {**DEFAULT_QUEUE["overflow"], **((qc or {}).get("overflow") or {})}
        add = [g for g in (o.get("add") or []) if g in GROUPS]
        if o.get("enabled") and not add:
            raise RoutingError(tr("cr.no_groups"))
        out["queues"][q] = {"mode": mode, "overflow": {
            "enabled": bool(o.get("enabled")), "waiting": _int(o.get("waiting"), 1, 500, "N"),
            "wait_sec": _int(o.get("wait_sec"), 0, 3600, "X"), "add": add, "calm_sec": _int(o.get("calm_sec"), 10, 3600, "calm")}}
    v = {**DEFAULT["vip"], **(cfg.get("vip") or {})}
    rules = []
    for r in (v.get("rules") or [])[:500]:
        match = str((r or {}).get("match", "")).strip()
        target = str((r or {}).get("target", "")).strip()
        if not match:
            continue
        digits = "".join(c for c in match.rstrip("*") if c.isdigit())
        if len(digits) < 3:
            raise RoutingError(tr("cr.bad_match", match=match))
        if target.startswith("agent:"):
            try:
                aid = int(target.split(":", 1)[1])
            except ValueError as exc:
                raise RoutingError(tr("cr.bad_target", target=target)) from exc
            if aid not in agent_ids:
                raise RoutingError(tr("cr.bad_target", target=target))
        elif target not in (*TARGETS_LEVEL, "last"):
            raise RoutingError(tr("cr.bad_target", target=target))
        rules.append({"match": match[:40], "target": target, "note": str((r or {}).get("note", ""))[:100]})
    out["vip"] = {"enabled": bool(v.get("enabled")), "ring_sec": _int(v.get("ring_sec"), 5, 120, "ring"),
                  "sticky": bool(v.get("sticky")), "sticky_days": _int(v.get("sticky_days"), 1, 365, "days"), "rules": rules}
    return out


@dataclass
class Pending:
    linkedid: str
    channel: str
    uniqueid: str
    queue: str
    agent_id: int
    deadline: datetime
    reason: str
    answered: bool = False


class CallRouting:
    def __init__(self, services):
        self.sv = services
        self.cfg: dict = copy.deepcopy(DEFAULT)
        self.active: dict[str, datetime] = {}      # queue → overflow on since
        self.calm: dict[str, datetime] = {}        # queue → calm since (while overflow is on)
        self.pending: dict[str, Pending] = {}      # linkedid → a customer ringing a VIP target
        self.routed: dict[str, datetime] = {}      # linkedid → already handled (never twice)
        self.strategy_state: dict[str, dict] = {}  # queue → {"want", "have", "applied_at", "error"}
        self._task: asyncio.Task | None = None
        self._tasks: set[asyncio.Task] = set()
        self._wake = asyncio.Event()
        self._last_strategy = 0.0

    # ------------------------------------------------------------------ the rules
    async def load(self) -> None:
        async with self.sv.db.sessionmaker() as s:
            row = await s.get(SystemSetting, KEY)
        try:
            data = json.loads(row.value) if row and row.value else {}
        except ValueError:
            data = {}
        cfg = copy.deepcopy(DEFAULT)
        cfg["queues"] = {q: {"mode": c.get("mode", ""), "overflow": {**DEFAULT_QUEUE["overflow"], **(c.get("overflow") or {})}}
                         for q, c in (data.get("queues") or {}).items()}
        cfg["vip"] = {**DEFAULT["vip"], **(data.get("vip") or {})}
        self.cfg = cfg

    def queue_cfg(self, q: str) -> dict:
        return self.cfg["queues"].get(q) or copy.deepcopy(DEFAULT_QUEUE)

    async def save(self, cfg: dict, user: AgentMapping) -> dict:
        async with self.sv.db.sessionmaker() as s:
            ids = set((await s.execute(select(AgentMapping.id).where(AgentMapping.active.is_(True)))).scalars().all())
        new = clean(cfg, self.sv.settings.queues, ids)
        old = self.cfg
        async with self.sv.db.sessionmaker() as s:
            row = await s.get(SystemSetting, KEY)
            if row is None:
                row = SystemSetting(key=KEY)
                s.add(row)
            row.value, row.is_secret, row.updated_by = json.dumps(new, ensure_ascii=False), False, user.id
            audit(s, "callroute_changed", actor_type="supervisor", actor_id=user.id,
                  queues={q: {"mode": c["mode"], "overflow": c["overflow"]["enabled"]} for q, c in new["queues"].items()},
                  vip=new["vip"]["enabled"], vip_rules=len(new["vip"]["rules"]), sticky=new["vip"]["sticky"])
            await s.commit()
        self.cfg = new
        # an overflow that was switched off ends now; a new strategy goes to Asterisk now
        for q in list(self.active):
            if not self.queue_cfg(q)["overflow"]["enabled"]:
                await self._overflow_off(q, "rule switched off")
        changed_modes = [q for q, c in new["queues"].items() if c["mode"] and c["mode"] != (old["queues"].get(q) or {}).get("mode")]
        for q in changed_modes:
            await self.apply_strategy(q, user)
        self.kick()
        return new

    # ------------------------------------------------------------------ background
    def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="call-routing")

    async def stop(self) -> None:
        for t in [self._task, *self._tasks]:
            if t:
                t.cancel()
        await asyncio.gather(*[t for t in [self._task, *self._tasks] if t], return_exceptions=True)
        self._task = None
        self._tasks.clear()

    def kick(self) -> None:
        self._wake.set()

    async def _loop(self) -> None:
        while True:
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=TICK)
            except asyncio.TimeoutError:
                pass
            self._wake.clear()
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("call routing check failed")

    async def tick(self, now: datetime | None = None) -> None:
        now = now or utcnow()
        await self.check_overflow(now)
        await self.check_pending(now)
        mono = asyncio.get_running_loop().time()
        if mono - self._last_strategy >= STRATEGY_EVERY:
            self._last_strategy = mono
            await self.keep_strategies()

    def _spawn(self, coro) -> None:
        t = asyncio.create_task(coro)
        self._tasks.add(t)
        t.add_done_callback(self._tasks.discard)

    # ------------------------------------------------------------------ C. overflow
    def boosted(self, m: AgentMapping, queue: str) -> bool:
        """Engine hook: this person rings in the first line of this queue right now (overflow)."""
        if queue not in self.active:
            return False
        return group_of(m) in self.queue_cfg(queue)["overflow"]["add"]

    async def waiting(self, now: datetime) -> dict[str, list[QueueCall]]:
        async with self.sv.db.sessionmaker() as s:
            rows = (await s.execute(select(QueueCall).where(
                QueueCall.outcome == "waiting", QueueCall.answered_at.is_(None), QueueCall.left_at.is_(None),
                QueueCall.joined_at >= now - STALE_WAIT))).scalars().all()
        out: dict[str, list[QueueCall]] = {}
        for r in rows:
            out.setdefault(r.queue or "?", []).append(r)
        return out

    async def check_overflow(self, now: datetime) -> None:
        rules = {q: c["overflow"] for q, c in self.cfg["queues"].items() if c["overflow"]["enabled"]}
        if not rules and not self.active:
            return
        waiting = await self.waiting(now)
        for q, o in rules.items():
            rows = waiting.get(q, [])
            n = len(rows)
            longest = max(((now - as_utc(r.joined_at)).total_seconds() for r in rows), default=0)
            busy = n >= o["waiting"] or (o["wait_sec"] > 0 and n and longest >= o["wait_sec"])
            if q not in self.active:
                if busy:
                    await self._overflow_on(q, n, int(longest), o)
                continue
            if busy:
                self.calm.pop(q, None)
            else:
                since = self.calm.setdefault(q, now)
                if (now - since).total_seconds() >= o["calm_sec"]:
                    await self._overflow_off(q, "calm")

    async def _recompute_groups(self, groups: list[str], cause: str) -> None:
        async with self.sv.db.sessionmaker() as s:
            people = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True)))).scalars().all()
        for m in people:
            if m.asterisk_interface and group_of(m) in groups:
                try:
                    await self.sv.engine.recompute(m.id, cause)
                except Exception:  # noqa: BLE001
                    log.exception("penalty for %s not applied", m.id)

    async def _overflow_on(self, q: str, n: int, longest: int, o: dict) -> None:
        self.active[q] = utcnow()
        self.calm.pop(q, None)
        async with self.sv.db.sessionmaker() as s:
            audit(s, "callroute_overflow_on", level="warning", actor_type="system", queue=q, waiting=n, longest_wait_sec=longest,
                  added=o["add"])
            await s.commit()
        await self._recompute_groups(o["add"], "overflow")
        self.sv.broker.publish_supervisors("alert", {"text": tr("cr.overflow_on", queue=q, n=n, groups=", ".join(tr("cr.g." + g) for g in o["add"])),
                                                    "kind": "routing", "ts": utcnow()})
        self.sv.broker.publish_supervisors("changed", {"topics": ["team"]})

    async def _overflow_off(self, q: str, why: str) -> None:
        since = self.active.pop(q, None)
        self.calm.pop(q, None)
        if since is None:
            return
        groups = list(GROUPS)
        async with self.sv.db.sessionmaker() as s:
            audit(s, "callroute_overflow_off", actor_type="system", queue=q, reason=why,
                  lasted_sec=int((utcnow() - since).total_seconds()))
            await s.commit()
        await self._recompute_groups(groups, "overflow_end")
        self.sv.broker.publish_supervisors("changed", {"topics": ["team"]})

    # ------------------------------------------------------------------ E. distribution (ring strategy)
    async def apply_strategy(self, q: str, user: AgentMapping | None = None) -> dict:
        want = self.queue_cfg(q)["mode"]
        st = self.strategy_state.setdefault(q, {})
        st["want"] = want
        cfg = self.sv.settings
        if not want:
            return st
        if not cfg.routing_strategy_via_ami:
            st["error"] = tr("cr.strategy_manual", queue=q)
            return st
        try:
            await self.sv.pbx.set_strategy(q, want, cfg.routing_queues_file)
            infos = await self.sv.pbx.queue_info([q])
            have = infos[0].strategy if infos else ""
            st.update({"have": have, "applied_at": utcnow(), "error": "" if have == want else tr("cr.strategy_not_taken", have=have)})
        except Exception as exc:  # noqa: BLE001
            st["error"] = str(exc) or type(exc).__name__
        async with self.sv.db.sessionmaker() as s:
            audit(s, "callroute_strategy", level="warning" if st.get("error") else "info",
                  actor_type="supervisor" if user else "system", actor_id=user.id if user else None,
                  queue=q, strategy=want, error=st.get("error", ""))
            await s.commit()
        return st

    async def keep_strategies(self) -> None:
        wanted = {q: c["mode"] for q, c in self.cfg["queues"].items() if c["mode"]}
        if not wanted or not self.sv.pbx.connected:
            return
        try:
            infos = await self.sv.pbx.queue_info(list(wanted))
        except Exception:  # noqa: BLE001
            return
        for info in infos:
            st = self.strategy_state.setdefault(info.queue, {})
            st.update({"want": wanted[info.queue], "have": info.strategy})
            if info.strategy and info.strategy != wanted[info.queue] and self.sv.settings.routing_strategy_via_ami:
                await self.apply_strategy(info.queue)  # FreePBX wrote its own configuration again

    # ------------------------------------------------------------------ F. VIP / the last operator
    def rule_for(self, number: str) -> dict | None:
        kw = {"country_code": self.sv.settings.phone_country_code, "national_prefix": self.sv.settings.phone_national_prefix}
        norm = normalize_phone(number, **kw)
        if not norm:
            return None
        for r in self.cfg["vip"]["rules"]:
            m = r["match"]
            if m.endswith("*"):
                p = normalize_phone(m[:-1], **kw) or "".join(c for c in m[:-1] if c.isdigit())
                if p and norm.startswith(p):
                    return r
            elif normalize_phone(m, **kw) == norm:
                return r
        return None

    async def _free(self, s, agents: list[AgentMapping], now: datetime) -> list[AgentMapping]:
        from .team import live_calls  # noqa: PLC0415
        busy = await live_calls(s, now)
        states = {x.agent_id: x for x in (await s.execute(select(AgentState).where(
            AgentState.agent_id.in_([a.id for a in agents] or [0])))).scalars().all()}
        out = []
        for a in agents:
            st = states.get(a.id)
            if a.active and a.extension and st and st.computed_state == "ready" and not st.dnd and a.id not in busy:
                out.append(a)
        return out

    async def decide(self, number: str, now: datetime | None = None) -> dict:
        """Who this customer should go to right now: {"agent": AgentMapping|None, "reason": str, "rule": dict|None}."""
        now = now or utcnow()
        vip = self.cfg["vip"]
        if not vip["enabled"]:
            return {"agent": None, "reason": "off", "rule": None}
        rule = self.rule_for(number)
        async with self.sv.db.sessionmaker() as s:
            target = rule["target"] if rule else ("last" if vip["sticky"] else "")
            if not target:
                return {"agent": None, "reason": "no_rule", "rule": None}
            candidates: list[AgentMapping] = []
            if target.startswith("agent:"):
                a = await s.get(AgentMapping, int(target.split(":", 1)[1]))
                candidates = [a] if a else []
            elif target in TARGETS_LEVEL:
                candidates = list((await s.execute(select(AgentMapping).where(
                    AgentMapping.level == target, AgentMapping.active.is_(True)))).scalars().all())
            elif target == "last":
                kw = {"country_code": self.sv.settings.phone_country_code, "national_prefix": self.sv.settings.phone_national_prefix}
                norm = normalize_phone(number, **kw)
                last = (await s.execute(select(CallRecord).where(
                    CallRecord.caller_normalized == norm, CallRecord.answered_at.is_not(None), CallRecord.agent_id.is_not(None),
                    CallRecord.started_at >= now - timedelta(days=vip["sticky_days"])).order_by(CallRecord.answered_at.desc()).limit(1))
                ).scalars().first() if len(norm) >= 5 else None
                if last is not None:
                    a = await s.get(AgentMapping, last.agent_id)
                    candidates = [a] if a else []
            if not candidates:
                return {"agent": None, "reason": "nobody", "rule": rule, "target": target}
            free = await self._free(s, candidates, now)
            if target in TARGETS_LEVEL and len(free) > 1:  # the one who has been free the longest gets it
                from .team import state_since  # noqa: PLC0415
                since = await state_since(s, [a.id for a in free], now)
                free.sort(key=lambda a: (since.get(a.id) or now, a.id))
        if not free:
            return {"agent": None, "reason": "busy", "rule": rule, "target": target, "candidates": [c.display_name for c in candidates]}
        return {"agent": free[0], "reason": "rule" if rule else "sticky", "rule": rule, "target": target}

    async def on_event(self, ev: dict) -> None:
        name = ev.get("Event", "")
        if name == "QueueCallerJoin":
            linkedid = ev.get("Linkedid") or ev.get("Uniqueid") or ""
            if linkedid and self.cfg["vip"]["enabled"] and linkedid not in self.routed and linkedid not in self.pending:
                self._spawn(self._route(ev, linkedid))
            if self.cfg["queues"]:
                self.kick()  # overflow reacts at once
        elif name == "DialEnd":
            p = self._pending_by_channel(ev)
            if p is not None:
                if ev.get("DialStatus") == "ANSWER":
                    p.answered = True
                    self.pending.pop(p.linkedid, None)
                    await self._mark_answered(p)
                else:  # busy / no answer / unavailable: back into the queue at once
                    self._spawn(self._back_to_queue(p, ev.get("DialStatus", "").lower() or "no_answer"))
        elif name == "Hangup":
            linkedid = ev.get("Linkedid") or ev.get("Uniqueid") or ""
            p = self.pending.get(linkedid)
            if p is not None and ev.get("Uniqueid") == p.uniqueid:
                self.pending.pop(linkedid, None)  # the customer hung up while it rang

    def _pending_by_channel(self, ev: dict) -> Pending | None:
        ch, uid = ev.get("Channel", ""), ev.get("Uniqueid", "")
        for p in self.pending.values():
            if (ch and ch == p.channel) or (uid and uid == p.uniqueid):
                return p
        return None

    async def _route(self, ev: dict, linkedid: str) -> None:
        number, channel = ev.get("CallerIDNum", ""), ev.get("Channel", "")
        if not channel:
            return
        d = await self.decide(number)
        self.routed[linkedid] = utcnow()
        if len(self.routed) > 5000:
            cut = utcnow() - timedelta(hours=6)
            self.routed = {k: v for k, v in self.routed.items() if v > cut}
        if d["agent"] is None:
            if d["reason"] in ("busy", "nobody") and d.get("rule"):
                async with self.sv.db.sessionmaker() as s:
                    audit(s, "callroute_vip", actor_type="system", number=number, queue=ev.get("Queue", ""), target=d.get("target"),
                          result="queue", reason=d["reason"], note=(d.get("rule") or {}).get("note", ""))
                    await s.commit()
            return
        a: AgentMapping = d["agent"]
        cfg = self.sv.settings
        try:
            await self.sv.pbx.redirect(channel, cfg.routing_dial_context, a.extension)
        except Exception as exc:  # noqa: BLE001 — the customer simply stays in the queue
            log.warning("VIP redirect of %s failed: %s", number, exc)
            return
        p = Pending(linkedid=linkedid, channel=channel, uniqueid=ev.get("Uniqueid", ""), queue=ev.get("Queue", ""), agent_id=a.id,
                    deadline=utcnow() + timedelta(seconds=self.cfg["vip"]["ring_sec"]), reason=d["reason"])
        self.pending[linkedid] = p
        async with self.sv.db.sessionmaker() as s:
            row = (await s.execute(select(QueueCall).where(QueueCall.linkedid == linkedid))).scalars().first()
            if row is not None and row.answered_at is None:
                row.outcome, row.left_at = "redirected", utcnow()
            audit(s, "callroute_vip", agent_id=a.id, actor_type="system", number=number, queue=p.queue, target=d.get("target"),
                  result="redirected", reason=d["reason"], name=a.display_name, note=(d.get("rule") or {}).get("note", ""))
            await s.commit()

    async def check_pending(self, now: datetime) -> None:
        for p in [p for p in self.pending.values() if not p.answered and now >= p.deadline]:
            await self._back_to_queue(p, "timeout")

    async def _back_to_queue(self, p: Pending, why: str) -> None:
        if self.pending.pop(p.linkedid, None) is None:
            return
        cfg = self.sv.settings
        try:
            await self.sv.pbx.redirect(p.channel, cfg.routing_queue_context, p.queue)
        except Exception as exc:  # noqa: BLE001
            log.warning("VIP customer could not be put back into queue %s: %s", p.queue, exc)
        async with self.sv.db.sessionmaker() as s:
            audit(s, "callroute_vip_back", agent_id=p.agent_id, actor_type="system", queue=p.queue, reason=why)
            await s.commit()

    async def _mark_answered(self, p: Pending) -> None:
        now = utcnow()
        async with self.sv.db.sessionmaker() as s:
            row = (await s.execute(select(QueueCall).where(QueueCall.linkedid == p.linkedid))).scalars().first()
            if row is not None and row.answered_at is None:
                row.answered_at, row.outcome, row.agent_id = now, "answered", p.agent_id
                row.wait_sec = int((now - as_utc(row.joined_at)).total_seconds())
            await s.commit()

    # ------------------------------------------------------------------ the page
    async def view(self) -> dict:
        cfg = self.sv.settings
        queues = []
        waiting = await self.waiting(utcnow())
        infos = {}
        if self.sv.pbx.connected and cfg.queues:
            try:
                infos = {i.queue: i for i in await self.sv.pbx.queue_info(cfg.queues)}
            except Exception:  # noqa: BLE001
                infos = {}
        for q in cfg.queues:
            c = self.queue_cfg(q)
            st = self.strategy_state.get(q, {})
            queues.append({"queue": q, "mode": c["mode"], "overflow": c["overflow"],
                           "overflow_active_since": self.active.get(q), "waiting": len(waiting.get(q, [])),
                           "strategy_now": infos[q].strategy if q in infos else st.get("have", ""),
                           "strategy_error": st.get("error", ""), "strategy_applied_at": st.get("applied_at")})
        async with self.sv.db.sessionmaker() as s:
            people = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True), AgentMapping.role != "admin")
                                      .order_by(AgentMapping.display_name))).scalars().all()
        return {"queues": queues, "vip": self.cfg["vip"], "modes": list(MODES), "groups": list(GROUPS),
                "level_routing": cfg.level_routing, "strategy_via_ami": cfg.routing_strategy_via_ami,
                "pending": [{"linkedid": p.linkedid, "agent_id": p.agent_id, "queue": p.queue, "deadline": p.deadline}
                            for p in self.pending.values()],
                "agents": [{"id": a.id, "name": a.display_name, "level": a.level, "extension": a.extension} for a in people]}
