"""Full release check — run before every new version.

    python -m scripts.release_check                       # SQLite only
    TEST_DATABASE_URL=postgresql+asyncpg://u:p@localhost/db python -m scripts.release_check

Steps:
  1. unit + integration tests (pytest) on SQLite
  2. the same tests on PostgreSQL (if TEST_DATABASE_URL is set)
  3. Alembic migrations: upgrade -> check -> downgrade -> upgrade (if TEST_DATABASE_URL is set)
  4. demo server + end-to-end browser test of every UI function, in both interface styles (needs playwright)
  5. v3.10: backup page in the browser (live restore) and backup / restore on the real PostgreSQL stack
"""
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY = sys.executable
results: list[tuple[str, str]] = []


def run(name: str, cmd: list[str], env: dict | None = None) -> bool:
    print(f"\n=== {name} ===", flush=True)
    r = subprocess.run(cmd, cwd=ROOT, env={**os.environ, **(env or {})})
    results.append((name, "PASS" if r.returncode == 0 else "FAIL"))
    return r.returncode == 0


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def main() -> int:
    run("Tests on SQLite", [PY, "-m", "pytest", "-q"], {"TEST_DATABASE_URL": ""})

    pg = os.environ.get("TEST_DATABASE_URL", "")
    if pg:
        run("Tests on PostgreSQL", [PY, "-m", "pytest", "-q"])
        env = {"DATABASE_URL": pg, "ZD_ENV": "development"}  # v3.20.2: the test database uses test credentials
        reset = [PY, "-c", (
            "import asyncio,sys;from sqlalchemy.ext.asyncio import create_async_engine;from sqlalchemy import text\n"
            "async def m():\n e=create_async_engine(sys.argv[1])\n async with e.begin() as c:\n"
            "  await c.execute(text('DROP SCHEMA public CASCADE'));await c.execute(text('CREATE SCHEMA public'))\n"
            " await e.dispose()\nasyncio.run(m())"), pg]
        ok = run("DB reset", reset)
        ok = ok and run("Migrations: upgrade head", [PY, "-m", "alembic", "upgrade", "head"], env)
        ok = ok and run("Migrations: model matches schema", [PY, "-m", "alembic", "check"], env)
        ok = ok and run("Migrations: downgrade base", [PY, "-m", "alembic", "downgrade", "base"], env)
        ok and run("Migrations: upgrade again", [PY, "-m", "alembic", "upgrade", "head"], env)
        if shutil.which("psql"):  # v3.10: two real servers with different keys, restore over HTTP, CLI restore
            base = pg.replace("+asyncpg", "").rsplit("/", 1)[0]
            run("Backup / restore on the real stack (PostgreSQL, Alembic, uvicorn, other JWT_SECRET, CLI)",
                [PY, "tests/realstack/backup_pg.py", base])
    else:
        results.append(("PostgreSQL tests and migrations", "SKIPPED (set TEST_DATABASE_URL)"))

    try:
        import playwright  # noqa: F401
    except ImportError:
        results.append(("End-to-end UI test", "SKIPPED (pip install playwright && playwright install chromium)"))
    else:
        # v3.12: the whole UI test runs on a fresh demo for every interface style — Classic, Studio and (v3.16) Flow
        for style, title in (("classic", "End-to-end UI test (all functions)"),
                             ("studio", "End-to-end UI test (all functions) — interface style Studio"),
                             ("flow", "End-to-end UI test (all functions) — interface style Flow")):
            port = free_port()
            print(f"\n=== Starting demo server on port {port} ({style}) ===", flush=True)
            tmpdb = os.path.join(__import__("tempfile").mkdtemp(), "demo.db")
            demo = subprocess.Popen([PY, "-c", f"import uvicorn; from scripts.demo import build; uvicorn.run(build(), host='127.0.0.1', port={port}, log_level='warning')"],
                                    cwd=ROOT, env={**os.environ, "DEMO_DB": tmpdb})
            try:
                for _ in range(60):
                    try:
                        urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1)
                        break
                    except Exception:  # noqa: BLE001
                        time.sleep(0.5)
                shots = os.environ.get("E2E_SCREENSHOTS", "") if style == "classic" else ""
                run(title, [PY, "tests/e2e_ui.py", f"http://127.0.0.1:{port}"] + ([shots] if shots else []), env={"ZD_STYLE": style})
            finally:
                demo.terminate()
                demo.wait(10)
        # v3.10: the Backup page on a fresh demo (it restores the whole demo system, so it gets its own one)
        port = free_port()
        tmpdb = os.path.join(__import__("tempfile").mkdtemp(), "demo.db")
        demo = subprocess.Popen([PY, "-c", f"import uvicorn; from scripts.demo import build; uvicorn.run(build(), host='127.0.0.1', port={port}, log_level='warning')"],
                                cwd=ROOT, env={**os.environ, "DEMO_DB": tmpdb})
        try:
            for _ in range(60):
                try:
                    urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1)
                    break
                except Exception:  # noqa: BLE001
                    time.sleep(0.5)
            run("Backup page: schedule, create, check, download, upload, live restore in the browser",
                [PY, "tests/e2e_backup.py", f"http://127.0.0.1:{port}"] + ([shots] if shots else []))
        finally:
            demo.terminate()
            demo.wait(10)
        run("Phone: WebRTC engine against a SIP server (register, calls, hold, DTMF, transfer)", [PY, "tests/e2e_phone.py"])
        if shutil.which("asterisk") and not os.environ.get("SKIP_ASTERISK"):  # v3.9: a real Asterisk 20, not a simulator
            run("Real Asterisk 20: AMI pause sync, restart recovery, PJSIP WebRTC phone, queue call, recording, call supervision", [PY, "tests/realstack/asterisk_e2e.py"])
            run("Real Asterisk 20: call routing by level (L1 → next L1 → L2 → L3, breaks, level change)", [PY, "tests/realstack/routing_e2e.py"])
            run("Real Asterisk 20: manager call routing (distribution per queue, VIP direct + back to the queue, overflow)", [PY, "tests/realstack/callrouting_e2e.py"])
        if shutil.which("mono") and shutil.which("mcs") and shutil.which("x86_64-w64-mingw32-windres") and not os.environ.get("SKIP_WINDOWS"):
            run("Windows: setup wizard, silent install / removal, connection test, program window (Mono)", ["sh", "windows/tests/run_tests.sh"])

    print("\n================ RELEASE CHECK ================")
    for name, status in results:
        print(f"  {status:<8} {name}")
    failed = [n for n, st in results if st == "FAIL"]
    print("RESULT:", "FAILED" if failed else "ALL CHECKS PASSED")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
