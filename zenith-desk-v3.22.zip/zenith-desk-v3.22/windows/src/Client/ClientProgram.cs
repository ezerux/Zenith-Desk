using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("Zenith Desk")]
[assembly: System.Reflection.AssemblyProduct("Zenith Desk")]
[assembly: System.Reflection.AssemblyCompany("Zenith Desk")]
[assembly: System.Reflection.AssemblyVersion("3.11.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("3.11.0.0")]
[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]

namespace ZenithDesk.Client
{
    /// <summary>
    /// ZenithDesk.exe — the operator's desktop program: a window with the Zenith Desk workplace (sign-in page first).
    ///   /settings   open "Server settings" (Start menu shortcut)
    ///   /autostart  started with Windows
    /// </summary>
    public static class ClientProgram
    {
        public static bool AutoStart, SettingsOnly, DevTools;

        [STAThread]
        public static int Main(string[] argv)
        {
            foreach (var a in argv)
            {
                var k = a.TrimStart('/', '-').ToLowerInvariant();
                if (k == "autostart") AutoStart = true;
                if (k == "settings") SettingsOnly = true;
                if (k == "devtools") DevTools = true;
                if (k.StartsWith("lang=")) Lang.Code = k.EndsWith("en") ? "en" : "ru";
            }
            Log.FilePath = Path.Combine(AppInfo.UserLocalAppData, AppInfo.Product, "client.log");
            Log.Write("==== Zenith Desk " + AppInfo.Version + " " + string.Join(" ", argv));
            Ui.Prepare();
            AppDomain.CurrentDomain.UnhandledException += (s, e) => Log.Write("UNHANDLED " + e.ExceptionObject);
            Application.ThreadException += (s, e) => Log.Error("ui thread", e.Exception);

            if (SettingsOnly)
            {
                using (var f = new SettingsForm(ServerConfig.Load())) { f.StartPosition = FormStartPosition.CenterScreen; f.ShowInTaskbar = true; f.ShowDialog(); }
                Activate();   // a running window picks up the new server
                return 0;
            }

            bool first;
            using (var mutex = new Mutex(true, Name("ZenithDesk.Client"), out first))
            {
                if (!first) { Activate(); return 0; }   // one window per user: bring the existing one to the front
                using (var signal = new EventWaitHandle(false, EventResetMode.AutoReset, Name("ZenithDesk.Activate")))
                using (var form = new MainForm())
                {
                    var t = new Thread(() => { while (true) { signal.WaitOne(); try { form.BeginInvoke((Action)form.ShowFromOtherInstance); } catch { return; } } }) { IsBackground = true };
                    t.Start();
                    Application.Run(form);
                }
            }
            return 0;
        }

        static string Name(string n) { return (AppInfo.IsWindows ? @"Local\" : "") + n + (AppInfo.IsTest ? "." + Path.GetFileName(AppInfo.TestRoot.TrimEnd('/')) : ""); }

        static void Activate()
        {
            try { using (var e = EventWaitHandle.OpenExisting(Name("ZenithDesk.Activate"))) e.Set(); } catch { /* not running */ }
        }
    }
}
