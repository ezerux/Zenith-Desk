// Tests of the Windows programs (setup wizard, silent install / removal, connection test, shortcuts, client window).
// Runs under Mono + Xvfb on the build machine: tests/run_tests.sh. Screenshots go to build/shots/.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZenithDesk;
using ZenithDesk.Setup;

public static class WinTests
{
    static int passed, failed;
    static string Root, Setup, ClientExe, Shots, Demo = "127.0.0.1", DemoPort = "8123";
    // the version the test server reports (VERSION of the repository): the app works with a newer server too
    static readonly string ServerVersion = System.IO.File.Exists("../VERSION") ? System.IO.File.ReadAllText("../VERSION").Trim() : AppInfo.ShortVersion;
    static readonly List<string> Failures = new List<string>();

    static void Expect(bool ok, string what) { if (!ok) throw new Exception(what); }

    static void Test(string name, Action a)
    {
        try { a(); passed++; Console.WriteLine("  PASS  " + name); }
        catch (Exception e) { failed++; Failures.Add(name); Console.WriteLine("  FAIL  " + name + ": " + (e.InnerException ?? e).Message); }
    }

    static async Task TestAsync(string name, Func<Task> a)
    {
        try { await a(); passed++; Console.WriteLine("  PASS  " + name); }
        catch (Exception e) { failed++; Failures.Add(name); Console.WriteLine("  FAIL  " + name + ": " + (e.InnerException ?? e).Message + "\n" + e.StackTrace); }
    }

    static string UseRoot(string name)
    {
        var r = Path.Combine(Root, name);
        if (Directory.Exists(r)) Directory.Delete(r, true);
        Directory.CreateDirectory(r);
        Environment.SetEnvironmentVariable("ZD_TEST_ROOT", r);
        return r;
    }

    static int RunSetup(string root, string args, Dictionary<string, string> env = null)
    {
        var psi = new ProcessStartInfo("mono", "\"" + Setup + "\" " + args) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
        psi.EnvironmentVariables["ZD_TEST_ROOT"] = root;
        psi.EnvironmentVariables["ZD_FAKE_WEBVIEW2"] = "";
        if (env != null) foreach (var kv in env) psi.EnvironmentVariables[kv.Key] = kv.Value;
        using (var p = Process.Start(psi))
        {
            p.StandardOutput.ReadToEnd(); p.StandardError.ReadToEnd();
            p.WaitForExit(120000);
            return p.ExitCode;
        }
    }

    static ServerConfig Cfg(string host, int port, bool https = false, string thumb = "")
    {
        return new ServerConfig { Host = host, Port = port, Https = https, CertThumbprint = thumb };
    }

    [STAThread]
    public static int Main(string[] argv)
    {
        Root = Path.GetFullPath(argv[0]); Setup = Path.GetFullPath(argv[1]); ClientExe = Path.GetFullPath(argv[2]); Shots = Path.GetFullPath(argv[3]);
        var certThumb = argv.Length > 4 ? argv[4] : "";
        Directory.CreateDirectory(Shots);
        Lang.Code = "ru";
        Ui.Prepare();
        Console.WriteLine("== logic");

        Test("Every text exists in Russian and English with the same placeholders", () => {
            foreach (var k in Lang.Keys)
            {
                var v = Lang.Raw(k);
                Expect(v.Length == 2 && v[0].Length > 0 && v[1].Length > 0, "empty text " + k);
                for (int i = 0; i < 4; i++) Expect(v[0].Contains("{" + i + "}") == v[1].Contains("{" + i + "}"), "placeholders differ in " + k);
            }
        });

        Test("Server address: IP, name, IPv6, pasted URL, bad input", () => {
            Func<string, string, bool, string> n = (h, p, s) => { string e; return ServerConfig.Normalize(ref h, ref p, ref s, out e) ? h + "|" + p + "|" + s : "ERR:" + e; };
            Expect(n("192.168.1.10", "8000", false) == "192.168.1.10|8000|False", "ip");
            Expect(n(" pbx.company.local ", "443", true) == "pbx.company.local|443|True", "name");
            Expect(n("http://10.0.0.5:8080/", "8000", false) == "10.0.0.5|8080|False", "pasted http url");
            Expect(n("https://desk.company.ru/login", "8000", false) == "desk.company.ru|8000|True", "pasted https url");
            Expect(n("10.0.0.5:9000", "8000", false) == "10.0.0.5|9000|False", "host:port");
            Expect(n("fe80::1", "8000", false) == "fe80::1|8000|False", "ipv6");
            Expect(n("[fe80::1]:8001", "", false) == "fe80::1|8001|False", "[ipv6]:port");
            Expect(n("", "8000", false) == "ERR:invalid", "empty");
            Expect(n("my server", "8000", false) == "ERR:invalid", "space");
            Expect(n("10.0.0.5", "0", false) == "ERR:port" && n("10.0.0.5", "70000", false) == "ERR:port" && n("10.0.0.5", "abc", false) == "ERR:port", "ports");
            Expect(Cfg("10.0.0.5", 8000).BaseUrl == "http://10.0.0.5:8000/" && Cfg("d.local", 443, true).BaseUrl == "https://d.local/" && Cfg("fe80::1", 8000).BaseUrl == "http://[fe80::1]:8000/", "base url");
        });

        Console.WriteLine("== test connection");
        ConnectionTester.TimeoutMs = 2500;
        Test("Zenith Desk server answers: OK with version", () => {
            var r = ConnectionTester.Test(Cfg(Demo, int.Parse(DemoPort)));
            Expect(r.Ok && !r.Warning && r.Version == ServerVersion, r.ToString());
        });
        Test("Nothing listens on the port: 'connection refused' explained", () => { var r = ConnectionTester.Test(Cfg(Demo, 1)); Expect(r.Code == TestCode.Refused && r.Detail.Contains("1"), r.ToString()); });
        Test("Another web program on that port: 'not a Zenith Desk server'", () => { var r = ConnectionTester.Test(Cfg(Demo, 8901)); Expect(r.Code == TestCode.NotZenith, r.ToString()); });
        Test("Server answers nothing: timeout explained", () => { var r = ConnectionTester.Test(Cfg(Demo, 8905)); Expect(r.Code == TestCode.Timeout, r.ToString()); });
        Test("Unknown server name: 'server not found'", () => { var r = ConnectionTester.Test(Cfg("zenith-no-such-host.invalid", 8000)); Expect(r.Code == TestCode.DnsFailed, r.ToString()); });
        Test("HTTPS ticked for a plain HTTP port: explained", () => { var r = ConnectionTester.Test(Cfg(Demo, int.Parse(DemoPort), true)); Expect(r.Code == TestCode.TlsFailed, r.ToString()); });
        Test("Server redirects to HTTPS / says HTTPS required: explained", () => {
            var a = ConnectionTester.Test(Cfg(Demo, 8902)); var b = ConnectionTester.Test(Cfg(Demo, 8904));
            Expect(a.Code == TestCode.HttpsRequired && b.Code == TestCode.HttpsRequired, a + " / " + b);
        });
        Test("Server without its database: connected with a warning", () => { var r = ConnectionTester.Test(Cfg(Demo, 8903)); Expect(r.Ok && r.Warning && r.Detail.Contains("баз"), r.ToString()); });
        Test("Server error 500 explained", () => { var r = ConnectionTester.Test(Cfg(Demo, 8906)); Expect(r.Code == TestCode.ServerError && r.Detail.Contains("500"), r.ToString()); });
        Test("Self-signed HTTPS certificate: refused until the user trusts it, then OK", () => {
            var r = ConnectionTester.Test(Cfg(Demo, 8443, true));
            Expect(r.Code == TestCode.CertUntrusted && r.CertThumbprint.Length == 40, r.ToString());
            if (certThumb.Length > 0) Expect(string.Equals(r.CertThumbprint, certThumb, StringComparison.OrdinalIgnoreCase), "thumbprint " + r.CertThumbprint + " != " + certThumb);
            var ok = ConnectionTester.Test(Cfg(Demo, 8443, true, r.CertThumbprint));
            Expect(ok.Ok && ok.Version == AppInfo.ShortVersion, ok.ToString());
        });

        Console.WriteLine("== configuration and shortcuts");
        Test("Server settings are saved and read back; the newer of computer / user wins", () => {
            UseRoot("config");
            Expect(!ServerConfig.Load().IsSet, "empty at first");
            var m = Cfg("10.0.0.5", 8000); m.TestedAt = "2026-10-01T10:00:00Z"; m.ServerVersion = "3.8"; m.Save(ServerConfig.MachineFile);
            Expect(ServerConfig.Load().Host == "10.0.0.5", "machine config");
            var u = Cfg("10.0.0.9", 8443, true, "ABCD"); u.TestedAt = "2026-10-05T10:00:00Z"; u.Save(ServerConfig.UserFile);
            var l = ServerConfig.Load(); Expect(l.Host == "10.0.0.9" && l.Https && l.Port == 8443 && l.CertThumbprint == "ABCD", "user override");
            m.TestedAt = "2026-10-09T10:00:00Z"; m.Save(ServerConfig.MachineFile);
            Expect(ServerConfig.Load().Host == "10.0.0.5", "a later re-install wins over an old personal setting");
            Expect(!File.Exists(ServerConfig.MachineFile + ".tmp"), "temp file left");
        });
        Test("Shortcut file (.lnk) is written in the Windows format", () => {
            var dir = UseRoot("lnk");
            File.WriteAllBytes(Path.Combine(dir, "manual.lnk"), Shortcuts.ManagedLink(@"C:\Program Files\Zenith Desk\ZenithDesk.exe", "/settings", @"C:\Program Files\Zenith Desk", "Zenith Desk — подключение к серверу", @"C:\Program Files\Zenith Desk\ZenithDesk.exe"));
            Expect(new FileInfo(Path.Combine(dir, "manual.lnk")).Length > 200, "lnk size");
        });

        Console.WriteLine("== silent installation (administrators)");
        string silentRoot = Path.Combine(Root, "silent");
        Test("Silent install /S: Microsoft component, files, server, shortcuts, Installed apps, autostart", () => {
            UseRoot("silent");
            var code = RunSetup(silentRoot, "/S /LANG=ru /SERVER=" + Demo + " /PORT=" + DemoPort + " /AUTOSTART /LOG=\"" + Path.Combine(silentRoot, "setup.log") + "\"");
            Expect(code == 0, "exit code " + code + "\n" + SafeRead(Path.Combine(silentRoot, "setup.log")));
            var dir = Path.Combine(AppInfo.ProgramFiles, "Zenith Desk");
            foreach (var f in new[] { "ZenithDesk.exe", "ZenithDesk.exe.config", "Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll", "WebView2Loader.dll",
                                      "runtimes/win-x64/native/WebView2Loader.dll", "runtimes/win-arm64/native/WebView2Loader.dll", "THIRD-PARTY-NOTICES.txt", "uninstall.exe" })
                Expect(File.Exists(Path.Combine(dir, f)), "missing " + f);
            var cfg = ServerConfig.LoadFile(ServerConfig.MachineFile);
            Expect(cfg != null && cfg.Host == Demo && cfg.Port == int.Parse(DemoPort) && cfg.ServerVersion == ServerVersion && cfg.TestedAt.Length > 0, "server.json");
            Expect(File.Exists(Path.Combine(AppInfo.CommonDesktop, "Zenith Desk.lnk")), "desktop shortcut");
            Expect(File.Exists(Path.Combine(AppInfo.StartMenuDir, "Zenith Desk.lnk")) && Directory.GetFiles(AppInfo.StartMenuDir, "*.lnk").Length == 2, "start menu shortcuts");
            var inst = Installed.Read();
            Expect(inst != null && inst.Version == AppInfo.Version && inst.AutoRun && Path.GetFullPath(inst.Dir) == Path.GetFullPath(dir), "Installed apps / autostart");
            using (var root = AppInfo.MachineRoot(false))
            using (var k = root.OpenSubKey(AppInfo.UninstallKeyPath))
            {
                Expect(k.GetValue("DisplayName").ToString() == "Zenith Desk" && k.GetValue("Publisher").ToString() == "Zenith Desk", "names");
                Expect(k.GetValue("UninstallString").ToString().Contains("uninstall.exe\" /uninstall") && k.GetValue("QuietUninstallString").ToString().EndsWith("/uninstall /S"), "uninstall strings");
                Expect(Convert.ToInt32(k.GetValue("EstimatedSize")) > 500, "size");
            }
            Expect(SafeRead(Path.Combine(silentRoot, "setup.log")).Contains("Microsoft Edge WebView2 Runtime"), "WebView2 was not installed");
        });
        Test("Silent install with a wrong server: refused (exit 2), nothing installed", () => {
            var r = UseRoot("silent-bad");
            var code = RunSetup(r, "/S /SERVER=" + Demo + " /PORT=1");
            Expect(code == 2, "exit code " + code);
            Expect(!Directory.Exists(Path.Combine(AppInfo.ProgramFiles, "Zenith Desk")) && Installed.Read() == null, "something was installed");
            Expect(RunSetup(r, "/S") == 2, "no /SERVER must fail too");
        });
        Test("Silent install without administrator rights: exit 4", () => {
            var r = UseRoot("silent-noadmin");
            Expect(RunSetup(r, "/S /SERVER=" + Demo + " /PORT=" + DemoPort, new Dictionary<string, string> { { "ZD_FAKE_NOADMIN", "1" } }) == 4, "exit code");
        });
        Test("Silent update keeps the server and the folder; settings survive", () => {
            Environment.SetEnvironmentVariable("ZD_TEST_ROOT", silentRoot);
            File.AppendAllText(Path.Combine(AppInfo.ProgramFiles, "Zenith Desk", "ZenithDesk.exe"), "old");  // pretend an old file
            using (var root = AppInfo.MachineRoot(true)) using (var k = root.CreateSubKey(AppInfo.UninstallKeyPath)) k.SetValue("DisplayVersion", "3.7.0");
            var code = RunSetup(silentRoot, "/S /LANG=ru");
            Expect(code == 0, "exit code " + code);
            Expect(Installed.Read().Version == AppInfo.Version && Installed.Read().AutoRun, "version / autostart kept");
            Expect(ServerConfig.LoadFile(ServerConfig.MachineFile).Host == Demo, "server kept");
        });
        Test("Silent removal: program, shortcuts, Installed apps and autostart gone; settings kept unless /REMOVEDATA", () => {
            Environment.SetEnvironmentVariable("ZD_TEST_ROOT", silentRoot);
            var code = RunSetup(silentRoot, "/uninstall /S");
            Expect(code == 0, "exit code " + code);
            Expect(!Directory.Exists(Path.Combine(AppInfo.ProgramFiles, "Zenith Desk")), "program folder left");
            Expect(!File.Exists(Path.Combine(AppInfo.CommonDesktop, "Zenith Desk.lnk")) && !Directory.Exists(AppInfo.StartMenuDir), "shortcuts left");
            Expect(Installed.Read() == null, "still in Installed apps");
            using (var root = AppInfo.MachineRoot(false)) using (var run = root.OpenSubKey(AppInfo.RunKeyPath)) Expect(run == null || run.GetValue(AppInfo.RunValueName) == null, "autostart left");
            Expect(File.Exists(ServerConfig.MachineFile), "settings should stay");
            Expect(RunSetup(silentRoot, "/S /SERVER=" + Demo + " /PORT=" + DemoPort) == 0, "reinstall");
            Expect(RunSetup(silentRoot, "/uninstall /S /REMOVEDATA") == 0 && !Directory.Exists(AppInfo.MachineDataDir), "settings not removed");
        });

        Console.WriteLine("== installation wizard and the program window (GUI)");
        var host = new Form { ShowInTaskbar = false, Opacity = 0, Size = new Size(1, 1), StartPosition = FormStartPosition.Manual, Location = new Point(-50, -50) };
        bool guiDone = false;
        host.Shown += async (s, e) => { await Gui(); guiDone = true; host.Close(); };
        Application.Run(host);
        if (!guiDone) { failed++; Failures.Add("GUI tests stopped early"); Console.WriteLine("  FAIL  GUI tests stopped early"); }

        Console.WriteLine();
        Console.WriteLine("WINDOWS TESTS: " + passed + "/" + (passed + failed) + " passed");
        if (failed > 0) Console.WriteLine("FAILED: " + string.Join("; ", Failures));
        return failed == 0 ? 0 : 1;
    }

    static string SafeRead(string f) { try { return File.ReadAllText(f); } catch { return ""; } }

    // ------------------------------------------------------------------ GUI helpers
    static async Task Until(Func<bool> cond, int ms, string what)
    {
        var sw = Stopwatch.StartNew();
        while (!cond()) { if (sw.ElapsedMilliseconds > ms) throw new Exception("timeout: " + what); await Task.Delay(50); }
    }

    static int shotNo;
    static async Task Shot(Form f, string name)
    {
        f.Activate(); f.Refresh(); await Task.Delay(250); Application.DoEvents();
        var p = f.PointToScreen(Point.Empty);
        var file = Path.Combine(Shots, (++shotNo).ToString("00") + "-" + name + ".png");
        var psi = new ProcessStartInfo("import", "-window root -crop " + f.ClientSize.Width + "x" + f.ClientSize.Height + "+" + p.X + "+" + p.Y + " +repage \"" + file + "\"") { UseShellExecute = false };
        using (var pr = Process.Start(psi)) pr.WaitForExit(15000);
    }

    static T Find<T>(Control root, string name) where T : Control
    {
        var c = root.Controls.Find(name, true).OfType<T>().FirstOrDefault();
        if (c == null) throw new Exception("control not found: " + name);
        return c;
    }

    static async Task Next(WizardForm w) { Expect(w.NextBtn.Enabled, "Next is disabled on " + w.Page.GetType().Name); w.NextBtn.PerformClick(); await Task.Delay(150); }

    static async Task Gui()
    {
        await TestAsync("Language choice at the start (Russian / English)", async () => {
            using (var lf = new LanguageForm())
            {
                lf.Show(); await Shot(lf, "setup-language");
                Expect(lf.Chosen == "ru", "default language");
                lf.Combo.SelectedIndex = 1; Expect(lf.Chosen == "en", "english");
                lf.Close();
            }
        });

        var guiRoot = UseRoot("gui");
        await TestAsync("Wizard: welcome → license → components → system check → server (test is mandatory) → install → finish", async () => {
            var st = SetupProgram.NewState(false);
            WizardForm.QuietClose = true;
            var w = SetupProgram.CreateWizard(st);
            w.Show();
            await Until(() => w.Page is WelcomePage, 2000, "welcome");
            Expect(!w.BackBtn.Enabled, "Back on the first page");
            await Shot(w, "setup-welcome");
            await Next(w);
            Expect(w.Page is LicensePage && !w.NextBtn.Enabled, "license must be accepted first");
            Find<RadioButton>(w, "accept").Checked = true; await Task.Delay(100);
            await Shot(w, "setup-license");
            await Next(w);
            Expect(w.Page is ComponentsPage, "components");
            Find<CheckBox>(w, "comp.autorun").Checked = true;
            Expect(Find<TextBox>(w, "folder").Text.EndsWith("Zenith Desk"), "default folder");
            await Shot(w, "setup-components");
            await Next(w);
            Expect(w.Page is PrereqPage, "system check");
            await Until(() => w.NextBtn.Enabled, 8000, "checks");
            Expect(Find<Label>(w, "prereq_detail2").Text.Contains("будет загружен"), "WebView2 missing must say it will be downloaded: " + Find<Label>(w, "prereq_detail2").Text);
            await Shot(w, "setup-system-check");
            await Next(w);
            var sp = (ServerPage)w.Page;
            Expect(!w.NextBtn.Enabled, "Next must wait for the connection test");
            await Shot(w, "setup-server-empty");
            sp.Panel.HostBox.Text = Demo; sp.Panel.PortBox.Text = "1";
            sp.Panel.TestButton.PerformClick();
            await Until(() => sp.Panel.LastResult != null && sp.Panel.TestButton.Enabled, 10000, "test 1");
            Expect(!w.NextBtn.Enabled && sp.Panel.LastResult.Code == TestCode.Refused, "wrong port must block: " + sp.Panel.LastResult);
            await Shot(w, "setup-server-error");
            sp.Panel.HostBox.Text = "http://" + Demo + ":" + DemoPort + "/";   // pasted URL is tidied up
            sp.Panel.TestButton.PerformClick();
            await Until(() => sp.Panel.LastResult != null && sp.Panel.TestButton.Enabled, 10000, "test 2");
            Expect(sp.Panel.Passed && w.NextBtn.Enabled, "test passed: " + sp.Panel.LastResult);
            Expect(sp.Panel.HostBox.Text == Demo && sp.Panel.PortBox.Text == DemoPort, "pasted URL split into host and port");
            await Shot(w, "setup-server-ok");
            sp.Panel.PortBox.Text = "8124"; await Task.Delay(100);
            Expect(!w.NextBtn.Enabled, "changing the port must require a new test");
            sp.Panel.PortBox.Text = DemoPort; sp.Panel.TestButton.PerformClick();
            await Until(() => sp.Panel.Passed, 10000, "test 3");
            await Next(w);
            Expect(w.Page is ReadyPage && w.NextBtn.Text == Lang.T("btn.install"), "ready page");
            Expect(Find<TextBox>(w, "summary").Text.Contains("WebView2") && Find<TextBox>(w, "summary").Text.Contains(DemoPort), "summary");
            await Shot(w, "setup-ready");
            await Next(w);
            Expect(w.Page is ProgressPage, "progress");
            await Task.Delay(200); await Shot(w, "setup-installing");
            await Until(() => w.Page is FinishPage, 30000, "finish");
            Expect(st.Outcome.Success, "install failed: " + st.Outcome.Error);
            Expect(!w.BackBtn.Visible && w.NextBtn.Text == Lang.T("btn.finish"), "finish buttons");
            await Shot(w, "setup-finish");
            Expect(File.Exists(Path.Combine(AppInfo.ProgramFiles, "Zenith Desk", "ZenithDesk.exe")) && File.Exists(Path.Combine(AppInfo.CommonDesktop, "Zenith Desk.lnk")), "installed files");
            Expect(Installed.Read() != null && Installed.Read().AutoRun, "registered");
            Find<CheckBox>(w, "launch").Checked = false;
            w.NextBtn.PerformClick();
            await Until(() => !w.Visible || w.IsDisposed, 3000, "close");
            Expect(st.ExitCode == 0, "exit code " + st.ExitCode);
        });

        await TestAsync("Wizard again on the same version: Repair / Remove; Remove takes everything away", async () => {
            Environment.SetEnvironmentVariable("ZD_TEST_ROOT", guiRoot);
            Environment.SetEnvironmentVariable("ZD_FAKE_WEBVIEW2", "130.0.2849.80");
            var st = SetupProgram.NewState(false);
            Expect(st.Maintenance, "should detect the installed version");
            var w = SetupProgram.CreateWizard(st); w.Show();
            await Next(w);
            Expect(w.Page is MaintenancePage, "maintenance page");
            await Shot(w, "setup-maintenance");
            Find<RadioButton>(w, "remove").Checked = true;
            await Next(w);
            Expect(w.Page is RemovePage && w.NextBtn.Text == Lang.T("btn.remove"), "remove page");
            Find<CheckBox>(w, "remove_data").Checked = true;
            await Shot(w, "setup-remove");
            await Next(w);
            await Until(() => w.Page is FinishPage, 20000, "finish");
            await Shot(w, "setup-removed");
            Expect(st.Outcome.Success && Installed.Read() == null && !Directory.Exists(Path.Combine(AppInfo.ProgramFiles, "Zenith Desk")) && !File.Exists(ServerConfig.MachineFile), "not removed");
            w.NextBtn.PerformClick();
        });

        await TestAsync("Wizard over an older version: update text, same folder, server pre-filled (still tested)", async () => {
            UseRoot("gui-upgrade");
            var old = Cfg(Demo, int.Parse(DemoPort)); old.TestedAt = "2026-09-01T00:00:00Z"; old.Save(ServerConfig.MachineFile);
            var oldDir = Path.Combine(AppInfo.ProgramFiles, "Zenith Desk Old");
            using (var root = AppInfo.MachineRoot(true)) using (var k = root.CreateSubKey(AppInfo.UninstallKeyPath)) { k.SetValue("DisplayVersion", "3.7.0"); k.SetValue("InstallLocation", oldDir); }
            var st = SetupProgram.NewState(false);
            Expect(st.Upgrade, "upgrade not detected");
            var w = SetupProgram.CreateWizard(st); w.Show();
            await Shot(w, "setup-upgrade-welcome");
            await Next(w);
            Find<RadioButton>(w, "accept").Checked = true; await Next(w);
            Expect(Find<TextBox>(w, "folder").Text == oldDir && !((ComponentsPage)w.Page).Change.Enabled, "same folder on update");
            await Next(w);
            await Until(() => w.NextBtn.Enabled, 8000, "checks");
            await Next(w);
            var sp = (ServerPage)w.Page;
            Expect(sp.Panel.HostBox.Text == Demo && sp.Panel.PortBox.Text == DemoPort && !w.NextBtn.Enabled, "pre-filled but not yet tested");
            sp.Panel.TestButton.PerformClick();
            await Until(() => sp.Panel.Passed, 10000, "test");
            await Next(w); await Next(w);
            await Until(() => w.Page is FinishPage, 30000, "finish");
            Expect(st.Outcome.Success && Installed.Read().Version == AppInfo.Version && File.Exists(Path.Combine(oldDir, "ZenithDesk.exe")), "update");
            Find<CheckBox>(w, "launch").Checked = false; w.NextBtn.PerformClick();
        });

        await TestAsync("English wizard", async () => {
            UseRoot("gui-en"); Lang.Code = "en";
            var w = SetupProgram.CreateWizard(SetupProgram.NewState(false)); w.Show();
            Expect(w.NextBtn.Text == "Next >" && w.Text.Contains("Setup"), "english texts");
            await Shot(w, "setup-welcome-en");
            await Next(w); Find<RadioButton>(w, "accept").Checked = true; await Next(w); await Next(w);
            await Until(() => w.NextBtn.Enabled, 8000, "checks"); await Next(w);
            await Shot(w, "setup-server-en");
            w.Close(); Lang.Code = "ru";
        });

        // ------------------------------------------------------------------ the program window (client), loaded from ZenithDesk.exe
        var asm = Assembly.LoadFrom(ClientExe);
        asm.GetType("ZenithDesk.Lang").GetField("Code").SetValue(null, "ru");
        Func<Form> newMain = () => (Form)Activator.CreateInstance(asm.GetType("ZenithDesk.Client.MainForm"));
        Func<Form, Tuple<string, string>> overlay = f => {
            var o = f.GetType().GetProperty("Screen").GetValue(f);
            return Tuple.Create((string)o.GetType().GetProperty("TitleText").GetValue(o), (string)o.GetType().GetProperty("DetailText").GetValue(o));
        };
        Action<Form> sized = f => { f.WindowState = FormWindowState.Normal; f.MinimumSize = new Size(0, 0); f.Bounds = new Rectangle(40, 30, 1100, 680); };

        await TestAsync("Program window: wrong server → 'no connection' with reason, Retry, Settings, countdown", async () => {
            UseRoot("client-bad");
            var c = Cfg(Demo, 1); c.TestedAt = "2026-10-01T00:00:00Z"; c.Save(ServerConfig.MachineFile);
            var f = newMain(); f.Show(); sized(f);
            await Until(() => overlay(f).Item1.Contains("Нет связи"), 10000, "offline screen");
            Expect(overlay(f).Item2.Contains("отклонил"), "reason: " + overlay(f).Item2);
            await Task.Delay(1300);
            await Shot(f, "client-no-connection");
            f.Close();
        });

        await TestAsync("Program window: server OK → opens the workplace (here: no WebView2 on Linux → install offer)", async () => {
            UseRoot("client-ok");
            var c = Cfg(Demo, int.Parse(DemoPort)); c.TestedAt = "2026-10-01T00:00:00Z"; c.Save(ServerConfig.MachineFile);
            var f = newMain(); f.Show(); sized(f);
            await Until(() => overlay(f).Item1.Contains("WebView2") || overlay(f).Item1.Contains("Не удалось"), 15000, "webview step: " + overlay(f).Item1);
            Expect(overlay(f).Item1.Contains("WebView2"), "should offer to install WebView2: " + overlay(f).Item1 + " / " + overlay(f).Item2);
            await Shot(f, "client-webview2-missing");
            var hm = f.GetType().GetMethod("HandleMessage");
            hm.Invoke(f, new object[] { new Dictionary<string, object> { { "type", "user" }, { "name", "Anna Petrova" } } });
            hm.Invoke(f, new object[] { new Dictionary<string, object> { { "type", "unread" }, { "n", 3 } } });
            Expect(f.Text == "(3) Zenith Desk — Anna Petrova", "window title: " + f.Text);
            f.Close();
            Expect(File.Exists(Path.Combine(AppInfo.UserDataDir, "window.json")), "window size not remembered");
        });

        await TestAsync("Program window: no server configured → asks for settings", async () => {
            UseRoot("client-none");
            var f = newMain(); f.Show(); sized(f);
            await Until(() => overlay(f).Item1.Length > 0, 5000, "screen");
            Expect(overlay(f).Item1.Contains("не указан"), overlay(f).Item1);
            f.Close();
        });

        await TestAsync("Server settings in the program: Save only after a successful test; saved for the user", async () => {
            UseRoot("client-settings");
            var sf = (Form)Activator.CreateInstance(asm.GetType("ZenithDesk.Client.SettingsForm"), new object[] { null });
            sf.Show();
            var save = Find<Button>(sf, "save");
            var host = Find<TextBox>(sf, "host"); var port = Find<TextBox>(sf, "port"); var test = Find<Button>(sf, "test");
            Expect(!save.Enabled, "Save before test");
            host.Text = Demo; port.Text = DemoPort; test.PerformClick();
            await Until(() => save.Enabled, 10000, "test passed");
            await Shot(sf, "client-settings");
            save.PerformClick();
            await Until(() => !sf.Visible, 3000, "dialog closed");
            var saved = ServerConfig.LoadFile(ServerConfig.UserFile);
            Expect(saved != null && saved.Host == Demo && saved.Port == int.Parse(DemoPort) && saved.ServerVersion == ServerVersion, "user server.json");
        });
    }
}
