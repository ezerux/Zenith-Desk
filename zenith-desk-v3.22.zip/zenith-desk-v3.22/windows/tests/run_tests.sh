#!/bin/sh
# Full test of the Windows programs on the build machine (Mono + Xvfb):
#   builds, starts a demo Zenith Desk server and misbehaving fake servers, runs tests/WinTests.cs (logic, connection
#   test, silent install / update / removal, the wizard page by page, the program window), checks the .lnk files and
#   the .exe resources. Screenshots: build/shots/.
set -e
cd "$(dirname "$0")/.."
WIN=$(pwd); ROOT=$(cd .. && pwd)
./build.sh > /dev/null
T=build/test; mkdir -p $T
rm -rf "$HOME/.mono/registry/CurrentUser/software/zenithdesktest" 2>/dev/null || true

openssl req -x509 -newkey rsa:2048 -nodes -keyout $T/key.pem -out $T/cert.pem -days 2 -subj "/CN=desk.company.local" 2>/dev/null
THUMB=$(openssl x509 -in $T/cert.pem -noout -fingerprint -sha1 | sed 's/.*=//; s/://g')
python3 tests/fake_servers.py $T/cert.pem $T/key.pem > $T/fake.log 2>&1 &
FAKE=$!
(cd "$ROOT" && DEMO_HISTORY=0 python3 -c "import uvicorn, scripts.demo as d; uvicorn.run(d.build(), host='127.0.0.1', port=8123, log_level='warning')") > $T/demo.log 2>&1 &
DEMO=$!
trap 'kill $FAKE $DEMO 2>/dev/null' EXIT
for i in $(seq 1 60); do curl -s -o /dev/null http://127.0.0.1:8123/api/health && break; sleep 0.5; done

mcs -sdk:4.5 -langversion:7 -nowarn:618 -r:System.Windows.Forms.dll -r:System.Drawing.dll -r:dist/ZenithDesk-Setup-3.11.exe tests/WinTests.cs -out:$T/WinTests.exe
cp dist/ZenithDesk-Setup-3.11.exe $T/
rm -rf build/shots
set +e
xvfb-run -a -s "-screen 0 1280x800x24" mono $T/WinTests.exe build/testroot $T/ZenithDesk-Setup-3.11.exe build/payload/ZenithDesk.exe build/shots $THUMB
RC=$?
set -e
echo "== shortcut files (.lnk) and program resources"
python3 tests/check_files.py build/testroot dist/ZenithDesk-Setup-3.11.exe build/payload/ZenithDesk.exe || RC=1
exit $RC
