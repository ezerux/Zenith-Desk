# Audit material (v3.20.2 security audit)

* `inventory.py` → `endpoints.json` — every route with the sign-in / role it requires.
* `repro.py` — reproduces each finding on any version from v3.18.1 on; `repro-<version>.json` are the recorded runs.
* `scans/` — raw scanner output (bandit, ruff, semgrep, pip-audit, detect-secrets, gitleaks with redaction, hadolint).
  Hits are triaged in `SECURITY_AUDIT_REPORT.md` §7; none contains a real secret.
