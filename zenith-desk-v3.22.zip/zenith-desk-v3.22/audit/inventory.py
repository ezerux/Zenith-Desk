"""Endpoint inventory: every route with its methods and the authentication / role it requires (from the dependency tree)."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi.routing import APIRoute, APIWebSocketRoute
from starlette.routing import Mount, Route
from app.config import Settings
from app.main import create_app

app = create_app(Settings(database_url="sqlite+aiosqlite:///:memory:", debug=True), background=False)

def deps(d, out):
    for sub in d.dependencies:
        name = getattr(sub.call, "__qualname__", repr(sub.call))
        clos = getattr(sub.call, "__closure__", None)
        if name.endswith("require_role.<locals>.dep") and clos:
            out.append("role>=" + [c.cell_contents for c in clos if isinstance(c.cell_contents, str)][0])
        else:
            out.append(name)
        deps(sub, out)
    return out

def flat(routes):
    for r in routes:
        if type(r).__name__ == "_IncludedRouter":
            yield from flat(r.original_router.routes)
        else:
            yield r

rows = []
for r in flat(app.routes):
    if isinstance(r, APIRoute):
        d = deps(r.dependant, [])
        auth = "PUBLIC"
        if any(x.startswith("role>=") for x in d):
            auth = [x for x in d if x.startswith("role>=")][0]
        elif "current_agent" in d:
            auth = "signed-in"
        rows.append({"path": r.path, "methods": sorted(r.methods - {"HEAD"}), "auth": auth, "name": r.name,
                     "module": r.endpoint.__module__.replace("app.", ""), "deps": [x for x in d if x not in ("get_services", "HTTPBearer", "bearer")]})
    elif isinstance(r, APIWebSocketRoute):
        rows.append({"path": r.path, "methods": ["WS"], "auth": "?", "name": r.name, "module": r.endpoint.__module__, "deps": []})
    elif isinstance(r, (Mount, Route)):
        rows.append({"path": getattr(r, "path", "?"), "methods": sorted(getattr(r, "methods", None) or ["*"]), "auth": "static/other", "name": getattr(r, "name", ""), "module": "starlette", "deps": []})
json.dump(rows, open(Path(__file__).resolve().parent / "endpoints.json", "w"), indent=1)
from collections import Counter
print(len(rows), Counter(x["auth"] for x in rows))
for x in rows:
    if x["auth"] in ("PUBLIC", "static/other"):
        print("  PUBLIC", ",".join(x["methods"]), x["path"], x["module"])
