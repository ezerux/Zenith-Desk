"""Reproduces every confirmed finding against whichever code tree is current (cwd).

Run with:   cd <tree> && python3 -I <path>/audit/repro.py <label>
It uses only APIs that exist in v3.18.1 … v3.20.2, so the same script shows "VULNERABLE" on the old code and
"FIXED" on the patched code. Results are written next to this script: repro-<label>.json.
"""
import asyncio
import json
import os
import struct
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path.cwd()
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
os.environ.setdefault("ZD_ENV", "development")
label = sys.argv[1]
out: dict[str, dict] = {}


def rec(fid, vulnerable: bool, detail: str):
    out[fid] = {"result": "VULNERABLE" if vulnerable else "FIXED", "detail": detail}
    print(f"{fid:7} {'VULNERABLE' if vulnerable else 'FIXED':10} {detail}")


async def main():
    from tests import conftest  # noqa: E402  (the project test environment)
    tmp = Path(tempfile.mkdtemp(prefix="repro-"))
    (tmp / "a").mkdir()
    (tmp / "b").mkdir()

    # ---------------- SEC-01 backup upload without size limit
    env = await conftest.build_env(tmp / "a", max_request_mb=1)
    try:
        if hasattr(env.settings, "backup_upload_max_mb"):
            env.settings.backup_upload_max_mb = 1
            env.settings.backup_min_free_mb = 0
        from app import backup as bk
        head = json.dumps({"app": "zenith-desk", "created_at": "2026-10-26T00:00:00Z"}).encode()
        blob = bk.MAGIC + struct.pack(">I", len(head)) + head
        data = blob + b"\0" * (3 * 1024 * 1024)

        async def gen():
            for i in range(0, len(data), 65536):
                yield data[i:i + 65536]
        root = await env.login("root")
        r = await env.client.put("/api/admin/backups/upload?filename=big.zdb", content=gen(), headers=root)
        rec("SEC-01", r.status_code == 200, f"3 MB chunked upload with MAX_REQUEST_MB=1 → HTTP {r.status_code}")

        # ---------------- SEC-04 AMI CR/LF injection
        from app.ami import build_message
        try:
            raw = build_message({"Action": "QueuePause", "Interface": "101\r\n\r\nAction: Originate\r\nChannel: PJSIP/900"})
            rec("SEC-04a", b"Action: Originate" in raw, "encoder emitted a second AMI action")
        except ValueError as e:
            rec("SEC-04a", False, f"encoder refused: {type(e).__name__}")
        users = (await env.client.get("/api/admin/users", headers=root)).json()
        a = next(u for u in users if u["username"] == "anna")
        body = {k: a[k] for k in ("last_name", "username", "position", "role", "level", "zammad_user_id",
                                  "extension", "asterisk_interface", "enabled")}
        body.update(first_name="Anna", asterisk_interface="Local/101@from-queue/n\r\nAction: Command\r\nCommand: core stop now")
        r = await env.client.put(f"/api/admin/users/{a['id']}", json=body, headers=root)
        rec("SEC-04b", r.status_code == 200, f"admin form, interface with CR/LF → HTTP {r.status_code}")

        # ---------------- SEC-05 unlimited live streams per user
        b = env.services.broker
        gens = []
        opened = 0
        for _ in range(30):
            g = b.stream(1, False, heartbeat=60)
            first = await g.__anext__()
            if "too_many" in first:
                await g.aclose()
                continue
            await g.__anext__()
            gens.append(g)
        opened = b.connections(1)
        for g in gens:
            await g.aclose()
        rec("SEC-05", opened >= 30, f"30 streams requested for one user → {opened} held open")

        # ---------------- SEC-06 recording lookup with wildcards
        from app.api.tickets import find_recording
        rd = tmp / "rec" / "2026" / "10" / "26"
        rd.mkdir(parents=True)
        (rd / "q400-102-other-call.wav").write_bytes(b"RIFF")
        hit = find_recording(str(tmp / "rec"), "*.wav")
        rec("SEC-06", hit is not None, f"stored name '*.wav' → {'another call: ' + hit.name if hit else 'nothing'}")

        # ---------------- SEC-07 logout does not end the session
        h = await env.login("anna")
        await env.client.post("/api/auth/logout", headers=h)
        r = await env.client.get("/api/auth/me", headers=h)
        rec("SEC-07", r.status_code == 200, f"token after sign-out → HTTP {r.status_code}")

        # ---------------- SEC-08 scrypt cost
        from app.crypto import hash_password
        n, rr, p = hash_password("x").split("$")[1:4]
        rec("SEC-08", p == "1", f"new hashes: scrypt N={n} r={rr} p={p}")

        # ---------------- SEC-09 password hashing blocks the event loop
        ticks = 0

        async def ticker():
            nonlocal ticks
            while True:
                await asyncio.sleep(0.005)
                ticks += 1
        t = asyncio.create_task(ticker())
        await asyncio.sleep(0.02)
        ticks, start = 0, time.monotonic()
        await asyncio.gather(*(env.client.post("/api/auth/login", json={"username": "boris", "password": f"bad{i}"})
                               for i in range(4)))
        spent = time.monotonic() - start
        t.cancel()
        ratio = ticks / max(1, spent / 0.005)
        rec("SEC-09", ratio < 0.4, f"4 wrong sign-ins took {spent*1000:.0f} ms; other work ran {ratio:.0%} of that time")
    finally:
        await env.client.aclose()
        await env.services.stop()
        await env.services.db.dispose()

    # ---------------- SEC-03 typing event to any id (v3.18.1)
    env = await conftest.build_env(tmp / "b")
    try:
        anna = await env.login("anna")
        r = await env.client.post("/api/chat/999/typing", headers=anna)
        rec("SEC-03", r.status_code < 300, f"typing to a non-existent user 999 → HTTP {r.status_code}")
    finally:
        await env.client.aclose()
        await env.services.stop()
        await env.services.db.dispose()

    # ---------------- SEC-02 published default secret accepted in production
    os.environ.pop("ZD_ENV", None)
    from app.config import Settings
    try:
        Settings(_env_file=None, database_url="sqlite+aiosqlite:///:memory:")
        rec("SEC-02", True, "production start with JWT_SECRET=change-me… accepted")
    except Exception as e:  # noqa: BLE001
        rec("SEC-02", False, "production start refused: " + str(e).split("\n")[1][:90])

    (Path(__file__).resolve().parent / f"repro-{label}.json").write_text(json.dumps(out, indent=1, ensure_ascii=False))


asyncio.run(main())
