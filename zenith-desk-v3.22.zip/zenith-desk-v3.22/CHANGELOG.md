# Changelog

## 3.22 — 2026-10-26
**Interface size, and a header that fits laptop screens.**
- The whole program is drawn a little smaller by default and adapts to the screen: **Auto** = 80 % on small laptops
  (below 1360 px), 85 % on laptops (below 1600 × 860), 90 % on big screens; phones stay at 100 %.
- **My settings → Interface size**: Auto · 80 · 90 · 100 · 110 · 125 % for every user, saved to the account (the same on
  any computer).
- Flow header on laptops: the menu stays on one row next to the logo. When it is tight, the pills get closer and
  «Shifts, recordings, log, routing» becomes «Manager tools»; only when even that does not fit does the menu take its own
  row. Fixed: once the menu had moved to its own row it never came back next to the logo after the window got wider.
- Full-height pages (Messages, mail, tickets), pop-ups, the phone window (drag, resize), chat menus and button ripples
  follow the chosen size.

## 3.21 — 2026-10-26
**Administration → Users: who is online, who is locked out and from where.**
- The users table shows at a glance: a presence dot on the picture (green online · grey offline · red locked), the
  state now (Online · Ready / Break, Offline, 🔒 Locked · N min, Disabled), the last sign-in with the computer's IP
  address, how many connections are open (browser tabs, phone, desktop app). Filters on top: All · Online · Offline ·
  Locked · Disabled with their counts. The list follows by itself (live).
- A click on a row opens everything about the user: state and since when, call, tickets in work; last sign-in (address,
  «usual» or not, device), password changed, failed attempts in 24 h; every open connection with its address and device
  and **Sign out everywhere**; the Zammad groups with their rights and the chat groups; which sections the role opens;
  extension, SIP, queues; the Zammad link, creation date, API keys.
- **Locked out after wrong passwords**: the row says until when, and the opened row says why — the address the attempts
  came from, whether it is the user's usual address and who last signed in from that computer (the user's own typo, or
  somebody else trying?), with the list of attempts. **Unlock** (or **Unlock + new password**) lifts the lock at once.
  Every administrator gets a bell notification when an account is locked; lock, unlock and «sign out everywhere» are in
  the log.
- Every sign-in attempt is kept 30 days (address, device, result); attempts during a lock are written at most once a
  minute per address. New table `login_attempt` (migration 0020).
- Note: the address is the one the server sees. Behind a reverse proxy set `PROXY_HEADERS=true`, otherwise the proxy's
  address is shown for everybody.

## 3.20.2 — 2026-10-26
**Security audit: eleven findings fixed, the rest documented.** Details: `SECURITY_AUDIT_REPORT.md`; upgrade, key
rotation and rollback: `SECURITY_FIXES.md`; tests: `SECURITY_TEST_PLAN.md`; server checklist:
`SECURITY_DEPLOYMENT_CHECKLIST.md`.
- **Production fails closed**: the server refuses to start with a missing, published, placeholder or weak
  `JWT_SECRET`, or a placeholder database password (`ZD_ENV=development` for test machines). Before, a server left
  with the example secret let anyone forge an administrator session.
- **Sign-out really signs out**: the session token stops working at once (before: 12 more hours); other devices stay
  signed in. New table `revoked_token` (migration 0019).
- **Asterisk commands cannot be smuggled** through an extension / interface / setting with line breaks; the admin form
  accepts only the characters a channel name has.
- **Sign-in no longer freezes the server** for everybody while a password is checked; stronger password hashing
  (upgraded automatically at the next sign-in — that ends the user's other sessions once).
- **Backup upload** has its own limit (`BACKUP_UPLOAD_MAX_MB`, 413), keeps disk space free (`BACKUP_MIN_FREE_MB`, 507)
  and accepts one upload at a time.
- **Live updates**: at most 12 connections per user, 2000 per server (429 / 503; the browser retries by itself).
- Recordings: the stored file name is matched literally, only audio files, no full archive scan; recording links
  must be web links. Log export to Excel never contains a formula.
- 73 new security tests; an automatic check that every protected endpoint refuses the wrong role.

## 3.20.1 — 2026-10-25
**Pop-ups in the middle, phones checked page by page, the call strip level with the status.**
- Fix: pop-ups (e.g. «Set a new password» in Administration) were trapped inside the page under the menu and stood too
  low. Cause: an entrance animation without an end frame left an invisible transform on the panel, which made it the
  frame for fixed pop-ups. Those animations no longer leave anything behind — every pop-up covers the whole window and
  stands in its middle.
- Phones, every section as operator, manager and administrator at 390 and 360 px:
  - WhatsApp / Telegram: the list of conversations was wider than the screen (a long preview widened it and the right
    part was cut off, with the search box) — it fits now and the preview ends with «…»; the same rule for mail.
  - The operator's top bar is two tidy rows: the status (a long text ends with «…»), Ready and Break · then the phone,
    do not disturb and LIVE (before, Break and the phone jumped between rows).
  - Users table: the name column is wide enough (no three-line names); the table scrolls sideways as before.
- Blocks side by side are built evenly on every page (no holes under the shorter block): the blocks of one row
  have the same height — My workplace, Manager panel, Overview, Backup, API keys, Settings. Where one block holds a long
  list (the team's calls, the audit log) the other block sets the height and the list scrolls inside; a very long
  dashboard list stops at a height and scrolls. Settings: the phone block on the right, calls / notifications and the
  account stacked on the left.
- Studio: the buttons of «Recent calls» (Call / Card) stuck out to the left of their block (a rule meant for the ticket
  cards applied to every list) — fixed.
- Wide screens (Flow): the status and the call strip stand a little higher, level with each other (same height), with
  room under the menu; while a call is on the top bar keeps room for the strip, so it never lies over the page below
  (e.g. the level filter of Overview).

## 3.20 — 2026-10-25
**Internal messenger: files, emoji, «typing…» with the name, groups. The call strip in the top bar.**
- **Files** — the 📎 next to the text box (or drag the files onto the conversation, or paste a screenshot): up to 10 files,
  20 MB each, 40 MB together; they wait above the text box (picture previews, size, ✕) and go with the message or
  alone. Pictures are shown in the bubble; any file downloads with one click. Files are kept encrypted in the database
  (so backups and restores include them) and only the people of that conversation can download them — a colleague
  outside it and the administrator get «not found». A picture is shown in the page only for PNG / JPEG / GIF / WebP;
  everything else (HTML, SVG …) only ever downloads. Deleting a message for everyone deletes its files.
- **Emoji** — the 🙂 next to the text box: smileys, gestures, hearts, work; the ones you used last come first.
- **«Anna is typing…»** — the other side sees it at once with the name of who types: in the open conversation (a
  bubble with moving dots and in the header) and in the list of chats; in a group with several names.
- **Groups** — «New group» next to the search: a name and colleagues (search by name, position or extension). Every
  member sees the group in the list with its newest message («Anna: …») and unread counter, gets it live, a toast and
  a background notification; the sender's name is over the bubbles. Files, emoji, reactions and edits work there too.
  The panel of a group lists the members; its creator renames it, adds and removes people; anybody can leave (when
  the creator leaves, the longest member takes over). A newcomer sees the history without it counting as unread.
  Only the members can read a group — not the administrator either.
- **The call strip** (Flow, wide screens) sits in the top bar in the middle, next to the status, as a rounded pill in
  the Flow look (round buttons, «Answer» / «New ticket» as pills); on a narrower window it takes its own line.
- Security: «typing…» now follows the same rules as writing — only to an existing, active colleague or into a group
  you are a member of — and is throttled (one event per 1.5 s per conversation), so it can no longer be sent to any
  user number nor used to flood somebody.

## 3.19.1 — 2026-10-25
**Login page.**
- The background is a soft grid that fades out towards the edges, with a green light behind the card (instead of the
  giant ZENITH.); dark and light.
- The Z icon stands level with the ZENITH. wordmark (DESK below the wordmark only).

## 3.19 — 2026-10-25
**Flow for everyone: the menu on top, the tools on the left.**
- **Flow is the default look** for every new user (and before the first sign-in); whoever chose Classic or Studio keeps it.
- **The tool rail** — in the middle of the left edge, separate rounded groups: **Ready / Break** (the current one lit),
  the **phone** (phone · dialer · do not disturb; the dialer opens next to the rail, searches names and numbers, Escape
  closes it), **Customize**, the **pinned sections** and the account buttons (My settings, theme, password, sign out).
  Short windows get smaller buttons so the whole rail fits.
- **The header row**: logo · menu · the bell, LIVE and the account picture (its tooltip has the name, level and
  position; a click opens My settings). When the sections do not fit next to them — a laptop, a manager or an
  administrator with many sections — the menu takes its own row, centred under the logo. The docked phone panel never
  covers them.
- **Quick access**: the «+» on the rail lists the sections of the top menu; tick up to **5** you use most and they
  appear on the rail (with their unread counters). They **stay in the top menu** as well. A 6th cannot be ticked
  (the counter shows «5 of 5»; the server refuses more too); untick one to add another. Saved to the account — the same
  on any computer.
- On a phone nothing changes: the menu at the top, the toolbar at the bottom, the phone in the top bar.

## 3.18.1 — 2026-10-25
**The ZENITH. wordmark.**
- The product name in the top bar (Flow and the phone layout), on the login page and on the wallboard is now the drawn
  **ZENITH.** wordmark — heavy caps with the cut E and the green dot — next to the Z icon, with **DESK** in wide caps.
  It is an inline SVG in the text colour (sharp at any size, follows the light / dark theme, no extra font to load);
  screen readers still read «Zenith Desk». Hovering the logo turns only the icon now, not the name.
- **New login page**: a giant, dimmed ZENITH. with its glowing green dot behind a frosted card, a soft green light from
  below; in the card the Z icon, the ZENITH. wordmark and DESK under it. Dark and light, every interface style, phones.
- Fix: the first use of an API key is always recorded («last used», IP, count), also on a server that started less than
  a minute ago.

## 3.18 — 2026-10-25
**The team right now (managers).**
- **«Team now» on the manager panel** — for every employee, live: the phase of his call — *ringing* (who calls: number,
  customer, queue), *calling out* (which number), *talking* (number, customer, direction, a running timer), *on hold*
  (from Asterisk), *wrap-up*; how long he has been in his status («Break 17 min»); the ticket he works on and for how
  long. Filters (on a call / free / busy / break / offline), sorting (by level, by name, longest in status) and quick
  actions in the row: listen / whisper / join, open the ticket, write in the messenger, his day, reconcile, override.
- **Queues now** — customers waiting in every queue with their waiting time ticking, the longest wait, free operators,
  who talks, and today's numbers per queue (offered, answered, missed, service level, average answer).
- **Calls of the team** — the last 50 calls live: who, which number, queue, the result (answered / talking / waiting /
  hung up while waiting / nobody answered / connected / no answer), wait and talk time, who else was rung, the ticket.
- **A person's day** — click a name: a timeline of statuses and calls, incoming answered / not answered (RONA) /
  outgoing, talk time and average, breaks, signed-in time, came in / left, tickets, occupancy, and every call of the
  day; any earlier day too.
- **Alerts for managers** (bell, toast, push; thresholds in Settings → Manager tools): a call longer than N min, a break
  longer than N min, an operator did not answer a ringing call, N customers wait in a queue, a missed customer call.
  Each problem once, also after a restart.
- **Wallboard** (TV mode, `/?wall=1`, full screen): waiting now and the longest wait, talking, free, on break,
  answered / missed today, service level against the target, average answer; queues; every employee as a tile with
  his phase and timer; the last calls.

**Call routing for managers** (Manager tools → Call routing).
- **Distribution per queue**: one after another, who has been free the longest, who has had the fewest calls, everybody
  at once. Applied in Asterisk at once (AMI UpdateConfig + QueueReload; the AMI user needs `write = config`) when the
  administrator allows it — and kept: if FreePBX writes its configuration again, Zenith Desk puts it back. Otherwise
  the page shows what to choose in FreePBX.
- **Overflow**: when N customers wait in a queue (or one waits X seconds), the chosen groups (Level 2, Level 3,
  managers) ring in the first line of that queue — and those busy with a ticket take calls there too (people on a
  break are left alone). When the queue has been calm for a while, everything goes back by itself.
- **VIP customers and the last operator**: a number or a prefix from the list goes straight to the chosen employee,
  to a free person of a level (the one free the longest), or to the operator who talked to the customer last; if that
  person does not answer in N seconds (or is busy), the customer goes back into the queue — he is never lost and the
  statistics count one call. «Check a number» shows where a call would go right now. Every decision is in the log.

**Moving to a new version or server** (Backup → «Download full export»): one encrypted file with everything — users
with logins and passwords, settings and integrations, chats, messengers with files, mail, calls, shifts, routing, the
log — and now also the server's HTTPS certificate and its sign-in key. Restored on the new installation, people who
were signed in keep working without signing in again and the browsers / Windows app see the same certificate.

**API keys for other programs** (Administration → API keys): a key acts as the chosen user with his rights; read-only
or full, allowed addresses, an expiry date, revocation, last use; only a hash is stored and the key is shown once;
`X-API-Key` or `Authorization: Bearer`; 1200 requests a minute per key; the API description (OpenAPI) can be
downloaded there.

- Fixed: a phone that stopped ringing without an answer (DialEnd NOANSWER / CANCEL / BUSY) no longer looks «ringing».
- Tests: 16 new unit / API tests (live board phases, queues, feed, a day, every alert, routing rules, overflow with
  unpausing, VIP direct / back / sticky, strategy, API keys, moving sessions and the certificate); the UI test checks
  the team board, the wallboard, the routing page and API keys; a new real Asterisk 20 test runs distribution, VIP
  (Redirect, answered and back to the queue) and overflow.

## 3.17.1 — 2026-10-25
- **Recordings is now a section for managers and administrators only.** Operators no longer see it in the menu,
  and the archive search (`/api/recordings`) answers 403 for them. An operator can still play the recording of his
  own call from «Recent calls», as before (other people's recordings stay closed, every play is in the log).
- **The stage of a ticket by colour, everywhere.** New — blue, open — amber, waiting (pending) — violet,
  closed — **green** (a filled dot). The list of open tickets under the overviews now shows each ticket's stage
  (it used to be the same green ring for all) and changes colour at once when the ticket is updated here or in
  Zammad; the hint over a tab names the state. The same colours are used in the ticket tables, the ticket header and
  the customer card, in Classic, Studio and Flow, light and dark.
- Tests: the operator has no Recordings section and the archive refuses him; managers and administrators find every
  conversation; the open-ticket list reports the stage of each ticket and a ticket closed in Zammad turns its tab
  green.

## 3.17 — 2026-10-25
**Security: a full review of the program and the code; nothing travels the network as plain text.**
- **HTTPS built in.** `python -m app.serve` (the Docker image starts it) serves Zenith Desk over HTTPS: TLS 1.2 and
  1.3 only, ECDHE + AES-GCM / ChaCha20, no compression, HSTS. Your certificate (`TLS_CERT_FILE`, `TLS_KEY_FILE`) or a
  self-signed one made once on the first start (its SHA-256 is printed in the log). Plain HTTP (port 80) only answers
  with a redirect to HTTPS — no page, no data. Docker publishes 443 and 80.
- **The database over TLS.** docker compose makes its own certificate authority once; PostgreSQL accepts only
  encrypted connections (`hostnossl … reject`, TLS 1.2+) and Zenith Desk checks its certificate (`ssl=verify-full`).
- **AMI over TLS** (Integrations → Telephony): the AMI password and the call events are encrypted; a self-signed
  certificate of FreePBX / Asterisk is pinned by its SHA-256 fingerprint. Tested against a real Asterisk 20.
- **Unencrypted addresses are refused.** http:// for Zammad / public address / recordings / alert webhook /
  Telegram / WhatsApp, ws:// for the phone, AMI without TLS, mail without SSL/STARTTLS are not saved unless the
  server is this computer (localhost). *System status → Encryption* lists every connection that would still be plain
  (and certificate checks that are off). «Allow unencrypted connections» (General, off) exists only for a test bench.
- **Messenger files (photos, documents, voice) are now encrypted in the database** like the messages; files saved by
  earlier versions are encrypted once on start; backups and restore with a new key handle them.
- Fixes from the security review:
  - the live event stream no longer carries the session token in its address (it could land in proxy logs): the page
    asks for a 60-second stream ticket that opens only the stream; session and stream tokens can't be swapped;
  - Zammad webhooks without a configured secret are no longer accepted (changes still arrive by the 10-second check);
  - login: the same answer time for unknown and known logins, a limit per address (password spraying), every failed
    sign-in is in the log;
  - requests larger than the limit (64 MB, webhooks 5 MB) are refused before they are read;
  - API answers, messenger files and mail attachments are never stored by the browser or a proxy (`no-store`);
  - the API description (/docs, /openapi.json) is off by default (`API_DOCS=true` to turn it on);
  - the first administrator's password is printed once to the console, never kept in the system log;
  - remote pictures in e-mails only over https; SHA-1 replaced by SHA-256 for internal fingerprints;
  - PyJWT 2.15.0 (security fixes); dependency audit (pip-audit) and static analysis (bandit) are clean.
- **Flow:** the phone docked as a side panel no longer covers the top menu — the menu moves aside, and when there is
  not enough room the pills wrap onto a second line instead of hiding behind the edge; the top menu is in the middle
  of the screen.
- Fixed: «Create backup now» pressed just as the scheduled backup started was refused («busy»); it now waits for
  that backup and runs right after it.
- Tests: 13 new security tests (TLS certificates, pinning, refused TLS 1.1, AMI over TLS, HTTP→HTTPS redirect,
  refused plain settings, token kinds, size limits, no-store, docs off, unsigned webhooks, login limits, files at
  rest, the Encryption block); the real Asterisk test runs over AMI TLS; Flow UI test: menu centred, never under the
  docked phone at 960–1920 px.

## 3.16.2 — 2026-10-24
- Fixed for good: a browser that had saved the interface files of an earlier version could still show the old
  settings (no «Flow») even after 3.16.1. The page now asks for every script and stylesheet with a fingerprint of the
  files (`app.js?v=…`): a new version is a new address, so an old saved copy can never be used.
- Fixed: a click on Start / Background / Postpone right after another action could be ignored silently (the previous
  action was still finishing). These buttons are now inactive for that moment, so a click is never lost.
- Fixed: hours being typed in Recordings / Log / Shifts (HH:MM fields) could be wiped when a colleague's change
  re-drew the page at that moment; the typed text now stays until you leave the field.
- Tests: the page references every interface file with one fingerprint; typed hours survive a live update.

## 3.16.1 — 2026-10-24
- Fixed: after an update the browser could keep showing the previous interface (e.g. no «Flow» in My settings even
  though v3.16 was running) because it reused its saved copy of app.js. The interface files are now always checked
  with the server (a few-byte answer when nothing changed), so every update appears at once; fonts stay cached.
- Test: interface files are revalidated (no-cache + ETag → 304), fonts cached.

## 3.16 — 2026-10-24
- **New interface style «Flow»** (My settings → Interface → Interface style; saved to the account, Classic and Studio
  stay as they were). Soft and airy, light and dark:
  - the sections are a **pill navigation at the top** with counters; the black active pill **slides** to the section
    you open (on a laptop the bar takes its own line, it never runs off the screen);
  - Settings, theme, password and sign-out are a **floating dark toolbar** on the left that stays in place while the
    page scrolls (on a phone: at the bottom, like an app dock);
  - big page titles, separate rounded number cards (the first one dark, the next white and soft grey), white cards
    with soft shadows, pill buttons, segmented controls with a white pill, charts in ink with one warm red;
  - on a phone: the bell and the account picture next to the logo, sections scroll sideways, segmented controls stay
    on one line and scroll;
  - its own font Manrope (served by Zenith Desk, no internet needed; SIL Open Font License).
- **Smoother motion** in Flow: blocks of a new page rise in one after another, list rows slide in, cards lift under
  the mouse, buttons give a little when pressed, pop-ups, notifications and messages open with a soft spring, the
  bell rings when hovered, the live dot breathes. Everything respects «Animations» off and the system's reduced
  motion setting.
- Tests: the whole UI test now runs in all three styles (Classic, Studio, Flow) — 84 checks each; a Flow test of the
  sliding pill, the floating toolbar (never covering the page, fixed on scroll, at the bottom on a phone), the phone
  header and one-line segmented controls.

## 3.15.1 — 2026-10-21
- **The icon rail always fits the screen.** An administrator had 15 icons plus the bottom buttons, so on a laptop
  (1366×768, 1280×720) Settings, theme and Sign out fell below the screen and the whole page scrolled. Now:
  - the 8 administration pages (Users, Integrations, System settings, Ticket groups, Ticket types, Call routing,
    System status, Backup) are **one «Administration» icon**; inside, the pages are tabs at the top of the page
    (in Studio: the section panel), and the last opened page is remembered;
  - the manager tools (Shifts, Recordings, Log) are one icon after *Overview*, with the same tabs (operators keep their
    own *Recordings* icon);
  - on short screens (up to 860 / 700 px high) the rail is tighter.
- **Tables on phones and narrow pages**: a wide table (Users, Call routing, Log, recordings…) now scrolls sideways
  inside its panel instead of squeezing every column to one letter (seen on the Users page on a phone and with the
  Studio section panel open on a 1024 px screen).
- **Icon buttons of one size**: in the WhatsApp / Telegram message box the attach button (a file picker) was taller
  and lower than the note button next to it; file pickers that look like buttons (mail, tickets) had the same
  problem. The phone button in the top bar without its text is now a 40×40 square like the bell and Do not disturb.
- Tests: UI test that icon buttons side by side have one size and line (top bar, message box, mail, tickets); UI test of the grouped navigation (tabs, remembered page, marked icon), the rail at 1366×768 and 1280×600 and
  the users table on a 390 px phone — in both interface styles.

## 3.15 — 2026-10-17
- **Call supervision — listen, whisper, join** (manager panel): every operator who is on a call shows the number and
  the talk time and three buttons: **Listen** (nobody hears the manager), **Whisper** (only the operator hears him —
  the customer does not), **Join** (the operator and the customer hear him). Zenith Desk asks Asterisk (AMI
  Originate + ChanSpy) to ring the manager's own phone; Zenith Phone answers by itself and shows whom he listens to,
  with the three modes as buttons (they send keys 4 / 5 / 6 — a desk phone can use the keys). A banner on the manager
  panel shows the session with Stop. It ends by itself when the operator's call ends. The manager's listening call is
  never a call card, a call record or a number in the statistics. Every session (start, mode changes, stop, how long)
  is in the log. AMI user: `write = agent,originate,call` (docs/INSTALL.md); switch, phone channels in
  System settings → Manager tools.
- **Shift schedule** (new page *Shifts*): the week as a grid of employees × days; plan shifts for several people and
  several days at once from a template (Morning / Day / Evening, own templates) or any HH:MM times, night shifts end
  the next day; a click on a shift edits or removes it, «+» in a cell adds one; *Copy previous week here*.
  **Attendance is computed by itself** from the presence history (signed in and not Offline): **late** arrival
  (also «not in yet»), **early leave** and **absence** (not in 30 minutes after the start) — with grace minutes in
  System settings. Each case is flagged in the grid, counted in the week summary and sent once to every manager's
  notifications; *Today* shows came in / left / worked. Operators get their coming shifts in the API.
- **Recordings archive** (new page *Recordings*): find a conversation by day range and **hours** (e.g. 09:00–12:00,
  or 22:00–06:00 over midnight, company time zone), operator, number or name, direction, queue, minimum length,
  with / without ticket; quick Today / Yesterday / 7 / 30 days; listen in the row and **download** — both through
  Zenith Desk with the rights check and an audit entry. Operators see only their own conversations.
- **Log** (new page *Log*): staff actions and **system problems** in one place. Server warnings and errors are now
  stored (setting «System problems written into the log»), the same problem within 10 minutes is one row with a
  counter and the error / trace. Filters: from / to (day and time), section (sign-in, status, shifts, calls,
  tickets, messages, administration, system), level, who did it, about whom, action, text in the details, ticket;
  rows open with all details; **CSV export** (Excel). Managers see the staff actions, the administrator everything.
- The new pages are appended to the icon rail after *Overview* (the other icons do not move); in Studio they are in
  the manager section panel. Times are typed as HH:MM (9 → 09:00, 1630 → 16:30) in every browser language.
- Demo: today's shifts of the demo team (one is late), templates, playable recordings.
- Tests: supervision rules (rights, not on a call, no own extension, modes and keys, Asterisk hang-up event, no call
  record), attendance rules (on time, late, absent, early leave, breaks, night shift), schedule API (plan, overlap,
  replace, edit, copy, templates), lateness alerts once per case, recordings filters (day, hours, over midnight,
  number, direction, ticket, operator's own only, download), log filters and rights, CSV, system problems captured
  and counted; UI test of all four tools in both interface styles; **real Asterisk 20**: the manager's browser phone
  is rung, ChanSpy listens to the operator's queue call, key 5 reaches Asterisk, Stop over AMI, Join, the session
  ends with the call.

## 3.14 — 2026-10-15
- **«My workplace» in five layouts — every operator chooses** (My settings → Interface → Home screen; in Studio also
  from the section panel): **Blocks** (as before, arranged with Customize), **Focus** (one big card with the next
  request — oldest first, Skip, Start / Background; while a task is active it shows that task with Complete /
  Background / Postpone; the queue and my tickets on the side), **Board** (columns New · In work · Assigned to me ·
  Pending, with the actions on every card), **Inbox** (everything in one list, filters by kind and by channel; today,
  notifications and recent calls on the side), **Table** (one ticket per row, filters). Same data and actions as the
  blocks; both interface styles; saved to the account.
- **My settings → Interface**: every interface control in one section — style (Classic / Studio), Studio section
  panel, home screen layout and its blocks, theme, compact density, animations.
- **New ticket straight from a call**: during an answered call the phone window and the call strip have a
  **«New ticket»** button. It opens Tickets with a new draft: the caller already chosen when Zammad knows the number,
  «How the request came» = phone, and the caller's number shown above the description **as a link** — a click opens
  the phone with the number typed, the operator only presses Call (no call is started by itself). When the ticket is
  created, the call details (number, time, extension, queue, call ID, recording) go into it and the call is linked
  to the ticket.
- Fixed: a new ticket requested together with the switch to Tickets (from a customer card) could be lost; each
  request now opens exactly one draft.
- Fixed: an unreadable server answer could empty the notification list and cause a script error; such an answer is
  now treated as an error and the lists stay as they were.
- Tests: draft from a call (call details, link, someone else's call ignored); UI tests of the Interface section, all
  four new layouts (Focus start / skip / postpone, Board, Inbox and Table filters, saved), call → new ticket → number
  link → ticket with the call — in both interface styles.

## 3.13 — 2026-10-15
- **Studio section panel — two modes, chosen by every user** (My settings → Appearance → «Section panel»):
  - **Next to the icons** (default): a compact panel (narrower, smaller rows) always open next to the icon rail;
    the **«** button hides it — then it works as a pop-up until it is pinned again;
  - **Pop-up**: the page uses the whole width; the sections open over the page from the **active icon** of the rail
    or the panel button at the start of the top bar, and close with a choice, Esc or a click outside; the pin button
    puts the panel back next to the icons. On Tickets the Zammad overviews stay on the page in this mode.
  - The account is still shown in one place only: bottom of the panel when it is next to the icons, the top bar in
    pop-up mode. The choice is saved to the account.
- «Start of shift» is one line with a progress bar; a click opens the checklist.
- Studio top bar stays in one row on a 1366 px laptop (the level under the name is hidden below 1500 px).
- Tests: UI test of both panel modes (hide, open from the icon and from the top bar, Esc / outside click, tickets,
  saved to the account, pin back); preference validation.

## 3.12.1 — 2026-10-14
Stabilization of the Studio style — the whole UI test (76 checks) now runs in **both** styles in the release check.
- Studio: pages that fill the screen (Messages, Mail, WhatsApp, Telegram, Tickets, Customers) had an extra inner
  margin; they now fill the frame like in Classic.
- Studio: the phone fixed to the right edge («Side panel») covered the page and its buttons; the page now moves
  aside like in Classic.
- Studio: the manager panel shows the same operators table as Classic again (with the photo / initials): cancel an
  operator's session, «Away» mark, sync errors and every other function were missing from the cards.
- Studio: level and period filters of the manager panel and the overview are on the page again (as in Classic);
  the section panel shows the pages and the live state counts.
- Tickets: a ticket or draft opened before the ticket settings arrived from Zammad could throw a script error
  (groups / priorities lists); the lists are empty until they arrive.
- UI test: runs in either style (`ZD_STYLE=studio`), names the step where a browser error happened.

## 3.12 — 2026-10-14
- **Interface style** (My settings → Appearance): **Classic** — the Command Center look as before — or the new
  **Studio**. Only the look and the page layout change: every function works the same and **every icon of the left
  rail and every button of the top bar stays where it is**. Saved to the account, so it follows the user to any
  computer; dark, light and system theme in both styles.
- **Studio**:
  - a **section panel** next to the icon rail: on the workplace the blocks with their counters (click scrolls to the
    block) and the channels (Messages, Mail, WhatsApp, Telegram with unread counts); on Tickets the operator's Zammad
    overviews, «New ticket» and the open tabs / drafts; on the manager pages period, levels and states; in the
    administration and in My settings their sections;
  - **the account is shown in one place only** — bottom left (photo or initials, name, level, state); the top bar does
    not repeat it (on a phone screen the panel is hidden and the account returns to the top bar);
  - framed workspace, greeting with the first name and the day («Good morning, Anna»), separate number cards;
  - new requests, assigned and background tickets as **cards** with a channel icon, a status pill and the actions;
    the manager panel shows operators as cards (state, reason, tickets, Reconcile / Override);
  - **Start of shift** checklist (phone online, mailbox signed in, Ready) — disappears when done or closed for the day;
  - graphite surfaces with amber accents; light variant.
- **Account picture**: every user can upload a photo (JPEG / PNG / WebP; the browser cuts the middle square and
  shrinks it to 256×256, no EXIF leaves the computer) or keep the **initials of the first and last name** (default);
  switch between photo and initials at any time, delete the photo. Shown in the top bar / Studio panel, the staff
  messenger, the manager panel and the users list. The picture is checked by its bytes (no SVG), served under a random
  key that changes with every upload; the administrator can remove an unsuitable photo.
- Fixed: right after the page was loaded a click on the theme switch (or another animated change) could be held back
  by the browser's page transition and do nothing; the change now always happens at once (the animation is skipped
  if the browser is not ready).
- Opening another page starts it at the top; the theme is saved at once (a reload right after switching no longer
  brings the old theme back).
- Windows tests compare with the version of the server they talk to (the 3.11 app works with a 3.12 server).
- Tests: 5 new server tests (pictures, rights, wrong files, style preference), UI tests of Studio (rail unchanged,
  account only bottom left, overviews in the panel, saved to the account, phone layout) and of the account picture;
  a backup test no longer depends on today's date.
- Windows app unchanged (3.11 works with 3.12); no new setup file in this version.

## 3.11 — 2026-10-12
- **Tickets like in the company's Zammad**:
  - left column: the operator's **own Zammad overviews** (`GET /api/v1/ticket_overviews` in his name) — the same
    names, order and counts as in Zammad, custom ones included («Назначенные мне заявки», «Не назначенные и открытые
    заявки», «Открытые заявки», «My Closed Tickets», «On-site Requests» …);
  - an overview is a table (title, number, customer with organization, group, state, priority, owner, created) with
    search, filters (group, state, priority, owner: me / unassigned / a colleague), sorting by any column and paging;
    Zammad's own limit of 2000 tickets per overview is shown when reached;
  - opened tickets and **drafts** stay as tabs under the overviews (kept on the server, ✕ closes);
  - **a new ticket is a draft** (autosaved) until «Create»: title, customer, how the request came (phone / note /
    web), text, ticket type, group*, owner, state*, priority*, tags; «Cancel & go back» throws it away; an owner
    without full access to the group is reported;
  - in a ticket the side panel — group, owner (agents of the group), state, priority, **tags** — is saved with
    **«Update»**; «Discard changes» brings the values back.
- **Ticket groups for the administrator** — Zammad groups (Cabling, IT Security, IT Support …): create, rename,
  switch off, give / take agents' full access (`PUT /api/v1/users/{id}` with the whole `group_ids` map).
- **Call routing by level** (Level 1 → next Level 1 → Level 2 → Level 3): Zenith Desk sets the queue member penalty
  from the level (AMI `QueuePenalty`, verified by `QueueStatus`; also for people whose pauses are not automated),
  changes it at once when the level changes; page «Call routing»: members, levels, penalties, who is free, who gets
  the next call, warnings (ring strategy, unknown members). Verified on a **real Asterisk 20** (rrmemory, ringinuse=no):
  L1 first, round robin between L1, both L1 on a call → L2, L2 busy → L3, L1 free again → L1, L1 on break → skipped,
  level change → new penalty.
- Notifications bell also loads for administrators at sign-in.
- Test infrastructure: the real mail server script no longer leaves Postfix / Dovecot attached to the caller's
  output (a test could wait for it forever).
- Tests: 15 new server tests (overviews, filters, tabs, drafts, tags, groups, Zammad contract of the new calls,
  routing), real Asterisk routing test (8 checks), UI test of the new ticket screens, groups and routing pages.
- Windows app 3.11 (`ZenithDesk-Setup-3.11.exe`): version only.

## 3.10 — 2026-10-12
- **Backup and restore of the whole system in one file** (admin panel → new section **Backup**):
  - one `*.zdb` file holds every table — users and passwords, panel settings and integrations, ticket links, calls,
    staff chat, Telegram / WhatsApp conversations **with their files**, POP3 mail, audit log, statistics — and the
    server key; encrypted with the **backup password** (AES-256-GCM in 1 MiB authenticated chunks, scrypt key, header,
    chunk number and last-chunk flag authenticated: a changed, cut or reordered file is refused; a wrong password is
    told apart from a damaged file);
  - **Create backup now**; **automatic backups** every day or every week at a chosen time (time zone of the panel),
    catch-up after the server was off, **keep the last N** automatic copies; list with date, type, size, version and
    author; **Download** (short-lived link), **Upload** (with progress), **Check** (password + the whole file, nothing
    changed), **Delete**;
  - **Restore** from the list or from an uploaded file, confirmed by typing `RESTORE`: the file is verified first, a
    **safety copy** of the current state is written, background jobs stop, every table is replaced **in one
    transaction** (all or nothing), settings are read again, Zammad / AMI / Telegram / WhatsApp / mail reconnect, jobs
    start again and every open browser reloads;
  - **restore on a new server**: secrets (panel secrets, SIP and mailbox passwords, VAPID key) and chat / messenger /
    mail texts are **re-encrypted for the key of the restoring server** — `.env` of the old server is not needed;
    PostgreSQL sequences are moved past the restored ids; backups of older versions restore (new columns get
    defaults), backups of newer versions are refused;
  - **failure alerts**: notification for every administrator (bell, live toast, push), `ADMIN_ALERT_WEBHOOK_URL`,
    audit event `backup_failed`, card «Last failure»; retried after 15 minutes without repeating the alert;
  - System status shows the last and the next backup; CLI `python -m app.cli backup | restore FILE | backups`;
    Docker volume `backups` (`/srv/backups`, `BACKUP_DIR`).
- Big files are streamed (≈100 MB of memory for a 160 MB backup with 60 000 messages and 150 files).
- Fix found by the real mail-server tests: a POP3 mailbox with more than 200 messages showed the **oldest** 200 at the
  first check and today's mail only many checks later — now the newest mail comes first, older mail follows.
- The notification bell is shown to administrators too (backup failures and restores).
- Tests: 14 new server tests (format, tampering, wrong password, restore on a server with another key, failed restore
  changes nothing, live restore with jobs running, schedule / daylight saving time, copies, alerts, rights, CLI) on
  SQLite and PostgreSQL; real stack (PostgreSQL + Alembic + uvicorn, two servers with different keys, restore over
  HTTP, restart, CLI restore into an empty database); browser test of the Backup page including a live restore.
- Windows app 3.10 (`ZenithDesk-Setup-3.10.exe`): version only; file version resources corrected (were 3.8).

## 3.9.1 — 2026-10-11 (documentation)
- GitHub-ready `README.md` in English with screenshots (`docs/screenshots/`), architecture diagram, quick start,
  production install, integrations, testing and project layout. The Russian README is kept as `README.ru.md`.
- No code changes: the application version stays 3.9.

## 3.9 — 2026-10-11
- **Telegram and WhatsApp windows** (one company bot and one company number — no personal numbers):
  - list «Open / Mine / Unassigned / Closed» with counters and badges in the side menu; conversation with photos, files,
    voice messages, ✓ sent / ✓✓ delivered / read, failed → «Resend»; **Take**, **Transfer** to a colleague (he is
    notified), only the person who has the conversation may answer; internal notes; quick replies with `{name}`;
    «Call» the customer; «Start» / «Background task» (FR-06); close / reopen.
  - WhatsApp: the 24-hour customer-service window is shown; after it only approved templates can be sent.
  - every conversation is also a **Zammad ticket** (customer found by phone or created; messages, files and notes copied;
    closing closes the ticket; a message after closing opens a new ticket).
  - Telegram Bot API: long polling (no public address needed) or webhook with a secret header. WhatsApp Cloud API:
    signed webhooks (`X-Hub-Signature-256`), verify token, media upload / download, statuses.
  - outbox with retries for messages that could not be sent; duplicates are impossible (unique external id).
- **Mail** (new icon in the side menu): the employee types only the **e-mail and password**; the administrator sets the
  server once — IMAP or POP3, SMTP, ports, SSL / STARTTLS, login format, domain, certificate check. Folders, search,
  safe HTML (cleaned with nh3, sandboxed, remote images on request), attachments, reply / reply all / forward with
  attachments, drafts, Sent, move, delete, **create a Zammad ticket from an e-mail**, new mail instantly (IMAP IDLE).
  Mailbox passwords are verified on the mail server and stored encrypted; a wrong mailbox password never signs the
  person out of Zenith Desk.
- **Admin panel → Integrations** now has tabs: Zammad · Telephony · Telegram · WhatsApp · Mail · **Sync**; every tab
  has «Test» against the real service (bot name, number and quality, mailbox login); Callback URL / Verify token /
  webhook URL to copy.
- **Background synchronisation of every system** (Zammad, Asterisk, Telegram, WhatsApp, mail): real-time events plus a
  **fallback check every 5 minutes** (configurable) that finds and repairs what a network failure made us miss
  (re-registers the Telegram webhook and fetches lost updates, re-sends the outbox, re-copies to Zammad, re-checks
  queue pauses, re-reads the mailbox). Panel *Sync*: real time on/off, last event, last / next check, recovered,
  **retry-queue length**, last error, «Check now». `/api/health` → `integrations`.
- ТЗ gaps closed: **protected call recordings** (played through Zenith Desk — only the operator of the call and managers,
  every play / refusal audited, paths outside the recordings folder refused); **data retention** (audit, calls,
  messages, days set in the panel); **ticket for every answered call** as a setting (ТЗ 15, default: by the button);
  monitoring of the retry queues (ТЗ 10).
- Fixes found by the new real-system tests: the Asterisk fallback check failed on every run (missing `await`); a
  recording announced before the agent's phone rang was lost; database work started from a closed event stream could
  spin forever and block shutdown — it now runs detached; the IMAP IDLE connection broke after the first quiet second
  (a socket timeout poisons Python's buffered reader) — IDLE now waits with select() and stays connected; background
  tasks (push notifications, downloads, inbox checks) are finished or cancelled on shutdown, never left holding a
  database transaction; Sync panel texts follow the interface language.
- Tests: 129 pytest (mail against **real Dovecot + Postfix**, Telegram / WhatsApp against faithful API simulators);
  UI e2e 72 scenarios (Telegram, WhatsApp, mail, integration tabs and Sync); **new end-to-end run on a real
  Asterisk 20.6** (`tests/realstack/asterisk_e2e.py`: AMI with the documented permissions, WebRTC phone registration,
  pause / unpause / DND, Asterisk restart recovery, customer call into a queue answered in the browser, recording
  playback, echo test) — part of the release check.
- Migration 0013 (msg_conversation, msg_message, msg_file, mail_account, mail_local). New dependency: nh3 (MIT).

## 3.8 — 2026-10-11
- **Zenith Desk for Windows** (`windows/`, C# / .NET Framework 4.8 / WinForms + Microsoft Edge WebView2):
  - **`ZenithDesk-Setup-3.8.exe`** — a classic installation wizard (like 1C): language → welcome → license →
    custom setup (desktop / Start menu shortcuts, start with Windows, folder) → **system check** (Windows 10/11,
    .NET Framework 4.8, WebView2 Runtime, disk, admin rights; missing Microsoft components are downloaded from
    Microsoft and installed) → **server connection with a mandatory “Test connection”** (every failure explained:
    name not found, port closed, no answer, not Zenith Desk, HTTPS needed, untrusted certificate, server without
    database) → ready → install (with rollback) → finish (“Launch Zenith Desk”). Repair / Remove when installed,
    update keeps folder and server. Registered in “Installed apps” with an uninstaller. Silent mode for
    administrators: `/S /SERVER= /PORT= [/HTTPS] [/AUTOSTART] …`, removal `/uninstall /S [/REMOVEDATA]`.
  - **`ZenithDesk.exe`** — the workplace window: checks the server first (explained error screen, Retry, Server
    settings, automatic retry), then the sign-in page; login remembered; microphone and notifications only for the
    company server (works on plain HTTP in the LAN too); stays in the notification area so calls are not missed;
    incoming call brings the window back and flashes the taskbar; unread count and user in the title; one window
    per user; window size remembered; links to other sites open in the normal browser.
- Server: `GET /api/desktop/hello` (is this Zenith Desk, version, database, HTTPS required — answered even when
  HTTP is redirected to HTTPS). The web app tells the Windows window about calls and unread messages.
- Tests: `windows/tests/run_tests.sh` — 28 scenarios + file checks (wizard page by page, silent install / update /
  removal, connection test against misbehaving servers, program window, .lnk and .exe resources); part of the
  release check.

## 3.7 — 2026-10-11
- **Minimized phone lives in the top bar**: phone button (status, timer) · “Number or name…” box with live search of
  customers and colleagues · green Call button · **DND** button. Enter calls the highlighted person.
- **Call strip under the top bar on every page** while a call is on (narrow, centred): name / number / company, timer or
  state, +N other lines, Mute · Hold · Transfer · Keypad (DTMF) · End; while ringing — Answer / Decline. Clicking the strip
  opens the phone. An incoming call no longer pops the phone window over the page (the strip rings instead).
- **Do not disturb on the server** (`POST /api/agents/me/dnd`): the operator is paused in all queues (reason “Do not
  disturb”), the browser phone rejects direct calls (486). Same switch in the top bar, the phone menu and My settings;
  pressing **Ready** turns DND off. New column `agent_state.dnd` (migration 0012).
- Phone window: **Keypad** on demand, **Hide** for the volume sliders and AC · AA · CONF · REC · VM, **resize from the
  corner** (80–160 %, the whole phone scales; kept on screen).
- **My settings → Phone**: window style **Classic** (MicroSIP), **Compact** (narrow, keypad and controls on demand) or
  **Side panel** (docked on the right, the page moves aside); minimized to the top-bar dialer or to the button only; call
  strip on/off; keypad / controls; size; DND. Kept per user on that computer.
- **WhatsApp and Telegram** in the side menu (generic icons). The pages explain what is coming; the chat interface is being
  agreed (mock-ups A / B / C), until then these chats are handled in Tickets.
- Tests: 111 pytest (DND), UI e2e 69 scenarios (strip, top-bar dialer, DND, hide / resize, window styles, messenger pages),
  phone e2e 12 scenarios (incoming call in the strip with hold and DTMF over real SIP; DND kept on the server).

## 3.6 — 2026-10-11
- **Zenith Phone with MicroSIP functionality and layout**, drawn in the Command Center design (dark / light):
  - title bar, tabs **Phone · Logs · Contacts**, ▾ menu, status bar (Online / Connecting / Not connected / Do not disturb · extension);
  - number box with history (▾) and live search of customers and colleagues; keypad 1–9 * 0 # with letters,
    **R** (redial), **+**, **C** (delete, double click clears); typing digits on the keyboard works too;
  - **Call / End / Answer** button, **Transfer** on the left (blind, or attended to another line), **Message** on the right
    (opens the messenger with that colleague);
  - **speaker and microphone sliders** with mute buttons and a live microphone level meter;
  - **AC** auto-conference, **AA** auto-answer, **CONF** 3-way conference (mixed in the browser), **REC** call recording
    (saved as a .webm file), **voicemail** button (*97, configurable);
  - **up to 3 lines**: a second call puts the first on hold automatically, line chips to switch, answer / decline a waiting call
    (soft call-waiting tone), DTMF from the keypad during a call (RFC 4733, SIP INFO as fallback);
  - **Logs**: every call kept on this computer (incoming, outgoing, missed, rejected, busy) with duration, missed badge, click to call back;
  - **Contacts**: colleagues with their live state (Ready / busy / break / offline) and customers from Zammad, one click to call;
  - ▾ menu: Do not disturb, Auto-answer, Auto-conference, ring sound, **microphone and speaker selection**, own always-on-top window.
- Admin panel: voicemail number (Integrations → Zenith Phone). New API: `/api/phone/contacts`.
- Tests: `tests/e2e_phone.py` now 12 scenarios against the SIP server (two lines, conference, recording, attended / blind transfer,
  DND, auto-answer, redial, voicemail, logs, contacts).

## 3.5 — 2026-10-11
- **Zenith Phone** — a softphone in the browser (WebRTC to FreePBX / Asterisk, JsSIP 3.13.8 bundled locally):
  - “Phone” button in the top bar with live status (ready / connecting / not connected) and the call timer;
  - small phone window: number or name search (customers from Zammad, colleagues by extension), keypad, recent calls;
  - incoming call rings in the window with the customer's name; Answer / Decline; it opens by itself and, if the call is
    missed, closes again;
  - in a call: mute, hold / resume, keypad (DTMF), blind transfer to a colleague or number, hang up;
  - **own window, always on top of other programs** (Document Picture-in-Picture, Chrome / Edge); elsewhere a floating
    window that can be dragged anywhere;
  - “Call” buttons on the customer card, the ticket page and in the recent calls list;
  - only one tab per browser holds the phone, a second tab offers “Use the phone in this tab”.
- Calls of the browser phone go through FreePBX, so the call card, customer lookup, queues and statistics work as for a
  desk phone (AMI events of the PJSIP channel).
- Admin panel: Integrations → **Zenith Phone** (on/off, WSS address, SIP domain, STUN/TURN); Users → SIP login and
  SIP password of the extension (stored encrypted, delivered only to the owner's browser). DB migration 0011.
- Security headers: microphone allowed for Zenith Desk itself; the PBX WebSocket is added to the Content-Security-Policy.
- Tests: `tests/test_softphone.py`, and `tests/e2e_phone.py` — the real WebRTC engine in Chromium against a SIP-over-WebSocket
  server (`tests/fake_sip.py`): digest registration, outgoing / busy / incoming calls, hold, DTMF, transfer.

## 3.4 — 2026-10-11
- **New name: Zenith Desk** (was Agentix) — in the interface, browser tab, login page, notifications,
  API title and documentation.
- **New logo**: the “Z” with a green dot — sidebar, login page, browser tab icon (SVG + PNG), phone home-screen icon
  and background notifications.
- Nothing changes for data: saved settings, themes, chat encryption and secrets keep working after the update.

## 3.3 — 2026-10-11
- **Tickets inside Agentix** (new “Tickets” page). Operators work with Zammad tickets without opening Zammad:
  - lists Mine / Unassigned / All open / Closed, search, filters by state, priority and group, paging;
  - ticket page: the whole conversation (e-mail, phone, Telegram, WhatsApp, notes) with attachments;
  - internal note, public note or reply to the customer in his own channel (e-mail threaded to his last message,
    Telegram, WhatsApp, SMS), file attachments, optional state change in the same step;
  - state (waiting with a date), priority, group and title; “Take it”; Start / Background work sessions;
  - transfer to a colleague with a comment: only Zammad users with full access to the group are offered, with their
    Agentix status; Zammad silently unassigns an owner without access — Agentix detects it, restores the owner and says why;
  - new ticket: customer search, group, priority, state, type with required fields, “assign to me” or leave for the team.
  Everything is written to Zammad at once **in the operator’s own name** (`From` header) — Zammad checks his group
  rights and its history shows who did it.
- **Two-way sync**: changes made in Zammad itself reach every open Agentix screen by themselves (webhook instantly,
  otherwise a light check every 10 s); the new owner of a transferred ticket gets a notification and a push.
  Closing / transferring a ticket also ends the operator's work session (calls come back).
- **Customers** page (read-only directory of Zammad customers and staff): search by name, phone, e-mail, company,
  card with tickets, “New ticket”. People are created in Zammad; Agentix copies them every 60 s (full check every 6 h,
  “Sync now” button) and shows newcomers immediately.
- Links to tickets everywhere in Agentix (workplace, call card, manager panel, notifications) now open the ticket
  inside Agentix; “Open in Zammad” stays available on the ticket page.
- New settings: ticket check interval, directory sync interval, maximum attachment size. DB migration 0010.
- Tests: `tests/test_ticketing.py` (9 scenarios), contract tests for the new Zammad endpoints, 7 new browser scenarios.

## 3.2 — 2026-10-10
- **Zammad API contract check**: every request Agentix sends was compared with the official Zammad source
  (routes, controllers, ticket selector rules, webhook job). Two compatibility fixes:
  - acting for an operator now sends the `From` header (Zammad 6+) together with `X-On-Behalf-Of` (older versions);
  - ticket and user search read every response shape Zammad uses (`[...]`, `{records}`, `{record_ids, assets}`).
- New `tests/test_zammad_contract.py`: a strict fake that validates conditions, payloads and auth exactly like Zammad.

## 3.1 — 2026-10-10
- **Chat list = conversations**: only people you have written with are listed; search finds any colleague to start a new chat.
- **Live order**: when a message arrives (or you send one) that chat's time and preview change at once and it slides
  to the top with an animation — on every page, not only in Messages.
- **Reactions** ❤️ 👍 😂 😮 😢 🔥 👏 🙏 — one per person per message (like Telegram), the same emoji again removes it,
  shown under the bubble with counters, live on both sides.
- **Edit** your own message within 48 hours (menu → Edit, or ↑ in an empty box); “edited” mark, live on both sides.
- **Delete** for me, or for everyone (own messages) — the text is removed from the database as well.
- Message menu: right click, long press on phones, or the “⋯” button next to a bubble; also “Copy text”.
- **Background notifications (Web Push)**: Settings → “Notifications when Agentix is closed”. A new message pops up on
  the computer even with every Agentix tab closed; clicking it opens the conversation. Sent only when the person has
  no Agentix window open (no doubles). Standard Web Push: payload encrypted for that browser (RFC 8291), server signed
  with VAPID (RFC 8292); expired subscriptions are removed automatically. Requires HTTPS.
- **Security**
  - Messages are **encrypted at rest** in the database (AES via Fernet, key derived from the server secret); messages
    written before 3.1 are encrypted automatically at start-up. A database dump or backup no longer reveals chats.
  - Transport: HTTPS (TLS) through the proxy as before, plus **HSTS**; optional `FORCE_HTTPS=true` redirects plain HTTP.
  - Security headers on every response: Content-Security-Policy (scripts/styles/fonts/connections only from Agentix),
    no framing, no MIME sniffing, strict referrer policy, camera/microphone/location disabled.
  - Privacy unchanged: only the two participants can read a conversation, administrators included.
- Migration `0009` (edit/delete fields, `chat_reaction`, `push_subscription`).
- Tests: 87 automated + 60 browser scenarios.

## 3.0 — 2026-10-10
- **Messenger for employees** — new “Messages” item in the left rail (second icon) with an unread badge.
  Layout like Telegram, colours of the Command Center design:
  - **Left**: search and the list of colleagues — avatar with initials and an online dot, name, time and preview of the
    last message (“You: …”), unread counter, ✓/✓✓ for my last message, position when there is no conversation yet,
    “typing…” live. Newest conversation on top.
  - **Middle**: the conversation — day separators (Today / Yesterday / date), bubbles grouped by sender, time and ✓ sent /
    ✓✓ read in every bubble, older messages load when scrolling up, multi-line messages (Shift+Enter), Enter sends,
    drafts are kept per chat. Header: name and “online / typing… / last seen at …”.
  - **Right** (click the name or avatar): user info — position, level, extension, login, current state, number of
    messages together, in Agentix since.
- **Saved and private**: every message is stored in the database (new table `chat_message`, migration `0008`).
  Only the two participants can read a conversation — administrators included.
- **Live**: messages, read receipts and “typing…” arrive instantly; a new message elsewhere shows a clickable toast,
  a soft chime (if sound is on) and a desktop notification when the window is hidden.
- Works on phones (list → conversation with a back button) and on any monitor.
- Tests: 79 automated + 59 browser scenarios (new: search, live delivery, badge, toast, ✓✓, typing, profile, history,
  privacy, validation).

## 2.9 — 2026-10-10
- **Responsive on every screen**: the interface now fills the whole width of any monitor (the content used to stop
  at 1680 px and leave an empty strip on the right on Full-HD and larger screens).
  - Large monitors (1800 px+, 2400 px+): a little more spacing and larger key numbers.
  - Charts are drawn at their real pixel width, so axis labels keep the same size from a phone to a 4K monitor.
  - Small phones (≤ 420 px): tighter spacing, full-width buttons in dialogs, period buttons share the row.
  - Long values (audit details, URLs) wrap instead of pushing the page sideways — fixed horizontal scrolling of the
    Manager panel on phones.
- Checked automatically on every page (login, workplace, manager panel, overview, settings, all admin pages) at
  360, 390, 768, 1024, 1280, 1440, 1920, 2560 and 3440 px: no sideways scrolling, no empty strip, nothing cut off.
- Tests: 74 automated + 58 browser scenarios (new: responsive check from 360 px to 2560 px).

## 2.8 — 2026-10-10
- **Inactivity pause**: when somebody has not used Agentix for 60 minutes (System settings → General →
  “Pause after inactivity, minutes”, 0 = off):
  - two minutes before, a quiet reminder appears at the bottom with a countdown — any movement keeps the person online;
  - then the whole interface **freezes**: it slowly dims to a dark, desaturated tone, animations stop, nothing can be
    clicked, and a card says “Paused — you were away” with the time the person left;
  - the person becomes **Offline**, so queue calls stop ringing at an empty desk; tasks are kept untouched;
  - managers see it live on the Manager panel: “Offline · Away: no activity in Agentix · since 18:53” and an AWAY tag;
  - “I'm back” restores exactly the previous state (Ready or Break) and calls resume; “Sign out” is also offered.
- Activity is any mouse, keyboard, touch or scroll in **any** Agentix tab; the server keeps the last moment and also
  pauses people whose computer went to sleep or whose browser was left open (checked every 30 s).
  Nobody is paused during an active phone call. A manager override also ends the pause.
- Audit log: `idle_offline` and `idle_returned`.
- Migration `0007` (agent_state.last_activity_at, idle_since).
- Tests: 74 automated + 57 browser scenarios.

## 2.7 — 2026-10-10
- **Live mode everywhere**: whatever the server receives reaches every screen that shows it at the same moment
  (measured 50–80 ms from a call event to the operator's screen), no reload, no waiting for a timer.
  - The service watches its own database: after every successful commit it pushes a small `changed` event to
    exactly the right people. New code paths cannot “forget” to notify — and nothing is sent for a rolled-back change.
  - Operator: tasks, calls, notifications, ticket lists (a Zammad webhook refreshes “New requests” for everyone),
    own account (level, position, being disabled → signed out at once).
  - Manager panel and Overview: states, tasks, calls, queue, audit log and statistics update live;
    the “longest wait” counter ticks every second.
  - Administration: users, ticket types, system status and settings reload when someone else changes them
    (never over unsaved edits).
- **Connection that heals itself**: “Live / Reconnecting…” indicator in the top bar; heartbeat every 15 s, a silent
  dead connection is detected within 35 s, reconnect after 1 s with backoff, and after every reconnect the screen
  is fully re-synchronised, so nothing that happened while offline is lost.
- **Instant restarts**: open live connections no longer block the server from stopping (it used to wait until
  Docker killed it); browsers reconnect to the new process in ~1.5 s.
- Demo: `DEMO_DB=/path/demo.db` keeps demo data between restarts.
- Tests: 69 automated + 56 browser scenarios (new: commit → push routing, rollback sends nothing, Zammad webhook →
  ticket lists, admin change → user's screen, timed live update on the Overview).

## 2.6 — 2026-10-10
- **Motion design** — minimal, calm and fast (120–320 ms), never moves data around:
  - **Page transitions**: the old page fades and slides out, the new one slides in; the direction follows the
    order of the menu (forward = from the right, back = from the left). Built on the browser's View Transitions API,
    so data and buttons change instantly — the animation is only visual. Older browsers get a soft fade-in.
  - **Theme switch** spreads as a circle from the button you clicked.
  - **Micro-interactions**: buttons lift on hover and press in on click with a ripple from the touch point;
    rail icons grow, the active item gets a sliding marker, tooltips glide in; the bell wiggles; checkboxes became
    animated switches; level and period chips pop; presets and leaders respond to the pointer.
  - **Fluid content**: dashboard blocks, cards and table rows appear with a short stagger; charts grow from the
    baseline, lines and the service-level gauge draw themselves, meters fill; changed live numbers briefly light up;
    toasts slide in and out; dialogs and popovers scale in; skeleton placeholders while statistics load.
- **Settings → Animations and smooth transitions** (per user, saved in the account). Animations are also switched off
  automatically when the operating system asks for reduced motion.
- Tests: 64 automated + 55 browser scenarios (all run with animations on; new: transitions, ripple, switching animations off).

## 2.5 — 2026-10-10
- **Manager Overview** (new item in the left rail for Managers): the whole picture of the contact center for
  Today / Yesterday / 7 days / 30 days, filter by level, refreshes every 30 s.
  - Incoming calls, answered, **missed** (abandoned + not answered; short abandons ≤ 5 s shown but not counted),
    answer rate, abandon rate, **service level** gauge (answered within 20 s, target 80 % — configurable),
    average speed of answer, longest wait, average talk time, outbound calls.
  - **Right now**: calls waiting in the queue and the longest wait, operators on a call / ready / busy / on break.
  - **Calls by hour** (answered vs missed, tooltip with service level), peak hour;
    **staffing vs workload** (operators logged in vs talk load in Erlang).
  - **Leaders**: most calls answered, most tickets completed.
  - **Missed callers not called back**: numbers whose missed call was neither answered later nor called back.
  - **Operators table**: logged-in time, ready share, breaks, occupancy, calls answered of rung,
    “did not pick up” (RONA — a colleague answering first is not counted), talk and average talk, tickets,
    **engagement index** and warning flags (does not pick up / long breaks / low load). Sortable.
  - “How the numbers are calculated” — every formula is written on the page.
- New table `queue_call` (migration `0006`) filled from AMI `QueueCallerJoin / AgentConnect / AgentComplete /
  QueueCallerAbandon / QueueCallerLeave`: one row per customer call, so a call that rang several operators is counted once.
- System settings → “Manager overview (statistics)”: service-level seconds, target %, short-abandon seconds.
- Demo: four extra operators with a realistic working day so the overview can be shown right away.
- Tests: 64 automated (hand-calculated scenario for every metric + real AMI event flow) and 54 browser scenarios.

## 2.4 — 2026-10-10
- **New design “Command Center”** (option A chosen by the customer) for the whole system: operator workplace,
  Manager panel, administration, personal settings, login, dialogs and mobile view.
  - Dark console look by default; the light variant of the same design stays available
    (Settings → Theme: Dark (default) / Light / Like the system, or the sun/moon button in the rail).
  - Narrow icon rail on the left with tooltips; on phones it turns into a top bar with a menu.
  - Top bar: live status with Asterisk confirmation line, Ready / Break, Customize, notifications,
    and the user block (initials, name, level and position under the name).
  - KPI strip with large monospaced numbers; default layout: work on the left (⅔),
    notifications and recent calls on the right (⅓); the incoming call is a green “live call” card.
  - IBM Plex Sans / IBM Plex Mono fonts (Latin + Cyrillic) served by Agentix itself — no internet needed.
  - Emoji replaced by line icons.
- Personal theme value `system` added (`""` = default dark look).
- Tests: 58 automated + 52 browser scenarios (new: design check — dark by default, icon rail, local fonts).

## 2.3 — 2026-10-10
- **Manager leads Level 1–3 staff (ТЗ FR-08, FR-10, criterion 10)**: the level now decides access rights.
  Level 1/2/3 → operator workplace; Manager → workplace + Manager panel; Administrator → administration.
  A separate “role” field is gone, so a Manager can no longer be left without team rights by mistake.
  Migration `0005` aligns existing users with their level.
- **Manager panel** (renamed from “Supervisor”): filter the team by level (All / Level 1 / Level 2 / Level 3 / Manager)
  with counts; summary cards and the 24-hour report follow the filter; staff sorted by level.
  The manager sees each operator's state and reason, tasks, can reconcile, override with a reason (audited),
  cancel a session and assign a ticket by number.
- User form: “Access (follows the level)” shows what the chosen level allows.
- Tests: 58 automated + 51 browser scenarios (new: level filter, “Manager” level gives the Manager panel).

## 2.2 — 2026-10-10
- **Customizable workspace**: every user can rearrange dashboard blocks (drag & drop or ◀ ▶), change their width
  (⅓ / ⅔ / full) and height (auto / S / M / L), hide and show blocks. Changes are saved to the user's account,
  so the workspace looks the same on any computer.
- **Ready layouts**: Default, Calls focus, Tickets focus, Compact, Minimal + “My layout”; “Reset to default”.
- **Settings** (personal) in the sidebar: theme (system / light / dark), compact density, workspace layout,
  sound on incoming calls, desktop notifications, account details, password change.
- **Levels (grades)**: Administrator, Level 1 (Entry-Level), Level 2 (Mid-Level), Level 3 & Above (Senior), Manager.
  Required when the administrator creates a user; shown in light color under the user's name (sidebar, supervisor
  panel, users list). Choosing a level suggests the matching role.
- Admin menu item “Settings” renamed to “System settings” (personal settings are separate).
- Database migration 0004 (level, personal preferences); existing supervisors get “Manager”, admins “Administrator”.
- Release check: 57 automated tests (SQLite + PostgreSQL), migrations, 49/49 browser scenarios (EN and RU).

## 2.1 — 2026-10-10
- **Operator dashboard**: summary cards (active tasks, background, completed today, calls today answered/missed,
  time busy with tasks) above the work panels.
- **Notification center** (FR-09): bell with unread counter + notifications panel — telephony sync problems,
  ticket reassigned / removed by supervisor, supervisor override, ticket closed or put on hold in Zammad,
  missed calls, password reset. Supervisors also see sync problems of all operators.
- Incoming call: sound signal and desktop notification (when the tab is in the background).
- **Light / dark theme** switch (sidebar and login page), remembered per browser; follows the system by default.
- **Supervisor** (FR-10): summary cards (online/ready/busy/break/offline/sync problems) and
  **assign / reassign a ticket by its number** from the panel.
- Database migration 0003 (notifications read marker).
- `docs/TZ_COMPLIANCE.md`: item-by-item compliance with the specification.
- Release check: 55 automated tests (SQLite + PostgreSQL), migrations, 45/45 browser scenarios (EN and RU).

## 2.0 — 2026-10-10
- **Administrator panel** (left sidebar): Users, Integrations (API), Settings, Ticket types, System status.
- **Own logins**: the administrator creates employees (first/last name, login, position, password, role) and links them
  to a Zammad user and a phone extension. Employees sign in with that login — no Zammad password and no setup on their computers.
- Password management: set/reset passwords, “change at first sign-in”, users change their own password,
  sessions end immediately when a user is disabled or the password changes, lock-out after 5 failed sign-ins.
- **All settings in the panel** (Zammad, AMI, queues, ticket states, language, time zone, rules…), applied immediately
  without restarting the server. API tokens and passwords are stored encrypted. “Test connection” for Zammad and AMI.
- `.env` now needs only POSTGRES_PASSWORD and JWT_SECRET; the first administrator is created automatically.
- New database migration 0002 (existing data is kept). Users from 1.x need a login and password set in the panel.
- Release check: 51 automated tests (SQLite + PostgreSQL), migrations, 40/40 browser scenarios.

## 1.4 — 2026-10-10
- Full release check: `python -m scripts.release_check` runs all tests (SQLite + PostgreSQL), migrations
  (upgrade/check/downgrade) and an end-to-end browser test of every UI function (28 scenarios).
- Zammad HTTP requests are no longer logged one by one (less log noise).
- Release check result for 1.4: ALL CHECKS PASSED (41 tests, migrations, 28/28 UI scenarios, EN and RU).

## 1.3 — 2026-10-10
- Product name: **Agentix**. Shown on the login page, in the top bar, browser tab and API docs.

## 1.2 — 2026-10-10
- Login: leading/trailing spaces in the login are ignored; demo logins are case-insensitive.
- Version number shown in the interface (login page and top bar) and in `/api/health`.

## 1.1 — 2026-10-10
- Interface in English by default; `UI_LANGUAGE=en|ru` switches the interface and server messages.
- Demo data translated to English.

## 1.0 — 2026-10-10
- First release: Task & Agent State Service, operator and supervisor UI, Zammad + FreePBX/Asterisk (AMI) integration,
  tests, Docker Compose, documentation.
