"""SEC-08: stronger scrypt parameters with transparent upgrade at sign-in; SEC-09: hashing no longer blocks the
server's event loop. Users: 1 anna, 2 boris, 3 boss, 4 root (password "pw")."""
import asyncio
import base64
import hashlib
import os
import time

import pytest

from app import crypto
from app.models import AgentMapping


def old_hash(pw: str) -> str:
    """How v3.20.1 and earlier stored passwords: scrypt N=2^14, r=8, p=1."""
    salt = os.urandom(16)
    dk = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt$16384$8$1${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def test_new_hashes_use_the_stronger_parameters():
    h = crypto.hash_password("correct horse")
    assert h.split("$")[1:4] == ["16384", "8", "5"]
    assert crypto.verify_password("correct horse", h) and not crypto.verify_password("wrong", h)
    assert not crypto.needs_rehash(h) and crypto.needs_rehash(old_hash("x")) and crypto.needs_rehash("garbage")


def test_old_hashes_still_verify():
    assert crypto.verify_password("pw", old_hash("pw"))


def test_a_hostile_stored_hash_cannot_exhaust_memory():
    salt = base64.b64encode(b"0" * 16).decode()
    for n, r, p in ((2**24, 8, 1), (2**14, 1024, 1), (2**14, 8, 10_000), (0, 8, 1), (3, 0, 1)):
        assert crypto.verify_password("pw", f"scrypt${n}${r}${p}${salt}$AAAA") is False


@pytest.mark.asyncio
async def test_old_hash_is_upgraded_at_sign_in(env):
    async with env.services.db.sessionmaker() as s:
        anna = await s.get(AgentMapping, 1)
        anna.password_hash = old_hash("pw")
        await s.commit()
    h = await env.login("anna")
    assert (await env.client.get("/api/auth/me", headers=h)).status_code == 200  # the new token matches the new hash
    async with env.services.db.sessionmaker() as s:
        stored = (await s.get(AgentMapping, 1)).password_hash
    assert stored.split("$")[3] == "5" and crypto.verify_password("pw", stored)
    r = await env.client.post("/api/auth/login", json={"username": "anna", "password": "nope"})
    assert r.status_code == 401
    async with env.services.db.sessionmaker() as s:
        assert (await s.get(AgentMapping, 1)).password_hash == stored  # a failed sign-in changes nothing


@pytest.mark.asyncio
async def test_hashing_does_not_freeze_the_server():
    """SEC-09: while a password is checked, other work keeps running (before: the event loop stopped ~50-250 ms
    per attempt, so a stream of wrong passwords slowed every user)."""
    h = crypto.hash_password("pw")
    ticks = 0

    async def ticker():
        nonlocal ticks
        while True:
            await asyncio.sleep(0.005)
            ticks += 1
    t = asyncio.create_task(ticker())
    start = time.monotonic()
    await asyncio.gather(*(crypto.verify_password_async("bad", h) for _ in range(4)))
    spent = time.monotonic() - start
    t.cancel()
    assert ticks >= spent / 0.005 * 0.4, (ticks, spent)  # the loop kept ticking the whole time
