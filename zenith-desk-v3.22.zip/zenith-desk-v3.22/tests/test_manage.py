"""v3.15 manager tools: call supervision, shift schedule with attendance, recordings archive, the log."""
import logging
from datetime import date, datetime, timedelta, timezone

from sqlalchemy import select

from app.db import utcnow
from app.models import AgentMapping, AuditLog, CallRecord, Shift
from app.shifts import attendance, intervals, local_span

from .conftest import IF1

UTC = timezone.utc


def T(h, m=0, day=2):  # 2026-03-<day> h:m UTC
    return datetime(2026, 3, day, h, m, tzinfo=UTC)


async def answered_call(env, linkedid="1700.9", number="+37491123456"):
    for ev in ({"Event": "AgentCalled", "Queue": "400", "Interface": IF1, "CallerIDNum": number, "Uniqueid": linkedid, "Linkedid": linkedid},
               {"Event": "AgentConnect", "Queue": "400", "Interface": IF1, "Uniqueid": linkedid, "Linkedid": linkedid}):
        await env.services.calls.handle_event(ev)


async def set_ext(env, agent_id, ext):
    async with env.services.db.sessionmaker() as s:
        (await s.get(AgentMapping, agent_id)).extension = ext
        await s.commit()


async def actions(env, prefix=""):
    async with env.services.db.sessionmaker() as s:
        rows = (await s.execute(select(AuditLog).order_by(AuditLog.id))).scalars().all()
    return [r for r in rows if r.action.startswith(prefix)]


# ====================================================================== call supervision
async def test_listen_whisper_barge(env):
    boss, anna = await env.login("boss"), await env.login("anna")
    await answered_call(env)
    # the manager needs his own phone
    r = await env.client.post("/api/sup/spy", json={"agent_id": 1, "mode": "listen"}, headers=boss)
    assert r.status_code == 409 and "extension" in r.text
    await set_ext(env, 3, "103")
    team = (await env.client.get("/api/admin/agents", headers=boss)).json()
    talking = {a["agent_id"]: a["call"] for a in team["agents"]}
    assert talking[1]["number"] == "+37491123456" and talking[2] is None and team["spy"] is None and team["spy_enabled"]
    # operators may not listen; nobody listens to somebody who is not on a call
    assert (await env.client.post("/api/sup/spy", json={"agent_id": 2, "mode": "listen"}, headers=anna)).status_code == 403
    r = await env.client.post("/api/sup/spy", json={"agent_id": 2, "mode": "listen"}, headers=boss)
    assert r.status_code == 409 and "not on a call" in r.text
    assert (await env.client.post("/api/sup/spy", json={"agent_id": 1, "mode": "shout"}, headers=boss)).status_code == 422
    r = await env.client.post("/api/sup/spy", json={"agent_id": 1, "mode": "listen"}, headers=boss)
    assert r.status_code == 200, r.text
    sess = r.json()["session"]
    assert sess["agent_id"] == 1 and sess["mode"] == "listen" and sess["digit"] == "4" and sess["caller"].startswith("zspy")
    spy = env.pbx.spies[-1]
    # Asterisk rings the manager's phone and ChanSpy listens to anna's phone (never also 1011, 1012…)
    assert spy["dial"] == "PJSIP/103" and spy["target"] == "PJSIP/101-" and spy["options"] == "qdE"
    assert spy["channel_id"] == "zspy-" + sess["id"] and f"<{sess['caller']}>" in spy["caller_id"]
    assert (await env.client.get("/api/sup/spy", headers=boss)).json()["session"]["id"] == sess["id"]
    # whisper → key 5, barge → key 6
    r = await env.client.post("/api/sup/spy/mode", json={"mode": "whisper"}, headers=boss)
    assert r.json()["session"]["digit"] == "5"
    assert (await env.client.post("/api/sup/spy/mode", json={"mode": "barge"}, headers=boss)).json()["session"]["digit"] == "6"
    # the manager's listening channel is never a customer call (no call card, not in the statistics)
    chan = spy["channel_id"]
    await env.services.calls.handle_event({"Event": "DialBegin", "DestChannel": "PJSIP/103-00000009", "DestUniqueid": chan,
                                           "DestLinkedid": chan, "DestCallerIDNum": sess["caller"]})
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(CallRecord).where(CallRecord.agent_id == 3))).scalars().all() == []
    # he put the phone down → the session ends by itself
    await env.services.calls.handle_event({"Event": "Hangup", "Uniqueid": chan, "Linkedid": chan, "Channel": "PJSIP/103-00000009"})
    assert (await env.client.get("/api/sup/spy", headers=boss)).json()["active"] is False
    acts = [(r.action, r.details.get("mode") or r.details.get("new"), r.agent_id, r.actor_id) for r in await actions(env, "spy_")]
    assert acts == [("spy_started", "listen", 1, 3), ("spy_mode", "whisper", 1, 3), ("spy_mode", "barge", 1, 3), ("spy_stopped", "barge", 1, None)]
    # Stop from the page hangs up the channel in Asterisk
    await env.client.post("/api/sup/spy", json={"agent_id": 1, "mode": "barge"}, headers=boss)
    assert env.pbx.spies[-1]["options"] == "qdEB"
    assert (await env.client.delete("/api/sup/spy", headers=boss)).json() == {"active": False}
    assert env.pbx.hangups == [env.pbx.spies[-1]["channel_id"]]
    assert (await env.client.post("/api/sup/spy/mode", json={"mode": "listen"}, headers=boss)).status_code == 404
    # switched off by the administrator
    env.settings.supervise_enabled = False
    assert (await env.client.post("/api/sup/spy", json={"agent_id": 1, "mode": "listen"}, headers=boss)).status_code == 403


async def test_spy_needs_pbx_and_not_self(env):
    boss = await env.login("boss")
    await set_ext(env, 3, "103")
    assert (await env.client.post("/api/sup/spy", json={"agent_id": 3, "mode": "listen"}, headers=boss)).status_code == 409
    await answered_call(env)
    env.pbx.connected_flag = False
    assert (await env.client.post("/api/sup/spy", json={"agent_id": 1, "mode": "listen"}, headers=boss)).status_code == 503


# ====================================================================== attendance rules
def test_attendance_rules():
    s0, s1 = T(9), T(18)
    on = lambda *pairs: [[a, b] for a, b in pairs]  # noqa: E731
    # came 08:50, left 18:05 → fine
    a = attendance(s0, s1, on((T(8, 50), T(18, 5))), T(19), 5, 30)
    assert a.status == "done" and a.problems == [] and a.worked_min == 540
    # came 09:20 → late 20 min; left 17:30 → early 30 min
    a = attendance(s0, s1, on((T(9, 20), T(17, 30))), T(19), 5, 30)
    assert a.late_min == 20 and a.early_min == 30 and a.problems == ["late", "early_leave"]
    # 4 minutes late is within the grace time
    assert attendance(s0, s1, on((T(9, 4), T(18))), T(19), 5, 30).problems == []
    # nobody yet at 09:03 → waiting; at 09:10 → late (still not in); at 09:31 → absent
    assert attendance(s0, s1, [], T(9, 3), 5, 30).status == "waiting"
    a = attendance(s0, s1, [], T(9, 10), 5, 30)
    assert a.status == "waiting" and a.late_min == 10 and a.problems == ["late"]
    assert attendance(s0, s1, [], T(9, 31), 5, 30).problems == ["absent"]
    # during the shift: working / away; after a break he came back, so no early leave
    assert attendance(s0, s1, on((T(9), T(12))), T(12), 5, 30).status == "working"
    assert attendance(s0, s1, on((T(9), T(12))), T(13), 5, 30).status == "away"
    a = attendance(s0, s1, on((T(9), T(12)), (T(13), T(18, 1))), T(19), 5, 30)
    assert a.problems == [] and a.worked_min == 480
    assert attendance(s0, s1, [], T(8), 5, 30).status == "upcoming"
    # presence intervals from change events
    ev = [(T(8, 55), True), (T(12), False), (T(13), True)]
    assert intervals(ev, False, T(6), T(14)) == [[T(8, 55), T(12)], [T(13), T(14)]]
    assert intervals([], True, T(6), T(7)) == [[T(6), T(7)]]
    # a night shift 22:00–06:00 local time ends the next day
    a, b = local_span(date(2026, 3, 2), "22:00", "06:00", "Asia/Yerevan")
    assert (a, b) == (T(18), T(2, day=3))


# ====================================================================== shift schedule API
async def test_shift_schedule(env):
    boss, anna = await env.login("boss"), await env.login("anna")
    env.settings.display_timezone = "UTC"
    days = ["2026-03-02", "2026-03-03"]
    assert (await env.client.post("/api/sup/shifts", json={"agent_ids": [1], "dates": days, "start": "09:00", "end": "18:00"},
                                  headers=anna)).status_code == 403
    r = await env.client.post("/api/sup/shifts", json={"agent_ids": [1, 2], "dates": days, "start": "09:00", "end": "18:00",
                                                       "note": "front desk"}, headers=boss)
    assert r.json()["created"] == 4
    # the same people again at an overlapping time → skipped; "replace" swaps them
    r = await env.client.post("/api/sup/shifts", json={"agent_ids": [1], "dates": days, "start": "12:00", "end": "20:00"}, headers=boss)
    assert r.json() == {"created": 0, "skipped": 2, "removed": 0, "ids": []}
    r = await env.client.post("/api/sup/shifts", json={"agent_ids": [1], "dates": days[:1], "start": "12:00", "end": "20:00",
                                                       "replace": True}, headers=boss)
    assert r.json()["created"] == 1 and r.json()["removed"] == 1
    for bad in ({"start": "9:00", "end": "18:00"}, {"start": "09:00", "end": "09:00"}, {"start": "25:00", "end": "18:00"}):
        assert (await env.client.post("/api/sup/shifts", json={"agent_ids": [1], "dates": days, **bad}, headers=boss)).status_code == 422
    week = (await env.client.get("/api/sup/shifts?start=2026-03-02&days=7", headers=boss)).json()
    assert len(week["days"]) == 7 and {a["id"] for a in week["agents"]} >= {1, 2, 3}
    shifts = sorted(week["shifts"], key=lambda x: (x["agent_id"], x["starts_at"]))
    assert [(x["agent_id"], x["starts_at"][:16]) for x in shifts] == [
        (1, "2026-03-02T12:00"), (1, "2026-03-03T09:00"), (2, "2026-03-02T09:00"), (2, "2026-03-03T09:00")]
    assert shifts[2]["note"] == "front desk" and shifts[2]["attendance"]["status"] == "absent"  # a past day without anybody
    # edit, overlap check, delete
    sid = shifts[0]["id"]
    r = await env.client.put(f"/api/sup/shifts/{sid}", json={"date": "2026-03-03", "start": "08:00", "end": "10:00"}, headers=boss)
    assert r.status_code == 409
    r = await env.client.put(f"/api/sup/shifts/{sid}", json={"date": "2026-03-02", "start": "22:00", "end": "06:00", "note": "night"}, headers=boss)
    assert r.status_code == 200 and r.json()["ends_at"].startswith("2026-03-03T06:00")
    assert (await env.client.delete(f"/api/sup/shifts/{shifts[1]['id']}", headers=boss)).json() == {"ok": True}
    assert (await env.client.delete(f"/api/sup/shifts/{shifts[1]['id']}", headers=boss)).status_code == 404
    # copy the week to the next one
    r = await env.client.post("/api/sup/shifts/copy", json={"source": "2026-03-02", "target": "2026-03-09", "days": 7}, headers=boss)
    assert r.json() == {"created": 3, "skipped": 0}
    r = await env.client.post("/api/sup/shifts/copy", json={"source": "2026-03-02", "target": "2026-03-09", "days": 7}, headers=boss)
    assert r.json() == {"created": 0, "skipped": 3}
    nxt = (await env.client.get("/api/sup/shifts?start=2026-03-09&days=7", headers=boss)).json()["shifts"]
    assert sorted(x["starts_at"][:16] for x in nxt) == ["2026-03-09T09:00", "2026-03-09T22:00", "2026-03-10T09:00"]
    # templates
    r = await env.client.post("/api/sup/shift-templates", json={"name": "Morning", "start": "09:00", "end": "18:00", "color": "#3b82f6"}, headers=boss)
    tid = r.json()["id"]
    assert (await env.client.get("/api/sup/shifts", headers=boss)).json()["templates"][0]["name"] == "Morning"
    assert (await env.client.delete(f"/api/sup/shift-templates/{tid}", headers=boss)).json() == {"ok": True}
    # the operator sees his own coming shifts
    today = datetime.now(UTC).date().isoformat()
    await env.client.post("/api/sup/shifts", json={"agent_ids": [1, 2], "dates": [today], "start": "23:00", "end": "23:30"}, headers=boss)
    mine = (await env.client.get("/api/agents/me/shifts", headers=anna)).json()["shifts"]
    assert len(mine) == 1 and mine[0]["agent_id"] == 1
    acts = [r.action for r in await actions(env, "shift_")]
    assert acts.count("shift_planned") >= 3 and "shift_changed" in acts and "shift_removed" in acts and "shift_copied" in acts


async def test_lateness_alerts(env):
    boss, anna = await env.login("boss"), await env.login("anna")
    env.settings.display_timezone = "UTC"
    async with env.services.db.sessionmaker() as s:
        await s.execute(AuditLog.__table__.delete())  # only the presence history below
        for aid, ts, new in ((1, T(9, 25), "ready"), (1, T(17), "offline"),   # anna: 25 min late, left an hour early
                             (2, T(8, 40), "ready")):                          # boris: on time and still here
            s.add(AuditLog(action="availability_changed", agent_id=aid, ts=ts, details={"old": "offline", "new": new}))
        for aid in (1, 2, 3):  # the manager himself never came
            s.add(Shift(agent_id=aid, starts_at=T(9), ends_at=T(18)))
        await s.commit()
    watch = env.services.shifts
    assert await watch.check(now=T(9, 10)) == 2  # nobody of anna and the manager yet → late (not in); boris fine
    assert await watch.check(now=T(9, 12)) == 0  # told once
    assert await watch.check(now=T(9, 40)) == 1  # the manager is absent now; anna came (late, already told)
    assert await watch.check(now=T(18, 30)) == 1  # anna left early
    got = [(r.action, r.agent_id, r.details.get("minutes"), r.details.get("arrived")) for r in await actions(env, "shift_")]
    assert sorted(got, key=str) == sorted([("shift_late", 1, 10, False), ("shift_late", 3, 10, False), ("shift_absent", 3, None, False),
                                           ("shift_early_leave", 1, 60, True)], key=str)
    # the managers are told in their notification center, the operator is not
    texts = [i["text"] for i in (await env.client.get("/api/agents/me/notifications", headers=boss)).json()["items"] if i["kind"] == "shift"]
    assert any("left the shift 60 min early" in x for x in texts) and any("absent" in x for x in texts)
    assert not [i for i in (await env.client.get("/api/agents/me/notifications", headers=anna)).json()["items"] if i["kind"] == "shift"]
    # the schedule shows the same
    day = {x["agent_id"]: x["attendance"] for x in (await env.client.get("/api/sup/shifts?start=2026-03-02&days=1", headers=boss)).json()["shifts"]}
    assert day[1]["late_min"] == 25 and day[1]["early_min"] == 60 and day[2]["problems"] == [] and day[3]["absent"]
    env.settings.shift_alerts = False
    assert await watch.check(now=T(19)) == 0


# ====================================================================== recordings archive
async def add_call(s, agent_id, start, talk=60, number="+37491123456", direction="in", ticket=None, queue="400", rec="r.wav"):
    c = CallRecord(linkedid=f"l{start.timestamp()}{agent_id}", agent_id=agent_id, direction=direction, queue=queue, caller_number=number,
                   caller_normalized=number.lstrip("+"), state="ended", started_at=start, answered_at=start + timedelta(seconds=5),
                   ended_at=start + timedelta(seconds=5 + talk), recording_file=rec, ticket_id=ticket)
    s.add(c)
    return c


async def test_recordings_archive(env, tmp_path):
    boss, anna = await env.login("boss"), await env.login("anna")
    env.settings.display_timezone = "Asia/Yerevan"  # UTC+4
    (tmp_path / "monitor").mkdir()
    (tmp_path / "monitor" / "r.wav").write_bytes(b"RIFF....WAVE")
    env.settings.recording_dir = str(tmp_path / "monitor")
    async with env.services.db.sessionmaker() as s:
        await add_call(s, 1, T(6), talk=120)                                      # 10:00 local
        await add_call(s, 1, T(11, 30), talk=20, number="+79123456789", ticket=7)  # 15:30 local
        await add_call(s, 2, T(19), direction="out", queue="")                     # 23:00 local
        await add_call(s, 2, T(7, day=5))
        await add_call(s, 1, T(8), rec="")                                         # no recording: not listed
        await s.commit()
    q = "/api/recordings?date_from=2026-03-02&date_to=2026-03-05"
    all_ = (await env.client.get(q, headers=boss)).json()
    assert all_["total"] == 4 and [i["started_at"][:13] for i in all_["items"]] == ["2026-03-05T07", "2026-03-02T19", "2026-03-02T11", "2026-03-02T06"]
    assert {a["name"] for a in all_["agents"]} >= {"Анна", "Борис"} and all_["items"][0]["agent_name"] == "Борис"
    assert all_["items"][0]["url"] == f"/api/calls/{all_['items'][0]['id']}/recording"

    async def n(extra, h=boss):
        return (await env.client.get(q + extra, headers=h)).json()["total"]
    assert await n("&date_to=2026-03-02") == 3
    assert await n("&time_from=09:00&time_to=12:00") == 2  # by the hour, local time: 10:00 + the 11:00 one of the 5th
    assert await n("&time_from=22:00&time_to=02:00") == 1  # over midnight
    assert await n("&agent_id=2") == 2 and await n("&direction=out") == 1 and await n("&queue=400") == 3
    assert await n("&number=912345") == 1 and await n("&number=8 912 345 67 89") == 1
    assert await n("&min_sec=100") == 1 and await n("&ticket=yes") == 1 and await n("&ticket=no") == 3
    assert (await env.client.get(q + "&limit=2&offset=2", headers=boss)).json()["items"][0]["started_at"].startswith("2026-03-02T11")
    # v3.17.1: the archive is for managers and administrators only
    assert (await env.client.get(q, headers=anna)).status_code == 403
    assert (await env.client.get(q, headers=await env.login("root"))).json()["total"] == 4
    # listen and download, both audited
    cid = all_["items"][-1]["id"]
    r = await env.client.get(f"/api/calls/{cid}/recording?download=1", headers=boss)
    assert r.status_code == 200 and r.headers["content-disposition"].startswith("attachment") and r.content == b"RIFF....WAVE"
    assert (await env.client.get(f"/api/calls/{cid}/recording", headers=boss)).headers["content-disposition"].startswith("inline")
    other = all_["items"][0]["id"]
    assert (await env.client.get(f"/api/calls/{other}/recording", headers=anna)).status_code == 403
    assert [r.action for r in await actions(env, "recording_")] == ["recording_downloaded", "recording_played", "recording_denied"]
    assert (await env.client.get("/api/recordings?date_from=2024-01-01&date_to=2026-03-05", headers=boss)).status_code == 422


# ====================================================================== the log
async def test_log_filters_and_rights(env):
    boss, anna, root = await env.login("boss"), await env.login("anna"), await env.login("root")
    async with env.services.db.sessionmaker() as s:
        s.add_all([
            AuditLog(action="system_log", level="error", ts=T(10), details={"logger": "ami", "message": "connection refused", "count": 3}),
            AuditLog(action="manual_state", agent_id=1, actor_type="agent", actor_id=1, ts=T(11), details={"old": "ready", "new": "break"}),
            AuditLog(action="ticket_created", agent_id=1, actor_type="agent", actor_id=1, ticket_id=77, ts=T(12), details={"title": "Printer"}),
            AuditLog(action="user_created", actor_type="admin", actor_id=4, ts=T(13), details={"username": "new"}),
            AuditLog(action="shift_late", agent_id=2, level="warning", ts=T(14), details={"minutes": 12}),
        ])
        await s.commit()
    since, until = "2026-03-02T00:00:00Z", "2026-03-03T00:00:00Z"
    base = f"/api/log?since={since}&until={until}"

    async def get(extra="", h=root):
        r = await env.client.get(base + extra, headers=h)
        assert r.status_code == 200, r.text
        return [x["action"] for x in r.json()["items"]]
    assert await get() == ["shift_late", "user_created", "ticket_created", "manual_state", "system_log"]
    # a manager sees the staff actions, not the system problems and the administration
    assert await get(h=boss) == ["shift_late", "ticket_created", "manual_state"]
    assert (await env.client.get(base + "&category=system", headers=boss)).status_code == 403
    assert (await env.client.get("/api/log", headers=anna)).status_code == 403
    assert await get("&category=system") == ["system_log"]
    assert await get("&category=tickets,state") == ["ticket_created", "manual_state"]
    assert await get("&level=error,warning") == ["shift_late", "system_log"]
    assert await get("&actor_id=1") == ["ticket_created", "manual_state"]
    assert await get("&agent_id=2") == ["shift_late"]
    assert await get("&action=manual_state") == ["manual_state"]
    assert await get("&ticket_id=77") == ["ticket_created"]
    assert await get("&q=printer") == ["ticket_created"] and await get("&q=refused") == ["system_log"]
    assert await get("&since=2026-03-02T11:30:00%2B00:00&until=2026-03-02T13:30:00Z") == ["user_created", "ticket_created"]
    # by the day and the hour in the company's time zone (UTC+4): 15:00–17:30 local = 11:00–13:30 UTC
    env.settings.display_timezone = "Asia/Yerevan"
    got = (await env.client.get("/api/log?date_from=2026-03-02&time_from=15:00&date_to=2026-03-02&time_to=17:30", headers=root)).json()
    assert [x["action"] for x in got["items"]] == ["user_created", "ticket_created", "manual_state"]
    got = (await env.client.get("/api/log?date_from=2026-03-02&date_to=2026-03-02", headers=root)).json()
    assert got["total"] == 5
    r = (await env.client.get(base + "&limit=2&offset=1", headers=root)).json()
    assert r["total"] == 5 and [x["action"] for x in r["items"]] == ["user_created", "ticket_created"]
    item = next(x for x in r["items"] if x["action"] == "ticket_created")
    assert item["category"] == "tickets" and item["actor_name"] == "Анна" and item["agent_name"] == "Анна"
    meta = (await env.client.get("/api/log/meta", headers=boss)).json()
    assert "system" not in meta["categories"] and {"manual_state", "ticket_created"} <= {a["action"] for a in meta["actions"]}
    assert "system_log" not in {a["action"] for a in meta["actions"]}
    assert "system" in (await env.client.get("/api/log/meta", headers=root)).json()["categories"]
    csv = await env.client.get(f"/api/log.csv?since={since}&until={until}&category=state", headers=boss)
    assert csv.status_code == 200 and "attachment" in csv.headers["content-disposition"]
    lines = csv.content.decode("utf-8-sig").strip().splitlines()
    assert lines[0].startswith("time;level;category") and len(lines) == 2 and "manual_state" in lines[1] and "new=break" in lines[1]
    assert (await actions(env, "log_exported"))[0].actor_id == 3


async def test_system_problems_are_logged(env):
    h = env.services.syslog
    h.start()
    try:
        app_log = logging.getLogger("ami")
        app_log.warning("AMI connection lost: %s", "refused")
        app_log.warning("AMI connection lost: %s", "timeout")  # the same problem → one row, counted
        try:
            raise ValueError("bad payload")
        except ValueError:
            logging.getLogger("webhooks").exception("Zammad webhook failed")
        logging.getLogger("sqlalchemy.engine").warning("never stored")
        logging.getLogger("ami").info("not a problem")
        await __import__("asyncio").sleep(0.05)
        assert await h.flush_now() == 3
        app_log.warning("AMI connection lost: %s", "again")
        await __import__("asyncio").sleep(0.05)
        await h.flush_now()
        env.settings.log_capture_level = "ERROR"
        app_log.warning("ignored now")
        await __import__("asyncio").sleep(0.05)
        assert await h.flush_now() == 0
    finally:
        await h.stop()
    rows = await actions(env, "system_log")
    assert len(rows) == 2
    ami = next(r for r in rows if r.details["logger"] == "ami")
    assert ami.level == "warning" and ami.details["count"] == 3 and ami.details["message"] == "AMI connection lost: again"
    hook = next(r for r in rows if r.details["logger"] == "webhooks")
    assert hook.level == "error" and hook.details["error"] == "ValueError: bad payload" and "Traceback" in hook.details["trace"]
    root = await env.login("root")
    got = (await env.client.get("/api/log?category=system&q=webhook", headers=root)).json()["items"]
    assert [x["details"]["logger"] for x in got] == ["webhooks"]
    assert utcnow()  # keep the import used
