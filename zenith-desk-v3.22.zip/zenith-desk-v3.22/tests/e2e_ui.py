"""End-to-end UI check of every function in a real browser against the demo server.

    python -m scripts.demo &          # or let scripts/release_check.py start it
    python tests/e2e_ui.py http://localhost:8000 [screenshots_dir]

Exits with code 1 and prints the failed step if anything does not work.
Requires: pip install playwright (Chromium installed via `playwright install chromium`).
"""
import asyncio
import time
import json
import os
import sys
import urllib.error
import urllib.request

from playwright.async_api import Page, async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
SHOTS = sys.argv[2] if len(sys.argv) > 2 else ""
# ZD_STYLE=studio runs every check with the "Studio" interface style (v3.12): both styles must work the same
STYLE = os.environ.get("ZD_STYLE", "classic")
ME = ".subnav .sn-me" if STYLE == "studio" else ".topbar .me"          # where the account is shown (wide screens)
ME_LEVEL = ".subnav .sn-me small" if STYLE == "studio" else ".topbar .me-level"
# v3.19 Flow: Ready / Break / Customize and the phone dialer are on the tool rail at the left
FLOW = STYLE == "flow"
BTN_READY = "[data-rail=ready]" if FLOW else ".topbar button.go"
BTN_BREAK = "[data-rail=break]" if FLOW else ".topbar button:nth-of-type(2)"
BTN_CUSTOMIZE = "[data-rail=customize]" if FLOW else ".customize-btn"
RESULTS: list[tuple[str, bool, str]] = []


def http(method: str, path: str, data: dict | None = None, token: str = ""):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(data).encode() if data else None,
                                 headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read() or b"null")


def http_raw(path: str) -> bytes:
    with urllib.request.urlopen(BASE + path) as r:
        return r.read()


def png_bytes(w: int = 480, h: int = 320) -> bytes:
    """A real PNG picture (no extra libraries): a landscape photo stand-in for the account picture tests."""
    import struct
    import zlib
    rows = b"".join(b"\x00" + b"".join(bytes((40 + x * 200 // w, 90, 160 - y * 100 // h)) for x in range(w)) for y in range(h))

    def chunk(kind: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def pbx(iface: str = "Local/101@from-queue/n") -> bool:
    return http("GET", "/demo/pbx")["400"][iface]["paused"]


CURRENT = {"step": "start"}


async def step(name: str, coro):
    CURRENT["step"] = name
    try:
        await coro
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}")
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, False, str(exc)[:300]))
        print(f"  FAIL  {name}: {str(exc)[:300 if not os.environ.get('ZD_DEBUG') else 1500]}")


async def login(page: Page, user: str, password: str = "pw", wait: str = ".topbar .status", style: str | None = None) -> None:
    await page.goto(BASE + "/")
    await page.wait_for_selector("input[autocomplete=username]")
    await page.fill("input[autocomplete=username]", user)
    await page.fill("input[type=password]", password)
    await page.click("form button.primary")
    await page.wait_for_selector(wait, timeout=8000)
    await page.wait_for_timeout(600)
    want = style or STYLE
    if await page.evaluate("document.documentElement.dataset.style") != want:
        await set_style(page, want)
        await page.wait_for_selector(wait, timeout=8000)
        await page.wait_for_timeout(600)


async def set_style(page: Page, style: str) -> None:
    """Save the interface style of the signed-in user (as My settings does) and load the page again."""
    await page.evaluate("""async (style) => {
        const h = { Authorization: "Bearer " + localStorage.getItem("aws_token"), "Content-Type": "application/json" };
        const p = await (await fetch("/api/agents/me/preferences", { headers: h })).json();
        if (p.style !== style) await fetch("/api/agents/me/preferences", { method: "PUT", headers: h, body: JSON.stringify({ ...p, style }) });
        localStorage.setItem("zenith_style", style);
    }""", style)
    await page.reload()


async def nav(page: Page, key) -> None:
    """Click a sidebar item by its key (work, chat, sup, overview, users, …) — works in any interface language."""
    if await page.locator(".burger").is_visible():
        await page.click(".burger")
    if isinstance(key, int):
        await page.locator(".side-nav button").nth(key).click()
    elif key in GROUPED and await page.locator(f".side-nav button[data-nav={key}]").count() == 0:
        await open_grouped(page, key)
    else:
        await page.click(f".side-nav button[data-nav={key}]")
    await page.wait_for_timeout(900)


# v3.15.1: the administration pages and the manager tools are one rail icon each; the pages are tabs inside
GROUPED = {**{k: "admin" for k in ("users", "integrations", "settings", "groups", "types", "routing", "system", "backup", "apikeys")},
           **{k: "mtools" for k in ("shifts", "recordings", "log", "callrouting")}}


async def open_grouped(page: Page, key: str) -> None:
    await page.click(f".side-nav button[data-nav={GROUPED[key]}]")
    await page.wait_for_timeout(400)
    tab = page.locator(f".sec-tabs [data-sec-tab={key}]")
    if await tab.count():
        await tab.click()
    else:  # Studio: the section panel next to the icons
        await page.click(f".subnav [data-sn={key}]")


async def status_text(page: Page) -> str:
    return await page.inner_text(".topbar .status")


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


async def main() -> int:
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        errors: list[str] = []

        def new_page(width=1440, height=950):
            async def make():
                pg = await browser.new_page(viewport={"width": width, "height": height})
                pg.on("pageerror", lambda e: errors.append(f"pageerror during «{CURRENT['step']}»: {e}"))
                # HTTP 4xx answers provoked on purpose (wrong password, refused Ready, validation) are not JS errors
                pg.on("console", lambda m: errors.append(f"console during «{CURRENT['step']}»: {m.text}")
                      if m.type == "error" and "Failed to load resource" not in m.text else None)
                return pg
            return make()

        pg = await new_page()

        # ---------------------------------------------------------------- login
        async def bad_login():
            await pg.goto(BASE + "/")
            await pg.fill("input[autocomplete=username]", "anna")
            await pg.fill("input[type=password]", "wrong")
            await pg.click("form button.primary")
            await pg.wait_for_selector("form p", timeout=5000)
            expect("Wrong" in await pg.inner_text("form p") or "Невер" in await pg.inner_text("form p"), "no error text")
        await step("Login: wrong password shows an error", bad_login())

        async def version_on_login():
            expect((await pg.inner_text(".login .version")).startswith("v"), "version missing")
            # v3.18.1: the name is the drawn ZENITH. wordmark (SVG) + DESK, named for screen readers
            expect(await pg.get_attribute(".login .logo .brand-word", "aria-label") == "Zenith Desk", "product name missing on the login page")
            expect(await pg.locator(".login .logo .brand-word svg path").count() == 1, "ZENITH. wordmark missing on the login page")
            expect("Zenith Desk" in await pg.title(), "product name missing in the browser tab")
            loaded = await pg.evaluate("(() => { const i = document.querySelector('.login .logo img'); return !!i && i.complete && i.naturalWidth > 0; })()")
            expect(loaded, "logo not loaded")
            icon = http_raw("/static/logo-192.png")
            expect(icon.startswith(b"\x89PNG"), "PNG icon missing")
        await step("Login page: Zenith Desk name, logo, tab icon and version", version_on_login())

        await step("Login: operator anna", login(pg, "anna"))

        async def dashboard_cards():
            expect(await pg.locator(".kpis .kpi").count() == 5, "dashboard cards missing")
            expect(await pg.locator(".ntf-panel").count() == 1, "notifications panel missing")
            expect(await pg.locator(".bell").count() == 1, "bell missing")
        await step("Operator dashboard: 5 summary cards, notifications panel, bell", dashboard_cards())

        async def console_design():
            expect(await pg.evaluate("document.documentElement.dataset.theme") == "dark", "dark console is not the default look")
            w = await pg.evaluate("document.querySelector('.sidebar').getBoundingClientRect().width")
            if STYLE == "flow":  # v3.16 Flow: the sections are text pills at the top, Manrope served by Zenith Desk
                expect(await pg.locator(".side-nav button .lbl").first.is_visible(), "flow: section names shown in the pill bar")
                await pg.wait_for_function("document.fonts.check('16px \"Manrope\"')", timeout=5000)
                font = await pg.evaluate("getComputedStyle(document.body).fontFamily")
                expect("Manrope" in font, f"font: {font}")
                expect(await pg.locator(f"{ME} .avatar").count() == 1, f"user block missing ({ME})")
                # v3.18.1: icon + the drawn ZENITH. wordmark + DESK next to the pills
                expect(await pg.locator(".logo-mark .brand-word .bw-mark").is_visible(), "flow: ZENITH. wordmark not shown")
                expect(await pg.inner_text(".logo-mark .brand-word .bw-sub") == "DESK", "flow: DESK missing next to the wordmark")
                return
            expect(w <= 80, f"sidebar is not an icon rail (width {w})")
            expect(await pg.locator(".side-nav button svg").count() >= 1, "rail icons missing")
            font = await pg.evaluate("getComputedStyle(document.body).fontFamily")
            expect("IBM Plex Sans" in font, f"font: {font}")
            ok = await pg.evaluate("document.fonts.check('16px \"IBM Plex Sans\"')")
            expect(ok, "IBM Plex Sans not loaded from the server")
            await pg.hover(".side-nav button >> nth=0")
            try:
                await pg.wait_for_function("getComputedStyle(document.querySelector('.side-nav button .lbl')).opacity === '1'", timeout=2000)
            except Exception as exc:
                raise AssertionError("rail tooltip not shown on hover") from exc
            expect(await pg.locator(f"{ME} .avatar").count() == 1, f"user block missing ({ME})")
        await step("Command Center design: dark by default, icon rail with tooltips, local fonts", console_design())

        async def theme_toggle():
            before = await pg.evaluate("getComputedStyle(document.body).backgroundColor")
            await pg.click(".sidebar .theme-toggle")
            await pg.wait_for_timeout(300)
            for _ in range(20):
                after = await pg.evaluate("getComputedStyle(document.body).backgroundColor")
                if after != before:
                    break
                await pg.wait_for_timeout(150)
            theme = await pg.evaluate("document.documentElement.dataset.theme")
            expect(before != after and theme in ("dark", "light"), f"theme did not change ({before} -> {after})")
            await pg.reload()
            await pg.wait_for_selector(".sidebar")
            expect(await pg.evaluate("document.documentElement.dataset.theme") == theme, "theme not remembered after reload")
            await pg.click(".sidebar .theme-toggle")  # back
            for _ in range(20):  # the colour change is animated; under load it may take longer than 300 ms
                await pg.wait_for_timeout(150)
                if await pg.evaluate("getComputedStyle(document.body).backgroundColor") == before:
                    break
            expect(await pg.evaluate("getComputedStyle(document.body).backgroundColor") == before, "theme did not switch back")
        await step("Dark / light theme switch is applied and remembered", theme_toggle())

        async def level_under_name():
            txt = await pg.inner_text(ME_LEVEL)
            expect("1" in txt, f"level missing: {txt!r}")
        await step("Level is shown under the user's name", level_under_name())

        async def customize_workspace():
            await pg.click(BTN_CUSTOMIZE)
            await pg.wait_for_selector(".edit-bar")
            calls = pg.locator(".widget[data-w=calls]")
            await calls.locator(".widget-tools .wt").nth(4).click()          # width: full (▭)
            await calls.locator(".widget-tools .wt").nth(5).click()          # height: M (default) -> L
            await pg.locator(".widget[data-w=pending] .widget-tools .wt.hide").click()
            await pg.drag_and_drop(".widget[data-w=notifications] .widget-tools", ".widget[data-w=active] .widget-tools")
            await pg.wait_for_timeout(300)
            await pg.click(".ws-done")
            await pg.wait_for_timeout(800)
            await pg.reload()
            await pg.wait_for_selector(".dash")
            await pg.wait_for_timeout(800)
            order = await pg.eval_on_selector_all(".dash > .widget", "els => els.map(e => e.dataset.w)")
            expect("pending" not in order, f"hidden block still visible: {order}")
            expect(order.index("notifications") < order.index("active"), f"drag & drop order not saved: {order}")
            cls = await pg.get_attribute(".widget[data-w=calls]", "class")
            expect("w3" in cls and "h-l" in cls, f"size not saved: {cls}")
        await step("Customize workspace: resize, hide, drag & drop — saved after reload", customize_workspace())

        async def presets_and_restore():
            await pg.click(".settings-btn")
            await pg.wait_for_selector(".presets")
            expect(await pg.locator(".preset").count() >= 6, "presets missing (5 + my layout)")
            await pg.click(".preset[data-preset=focus]")
            await pg.click(".side-nav button >> nth=0")
            await pg.wait_for_timeout(700)
            order = await pg.eval_on_selector_all(".dash > .widget", "els => els.map(e => e.dataset.w)")
            expect(order == ["active", "notifications", "new", "background"], f"focus preset wrong: {order}")
            await pg.click(BTN_CUSTOMIZE)
            await pg.click(".edit-bar button:has-text('Reset'), .edit-bar button:has-text('Сбросить')")
            await pg.click(".ws-done")
            await pg.wait_for_timeout(600)
            order = await pg.eval_on_selector_all(".dash > .widget", "els => els.map(e => e.dataset.w)")
            expect(order == ["kpis", "active", "notifications", "background", "calls", "new", "mine", "pending"], f"default not restored: {order}")
        await step("Ready layouts (presets) and reset to default", presets_and_restore())

        async def settings_follow_user():
            await pg.click(".settings-btn")
            await pg.click(".seg button[data-theme-opt=light]")
            await pg.uncheck(".my-settings input[name=sound]")
            # v3.22: interface size — the whole page is zoomed and the choice follows the account
            expect(await pg.evaluate("document.documentElement.style.zoom") in ("0.8", "0.85", "0.9"), "auto zoom not applied")
            await pg.click("[data-zoom-opt='110']")
            await pg.wait_for_timeout(400)
            expect(await pg.evaluate("document.documentElement.style.zoom") == "1.1", "110 % not applied")
            await pg.wait_for_timeout(900)
            other = await browser.new_page()   # a "different computer": empty browser storage
            await login(other, "anna", wait=".sidebar")
            expect(await other.evaluate("document.documentElement.dataset.theme") == "light", "theme not loaded from the account")
            expect(await other.evaluate("document.documentElement.style.zoom") == "1.1", "interface size not loaded from the account")
            await other.click(".settings-btn")
            expect(not await other.is_checked(".my-settings input[name=sound]"), "sound setting not loaded from the account")
            await other.close()
            await pg.click(".seg button[data-theme-opt=system]")
            expect(await pg.evaluate("document.documentElement.dataset.theme") in ("light", "dark"), "system theme not applied")
            await pg.click(".seg button[data-theme-opt=dark]")
            await pg.click("[data-zoom-opt=auto]")
            await pg.check(".my-settings input[name=sound]")
            await pg.wait_for_timeout(700)
            await pg.click(".side-nav button >> nth=0")
            await pg.wait_for_timeout(500)
        await step("Personal settings follow the user to another computer", settings_follow_user())

        async def motion():
            # a page change runs as a View Transition, and the new page is in the DOM immediately after it
            vt = await pg.evaluate("""() => new Promise(res => {
                const seen = []; const obs = new MutationObserver(() => seen.push(document.documentElement.dataset.vt || ''));
                obs.observe(document.documentElement, {attributes: true, attributeFilter: ['data-vt']});
                document.querySelector('.settings-btn').click();
                setTimeout(() => { obs.disconnect(); res(seen); }, 700);
            })""")
            expect("page" in vt, f"no page transition: {vt}")
            expect(await pg.locator(".my-settings").count() == 1, "settings page not shown after the transition")
            await pg.click(".seg button[data-theme-opt=light]")       # ripple feedback on press
            expect(await pg.evaluate("!!document.querySelector('.seg [data-ripple]')"), "no ripple on press")
            await pg.click(".seg button[data-theme-opt=dark]")
            await pg.click(".my-settings input[name=motion]")          # switch animations off
            await pg.wait_for_timeout(700)
            expect(await pg.evaluate("document.documentElement.dataset.motion") == "off", "animations not switched off")
            await pg.reload()
            await pg.wait_for_selector(".sidebar")
            await pg.wait_for_timeout(600)
            expect(await pg.evaluate("document.documentElement.dataset.motion") == "off", "animation setting not saved")
            dur = await pg.evaluate("getComputedStyle(document.querySelector('.btn')).transitionDuration")
            expect(all(float(x.strip()[:-1]) < 0.01 for x in dur.split(",")), f"transitions still on: {dur}")
            await pg.click(".settings-btn")
            await pg.click(".my-settings input[name=motion]")          # back on
            await pg.wait_for_timeout(700)
            expect(await pg.evaluate("document.documentElement.dataset.motion") is None, "animations not switched back on")
            await pg.click(".side-nav button >> nth=0")
            await pg.wait_for_timeout(500)
        await step("Motion: page transitions, ripple, animations can be switched off and it is saved", motion())

        async def initial_ready():
            st = await status_text(pg)
            expect("Ready" in st or "Готов" in st, f"status: {st}")
            expect(not pbx(), "anna should not be paused when ready")
        await step("After login operator is Ready and receives calls", initial_ready())

        # ---------------------------------------------------------------- break / ready
        async def go_break():
            await pg.click(BTN_BREAK)
            await pg.wait_for_timeout(700)
            expect("break" in (await status_text(pg)).lower() or "Перерыв" in await status_text(pg), "not on break")
            expect(pbx(), "should be paused on break")
        await step("Break pauses the operator in queues", go_break())

        async def go_ready():
            await pg.click(BTN_READY)
            await pg.wait_for_timeout(700)
            expect(not pbx(), "should be unpaused after Ready")
        await step("Ready unpauses the operator", go_ready())

        # ---------------------------------------------------------------- start blocking / complete
        async def start_blocking():
            await pg.click(".widget[data-w=mine] section .item .actions button.primary")  # "Assigned to me" -> Start
            await pg.wait_for_timeout(900)
            expect(pbx(), "blocking task must pause the operator")
            expect(await pg.locator(".widget[data-w=active] section .item").count() == 1, "no active task")
        await step("Start (blocking) pauses calls and shows the active task", start_blocking())

        async def ready_refused():
            await pg.evaluate("""() => fetch('/api/agents/me/ready', {method:'POST', headers:{Authorization:'Bearer '+localStorage.getItem('aws_token')}}).then(r => window.__ready = r.status)""")
            await pg.wait_for_timeout(400)
            expect(await pg.evaluate("window.__ready") == 409, "Ready must be refused while blocking")
        await step("Manual Ready is refused while a blocking task exists", ready_refused())

        async def to_background_and_back():
            await pg.click(".widget[data-w=active] section .item .actions button:nth-child(2)")  # Background task
            await pg.wait_for_timeout(800)
            expect(not pbx(), "background must not pause")
            expect(await pg.locator(".widget[data-w=background] section .item").count() == 1, "not in background list")
            await pg.click(".widget[data-w=background] section .item .actions button.primary")  # Start (back to blocking)
            await pg.wait_for_timeout(800)
            expect(pbx(), "back to blocking must pause")
        await step("Switch blocking -> background -> blocking", to_background_and_back())

        async def complete():
            await pg.click(".widget[data-w=active] section .item .actions button.go")
            await pg.wait_for_selector(".modal")
            await pg.fill(".modal textarea", "Resolved by e2e test")
            await pg.click(".modal button.go")
            await pg.wait_for_timeout(900)
            expect(not pbx(), "complete must return the operator to the queue")
            expect(await pg.locator(".widget[data-w=active] section .item").count() == 0, "task still active")
        await step("Complete closes the task and returns calls", complete())

        async def kpi_completed():
            await pg.wait_for_timeout(500)
            expect((await pg.inner_text(".kpi.done .v")).strip() == "1", "completed-today counter not updated")
        await step("Dashboard counter 'completed today' updates", kpi_completed())

        # ---------------------------------------------------------------- unassigned (messenger) tickets
        async def two_blocking():
            await pg.click(".widget[data-w=new] section .item >> nth=0 >> button.primary")
            await pg.wait_for_timeout(700)
            await pg.click(".widget[data-w=new] section .item >> nth=0 >> button.primary")
            await pg.wait_for_timeout(700)
            expect(await pg.locator(".widget[data-w=active] section .item").count() == 2, "expected 2 blocking tasks")
            await pg.click(".widget[data-w=active] section .item >> nth=0 >> button.go")
            await pg.wait_for_selector(".modal"); await pg.click(".modal button.go"); await pg.wait_for_timeout(900)
            expect(pbx(), "one blocking task left — must stay paused")
            await pg.click(".widget[data-w=active] section .item >> nth=0 >> button.go")
            await pg.wait_for_selector(".modal"); await pg.click(".modal button.go"); await pg.wait_for_timeout(900)
            expect(not pbx(), "no blocking tasks — must be unpaused")
        await step("New requests: two blocking tasks, completing one keeps the pause", two_blocking())

        async def background_from_new():
            await pg.click(".widget[data-w=new] section .item >> nth=0 >> button:nth-child(2)")
            await pg.wait_for_timeout(800)
            expect(not pbx(), "background task must not pause")
            await pg.click(".widget[data-w=background] section .item >> nth=0 >> button:nth-child(3)")  # Remove
            await pg.wait_for_timeout(700)
        await step("Background task from a messenger ticket does not pause", background_from_new())

        # ---------------------------------------------------------------- incoming call
        async def incoming_call():
            http("POST", "/demo/call?ext=101&number=89123456789")
            await pg.wait_for_selector(".call", timeout=5000)
            await pg.wait_for_selector(".call .customer b", timeout=5000)
            expect("Ivan" in await pg.inner_text(".call"), "customer card not shown")
        await step("Incoming call opens the customer card", incoming_call())

        async def ticket_from_call():
            await pg.click(".call button.primary")
            await pg.wait_for_selector(".modal")
            await pg.select_option(".modal select >> nth=1", "Order")
            await pg.fill(".modal input >> nth=0", "A-777")
            await pg.fill(".modal input >> nth=1", "E2E ticket from call")
            await pg.click(".modal .footer button.primary")
            await pg.wait_for_timeout(1000)
            expect(await pg.locator(".modal").count() == 0, "modal still open")
            expect(pbx(), "save and start (blocking) must pause")
            expect("E2E ticket from call" in await pg.inner_text(".widget[data-w=active] section"), "ticket not in active tasks")
        await step("Create ticket from call with required fields and start", ticket_from_call())

        async def required_field_check():
            http("POST", "/demo/call?ext=101&number=89123456789")
            await pg.wait_for_selector(".call")
            await pg.click(".call button.primary")
            await pg.wait_for_selector(".modal")
            await pg.select_option(".modal select >> nth=1", "Order")
            await pg.fill(".modal input >> nth=1", "Missing order number")
            await pg.click(".modal .footer button:nth-child(2)")
            await pg.wait_for_selector(".toast.error", timeout=4000)
            expect(await pg.locator(".modal").count() == 1, "modal must stay open on validation error")
            await pg.click(".modal .footer button:nth-child(1)")
        await step("Required fields are validated", required_field_check())

        async def unknown_caller():
            http("POST", "/demo/call?ext=101&number=89990000000")
            await pg.wait_for_timeout(1000)
            await pg.click(".call .actions button:nth-child(2)")  # Create customer
            await pg.wait_for_selector(".modal")
            await pg.fill(".modal input >> nth=0", "New")
            await pg.fill(".modal input >> nth=1", "Caller")
            await pg.click(".modal .footer button.primary")
            await pg.wait_for_selector(".call .customer b", timeout=5000)
            expect("New Caller" in await pg.inner_text(".call"), "new customer not shown")
            await pg.click(".call .actions button:last-child")  # Hide
        await step("Unknown caller: create customer", unknown_caller())

        async def recent_calls():
            expect(await pg.locator(".widget[data-w=calls] section .item").count() >= 3, "recent calls missing")
        await step("Recent calls list", recent_calls())

        # ---------------------------------------------------------------- v3.3 ticketing inside Zenith Desk
        anna_tok = await pg.evaluate("localStorage.getItem('aws_token')")

        def find_ticket(title: str, view: str = "all") -> dict:
            from urllib.parse import quote
            rows = http("GET", f"/api/tk/tickets?view={view}&q={quote(title)}", token=anna_tok)["tickets"]
            return next(r for r in rows if r["title"] == title)

        http("POST", "/demo/zammad/ticket?title=Refund%20for%20a%20damaged%20sofa&text=The%20sofa%20arrived%20with%20a%20broken%20leg.%20I%20want%20a%20refund.")

        async def tk_lists():
            await nav(pg, "tickets")
            await pg.wait_for_selector(".tkn-ovs [data-ov=my_assigned]", timeout=6000)
            names = await pg.locator(".tkn-ovs button .tkn-name").all_inner_texts()
            expect(names[:2] == ["My Assigned Tickets", "Unassigned & Open Tickets"] and "On-site Requests" in names, f"Zammad overviews: {names}")
            await pg.wait_for_selector(".tko tbody tr", timeout=6000)
            mine = await pg.locator(".tko tbody tr").count()
            expect(mine >= 2, f"my tickets missing ({mine})")
            for v in ("all_unassigned", "all_open", "my_closed_tickets", "on_site_requests"):
                await pg.click(f".tkn-ovs [data-ov={v}]")
                await pg.wait_for_selector(f".tkn-ovs [data-ov={v}].on")
                await pg.wait_for_timeout(500)
                cnt = int(await pg.inner_text(f".tkn-ovs [data-ov={v}] b"))
                expect(await pg.locator(".tko tbody tr").count() == cnt, f"{v}: rows != count {cnt}")
            expect("Server room visit" in await pg.inner_text(".tko"), "on-site request missing")
            await pg.click(".tkn-ovs [data-ov=all_open]")
            await pg.wait_for_timeout(600)
            await pg.fill("input[name=tk-q]", "damaged sofa")
            await pg.wait_for_timeout(800)
            rows = await pg.locator(".tko tbody tr").all_inner_texts()
            expect(len(rows) == 1 and "Refund for a damaged sofa" in rows[0], f"search: {rows}")
            await pg.select_option("select[name=f-priority]", "3 high")
            await pg.wait_for_selector(".tko-none", timeout=4000)
            await pg.select_option("select[name=f-priority]", "")
            await pg.wait_for_timeout(500)
            await pg.fill("input[name=tk-q]", "")
            await pg.select_option("select[name=f-group]", "IT Support")
            await pg.wait_for_timeout(600)
            groups = {r.split("\t")[3] if "\t" in r else "" for r in await pg.locator(".tko tbody tr").all_inner_texts()}
            expect(await pg.locator(".tko tbody tr").count() >= 2, "group filter: IT Support tickets missing")
            await pg.select_option("select[name=f-owner]", "none")
            await pg.wait_for_timeout(600)
            owners = await pg.locator(".tko tbody td.c-owner").all_inner_texts()
            expect(owners and all(o.strip() == "-" for o in owners), f"owner filter: {owners}")
            await pg.click(".tko th.c-title button")
            await pg.wait_for_timeout(400)
            await pg.click(".tko-filters button.btn")  # reset filters
            await pg.wait_for_timeout(600)
            del groups
        await step("Tickets: the operator's Zammad overviews with counts, table, search, filters (group, owner, priority), sort", tk_lists())

        async def tk_conversation():
            await pg.fill("input[name=tk-q]", "damaged sofa")
            await pg.wait_for_timeout(700)
            await pg.click(".tko tbody tr >> nth=0")
            await pg.wait_for_selector(".tk-art", timeout=6000)
            await pg.wait_for_selector(".tkn-tab.on", timeout=5000)  # the ticket opened in a tab
            expect(await pg.locator(".tkn-tab.on").count() == 1, "the ticket did not open in a tab")
            expect("broken leg" in await pg.inner_text(".tk-thread"), "customer message not shown")
            await pg.fill(".tk-compose textarea", "Photos checked, refund goes today.")
            await pg.set_input_files(".tc-attach input[type=file]", files=[{"name": "refund.txt", "mimeType": "text/plain", "buffer": b"refund 4512"}])
            await pg.wait_for_selector(".tc-files .ta-file")
            await pg.click(".tc-send")
            await pg.wait_for_selector(".tk-art.internal >> text=refund goes today", timeout=6000)
            expect(await pg.locator(".tk-art.internal .ta-file").count() >= 1, "attachment not in the note")
            await pg.click(".tc-modes [data-kind=reply]")
            target = await pg.inner_text(".tc-target")
            expect("E-mail" in target and "tigran" in target.lower(), f"reply target: {target}")
            await pg.fill(".tk-compose textarea", "Dear Tigran, your refund is approved.")
            await pg.click(".tc-send")
            await pg.wait_for_selector(".tk-art.from-agent:not(.internal) >> text=refund is approved", timeout=6000)
            d = http("GET", f"/api/tk/tickets/{find_ticket('Refund for a damaged sofa')['id']}", token=anna_tok)
            last = d["articles"][-1]
            expect(last["type"] == "email" and not last["internal"] and "tigran" in last["to"], f"reply not sent by e-mail: {last}")
        await step("Ticket page: conversation, internal note with a file, reply to the customer by e-mail (saved in Zammad)", tk_conversation())

        async def tk_properties():
            expect(await pg.locator("[data-act=update]").is_disabled(), "Update must wait for a change")
            await pg.select_option(".tk-side select[data-f=priority]", "2 normal")
            await pg.select_option(".tk-side select[data-f=state]", "pending reminder")
            await pg.fill("input[name=tk-tag]", "refund")
            await pg.keyboard.press("Enter")
            await pg.fill("input[name=tk-tag]", "vip")
            await pg.keyboard.press("Enter")
            t = find_ticket("Refund for a damaged sofa")
            expect(t["state"] != "pending reminder", "saved before Update")  # nothing goes to Zammad before «Update»
            await pg.click("[data-act=update]")
            await pg.wait_for_selector(".tk-hnum .tk-chip.c-pending", timeout=5000)
            t = find_ticket("Refund for a damaged sofa")
            expect(t["priority"] == "2 normal" and t["state"] == "pending reminder", f"not saved in Zammad: {t}")
            d = http("GET", f"/api/tk/tickets/{t['id']}", token=anna_tok)
            expect(sorted(d["ticket"]["tags"]) == ["refund", "vip"], f"tags: {d['ticket']['tags']}")
            # changes can be thrown away before Update
            await pg.select_option(".tk-side select[data-f=priority]", "3 high")
            await pg.click("[data-act=revert]")
            expect(await pg.input_value(".tk-side select[data-f=priority]") == "2 normal", "revert")
            await pg.click(".tk-title")
            await pg.fill(".tk-title-input", "Refund for a damaged sofa (approved)")
            await pg.press(".tk-title-input", "Enter")
            await pg.wait_for_selector(".tk-title >> text=(approved)", timeout=5000)
            await pg.select_option(".tk-side select[data-f=state]", "open")
            await pg.click("[data-act=update]")
            await pg.wait_for_selector(".tk-hnum .tk-chip.c-open", timeout=5000)
        await step("Ticket: group / owner / state / priority / tags are changed only with «Update» (and can be discarded)", tk_properties())

        bp = await new_page()
        await login(bp, "boris")

        async def tk_transfer():
            await nav(bp, "tickets")
            await bp.wait_for_selector(".tko tbody tr, .tko-none", timeout=6000)
            before = await bp.locator(".tko tbody tr").count()
            await pg.click(".tk-side [data-act=transfer]")
            await pg.wait_for_selector(".tr-person[data-person]", timeout=5000)
            await pg.click(".tr-person[data-person='11']")
            await pg.fill(".tk-transfer textarea", "Boris, please call Tigran back")
            await pg.click("[data-act=do-transfer]")
            await pg.wait_for_selector(".tk-transfer", state="detached", timeout=5000)
            await bp.wait_for_selector(".toast.chat", timeout=4000)
            await bp.wait_for_function(f"document.querySelectorAll('.tko tbody tr').length === {before + 1}", timeout=6000)
            expect("(approved)" in await bp.inner_text(".tko"), "transferred ticket not in Boris' list")
            await bp.click(".toast.chat")
            await bp.wait_for_selector(".tk-art >> text=please call Tigran back", timeout=5000)
            owner = await pg.evaluate("(() => { const s = document.querySelector('.tk-side select[data-f=owner]'); return s.options[s.selectedIndex].text; })()")
            expect("Boris" in owner, f"owner not updated for Anna: {owner}")
        await step("Transfer to a colleague: he gets it live with a notification, comment included", tk_transfer())

        async def tk_live_from_zammad():
            tid = find_ticket("Refund for a damaged sofa (approved)")["id"]
            http("POST", f"/demo/zammad/change?ticket={tid}&note=Thank%20you%20very%20much!")
            await bp.wait_for_selector(".tk-art >> text=Thank you very much!", timeout=5000)
            http("POST", f"/demo/zammad/change?ticket={tid}&state=closed")
            await bp.wait_for_selector(".tk-hnum .tk-chip.c-closed", timeout=5000)
            # v3.17.1: its tab in the open-ticket list turns green (closed) at once, the others keep their stage
            await bp.wait_for_selector(f".tkn-tab[data-tab='{tid}'][data-cat=closed]", timeout=5000)
            green = await bp.evaluate(f"getComputedStyle(document.querySelector(\".tkn-tab[data-tab='{tid}'] .tkn-dot\")).backgroundColor")
            r, g, b = [int(x) for x in green[green.index("(") + 1:green.index(")")].split(",")[:3]]
            expect(g > r + 40 and g > b + 40, f"closed ticket dot is not green: {green}")
            cats = await bp.evaluate("[...document.querySelectorAll('.tkn-tab')].map(t => t.dataset.cat)")
            expect(all(c in ("new", "open", "pending", "closed", "draft", "unknown") for c in cats), f"tab stages: {cats}")
        await step("Changes made in Zammad (new message, closed) appear in Zenith Desk by themselves; the ticket's tab turns green", tk_live_from_zammad())

        async def tk_create():
            before = len(http("GET", "/api/tk/tickets?view=all&per_page=100", token=anna_tok)["tickets"])
            await pg.click("[data-act=new-draft]")
            await pg.wait_for_selector(".dr-title")
            expect(await pg.locator("[data-act=create]").is_disabled(), "Create must wait for the required fields")
            await pg.fill("[name=dr-title]", "Gift card balance")
            await pg.fill("[name=dr-customer-q]", "Maria")
            await pg.click(".zresults .zitem >> text=Maria Kuznetsova")
            await pg.fill("[name=dr-body]", "Customer asks how much is left on the gift card.")
            await pg.select_option(".tk-side select[data-f=group]", "IT Support")
            await pg.select_option(".tk-side select[data-f=state]", "open")
            await pg.select_option(".tk-side select[data-f=priority]", "3 high")
            await pg.fill("input[name=dr-tag]", "gift-card")
            await pg.keyboard.press("Enter")
            await pg.wait_for_selector(".dr-save >> text=draft saved", timeout=5000)
            # a draft is kept on the server: it is still there after a reload, and nothing exists in Zammad yet
            expect(len(http("GET", "/api/tk/tickets?view=all&per_page=100", token=anna_tok)["tickets"]) == before, "draft created a ticket")
            await pg.reload()
            await pg.wait_for_selector(".sidebar")
            await nav(pg, "tickets")
            await pg.wait_for_selector(".tkn-tab[data-tab=draft]", timeout=6000)
            await pg.click(".tkn-tab[data-tab=draft] .tkn-open")
            await pg.wait_for_selector(".dr-title")
            expect(await pg.input_value("[name=dr-title]") == "Gift card balance" and "gift-card" in await pg.inner_text(".tf-tags"), "draft not restored")
            await pg.click("[data-act=create]")
            await pg.wait_for_selector(".tk-compose", timeout=6000)  # the ticket itself (the draft has no conversation)
            await pg.wait_for_selector(".tk-title >> text=Gift card balance", timeout=6000)
            t = find_ticket("Gift card balance", "mine")
            expect(t["customer_name"] == "Maria Kuznetsova" and t["mine"] and t["group"] == "IT Support" and t["state"] == "open"
                   and t["priority"] == "3 high", f"ticket not created in Zammad: {t}")
            expect(await pg.locator(".tkn-tab[data-tab=draft]").count() == 0, "the draft tab must become the ticket")
            d = http("GET", f"/api/tk/tickets/{t['id']}", token=anna_tok)
            expect(d["ticket"]["tags"] == ["gift-card"] and "gift card" in d["articles"][0]["body"], f"tags/text: {d['ticket']['tags']}")
            # closing the tab
            n = await pg.locator(".tkn-tab").count()
            await pg.hover(".tkn-tab.on")
            await pg.click(".tkn-tab.on .tkn-x")
            await pg.wait_for_function(f"document.querySelectorAll('.tkn-tab').length === {n - 1}", timeout=4000)
            expect(await pg.locator(".tko-head").count() == 1, "back to the overview after closing")
        await step("New ticket is a draft first (kept on the server); group, owner, state, priority, tags; «Create» makes it in Zammad", tk_create())

        async def contacts():
            await nav(pg, "contacts")
            await pg.wait_for_selector(".ct-row", timeout=5000)
            await pg.fill(".tk-search input", "Acme")
            await pg.wait_for_timeout(600)
            expect(await pg.locator(".ct-row").count() == 2, "company search")
            await pg.fill(".tk-search input", "")
            await pg.wait_for_timeout(600)
            await pg.click(".ct-row >> text=Ivan Sidorov")
            await pg.wait_for_selector(".ct-hero", timeout=5000)
            expect("VIP customer" in await pg.inner_text(".ct-card") and await pg.locator(".ct-card .tk-row").count() >= 2, "customer card")
            n = await pg.locator(".ct-row").count()
            http("POST", "/demo/zammad/customer?firstname=Narine&lastname=Avetisyan&organization=Sevan%20Hotels")
            await pg.wait_for_selector(".toast.chat >> text=Narine Avetisyan", timeout=6000)
            await pg.wait_for_function(f"document.querySelectorAll('.ct-row').length === {n + 1}", timeout=4000)
            await pg.click("[data-kind=staff]")
            await pg.wait_for_timeout(500)
            expect(await pg.locator(".ct-row").count() >= 4, "Zammad users missing")
            await pg.click(".ct-row >> nth=0")
            await pg.wait_for_selector(".ct-hero")
            await pg.click(".ct-card .tk-row >> nth=0") if await pg.locator(".ct-card .tk-row").count() else None
            await nav(pg, "work")
        await step("Customers: search, card with tickets, new customer from Zammad appears live; Zammad users", contacts())

        async def zenith_phone():
            await pg.wait_for_selector(".phone-btn.p-registered", timeout=6000)
            await pg.wait_for_selector(".phone-btn.c-idle", timeout=30000)  # calls of earlier steps stopped ringing
            if await pg.locator(".ph-card").is_visible():
                await pg.click("[data-act=minimize]")
            await nav(pg, "contacts")
            await pg.click("[data-kind=customers]")
            await pg.wait_for_selector(".ct-row")
            await pg.click(".ct-row >> text=Ivan Sidorov")
            await pg.wait_for_selector(".ct-hero")
            await pg.click("[data-act=dial-phone]")  # click-to-call from the customer card
            # v3.7: the phone stays minimized, the call strip under the top bar shows the call
            await pg.wait_for_selector(".ph-strip.cs-active >> text=Ivan Sidorov", timeout=6000)
            expect(not await pg.locator(".ph-card").is_visible(), "the phone window must stay minimized during a call")
            await pg.wait_for_selector(".phone-btn.c-active", timeout=3000)
            await pg.click("[data-act=strip-hold]")
            await pg.wait_for_selector(".ph-strip.cs-held", timeout=3000)
            await pg.click("[data-act=strip-hold]")
            await pg.wait_for_selector(".ph-strip.cs-active", timeout=3000)
            await pg.click(".ph-strip .ph-stext")  # click the strip → the phone opens
            await pg.wait_for_selector(".ph-card.ph-active", timeout=3000)
            await pg.wait_for_selector(".ph-who >> text=Ivan Sidorov", timeout=4000)
            await pg.click("[data-act=hold]")
            await pg.wait_for_selector(".ph-line.l-held", timeout=3000)
            await pg.click("[data-act=hold]")
            await pg.click("[data-act=call]")  # End
            await pg.wait_for_selector(".ph-card.ph-idle", timeout=4000)
            expect(await pg.locator(".ph-strip").count() == 0, "call strip must disappear after the call")
            await pg.click("[data-tab=logs]")
            await pg.wait_for_selector(".ph-logrow >> text=Ivan Sidorov", timeout=4000)  # in the call log
            await pg.click("[data-tab=phone]")
            # hide / show the volume sliders and AC · AA · CONF · REC · VM
            await pg.click("[data-act=toggle-ctl]")
            expect(await pg.locator(".ph-card .ph-flags").count() == 0 and await pg.locator(".ph-card .ph-vol").count() == 0, "controls not hidden")
            await pg.click("[data-act=toggle-ctl]")
            await pg.wait_for_selector(".ph-card .ph-flags")
            # resize from the corner
            w0 = (await pg.locator(".ph-card").bounding_box())["width"]
            r = await pg.locator(".ph-resize").bounding_box()
            await pg.mouse.move(r["x"] + 8, r["y"] + 8); await pg.mouse.down()
            await pg.mouse.move(r["x"] - 40, r["y"] - 40, steps=4); await pg.mouse.up()
            w1 = (await pg.locator(".ph-card").bounding_box())["width"]
            expect(w1 < w0 - 10, f"resize from the corner did not work: {w0} -> {w1}")
            await pg.click("[data-act=minimize]")
            expect(await pg.locator(".ph-card:visible").count() == 0, "phone did not minimize")
            # incoming call: the strip rings (Answer / Decline) without covering the page
            http("POST", "/demo/phone/ring?ext=101&number=%2B37491123456")
            await pg.wait_for_selector(".ph-strip.cs-ringing >> text=Aram Grigoryan", timeout=5000)  # caller recognised
            await pg.click("[data-act=strip-answer]")
            await pg.wait_for_selector(".ph-strip.cs-active", timeout=4000)
            await pg.click("[data-act=strip-keypad]")
            await pg.click("[data-skey='7']")
            await pg.wait_for_selector(".ph-sdtmf >> text=7", timeout=2000)
            await pg.click("[data-act=strip-hangup]")
            await pg.wait_for_selector(".ph-strip", state="detached", timeout=4000)
            # the top-bar dialer: search by name and call (v3.19 Flow: it opens from the rail)
            if FLOW:
                await pg.click("[data-act=rail-dial]")
            await pg.fill("[data-tb]", "Maria Kuz")  # "Maria" alone also finds the colleague Mariam (listed first)
            await pg.wait_for_selector(".ph-tbdrop .ph-res >> text=Maria Kuznetsova", timeout=4000)
            await pg.press("[data-tb]", "Enter")
            await pg.wait_for_selector(".ph-strip >> text=Maria Kuznetsova", timeout=5000)
            await pg.click("[data-act=strip-hangup]")
            await pg.wait_for_selector(".ph-strip", state="detached", timeout=4000)
            # Do not disturb: the operator is paused and the phone rejects calls
            await pg.click("[data-act=dnd]")
            await pg.wait_for_selector(".ph-dndbtn.on", timeout=3000)
            await pg.wait_for_selector(".phone-btn.p-dnd", timeout=3000)
            st = http("GET", "/api/agents/me/state", token=await pg.evaluate("localStorage.getItem('aws_token')"))
            # a blocking ticket that reached Anna meanwhile outranks the break (the demo hands out new tickets by itself)
            expect(st.get("dnd") is True and st.get("computed_state") in ("break", "busy_task") and st.get("queue_paused"),
                   f"DND not on the server: {st}")
            http("POST", "/demo/phone/ring?ext=101&number=%2B37491123456")
            await pg.wait_for_timeout(1500)
            expect(await pg.locator(".ph-strip.cs-ringing").count() == 0, "DND must reject the call")
            await pg.click("[data-act=dnd]")
            await pg.wait_for_selector(".ph-dndbtn:not(.on)", timeout=3000)
            await pg.wait_for_selector(".phone-btn.p-registered", timeout=3000)
            await nav(pg, "work")
        await step("Zenith Phone: click-to-call shows the call strip, hold, open, End, log, hide controls, resize; incoming call in the strip; top-bar dialer; DND", zenith_phone())

        async def phone_settings():
            await pg.click(".settings-btn")
            await pg.wait_for_selector("[data-phone-settings]", timeout=4000)
            await pg.click("[data-layout=docked]")
            await pg.click("[data-act=phone]")
            await pg.wait_for_selector(".ph-card.lay-docked", timeout=3000)
            expect(await pg.evaluate("document.documentElement.classList.contains('ph-docked')"), "side panel must move the page aside")
            box = await pg.locator(".ph-card").bounding_box()
            vw = await pg.evaluate("innerWidth")
            expect(abs(box["x"] + box["width"] - vw) < 2 and box["y"] < 2, f"side panel not docked: {box}")
            await pg.click("[data-layout=compact]")
            await pg.wait_for_selector(".ph-card.lay-compact", timeout=3000)
            expect(await pg.locator(".ph-card .ph-pad").count() == 0 and await pg.locator(".ph-card .ph-flags").count() == 0, "compact: keypad and controls on demand")
            expect(not await pg.evaluate("document.documentElement.classList.contains('ph-docked')"), "page still moved aside")
            await pg.click("[data-act=toggle-pad]")
            await pg.wait_for_selector(".ph-card .ph-pad", timeout=2000)
            await pg.click("[data-min=button]")
            await pg.wait_for_selector("[data-act=rail-dial]" if FLOW else "[data-tb]", state="detached", timeout=2000)
            await pg.click("[data-min=bar]")
            await pg.wait_for_selector("[data-act=rail-dial]" if FLOW else "[data-tb]", timeout=2000)
            await pg.click("[data-layout=classic]")
            await pg.wait_for_selector(".ph-card.lay-classic .ph-flags", timeout=2000)
            await pg.click("[data-act=minimize]")
            await nav(pg, "work")
        await step("Phone settings: classic / compact / side panel, top-bar dialer on/off", phone_settings())

        async def telegram_inbox():
            # the company bot (one for the whole organisation): the seeded chats are already there, mirrored to Zammad
            await nav(pg, "telegram")
            await pg.wait_for_selector(".ib[data-channel=telegram] .ib-item", timeout=6000)
            expect(await pg.locator(".ib-item:has-text('Maria Kuznetsova')").count() == 1, "Telegram chat of Maria missing")
            expect(await pg.locator(".ib-item .ib-badge.whatsapp").count() == 0, "WhatsApp chat shown under Telegram")
            # a new message comes in live (real time: long polling of the bot) with a photo
            http("POST", "/demo/telegram/message?name=Lilit&text=" + urllib.request.quote("Where is my parcel?") + "&chat_id=777001&username=lilit_s&photo=true")
            await pg.wait_for_selector(".ib-item:has-text('Lilit')", timeout=8000)
            await pg.wait_for_function("document.querySelector('[data-nav=telegram] .nav-badge')", timeout=6000)
            await pg.click(".ib-item:has-text('Lilit')")
            await pg.wait_for_selector(".ib-b.in .ib-text:has-text('Where is my parcel?')", timeout=5000)
            await pg.wait_for_selector(".ib-b.in img.ib-img", timeout=8000)  # the photo was downloaded from Telegram and shown
            await pg.wait_for_selector(".ib-tht small:has-text('#')", timeout=8000)  # a Zammad ticket was opened for the chat
            # take it and answer with a quick reply; it reaches Telegram (simulator) and gets ✓✓ when delivered
            await pg.click("[data-act=in-take]")
            await pg.wait_for_selector("[data-act=in-take]", state="detached", timeout=4000)
            await pg.click(".ib-quick button >> nth=0")
            expect("Lilit" in await pg.input_value("textarea[name=ib-text]"), "quick reply did not fill in the name")
            await pg.fill("textarea[name=ib-text]", "Hello Lilit! Your parcel arrives tomorrow.")
            await pg.click("[data-act=in-send]")
            await pg.wait_for_selector(".ib-b.out .ib-text:has-text('arrives tomorrow')", timeout=5000)
            await pg.wait_for_selector(".ib-b.out .ib-tick.s-sent, .ib-b.out .ib-tick.s-delivered", timeout=8000)
            sent = http("GET", "/demo/messengers/sent")["telegram"]["sent"]
            expect(any("arrives tomorrow" in (m.get("text") or "") and str(m.get("chat_id")) == "777001" for m in sent), f"not sent to Telegram: {sent[-2:]}")
            # an internal note stays inside (Zammad), never goes to the customer
            n_before = len(sent)
            await pg.click("[data-act=in-note]")
            await pg.fill("textarea[name=ib-text]", "VIP customer, check the courier")
            await pg.click("[data-act=in-send]")
            await pg.wait_for_selector(".ib-b.note .ib-text:has-text('VIP customer')", timeout=5000)
            await pg.click("[data-act=in-note]")
            await pg.wait_for_timeout(600)
            expect(len(http("GET", "/demo/messengers/sent")["telegram"]["sent"]) == n_before, "internal note was sent to the customer")
            # close the conversation (also closes the Zammad ticket) and find it under Closed
            await pg.click("[data-act=in-close]")
            await pg.wait_for_selector("[data-act=in-reopen]", timeout=5000)
            await pg.click(".ib-tabs [data-view=closed]")
            await pg.wait_for_selector(".ib-item:has-text('Lilit')", timeout=5000)
            await pg.click(".ib-tabs [data-view=open]")
        await step("Telegram (company bot): live incoming message with photo, Zammad ticket, take, quick reply, ✓ delivered, internal note, close", telegram_inbox())

        async def whatsapp_inbox():
            await nav(pg, "whatsapp")
            await pg.wait_for_selector(".ib[data-channel=whatsapp] .ib-item", timeout=6000)
            await pg.click(".ib-item:has-text('Aram Grigoryan')")
            await pg.wait_for_selector(".ib-window:not(.closed)", timeout=4000)  # 24-hour customer-service window is open
            await pg.wait_for_selector(".ib-tht small:has-text('+374')", timeout=4000)
            await pg.fill("textarea[name=ib-text]", "Hello Aram! The sofa will be delivered on Friday.")
            await pg.keyboard.press("Enter")
            await pg.wait_for_selector(".ib-b.out .ib-text:has-text('on Friday')", timeout=5000)
            await pg.wait_for_selector(".ib-b.out .ib-tick.s-delivered, .ib-b.out .ib-tick.s-read", timeout=10000)  # status webhook from Meta
            sent = http("GET", "/demo/messengers/sent")["whatsapp"]["sent"]
            expect(any("on Friday" in json.dumps(m) for m in sent), "not sent to WhatsApp Cloud API")
            # a reply from the customer arrives live (signed webhook)
            http("POST", "/demo/whatsapp/message?text=" + urllib.request.quote("Great, thank you!"))
            await pg.wait_for_selector(".ib-b.in .ib-text:has-text('Great, thank you!')", timeout=8000)
            # transfer to a colleague
            await pg.click("[data-act=in-transfer]")
            await pg.click(".ib-tr .ib-tra[data-agent='2']")
            await pg.wait_for_selector(".ib-taken", timeout=5000)
            await pg.wait_for_selector(".ib-event", timeout=5000)
            # the number is the organisation's: the operator has no personal number, the call button uses the company phone
            expect(await pg.locator("[data-act=in-call]").count() == 1, "call button missing")
        await step("WhatsApp (company number): 24-hour window, send ✓✓ via Cloud API, live reply by webhook, transfer to a colleague", whatsapp_inbox())

        async def mail_page():
            await nav(pg, "mail")
            await pg.wait_for_selector("[data-mail-login], .ml-center, .ml-folders", timeout=6000)
            if await pg.locator(".ml-center .ml-card h2").count() and not await pg.locator("[data-mail-login]").count():
                RESULTS.append(("Mail: (mail server not running in this environment — skipped)", True, ""))
                return
            # the employee types only the e-mail and password: the server was set up by the administrator
            await pg.fill("input[name=mail-email]", "anna@company.test")
            await pg.fill("input[name=mail-password]", "wrong")
            await pg.click("[data-mail-login] button.primary")
            await pg.wait_for_selector(".toast.error", timeout=8000)
            await pg.fill("input[name=mail-password]", "anna-mail-1")
            await pg.click("[data-mail-login] button.primary")
            await pg.wait_for_selector(".ml-folders [data-folder=inbox]", timeout=10000)
            await pg.wait_for_selector(".ml-item:has-text('Order 4512')", timeout=8000)
            await pg.click(".ml-item:has-text('Order 4512')")
            await pg.wait_for_selector(".ml-head h2:has-text('Order 4512')", timeout=6000)
            body = await pg.frame_locator("iframe.ml-frame").locator("body").inner_text()
            expect("invoice for order 4512" in body, f"message body not shown: {body[:200]}")
            # reply: goes out through SMTP with Anna's own login and lands in Sent
            await pg.click("[data-act=ml-reply]")
            await pg.wait_for_selector("[data-compose]", timeout=3000)
            expect("client@company.test" in await pg.input_value("input[name=ml-to]"), "reply recipient not filled in")
            expect((await pg.input_value("input[name=ml-subject]")).lower().startswith("re:"), "reply subject")
            await pg.fill("textarea[name=ml-body]", "Hello Narine, the invoice is attached.\n\n" + await pg.input_value("textarea[name=ml-body]"))
            await pg.set_input_files("[data-compose] input[type=file]", files=[{"name": "invoice-4512.txt", "mimeType": "text/plain", "buffer": b"Invoice 4512: 120 000 AMD"}])
            await pg.click("[data-act=ml-send]")
            await pg.wait_for_selector("[data-compose]", state="detached", timeout=10000)
            await pg.click(".ml-folders [data-folder=sent]")
            await pg.wait_for_selector(".ml-item:has-text('Order 4512')", timeout=8000)
            await pg.click(".ml-folders [data-folder=inbox]")
            await pg.wait_for_selector(".ml-item", timeout=6000)
            # create a Zammad ticket from the e-mail
            await pg.click(".ml-item:has-text('Meeting on Thursday')")
            await pg.wait_for_selector(".ml-head h2:has-text('Meeting')", timeout=6000)
            await pg.click("[data-act=ml-ticket]")
            await pg.wait_for_selector(".toast:not(.error)", timeout=8000)
            # a new e-mail arrives in real time (IMAP IDLE) — no reload
            import smtplib, ssl  # noqa: E401
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE  # noqa: E702
            c = smtplib.SMTP("127.0.0.1", 587, timeout=10); c.starttls(context=ctx); c.login("client@company.test", "client-mail-3")  # noqa: E702
            c.sendmail("client@company.test", ["anna@company.test"], b"From: client@company.test\r\nTo: anna@company.test\r\nSubject: Urgent: live test\r\n\r\nhi")
            c.quit()
            await nav(pg, "work")
            await pg.wait_for_function("document.querySelector('[data-nav=mail] .nav-badge')", timeout=15000)
            await nav(pg, "mail")
            await pg.wait_for_selector(".ml-item:has-text('Urgent: live test')", timeout=10000)
        await step("Mail: sign in with e-mail + password only, read, reply with attachment (SMTP → Sent), ticket from e-mail, live new mail (IMAP IDLE)", mail_page())
        await bp.close()

        if SHOTS:
            await pg.screenshot(path=f"{SHOTS}/e2e_operator.png", full_page=True)

        # ---------------------------------------------------------------- supervisor
        sp = await new_page()
        await step("Login: supervisor boss", login(sp, "boss"))

        async def sup_view():
            await nav(sp, "sup")
            await sp.wait_for_selector("table tbody tr", timeout=5000)
            txt = await sp.inner_text("table")
            expect("Anna" in txt and "Boris" in txt, "operators missing")
            expect("blocking" in txt.lower() or "блок" in txt.lower(), "anna's reason missing")
            expect(await sp.locator("table tbody tr:has-text('Anna') .lvl").count() == 1, "level not shown in supervisor table")
        await step("Supervisor sees operators with reasons", sup_view())

        async def sup_level_filter():
            await sp.click(".level-filter button[data-level=level1]")
            await sp.wait_for_timeout(300)
            rows = await sp.locator("table").first.locator("tbody tr").count()
            names = await sp.inner_text("table tbody")
            expect(rows == 1 and "Anna" in names, f"level filter shows: {names!r}")
            await sp.click(".level-filter button >> nth=0")
            await sp.wait_for_timeout(300)
            expect(await sp.locator("table").first.locator("tbody tr").count() >= 2, "'All' filter does not show everyone")
        await step("Manager panel: filter the team by level", sup_level_filter())

        async def overview_page():
            await nav(sp, "overview")
            await sp.wait_for_selector(".ov-tiles .tile", timeout=8000)
            expect(await sp.locator(".ov-tiles .tile").count() == 5, "overview tiles missing")
            offered = int((await sp.inner_text(".tile-calls .big")).strip())
            expect(offered >= 20, f"incoming calls on the overview: {offered}")
            sl = (await sp.inner_text(".gauge-val")).strip()
            expect(sl.endswith("%"), f"service level: {sl!r}")
            expect(await sp.locator(".ov-chart .bar-ans").count() >= 3, "hourly chart has no bars")
            await sp.hover(".ov-chart .hit >> nth=4")
            expect(await sp.locator(".chart-tip").count() == 1, "chart tooltip missing")
            rows = await sp.locator(".ov-table tbody tr").count()
            expect(rows >= 6, f"operators table rows: {rows}")
            davit = await sp.inner_text(".ov-table tbody tr:has-text('Davit')")
            expect("Does not pick up" in davit or "Не берёт" in davit, f"no RONA flag for the avoider: {davit!r}")
            best = await sp.inner_text(".ov-leaders .lead >> nth=0")
            expect(any(n in best for n in ("Mariam", "Narek", "Sona")), f"leader: {best!r}")
            expect(await sp.locator(".ov-unret .unret").count() >= 1, "missed callers list empty")
        await step("Manager overview: calls, service level, chart, ranking, flags", overview_page())

        async def overview_filters():
            await sp.click(".ov-levels button[data-level=level3]")
            await sp.wait_for_timeout(300)
            names = await sp.inner_text(".ov-table tbody")
            expect("Mariam" in names and "Davit" not in names, f"level filter on overview: {names[:120]!r}")
            await sp.click(".ov-levels button >> nth=0")
            await sp.select_option(".ov-agents select[name=ov-sort]", "rona")
            await sp.wait_for_timeout(300)
            first = await sp.inner_text(".ov-table tbody tr >> nth=0")
            expect("Davit" in first, f"sort by 'not picked up' should put Davit first: {first[:60]!r}")
            await sp.click(".ov-period button[data-period='7d']")
            await sp.wait_for_timeout(1200)
            expect(await sp.locator(".ov-chart .bar-ans").count() >= 1, "7-day chart empty")
            await sp.click(".ov-period button[data-period=today]")
            await sp.wait_for_timeout(800)
            await nav(sp, "sup")
        await step("Overview: level filter, sorting, period switch", overview_filters())

        async def live_push():
            expect(await sp.locator(".live-pill.lv-ok").count() == 1, "live indicator is not green")
            await nav(sp, "overview")
            await sp.wait_for_selector(".tile-live .big")
            await sp.wait_for_timeout(600)
            before = int((await sp.inner_text(".tile-live .big")).strip())
            t0 = time.monotonic()
            link = http("POST", "/demo/call?ext=102&number=89995554433")["linkedid"]   # a call starts ringing
            now = before
            while time.monotonic() - t0 < 3 and now != before + 1:
                await sp.wait_for_timeout(50)
                now = int((await sp.inner_text(".tile-live .big")).strip())
            took = time.monotonic() - t0
            expect(now == before + 1, f"waiting calls did not update live ({before} -> {now})")
            expect(took < 2.0, f"live update took {took:.2f} s")            # polling would take up to 30 s
            http("POST", f"/demo/answer?linkedid={link}&ext=102")             # answered -> gone from the queue
            t0 = time.monotonic()
            while time.monotonic() - t0 < 3 and now != before:
                await sp.wait_for_timeout(50)
                now = int((await sp.inner_text(".tile-live .big")).strip())
            expect(now == before, f"answered call still waiting ({now})")
            await nav(sp, "sup")
        await step("Live mode: a new call appears on the manager's overview within 2 s, no reload", live_push())

        async def idle_pause():
            # boris opens Zenith Desk and walks away; a short test limit (8 s) instead of the real 60 minutes
            bp = await new_page()
            await login(bp, "boris")
            await bp.evaluate("localStorage.setItem('agentix_idle_test_ms', '8000'); localStorage.removeItem('agentix_last_activity')")
            await bp.reload()
            await bp.wait_for_selector(".topbar .status")
            await bp.wait_for_selector(".idle-warn", timeout=12000)                 # warning before the pause
            await bp.wait_for_selector(".idle-overlay .idle-back", timeout=12000)   # paused
            expect(await bp.locator(".layout.frozen").count() == 1, "interface is not dimmed / frozen")
            try:   # the screen freezes at once; the server's confirmation (offline) follows within a moment
                await bp.wait_for_selector(".topbar .status.st-offline", state="attached", timeout=5000)
            except Exception:  # noqa: BLE001
                expect(False, "operator not offline after the pause")
            expect(http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["paused"], "calls still go to the absent operator")
            row = sp.locator("table tbody tr:has-text('Boris')").first
            await row.locator(".idle-tag").wait_for(timeout=4000)                    # manager sees it live
            expect(await row.locator(".status.st-offline").count() == 1, "manager does not see Boris offline")
            await bp.evaluate("localStorage.removeItem('agentix_idle_test_ms')")
            await bp.click(".idle-back")
            await bp.wait_for_selector(".idle-overlay", state="detached", timeout=4000)
            await bp.wait_for_timeout(600)
            expect(await bp.locator(".layout.frozen").count() == 0, "still frozen after 'I'm back'")
            expect(not http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["paused"], "calls did not resume")
            await sp.wait_for_timeout(800)
            expect(await sp.locator("table tbody tr:has-text('Boris') .idle-tag").count() == 0, "manager still sees Boris away")
            await bp.close()
        await step("Inactivity: warning, screen dims and freezes, calls stop, manager sees 'Away'; 'I'm back' resumes", idle_pause())

        async def messenger():
            # the manager finds Anna, writes to her; Anna gets it live, answers; ✓✓ and history are kept
            await nav(sp, "chat")
            await sp.wait_for_selector(".chat-item")
            await sp.fill("input[name=chat-search]", "anna")
            try:
                await sp.wait_for_function("document.querySelectorAll('.chat-item').length === 1", timeout=3000)
            except Exception:  # noqa: BLE001
                pass
            items = await sp.locator(".chat-item").count()
            names = await sp.evaluate("[...document.querySelectorAll('.chat-item .ci-name')].map(e => e.textContent)")
            expect(items == 1 and "Anna" in names[0], f"search did not find Anna: {names}")
            await sp.click(".chat-item")
            await sp.wait_for_selector(".chat-compose textarea")
            before = await pg.evaluate("+(document.querySelector('.nav-badge') || {textContent: '0'}).textContent")
            await sp.fill(".chat-compose textarea", "E2E hello Anna\nsecond line")
            await sp.keyboard.press("Enter")
            await sp.wait_for_selector(".bubble-row.mine:has-text('E2E hello Anna')")
            expect(await sp.locator(".chat-compose textarea").input_value() == "", "composer not cleared")
            # Anna (on her workplace) gets an unread badge and a clickable toast, live
            await pg.wait_for_selector(".toast.chat", timeout=4000)
            after = await pg.evaluate("+(document.querySelector('.nav-badge') || {textContent: '0'}).textContent")
            expect(after == before + 1, f"unread badge did not go up live ({before} -> {after})")
            await pg.click(".toast.chat")                       # opens the conversation
            await pg.wait_for_selector(".bubble-row:not(.mine):has-text('E2E hello Anna')", timeout=4000)
            expect("second line" in await pg.inner_text(".bubble-row:not(.mine):has-text('E2E hello Anna')"), "multi-line text lost")
            await sp.wait_for_selector(".bubble-row.mine:has-text('E2E hello Anna') .tick.read", timeout=4000)   # ✓✓ read
            # typing indicator + reply
            await pg.type(".chat-compose textarea", "Hi! On my way", delay=20)
            await sp.wait_for_selector(".ch-text small.on", timeout=4000)
            await pg.click(".send-btn")
            await sp.wait_for_selector(".bubble-row:not(.mine):has-text('Hi! On my way')", timeout=4000)
            # user info panel
            await sp.click(".ch-person")
            await sp.wait_for_selector(".chat-info .ci-row")
            info = await sp.inner_text(".chat-info")
            expect("101" in info and "Anna" in info, f"profile card: {info[:120]!r}")
            await sp.click(".chat-info .ch-btn")
            # history is kept: reload and it is still there
            await sp.reload()
            await sp.wait_for_selector(".sidebar")
            await nav(sp, "chat")
            await sp.click(".chat-item:has-text('Anna')")
            await sp.wait_for_selector(".bubble:has-text('Hi! On my way')", timeout=4000)
            await nav(pg, "work")
            await nav(sp, "sup")
        await step("Messenger: search, send, live delivery + badge + toast, ✓✓ read, typing, profile, history kept", messenger())

        async def messenger_plus():
            await nav(sp, "chat")
            await sp.click(".chat-item:has-text('Anna')")
            await sp.wait_for_selector(".bubble")
            # the list shows only conversations; Boris writes -> his chat jumps to the top with the new time, live
            boris_token = http("POST", "/api/auth/login", {"username": "boris", "password": "pw"})["token"]
            boss_id = await sp.evaluate("JSON.parse(atob(localStorage.getItem('aws_token').split('.')[1])).sub")
            http("POST", f"/api/chat/{boss_id}/messages", {"body": "E2E ping from Boris"}, token=boris_token)
            await sp.wait_for_function("document.querySelector('.chat-item .ci-name') && document.querySelector('.chat-item .ci-name').textContent.includes('Boris')", timeout=4000)
            expect("E2E ping from Boris" in await sp.inner_text(".chat-item >> nth=0"), "preview of the newest chat not updated")
            # reactions: Anna reacts to the manager's message from her side, the manager sees it live
            await nav(pg, "chat")
            await pg.click(".chat-item:has-text('Olga'), .chat-item:has-text('Руковод'), .chat-item >> nth=0")
            await pg.wait_for_selector(".bubble-row:not(.mine) .bubble")
            await pg.locator(".bubble-row:not(.mine) .bubble").last.click(button="right")
            await pg.click(".mm-react[data-emoji='👍']")
            await sp.wait_for_selector(".bubble-row.mine .react-chip:has-text('👍')", timeout=4000)
            # edit: the manager fixes his last message, Anna sees the new text live with "edited"
            await sp.locator(".bubble-row.mine .bubble").last.click(button="right")
            await sp.click(".mm-edit")
            await sp.fill(".chat-compose textarea", "E2E edited text")
            await sp.keyboard.press("Enter")
            await pg.wait_for_selector(".bubble:has-text('E2E edited text') .b-edited", timeout=4000)
            # delete for everyone: gone on both screens
            await sp.fill(".chat-compose textarea", "E2E to be deleted")
            await sp.keyboard.press("Enter")
            await pg.wait_for_selector(".bubble:has-text('E2E to be deleted')", timeout=4000)
            await sp.locator(".bubble:has-text('E2E to be deleted')").click(button="right")
            await sp.click(".mm-delete")
            expect(await sp.is_checked(".chat-dialog input[name=del-all]"), "'also delete for Anna' should be on for own messages")
            await sp.click(".cd-confirm")
            await sp.wait_for_selector(".bubble:has-text('E2E to be deleted')", state="detached", timeout=3000)
            await pg.wait_for_selector(".bubble:has-text('E2E to be deleted')", state="detached", timeout=4000)
            # background notifications: the service worker is installed and the setting is offered
            reg = await pg.evaluate("navigator.serviceWorker.getRegistration('/').then(r => !!r)")
            expect(reg, "service worker for background notifications not registered")
            await pg.click(".settings-btn")
            await pg.wait_for_selector(".push-row")
            await nav(pg, "work")
            await nav(sp, "sup")
        await step("Messenger v3.1: live re-order, reactions, edit, delete for everyone, background notifications", messenger_plus())

        async def messenger_groups_files():
            # v3.20: «Anna is typing…» with the name, files (picture shown, document downloads), emoji, group conversations
            await nav(sp, "chat")
            await nav(pg, "chat")
            await sp.click(".chat-item:has-text('Anna')")
            await pg.click(".chat-item:has-text('Olga'), .chat-item:has-text('Руковод')")
            await sp.wait_for_selector(".chat-compose textarea")
            await pg.wait_for_selector(".chat-compose textarea")
            await pg.type(".chat-compose textarea", "typing test", delay=25)
            await sp.wait_for_selector("[data-typing]", timeout=4000)
            who = await sp.inner_text("[data-typing]")
            expect("Anna" in who or "Анна" in who, f"the typing bubble does not name who types: {who!r}")
            expect(("Anna" in await sp.inner_text("[data-chat-status]")), "the header does not show who types")
            await pg.fill(".chat-compose textarea", "")
            # files + emoji from the manager
            await sp.set_input_files("#chat-file-input", [{"name": "screen.png", "mimeType": "image/png", "buffer": png_bytes(120, 80)},
                                                          {"name": "report.txt", "mimeType": "text/plain", "buffer": b"E2E report body"}])
            await sp.wait_for_function("document.querySelectorAll('[data-pending] .cp-file:not(.reading)').length === 2", timeout=4000)
            await sp.click("[data-act=emoji]")
            await sp.click("[data-em-tab=gestures]")
            await sp.click("[data-em='👍']")
            expect("👍" in await sp.input_value(".chat-compose textarea"), "the emoji was not put into the text")
            await sp.keyboard.type(" E2E files")
            await sp.keyboard.press("Enter")
            await sp.wait_for_selector("[data-pending]", state="detached", timeout=4000)
            await pg.wait_for_selector(".bubble:has-text('E2E files') .b-img img", timeout=6000)  # the picture, fetched with the sign-in
            expect(await pg.locator(".bubble:has-text('E2E files') .b-file:has-text('report.txt')").count() == 1, "the document is not in the bubble")
            async with pg.expect_download() as dl:
                await pg.click(".bubble:has-text('E2E files') .b-file:has-text('report.txt')")
            path = await (await dl.value).path()
            expect(open(path, "rb").read() == b"E2E report body", "the downloaded file differs")
            # a group: the manager creates it with Anna and Boris, writes; Anna gets it live with the sender's name
            await sp.click("[data-act=new-group]")
            await sp.fill(".ng-name", "E2E night shift")
            await sp.fill("input[name=group-people-search]", "Anna")
            await sp.click("[data-new-group] .pick-row:has-text('Anna')")
            await sp.fill("input[name=group-people-search]", "Boris")
            await sp.click("[data-new-group] .pick-row:has-text('Boris')")
            await sp.click("[data-act=group-create]")
            await sp.wait_for_selector(".chat-head:has-text('E2E night shift')", timeout=4000)
            await pg.wait_for_selector(".chat-item.group:has-text('E2E night shift')", timeout=4000)
            await sp.fill(".chat-compose textarea", "E2E group hello")
            await sp.keyboard.press("Enter")
            await pg.wait_for_selector(".chat-item.group:has-text('E2E group hello') .ci-badge", timeout=4000)
            await pg.click(".chat-item.group:has-text('E2E night shift')")
            await pg.wait_for_selector(".bubble:has-text('E2E group hello') .b-who", timeout=4000)
            # typing in the group names the person too
            await pg.type(".chat-compose textarea", "I take it", delay=25)
            await sp.wait_for_selector("[data-typing]", timeout=4000)
            await pg.keyboard.press("Enter")
            await sp.wait_for_selector(".bubble:has-text('I take it')", timeout=4000)
            # the group panel: members, the owner adds / removes, a member leaves
            await sp.click(".chat-head .ch-btn")
            await sp.wait_for_selector("[data-group-info] [data-member]")
            expect(await sp.locator("[data-group-info] [data-member]").count() == 3, "group members missing")
            await pg.click(".chat-head .ch-btn")
            await pg.wait_for_selector("[data-group-info]")
            expect(await pg.locator("[data-act=group-add]").count() == 0, "only the owner may add members")
            await pg.click("[data-act=group-leave]")
            await pg.click("[data-act=group-leave-yes]")
            await pg.wait_for_selector(".chat-item.group:has-text('E2E night shift')", state="detached", timeout=4000)
            await sp.wait_for_function("document.querySelectorAll('[data-group-info] [data-member]').length === 2", timeout=4000)
            await sp.click("[data-group-info] .ci-head .ch-btn")
            await nav(pg, "work")
            await nav(sp, "sup")
        await step("Messenger v3.20: «Anna is typing…» with the name, files (picture shown, download), emoji, a group: create, live with names, members, leave", messenger_groups_files())

        async def sup_reconcile():
            await sp.click("table tbody tr:has-text('Anna') button:has-text('Reconcile'), table tbody tr:has-text('Anna') button:has-text('Сверка')")
            await sp.wait_for_selector(".toast", timeout=4000)
        await step("Supervisor: reconcile", sup_reconcile())

        async def sup_override():
            await sp.click("table tbody tr:has-text('Anna') button.warn")
            await sp.wait_for_selector(".modal")
            await sp.check(".modal input[type=checkbox]")
            await sp.fill(".modal textarea", "E2E peak load")
            await sp.click(".modal .footer button.warn")
            await sp.wait_for_timeout(900)
            expect(not pbx(), "override ready must unpause despite blocking")
        await step("Supervisor: override with reason", sup_override())

        async def sup_cancel():
            sp.once("dialog", lambda d: asyncio.ensure_future(d.accept("E2E cancel")))
            await sp.click("table tbody tr:has-text('Anna') a.empty")
            await sp.wait_for_timeout(1000)
            tasks = http("GET", "/api/agents/me/tasks", token=await pg.evaluate("localStorage.getItem('aws_token')"))
            expect(len(tasks["blocking"]) == 0, "session not cancelled")
        await step("Supervisor: cancel an operator's session", sup_cancel())

        async def operator_notified():
            await pg.wait_for_timeout(1500)
            await pg.reload()
            await pg.wait_for_selector(".bell")
            await pg.wait_for_timeout(800)
            expect(await pg.locator(".bell .badge").count() == 1, "no unread badge on the bell")
            await pg.click(".bell")
            await pg.wait_for_selector(".ntf-pop .ntf-item", timeout=4000)
            expect("E2E cancel" in await pg.inner_text(".ntf-pop"), "cancel reason not in notifications")
            await pg.wait_for_timeout(500)
            expect(await pg.locator(".bell .badge").count() == 0, "badge not cleared after opening")
            await pg.click("main", position={"x": 12, "y": 12})  # outside the popup closes it
            await pg.wait_for_selector(".ntf-pop", state="detached", timeout=3000)
        await step("Operator gets a notification (bell + panel) when supervisor intervenes", operator_notified())

        async def sup_kpis_and_assign():
            expect(await sp.locator(".sup-kpis .kpi").count() == 6, "supervisor summary cards missing")
            await sp.click(".assign-btn")
            await sp.wait_for_selector(".modal")
            await sp.fill(".modal input[name=ticket]", "31102")  # still unassigned/new
            boris = await sp.evaluate("[...document.querySelectorAll('.modal select[name=agent] option')].find(o => o.textContent.includes('Boris')).value")
            await sp.select_option(".modal select[name=agent]", boris)
            await sp.select_option(".modal select[name=mode]", "background")
            await sp.click(".modal .footer button.primary")
            await sp.wait_for_timeout(1200)
            expect(await sp.locator(".modal").count() == 0, "assign modal still open")
            txt = await sp.inner_text("table")
            expect("#31102" in txt, "assigned ticket not shown in operator tasks")
        await step("Supervisor: summary cards and assign a ticket by number", sup_kpis_and_assign())

        async def sup_audit_report():
            txt = await sp.inner_text("main")
            expect("supervisor_override" in txt, "override not in audit log")
            expect(await sp.locator(".grid table tbody tr").count() >= 3, "report rows missing")
        await step("Supervisor: audit log and report", sup_audit_report())

        if SHOTS:
            await sp.screenshot(path=f"{SHOTS}/e2e_supervisor.png", full_page=True)

        # ---------------------------------------------------------------- second operator, mobile, logout
        mob = await new_page(390, 844)
        await step("Login: operator boris on mobile", login(mob, "boris"))

        async def mobile_layout():
            width = await mob.evaluate("document.documentElement.scrollWidth")
            expect(width <= 390, f"horizontal scroll on mobile: {width}px")
        await step("Mobile layout has no horizontal scroll", mobile_layout())

        async def logout():
            if await mob.locator(".burger").is_visible():  # Flow: the toolbar is always at the bottom
                await mob.click(".burger")
            await mob.click(".side-foot .logout")
            await mob.wait_for_selector("input[autocomplete=username]", timeout=5000)
            expect(http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["paused"], "logout must pause (offline)")
        await step("Sign out sets the operator offline (paused)", logout())

        # ---------------------------------------------------------------- administrator panel
        ad = await new_page()
        await step("Login: administrator (no operator controls)", login(ad, "admin", "admin", wait=".sidebar"))

        async def admin_nav_only():
            expect(await ad.locator(".topbar button.go, .topbar .status").count() == 0, "admin must not see Ready/Break")
            expect(await ad.locator(".topbar .bell").count() == 1, "v3.10: admin has the notification bell (backup alerts)")
            expect(await ad.locator(".side-nav button").count() == 6, "admin menu must have 6 items (customers, messages, manager panel, overview, manager tools, administration)")
            expect(await ad.locator("table.users tbody tr").count() == 8, "users table not shown")  # 4 + 4 demo-history operators
        await step("Admin opens on the Users page with the admin menu", admin_nav_only())

        async def users_panel():
            # v3.21: presence, filters, a row opens the details; a lock shows where the attempts came from and is lifted here
            for _ in range(5):
                try:
                    http("POST", "/api/auth/login", {"username": "sona", "password": "wrong-guess"})
                except urllib.error.HTTPError:
                    pass
            await ad.click("[data-um-filter=all]")
            await ad.wait_for_timeout(1500)  # the list follows by itself (live)
            if await ad.locator("tr[data-user=sona] [data-unlock]").count() == 0:
                await nav(ad, "users")
            await ad.wait_for_selector("tr[data-user=sona] [data-unlock]", timeout=6000)
            expect(await ad.get_attribute("tr[data-user=sona] [data-presence]", "data-presence") == "lock", "sona must show as locked")
            expect(await ad.get_attribute("tr[data-user=admin] [data-presence]", "data-presence") == "on", "the admin himself is online")
            await ad.click("[data-um-filter=locked]")
            await ad.wait_for_timeout(300)
            expect(await ad.locator("table.users tbody tr.urow").count() == 1, "the Locked filter shows only sona")
            await ad.click("tr[data-user=sona]")
            await ad.wait_for_selector("[data-user-detail=sona] [data-um-lock]", timeout=5000)
            lock = await ad.inner_text("[data-user-detail=sona] [data-um-lock]")
            expect("127.0.0.1" in lock and "5" in lock, f"lock reason: {lock!r}")
            tries = await ad.locator("[data-user-detail=sona] .um-tries tbody tr").count()
            expect(tries >= 5, f"sign-in attempts listed: {tries}")
            await ad.click("[data-user-detail=sona] .um-alert-btns .btn.primary")
            await ad.wait_for_timeout(1200)
            expect(await ad.locator("tr[data-user=sona] [data-unlock]").count() == 0, "still locked after Unlock")
            try:  # the demo-history accounts have no password: after the unlock the answer is «wrong password», not «locked»
                http("POST", "/api/auth/login", {"username": "sona", "password": "x"})
                code = 200
            except urllib.error.HTTPError as e:
                code = e.code
            expect(code == 401, f"after the unlock the login answers {code}, expected 401 (not 429)")
            await ad.click("[data-um-filter=all]")
            await ad.click("tr[data-user=sona]")  # close it again
            await ad.click("tr[data-user=anna]")
            await ad.wait_for_selector("[data-user-detail=anna] .um-grid", timeout=5000)
            det = await ad.inner_text("[data-user-detail=anna]")
            expect("101" in det and ("127.0.0.1" in det), f"anna's details: {det[:200]!r}")
            await ad.click("tr[data-user=anna]")
            await ad.wait_for_timeout(300)
            expect(await ad.locator("table.users tbody tr").count() == 8, "rows closed again")
        await step("Users panel: online / locked at a glance, details, lock with its address, Unlock", users_panel())

        async def admin_grouped_nav():
            # v3.15.1: one «Administration» icon; the 9 pages are tabs; the last one is remembered; the rail fits any screen
            await nav(ad, "users")
            if STYLE != "studio":
                tabs = await ad.eval_on_selector_all(".sec-tabs [data-sec-tab]", "els => els.map(e => e.dataset.secTab)")
                expect(tabs == ["users", "integrations", "settings", "groups", "types", "routing", "system", "backup", "apikeys"], f"admin tabs: {tabs}")
            await nav(ad, "routing")
            await nav(ad, "sup")
            await ad.click(".side-nav button[data-nav=admin]")
            await ad.wait_for_timeout(700)
            expect(await ad.get_attribute("main .page", "data-page") == "routing", "the last administration page opens again")
            expect(await ad.locator(".side-nav button[data-nav=admin].on").count() == 1, "the group icon is marked")
            await nav(ad, "users")
            for w, h in ((1366, 768), (1280, 600)):
                await ad.set_viewport_size({"width": w, "height": h})
                await ad.wait_for_timeout(300)
                r = await ad.evaluate("() => { const a = document.querySelector('.sidebar'), f = document.querySelector('.side-foot .logout').getBoundingClientRect(); return [a.scrollHeight - a.clientHeight, Math.round(f.bottom)]; }")
                expect(r[0] <= 1 and r[1] <= h, f"{w}×{h}: the rail does not fit ({r})")
            await ad.set_viewport_size({"width": 390, "height": 844})
            await ad.wait_for_timeout(400)
            narrow = await ad.evaluate("() => [...document.querySelectorAll('table.users td')].filter(c => c.getBoundingClientRect().width < 50 && c.innerText.trim().length > 5).length")
            sw = await ad.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            expect(narrow == 0 and sw <= 1, f"phone: users table squeezed ({narrow} cells) or sideways scroll ({sw}px)")
            await ad.set_viewport_size({"width": 1440, "height": 950})
            await ad.wait_for_timeout(300)
        await step("Administration: one rail icon, pages as tabs (last one remembered), rail fits 600 px high, tables scroll on a phone", admin_grouped_nav())

        async def api_keys():
            # v3.18: a key for another program — shown once, works with the chosen user's rights, can be revoked
            await nav(ad, "apikeys")
            await ad.wait_for_selector("[data-ak=form]")
            await ad.fill("[name=ak-name]", "CRM export")
            opt = await ad.eval_on_selector("[name=ak-user]", "s => [...s.options].find(o => o.text.includes('Olga')).value")
            await ad.select_option("[name=ak-user]", opt)
            await ad.click("[data-ak=create]")
            await ad.wait_for_selector("[data-ak=new-key]")
            key = await ad.input_value("[data-ak=new-key] input")
            expect(key.startswith("zdk_"), f"key shown once: {key[:8]}")
            req = urllib.request.Request(BASE + "/api/admin/agents", headers={"X-API-Key": key})
            with urllib.request.urlopen(req) as r:
                expect(r.status == 200 and "agents" in json.loads(r.read()), "the program reads the team with the key")
            try:
                urllib.request.urlopen(urllib.request.Request(BASE + "/api/admin/agents/1/reconcile", method="POST", headers={"X-API-Key": key}))
                ro = False
            except urllib.error.HTTPError as e:
                ro = e.code == 403
            expect(ro, "a read-only key cannot change anything")
            ad.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await ad.click("[data-ak=list] tr[data-key] [data-act=revoke] >> nth=0")
            await ad.wait_for_selector("[data-ak=list] tr[data-key] .ak-st.revoked", timeout=5000)
            try:
                urllib.request.urlopen(req)
                gone = False
            except urllib.error.HTTPError as e:
                gone = e.code == 401
            expect(gone, "a revoked key is refused at once")
            await nav(ad, "users")  # the next checks start on the users page
        await step("API keys: the administrator makes a key for another program (shown once, read only), it works, revoked it stops", api_keys())

        async def create_user():
            await ad.click(".toolbar button.primary")
            await ad.wait_for_selector(".modal.wide")
            f = lambda n: f".modal.wide input[name={n}]"  # noqa: E731
            await ad.fill(f("first_name"), "Karen")
            await ad.fill(f("last_name"), "Petrosyan")
            await ad.fill(f("username"), "karen")
            await ad.fill(f("position"), "Night shift operator")
            await ad.select_option(".modal.wide select[name=level]", "level2")
            await ad.fill(f("password"), "karen-pass-1")
            await ad.fill(f("zammad_search"), "karen")
            await ad.click(".modal.wide button.zsearch")
            await ad.wait_for_selector(".zitem", timeout=4000)
            await ad.click(".zitem >> nth=0")
            await ad.fill(f("extension"), "103")
            await ad.click(".modal.wide button.fill-iface")
            expect(await ad.input_value(f("asterisk_interface")) == "Local/103@from-queue/n", "interface not filled")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(900)
            expect(await ad.locator(".modal").count() == 0, "user modal still open")
            row = await ad.inner_text("table.users tbody tr:has-text('Karen')")
            expect("karen" in row and "103" in row and "#12" in row, f"row: {row!r}")
        await step("Admin creates a user with Zammad link and extension", create_user())

        async def new_user_works():
            kp = await new_page()
            await login(kp, "karen", "karen-pass-1")
            # v3.19 Flow: only the picture in the header, the name / level / position in its tooltip
            me_text = (await kp.get_attribute(ME, "title") or "") if FLOW else await kp.inner_text(ME)
            expect("Karen Petrosyan" in me_text, "name not shown")
            if STYLE != "studio":
                expect("Night shift operator" in me_text, "position not in the top bar")
            lvl = me_text if FLOW else await kp.inner_text(ME_LEVEL)
            expect("2" in lvl, f"level not shown under the name: {lvl!r}")
            expect(await kp.locator(".side-nav button").count() == 7, "operator must see the workplace, tickets, customers, messages, mail, WhatsApp, Telegram")
            expect(await kp.locator("[data-nav=recordings]").count() == 0, "no Recordings section for an operator")
            expect(not http("GET", "/demo/pbx")["400"]["Local/103@from-queue/n"]["paused"], "karen must receive calls")
            await kp.close()
        await step("New user signs in and gets the workplace (no setup needed)", new_user_works())

        async def reset_password_forced_change():
            await ad.click("table.users tbody tr:has-text('Karen') button >> nth=1")
            await ad.wait_for_selector(".modal")
            pw = ad.locator(".modal input").nth(0)
            await pw.fill("temp-pass-99")
            await ad.check(".modal input[type=checkbox]")
            await ad.click(".modal .footer button.primary")
            await ad.wait_for_selector(".modal input[readonly]")
            expect("temp-pass-99" in await ad.input_value(".modal input[readonly]"), "password not shown to admin")
            await ad.click(".modal .footer button.primary")
            kp = await new_page()
            await login(kp, "karen", "temp-pass-99", wait=".modal form")
            fields = kp.locator(".modal form input")
            await fields.nth(0).fill("temp-pass-99")
            await fields.nth(1).fill("karen-own-pass")
            await fields.nth(2).fill("karen-own-pass")
            await kp.click(".modal form button.primary")
            await kp.wait_for_selector(".topbar .status", timeout=6000)
            await kp.close()
        await step("Password reset forces the user to set an own password", reset_password_forced_change())

        async def disable_user():
            await ad.click("table.users tbody tr:has-text('Karen') button >> nth=0")
            await ad.wait_for_selector(".modal.wide")
            await ad.uncheck(".modal.wide input[name=active]")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(900)
            expect("disabled" in (await ad.inner_text("table.users tbody tr:has-text('Karen')")).lower()
                   or "отключ" in (await ad.inner_text("table.users tbody tr:has-text('Karen')")).lower(), "not disabled")
            kp = await new_page()
            await kp.goto(BASE + "/")
            await kp.fill("input[autocomplete=username]", "karen")
            await kp.fill("input[type=password]", "karen-own-pass")
            await kp.click("form button.primary")
            await kp.wait_for_selector("form p", timeout=5000)
            await kp.close()
        await step("Disabled user cannot sign in", disable_user())

        async def manager_level_gives_team_rights():
            await ad.click(".toolbar button.primary")
            await ad.wait_for_selector(".modal.wide")
            f = lambda n: f".modal.wide input[name={n}]"  # noqa: E731
            await ad.fill(f("first_name"), "Lilit")
            await ad.fill(f("last_name"), "Hakobyan")
            await ad.fill(f("username"), "lilit")
            await ad.fill(f("position"), "Shift manager")
            await ad.select_option(".modal.wide select[name=level]", "manager")
            access = await ad.inner_text(".modal.wide .access")
            expect("Manager" in access or "руковод" in access, f"access text: {access!r}")
            await ad.fill(f("password"), "lilit-pass-1")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(900)
            lp = await new_page()
            await login(lp, "lilit", "lilit-pass-1")
            expect(await lp.locator(".side-nav button").count() == 10, "manager must see workplace + tickets + customers + messages + mail + WhatsApp + Telegram + manager panel + overview + manager tools")
            await nav(lp, "sup")
            await lp.wait_for_selector("table tbody tr")
            expect("Anna" in await lp.inner_text("table"), "manager does not see the team")
            await lp.close()
        await step("Level 'Manager' gives the manager panel automatically", manager_level_gives_team_rights())

        async def integrations():
            await nav(ad, "integrations")
            expect(await ad.locator(".itabs [data-itab]").count() == 6, "integration tabs missing")
            await ad.click("[data-itab=zammad]")
            expect("/api/integrations/zammad/webhook" in await ad.input_value("[data-group=zammad] .webhook input"), "webhook url missing")
            await ad.click("[data-test=zammad]")
            await ad.wait_for_selector("[data-group=zammad] .banner.ok", timeout=6000)
            await ad.click("[data-itab=telephony]")
            expect(await ad.locator("[data-group=telephony], [data-group=phone]").count() == 2, "telephony + Zenith Phone groups")
            await ad.click("[data-test=telephony]")
            await ad.wait_for_selector("[data-group=telephony] .banner", timeout=6000)
            expect(await ad.locator("[data-group=telephony] .banner.ok").count() == 1, "AMI test not ok")
            # Telegram: the organisation's bot; the test asks Telegram who the bot is (getMe)
            await ad.click("[data-itab=telegram]")
            await ad.wait_for_selector("[data-group=telegram]", timeout=3000)
            expect(await ad.locator("[data-group=messengers]").count() == 1, "common messenger settings (Zammad mirror, quick replies) missing")
            await ad.click("[data-test=telegram]")
            await ad.wait_for_selector("[data-group=telegram] .banner.ok", timeout=8000)
            expect("@" in await ad.inner_text("[data-group=telegram] .banner.ok"), "bot name not shown")
            # WhatsApp: one company number; Callback URL + verify token for Meta
            await ad.click("[data-itab=whatsapp]")
            expect("/api/integrations/whatsapp/webhook" in await ad.inner_html("[data-group=whatsapp] .webhook"), "WhatsApp callback URL missing")
            expect(len(await ad.input_value("input[name=wa-verify]")) >= 16, "verify token missing")
            await ad.click("[data-test=whatsapp]")
            await ad.wait_for_selector("[data-group=whatsapp] .banner.ok", timeout=8000)
            expect("555 000" in await ad.inner_text("[data-group=whatsapp] .banner.ok"), "company number not shown")
            # Mail: the administrator sets IMAP/POP3/SMTP once; the test logs in with a real mailbox
            await ad.click("[data-itab=mail]")
            expect(await ad.locator("[data-group=mail] .setting").count() >= 10, "mail server settings missing")
            if http("GET", "/api/mail/account", token=await ad.evaluate("localStorage.getItem('aws_token')")).get("enabled"):
                await ad.fill("input[name=mail-test-email]", "boris@company.test")
                await ad.fill("input[name=mail-test-password]", "boris-mail-2")
                await ad.click("[data-test=mail]")
                await ad.wait_for_selector("[data-group=mail] .banner.ok", timeout=12000)
            # Sync: every system with real time + fallback check
            await ad.click("[data-itab=sync]")
            await ad.wait_for_selector("table.sync tr[data-sync=telegram]", timeout=5000)
            expect(await ad.locator("table.sync tbody tr").count() == 5, "sync table must list Zammad, Asterisk, Telegram, WhatsApp, Mail")
            await ad.click("[data-poll=telegram]")
            await ad.wait_for_function("document.querySelector('tr[data-sync=telegram] td:nth-child(4)').textContent.includes('ms')", timeout=8000)
            expect(await ad.locator("tr[data-sync=telegram] .sdot.ok").count() == 1, "Telegram not OK in the sync table")
        await step("Integrations: tabs; Zammad, AMI, Telegram bot, WhatsApp number and mail server tests; sync panel with a manual check", integrations())

        async def save_setting():
            await ad.click("[data-itab=telephony]")
            box = ad.locator(".setting:has-text('Wrap-up'), .setting:has-text('Постобработка')").locator("input")
            await box.fill("20")
            await ad.wait_for_selector(".savebar.show")
            await ad.click(".savebar button.primary")
            await ad.wait_for_timeout(900)
            expect(await ad.locator(".savebar.show").count() == 0, "save bar still visible")
            await ad.reload()
            await ad.wait_for_selector(".sidebar")
            await nav(ad, "integrations")
            await ad.click("[data-itab=telephony]")
            expect(await box.input_value() == "20", "setting not persisted")
            await box.fill("0")
            await ad.click(".savebar button.primary")
            await ad.wait_for_timeout(700)
        await step("Integrations: change a setting, it is saved and applied", save_setting())

        async def settings_page():
            await nav(ad, "settings")
            expect(await ad.locator(".settings-group").count() == 4, "settings groups missing (tickets, statistics, general, privacy)")
            expect(await ad.locator(".setting select").count() >= 2, "choice settings missing")
        await step("Settings page", settings_page())

        async def ticket_types():
            await nav(ad, "types")
            await ad.click(".admin h2 button.primary")
            await ad.wait_for_selector(".modal.wide")
            row = ad.locator(".modal.wide .row input")
            await row.nth(0).fill("Complaint")
            await row.nth(1).fill("complaint")
            await ad.click(".modal.wide button:has-text('+')")
            await ad.locator(".field-row input").nth(0).fill("severity")
            await ad.locator(".field-row input").nth(1).fill("Severity")
            await ad.click(".modal.wide .footer button.primary")
            await ad.wait_for_timeout(800)
            expect("Complaint" in await ad.inner_text(".admin"), "type not created")
            ad.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await ad.click(".item:has-text('Complaint') button.danger")
            await ad.wait_for_timeout(800)
            expect("Complaint" not in await ad.inner_text(".admin"), "type not deleted")
        await step("Ticket types: create and delete", ticket_types())

        async def system_status():
            await nav(ad, "system")
            await ad.wait_for_selector(".cards .card")
            expect(await ad.locator(".card.good").count() == 2, "Zammad/AMI not shown as connected")
            expect(await ad.locator("section:not(.sys-enc) > .sys-int .sys-it").count() == 5, "integration health block missing")
            # v3.17: the Encryption block names every connection that would travel as plain text (the demo's Zammad is http)
            enc = await ad.inner_text("[data-sys=encryption]")
            expect(await ad.locator("[data-sys=encryption] [data-enc=zammad_url]").count() == 1 and "AES" in enc, f"encryption block: {enc}")
        await step("System status page", system_status())

        async def ticket_groups():
            await nav(ad, "groups")
            await ad.wait_for_selector(".zg-card[data-group='IT Support']", timeout=6000)
            expect(await ad.locator(".zg-card").count() >= 5, "groups from Zammad")
            await ad.fill("input[name=zg-new]", "Field Service")
            await ad.click("[data-zg=add]")
            await ad.wait_for_selector(".zg-card[data-group='Field Service']", timeout=5000)
            await ad.click(".zg-card[data-group='Field Service'] input[data-agent='10']")
            await ad.wait_for_selector(".zg-card[data-group='Field Service'] .zg-person.on", timeout=5000)
            await ad.click(".zg-card[data-group='Field Service'] [data-zg=toggle]")
            await ad.wait_for_selector(".zg-card.off[data-group='Field Service']", timeout=5000)
            await ad.click(".zg-card[data-group='Field Service'] [data-zg=toggle]")
            await ad.wait_for_selector(".zg-card:not(.off)[data-group='Field Service']", timeout=5000)
            groups = [g["name"] for g in http("GET", "/api/tk/meta", token=anna_tok)["groups"]]
            expect("Field Service" in groups, f"Anna does not see the new group: {groups}")
        await step("Ticket groups: create in Zammad, give an agent access, switch off / on", ticket_groups())

        async def call_routing():
            await nav(ad, "routing")
            await ad.wait_for_selector(".rt-queue[data-queue='400'] .rt-table tbody tr", timeout=6000)
            rows = [r.lower() for r in await ad.locator(".rt-queue[data-queue='400'] .rt-table tbody tr").all_inner_texts()]
            expect(any("level 1" in r for r in rows) and any("level 2" in r for r in rows), f"levels: {rows}")
            expect("next call goes to" in (await ad.inner_text(".rt-queue[data-queue='400'] .rt-next")).lower(), "next call")
            members = http("GET", "/api/admin/routing", token=http("POST", "/api/auth/login", {"username": "admin", "password": "admin"})["token"])["queues"][0]["members"]
            pen = {m["interface"]: m["penalty"] for m in members}
            expect(pen.get("Local/101@from-queue/n") == 0 and pen.get("Local/102@from-queue/n") == 1, f"penalties in the PBX: {pen}")
            await ad.fill("input[name=penalty_level2]", "4")
            await ad.click("[data-rt=save]")
            for _ in range(20):
                await ad.wait_for_timeout(300)
                if http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["penalty"] == 4:
                    break
            expect(http("GET", "/demo/pbx")["400"]["Local/102@from-queue/n"]["penalty"] == 4, "Level 2 penalty not set in the PBX")
            await ad.fill("input[name=penalty_level2]", "1")
            await ad.click("[data-rt=save]")
            await ad.wait_for_timeout(800)
        await step("Call routing page: levels, penalties, who gets the next call; penalties are saved", call_routing())

        async def operator_no_admin_api():
            r = urllib.request.Request(BASE + "/api/admin/users", headers={"Authorization": "Bearer " + await pg.evaluate("localStorage.getItem('aws_token')")})
            try:
                urllib.request.urlopen(r)
                raise AssertionError("operator could open admin API")
            except urllib.error.HTTPError as exc:
                expect(exc.code in (401, 403), f"code {exc.code}")
        await step("Operators have no access to the admin API", operator_no_admin_api())

        if SHOTS:
            await nav(ad, "sup")
            await ad.screenshot(path=f"{SHOTS}/e2e_admin.png", full_page=True)

        async def health():
            h = http("GET", "/api/health")
            expect(h["status"] == "ok" and h["database"] and h["ami_connected"], f"health: {h}")
        await step("Health endpoint", health())

        # ---------------------------------------------------------------- v3.14 interface settings, layouts, call → ticket
        async def interface_settings():
            await pg.click(".side-foot .settings-btn")
            sec = pg.locator("[data-sec=interface]")
            await sec.wait_for()
            for sel in ("[data-style-opt=classic]", "[data-style-opt=studio]", "[data-dash-opt=focus]", "[data-dash-opt=table]",
                        "[data-theme-opt=light]", "input[name=motion]", "input[name=compact]", "[data-preset=calls]"):
                expect(await sec.locator(sel).count() == 1, f"{sel} not in the Interface section")
            expect(await pg.locator("[data-sec=workspace], [data-sec=appearance]").count() == 0, "old separate sections still there")
        await step("My settings → Interface: style, panel, home screen layout, theme, motion and blocks in one section", interface_settings())

        async def dash_layouts():
            async def choose(d):
                await pg.click(".side-foot .settings-btn")
                await pg.click(f"[data-dash-opt={d}]")
                await pg.wait_for_selector(f"[data-dash-opt={d}].on")
                await nav(pg, "work")
            # Focus: the oldest new request; Skip shows the next; Start makes it the active task; Postpone gives it back
            await choose("focus")
            await pg.wait_for_selector("[data-dash=focus] [data-focus=next] .dl-big")
            first = await pg.inner_text("[data-focus=next] .dl-big")
            if await pg.locator("[data-act=focus-skip]").count():
                await pg.click("[data-act=focus-skip]")
                await pg.wait_for_function(f"document.querySelector('[data-focus=next] .dl-big').innerText !== {json.dumps(first)}", timeout=3000)
            nxt = await pg.inner_text("[data-focus=next] .dl-big")
            await pg.click("[data-act=focus-start]")
            await pg.wait_for_selector("[data-focus=active] .dl-big", timeout=8000)
            expect(nxt in await pg.inner_text("[data-focus=active]"), "the started request is the active task")
            expect(pbx(), "calls must be paused while a blocking task is active")
            await pg.click("[data-focus=active] .dl-acts .btn:has-text('Postpone'), [data-focus=active] .dl-acts .btn:nth-child(3)")
            await pg.wait_for_selector("[data-focus=next]", timeout=8000)
            # Board: the columns hold the same work
            await choose("board")
            await pg.wait_for_selector("[data-dash=board] [data-col=new] .dl-card")
            n_board = await pg.locator("[data-col=new] .dl-card").count()
            # Inbox: filters by kind and channel
            await choose("inbox")
            await pg.wait_for_selector("[data-dash=inbox] .dl-row[data-kind]")
            await pg.click("[data-dash=inbox] [data-kind=new].dl-chip")
            kinds = await pg.eval_on_selector_all("[data-dash=inbox] .dl-box .dl-row[data-kind]", "els => els.map(e => e.dataset.kind)")
            expect(kinds and set(kinds) == {"new"} and len(kinds) == n_board, f"inbox «new» filter: {kinds} vs board {n_board}")
            if await pg.locator("[data-dash=inbox] [data-ch=email]").count():
                await pg.click("[data-dash=inbox] [data-ch=email]")
                expect(await pg.locator("[data-dash=inbox] .dl-box .dl-row[data-kind] .src-email").count() == await pg.locator("[data-dash=inbox] .dl-box .dl-row[data-kind]").count(), "channel filter")
            # Table: one row per ticket, the «mine» filter
            await choose("table")
            await pg.wait_for_selector("[data-dash=table] tbody tr[data-kind]")
            await pg.click("[data-tkind=mine]")
            kinds = await pg.eval_on_selector_all("[data-dash=table] tbody tr[data-kind]", "els => els.map(e => e.dataset.kind)")
            expect(set(kinds) <= {"mine"}, f"table «mine» filter: {kinds}")
            # saved to the account; back to the blocks
            expect(http("GET", "/api/agents/me/preferences", token=anna_tok)["dash"] == "table", "layout not saved")
            await choose("standard")
            await pg.wait_for_selector(".dash .widget[data-w=new]")
        await step("My workplace layouts: Focus (next, skip, start, postpone), Board, Inbox (filters), Table (filters); saved; Blocks back", dash_layouts())

        async def call_to_ticket():
            await nav(pg, "work")
            await pg.wait_for_selector(".phone-btn.p-registered", timeout=6000)
            await pg.wait_for_selector(".phone-btn.c-idle", timeout=30000)
            if await pg.locator(".ph-card").is_visible():
                await pg.click("[data-act=minimize]")
            http("POST", "/demo/phone/ring?ext=101&number=%2B37491123456")
            await pg.wait_for_selector(".ph-strip.cs-ringing >> text=Aram Grigoryan", timeout=6000)
            expect(await pg.locator("[data-act=strip-ticket]").count() == 0, "no «New ticket» before the call is answered")
            await pg.click("[data-act=strip-answer]")
            await pg.wait_for_selector(".ph-strip.cs-active", timeout=4000)
            await pg.click("[data-act=strip-ticket]")
            # a ticket draft opens with the number (a link) and the caller found in Zammad
            await pg.wait_for_selector(".dr-caller", timeout=6000)
            expect("+37491123456" in await pg.inner_text(".dr-caller"), "caller number missing in the draft")
            await pg.wait_for_selector(".nw-cust >> text=Aram Grigoryan", timeout=4000)
            # the number opens the phone with the number typed — no second call
            await pg.click("[data-act=caller-prefill]")
            await pg.wait_for_selector(".ph-card .ph-num input", timeout=3000)
            expect(await pg.input_value(".ph-card .ph-num input") == "+37491123456", "number not typed in the phone")
            expect(await pg.locator(".ph-strip.cs-active").count() == 1 and await pg.locator(".ph-strip .ph-smore").count() == 0, "a second call was started")
            await pg.click("[data-act=minimize]")
            # create: the ticket gets the call details
            await pg.fill("[name=dr-title]", "Router blinks red")
            await pg.fill("[name=dr-body]", "Customer called about the router")
            await pg.click("[data-act=create]")
            await pg.wait_for_selector(".tk-art >> text=+37491123456", timeout=8000)
            await pg.click("[data-act=strip-hangup]")
            await pg.wait_for_selector(".ph-strip", state="detached", timeout=4000)
        await step("Call → «New ticket» in the phone: draft with the caller and the number as a link that types it in the phone; ticket gets the call", call_to_ticket())

        # ---------------------------------------------------------------- v3.12 interface style & account picture
        async def studio_style():
            sp = await new_page(1440, 950)
            await sp.emulate_media(reduced_motion="reduce")
            await login(sp, "anna", style="classic")
            rail = await sp.eval_on_selector_all(".side-nav button, .side-foot button", "els => els.map(e => e.dataset.nav || e.classList[0] || e.getAttribute('aria-label'))")
            expect(await sp.locator(".topbar .me").is_visible(), "classic: the account is in the top bar")
            expect(await sp.locator(".subnav").count() == 0, "classic has no section panel")
            await sp.click(".side-foot .settings-btn")
            await sp.wait_for_selector("[data-style-opt=studio]")
            await sp.click("[data-style-opt=studio]")
            await sp.wait_for_selector(".subnav .sn-me")
            expect(await sp.evaluate("document.documentElement.dataset.style") == "studio", "style attribute")
            rail2 = await sp.eval_on_selector_all(".side-nav button, .side-foot button", "els => els.map(e => e.dataset.nav || e.classList[0] || e.getAttribute('aria-label'))")
            expect(rail == rail2, f"the icons of the rail must not move: {rail} vs {rail2}")
            # the account is shown in ONE place only: bottom left
            expect(not await sp.locator(".topbar .me").is_visible(), "studio: the top bar must not repeat the account")
            expect("Anna" in await sp.inner_text(".subnav .sn-me"), "account card bottom left")
            await nav(sp, "work")
            expect("Anna" in await sp.inner_text(".st-hello h1"), "greeting with the first name")
            expect(await sp.locator(".subnav [data-sn=w-new] .sn-count").inner_text() == str(len(await sp.query_selector_all(".widget[data-w=new] .item"))),
                   "section counter = number of new requests")
            await sp.click(".subnav [data-sn=w-new]")
            expect(await sp.locator(".widget[data-w=new] .item .it-ico").first.is_visible(), "requests are cards with a channel icon")
            kp = await sp.eval_on_selector(".kpis", "e => getComputedStyle(e).columnGap")
            expect(kp == "12px", f"number cards are separate: gap {kp}")
            # tickets: Zammad overviews live in the section panel
            await nav(sp, "tickets")
            await sp.wait_for_selector(".subnav .tkn [data-ov]")
            await sp.click(".subnav .tkn [data-ov]:nth-child(2)")
            await sp.wait_for_selector(".tko tbody tr")
            expect(await sp.locator(".tk2 > .tkn").count() == 0, "the overview list moved out of the page")
            sw = await sp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            expect(sw <= 1, f"no sideways scroll ({sw}px)")
            # messenger: channels with counters
            await nav(sp, "chat")
            expect(await sp.locator(".subnav [data-sn=chat].on").count() == 1, "communication panel marks Messages")
            # saved to the account: survives a reload and another browser
            await sp.reload()
            await sp.wait_for_selector(".subnav .sn-me")
            other = await new_page(1440, 950)
            await login(other, "anna", style="studio")
            expect(await other.locator(".subnav").count() == 1, "studio follows the user to another browser")
            await other.close()
            # small screen: no section panel, the account returns to the top bar
            mob = await new_page(390, 844)
            await login(mob, "anna", style="studio")
            expect(await mob.locator(".subnav").count() == 0 and await mob.locator(".topbar .me").is_visible(), "phone layout")
            sw = await mob.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            expect(sw <= 1, f"phone: no sideways scroll ({sw}px)")
            await mob.close()
            if SHOTS:
                await nav(sp, "work")
                await sp.screenshot(path=f"{SHOTS}/e2e_studio.png")
            # back to Classic
            await sp.click(".side-foot .settings-btn")
            await sp.click("[data-style-opt=classic]")
            await sp.wait_for_timeout(500)
            expect(await sp.locator(".subnav").count() == 0 and await sp.locator(".topbar .me").is_visible(), "classic restored")
            await sp.close()
        def classic_again(user="anna"):
            """Leave the user in the style of this run even if a check above failed."""
            tok = http("POST", "/api/auth/login", {"username": user, "password": "pw"})["token"]
            prefs = http("GET", "/api/agents/me/preferences", token=tok)
            if prefs.get("style") != STYLE:
                http("PUT", "/api/agents/me/preferences", {**prefs, "style": STYLE}, token=tok)

        async def studio_style_safe():
            try:
                await studio_style()
            finally:
                classic_again()
        await step("Interface style: Studio keeps the rail icons, account only bottom-left, overviews in the panel, saved to the account; Classic back", studio_style_safe())

        async def panel_modes():
            """v3.13: Studio section panel docked next to the icons (« hides it) or as a pop-up (setting)."""
            pp = await new_page(1366, 768)
            await pp.emulate_media(reduced_motion="reduce")
            await login(pp, "anna", style="studio")
            await nav(pp, "work")
            await pp.wait_for_selector(".subnav:not(.popup) .sn-me")
            # « hides the docked panel: it becomes a pop-up, the account goes to the top bar (still one place)
            await pp.click("[data-panel=hide]")
            await pp.wait_for_selector(".subnav.popup", state="attached")
            expect(not await pp.locator(".subnav").is_visible(), "pop-up closed after hiding")
            expect(await pp.locator(".topbar .me").is_visible() and await pp.locator(".sn-me").count() == 0, "account in one place (top bar)")
            # the active icon opens the sections over the page; a section closes it and scrolls to its block
            await nav(pp, "work")
            await pp.wait_for_selector(".subnav.popup.open")
            await pp.click(".subnav [data-sn=w-new]")
            await pp.wait_for_selector(".subnav.popup:not(.open)", state="attached")
            # the top-bar button opens it too; Esc and a click outside close it
            await pp.click(".topbar [data-panel=open]")
            await pp.wait_for_selector(".subnav.popup.open")
            await pp.keyboard.press("Escape")
            await pp.wait_for_selector(".subnav.popup:not(.open)", state="attached")
            await pp.click(".topbar [data-panel=open]")
            await pp.click(".sn-dim", position={"x": 900, "y": 400})
            await pp.wait_for_selector(".subnav.popup:not(.open)", state="attached")
            # tickets in pop-up mode: the overview list stays on the page
            await nav(pp, "tickets")
            await pp.wait_for_selector(".tk2 > .tkn [data-ov]")
            sw = await pp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            expect(sw <= 1, f"no sideways scroll ({sw}px)")
            # saved to the account: another browser opens in pop-up mode
            other = await new_page(1366, 768)
            await login(other, "anna", style="studio")
            expect(await other.locator(".subnav.popup").count() == 1, "pop-up mode follows the user")
            await other.close()
            # the setting, then pin back next to the icons
            await pp.click(".side-foot .settings-btn")
            await pp.wait_for_selector("[data-panel-opt=popup].on")
            await pp.click("[data-panel-opt=docked]")
            await pp.wait_for_selector(".subnav:not(.popup) .sn-me")
            await pp.click("[data-panel=hide]")
            await pp.click(".topbar [data-panel=open]")
            await pp.click(".subnav [data-panel=pin]")
            await pp.wait_for_selector(".subnav:not(.popup) .sn-me")
            await pp.close()

        async def panel_modes_safe():
            try:
                await panel_modes()
            finally:
                tok = http("POST", "/api/auth/login", {"username": "anna", "password": "pw"})["token"]
                prefs = http("GET", "/api/agents/me/preferences", token=tok)
                http("PUT", "/api/agents/me/preferences", {**prefs, "style": STYLE, "panel": "docked"}, token=tok)
        await step("Studio section panel: next to the icons (« hides it) or pop-up from the active icon / top-bar button; saved; pin back", panel_modes_safe())

        async def flow_style():
            # v3.16: the «Flow» style — sections as pills at the top with a sliding active pill, a floating toolbar
            fp = await new_page(1366, 768)
            await login(fp, "boss", style=STYLE)
            await fp.click(".side-foot .settings-btn")
            await fp.click("[data-style-opt=flow]")
            await fp.wait_for_function("document.documentElement.dataset.style === 'flow'")
            expect(http("GET", "/api/agents/me/preferences", token=http("POST", "/api/auth/login", {"username": "boss", "password": "pw"})["token"])["style"] == "flow", "saved to the account")
            ind = """() => { const n = document.querySelector('.side-nav'), on = n.querySelector('button.on'), cs = getComputedStyle(n);
                return { x: parseFloat(cs.getPropertyValue('--ind-x')), w: parseFloat(cs.getPropertyValue('--ind-w')), o: cs.getPropertyValue('--ind-o').trim(),
                         bx: on ? on.offsetLeft : -1, bw: on ? on.offsetWidth : -1, labels: [...n.querySelectorAll('button .lbl')].every(l => getComputedStyle(l).position === 'static') }; }"""
            for key in ("sup", "overview", "chat"):
                await nav(fp, key)
                await fp.wait_for_timeout(300)
                r = await fp.evaluate(ind)
                expect(r["o"] == "1" and abs(r["x"] - r["bx"]) <= 1 and abs(r["w"] - r["bw"]) <= 1 and r["labels"], f"{key}: the active pill is not on the section ({r})")
            tb = """() => { const f = document.querySelector('.side-foot'), r = f.getBoundingClientRect(), o = document.querySelector('.side-foot .logout').getBoundingClientRect();
                const hit = document.elementFromPoint(o.left + o.width / 2, o.top + o.height / 2);
                const m = document.querySelector('main').getBoundingClientRect();
                return { pos: getComputedStyle(f).position, top: r.top, bottom: r.bottom, left: r.left, right: r.right, vh: innerHeight, vw: innerWidth,
                         clickable: !!(hit && hit.closest('.logout')), mainLeft: m.left + parseFloat(getComputedStyle(document.querySelector('main')).paddingLeft) }; }"""
            r = await fp.evaluate(tb)
            expect(r["pos"] == "fixed" and r["top"] >= 0 and r["bottom"] <= r["vh"] and r["clickable"], f"desktop toolbar: {r}")
            expect(r["right"] < r["mainLeft"], f"the toolbar covers the page: {r}")
            await fp.evaluate("window.scrollTo(0, 2000)")
            r2 = await fp.evaluate(tb)
            expect(abs(r2["top"] - r["top"]) <= 1, "the toolbar stays in place when the page scrolls")
            sw = await fp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            expect(sw <= 1, f"sideways scroll {sw}px")
            # v3.17: the top menu is in the middle; the phone docked as a side panel never covers it
            navbox = """() => { const n = document.querySelector('.side-nav').getBoundingClientRect(), c = document.querySelector('.ph-card');
                const k = c ? c.getBoundingClientRect() : null;
                const hidden = [...document.querySelectorAll('.side-nav button')].filter(b => { const r = b.getBoundingClientRect();
                    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return !(hit && b.contains(hit)); }).length;
                const tr = document.querySelector('.top-right'), trr = tr && getComputedStyle(tr).position === 'fixed' ? tr.getBoundingClientRect().right : 0;
                return { left: n.left, right: n.right, mid: (n.left + n.right) / 2, vw: innerWidth, card: k ? k.left : null, hidden, trRight: trr }; }"""
            await fp.set_viewport_size({"width": 1920, "height": 1080})
            await fp.wait_for_timeout(500)
            r = await fp.evaluate(navbox)
            expect(abs(r["mid"] - r["vw"] / 2) <= 24 and r["hidden"] == 0, f"the top menu is not in the middle ({r})")
            await fp.click(".side-foot .settings-btn")
            await fp.wait_for_selector("[data-phone-settings]", timeout=4000)
            await fp.click("[data-layout=docked]")
            await fp.keyboard.press("Escape")
            if not await fp.locator(".ph-card.lay-docked").is_visible():
                await fp.click("[data-act=phone]")
            await fp.wait_for_selector(".ph-card.lay-docked", timeout=3000)
            for w, h in ((1920, 1080), (1440, 900), (1366, 768), (1100, 800), (960, 700)):
                await fp.set_viewport_size({"width": w, "height": h})
                await fp.wait_for_timeout(450)
                r = await fp.evaluate(navbox)
                expect(r["card"] is not None and r["right"] <= r["card"] + 1 and r["hidden"] == 0, f"{w}px: the docked phone covers the top menu ({r})")
                expect(r["trRight"] <= r["card"] + 1, f"{w}px: the docked phone covers the bell / account ({r})")  # v3.19
            await fp.click(".side-foot .settings-btn")
            await fp.wait_for_selector("[data-phone-settings]", timeout=4000)
            await fp.click("[data-layout=classic]")
            await fp.keyboard.press("Escape")
            await fp.set_viewport_size({"width": 1366, "height": 768})
            await nav(fp, "chat")  # back from My settings to the section the checks above ended on
            await fp.wait_for_timeout(300)
            await fp.set_viewport_size({"width": 390, "height": 844})
            await fp.wait_for_timeout(500)
            r = await fp.evaluate(tb)
            expect(r["pos"] == "fixed" and r["bottom"] <= r["vh"] and r["vh"] - r["bottom"] < 40 and r["clickable"], f"phone: the toolbar is at the bottom ({r})")
            top = await fp.evaluate("""() => ['.topbar .me .avatar', '.topbar .bell'].map(s => { const e = document.querySelector(s), b = e.getBoundingClientRect();
                const hit = document.elementFromPoint(b.left + b.width / 2, b.top + b.height / 2); return [Math.round(b.top), !!(hit && (hit === e || e.contains(hit)))]; })""")
            expect(all(t < 70 and vis for t, vis in top), f"phone: bell and account picture next to the logo, not covered ({top})")
            await nav(fp, "overview")
            r = await fp.evaluate(ind)
            expect(abs(r["x"] - r["bx"]) <= 1, f"phone: active pill ({r})")
            lf = await fp.evaluate("(() => { const e = document.querySelector('.ov .level-filter'); return e ? [e.scrollHeight <= e.clientHeight + 2, getComputedStyle(e).flexWrap] : [true, 'nowrap']; })()")
            expect(lf[0] and lf[1] == "nowrap", f"phone: segmented controls stay one line and scroll ({lf})")
            sw = await fp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            expect(sw <= 1, f"phone: sideways scroll {sw}px")
            if SHOTS:
                await fp.set_viewport_size({"width": 1440, "height": 900})
                await nav(fp, "overview")
                await fp.wait_for_timeout(900)
                await fp.screenshot(path=f"{SHOTS}/e2e_flow.png")
            await fp.close()

        async def flow_style_safe():
            try:
                await flow_style()
            finally:
                classic_again("boss")
        await step("Interface style Flow: section pills with a sliding active pill (menu in the middle, never under the docked phone), floating toolbar (left; bottom on a phone) never covers the page, saved", flow_style_safe())

        async def flow_rail():
            # v3.19 Flow: the tools on a rail at the left (in the middle of the screen), the menu on top, bell / LIVE /
            # account at the right of the header; up to 5 sections of the top menu pinned to the rail (they stay on top)
            rp = await new_page(1440, 900)
            await login(rp, "anna", style="flow")
            tok = await rp.evaluate("localStorage.getItem('aws_token')")
            prefs = http("GET", "/api/agents/me/preferences", token=tok)
            http("PUT", "/api/agents/me/preferences", {**prefs, "pins": []}, token=tok)
            await rp.reload(); await rp.wait_for_selector(".side-foot.rail"); await rp.wait_for_timeout(700)
            geo = await rp.evaluate("""() => { const f = document.querySelector('.side-foot.rail').getBoundingClientRect(),
                    tr = document.querySelector('.top-right').getBoundingClientRect(), nav = document.querySelector('.side-nav').getBoundingClientRect();
                const vis = (sel) => { const e = document.querySelector(sel); if (!e) return false; const b = e.getBoundingClientRect();
                    const hit = document.elementFromPoint(b.left + b.width / 2, b.top + b.height / 2); return !!(hit && (hit === e || e.contains(hit))); };
                return { mid: (f.top + f.bottom) / 2, vh: innerHeight, top: f.top, bottom: f.bottom, trTop: tr.top, trRight: innerWidth - tr.right,
                         navTop: nav.top, bell: vis('.top-right .bell'), me: vis('.top-right .me .avatar'), ready: vis('[data-rail=ready]'),
                         brk: vis('[data-rail=break]'), phone: vis('#ph-rail-slot [data-act=phone]'), dnd: vis('#ph-rail-slot [data-act=dnd]'),
                         topReady: document.querySelectorAll('.topbar button.go').length, topBar: document.querySelectorAll('#ph-bar-slot .ph-bar').length }; }""")
            expect(geo["top"] > 60 and geo["bottom"] < geo["vh"] and abs(geo["mid"] - geo["vh"] / 2) < 80, f"the rail is not in the middle of the left edge ({geo})")
            expect(geo["trTop"] < 30 and geo["trRight"] < 40 and geo["bell"] and geo["me"], f"bell / account not at the right of the header ({geo})")
            expect(geo["ready"] and geo["brk"] and geo["phone"] and geo["dnd"] and geo["topReady"] == 0 and geo["topBar"] == 0,
                   f"Ready / Break / phone must be on the rail, not in the top bar ({geo})")
            # status from the rail
            await rp.click("[data-rail=break]")
            await rp.wait_for_selector("[data-rail=break].on", timeout=4000)
            expect(http("GET", "/api/agents/me/state", token=tok)["manual_state"] == "break", "Break on the rail did not reach the server")
            await rp.click("[data-rail=ready]")
            await rp.wait_for_selector("[data-rail=ready].on", timeout=4000)
            # the dialer opens next to the rail and closes with Escape
            await rp.click("[data-act=rail-dial]")
            await rp.wait_for_selector(".ph-bar.rail [data-tb]", timeout=2000)
            expect(await rp.evaluate("document.activeElement && document.activeElement.matches('[data-tb]')"), "the dialer input is not focused")
            await rp.keyboard.press("Escape")
            await rp.wait_for_selector(".ph-bar.rail [data-tb]", state="detached", timeout=2000)
            # pin sections: at most 5, they stay in the top menu; a section the person does not have (admin) takes no place
            http("PUT", "/api/agents/me/preferences", {**http("GET", "/api/agents/me/preferences", token=tok), "pins": ["admin"]}, token=tok)
            await rp.reload(); await rp.wait_for_selector(".side-foot.rail"); await rp.wait_for_timeout(600)
            expect(await rp.locator("[data-pin]").count() == 0, "a section the operator does not have is shown on the rail")
            await rp.click("[data-rail=pins]")
            await rp.wait_for_selector(".pin-pop")
            for k in ("tickets", "chat", "mail", "whatsapp", "telegram"):
                await rp.click(f"[data-pin-opt={k}]")
                await rp.wait_for_selector(f"[data-pin={k}]", timeout=2000)
            expect(await rp.locator(".pin-row:not(.on):disabled").count() == await rp.locator(".pin-row:not(.on)").count() > 0, "a 6th section can be pinned")
            expect("5" in await rp.inner_text(".pin-count"), "counter is not 5 of 5")
            await rp.keyboard.press("Escape")
            await rp.wait_for_selector(".pin-pop", state="detached", timeout=2000)
            order = await rp.eval_on_selector_all("[data-pin]", "els => els.map(e => e.dataset.pin)")
            expect(order == ["tickets", "chat", "mail", "whatsapp", "telegram"], f"pinned order {order}")
            for k in order:
                expect(await rp.locator(f".side-nav [data-nav={k}]").is_visible(), f"{k} disappeared from the top menu")
            await rp.click("[data-pin=tickets]")
            await rp.wait_for_selector(".side-nav [data-nav=tickets].on", timeout=4000)
            expect(await rp.locator("[data-pin=tickets].on").count() == 1, "the pinned section is not marked as open")
            saved = http("GET", "/api/agents/me/preferences", token=tok)["pins"]
            expect(saved == order, f"not saved to the account: {saved}")
            try:
                http("PUT", "/api/agents/me/preferences", {**http("GET", "/api/agents/me/preferences", token=tok), "pins": order + ["work"]}, token=tok)
                code = 200
            except urllib.error.HTTPError as e:
                code = e.code
            expect(code == 422, f"the server took a 6th pin ({code})")
            # another computer: the same pins; unpin one and a section can be added again
            rp2 = await new_page(1440, 900)
            await login(rp2, "anna", style="flow")
            expect(await rp2.eval_on_selector_all("[data-pin]", "els => els.map(e => e.dataset.pin)") == order, "pins not the same on another computer")
            await rp2.click("[data-rail=pins]")
            await rp2.click("[data-pin-opt=mail]")
            await rp2.wait_for_selector("[data-pin=mail]", state="detached", timeout=2000)
            expect(await rp2.locator(".pin-row:not(.on):disabled").count() == 0, "after unpinning, sections can be added again")
            await rp2.mouse.click(900, 500)
            await rp2.wait_for_selector(".pin-pop", state="detached", timeout=2000)
            # a phone: no rail, the bottom toolbar and the top-bar phone as before
            await rp2.set_viewport_size({"width": 390, "height": 844})
            await rp2.wait_for_timeout(600)
            expect(await rp2.locator(".side-foot.rail").count() == 0 and await rp2.locator("#ph-bar-slot .ph-bar").count() == 1, "phone: the rail must give way to the phone layout")
            await rp2.set_viewport_size({"width": 1440, "height": 900})
            await rp2.wait_for_selector("#ph-rail-slot .ph-bar.rail", timeout=3000)
            if SHOTS:
                await rp2.screenshot(path=f"{SHOTS}/e2e_flow_rail.png")
            await rp.close(); await rp2.close()

        async def flow_rail_safe():
            try:
                await flow_rail()
            finally:
                tok = http("POST", "/api/auth/login", {"username": "anna", "password": "pw"})["token"]
                prefs = http("GET", "/api/agents/me/preferences", token=tok)
                http("PUT", "/api/agents/me/preferences", {**prefs, "style": STYLE, "pins": []}, token=tok)
                try:
                    http("POST", "/api/agents/me/ready", token=tok)
                except urllib.error.HTTPError:
                    pass  # e.g. a blocking ticket reached Anna meanwhile
        await step("Flow tool rail: status, phone and customize at the left in the middle, bell / account in the header, up to 5 sections pinned (they stay in the top menu), saved to the account", flow_rail_safe())

        async def account_picture():
            import tempfile
            ap = await new_page(1440, 950)
            await login(ap, "anna", style="classic")
            expect((await ap.inner_text(".topbar .me .avatar")).strip() == "AP", "default: initials of the first and last name")
            await ap.click(".side-foot .settings-btn")
            await ap.wait_for_selector("[data-av=upload]")
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
                f.write(png_bytes())
            async with ap.expect_file_chooser() as fc:
                await ap.click("[data-av=upload]")
            await (await fc.value).set_files(f.name)
            await ap.wait_for_selector(".topbar .me .avatar img")
            size = await ap.eval_on_selector(".topbar .me .avatar img", "i => new Promise(r => i.complete ? r([i.naturalWidth, i.naturalHeight]) : i.onload = () => r([i.naturalWidth, i.naturalHeight]))")
            expect(size == [256, 256], f"the browser cuts a 256x256 square: {size}")
            await ap.click("[data-av=initials]")
            await ap.wait_for_timeout(400)
            expect((await ap.inner_text(".topbar .me .avatar")).strip() == "AP" and await ap.locator(".topbar .me .avatar img").count() == 0, "initials chosen")
            await ap.click("[data-av=photo]")
            await ap.wait_for_selector(".topbar .me .avatar img")
            # a colleague sees the photo in the messenger
            bp = await new_page(1440, 950)
            await login(bp, "boris")
            await nav(bp, "chat")
            await bp.fill("input[name=chat-search]", "Anna")
            await bp.wait_for_selector(".chat-items .av img", timeout=6000)
            await bp.close()
            # the administrator can remove an unsuitable photo
            adp = await new_page(1440, 950)
            await login(adp, "admin", "admin", wait=".sidebar")
            await nav(adp, "users")
            adp.on("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await adp.wait_for_selector("[data-rm-photo]")
            await adp.click("[data-rm-photo]")
            await adp.wait_for_timeout(800)
            expect(await adp.locator("[data-rm-photo]").count() == 0, "admin removed the photo")
            await adp.close()
            await ap.wait_for_function("!document.querySelector('.topbar .me .avatar img')", timeout=8000)
            expect(await ap.locator("[data-av=delete]").count() == 0, "no photo left to delete")
            # upload again and delete it yourself
            async with ap.expect_file_chooser() as fc:
                await ap.click("[data-av=upload]")
            await (await fc.value).set_files(f.name)
            await ap.wait_for_selector("[data-av=delete]")
            await ap.click("[data-av=delete]")
            await ap.wait_for_function("!document.querySelector('.topbar .me .avatar img')", timeout=8000)
            await ap.close()
        await step("Account picture: photo (cut to a square) or initials, colleagues see it, admin can remove it, user can delete it", account_picture())

        async def responsive():
            # every main screen fills the whole width and never scrolls sideways, from a small phone to a 4K monitor
            check = """() => { const vw = document.documentElement.clientWidth, m = document.querySelector('main');
                return { h: document.documentElement.scrollWidth - vw, gap: m ? Math.round(vw - m.getBoundingClientRect().right) : 0 }; }"""
            problems = []
            for w, h in ((360, 740), (768, 1024), (1280, 800), (1920, 1080), (2560, 1440)):
                rp = await new_page(w, h)
                await rp.emulate_media(reduced_motion="reduce")
                await login(rp, "boss")
                for idx, name in ((None, "workplace"), ("sup", "manager panel"), ("overview", "overview"), ("shifts", "shifts"),
                                  ("recordings", "recordings"), ("log", "log"), ("chat", "messages")):
                    if idx is not None:
                        await nav(rp, idx)
                        await rp.wait_for_timeout(900)
                    r = await rp.evaluate(check)
                    # Studio frames the page with a 10 px margin on wide screens (by design)
                    if r["h"] > 1 or r["gap"] > (12 if STYLE == "studio" and w > 900 else 2):
                        problems.append(f"{w}px {name}: sideways scroll {r['h']}px, empty right gap {r['gap']}px")
                await rp.close()
            expect(not problems, "; ".join(problems))
        # ---------------------------------------------------------------- v3.15 manager tools
        async def manager_tools():
            mp = await new_page(1440, 950)
            await mp.emulate_media(reduced_motion="reduce")
            mp.on("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await login(mp, "boss")
            boss_tok = http("POST", "/api/auth/login", {"username": "boss", "password": "pw"})["token"]
            # ---- call supervision: anna talks to a customer; the manager listens, whispers, stops
            call = http("POST", "/demo/call?ext=101&number=%2B37491777001")
            http("POST", f"/demo/phone?kind=answer_in&ext=101&linkedid={call['linkedid']}")
            await nav(mp, "sup")
            row = mp.locator("tr:has(.spy-cell[data-call])").filter(has_text="Anna")
            await row.locator("[data-spy=listen]").wait_for(timeout=8000)
            expect("+37491777001" in await row.locator(".tm-callinfo").inner_text(), "the operator's current call is shown")
            await row.locator("[data-spy=listen]").click()
            await mp.wait_for_selector("[data-spy-line]", timeout=8000)  # the manager's phone answered by itself
            title = await mp.inner_text(".ph-host")
            expect("Anna" in title and "zspy" not in title, f"phone shows whom he listens to: {title[:200]}")
            expect("Listening" in await mp.inner_text("[data-spy-bar]"), "banner on the manager panel")
            await mp.click("[data-spy-line] [data-spy=whisper]")
            await mp.wait_for_function("document.querySelector('[data-spy-bar]') && document.querySelector('[data-spy-bar]').innerText.includes('Whispering')", timeout=5000)
            cur = http("GET", "/api/sup/spy", token=boss_tok)
            expect(cur["active"] and cur["session"]["mode"] == "whisper" and cur["session"]["digit"] == "5", f"whisper on the server: {cur}")
            await mp.locator("[data-spy-bar] [data-spy-mode=barge]").dispatch_event("click")
            await mp.wait_for_function("document.querySelector('[data-spy-line] [data-spy=barge].on')", timeout=5000)
            await mp.locator("[data-spy-stop]").dispatch_event("click")
            await mp.wait_for_function("!document.querySelector('[data-spy-line]') && !document.querySelector('[data-spy-bar]')", timeout=6000)
            expect(not http("GET", "/api/sup/spy", token=boss_tok)["active"], "listening stopped")
            # the manager's listening call is never a call of his own (log, statistics)
            expect(not [c for c in http("GET", "/api/agents/me/calls", token=boss_tok) or [] if "zspy" in str(c)], "no call record for listening")
            http("POST", f"/demo/phone?kind=hangup&ext=101&linkedid={call['linkedid']}")
            # ---- shift schedule: plan, see attendance, edit, template, copy a week (Olga has no demo shifts)
            await nav(mp, "shifts")
            await mp.wait_for_selector("[data-page=shifts] .sh-grid tbody tr")
            expect(await mp.locator("tr[data-person='6'] td.today .sh-chip[data-state=late]").count() == 1, "Davit's late arrival is flagged today")
            day = await mp.get_attribute("[data-sh=plan] .sh-day >> nth=0", "data-day")
            await mp.click(f"[data-sh=plan] [data-day='{day}']")
            await mp.click("[data-sh=plan] .sh-who[data-person='3']")
            await mp.fill("[data-sh=start]", "8")
            await mp.press("[data-sh=start]", "Tab")
            await mp.fill("[data-sh=end]", "1630")
            await mp.press("[data-sh=end]", "Tab")
            expect(await mp.input_value("[data-sh=start]") == "08:00" and await mp.input_value("[data-sh=end]") == "16:30", "times are typed as HH:MM")
            await mp.click("[data-sh=add]")
            chip = mp.locator(f"tr[data-person='3'] td[data-day='{day}'] .sh-chip")
            await chip.first.wait_for(timeout=6000)
            expect("08:00–16:30" in await chip.first.inner_text(), "the planned shift is in the grid")
            await chip.first.click()
            await mp.fill("[data-ed=end]", "17:00")
            await mp.press("[data-ed=end]", "Tab")
            await mp.click("[data-ed=save]")
            await mp.wait_for_function(f"document.querySelector(\"tr[data-person='3'] td[data-day='{day}'] .sh-chip\").innerText.includes('08:00–17:00')", timeout=6000)
            await mp.fill(".sh-tplname", "E2E shift")
            await mp.click(".sh-tplname + .btn")
            await mp.wait_for_selector("[data-tpl='E2E shift']")
            await mp.locator(".sh-tpl:has([data-tpl='E2E shift']) i").click()
            await mp.wait_for_function("!document.querySelector(\"[data-tpl='E2E shift']\")", timeout=5000)
            await mp.click("[data-sh=next]")
            await mp.wait_for_timeout(800)
            await mp.click("[data-sh=copy]")
            nxt = await mp.get_attribute("[data-sh=plan] .sh-day >> nth=0", "data-day")
            await mp.wait_for_selector(f"tr[data-person='3'] td[data-day='{nxt}'] .sh-chip", timeout=6000)
            expect("08:00–17:00" in await mp.inner_text(f"tr[data-person='3'] td[data-day='{nxt}'] .sh-chip"), "copied to the next week")
            for d in (day, nxt):  # leave the demo data as it was
                wk = http("GET", f"/api/sup/shifts?start={d}&days=1", token=boss_tok)
                for x in wk["shifts"]:
                    if x["agent_id"] == 3:
                        http("DELETE", f"/api/sup/shifts/{x['id']}", token=boss_tok)
            if SHOTS:
                await mp.click("[data-sh=today]")
                await mp.wait_for_timeout(600)
                await mp.screenshot(path=f"{SHOTS}/e2e_shifts.png")
            # ---- recordings: find by number, by direction; listen; download
            anna_tok_live = http("POST", "/api/auth/login", {"username": "anna", "password": "pw"})["token"]
            await nav(mp, "recordings")
            await mp.wait_for_selector("[data-page=recordings] tr[data-rec]")
            num = (await mp.inner_text("tr[data-rec] >> nth=0 >> td >> nth=2")).split()[1]
            await mp.fill("[data-f=number]", num)
            await mp.wait_for_timeout(900)
            rows = await mp.locator("tr[data-rec]").all_inner_texts()
            expect(rows and all(num in r for r in rows), f"filtered by the number {num}: {rows[:3]}")
            await mp.click("tr[data-rec] >> nth=0 >> [data-act=rec-play]")
            await mp.wait_for_selector("audio[data-rec-audio]", timeout=6000)
            expect((await mp.get_attribute("audio[data-rec-audio]", "src")).startswith("blob:"), "played through Zenith Desk (with rights)")
            async with mp.expect_download() as dl:
                await mp.click("tr[data-rec] >> nth=0 >> [data-act=rec-download]")
            expect((await dl.value).suggested_filename.endswith(".wav"), "downloaded as a file")
            await mp.fill("[data-f=number]", "")
            await mp.select_option("[data-f=direction]", "out")
            await mp.wait_for_timeout(900)
            dirs = await mp.locator("tr[data-rec] .rec-dir").all_inner_texts()
            expect(dirs and set(dirs) == {"↗"}, f"only outgoing: {set(dirs)}")
            # what is being typed survives a live update of the page (a colleague's change re-draws the list)
            await mp.fill("[data-f=time_from]", "7")
            for path in ("/api/agents/me/break", "/api/agents/me/ready"):  # anna's status changes → the manager's pages re-draw
                try:
                    http("POST", path, token=anna_tok_live)
                except urllib.error.HTTPError:
                    pass
            await mp.wait_for_timeout(2500)
            expect(await mp.input_value("[data-f=time_from]") == "7", "typed hours wiped by a live update")
            await mp.fill("[data-f=time_from]", "0")
            await mp.press("[data-f=time_from]", "Tab")
            await mp.fill("[data-f=time_to]", "0001")
            await mp.press("[data-f=time_to]", "Tab")
            expect(await mp.input_value("[data-f=time_from]") == "00:00" and await mp.input_value("[data-f=time_to]") == "00:01", "hours typed as HH:MM")
            try:
                await mp.wait_for_function("!document.querySelector('tr[data-rec]')", timeout=6000)
            except Exception as exc:
                raise AssertionError("by the hour: nothing between 00:00 and 00:01") from exc
            await mp.click("[data-page=recordings] .mg-reset")
            anna_tok = http("POST", "/api/auth/login", {"username": "anna", "password": "pw"})["token"]
            try:
                http("GET", "/api/recordings", token=anna_tok)
                denied = False
            except urllib.error.HTTPError as e:
                denied = e.code == 403
            expect(denied, "an operator has no recordings archive (managers and admins only)")
            # ---- the log: staff actions with filters, details, export
            await nav(mp, "log")
            await mp.wait_for_selector("[data-page=log] tr[data-log]")
            expect(await mp.locator("[data-cat=system]").count() == 0, "a manager does not see the system problems")
            await mp.click("[data-cat=calls]")
            await mp.select_option("[data-f=action]", "spy_started")
            await mp.wait_for_timeout(900)
            acts = await mp.eval_on_selector_all("tr[data-log]", "els => els.map(e => e.dataset.action)")
            expect(acts and set(acts) == {"spy_started"}, f"only «started listening»: {set(acts)}")
            await mp.click("tr[data-log] >> nth=0")
            expect("whisper" in (await mp.inner_text("tr.lg-open")) or "listen" in (await mp.inner_text("tr.lg-open")), "details open")
            async with mp.expect_download() as dl:
                await mp.click("[data-act=log-csv]")
            path = await (await dl.value).path()
            body = open(path, encoding="utf-8-sig").read()
            expect("spy_started" in body and body.startswith("time;level;category"), "CSV export with the filter")
            await mp.select_option("[data-f=action]", "")
            await mp.click("[data-cat=calls]")
            await mp.fill("[data-f=q]", "E2E shift")
            await mp.wait_for_timeout(900)
            expect(await mp.locator("tr[data-log]").count() == 0, "text search")
            await mp.fill("[data-f=q]", "")
            await mp.click("[data-cat=shifts]")
            await mp.wait_for_timeout(900)
            acts = await mp.eval_on_selector_all("tr[data-log]", "els => els.map(e => e.dataset.action)")
            expect({"shift_planned", "shift_changed", "shift_copied"} <= set(acts), f"shift changes are logged: {set(acts)}")
            if SHOTS:
                await mp.screenshot(path=f"{SHOTS}/e2e_log.png")
            await mp.close()
        await step("Manager tools: listen / whisper / join a call from the manager panel; shift schedule with lateness; recordings archive; log with filters", manager_tools())

        # ---------------------------------------------------------------- v3.18 the team right now
        async def team_now():
            tp = await new_page(1440, 950)
            await tp.emulate_media(reduced_motion="reduce")
            await login(tp, "boss")
            await nav(tp, "sup")
            await tp.wait_for_selector("[data-team=board] tr[data-agent]")
            row = "[data-team=board] tr[data-agent]:has-text('Mariam')"
            # a customer rings Mariam: who calls and from which queue, while it rings
            call = http("POST", "/demo/call?ext=104&number=%2B37491888001")
            await tp.wait_for_selector(f"{row} td[data-phase=ringing]", timeout=5000)
            expect("+37491888001" in await tp.inner_text(f"{row} td[data-phase]"), "ringing: the caller's number")
            # answered: talking with a running timer; hold and back
            http("POST", f"/demo/phone?kind=answer_in&ext=104&linkedid={call['linkedid']}")
            await tp.wait_for_selector(f"{row} td[data-phase=talking]", timeout=5000)
            t1 = await tp.inner_text(f"{row} .tm-timer")
            await tp.wait_for_timeout(2200)
            t2 = await tp.inner_text(f"{row} .tm-timer")
            expect(t1 != t2, f"the call timer does not run ({t1} → {t2})")
            http("POST", "/demo/hold?ext=104")
            await tp.wait_for_selector(f"{row} td[data-phase=hold]", timeout=5000)
            http("POST", "/demo/hold?ext=104&on=false")
            await tp.wait_for_selector(f"{row} td[data-phase=talking]", timeout=5000)
            # Davit calls out: the number he dials
            out = http("POST", "/demo/phone?kind=dial&ext=105&number=%2B37410777000")
            await tp.wait_for_selector("[data-team=board] tr[data-agent]:has-text('Davit') td[data-phase=dialing]", timeout=5000)
            # filter: only people on a call
            await tp.click("[data-tm-filter=call]")
            groups = await tp.eval_on_selector_all("[data-team=board] tr[data-agent]", "rs => rs.map(r => r.dataset.group)")
            expect(groups and all(g == "call" for g in groups) and len(groups) >= 2, f"filter «on a call»: {groups}")
            await tp.click("[data-tm-filter=all]")
            await tp.select_option("[data-tm-sort]", "long")
            await tp.select_option("[data-tm-sort]", "level")
            # a customer waits in queue 400: the queue panel and the feed show him live
            w = http("POST", "/demo/queue/join?queue=400&number=%2B37499111222&name=Waiting%20Customer")
            await tp.wait_for_selector("[data-team=queues] [data-queue='400'].hot", timeout=5000)
            expect("+37499111222" in await tp.inner_text("[data-team=queues] [data-queue='400']"), "the waiting customer in the queue panel")
            await tp.wait_for_selector("[data-team=feed] [data-feed-row=waiting]", timeout=5000)
            await tp.wait_for_selector("[data-team=feed] [data-feed-row=talking]", timeout=5000)
            await tp.click("[data-feed=out]")
            dirs = await tp.eval_on_selector_all("[data-team=feed] .tmf .tmf-dir", "xs => xs.map(x => x.classList.contains('out'))")
            expect(dirs and all(dirs), "feed filter «outgoing»")
            await tp.click("[data-feed=all]")
            # the person's day
            await tp.click(f"{row} [data-act=day]")
            await tp.wait_for_selector("[data-agent-day] [data-day-stats]", timeout=5000)
            expect("Mariam" in await tp.inner_text("[data-agent-day] h3"), "day card of the right person")
            await tp.wait_for_selector("[data-agent-day] [data-day-call=talking]", timeout=5000)
            shown = (await tp.inner_text("[data-agent-day] [data-day]")).strip()  # the day in the company's time zone
            await tp.click("[data-agent-day] [data-day-prev]")
            # v3.20.1: compare with the day shown before (not with today in UTC — around midnight they differ)
            await tp.wait_for_function("(d) => document.querySelector('[data-agent-day] [data-day]').textContent.trim() < d", arg=shown, timeout=8000)
            await tp.keyboard.press("Escape")
            await tp.wait_for_selector("[data-agent-day]", state="detached", timeout=3000)
            if SHOTS:
                await tp.screenshot(path=f"{SHOTS}/team-now.png")
            # the wallboard for a TV
            await tp.goto(BASE + "/?wall=1")
            await tp.wait_for_selector("[data-wall] [data-wt=waiting]", timeout=8000)
            expect((await tp.inner_text("[data-wall] [data-wt=waiting] > b")).strip() != "0", "wallboard: customers waiting")
            await tp.wait_for_selector("[data-wall] .wp.ph-talking", timeout=5000)
            sw = await tp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            expect(sw <= 1, f"wallboard sideways scroll {sw}px")
            if SHOTS:
                await tp.set_viewport_size({"width": 1920, "height": 1080})
                await tp.wait_for_timeout(500)
                await tp.screenshot(path=f"{SHOTS}/wallboard.png")
            await tp.click("[data-wall-exit]")
            await tp.wait_for_selector("[data-team=board]", timeout=5000)
            # the end of it all
            http("POST", f"/demo/queue/abandon?linkedid={w['linkedid']}")
            http("POST", f"/demo/phone?kind=hangup&ext=104&linkedid={call['linkedid']}")
            http("POST", f"/demo/phone?kind=hangup&ext=105&linkedid={out['linkedid']}")
            await tp.wait_for_selector(f"{row} td[data-phase=talking]", state="detached", timeout=5000)
            await tp.close()
        await step("Team now: who rings / talks / holds / dials (number, queue, timer), filters, queues live, call feed, the person's day, wallboard", team_now())

        # ---------------------------------------------------------------- v3.18 call routing for managers
        async def call_routing():
            rp = await new_page(1440, 950)
            await rp.emulate_media(reduced_motion="reduce")
            await login(rp, "boss")
            await nav(rp, "callrouting")
            await rp.wait_for_selector("[data-cr-queue='400']")
            q = "[data-cr-queue='400']"
            await rp.select_option(f"{q} [data-cr=mode]", "leastrecent")
            await rp.check(f"{q} [data-cr=over-enabled]")
            await rp.fill(f"{q} [data-cr=over-n]", "2")
            await rp.fill(f"{q} [data-cr=over-x]", "0")
            if not await rp.is_checked(f"{q} [data-cr-group=level2]"):
                await rp.check(f"{q} [data-cr-group=level2]")
            await rp.check("[data-cr=vip-enabled]")
            await rp.click("[data-cr=add-rule]")
            rule = "[data-cr-rule='0']"
            await rp.fill(f"{rule} [data-cr=match]", "+37491999000")
            opt = await rp.eval_on_selector(f"{rule} [data-cr=target]", "s => [...s.options].find(o => o.text.includes('Mariam')).value")
            await rp.select_option(f"{rule} [data-cr=target]", opt)
            await rp.wait_for_selector("[data-cr=dirty]")
            await rp.click("[data-cr=save]")
            await rp.wait_for_selector("[data-cr=dirty]", state="detached", timeout=5000)
            expect("leastrecent" in await rp.inner_text(f"{q} .hint") or await rp.locator(f"{q} [data-cr=strategy-error]").count() == 1,
                   "distribution saved (applied or a FreePBX hint)")
            await rp.fill("[data-cr=test-number]", "+37491999000")
            await rp.click("[data-cr=test]")
            await rp.wait_for_selector("[data-cr=test-result]", timeout=5000)
            expect("Mariam" in await rp.inner_text("[data-cr=test-result]") or "busy" in await rp.inner_text("[data-cr=test-result]"),
                   "number check names the person")
            # the VIP calls: he goes to Mariam's phone, not to the queue
            vip = http("POST", "/demo/queue/join?queue=401&number=%2B37491999000&name=Director")
            await rp.wait_for_selector("[data-cr-recent=callroute_vip]", timeout=8000)
            sp = await new_page(1440, 950)
            await login(sp, "boss")
            await nav(sp, "sup")
            await sp.wait_for_selector("[data-team=board] tr[data-agent]:has-text('Mariam') td[data-phase=ringing]", timeout=8000)
            # two customers wait in 400: overflow — Level 2 takes calls too
            a1 = http("POST", "/demo/queue/join?queue=400&number=%2B37499100001")
            a2 = http("POST", "/demo/queue/join?queue=400&number=%2B37499100002")
            await rp.wait_for_selector(f"{q} [data-cr=overflow-on]", timeout=10000)
            if SHOTS:
                await rp.screenshot(path=f"{SHOTS}/call-routing.png", full_page=True)
            for x in (a1, a2, vip):
                http("POST", f"/demo/queue/abandon?linkedid={x['linkedid']}" + ("&queue=401" if x is vip else ""))
            # switch it all off again (the other checks expect the plain demo)
            await rp.uncheck(f"{q} [data-cr=over-enabled]")
            await rp.uncheck("[data-cr=vip-enabled]")
            await rp.select_option(f"{q} [data-cr=mode]", "")
            await rp.click("[data-cr=save]")
            await rp.wait_for_selector(f"{q} [data-cr=overflow-on]", state="detached", timeout=8000)
            await sp.close()
            await rp.close()
        await step("Call routing (manager): distribution per queue, overflow adds Level 2 when the queue is full, VIP goes straight to the chosen person, number check", call_routing())

        async def icon_buttons():
            # v3.15.1: icon-only buttons next to each other (top bar, message composer…) are the same size and on one line
            audit = """() => { const out = [];
              const isIcon = (e) => e.querySelector(':scope > svg') && !e.innerText.trim() && e.getBoundingClientRect().width > 0;
              const parents = new Set([...document.querySelectorAll('button, label, a')].filter(isIcon).map(e => e.parentElement));
              for (const p of parents) { const kids = [...p.children].filter(isIcon); if (kids.length < 2) continue;
                const rs = kids.map(k => k.getBoundingClientRect()), hs = new Set(rs.map(r => Math.round(r.height))), ws = new Set(rs.map(r => Math.round(r.width)));
                const mid = rs.map(r => Math.round(r.top + r.height / 2)), col = rs.map(r => Math.round(r.left + r.width / 2));
                const line = mid.every(t => Math.abs(t - mid[0]) <= 1) || col.every(c => Math.abs(c - col[0]) <= 1);  // a row, or (v3.19 rail) a column
                if (hs.size > 1 || ws.size > 1 || !line) out.push(String(p.className || p.tagName).slice(0, 40) + ' h=' + [...hs] + ' w=' + [...ws]); }
              return out; }"""
            ip = await new_page(1440, 900)
            await login(ip, "anna")
            bad = []
            for key in ("work", "tickets", "chat", "mail", "whatsapp", "telegram"):
                await nav(ip, key)
                if key in ("whatsapp", "telegram") and await ip.locator(".ib-item").count():
                    await ip.locator(".ib-item").first.click()
                    await ip.wait_for_selector(".ib-inp", timeout=5000)
                bad += [f"{key}: {b}" for b in await ip.evaluate(audit)]
            expect(not bad, "; ".join(bad[:6]))
            await ip.close()
        await step("Icon buttons side by side have one size and line (top bar, message composer, mail, tickets)", icon_buttons())

        await step("Responsive: 360 px phone to 2560 px monitor, full width, no sideways scrolling", responsive())

        async def popups_and_phone_lists():
            # v3.20.1: a pop-up always covers the whole window (no entrance animation may trap it in a panel),
            # and on a phone no list is wider than the screen (a long message preview is cut, not the screen)
            ap = await new_page(1920, 934)
            await login(ap, "admin", "admin", wait=".sidebar")
            await nav(ap, "admin")
            await ap.wait_for_selector(".admin table tbody tr td.nowrap button", timeout=6000)
            await ap.wait_for_timeout(900)  # the entrance animations are over
            await ap.locator(".admin table tbody tr").first.locator("td.nowrap button").nth(1).click()
            await ap.wait_for_selector(".overlay .modal")
            box = await ap.evaluate("(() => { const o = document.querySelector('.overlay').getBoundingClientRect(), m = document.querySelector('.overlay .modal').getBoundingClientRect();"
                                    " return [o.left, o.top, o.width, o.height, innerWidth, innerHeight, (m.top + m.bottom) / 2]; })()")
            expect(box[0] == 0 and box[1] == 0 and box[2] == box[4] and box[3] == box[5], f"the pop-up does not cover the window: {box}")
            expect(abs(box[6] - box[5] / 2) < 60, f"the pop-up is not in the middle of the window: {box}")
            await ap.keyboard.press("Escape")
            await ap.evaluate("document.querySelector('.overlay') && document.querySelector('.overlay').click()")
            # blocks side by side are built evenly: no hole under the shorter block of a row
            gaps = """() => { const out = [];
                for (const g of document.querySelectorAll('.dash, .ov-row, .bk-grid, .grid, .tm-grid')) {
                    const kids = [...g.children].filter(k => { const r = k.getBoundingClientRect(); return r.width > 150 && r.height > 80; });
                    const rows = {}; for (const k of kids) { const r = k.getBoundingClientRect(); (rows[Math.round(r.top / 4)] = rows[Math.round(r.top / 4)] || []).push(r.height); }
                    for (const hs of Object.values(rows)) if (hs.length > 1 && Math.max(...hs) - Math.min(...hs) > 24) out.push(String(g.className) + ' ' + hs.map(Math.round)); }
                return out; }"""
            await ap.set_viewport_size({"width": 1440, "height": 900})
            for key in ("sup", "overview"):
                await nav(ap, key)
                await ap.wait_for_timeout(1500)
                bad = await ap.evaluate(gaps)
                expect(not bad, f"{key}: blocks of one row are not even: {bad}")
            await ap.close()
            clipped = """() => { const vw = innerWidth, out = [];
                const scroller = (e) => { for (let a = e.parentElement; a; a = a.parentElement) { const c = getComputedStyle(a);
                    if ((c.overflowX === 'auto' || c.overflowX === 'scroll') && a.scrollWidth > a.clientWidth + 1) return true; } return false; };
                for (const e of document.querySelectorAll('main *')) { const r = e.getBoundingClientRect();
                    if (r.width && r.height && (r.right > vw + 1 || r.left < -1) && !scroller(e) && getComputedStyle(e).position !== 'fixed')
                        out.push(String(e.className).slice(0, 30) + ' ' + Math.round(r.left) + '..' + Math.round(r.right)); }
                return out.slice(0, 5); }"""
            mp = await new_page(360, 740)
            await login(mp, "anna", wait=".sidebar")  # on a phone the menu may sit behind ☰ (Classic / Studio)
            for key in ("work", "tickets", "contacts", "chat", "mail", "whatsapp", "telegram"):
                await nav(mp, key)
                await mp.wait_for_timeout(900)
                bad = await mp.evaluate(clipped)
                expect(not bad, f"phone, {key}: cut off at the right edge: {bad}")
            if FLOW:  # the operator's top bar: status, Ready and Break on one row
                await nav(mp, "work")
                ys = await mp.evaluate("['.topbar .status', '.topbar .btn.go', '.topbar > .btn:not(.go)'].map(s => { const e = document.querySelector(s); const r = e.getBoundingClientRect(); return Math.round(r.top + r.height / 2); })")
                expect(max(ys) - min(ys) <= 6, f"phone: the status, Ready and Break are not on one row ({ys})")
            await mp.close()
        await step("Pop-ups cover the whole window and stay in the middle; on a phone no list is cut off at the right edge, status · Ready · Break on one row", popups_and_phone_lists())

        async def no_js_errors():
            expect(not errors, "; ".join(errors[:5]))
        await step("No JavaScript errors in the browser", no_js_errors())

        await browser.close()

    failed = [r for r in RESULTS if not r[1]]
    print(f"\nE2E: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
