"""v3.18 the team right now: live board phases, queues, the call feed, one person's day, alerts for managers."""
from datetime import timedelta

from app.db import utcnow

from .conftest import IF1, IF2


async def ev(env, **e):
    await env.services.calls.handle_event(e)


async def board(env, h) -> dict:
    r = await env.client.get("/api/admin/agents", headers=h)
    assert r.status_code == 200, r.text
    return {a["agent_id"]: a for a in r.json()["agents"]}


async def test_live_board_phases(env):
    boss, anna = await env.login("boss"), await env.login("anna")
    env.settings.wrap_up_seconds = 30
    assert (await env.client.post("/api/agents/me/ready", headers=anna)).status_code == 200
    b = await board(env, boss)
    assert b[1]["phase"] is None and b[1]["live_call"] is None and b[1]["group"] in ("free", "busy", "offline", "break")
    # ringing: who calls, from which queue
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF1, CallerIDNum="+37491123456", CallerIDName="Ivan", Uniqueid="L1", Linkedid="L1")
    b = await board(env, boss)
    assert b[1]["phase"] == "ringing" and b[1]["group"] == "call" and b[1]["phase_since"]
    assert b[1]["live_call"]["number"] == "+37491123456" and b[1]["live_call"]["name"] == "Ivan" and b[1]["live_call"]["queue"] == "400"
    # boris calls out from his own phone
    await ev(env, Event="DialBegin", Channel="PJSIP/102-0001", DestChannel="PJSIP/trunk-1", DestCallerIDNum="+37410999999",
             Uniqueid="O1", Linkedid="O1")
    b = await board(env, boss)
    assert b[2]["phase"] == "dialing" and b[2]["live_call"]["number"] == "+37410999999" and b[2]["live_call"]["direction"] == "out"
    # answered → talking (the timer starts at the answer), hold / unhold from Asterisk
    await ev(env, Event="AgentConnect", Queue="400", Interface=IF1, Uniqueid="L1", Linkedid="L1")
    b = await board(env, boss)
    assert b[1]["phase"] == "talking" and b[1]["phase_since"] == b[1]["live_call"]["answered_at"] and b[1]["call"]["number"] == "+37491123456"
    await ev(env, Event="Hold", Channel="PJSIP/101-0000abcd", Uniqueid="L1x", Linkedid="L1")
    assert (await board(env, boss))[1]["phase"] == "hold"
    await ev(env, Event="Hold", Channel="PJSIP/trunk-1-0002")  # the customer's side: nobody of ours
    await ev(env, Event="Unhold", Channel="PJSIP/101-0000abcd")
    assert (await board(env, boss))[1]["phase"] == "talking"
    await ev(env, Event="Hold", Channel="PJSIP/101-0000abcd")
    # the call ends: on hold no more, wrap-up follows
    await ev(env, Event="AgentComplete", Queue="400", Interface=IF1, Uniqueid="L1", Linkedid="L1")
    b = await board(env, boss)
    assert 1 not in env.services.calls.hold
    assert b[1]["phase"] == "wrap_up" and b[1]["live_call"] is None and b[1]["computed_state"] == "wrap_up"
    assert b[1]["state_since"] is not None
    # a blocking ticket: what and since when
    env.zammad.add_ticket("Printer broken", owner_id=10, state="open")
    tid = max(env.zammad.tickets)
    r = await env.client.post(f"/api/tickets/{tid}/start", json={"work_mode": "blocking"}, headers=anna)
    if r.status_code == 200:
        w = (await board(env, boss))[1]["work"]
        assert w and w["ticket_id"] == tid and w["started_at"]
    # only managers / administrators
    assert (await env.client.get("/api/admin/team/live", headers=anna)).status_code == 403
    assert (await env.client.get("/api/admin/team/agents/1/day", headers=anna)).status_code == 403
    assert (await env.client.get("/api/admin/team/live", headers=await env.login("root"))).status_code == 200


async def test_queues_and_call_feed(env):
    boss = await env.login("boss")
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37499000111", CallerIDName="Waiting Guy", Uniqueid="Q1", Linkedid="Q1")
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37499000222", Uniqueid="Q2", Linkedid="Q2")
    d = (await env.client.get("/api/admin/team/live", headers=boss)).json()
    q = {x["queue"]: x for x in d["queues"]}
    assert q["400"]["waiting"] == 2 and q["401"]["waiting"] == 0 and d["waiting_total"] == 2
    assert [c["number"] for c in q["400"]["callers"]] == ["+37499000111", "+37499000222"] and q["400"]["callers"][0]["name"] == "Waiting Guy"
    assert q["400"]["managed"] and q["400"]["free"] == d["free_total"]
    # one hangs up after 40 s, the other is answered by anna
    await ev(env, Event="QueueCallerAbandon", Queue="400", HoldTime="40", Uniqueid="Q1", Linkedid="Q1")
    await ev(env, Event="Hangup", Uniqueid="Q1", Linkedid="Q1")
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF1, CallerIDNum="+37499000222", Uniqueid="Q2", Linkedid="Q2")
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF2, CallerIDNum="+37499000222", Uniqueid="Q2", Linkedid="Q2")
    await ev(env, Event="AgentConnect", Queue="400", Interface=IF1, HoldTime="7", Uniqueid="Q2", Linkedid="Q2")
    await ev(env, Event="DialBegin", Channel="PJSIP/102-0003", DestChannel="PJSIP/trunk-1", DestCallerIDNum="+37410555000", Uniqueid="O2", Linkedid="O2")
    await ev(env, Event="Hangup", Uniqueid="O2", Linkedid="O2")
    d = (await env.client.get("/api/admin/team/live?feed=10", headers=boss)).json()
    assert d["waiting_total"] == 0 and d["talking_total"] == 1
    assert d["today"]["missed"] == 1 and d["today"]["answered"] == 1 and d["today"]["outbound"] == 1
    feed = {x["id"]: x for x in d["feed"]}
    assert feed["Q1"]["result"] == "abandoned" and feed["Q1"]["wait_sec"] == 40 and feed["Q1"]["number"] == "+37499000111"
    assert feed["Q2"]["result"] == "talking" and feed["Q2"]["agent"] == "Анна" and feed["Q2"]["rang"] == ["Борис"]
    assert feed["O2"]["direction"] == "out" and feed["O2"]["result"] == "no_answer" and feed["O2"]["agent"] == "Борис"
    assert [x["id"] for x in d["feed"]][:1] == ["O2"]  # newest first
    assert len((await env.client.get("/api/admin/team/live?feed=1", headers=boss)).json()["feed"]) == 1


async def test_agent_day(env):
    boss = await env.login("boss")
    await env.login("anna")
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF1, CallerIDNum="+111", Uniqueid="D1", Linkedid="D1")
    await ev(env, Event="AgentConnect", Queue="400", Interface=IF1, Uniqueid="D1", Linkedid="D1")
    await ev(env, Event="AgentComplete", Queue="400", Interface=IF1, Uniqueid="D1", Linkedid="D1")
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF1, CallerIDNum="+222", Uniqueid="D2", Linkedid="D2")
    await ev(env, Event="AgentRingNoAnswer", Queue="400", Interface=IF1, Uniqueid="D2", Linkedid="D2")
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF2, CallerIDNum="+333", Uniqueid="D3", Linkedid="D3")
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF1, CallerIDNum="+333", Uniqueid="D3", Linkedid="D3")
    await ev(env, Event="AgentConnect", Queue="400", Interface=IF2, Uniqueid="D3", Linkedid="D3")
    await ev(env, Event="Hangup", Uniqueid="D3", Linkedid="D3")
    r = await env.client.get("/api/admin/team/agents/1/day", headers=boss)
    assert r.status_code == 200, r.text
    d = r.json()
    res = {c["number"]: c["result"] for c in d["calls"]}
    assert res == {"+111": "answered", "+222": "missed", "+333": "colleague"}
    st = d["stats"]
    assert st["inbound_rang"] == 3 and st["inbound_answered"] == 1 and st["rona"] == 1 and st["inbound_missed"] == 1
    assert d["agent"]["name"] == "Анна" and len(d["calls_lane"]) == 1 and d["calls_lane"][0]["direction"] == "in"
    assert any(x["state"] != "offline" for x in d["states"])  # anna signed in today
    tomorrow = (utcnow() + timedelta(days=2)).date().isoformat()
    assert (await env.client.get(f"/api/admin/team/agents/1/day?day={tomorrow}", headers=boss)).status_code == 422
    assert (await env.client.get("/api/admin/team/agents/999/day", headers=boss)).status_code == 404
    old = (await env.client.get("/api/admin/team/agents/1/day?day=2026-01-05", headers=boss)).json()
    assert old["calls"] == [] and old["stats"]["inbound_rang"] == 0


async def test_alerts_for_managers(env):
    boss, anna, boris = await env.login("boss"), await env.login("anna"), await env.login("boris")
    cfg = env.settings
    cfg.alert_long_call_min, cfg.alert_long_break_min, cfg.alert_queue_waiting = 15, 20, 3
    cfg.alert_rona = cfg.alert_missed_calls = True
    for h in (boss, anna):  # signed in = break until «Ready» (login_sets_ready is off in the tests)
        assert (await env.client.post("/api/agents/me/ready", headers=h)).status_code == 200
    watch = env.services.team
    watch.started_at = utcnow() - timedelta(minutes=5)
    # anna talks (long), boris goes on a break (long) and did not answer a call (RONA)
    await ev(env, Event="AgentCalled", Queue="400", Interface=IF1, CallerIDNum="+37491000001", Uniqueid="A1", Linkedid="A1")
    await ev(env, Event="AgentConnect", Queue="400", Interface=IF1, Uniqueid="A1", Linkedid="A1")
    await ev(env, Event="QueueCallerJoin", Queue="401", CallerIDNum="+37491000002", Uniqueid="R1", Linkedid="R1")
    await ev(env, Event="AgentCalled", Queue="401", Interface=IF2, CallerIDNum="+37491000002", Uniqueid="R1", Linkedid="R1")
    await ev(env, Event="AgentRingNoAnswer", Queue="401", Interface=IF2, Uniqueid="R1", Linkedid="R1")
    assert (await env.client.post("/api/agents/me/break", json={"reason": ""}, headers=boris)).status_code == 200
    # three wait in 401; one more gave up after 30 s in 400
    for i in range(3):
        await ev(env, Event="QueueCallerJoin", Queue="401", CallerIDNum=f"+3749100010{i}", Uniqueid=f"W{i}", Linkedid=f"W{i}")
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37491000009", Uniqueid="M1", Linkedid="M1")
    await ev(env, Event="QueueCallerAbandon", Queue="400", HoldTime="30", Uniqueid="M1", Linkedid="M1")
    await ev(env, Event="Hangup", Uniqueid="M1", Linkedid="M1")
    sent = await watch.check(utcnow() + timedelta(seconds=10))  # RONA after a few seconds: a colleague may still answer
    kinds = sorted(a["kind"] for a in sent)
    assert kinds == ["missed", "queue", "rona"], kinds  # not yet long
    later = utcnow() + timedelta(minutes=21)
    sent = await watch.check(later)
    assert sorted(a["kind"] for a in sent) == ["long_break", "long_call"]
    assert {a["kind"]: a.get("agent_id") for a in sent} == {"long_break": 2, "long_call": 1}
    assert await watch.check(later + timedelta(seconds=30)) == []  # once per problem
    # the bell of every manager — not of the operators
    items = (await env.client.get("/api/agents/me/notifications?limit=50", headers=boss)).json()["items"]
    team = [i["text"] for i in items if i["kind"] == "team"]
    assert len(team) == 5, team
    assert any("+37491000002" in x and "Борис" in x for x in team), team
    assert any("401" in x and "4" in x for x in team), team
    for h in (anna, boris):
        items = (await env.client.get("/api/agents/me/notifications?limit=50", headers=h)).json()["items"]
        assert not [i for i in items if i["kind"] == "team"]
    # a restart does not repeat them
    from app.team import TeamWatch
    fresh = TeamWatch(env.services)
    fresh.started_at = watch.started_at
    await fresh._load_sent()
    fresh.queue_over = set(watch.queue_over)
    assert await fresh.check(later + timedelta(seconds=60)) == []
    # under the threshold and over it again: a new queue alert
    for w in ("W0", "W1"):  # short abandons: no «missed» alert
        await ev(env, Event="QueueCallerAbandon", Queue="401", HoldTime="3", Uniqueid=w, Linkedid=w)
        await ev(env, Event="Hangup", Uniqueid=w, Linkedid=w)
    assert [a["kind"] for a in await watch.check(utcnow())] == []
    await ev(env, Event="QueueCallerJoin", Queue="401", CallerIDNum="+37491000199", Uniqueid="W9", Linkedid="W9")
    assert [a["kind"] for a in await watch.check(utcnow())] == ["queue"]
    # switched off: nothing
    cfg.alert_long_call_min = cfg.alert_long_break_min = cfg.alert_queue_waiting = 0
    cfg.alert_rona = cfg.alert_missed_calls = False
    watch.sent.clear()
    assert await watch.check(later) == []
