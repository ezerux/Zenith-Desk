"""SEC-01 (finding A): the backup upload has its own size limit, enforced while streaming.

Users of the test environment: 1 anna (operator), 2 boris (operator), 3 boss (supervisor), 4 root (administrator).
"""
import asyncio
import json
import struct
from pathlib import Path

import pytest

from app import backup as bk

MB = 1024 * 1024


def backup_like(size: int) -> bytes:
    """Bytes that pass the header check of a Zenith Desk backup, padded to exactly `size`."""
    head = json.dumps({"app": "zenith-desk", "created_at": "2026-10-26T00:00:00Z"}).encode()
    blob = bk.MAGIC + struct.pack(">I", len(head)) + head
    assert size >= len(blob)
    return blob + b"\0" * (size - len(blob))


def leftovers(env) -> list[str]:
    return [p.name for p in Path(env.settings.backup_dir).glob("*.part")] + [p.name for p in Path(env.settings.backup_dir).glob(".upload-*")]


async def chunked(data: bytes, step: int = 256 * 1024):
    for i in range(0, len(data), step):
        yield data[i:i + step]


@pytest.fixture
def small_limit(env):
    env.settings.backup_upload_max_mb = 1
    env.settings.backup_min_free_mb = 0
    return env


@pytest.mark.asyncio
async def test_below_and_exactly_at_the_limit_are_accepted(small_limit):
    env = small_limit
    root = await env.login("root")
    r = await env.client.put("/api/admin/backups/upload?filename=small.zdb", content=backup_like(4096), headers=root)
    assert r.status_code == 200, r.text
    r = await env.client.put("/api/admin/backups/upload?filename=exact.zdb", content=backup_like(1 * MB), headers=root)
    assert r.status_code == 200, r.text
    assert r.json()["uploaded"]["size"] == 1 * MB
    assert not leftovers(env)


@pytest.mark.asyncio
async def test_above_the_limit_is_refused_with_413_and_nothing_is_kept(small_limit):
    env = small_limit
    root = await env.login("root")
    before = sorted(p.name for p in Path(env.settings.backup_dir).glob("*"))
    # declared too big (Content-Length): refused before anything is written
    r = await env.client.put("/api/admin/backups/upload?filename=big.zdb", content=backup_like(1 * MB + 1), headers=root)
    assert r.status_code == 413
    # no Content-Length at all (chunked transfer): stopped while streaming
    r = await env.client.put("/api/admin/backups/upload?filename=chunked.zdb", content=chunked(backup_like(3 * MB)), headers=root)
    assert r.status_code == 413
    assert sorted(p.name for p in Path(env.settings.backup_dir).glob("*")) == before
    assert not leftovers(env)


@pytest.mark.asyncio
async def test_a_misleading_small_content_length_is_not_trusted(small_limit):
    env = small_limit
    # the service gets a small declared size but a big stream: the streamed bytes decide
    with pytest.raises(bk.BackupError) as e:
        await env.services.backups.save_upload("liar.zdb", chunked(backup_like(2 * MB)), declared=10)
    assert e.value.code == "bk.too_big"
    assert not leftovers(env)


@pytest.mark.asyncio
async def test_an_interrupted_upload_leaves_no_partial_file(small_limit):
    env = small_limit

    async def cut():
        yield backup_like(64 * 1024)
        raise ConnectionResetError("client went away")
    with pytest.raises(ConnectionResetError):
        await env.services.backups.save_upload("cut.zdb", cut())
    assert not leftovers(env)
    assert not list(Path(env.settings.backup_dir).glob("cut*"))


@pytest.mark.asyncio
async def test_only_one_upload_at_a_time(small_limit):
    env = small_limit
    gate = asyncio.Event()

    async def slow():
        yield backup_like(1024)
        await gate.wait()
    first = asyncio.create_task(env.services.backups.save_upload("one.zdb", slow()))
    await asyncio.sleep(0.05)
    with pytest.raises(bk.BackupError) as e:
        await env.services.backups.save_upload("two.zdb", chunked(backup_like(1024)))
    assert e.value.code == "bk.upload_busy"
    gate.set()
    assert (await first)["name"].endswith(".zdb")
    root = await env.login("root")
    r = await env.client.put("/api/admin/backups/upload?filename=two.zdb", content=backup_like(1024), headers=root)
    assert r.status_code == 200  # after the first one finished


@pytest.mark.asyncio
async def test_free_disk_space_is_kept(small_limit, monkeypatch):
    env = small_limit
    env.settings.backup_min_free_mb = 10
    import shutil
    monkeypatch.setattr(shutil, "disk_usage", lambda p: shutil._ntuple_diskusage(100 * MB, 99 * MB, 1 * MB))
    root = await env.login("root")
    r = await env.client.put("/api/admin/backups/upload?filename=full.zdb", content=backup_like(4096), headers=root)
    assert r.status_code == 507
    assert not leftovers(env)


@pytest.mark.asyncio
async def test_malformed_and_traversal_names(small_limit):
    env = small_limit
    root = await env.login("root")
    r = await env.client.put("/api/admin/backups/upload?filename=junk.zdb", content=b"\x00\x01 not a backup at all", headers=root)
    assert r.status_code == 400
    r = await env.client.put("/api/admin/backups/upload?filename=" + "../../../../etc/passwd", content=backup_like(2048), headers=root)
    assert r.status_code == 200
    name = r.json()["uploaded"]["name"]
    assert "/" not in name and ".." not in name and name.endswith(".zdb")
    assert (Path(env.settings.backup_dir) / name).is_file()
    assert not leftovers(env)


@pytest.mark.asyncio
async def test_a_symlink_in_the_folder_is_never_served(small_limit, tmp_path):
    env = small_limit
    root = await env.login("root")
    secret = tmp_path / "outside.txt"
    secret.write_text("not for download")
    folder = Path(env.settings.backup_dir)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "zenith-backup-link.zdb").symlink_to(secret)
    r = await env.client.post("/api/admin/backups/zenith-backup-link.zdb/link", headers=root)
    assert r.status_code == 404


@pytest.mark.asyncio
async def test_only_an_administrator_may_upload(small_limit):
    env = small_limit
    for user in ("anna", "boss"):
        h = await env.login(user)
        r = await env.client.put("/api/admin/backups/upload?filename=x.zdb", content=backup_like(2048), headers=h)
        assert r.status_code == 403, user
    assert (await env.client.put("/api/admin/backups/upload?filename=x.zdb", content=backup_like(2048))).status_code == 401
    assert not list(Path(env.settings.backup_dir).glob("x*"))
