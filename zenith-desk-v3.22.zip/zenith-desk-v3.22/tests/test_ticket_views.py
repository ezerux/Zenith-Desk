"""v3.11 — Zammad overviews, filters, tabs and drafts, tags, Zammad groups for the administrator.
The fake answers in the shapes of the Zammad 7.2 source (TicketOverviewsController, Ticket::Overviews.index,
TagsController, GroupsController, HasGroups#group_ids_access_map=)."""
from sqlalchemy import select

from app.models import AuditLog, TicketTab


RU = {"my_assigned": "Назначенные мне заявки", "all_unassigned": "Не назначенные и открытые заявки", "all_open": "Открытые заявки",
      "my_pending_reached": "Мои ожидающие решения заявки", "my_subscribed_tickets": "Мои заявки по подписке",
      "all_pending_reached": "Ожидающие решения заявки", "all_escalated": "Эскалированные заявки"}


def seed(env):
    fz = env.zammad
    fz.rename_overviews(RU)  # the company's Zammad speaks Russian
    fz.orgs[7] = {"id": 7, "name": "Coffeeshop test"}
    fz.users[50]["organization_id"] = 7
    t = {}
    t["a1"] = fz.add_ticket("Alarm Audit", owner_id=10, state="open")
    t["a2"] = fz.add_ticket("Vino Nor", owner_id=10, state="new", priority="3 high")
    t["a3"] = fz.add_ticket("Old closed one", owner_id=10, state="closed", close_at="2026-09-01T10:00:00Z")
    t["u1"] = fz.add_ticket("Nobody took it", owner_id=1, state="new")
    t["u2"] = fz.add_ticket("Second free one", owner_id=1, state="open")
    t["b1"] = fz.add_ticket("Boris works on it", owner_id=11, state="open")
    t["s1"] = fz.add_ticket("Sales only", owner_id=1, state="open", group="Sales")
    t["on"] = fz.add_ticket("Visit the office", owner_id=1, state="open")
    fz.tags[t["on"]["id"]] = ["on-site"]
    return t


def obo_requests(fz, path):
    return [r for r in fz.requests if r[1] == path]


async def test_overviews_are_the_operators_own_zammad_overviews(env):
    seed(env)
    h = await env.login("anna")
    r = await env.client.get("/api/tk/overviews", headers=h)
    assert r.status_code == 200, r.text
    ovs = {o["link"]: o for o in r.json()["overviews"]}
    assert [o["name"] for o in r.json()["overviews"]] == ["Назначенные мне заявки", "Не назначенные и открытые заявки",
                                                          "Мои ожидающие решения заявки", "Мои заявки по подписке", "Открытые заявки",
                                                          "Ожидающие решения заявки", "Эскалированные заявки", "My Closed Tickets",
                                                          "On-site Requests"]
    assert ovs["my_assigned"]["count"] == 2 and ovs["all_unassigned"]["count"] == 3  # Sales is not Anna's group
    assert ovs["all_open"]["count"] == 6 and ovs["my_closed_tickets"]["count"] == 1 and ovs["on_site_requests"]["count"] == 1
    # boris sees his own numbers (the request is made in the operator's name)
    r = await env.client.get("/api/tk/overviews", headers=await env.login("boris"))
    assert {o["link"]: o["count"] for o in r.json()["overviews"]}["my_assigned"] == 1


async def test_overview_list_filters_sort_paging(env):
    t = seed(env)
    h = await env.login("anna")
    r = await env.client.get("/api/tk/overviews/all_open", headers=h)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["overview"]["name"] == "Открытые заявки" and d["overview"]["count"] == 6 and d["total"] == 6 and not d["limited"]
    row = next(x for x in d["tickets"] if x["id"] == t["a1"]["id"])
    assert row["customer"] == "Иван" and row["organization"] == "Coffeeshop test" and row["group"] == "Users"
    assert row["state"] == "open" and row["priority"] == "2 normal" and row["owner_id"] == 10 and row["mine"]
    free = next(x for x in d["tickets"] if x["id"] == t["u1"]["id"])
    assert free["owner_id"] is None and free["owner"] == ""
    assert {o["id"] for o in d["facets"]["owners"]} == {10, 11}
    # filters
    q = lambda **kw: env.client.get("/api/tk/overviews/all_open", params=kw, headers=h)  # noqa: E731
    assert [x["title"] for x in (await q(q="vino")).json()["tickets"]] == ["Vino Nor"]
    assert [x["title"] for x in (await q(q="coffeeshop")).json()["tickets"]]  # organization is searchable
    assert {x["title"] for x in (await q(owner="none")).json()["tickets"]} == {"Nobody took it", "Second free one", "Visit the office"}
    assert {x["title"] for x in (await q(owner="me")).json()["tickets"]} == {"Alarm Audit", "Vino Nor"}
    assert {x["title"] for x in (await q(owner="11")).json()["tickets"]} == {"Boris works on it"}
    assert {x["title"] for x in (await q(state="new")).json()["tickets"]} == {"Vino Nor", "Nobody took it"}
    assert [x["title"] for x in (await q(priority="3 high")).json()["tickets"]] == ["Vino Nor"]
    assert len((await q(group="Users")).json()["tickets"]) == 6 and not (await q(group="Sales")).json()["tickets"]
    # sort
    asc = [x["title"] for x in (await q(sort="title", direction="asc")).json()["tickets"]]
    assert asc == sorted(asc, key=str.lower)
    desc = [x["number"] for x in (await q(sort="number", direction="desc")).json()["tickets"]]
    assert desc == sorted(desc, key=int, reverse=True)
    # paging
    p1 = (await q(per_page=10, page=1)).json()
    assert p1["total"] == 6 and len(p1["tickets"]) == 6
    # Zammad's own limit (ui_ticket_overview_ticket_limit): the count stays right, the list says it is cut
    env.zammad.overview_limit = 2
    d = (await env.client.get("/api/tk/overviews/all_open?fresh=true", headers=h)).json()
    assert d["overview"]["count"] == 6 and d["loaded"] == 2 and d["limited"]
    # unknown overview
    assert (await env.client.get("/api/tk/overviews/nope", headers=h)).status_code == 404
    # the requests went to Zammad in the operator's name with ?view=
    assert any(p == "/api/v1/ticket_overviews" for _, p in env.zammad.requests)


async def test_overview_cache_is_forgotten_after_a_change(env):
    t = seed(env)
    h = await env.login("anna")
    d = (await env.client.get("/api/tk/overviews/my_assigned", headers=h)).json()
    assert d["total"] == 2
    r = await env.client.patch(f"/api/tk/tickets/{t['u1']['id']}", json={"owner_id": 10}, headers=h)
    assert r.status_code == 200, r.text
    d = (await env.client.get("/api/tk/overviews/my_assigned", headers=h)).json()
    assert d["total"] == 3


async def test_tabs_and_drafts(env):
    seed(env)
    h = await env.login("anna")
    # opening the same ticket twice keeps one tab
    for _ in range(2):
        r = await env.client.post("/api/tk/tabs", json={"ticket_id": 100, "number": "31100", "title": "Alarm Audit"}, headers=h)
        assert r.status_code == 200
    tabs = (await env.client.get("/api/tk/tabs", headers=h)).json()["tabs"]
    assert len(tabs) == 1 and tabs[0]["kind"] == "ticket" and tabs[0]["number"] == "31100"
    # a draft: nothing in Zammad yet
    before = len(env.zammad.tickets)
    r = await env.client.post("/api/tk/drafts", json={"data": {"title": "Ecoville VPN"}}, headers=h)
    assert r.status_code == 200, r.text
    draft = r.json()
    assert draft["kind"] == "draft" and draft["draft"]["group"] == "Users" and len(env.zammad.tickets) == before
    # autosave merges
    r = await env.client.put(f"/api/tk/drafts/{draft['id']}", json={"data": {"body": "094950442", "tags": "vpn, ecoville"}}, headers=h)
    assert r.json()["draft"]["title"] == "Ecoville VPN" and r.json()["draft"]["tags"] == ["vpn", "ecoville"]
    # Create refuses until the required fields are there (like the * in Zammad)
    r = await env.client.post(f"/api/tk/drafts/{draft['id']}/create", json={}, headers=h)
    assert r.status_code == 422
    missing = r.json()["detail"]["missing"]
    assert set(missing) == {"customer", "state", "priority"}
    await env.client.put(f"/api/tk/drafts/{draft['id']}", json={"data": {
        "customer": {"id": 50, "name": "Иван"}, "state": "open", "priority": "2 normal", "owner_id": 10}}, headers=h)
    r = await env.client.post(f"/api/tk/drafts/{draft['id']}/create", json={}, headers=h)
    assert r.status_code == 200, r.text
    res = r.json()
    tid = res["ticket"]["id"]
    zt = env.zammad.tickets[tid]
    assert zt["title"] == "Ecoville VPN" and zt["owner_id"] == 10 and env.zammad.state_of(tid) == "open"
    assert env.zammad.tags[tid] == ["vpn", "ecoville"]
    art = [a for a in env.zammad.articles if a.get("ticket_id") == tid][0]
    assert art["body"] == "094950442" and art["created_by_id"] == 10  # in Anna's name
    assert res["tab"]["kind"] == "ticket" and res["tab"]["ticket_id"] == tid and not res["owner_dropped"]
    # it is in "assigned to me" at once
    d = (await env.client.get("/api/tk/overviews/my_assigned", headers=h)).json()
    assert tid in [x["id"] for x in d["tickets"]]
    # a draft of somebody else is not mine
    other = (await env.client.post("/api/tk/drafts", json={"data": {}}, headers=await env.login("boris"))).json()
    assert (await env.client.put(f"/api/tk/drafts/{other['id']}", json={"data": {"title": "x"}}, headers=h)).status_code == 404
    # closing a tab
    r = await env.client.delete(f"/api/tk/tabs/{res['tab']['id']}", headers=h)
    assert all(x["id"] != res["tab"]["id"] for x in r.json()["tabs"])
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(AuditLog).where(AuditLog.action == "ticket_created"))).scalars().first().details["from_draft"]


async def test_draft_owner_without_group_access_is_reported(env):
    seed(env)
    h = await env.login("anna")
    d = (await env.client.post("/api/tk/drafts", json={"data": {"title": "Sales question", "customer": {"id": 50}, "group": "Sales",
                                                                "state": "new", "priority": "2 normal", "owner_id": 11}}, headers=h)).json()
    r = await env.client.post(f"/api/tk/drafts/{d['id']}/create", json={}, headers=h)
    assert r.status_code == 200, r.text
    assert r.json()["owner_dropped"]  # Zammad resets an owner without full access to the group


async def test_tags_and_staged_update(env):
    t = seed(env)
    h = await env.login("anna")
    tid = t["a1"]["id"]
    r = await env.client.patch(f"/api/tk/tickets/{tid}", json={"tags": ["vpn", "urgent"], "state": "pending reminder",
                                                              "priority": "3 high"}, headers=h)
    assert r.status_code == 200, r.text
    assert sorted(r.json()["ticket"]["tags"]) == ["urgent", "vpn"]
    assert env.zammad.state_of(tid) == "pending reminder" and env.zammad.tickets[tid]["priority_id"] == 3
    r = await env.client.patch(f"/api/tk/tickets/{tid}", json={"tags": ["vpn"]}, headers=h)  # only tags
    assert r.json()["ticket"]["tags"] == ["vpn"]
    assert (await env.client.get("/api/tk/tags?term=v", headers=h)).json()["tags"] == ["vpn"]
    # the Zammad calls had the documented shapes
    tags_add = [r for r in env.zammad.requests if r[1] == "/api/v1/tags/add"]
    assert tags_add and [r for r in env.zammad.requests if r == ("DELETE", "/api/v1/tags/remove")]


async def test_assignees_of_a_group(env):
    seed(env)
    await env.services.directory.sync(full=True)
    h = await env.login("anna")
    r = await env.client.get("/api/tk/assignees?group=Users", headers=h)
    assert r.status_code == 200, r.text
    people = r.json()["people"]
    assert people[0]["me"] and {p["id"] for p in people} >= {10, 11}


async def test_admin_manages_zammad_groups(env):
    await env.services.directory.sync(full=True)
    h = await env.login("root")
    assert (await env.client.get("/api/admin/zammad-groups", headers=await env.login("anna"))).status_code == 403
    r = await env.client.get("/api/admin/zammad-groups", headers=h)
    assert r.status_code == 200, r.text
    users = next(g for g in r.json()["groups"] if g["name"] == "Users")
    assert {m["id"] for m in users["members"]} >= {10, 11}
    for name in ("Cabling", "IT Security", "IT Support"):
        r = await env.client.post("/api/admin/zammad-groups", json={"name": name}, headers=h)
        assert r.status_code == 200, r.text
    names = [g["name"] for g in r.json()["groups"]]
    assert {"Cabling", "IT Security", "IT Support"} <= set(names)
    assert (await env.client.post("/api/admin/zammad-groups", json={"name": "Cabling"}, headers=h)).status_code == 422
    cab = next(g for g in r.json()["groups"] if g["name"] == "Cabling")
    # Anna gets full access → she can own Cabling tickets; her other access is kept
    r = await env.client.put(f"/api/admin/zammad-groups/{cab['id']}/members/10", json={"access": True}, headers=h)
    assert r.status_code == 200, r.text
    cab = next(g for g in r.json()["groups"] if g["name"] == "Cabling")
    assert [m["id"] for m in cab["members"]] == [10]
    assert env.zammad.users[10]["groups"] == {"Users": ["full"], "Cabling": ["full"]}
    # rename + switch off
    r = await env.client.put(f"/api/admin/zammad-groups/{cab['id']}", json={"name": "Cabling & Network", "active": False}, headers=h)
    g = next(g for g in r.json()["groups"] if g["id"] == cab["id"])
    assert g["name"] == "Cabling & Network" and not g["active"]
    # take the access back
    r = await env.client.put(f"/api/admin/zammad-groups/{cab['id']}/members/10", json={"access": False}, headers=h)
    assert env.zammad.users[10]["groups"] == {"Users": ["full"]}
    # what went to Zammad: the whole map, ids as keys (HasGroups#group_ids_access_map=)
    async with env.services.db.sessionmaker() as s:
        acts = [a.action for a in (await s.execute(select(AuditLog))).scalars().all()]
    assert "zammad_group_saved" in acts and "zammad_group_access" in acts


async def test_tab_limit_keeps_drafts(env):
    h = await env.login("anna")
    d = (await env.client.post("/api/tk/drafts", json={"data": {"title": "keep me"}}, headers=h)).json()
    for i in range(45):
        await env.client.post("/api/tk/tabs", json={"ticket_id": 1000 + i}, headers=h)
    tabs = (await env.client.get("/api/tk/tabs", headers=h)).json()["tabs"]
    assert len([x for x in tabs if x["kind"] == "ticket"]) <= 40 and any(x["id"] == d["id"] for x in tabs)
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(TicketTab).where(TicketTab.kind == "draft"))).scalars().first().title == "keep me"


async def test_draft_from_a_call(env):
    """v3.14: «New ticket» on an answered call — the draft carries the number and the call; the ticket gets the call
    details (phone article), the call gets the ticket; a call of another operator is not used."""
    from app.models import CallRecord
    seed(env)
    async with env.services.db.sessionmaker() as s:
        mine = CallRecord(linkedid="L-1", agent_id=1, caller_number="+37491123456", extension="101", queue="400", state="answered")
        other = CallRecord(linkedid="L-2", agent_id=2, caller_number="+37477000000", extension="102", state="answered")
        s.add_all([mine, other])
        await s.commit()
        mine_id, other_id = mine.id, other.id
    h = await env.login("anna")
    data = {"title": "Router does not work", "customer": {"id": 50}, "group": "Users", "state": "new", "priority": "2 normal",
            "phone": "+374 91 12-34-56", "call_id": mine_id, "body": "Customer says the router blinks red"}
    d = (await env.client.post("/api/tk/drafts", json={"data": data}, headers=h)).json()
    assert d["draft"]["phone"] == "+37491123456" and d["draft"]["call_id"] == mine_id
    r = await env.client.post(f"/api/tk/drafts/{d['id']}/create", json={}, headers=h)
    assert r.status_code == 200, r.text
    tid = r.json()["ticket"]["id"]
    art = [a for a in env.zammad.articles if a.get("ticket_id") == tid][0]
    assert art["type"] == "phone" and "router blinks red" in art["body"] and "+37491123456" in art["body"] and "400" in art["body"]
    async with env.services.db.sessionmaker() as s:
        assert (await s.get(CallRecord, mine_id)).ticket_id == tid
    # someone else's call: not linked, only the number goes into the ticket
    d = (await env.client.post("/api/tk/drafts", json={"data": {**data, "call_id": other_id, "phone": "+37477000000"}}, headers=h)).json()
    tid2 = (await env.client.post(f"/api/tk/drafts/{d['id']}/create", json={}, headers=h)).json()["ticket"]["id"]
    art = [a for a in env.zammad.articles if a.get("ticket_id") == tid2][0]
    assert "+37477000000" in art["body"] and "400" not in art["body"]
    async with env.services.db.sessionmaker() as s:
        assert (await s.get(CallRecord, other_id)).ticket_id is None


async def test_tabs_show_the_stage_of_each_ticket(env):
    """v3.17.1: the open-ticket list colours each tab by the ticket's stage (closed = green in the UI)."""
    t = seed(env)
    h = await env.login("anna")
    for key in ("a1", "a2", "a3"):
        await env.client.post("/api/tk/tabs", json={"ticket_id": t[key]["id"]}, headers=h)
    await env.client.post("/api/tk/tabs", json={"ticket_id": 99999}, headers=h)  # gone from Zammad: stays unknown
    await env.client.post("/api/tk/drafts", json={"data": {"title": "draft"}}, headers=h)
    plain = (await env.client.get("/api/tk/tabs", headers=h)).json()["tabs"]
    assert all("category" not in x for x in plain)  # no Zammad calls unless asked
    tabs = {x["ticket_id"]: x for x in (await env.client.get("/api/tk/tabs?with_state=true", headers=h)).json()["tabs"] if x["kind"] == "ticket"}
    assert tabs[t["a1"]["id"]]["category"] == "open" and tabs[t["a2"]["id"]]["category"] == "new"
    assert tabs[t["a3"]["id"]]["category"] == "closed" and tabs[t["a3"]["id"]]["state"] == "closed"
    assert "category" not in tabs[99999]
