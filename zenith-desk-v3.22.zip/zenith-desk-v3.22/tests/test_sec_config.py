"""SEC-02 (finding C): production fails closed with a missing / published / placeholder / weak JWT_SECRET or a
placeholder database password; development stays usable; what a changed key does to sessions and encrypted data."""
import os
import secrets
import subprocess
import sys
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.config import Settings
from app.crypto import MessageCipher, SecretBox

ROOT = Path(__file__).resolve().parents[1]
DB = "sqlite+aiosqlite:///:memory:"
STRONG = secrets.token_hex(32)


def make(**kw):
    return Settings(_env_file=None, database_url=kw.pop("database_url", DB), **kw)


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    for k in ("JWT_SECRET", "ZD_ENV", "DATABASE_URL"):
        monkeypatch.delenv(k, raising=False)


@pytest.mark.parametrize("value", [
    None,                                              # not set at all → the published default
    "change-me-please-use-32+-random-chars",           # the default, given explicitly
    "CHANGE-ME-to-something-random-0123456789",        # a placeholder in any case
    "your-secret-here-0123456789abcdefghijkl",
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",        # 40 characters, 1 different
    "abababababababababababababababababababab",
    "test-secret-0123456789-abcdefghijklmnop",         # published in this repository (tests)
    "demo-secret-demo-secret-demo-secret",             # published (demo)
])
def test_production_refuses_insecure_secrets(value):
    kw = {} if value is None else {"jwt_secret": value}
    with pytest.raises(ValidationError) as e:
        make(**kw)
    msg = str(e.value)
    assert "refusing to start in production" in msg
    if value:
        # the reason names the problem; no piece of the secret reaches the log (pydantic would print a shortened copy)
        assert not any(value[i:i + 12] in msg for i in range(len(value) - 11)), msg


def test_empty_and_short_secrets_are_refused_in_every_mode():
    for env in ("production", "development"):
        with pytest.raises(ValidationError):
            make(jwt_secret="", zd_env=env)
        with pytest.raises(ValidationError):
            make(jwt_secret="short-but-random-Qx7", zd_env=env)


def test_a_strong_secret_starts():
    s = make(jwt_secret=STRONG)
    assert s.zd_env == "production" and s.jwt_secret == STRONG


def test_development_keeps_working_with_the_demo_values():
    s = make(zd_env="development")  # the default secret, only allowed when asked for explicitly
    assert s.jwt_secret.startswith("change-me")


def test_environment_variables_and_env_file_cannot_bypass_the_check(monkeypatch, tmp_path):
    monkeypatch.setenv("JWT_SECRET", "change-me-please-use-32+-random-chars")
    with pytest.raises(ValidationError):
        Settings(_env_file=None, database_url=DB)
    monkeypatch.delenv("JWT_SECRET")
    env_file = tmp_path / ".env"
    env_file.write_text("JWT_SECRET=changeme-changeme-changeme-changeme-1234\nZD_ENV=production\n")
    with pytest.raises(ValidationError):
        Settings(_env_file=str(env_file), database_url=DB)
    monkeypatch.setenv("ZD_ENV", "staging")  # unknown modes are not a way around it either
    with pytest.raises(ValidationError):
        Settings(_env_file=None, database_url=DB, jwt_secret=STRONG)


def test_placeholder_database_password_is_refused_in_production():
    with pytest.raises(ValidationError) as e:
        make(jwt_secret=STRONG, database_url="postgresql+asyncpg://aws:change-me@db:5432/aws?ssl=verify-full")
    assert "database password" in str(e.value) and "aws:change" not in str(e.value) and "postgresql" not in str(e.value)
    assert make(jwt_secret=STRONG, database_url=f"postgresql+asyncpg://aws:{secrets.token_hex(16)}@db:5432/aws").zd_env == "production"
    for weak in ("aws:aws", "app:app", "aws:CHANGEME"):  # the built-in default URL and user = password
        with pytest.raises(ValidationError):
            make(jwt_secret=STRONG, database_url=f"postgresql+asyncpg://{weak}@db:5432/aws")
    with pytest.raises(ValidationError):  # nothing set at all → the default aws:aws@localhost
        Settings(_env_file=None, jwt_secret=STRONG)


def test_the_server_does_not_start_without_a_proper_secret(tmp_path):
    env = {k: v for k, v in os.environ.items() if k not in ("JWT_SECRET", "ZD_ENV")}
    env["DATABASE_URL"] = f"sqlite+aiosqlite:///{tmp_path}/x.db"
    code = "from app.config import get_settings; from app.main import create_app; create_app(get_settings())"
    r = subprocess.run([sys.executable, "-c", code], cwd=tmp_path, env={**env, "PYTHONPATH": str(ROOT)}, capture_output=True, text=True, timeout=60)
    assert r.returncode != 0 and "refusing to start in production" in r.stderr
    r = subprocess.run([sys.executable, "-c", code], cwd=tmp_path, env={**env, "PYTHONPATH": str(ROOT), "JWT_SECRET": STRONG},
                       capture_output=True, text=True, timeout=60)
    assert r.returncode == 0, r.stderr[-500:]


@pytest.mark.asyncio
async def test_rotating_the_key_ends_sessions_and_old_data_needs_the_old_key(env):
    """A new JWT_SECRET: every session signed with the old one is refused, and secrets / messages encrypted with the
    old key cannot be read with the new one — the safe way is backup → new key → restore (re-encrypts), see
    SECURITY_FIXES.md «Key rotation»."""
    h = await env.login("anna")
    assert (await env.client.get("/api/auth/me", headers=h)).status_code == 200
    old = env.services.settings.jwt_secret
    env.services.settings.jwt_secret = STRONG
    try:
        assert (await env.client.get("/api/auth/me", headers=h)).status_code == 401
    finally:
        env.services.settings.jwt_secret = old
    assert (await env.client.get("/api/auth/me", headers=h)).status_code == 200
    assert SecretBox(STRONG).decrypt(SecretBox(old).encrypt("zammad-token")) is None
    sealed = MessageCipher(old).seal("hello")
    assert MessageCipher(old).open(sealed) == "hello" and MessageCipher(STRONG).open(sealed) != "hello"
