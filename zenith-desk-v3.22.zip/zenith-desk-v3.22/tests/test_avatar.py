"""v3.12 — account picture (photo or initials) and the interface style preference."""
import io

from sqlalchemy import select

from app.models import AgentAvatar, AgentMapping, AuditLog

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 64
WEBP = b"RIFF\x24\x00\x00\x00WEBPVP8 " + b"\x00" * 64


async def me(env, h) -> dict:
    return (await env.client.get("/api/auth/me", headers=h)).json()


async def test_default_is_initials(env):
    h = await env.login("anna")
    u = await me(env, h)
    assert u["avatar_mode"] == "initials" and u["avatar_url"] is None and not u["has_photo"]
    assert "first_name" in u and "last_name" in u  # the initials come from the first and last name


async def test_upload_switch_and_delete(env):
    h = await env.login("anna")
    r = await env.client.put("/api/agents/me/avatar", content=PNG, headers={**h, "Content-Type": "image/png"})
    assert r.status_code == 200, r.text
    v = r.json()
    assert v["avatar_mode"] == "photo" and v["has_photo"] and v["avatar_url"].startswith("/api/avatars/")
    # the picture is served without a session (random key), with its real type and safe headers
    pic = await env.client.get(v["avatar_url"])
    assert pic.status_code == 200 and pic.content == PNG
    assert pic.headers["content-type"] == "image/png" and pic.headers["x-content-type-options"] == "nosniff"
    assert "immutable" in pic.headers["cache-control"]
    # colleagues see it in the team chat
    contacts = (await env.client.get("/api/chat/contacts?q=anna", headers=await env.login("boris"))).json()["contacts"]
    assert contacts[0]["avatar_url"] == v["avatar_url"]
    # back to the initials: the photo is kept and can be shown again
    r = await env.client.put("/api/agents/me/avatar/mode", json={"mode": "initials"}, headers=h)
    assert r.json() == {"avatar_mode": "initials", "avatar_url": None, "has_photo": True}
    assert (await env.client.get(v["avatar_url"])).status_code == 200
    r = await env.client.put("/api/agents/me/avatar/mode", json={"mode": "photo"}, headers=h)
    assert r.json()["avatar_url"] == v["avatar_url"]
    # a new upload gets a new address (old one disappears: browsers never show a stale cached picture)
    r2 = (await env.client.put("/api/agents/me/avatar", content=JPEG, headers=h)).json()
    assert r2["avatar_url"] != v["avatar_url"]
    assert (await env.client.get(v["avatar_url"])).status_code == 404
    assert (await env.client.get(r2["avatar_url"])).headers["content-type"] == "image/jpeg"
    # delete
    r = await env.client.delete("/api/agents/me/avatar", headers=h)
    assert r.json() == {"avatar_mode": "initials", "avatar_url": None, "has_photo": False}
    assert (await env.client.get(r2["avatar_url"])).status_code == 404
    r = await env.client.put("/api/agents/me/avatar/mode", json={"mode": "photo"}, headers=h)
    assert r.status_code == 409
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(AgentAvatar))).scalars().all() == []
        acts = (await s.execute(select(AuditLog.action).where(AuditLog.action == "avatar_changed"))).scalars().all()
    assert len(acts) == 5


async def test_rejects_wrong_pictures(env):
    h = await env.login("anna")
    svg = b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'
    r = await env.client.put("/api/agents/me/avatar", content=svg, headers={**h, "Content-Type": "image/png"})
    assert r.status_code == 415  # the bytes decide, not the header
    assert (await env.client.put("/api/agents/me/avatar", content=b"", headers=h)).status_code == 415
    big = io.BytesIO(PNG + b"\x00" * (1024 * 1024))
    assert (await env.client.put("/api/agents/me/avatar", content=big.getvalue(), headers=h)).status_code == 413
    assert (await env.client.put("/api/agents/me/avatar", content=WEBP, headers=h)).status_code == 200
    assert (await env.client.put("/api/agents/me/avatar", content=PNG)).status_code == 401  # needs a session
    for bad in ("x", "../../etc/passwd", "g" * 32, "0" * 32):
        assert (await env.client.get(f"/api/avatars/{bad}")).status_code == 404


async def test_admin_removes_a_photo(env):
    h = await env.login("anna")
    url = (await env.client.put("/api/agents/me/avatar", content=PNG, headers=h)).json()["avatar_url"]
    root = await env.login("root")
    users = (await env.client.get("/api/admin/users", headers=root)).json()
    anna = next(u for u in users if u["username"] == "anna")
    assert anna["avatar_url"] == url and anna["has_photo"]
    assert (await env.client.delete(f"/api/admin/users/{anna['id']}/avatar", headers=h)).status_code == 403
    r = await env.client.delete(f"/api/admin/users/{anna['id']}/avatar", headers=root)
    assert r.status_code == 200 and r.json()["avatar_url"] is None
    assert (await me(env, h))["avatar_mode"] == "initials"
    assert (await env.client.get(url)).status_code == 404


async def test_style_preference(env):
    h = await env.login("anna")
    p = (await env.client.get("/api/agents/me/preferences", headers=h)).json()
    assert p["style"] == "flow" and p["panel"] == "docked" and p["pins"] == []  # v3.19: Flow is the default look
    r = await env.client.put("/api/agents/me/preferences", json={**p, "style": "studio"}, headers=h)
    assert r.status_code == 200 and r.json()["style"] == "studio"
    assert (await me(env, h))["prefs"]["style"] == "studio"
    r = await env.client.put("/api/agents/me/preferences", json={**p, "style": "neon"}, headers=h)
    assert r.status_code == 422
    r = await env.client.put("/api/agents/me/preferences", json={**p, "style": "studio", "panel": "popup"}, headers=h)
    assert r.status_code == 200 and r.json()["panel"] == "popup"
    assert (await env.client.put("/api/agents/me/preferences", json={**p, "panel": "left"}, headers=h)).status_code == 422
    async with env.services.db.sessionmaker() as s:
        assert (await s.get(AgentMapping, 1)).ui_prefs["style"] in ("studio", "classic")


async def test_pinned_sections(env):  # v3.19: quick access on the left rail — known sections, at most 5, no repeats
    h = await env.login("anna")
    p = (await env.client.get("/api/agents/me/preferences", headers=h)).json()
    pins = ["tickets", "chat", "mail", "whatsapp", "telegram"]
    r = await env.client.put("/api/agents/me/preferences", json={**p, "pins": pins}, headers=h)
    assert r.status_code == 200 and r.json()["pins"] == pins
    assert (await me(env, h))["prefs"]["pins"] == pins  # kept on the account: the same on any computer
    for bad in (pins + ["work"], ["tickets", "tickets"], ["settings"], ["<script>"]):
        assert (await env.client.put("/api/agents/me/preferences", json={**p, "pins": bad}, headers=h)).status_code == 422, bad
    assert (await me(env, h))["prefs"]["pins"] == pins
