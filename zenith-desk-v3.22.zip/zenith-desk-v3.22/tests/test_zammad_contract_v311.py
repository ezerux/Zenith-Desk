"""v3.11 contract: the new Zammad calls have the exact routes, verbs and parameters of the Zammad 7.2 source
(config/routes/ticket.rb, tag.rb, group.rb, user.rb; TicketOverviewsController#show; TagsController#add/#remove use
params[:object], params[:o_id], params[:item]; UsersController#update takes group_ids as {group_id => access})."""
import json

import httpx

from app.zammad import ZammadClient

ROUTES = {  # (verb, path) allowed by Zammad's routes for these features
    ("GET", "/api/v1/ticket_overviews"), ("GET", "/api/v1/tags"), ("POST", "/api/v1/tags/add"), ("DELETE", "/api/v1/tags/remove"),
    ("GET", "/api/v1/tag_search"), ("GET", "/api/v1/groups"), ("POST", "/api/v1/groups"), ("PUT", "/api/v1/groups/3"),
    ("GET", "/api/v1/users/10"), ("PUT", "/api/v1/users/10"),
}


async def test_v311_requests_match_zammad():
    seen: list[httpx.Request] = []

    def handle(req: httpx.Request) -> httpx.Response:
        seen.append(req)
        assert (req.method, req.url.path) in ROUTES, (req.method, req.url.path)
        if req.url.path == "/api/v1/ticket_overviews":
            if "view" in req.url.params:
                return httpx.Response(200, json={"assets": {}, "index": {"overview": {"id": 1, "name": "x", "view": "all_open"},
                                                                           "tickets": [], "count": 0}})
            return httpx.Response(200, json=[{"id": 1, "name": "x", "prio": 1, "link": "all_open", "count": 0}])
        if req.url.path == "/api/v1/tags":
            return httpx.Response(200, json={"tags": ["a"]})
        if req.url.path == "/api/v1/users/10":
            return httpx.Response(200, json={"id": 10, "group_ids": {"1": ["full"], "2": "read"}})
        if req.url.path == "/api/v1/tag_search":
            return httpx.Response(200, json=[{"id": 1, "value": "vpn"}])
        return httpx.Response(200, json={"id": 3, "name": "g"})

    z = ZammadClient("http://z", "tok", transport=httpx.MockTransport(handle))
    assert (await z.overviews(10))[0]["link"] == "all_open"
    await z.overview("all_open", 10)
    assert await z.tags(5, 10) == ["a"]
    await z.tag_add(5, "vpn", 10)
    await z.tag_remove(5, "vpn", 10)
    assert await z.tag_search("v", 10) == ["vpn"]
    await z.create_group({"name": "Cabling", "active": True, "note": ""})
    await z.update_group(3, {"name": "Cabling", "active": False, "note": ""})
    ids = await z.user_group_ids(10)
    assert ids == {"1": ["full"], "2": ["read"]}  # a single access string is normalised to a list
    await z.set_user_group_ids(10, {**ids, "3": ["full"]})
    await z.close()

    by = {(r.method, r.url.path, tuple(sorted(r.url.params.items()))): r for r in seen}
    # overviews are read in the operator's name ("From"; older Zammad: X-On-Behalf-Of)
    ov = [r for r in seen if r.url.path == "/api/v1/ticket_overviews"]
    assert all(r.headers["from"] == "10" and r.headers["x-on-behalf-of"] == "10" for r in ov)
    assert ov[1].url.params["view"] == "all_open"
    tag_get = next(r for r in seen if r.url.path == "/api/v1/tags")
    assert dict(tag_get.url.params) == {"object": "Ticket", "o_id": "5"}
    add = next(r for r in seen if r.url.path == "/api/v1/tags/add")
    assert json.loads(add.content) == {"object": "Ticket", "o_id": 5, "item": "vpn"}
    rem = next(r for r in seen if r.url.path == "/api/v1/tags/remove")
    assert dict(rem.url.params) == {"object": "Ticket", "o_id": "5", "item": "vpn"} and not rem.content
    put = next(r for r in seen if r.method == "PUT" and r.url.path == "/api/v1/users/10")
    assert json.loads(put.content) == {"group_ids": {"1": ["full"], "2": ["read"], "3": ["full"]}}
    grp = next(r for r in seen if r.method == "POST" and r.url.path == "/api/v1/groups")
    assert json.loads(grp.content)["name"] == "Cabling"
    assert by  # every request was checked against the route table above
