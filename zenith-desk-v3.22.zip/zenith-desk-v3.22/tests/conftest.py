import os
from dataclasses import dataclass

import httpx
import pytest
import pytest_asyncio

from app.config import Settings
from app.crypto import hash_password
from app.db import Database
from app.main import create_app
from app.models import AgentMapping, AgentState
from app.services import Services
from app.zammad import ZammadClient

from .fakes import FakePbx, FakeZammad

QUEUES = ["400", "401"]
PW = hash_password("pw")
IF1, IF2 = "Local/101@from-queue/n", "Local/102@from-queue/n"


async def fix_sequences(db: Database) -> None:
    """Rows inserted with explicit ids do not advance PostgreSQL sequences."""
    if db.engine.dialect.name != "postgresql":
        return
    from sqlalchemy import text
    async with db.engine.begin() as conn:
        await conn.execute(text("SELECT setval(pg_get_serial_sequence('agent_mapping', 'id'), "
                                "(SELECT COALESCE(MAX(id), 1) FROM agent_mapping))"))


def make_settings(tmp_path, **over) -> Settings:
    url = os.environ.get("TEST_DATABASE_URL") or f"sqlite+aiosqlite:///{tmp_path}/test.db"
    base = dict(
        database_url=url, jwt_secret="test-secret-0123456789-abcdefghijklmnop", zd_env="development", zammad_url="http://zammad.test", zammad_token="t",
        zammad_webhook_secret="hooksecret", managed_queues=",".join(QUEUES), retry_base_sec=1,
        zammad_complete_states="closed,pending close", ui_language="en", backup_dir=os.path.join(str(tmp_path), "backups"),
    )
    base.update(over)
    return Settings(_env_file=None, **base)


@dataclass
class Env:
    services: Services
    client: httpx.AsyncClient
    pbx: FakePbx
    zammad: FakeZammad
    settings: Settings
    tokens: dict

    async def login(self, login: str) -> dict:
        r = await self.client.post("/api/auth/login", json={"username": login, "password": "pw"})
        assert r.status_code == 200, r.text
        return {"Authorization": f"Bearer {r.json()['token']}"}


async def build_env(tmp_path, db: Database | None = None, pbx: FakePbx | None = None,
                    fz: FakeZammad | None = None, seed: bool = True, **over) -> Env:
    from app.api import auth_routes
    auth_routes._failures.clear()  # login lock-out is in-process state; isolate tests
    auth_routes._locked_noted.clear()
    settings = make_settings(tmp_path, **over)
    db = db or Database(settings.database_url)
    if seed:
        if settings.database_url.startswith("postgresql"):
            from app.db import Base
            async with db.engine.begin() as conn:
                await conn.run_sync(Base.metadata.drop_all)
        await db.create_all()
        async with db.sessionmaker() as s:
            s.add_all([
                AgentMapping(id=1, username="anna", password_hash=PW, zammad_user_id=10, display_name="Анна",
                             asterisk_interface=IF1, extension="101"),
                AgentMapping(id=2, username="boris", password_hash=PW, zammad_user_id=11, display_name="Борис",
                             asterisk_interface=IF2, extension="102"),
                AgentMapping(id=3, username="boss", password_hash=PW, zammad_user_id=20, display_name="Руководитель",
                             role="supervisor", level="manager"),
                AgentMapping(id=4, username="root", password_hash=PW, display_name="Admin", role="admin", level="admin",
                             enabled=False),
            ])
            await s.flush()
            s.add_all([AgentState(agent_id=i) for i in (1, 2, 3, 4)])
            await s.commit()
        await fix_sequences(db)
    fz = fz or FakeZammad()
    if seed:
        fz.add_user(10, "anna")
        fz.add_user(11, "boris")
        fz.add_user(20, "boss")
        fz.add_user(50, "client", firstname="Иван", phone="+7 (912) 345-67-89")
    pbx = pbx or FakePbx(QUEUES, [IF1, IF2])
    zc = ZammadClient(settings.zammad_url, settings.zammad_token, transport=fz.transport())
    services = Services(settings, db=db, zammad=zc, pbx=pbx)
    app = create_app(settings, services, background=False)
    app.state.services = services
    await services.start(background=False)
    client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test")
    return Env(services, client, pbx, fz, settings, {})


@pytest_asyncio.fixture
async def env(tmp_path):
    e = await build_env(tmp_path)
    yield e
    await e.client.aclose()
    # stop everything the test started (push notifications, mail IDLE, messenger downloads…), so no task outlives
    # the test's event loop with an open database transaction (that would block the next test's DROP TABLE)
    await e.services.stop()
    await e.services.db.dispose()


@pytest.fixture
def anyio_backend():
    return "asyncio"
