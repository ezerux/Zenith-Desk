"""SEC-05: live-update (SSE) connections are capped per user and in total, so one account cannot exhaust the
server's memory / file descriptors. Users: 1 anna, 2 boris, 3 boss, 4 root."""
import asyncio

import pytest


async def take(gen, n):
    out = []
    for _ in range(n):
        out.append(await gen.__anext__())
    return out


@pytest.mark.asyncio
async def test_broker_caps_per_user_and_total(env):
    b = env.services.broker
    b.max_per_user, b.max_total = 3, 4
    gens = [b.stream(1, False, heartbeat=60) for _ in range(3)]
    for g in gens:
        await take(g, 2)  # retry + hello: registered
    assert b.connections(1) == 3 and b.refusal(1) == "user"
    extra = b.stream(1, False, heartbeat=60)
    first = await extra.__anext__()
    assert "too_many" in first
    with pytest.raises(StopAsyncIteration):
        await extra.__anext__()
    assert b.connections(1) == 3  # the refused one was never registered
    other = b.stream(2, False, heartbeat=60)
    await take(other, 2)
    assert b.total() == 4 and b.refusal(3) == "total"
    for g in gens + [other]:
        await g.aclose()
    assert b.total() == 0 and b.refusal(1) is None  # closed streams free their place


@pytest.mark.asyncio
async def test_parallel_openings_cannot_slip_past_the_cap(env):
    b = env.services.broker
    b.max_per_user, b.max_total = 2, 100
    gens = [b.stream(1, False, heartbeat=60) for _ in range(10)]
    firsts = await asyncio.gather(*(g.__anext__() for g in gens))
    assert sum("too_many" in f for f in firsts) == 8 and b.connections(1) == 2
    for g in gens:
        await g.aclose()
    assert b.connections(1) == 0


@pytest.mark.asyncio
async def test_endpoint_answers_429_when_the_user_is_at_the_cap(env):
    b = env.services.broker
    b.max_per_user = 1
    anna = await env.login("anna")
    me = (await env.client.get("/api/auth/me", headers=anna)).json()
    held = b.stream(me["id"], False, heartbeat=60)
    await take(held, 2)
    try:
        r = await env.client.get("/api/events/stream", headers=anna)
        assert r.status_code == 429 and r.headers.get("retry-after") == "15"
        boris = await env.login("boris")  # another user is not affected
        bid = (await env.client.get("/api/auth/me", headers=boris)).json()["id"]
        assert b.refusal(bid) is None
    finally:
        await held.aclose()
    assert b.refusal(me["id"]) is None
