"""v3.17 security: encryption in transit and at rest, token kinds, limits, headers."""
import asyncio
import hashlib
import hmac
import ssl
import time

import jwt
import pytest
from sqlalchemy import select
from starlette.requests import Request

from app import tls
from app.auth import STREAM_PATH, current_agent, issue_stream_token, issue_token
from app.models import AgentMapping, AuditLog, MsgConversation, MsgFile
from app.serve import redirect_app

from .conftest import build_env
from .test_ami import FakeAsterisk


# ------------------------------------------------------------------ what counts as unencrypted
def test_is_local_and_url_problem():
    assert tls.is_local("localhost") and tls.is_local("127.0.0.5") and tls.is_local("[::1]") and tls.is_local("x.localhost")
    assert not tls.is_local("10.0.0.5") and not tls.is_local("zammad.example.com") and not tls.is_local("")
    assert tls.url_problem("zammad_url", "https://zammad.example.com") is None
    assert tls.url_problem("zammad_url", "http://127.0.0.1:3000") is None  # loopback never leaves the computer
    assert "unencrypted" in tls.url_problem("zammad_url", "http://zammad.example.com")
    assert tls.url_problem("phone_wss_url", "wss://pbx.example.com:8089/ws") is None
    assert tls.url_problem("phone_wss_url", "ws://pbx.example.com:8088/ws")
    assert tls.url_problem("recording_url_template", "http://pbx.example.com/rec/{file}")
    assert tls.url_problem("recording_url_template", "https://pbx.example.com/rec/{file}") is None
    assert tls.url_problem("public_url", "") is None


def test_plain_problems_lists_every_unencrypted_link():
    class Cfg:
        zammad_url, phone_wss_url, public_url = "http://zammad.example.com", "wss://pbx/ws", "https://desk.example.com"
        admin_alert_webhook_url = telegram_api_base = whatsapp_api_base = recording_url_template = ""
        ami_host, ami_port, ami_secret, ami_tls, ami_tls_verify, ami_tls_fingerprint = "10.0.0.5", 5038, "s", False, True, ""
        mail_enabled, mail_in_host, mail_smtp_host, mail_in_security, mail_smtp_security = True, "imap.example.com", "localhost", "none", "none"
        zammad_verify_tls, mail_verify_tls = False, True
        database_url = "postgresql+asyncpg://u:p@db.example.com/zd"
    keys = {p["key"] for p in tls.plain_problems(Cfg)}
    assert keys == {"zammad_url", "ami_tls", "mail_in_security", "zammad_verify_tls", "database_url"}
    Cfg.zammad_url, Cfg.ami_tls, Cfg.mail_in_security, Cfg.zammad_verify_tls = "https://zammad.example.com", True, "ssl", True
    Cfg.database_url += "?ssl=verify-full"
    assert tls.plain_problems(Cfg) == []
    Cfg.ami_tls_verify = False
    assert [p["key"] for p in tls.plain_problems(Cfg)] == ["ami_tls_verify"]  # TLS without any certificate check
    Cfg.ami_tls_fingerprint = "ab" * 32
    assert tls.plain_problems(Cfg) == []


# ------------------------------------------------------------------ certificates + pinning
def test_certificates(tmp_path):
    crt, key, made = tls.server_cert(tmp_path)
    assert made and (tmp_path / "server.key").stat().st_mode & 0o077 == 0
    assert tls.server_cert(tmp_path)[2] is False  # kept, not remade
    tls.make_pg_certs(tmp_path / "pg", owner_uid=None)
    hba = (tmp_path / "pg" / "pg_hba.conf").read_text()
    assert "hostnossl all all all reject" in hba and "hostssl all all all scram-sha-256" in hba
    assert (tmp_path / "pg" / "db.key").stat().st_mode & 0o077 == 0
    ctx = ssl.create_default_context(cafile=str(tmp_path / "pg" / "ca.crt"))  # the db certificate is signed by the CA
    assert ctx.get_ca_certs()


async def test_pinned_tls_connection(tmp_path):
    crt, key, _ = tls.server_cert(tmp_path)
    der = ssl.PEM_cert_to_DER_cert(open(crt).read())
    server = await asyncio.start_server(lambda r, w: w.close(), "127.0.0.1", 0, ssl=tls.server_context(crt, key))
    port = server.sockets[0].getsockname()[1]
    try:
        _, w = await asyncio.open_connection("127.0.0.1", port, ssl=tls.client_context(pin=tls.fingerprint(der)), server_hostname="localhost")
        tls.check_pin(w.get_extra_info("ssl_object"), tls.fingerprint(der).upper()[:10] + ":" + tls.fingerprint(der)[10:])
        assert w.get_extra_info("ssl_object").version() in ("TLSv1.2", "TLSv1.3")
        with pytest.raises(ssl.SSLError):
            tls.check_pin(w.get_extra_info("ssl_object"), "00" * 32)
        w.close()
        with pytest.raises(ssl.SSLError):  # without a pin the system CAs are required: a self-signed certificate is refused
            await asyncio.open_connection("127.0.0.1", port, ssl=tls.client_context(), server_hostname="localhost")
        old = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        old.check_hostname, old.verify_mode = False, ssl.CERT_NONE
        with pytest.warns(DeprecationWarning):
            old.maximum_version = ssl.TLSVersion.TLSv1_1
        with pytest.raises((ssl.SSLError, ConnectionError, OSError)):
            await asyncio.open_connection("127.0.0.1", port, ssl=old)
    finally:
        server.close()


async def test_ami_over_tls_with_pin(tmp_path):
    from app.ami import AMIClient
    crt, key, _ = tls.server_cert(tmp_path)
    fp = tls.fingerprint(ssl.PEM_cert_to_DER_cert(open(crt).read()))
    fake = FakeAsterisk()
    fake.server = await asyncio.start_server(fake.handle, "127.0.0.1", 0, ssl=tls.server_context(crt, key))
    port = fake.server.sockets[0].getsockname()[1]
    try:
        good = AMIClient("127.0.0.1", port, "u", "s3cret", action_timeout=2, tls=True, tls_fingerprint=fp)
        good.start()
        assert await good.wait_connected(3)
        await good.stop()
        bad = AMIClient("127.0.0.1", port, "u", "s3cret", action_timeout=1, tls=True, tls_fingerprint="11" * 32)
        bad.start()
        assert not await bad.wait_connected(1.5)
        assert "fingerprint" in bad.last_error
        await bad.stop()
        assert not any(a.get("Secret") for a in fake.actions[1:])  # the wrong server never saw the password
    finally:
        fake.server.close()


# ------------------------------------------------------------------ HTTP → HTTPS
async def test_http_only_redirects():
    app = redirect_app(8443, 443)
    sent = []

    async def receive():
        return {"type": "http.request", "body": b""}

    async def send(m):
        sent.append(m)
    await app({"type": "http", "headers": [(b"host", b"desk.example.com:8000")], "raw_path": b"/api/x", "query_string": b"a=1"}, receive, send)
    assert sent[0]["status"] == 308 and dict(sent[0]["headers"])[b"location"] == b"https://desk.example.com/api/x?a=1"
    assert sent[1]["body"] == b""
    sent.clear()
    await redirect_app(8443)({"type": "http", "headers": [(b"host", b"evil.com/@x")], "raw_path": b"/"}, receive, send)
    assert dict(sent[0]["headers"])[b"location"] == b"https://localhost:8443/"


# ------------------------------------------------------------------ settings refuse plain text
async def test_settings_refuse_unencrypted(env):
    h = await env.login("root")
    put = lambda v: env.client.put("/api/admin/settings", json={"values": v}, headers=h)  # noqa: E731
    r = await put({"zammad_url": "http://zammad.example.com"})
    assert r.status_code == 422 and "unencrypted" in r.json()["detail"]
    assert (await put({"phone_wss_url": "ws://pbx.example.com:8088/ws"})).status_code == 422
    assert (await put({"ami_host": "10.0.0.5", "ami_secret": "x"})).status_code == 422
    assert (await put({"ami_host": "10.0.0.5", "ami_secret": "x", "ami_tls": True})).status_code == 200
    assert (await put({"mail_in_host": "imap.example.com", "mail_in_security": "none"})).status_code == 422
    assert (await put({"zammad_url": "https://zammad.example.com"})).status_code == 200
    assert (await put({"zammad_url": "http://127.0.0.1:3000"})).status_code == 200  # loopback
    assert (await put({"allow_unencrypted": True, "zammad_url": "http://zammad.example.com"})).status_code == 200


# ------------------------------------------------------------------ tokens
def _req(path: str, query: bytes = b"") -> Request:
    return Request({"type": "http", "method": "GET", "path": path, "query_string": query, "headers": [],
                    "scheme": "https", "server": ("test", 443)})


async def test_token_kinds(env):
    sv = env.services
    async with sv.db.sessionmaker() as s:
        anna = await s.get(AgentMapping, 1)
    session, stream = issue_token(sv, anna), issue_stream_token(sv, anna)
    assert jwt.decode(stream, sv.settings.jwt_secret, algorithms=["HS256"])["exp"] - time.time() <= 61
    c = env.client
    # the stream ticket opens only the live stream; the session token never travels in an address
    assert (await c.get("/api/auth/me", headers={"Authorization": f"Bearer {stream}"})).status_code == 401
    assert (await c.get(f"/api/auth/me?token={session}")).status_code == 401
    assert (await c.get("/api/auth/me", headers={"Authorization": f"Bearer {session}"})).status_code == 200
    assert (await current_agent(_req(STREAM_PATH, f"token={stream}".encode()), None, sv)).id == 1
    for bad in (session, jwt.encode({"sub": "1", "typ": "stream"}, sv.settings.jwt_secret, algorithm="HS256"),  # no exp
                jwt.encode({"sub": "x", "typ": "stream", "exp": time.time() + 60}, sv.settings.jwt_secret, algorithm="HS256")):
        with pytest.raises(Exception) as e:
            await current_agent(_req(STREAM_PATH, f"token={bad}".encode()), None, sv)
        assert getattr(e.value, "status_code", None) == 401
    r = await c.post("/api/auth/stream-token", headers={"Authorization": f"Bearer {session}"})
    assert r.status_code == 200 and jwt.decode(r.json()["token"], sv.settings.jwt_secret, algorithms=["HS256"])["typ"] == "stream"
    # tokens issued before v3.17 (no typ) stay valid sessions until they expire
    old = jwt.decode(session, sv.settings.jwt_secret, algorithms=["HS256"])
    old.pop("typ")
    old_tok = jwt.encode(old, sv.settings.jwt_secret, algorithm="HS256")
    assert (await c.get("/api/auth/me", headers={"Authorization": f"Bearer {old_tok}"})).status_code == 200


# ------------------------------------------------------------------ headers, docs, limits
async def test_headers_docs_and_body_limit(tmp_path):
    e = await build_env(tmp_path, max_request_mb=1)
    try:
        h = await e.login("anna")
        r = await e.client.get("/api/auth/me", headers=h)
        assert r.headers["cache-control"] == "no-store"
        for p in ("/docs", "/redoc", "/openapi.json"):
            assert (await e.client.get(p)).status_code == 404
        big = b"x" * (1024 * 1024 + 10)
        r = await e.client.post("/api/auth/login", content=big, headers={"content-type": "application/json"})
        assert r.status_code == 413

        async def chunks():  # no Content-Length: counted while reading
            for _ in range(20):
                yield b"y" * 100_000
        r = await e.client.post("/api/auth/login", content=chunks(), headers={"content-type": "application/json"})
        assert r.status_code == 413
        assert (await e.client.get("/api/health")).status_code == 200
    finally:
        await e.client.aclose()
        await e.services.stop()
        await e.services.db.dispose()


# ------------------------------------------------------------------ webhooks
async def test_webhook_needs_a_signature(tmp_path):
    e = await build_env(tmp_path, zammad_webhook_secret="")
    try:
        body = b'{"ticket": {}}'
        assert (await e.client.post("/api/integrations/zammad/webhook", content=body)).status_code == 401
        e.services.settings.zammad_webhook_secret = "hooksecret"
        sig = "sha1=" + hmac.new(b"hooksecret", body, hashlib.sha1).hexdigest()
        assert (await e.client.post("/api/integrations/zammad/webhook", content=body, headers={"X-Hub-Signature": "sha1=00"})).status_code == 401
        r = await e.client.post("/api/integrations/zammad/webhook", content=body, headers={"X-Hub-Signature": sig})
        assert r.status_code == 200 and r.json()["status"] == "accepted"
    finally:
        await e.client.aclose()
        await e.services.stop()
        await e.services.db.dispose()


# ------------------------------------------------------------------ login
async def test_login_audit_and_ip_limit(env):
    for i in range(20):  # one address trying many invented logins (password spraying)
        r = await env.client.post("/api/auth/login", json={"username": f"user{i}", "password": "nope"})
        assert r.status_code == 401
    assert (await env.client.post("/api/auth/login", json={"username": "anna", "password": "pw"})).status_code == 429
    async with env.services.db.sessionmaker() as s:
        rows = (await s.execute(select(AuditLog).where(AuditLog.action == "login_failed"))).scalars().all()
    assert len(rows) == 20 and rows[0].details["known"] is False and rows[0].details["username"] == "user0"


# ------------------------------------------------------------------ messenger files at rest
async def test_messenger_files_encrypted_at_rest(env):
    sv = env.services
    payload = b"\x89PNG secret picture" * 100
    async with sv.db.sessionmaker() as s:
        conv = MsgConversation(channel="telegram", external_id="77", name="Ivan")
        s.add(conv)
        await s.flush()
        s.add(MsgFile(key="old1", conversation_id=conv.id, name="a.png", mime="image/png", size=len(payload), data=payload))
        await s.commit()
    assert await sv.encrypt_old_files() == 1
    assert await sv.encrypt_old_files() == 0  # once only
    async with sv.db.sessionmaker() as s:
        f = (await s.execute(select(MsgFile).where(MsgFile.key == "old1"))).scalars().one()
    assert f.data.startswith(b"ZDX1:") and payload not in f.data
    assert sv.cipher.open_bytes(f.data) == payload
    assert sv.cipher.open_bytes(payload) == payload  # a file from before v3.17 still opens


# ------------------------------------------------------------------ System status → Encryption
async def test_system_status_encryption(env):
    h = await env.login("root")
    enc = (await env.client.get("/api/admin/system", headers=h)).json()["encryption"]
    # the test client is loopback (127.0.0.1) and speaks http; the test Zammad URL is plain http
    assert enc["browser"] == "local" and {p["key"] for p in enc["problems"]} >= {"zammad_url"}
    assert "https" not in {p["key"] for p in enc["problems"]}
    await env.client.put("/api/admin/settings", json={"values": {"zammad_url": "https://zammad.example.com"}}, headers=h)
    c2 = type(env.client)(transport=env.client._transport, base_url="https://test")
    enc = (await c2.get("/api/admin/system", headers=h)).json()["encryption"]
    await c2.aclose()
    assert enc["browser"] == "https" and not [p for p in enc["problems"] if p["level"] == "error"]
    import httpx
    remote = httpx.AsyncClient(transport=httpx.ASGITransport(app=env.client._transport.app, client=("10.1.2.3", 5000)), base_url="http://desk")
    enc = (await remote.get("/api/admin/system", headers=h)).json()["encryption"]
    await remote.aclose()
    assert enc["browser"] == "plain" and enc["problems"][0]["key"] == "https"


# ------------------------------------------------------------------ v3.18 sign-ins of the server a backup came from
async def test_previous_session_keys(env):
    import json as _json
    from datetime import timedelta as _td

    from app.db import utcnow
    sv = env.services
    old = "the-old-servers-secret-0123456789-abcdefghijk"
    tok = jwt.encode({"sub": "1", "pv": __import__("app.auth", fromlist=["x"]).password_version(
        (await _agent(sv, 1))), "typ": "session", "exp": time.time() + 3600}, old, algorithm="HS256")
    me = lambda: env.client.get("/api/auth/me", headers={"Authorization": f"Bearer {tok}"})  # noqa: E731
    assert (await me()).status_code == 401  # unknown key
    sv.settings.previous_session_keys = _json.dumps([{"k": old, "until": (utcnow() + _td(hours=1)).isoformat()}])
    assert (await me()).status_code == 200
    stream = jwt.encode({"sub": "1", "typ": "stream", "exp": time.time() + 60}, old, algorithm="HS256")
    with pytest.raises(Exception) as e:  # stream tickets only ever come from this server
        await current_agent(_req(STREAM_PATH, f"token={stream}".encode()), None, sv)
    assert getattr(e.value, "status_code", None) == 401
    sv.settings.previous_session_keys = _json.dumps([{"k": old, "until": (utcnow() - _td(seconds=1)).isoformat()}])
    assert (await me()).status_code == 401  # kept only until those sign-ins expire
    sv.settings.previous_session_keys = "not json"
    assert (await me()).status_code == 401


async def _agent(sv, aid):
    async with sv.db.sessionmaker() as s:
        return await s.get(AgentMapping, aid)


async def test_certificate_moves_without_a_restart(tmp_path, monkeypatch):
    monkeypatch.delenv("TLS_CERT_FILE", raising=False)
    monkeypatch.setenv("TLS_DIR", str(tmp_path / "here"))
    here_crt, here_key, _ = tls.server_cert(tmp_path / "here")
    old_crt, old_key, _ = tls.server_cert(tmp_path / "old")
    ctx = tls.server_context(here_crt, here_key)
    monkeypatch.setattr(tls, "SERVING", [ctx])
    server = await asyncio.start_server(lambda r, w: w.close(), "127.0.0.1", 0, ssl=ctx)
    port = server.sockets[0].getsockname()[1]

    async def served() -> str:
        _, w = await asyncio.open_connection("127.0.0.1", port, ssl=tls.client_context(pin="x"), server_hostname="localhost")
        fp = tls.fingerprint(w.get_extra_info("ssl_object").getpeercert(binary_form=True))
        w.close()
        return fp
    try:
        fp_old = tls.fingerprint(ssl.PEM_cert_to_DER_cert(open(old_crt).read()))
        assert await served() != fp_old
        data = {"cert": open(old_crt).read(), "key": open(old_key).read()}
        assert tls.export_cert()["cert"] == open(here_crt).read()
        assert tls.import_cert(data) is True
        assert await served() == fp_old  # new connections get the old server's certificate at once
        assert tls.import_cert(data) is False  # already in place
        assert tls.import_cert({"cert": "garbage", "key": "x"}) is False and tls.import_cert(None) is False
        monkeypatch.setenv("TLS_CERT_FILE", "/etc/company.crt")  # the company's own certificate is never replaced
        assert tls.export_cert() is None and tls.import_cert(data) is False
    finally:
        server.close()
