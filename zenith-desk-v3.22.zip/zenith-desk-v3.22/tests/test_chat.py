"""Messenger (v3.0): conversations are stored, private, live, with unread counters and read receipts."""
import pytest


@pytest.mark.asyncio
async def test_conversation_is_stored_and_ordered(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    r = await env.client.post("/api/chat/1/messages", json={"body": "Anna, can you take #31100?"}, headers=boss)
    assert r.status_code == 200 and r.json()["from"] == 3 and r.json()["read_at"] is None
    await env.client.post("/api/chat/3/messages", json={"body": "Yes, on it"}, headers=anna)
    await env.client.post("/api/chat/3/messages", json={"body": "  line 1\nline 2  "}, headers=anna)
    msgs = (await env.client.get("/api/chat/1/messages", headers=boss)).json()["messages"]
    assert [m["body"] for m in msgs] == ["Anna, can you take #31100?", "Yes, on it", "line 1\nline 2"]
    # the same conversation from the other side
    assert len((await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"]) == 3
    # paging to older messages
    page = (await env.client.get(f"/api/chat/1/messages?limit=2", headers=boss)).json()
    assert page["has_more"] and len(page["messages"]) == 2
    older = (await env.client.get(f"/api/chat/1/messages?limit=2&before_id={page['messages'][0]['id']}", headers=boss)).json()
    assert [m["body"] for m in older["messages"]] == ["Anna, can you take #31100?"] and not older["has_more"]


@pytest.mark.asyncio
async def test_contacts_unread_and_read_receipts(env):
    anna, boss, boris = await env.login("anna"), await env.login("boss"), await env.login("boris")
    await env.client.post("/api/chat/1/messages", json={"body": "hi"}, headers=boss)
    await env.client.post("/api/chat/1/messages", json={"body": "are you there?"}, headers=boss)
    await env.client.post("/api/chat/1/messages", json={"body": "lunch?"}, headers=boris)
    c = (await env.client.get("/api/chat/contacts", headers=anna)).json()
    assert c["unread_total"] == 3
    first = c["contacts"][0]
    assert first["id"] == 2 and first["last"]["body"] == "lunch?" and first["unread"] == 1   # newest conversation first
    boss_row = next(x for x in c["contacts"] if x["id"] == 3)
    assert boss_row["unread"] == 2 and boss_row["position"] == "" and "online" in boss_row
    assert (await env.client.get("/api/chat/unread", headers=anna)).json() == {"unread": 3}
    # Anna opens the chat with the manager -> read receipts
    spy = []
    orig = env.services.broker.publish_agent
    env.services.broker.publish_agent = lambda aid, ev, data: (spy.append((aid, ev, data)), orig(aid, ev, data))
    assert (await env.client.post("/api/chat/3/read", headers=anna)).json() == {"read": 2}
    assert any(aid == 3 and ev == "chat_read" for aid, ev, _ in spy)          # the manager sees ✓✓
    msgs = (await env.client.get("/api/chat/1/messages", headers=boss)).json()["messages"]
    assert all(m["read_at"] for m in msgs)
    assert (await env.client.get("/api/chat/unread", headers=anna)).json() == {"unread": 1}
    # search
    found = (await env.client.get("/api/chat/contacts?q=бор", headers=anna)).json()["contacts"]
    assert [x["id"] for x in found] == [2]


@pytest.mark.asyncio
async def test_live_delivery_typing_and_validation(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    spy = []
    orig = env.services.broker.publish_agent
    env.services.broker.publish_agent = lambda aid, ev, data: (spy.append((aid, ev, data)), orig(aid, ev, data))
    await env.client.post("/api/chat/1/messages", json={"body": "ping"}, headers=boss)
    assert (1, "chat") in [(a, e) for a, e, _ in spy]                      # recipient gets it at once
    assert (3, "chat") in [(a, e) for a, e, _ in spy]                      # and the sender's other tabs
    await env.client.post("/api/chat/3/typing", headers=anna)
    assert (3, "chat_typing", {"from": 1, "name": "Анна"}) in spy  # v3.20: with the name of who is typing
    assert (await env.client.post("/api/chat/1/messages", json={"body": "   "}, headers=boss)).status_code == 422
    assert (await env.client.post("/api/chat/1/messages", json={"body": "x" * 4001}, headers=boss)).status_code == 422
    assert (await env.client.post("/api/chat/3/messages", json={"body": "me"}, headers=boss)).status_code == 400
    assert (await env.client.post("/api/chat/999/messages", json={"body": "hi"}, headers=boss)).status_code == 404


@pytest.mark.asyncio
async def test_conversations_are_private(env):
    anna, boss, root = await env.login("anna"), await env.login("boss"), await env.login("root")
    await env.client.post("/api/chat/1/messages", json={"body": "private"}, headers=boss)
    # even the administrator only sees conversations he is part of
    assert (await env.client.get("/api/chat/1/messages", headers=root)).json()["messages"] == []
    contacts = (await env.client.get("/api/chat/contacts", headers=root)).json()["contacts"]
    assert all(c["last"] is None for c in contacts)
    assert (await env.client.get("/api/chat/contacts")).status_code == 401


@pytest.mark.asyncio
async def test_profile_card(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    await env.client.post("/api/chat/1/messages", json={"body": "hi"}, headers=boss)
    p = (await env.client.get("/api/chat/1/profile", headers=boss)).json()
    assert p["name"] == "Анна" and p["extension"] == "101" and p["messages_total"] == 1 and p["state_label"]
    assert "member_since" in p and "last_seen" in p
