"""SEC-07: signing out revokes that session token (before: it stayed valid for jwt_ttl_hours). Other sessions of
the same user keep working; expired revocations are cleaned up. Users: 1 anna, 2 boris, 3 boss, 4 root."""
from datetime import timedelta

import jwt
import pytest
from sqlalchemy import func, select

from app.auth import revoke_session
from app.db import utcnow
from app.models import RevokedToken


@pytest.mark.asyncio
async def test_a_signed_out_token_is_refused(env):
    h = await env.login("anna")
    assert (await env.client.get("/api/auth/me", headers=h)).status_code == 200
    assert (await env.client.post("/api/auth/logout", headers=h)).status_code == 200
    for path in ("/api/auth/me", "/api/agents/me/state", "/api/chat/contacts"):
        assert (await env.client.get(path, headers=h)).status_code == 401, path
    assert (await env.client.post("/api/auth/stream-token", headers=h)).status_code == 401  # no new stream tickets
    assert (await env.client.post("/api/auth/logout", headers=h)).status_code == 401


@pytest.mark.asyncio
async def test_other_sessions_of_the_same_user_stay_signed_in(env):
    phone, desk = await env.login("anna"), await env.login("anna")
    assert phone != desk
    await env.client.post("/api/auth/logout", headers=phone)
    assert (await env.client.get("/api/auth/me", headers=phone)).status_code == 401
    assert (await env.client.get("/api/auth/me", headers=desk)).status_code == 200
    boss = await env.login("boss")
    assert (await env.client.get("/api/auth/me", headers=boss)).status_code == 200


@pytest.mark.asyncio
async def test_every_session_has_its_own_id(env):
    tokens = [(await env.login("anna"))["Authorization"][7:] for _ in range(3)]
    ids = {jwt.decode(t, options={"verify_signature": False})["jti"] for t in tokens}
    assert len(ids) == 3


@pytest.mark.asyncio
async def test_forged_or_foreign_tokens_cannot_revoke_anything(env):
    assert await revoke_session(env.services, "not-a-token") is False
    forged = jwt.encode({"sub": "1", "typ": "session", "jti": "x" * 32, "exp": utcnow() + timedelta(hours=1)},
                        "some-other-key-0123456789abcdef0123456789", algorithm="HS256")
    assert await revoke_session(env.services, forged) is False
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(func.count()).select_from(RevokedToken))).scalar() == 0


@pytest.mark.asyncio
async def test_expired_revocations_are_cleaned_up(env):
    h = await env.login("anna")
    await env.client.post("/api/auth/logout", headers=h)
    async with env.services.db.sessionmaker() as s:
        row = (await s.execute(select(RevokedToken))).scalars().one()
        row.expires_at = utcnow() - timedelta(minutes=1)
        await s.commit()
    done = await env.services.retention_cleanup()
    assert done.get("revoked_tokens") == 1


@pytest.mark.asyncio
async def test_sign_out_ends_the_open_live_streams(env):
    h = await env.login("anna")
    me = (await env.client.get("/api/auth/me", headers=h)).json()
    b = env.services.broker
    g = b.stream(me["id"], False, heartbeat=60)
    await g.__anext__(); await g.__anext__()
    await env.client.post("/api/auth/logout", headers=h)
    seen = []
    with pytest.raises(StopAsyncIteration):
        for _ in range(50):  # the "went offline" events queued before the close are still delivered
            seen.append(await g.__anext__())
    assert len(seen) < 50
    assert b.connections(me["id"]) == 0
