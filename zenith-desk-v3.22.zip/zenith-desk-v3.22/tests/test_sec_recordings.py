"""SEC-06: recording lookup matches the stored file name literally, serves only audio files from the
recording folder, and does not walk the whole archive."""

from app.api.tickets import find_recording


def make(tmp_path):
    base = tmp_path / "rec"
    day = base / "2026" / "10" / "26"
    day.mkdir(parents=True)
    (day / "q400-101-1.wav").write_bytes(b"RIFF1")
    (day / "q400-102-2.wav").write_bytes(b"RIFF2")
    (base / "notes.txt").write_text("not audio")
    (tmp_path / "outside.wav").write_bytes(b"RIFFX")
    return base


def test_real_names_are_found(tmp_path):
    base = make(tmp_path)
    assert find_recording(str(base), "q400-101-1.wav").read_bytes() == b"RIFF1"
    assert find_recording(str(base), "2026/10/26/q400-102-2.wav").read_bytes() == b"RIFF2"
    assert find_recording(str(base), str(base / "2026/10/26/q400-102-2.wav")).read_bytes() == b"RIFF2"


def test_wildcards_are_literal(tmp_path):
    base = make(tmp_path)
    for name in ("*.wav", "q400-1*", "q400-10?-1.wav", "q400-[0-9]*.wav", "**/*.wav"):
        assert find_recording(str(base), name) is None, name


def test_only_audio_inside_the_folder(tmp_path):
    base = make(tmp_path)
    assert find_recording(str(base), "notes.txt") is None
    assert find_recording(str(base), "../outside.wav") is None
    assert find_recording(str(base), str(tmp_path / "outside.wav")) is None
    (base / "2026" / "link.wav").symlink_to(tmp_path / "outside.wav")
    assert find_recording(str(base), "link.wav") is None


def test_search_depth_is_bounded(tmp_path):
    base = make(tmp_path)
    deep = base / "a" / "b" / "c" / "d"
    deep.mkdir(parents=True)
    (deep / "deep.wav").write_bytes(b"RIFF")
    assert find_recording(str(base), "deep.wav") is None


def test_recording_link_template_only_gives_web_links(tmp_path):
    """SEC-11: the browser opens this link (window.open); a javascript:/data: template must give no link."""
    from types import SimpleNamespace
    from app.calls import CallService
    from app.models import CallRecord
    c = CallRecord(id=7, linkedid="1.1", uniqueid="1.1", recording_file="q-101.wav")
    for tpl, ok in (("https://pbx.local/rec/{file}", True), ("/rec/{file}", True),
                    ("javascript:alert(document.cookie)//{file}", False), ("data:text/html,<script>1</script>{file}", False),
                    (" JavaScript:x{file}", False)):
        svc = CallService.__new__(CallService)
        svc.settings = SimpleNamespace(recording_dir="", recording_url_template=tpl)
        assert bool(svc.recording_url(c)) is ok, tpl
