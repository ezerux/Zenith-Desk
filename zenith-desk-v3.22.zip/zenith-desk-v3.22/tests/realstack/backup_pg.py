"""v3.10 — backup / restore on the real stack: PostgreSQL schema made by Alembic, the real server (uvicorn, every
background job running), two servers with DIFFERENT JWT_SECRET, restore over the HTTP API, a restart afterwards,
and the command-line restore into a third empty database.

    python tests/realstack/backup_pg.py   [postgresql://aws:aws@localhost]     (needs a PostgreSQL user that may CREATE DATABASE)
"""
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PG = sys.argv[1] if len(sys.argv) > 1 else "postgresql://aws:aws@localhost"
PY = sys.executable
PASS = "real-stack-backup-pw"
WORK = Path(os.environ.get("TMPDIR", "/tmp")) / f"zd-backup-real-{os.getpid()}"
OK: list[str] = []


def sh(*args, env=None, check=True) -> subprocess.CompletedProcess:
    r = subprocess.run(args, cwd=ROOT, env=env, capture_output=True, text=True, timeout=300)
    if check and r.returncode != 0:
        raise SystemExit(f"FAILED: {' '.join(args)}\n{r.stdout}\n{r.stderr}")
    return r


def psql(sql: str) -> None:
    sh("psql", f"{PG}/postgres", "-v", "ON_ERROR_STOP=1", "-qc", sql)


def server_env(db: str, secret: str, port: int) -> dict:
    return {**os.environ, "DATABASE_URL": f"{PG.replace('postgresql://', 'postgresql+asyncpg://')}/{db}", "JWT_SECRET": secret, "ZD_ENV": "development",
            "INITIAL_ADMIN_USERNAME": "admin", "INITIAL_ADMIN_PASSWORD": "Admin-pass-1", "BACKUP_DIR": str(WORK / db),
            "UI_LANGUAGE": "en", "PYTHONUNBUFFERED": "1", "PORT": str(port)}


class Server:
    def __init__(self, db: str, secret: str, port: int):
        self.db, self.port, self.env = db, port, server_env(db, secret, port)
        self.base = f"http://127.0.0.1:{port}"
        self.log = WORK / f"{db}.log"
        self.proc = None

    def migrate(self) -> None:
        psql(f"DROP DATABASE IF EXISTS {self.db}")
        psql(f"CREATE DATABASE {self.db}")
        sh(PY, "-m", "alembic", "upgrade", "head", env=self.env)

    def start(self) -> None:
        self.proc = subprocess.Popen([PY, "-m", "uvicorn", "app.main:get_app", "--factory", "--port", str(self.port)], cwd=ROOT,
                                     env=self.env, stdout=open(self.log, "a"), stderr=subprocess.STDOUT)  # noqa: SIM115
        for _ in range(100):
            try:
                if self.call("GET", "/api/health")["database"]:
                    return
            except Exception:  # noqa: BLE001
                time.sleep(0.2)
        raise SystemExit(f"server {self.db} did not start:\n{self.log.read_text()[-3000:]}")

    def stop(self) -> None:
        if self.proc:
            self.proc.terminate()
            self.proc.wait(20)
            self.proc = None

    def call(self, method, path, data=None, token="", raw=None, headers=None):
        body = raw if raw is not None else (json.dumps(data).encode() if data is not None else None)
        h = {"Content-Type": "application/octet-stream" if raw is not None else "application/json", **(headers or {})}
        if token:
            h["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(self.base + path, method=method, data=body, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = r.read()
                return data if path.startswith("/api/admin/backups/") and "/download" in path else json.loads(data or b"null")
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"{method} {path} → {e.code} {e.read()[:300]!r}") from e

    def login(self, user, pw):
        return self.call("POST", "/api/auth/login", {"username": user, "password": pw})["token"]


def check(cond, msg):
    if not cond:
        raise SystemExit("FAILED: " + msg)
    OK.append(msg)
    print("  PASS ", msg)


def main() -> int:
    WORK.mkdir(parents=True, exist_ok=True)
    a = Server("zd_backup_a", "server-A-secret-0123456789abcdefghijklmnop", 8131)
    b = Server("zd_backup_b", "server-B-secret-zyxwvutsrqponmlkjihgfedcba", 8132)
    try:
        # ---------------- server A with data
        a.migrate()
        a.start()
        adm = a.login("admin", "Admin-pass-1")
        for u in ({"first_name": "Anna", "username": "anna", "level": "level1", "password": "Anna-pass-1", "extension": "101",
                   "sip_password": "sip-anna-secret"},
                  {"first_name": "Boris", "username": "boris", "level": "level2", "password": "Boris-pass-1", "extension": "102"}):
            a.call("POST", "/api/admin/users", u, token=adm)
        a.call("PUT", "/api/admin/settings", {"values": {"zammad_token": "zammad-secret-token", "ami_secret": "ami-secret",
                                                         "phone_enabled": True, "phone_wss_url": "wss://pbx.example:8089/ws"}}, token=adm)
        users = {u["username"]: u["id"] for u in a.call("GET", "/api/admin/users", token=adm)}
        anna = a.login("anna", "Anna-pass-1")
        for i in range(250):
            a.call("POST", f"/api/chat/{users['boris']}/messages", {"body": f"сообщение {i} — confidential"}, token=anna)
        a.call("PUT", "/api/admin/backups/settings", {"values": {"backup_password": PASS, "backup_enabled": True}}, token=adm)
        v = a.call("POST", "/api/admin/backups", {"wait": True, "note": "real stack"}, token=adm)
        item = next(x for x in v["items"] if x["kind"] == "manual")
        check(item["rows"] > 250 and item["app_version"], f"backup on server A: {item['rows']} rows, {item['size']} bytes")
        # the scheduler of the running server makes the automatic copy of the last slot by itself (catch-up)
        for _ in range(60):
            v = a.call("GET", "/api/admin/backups", token=adm)
            if any(x["kind"] == "scheduled" for x in v["items"]):
                break
            time.sleep(0.5)
        check(any(x["kind"] == "scheduled" for x in v["items"]), "running scheduler made the automatic backup")
        url = a.call("POST", f"/api/admin/backups/{item['name']}/link", token=adm)["url"]
        blob = a.call("GET", url)
        check(blob[:5] == b"ZDBK\x01" and b"confidential" not in blob, "downloaded file is encrypted")
        a.stop()

        # ---------------- server B: other key, its own first admin, restore over the API
        b.migrate()
        b.start()
        badm = b.login("admin", "Admin-pass-1")
        up = b.call("PUT", "/api/admin/backups/upload?filename=from-a.zdb", raw=blob, token=badm)
        check(up["uploaded"]["name"] == "from-a.zdb", "uploaded to server B")
        r = b.call("POST", "/api/admin/backups/from-a.zdb/restore", {"password": PASS, "confirm": "RESTORE", "wait": True}, token=badm)
        res = r["job"]["result"]
        check(res["rekeyed"] and res["rekey_failed"] == 0, f"restored on server B with its own key: {res['rows']} rows")
        anna_b = b.login("anna", "Anna-pass-1")
        boris_b = b.login("boris", "Boris-pass-1")
        msgs = b.call("GET", f"/api/chat/{users['anna']}/messages?limit=200", token=boris_b)["messages"]
        check(len(msgs) == 200 and all("confidential" in m["body"] for m in msgs), "chat history readable on server B")
        cfg = b.call("GET", "/api/phone/config", token=anna_b)
        check("sip-anna-secret" in json.dumps(cfg), "SIP password readable on server B")
        groups = b.call("GET", "/api/admin/settings", token=b.login("admin", "Admin-pass-1"))["groups"]
        tok = [i for g in groups for i in g["items"] if i["key"] == "zammad_token"][0]
        check(tok["has_value"] and tok["source"] == "panel", "Zammad token restored")
        h = b.call("GET", "/api/health")
        check(h["database"], "server B healthy after the restore")
        # new data still gets ids (PostgreSQL sequences moved)
        b.call("POST", f"/api/chat/{users['boris']}/messages", {"body": "after restore"}, token=anna_b)
        check(True, "new rows after restore")
        b.stop()
        # restart: the restored settings decrypt with B's key, no errors
        b.start()
        b.stop()
        log = b.log.read_text()
        check("cannot decrypt" not in log and "Traceback" not in log, "restart after restore: no decrypt errors, no tracebacks")

        # ---------------- command line into a third, empty database (server stopped)
        c_env = server_env("zd_backup_c", "server-C-secret-0000000000000000000000000", 8133)
        psql("DROP DATABASE IF EXISTS zd_backup_c")
        psql("CREATE DATABASE zd_backup_c")
        sh(PY, "-m", "alembic", "upgrade", "head", env=c_env)
        f = WORK / "from-a.zdb"
        f.write_bytes(blob)
        r = sh(PY, "-m", "app.cli", "restore", str(f), "--yes", "--password", PASS, env=c_env)
        check("re-encrypted" in r.stdout, "command-line restore into an empty database")
        c = Server("zd_backup_c", c_env["JWT_SECRET"], 8133)
        c.env = c_env
        c.start()
        msgs = c.call("GET", f"/api/chat/{users['anna']}/messages", token=c.login("boris", "Boris-pass-1"))["messages"]
        check(msgs and "confidential" in msgs[-1]["body"], "server C starts on the restored data")
        r = sh(PY, "-m", "app.cli", "backup", "--password", PASS, env=c_env)
        check(Path(r.stdout.splitlines()[0]).exists(), "command-line backup on PostgreSQL")
        c.stop()
    finally:
        a.stop()
        b.stop()
        for db in ("zd_backup_a", "zd_backup_b", "zd_backup_c"):
            sh("psql", f"{PG}/postgres", "-qc", f"DROP DATABASE IF EXISTS {db} WITH (FORCE)", check=False)
    print(f"\n{len(OK)} checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
