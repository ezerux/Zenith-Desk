"""v3.11 — call routing by level against a REAL Asterisk 20.

    tests/realstack/asterisk.sh start
    python tests/realstack/routing_e2e.py

Queue 410 (strategy rrmemory, ringinuse=no) has four members — L1 Alice 111, L1 Bob 112, L2 Carol 121, L3 Dave 131 —
all with penalty 0, as FreePBX creates them. Zenith Desk (real AMI user `agent-state` with the documented permissions)
sets the penalties from the users' levels; then customer calls are placed into the queue and the test watches which
member Asterisk rings FIRST (AgentCalled):
  * everybody free → a Level 1 agent, and the next call → the other Level 1 agent (round robin);
  * both Level 1 on a call → Level 2; Level 2 on a call too → Level 3;
  * a Level 1 agent becomes free again → back to Level 1;
  * a Level 1 agent on break in Zenith Desk (paused in Asterisk) counts as busy;
  * the administrator changes a level → the penalty in Asterisk follows.
"""
import asyncio
import os
import re
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

from app.config import Settings  # noqa: E402
from app.crypto import hash_password  # noqa: E402
from app.db import Database  # noqa: E402
from app.models import AgentMapping, AgentState  # noqa: E402
from app.services import Services  # noqa: E402
from app.workflow import Actor  # noqa: E402
from app.zammad import ZammadClient  # noqa: E402
from tests.fakes import FakeZammad  # noqa: E402

AST = os.path.join(ROOT, "tests", "realstack", "asterisk.sh")
RESULTS: list[tuple[str, bool, str]] = []
AGENTS = [(11, "alice", "level1", "111"), (12, "bob", "level1", "112"), (21, "carol", "level2", "121"), (31, "dave", "level3", "131")]


def cli(cmd: str) -> str:
    out = subprocess.run([AST, "cli", cmd], capture_output=True, text=True, timeout=20).stdout
    return re.sub(r"\x1b\[[0-9;]*m", "", out)


def expect(cond, msg):
    if not cond:
        raise AssertionError(msg)


async def step(name, coro):
    try:
        await coro
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}", flush=True)
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, False, str(exc)[:400]))
        print(f"  FAIL  {name}: {str(exc)[:400]}", flush=True)


class Watcher:
    """The test's own AMI connection (user `tester`): places customer calls and records AgentCalled events."""

    def __init__(self):
        self.called: list[str] = []
        self.connected: list[str] = []
        self.task = None

    async def start(self):
        self.r, self.w = await asyncio.open_connection("127.0.0.1", 5038)
        await self.r.readline()
        self.w.write(b"Action: Login\r\nUsername: tester\r\nSecret: tester-secret\r\nEvents: agent\r\n\r\n")
        await self.w.drain()
        self.task = asyncio.create_task(self._read())

    async def _read(self):
        while True:
            block = (await self.r.readuntil(b"\r\n\r\n")).decode(errors="replace")
            d = dict(x.split(": ", 1) for x in block.strip().split("\r\n") if ": " in x)
            if d.get("Event") == "AgentCalled" and d.get("Queue") == "410":
                self.called.append(d.get("Interface") or d.get("MemberName", ""))
            if d.get("Event") == "AgentConnect" and d.get("Queue") == "410":
                self.connected.append(d.get("Interface") or d.get("MemberName", ""))

    async def call(self, n: int = 1) -> str:
        """One customer call into queue 410; returns the extension of the FIRST member Asterisk rings."""
        self.called.clear()
        self.connected.clear()
        self.w.write((f"Action: Originate\r\nChannel: Local/410@incoming\r\nContext: customer\r\nExten: s\r\nPriority: 1\r\n"
                      f"CallerID: Customer {n} <7900000{n:04d}>\r\nAsync: true\r\n\r\n").encode())
        await self.w.drain()
        end = time.monotonic() + 15
        while time.monotonic() < end and not self.called:
            await asyncio.sleep(0.1)
        expect(self.called, "Asterisk rang nobody")
        first = re.search(r"Local/(\d+)@", self.called[0]).group(1)
        end = time.monotonic() + 8  # let the agent answer: the round-robin position moves on answered calls
        while time.monotonic() < end and not self.connected:
            await asyncio.sleep(0.1)
        cli("channel request hangup all")
        end = time.monotonic() + 10
        while time.monotonic() < end and "410 has 0 calls" not in cli("queue show 410"):
            await asyncio.sleep(0.2)
        await asyncio.sleep(0.6)
        return first

    async def stop(self):
        if self.task:
            self.task.cancel()
        self.w.close()


def devstate(ext: str, state: str) -> None:
    cli(f"devstate change Custom:agent{ext} {state}")


def penalties() -> dict[str, int]:
    out = {}
    for ln in cli("queue show 410").splitlines():
        m = re.search(r"Local/(\d+)@routing-agents/n", ln)
        if m:
            p = re.search(r"with penalty (\d+)", ln)
            out[m.group(1)] = int(p.group(1)) if p else 0
    return out


async def main() -> int:
    subprocess.run([AST, "start"], check=True, timeout=60)
    cli("queue reset stats 410")
    for _, _, _, ext in AGENTS:  # FreePBX state: every member penalty 0
        cli(f"queue set penalty 0 on Local/{ext}@routing-agents/n in 410")
        cli(f"queue unpause member Local/{ext}@routing-agents/n queue 410")
        devstate(ext, "NOT_INUSE")
    tmp = tempfile.mkdtemp()
    settings = Settings(_env_file=None, database_url=f"sqlite+aiosqlite:///{tmp}/r.db", jwt_secret="routing-test-secret-0123456789abcdef", zd_env="development",
                        zammad_url="http://zammad.test", zammad_token="t", ami_host="127.0.0.1", ami_port=5038, ami_user="agent-state",
                        ami_secret="ami-secret-zenith", managed_queues="410", level_routing=True, respect_external_pause=False,
                        backup_dir=f"{tmp}/bk")
    db = Database(settings.database_url)
    await db.create_all()
    async with db.sessionmaker() as s:
        for uid, login, level, ext in AGENTS:
            s.add(AgentMapping(id=uid, username=login, password_hash=hash_password("pw"), display_name=login.title(), level=level,
                               role="operator", extension=ext, asterisk_interface=f"Local/{ext}@routing-agents/n", enabled=True))
        await s.flush()
        for uid, *_ in AGENTS:
            s.add(AgentState(agent_id=uid, manual_state="ready"))
        s.add(AgentMapping(id=1, username="admin", password_hash=hash_password("pw"), display_name="Admin", role="admin", level="admin", enabled=False))
        await s.commit()
    fz = FakeZammad()
    sv = Services(settings, db=db, zammad=ZammadClient(settings.zammad_url, "t", transport=fz.transport()))
    await sv.start(background=False)
    sv.ami.start()
    w = Watcher()
    sv.ami.on_disconnect = None  # the test stops the service while Asterisk keeps running: no "AMI lost" noise
    try:
        expect(await sv.ami.wait_connected(10), "AMI not connected")
        await w.start()

        async def set_penalties():
            await sv.engine.reconcile_all("test")
            p = penalties()
            expect(p == {"111": 0, "112": 0, "121": 1, "131": 2}, f"penalties in Asterisk: {p}")
            info = (await sv.pbx.queue_info(["410"]))[0]
            expect(info.strategy == "rrmemory" and len(info.members) == 4, f"queue info: {info}")
        await step("Zenith Desk sets the penalties from the levels (QueuePenalty, real AMI): L1=0, L2=1, L3=2", set_penalties())

        async def all_free():
            a = await w.call(1)
            b = await w.call(2)
            expect(a in ("111", "112") and b in ("111", "112"), f"rang {a}, {b} — Level 1 expected")
            expect(a != b, f"round robin: both calls rang {a} first")
        await step("Everybody free → Level 1 first; the next call → the other Level 1 agent (round robin)", all_free())

        async def l1_busy():
            devstate("111", "INUSE")
            first = await w.call(3)
            expect(first == "112", f"Alice on a call → Bob expected, rang {first}")
            devstate("112", "INUSE")
            first = await w.call(4)
            expect(first == "121", f"both Level 1 on a call → Level 2 (121) expected, rang {first}")
        await step("Level 1 agent on a call → the other Level 1; both Level 1 busy → Level 2", l1_busy())

        async def l2_busy():
            devstate("121", "INUSE")
            first = await w.call(5)
            expect(first == "131", f"Level 1 and 2 busy → Level 3 (131) expected, rang {first}")
        await step("Level 1 and Level 2 busy → Level 3", l2_busy())

        async def back_to_l1():
            devstate("112", "NOT_INUSE")
            first = await w.call(6)
            expect(first == "112", f"Bob free again → Bob expected, rang {first}")
        await step("A Level 1 agent is free again → calls go back to Level 1", back_to_l1())

        async def zenith_pause():
            await sv.workflow.set_manual_state(12, "break", Actor("agent", 12), "test")  # Bob on break in Zenith Desk
            expect("paused" in next(ln for ln in cli("queue show 410").splitlines() if "Local/112" in ln).lower(), "Bob not paused in Asterisk")
            devstate("121", "NOT_INUSE")
            first = await w.call(7)
            expect(first == "121", f"Alice on a call + Bob on break → Level 2 expected, rang {first}")
            await sv.workflow.set_manual_state(12, "ready", Actor("agent", 12), "test")
            first = await w.call(8)
            expect(first == "112", f"Bob ready again → Bob expected, rang {first}")
        await step("Level 1 agent on break in Zenith Desk (paused in Asterisk) is skipped like a busy one", zenith_pause())

        async def level_change():
            async with sv.db.sessionmaker() as s:
                m = await s.get(AgentMapping, 12)
                m.level = "level3"
                await s.commit()
            await sv.engine.recompute(12, "user_updated")
            p = penalties()
            expect(p.get("112") == 2, f"Bob → Level 3, penalty in Asterisk: {p}")
            devstate("111", "NOT_INUSE")
            first = await w.call(9)
            expect(first == "111", f"Alice (the only Level 1) expected, rang {first}")
        await step("Administrator changes a level → the penalty in Asterisk follows", level_change())

        async def routing_panel():
            from app.api.routing import routing
            r = await routing(None, sv)
            q = r["queues"][0]
            expect(q["strategy"] == "rrmemory" and not [x for x in q["warnings"] if x["kind"] in ("penalty", "strategy")], f"warnings: {q['warnings']}")
            expect(q["next_penalty"] == 0 and q["next_members"] == ["Alice"], f"next: {q['next_penalty']} {q['next_members']}")
        await step("Routing panel: strategy, penalties, who gets the next call", routing_panel())
    finally:
        await w.stop()
        for _, _, _, ext in AGENTS:
            devstate(ext, "NOT_INUSE")
        await sv.stop()
    failed = [r for r in RESULTS if not r[1]]
    print(f"\nReal Asterisk routing: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
