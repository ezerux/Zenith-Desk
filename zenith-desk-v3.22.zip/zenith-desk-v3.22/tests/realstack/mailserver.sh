#!/bin/sh
# A real company mail server for the integration tests: Dovecot (IMAP 993/143, POP3 995/110, IDLE, SPECIAL-USE) +
# Postfix (SMTP 25, submission 587 STARTTLS, smtps 465), domain company.test, mailboxes:
#   anna@company.test / anna-mail-1     boris@company.test / boris-mail-2     client@company.test / client-mail-3
# Usage: sh tests/realstack/mailserver.sh start|stop
set -e
D=/tmp/zd-mail
case "$1" in
stop)
  postfix stop 2>/dev/null || true
  doveadm -c $D/dovecot.conf stop 2>/dev/null || pkill -x dovecot 2>/dev/null || true
  exit 0 ;;
esac
mkdir -p $D/mail
[ -s /etc/postfix/main.cf ] || cp /usr/share/postfix/main.cf.debian /etc/postfix/main.cf
id vmail >/dev/null 2>&1 || useradd -r -u 5000 -d $D/mail -s /usr/sbin/nologin vmail 2>/dev/null || true
chown -R vmail:vmail $D/mail
[ -f $D/cert.pem ] || openssl req -x509 -newkey rsa:2048 -nodes -keyout $D/key.pem -out $D/cert.pem -days 30 -subj "/CN=mail.company.test" 2>/dev/null
chmod 644 $D/cert.pem $D/key.pem
cat > $D/users <<USERS
anna@company.test:{PLAIN}anna-mail-1:5000:5000::$D/mail/anna
boris@company.test:{PLAIN}boris-mail-2:5000:5000::$D/mail/boris
client@company.test:{PLAIN}client-mail-3:5000:5000::$D/mail/client
USERS
cat > $D/dovecot.conf <<CONF
protocols = imap pop3 lmtp
listen = 127.0.0.1
base_dir = $D/run
state_dir = $D/state
log_path = $D/dovecot.log
ssl = yes
ssl_cert = <$D/cert.pem
ssl_key = <$D/key.pem
disable_plaintext_auth = no
auth_mechanisms = plain login
mail_location = maildir:~/Maildir
first_valid_uid = 5000
passdb {
  driver = passwd-file
  args = scheme=PLAIN username_format=%u $D/users
}
userdb {
  driver = passwd-file
  args = username_format=%u $D/users
}
namespace inbox {
  inbox = yes
  separator = /
  mailbox Drafts {
    special_use = \\Drafts
    auto = subscribe
  }
  mailbox Sent {
    special_use = \\Sent
    auto = subscribe
  }
  mailbox Trash {
    special_use = \\Trash
    auto = subscribe
  }
  mailbox Junk {
    special_use = \\Junk
    auto = subscribe
  }
}
service imap-login {
  inet_listener imap {
    port = 143
  }
  inet_listener imaps {
    port = 993
    ssl = yes
  }
}
service pop3-login {
  inet_listener pop3 {
    port = 110
  }
  inet_listener pop3s {
    port = 995
    ssl = yes
  }
}
service lmtp {
  inet_listener lmtp {
    address = 127.0.0.1
    port = 24
  }
}
service auth {
  inet_listener {
    address = 127.0.0.1
    port = 12345
  }
}
protocol imap {
  imap_idle_notify_interval = 1 mins
}
CONF
mkdir -p $D/run $D/state
pkill -x dovecot 2>/dev/null || true
for i in 1 2 3 4 5 6 7 8 9 10; do pgrep -x dovecot >/dev/null || break; sleep 0.5; done
rm -f $D/run/master.pid
dovecot -c $D/dovecot.conf </dev/null >/dev/null 2>&1
postconf -e "myhostname = mail.company.test" "mydomain = company.test" "myorigin = company.test" "inet_interfaces = 127.0.0.1" \
  "inet_protocols = ipv4" "mydestination = localhost" "virtual_mailbox_domains = company.test" "virtual_transport = lmtp:inet:127.0.0.1:24" \
  "smtpd_tls_cert_file = $D/cert.pem" "smtpd_tls_key_file = $D/key.pem" "smtpd_tls_security_level = may" \
  "smtpd_sasl_type = dovecot" "smtpd_sasl_path = inet:127.0.0.1:12345" "smtpd_sasl_auth_enable = yes" \
  "smtpd_recipient_restrictions = permit_sasl_authenticated, permit_mynetworks, reject_unauth_destination" \
  "mynetworks = 127.0.0.0/8" "maillog_file_prefixes = /var,/dev/stdout,/tmp" "maillog_file = $D/postfix.log" "compatibility_level = 3.6" "smtputf8_enable = yes"
postconf -M submission/inet="submission inet n - n - - smtpd" 2>/dev/null; postconf -F "*/*/chroot = n"
postconf -P "submission/inet/syslog_name=postfix/submission" "submission/inet/smtpd_tls_security_level=encrypt" \
  "submission/inet/smtpd_sasl_auth_enable=yes" "submission/inet/smtpd_client_restrictions=permit_sasl_authenticated,reject" \
  "submission/inet/smtpd_recipient_restrictions=permit_sasl_authenticated,reject"
postconf -M smtps/inet="smtps inet n - n - - smtpd" 2>/dev/null; postconf -F "*/*/chroot = n"
postconf -P "smtps/inet/syslog_name=postfix/smtps" "smtps/inet/smtpd_tls_wrappermode=yes" "smtps/inet/smtpd_sasl_auth_enable=yes" \
  "smtps/inet/smtpd_client_restrictions=permit_sasl_authenticated,reject" "smtps/inet/smtpd_recipient_restrictions=permit_sasl_authenticated,reject"
newaliases 2>/dev/null || true
postfix stop 2>/dev/null || true
# daemons must not keep the caller's stdout open (a test waiting for EOF would hang)
postfix start </dev/null >"$D/postfix-start.log" 2>&1 || true
tail -1 "$D/postfix-start.log"
sleep 1
echo "mail server up: IMAP 993/143, POP3 995/110, SMTP 25/587/465 (company.test)"
