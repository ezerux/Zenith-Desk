"""v3.18 — call routing for managers against a REAL Asterisk 20.

    tests/realstack/asterisk.sh start
    python tests/realstack/callrouting_e2e.py

Queue 410 (four members: L1 Alice 111, L1 Bob 112, L2 Carol 121, L3 Dave 131 — custom device states make them busy).
Zenith Desk connects with its own AMI user (`agent-routing`: the documented permissions + write = config):
  * distribution: the manager chooses «longest idle» → UpdateConfig + QueueReload: Asterisk uses «leastrecent», the
    members, pauses and penalties stay; back to «round robin»;
  * VIP: a customer on the list is taken out of the queue (Redirect) and rings Dave's phone directly — answered;
    another VIP's person (Carol) does not answer → after the ring time the customer is back in the queue and is
    answered there;
  * overflow: Level 1 busy, Carol (Level 2) busy with a ticket (paused) → a customer waits; the rule «1 waiting → add
    Level 2» unpauses Carol in 410 and Asterisk rings her; when the queue is calm, she is paused again.
"""
import asyncio
import os
import re
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

from sqlalchemy import select  # noqa: E402

from app.config import Settings  # noqa: E402
from app.crypto import hash_password  # noqa: E402
from app.db import Database  # noqa: E402
from app.models import AgentMapping, AgentState, AuditLog, QueueCall  # noqa: E402
from app.services import Services  # noqa: E402
from app.workflow import Actor  # noqa: E402
from app.zammad import ZammadClient  # noqa: E402
from tests.fakes import FakeZammad  # noqa: E402

AST = os.path.join(ROOT, "tests", "realstack", "asterisk.sh")
RESULTS: list[tuple[str, bool, str]] = []
AGENTS = [(11, "alice", "level1", "111"), (12, "bob", "level1", "112"), (21, "carol", "level2", "121"), (31, "dave", "level3", "131")]


def cli(cmd: str) -> str:
    out = subprocess.run([AST, "cli", cmd], capture_output=True, text=True, timeout=20).stdout
    return re.sub(r"\x1b\[[0-9;]*m", "", out)


def expect(cond, msg):
    if not cond:
        raise AssertionError(msg)


async def step(name, coro):
    try:
        await coro
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}", flush=True)
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, False, str(exc)[:500]))
        print(f"  FAIL  {name}: {str(exc)[:500]}", flush=True)


def devstate(ext: str, state: str) -> None:
    cli(f"devstate change Custom:agent{ext} {state}")


def penalties() -> dict[str, int]:
    out = {}
    for ln in cli("queue show 410").splitlines():
        m = re.search(r"Local/(\d+)@routing-agents/n", ln)
        if m:
            p = re.search(r"with penalty (\d+)", ln)
            out[m.group(1)] = int(p.group(1)) if p else 0
    return out


def paused(ext: str) -> bool:
    ln = next((x for x in cli("queue show 410").splitlines() if f"Local/{ext}@" in x), "")
    return "paused" in ln.lower()


class Watcher:
    """The test's own AMI connection: places customer calls and records what Asterisk does."""

    def __init__(self):
        self.events: list[dict] = []
        self.task = None

    async def start(self):
        self.r, self.w = await asyncio.open_connection("127.0.0.1", 5038)
        await self.r.readline()
        self.w.write(b"Action: Login\r\nUsername: tester\r\nSecret: tester-secret\r\nEvents: call,agent\r\n\r\n")
        await self.w.drain()
        self.task = asyncio.create_task(self._read())

    async def _read(self):
        while True:
            block = (await self.r.readuntil(b"\r\n\r\n")).decode(errors="replace")
            d = dict(x.split(": ", 1) for x in block.strip().split("\r\n") if ": " in x)
            if d.get("Event") in ("AgentCalled", "AgentConnect", "DialBegin", "DialEnd", "QueueCallerJoin"):
                self.events.append(d)

    def call(self, number: str) -> None:
        self.events.clear()
        self.w.write((f"Action: Originate\r\nChannel: Local/410@incoming\r\nContext: customer\r\nExten: s\r\nPriority: 1\r\n"
                      f"CallerID: Customer <{number}>\r\nAsync: true\r\n\r\n").encode())

    async def wait(self, pred, timeout=15.0, what="event"):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            hit = next((e for e in self.events if pred(e)), None)
            if hit:
                return hit
            await asyncio.sleep(0.1)
        raise AssertionError(f"timeout waiting for {what}; seen: {[e.get('Event') + ':' + (e.get('Interface') or e.get('DestChannel') or '') for e in self.events][-12:]}")

    async def stop(self):
        if self.task:
            self.task.cancel()
        self.w.close()


async def hangup_all():
    cli("channel request hangup all")
    end = time.monotonic() + 10
    while time.monotonic() < end and "410 has 0 calls" not in cli("queue show 410"):
        await asyncio.sleep(0.2)
    await asyncio.sleep(0.6)


async def main() -> int:
    subprocess.run([AST, "stop"], timeout=60)  # a fresh configuration (the strategy test writes queues.conf)
    subprocess.run([AST, "start"], check=True, timeout=60)
    for _, _, _, ext in AGENTS:
        cli(f"queue set penalty 0 on Local/{ext}@routing-agents/n in 410")
        cli(f"queue unpause member Local/{ext}@routing-agents/n queue 410")
        devstate(ext, "NOT_INUSE")
    tmp = tempfile.mkdtemp()
    settings = Settings(_env_file=None, database_url=f"sqlite+aiosqlite:///{tmp}/r.db", jwt_secret="callrouting-test-secret-0123456789abcd", zd_env="development",
                        zammad_url="http://zammad.test", zammad_token="t", ami_host="127.0.0.1", ami_port=5038, ami_user="agent-routing",
                        ami_secret="ami-secret-routing", managed_queues="410", level_routing=True, respect_external_pause=False,
                        backup_dir=f"{tmp}/bk", routing_strategy_via_ami=True, routing_queues_file="queues.conf",
                        routing_dial_context="routing-direct", routing_queue_context="incoming")
    db = Database(settings.database_url)
    await db.create_all()
    async with db.sessionmaker() as s:
        for uid, login, level, ext in AGENTS:
            s.add(AgentMapping(id=uid, username=login, password_hash=hash_password("pw"), display_name=login.title(), level=level,
                               role="operator", extension=ext, asterisk_interface=f"Local/{ext}@routing-agents/n", enabled=True,
                               zammad_user_id=100 + uid))
        await s.flush()
        for uid, *_ in AGENTS:
            s.add(AgentState(agent_id=uid, manual_state="ready"))
        s.add(AgentMapping(id=1, username="boss", password_hash=hash_password("pw"), display_name="Boss", role="supervisor", level="manager",
                           enabled=False))
        await s.commit()
    fz = FakeZammad()
    for uid, login, *_ in AGENTS:
        fz.add_user(100 + uid, login)
    sv = Services(settings, db=db, zammad=ZammadClient(settings.zammad_url, "t", transport=fz.transport()))
    await sv.start(background=False)
    sv.ami.start()
    consumer = asyncio.create_task(sv._consume_ami_events())  # AMI events → call log + routing
    sv.ami.on_disconnect = None
    w = Watcher()
    async with db.sessionmaker() as s:
        boss = await s.get(AgentMapping, 1)
    try:
        expect(await sv.ami.wait_connected(10), "AMI not connected")
        await w.start()
        await sv.engine.reconcile_all("test")
        expect(penalties() == {"111": 0, "112": 0, "121": 1, "131": 2}, f"penalties: {penalties()}")

        async def distribution():
            await sv.routing.save({"queues": {"410": {"mode": "leastrecent"}}}, boss)
            out = cli("queue show 410")
            expect("'leastrecent' strategy" in out, f"strategy not applied: {out.splitlines()[0] if out else out}")
            expect(penalties() == {"111": 0, "112": 0, "121": 1, "131": 2}, f"members/penalties changed by the reload: {penalties()}")
            st = sv.routing.strategy_state["410"]
            expect(st.get("have") == "leastrecent" and not st.get("error"), f"state: {st}")
            # somebody else (FreePBX «Apply config») writes the file again → Zenith Desk puts its strategy back
            await sv.pbx.set_strategy("410", "ringall", "queues.conf")
            expect("'ringall' strategy" in cli("queue show 410"), "test could not change it")
            await sv.routing.keep_strategies()
            expect("'leastrecent' strategy" in cli("queue show 410"), "strategy not restored")
            await sv.routing.save({"queues": {"410": {"mode": "rrmemory"}}}, boss)
            expect("'rrmemory' strategy" in cli("queue show 410"), "back to round robin")
        await step("Distribution per queue: «longest idle» applied in Asterisk (UpdateConfig + QueueReload), members kept, restored after a foreign change", distribution())

        async def vip_answered():
            await sv.routing.save({"vip": {"enabled": True, "ring_sec": 12, "rules": [{"match": "79000099999", "target": "agent:31", "note": "VIP"}]}}, boss)
            for ext in ("111", "112", "121", "131"):
                devstate(ext, "INUSE")  # the queue itself cannot answer (Dave's direct ring does not look at it)
            w.call("79000099999")
            await w.wait(lambda e: e.get("Event") == "QueueCallerJoin", what="the customer in queue 410")
            d = await w.wait(lambda e: e.get("Event") == "DialBegin" and "Local/131@routing-agents" in e.get("DestChannel", ""), what="Dave's phone rings")
            await w.wait(lambda e: e.get("Event") == "DialEnd" and e.get("DialStatus") == "ANSWER" and "131" in e.get("DestChannel", ""), what="Dave answers")
            await asyncio.sleep(0.5)
            async with db.sessionmaker() as s:
                q = (await s.execute(select(QueueCall).where(QueueCall.linkedid == d.get("Linkedid")))).scalars().first()
                a = (await s.execute(select(AuditLog).where(AuditLog.action == "callroute_vip"))).scalars().all()
            expect(q is not None and q.outcome == "answered" and q.agent_id == 31, f"queue call: {q and (q.outcome, q.agent_id)}")
            expect(a and a[-1].details["result"] == "redirected" and a[-1].agent_id == 31, "logged")
            expect(not any(e.get("Event") == "AgentCalled" and "131" in e.get("Interface", "") for e in w.events), "rang through the queue, not directly")
            await hangup_all()
        await step("VIP: taken out of the queue (Redirect) straight to Dave's phone, answered; counted as an answered queue call", vip_answered())

        async def vip_back():
            await sv.routing.save({"vip": {"enabled": True, "ring_sec": 5, "rules": [{"match": "79000088888", "target": "agent:21"}]}}, boss)
            for ext in ("111", "112", "121", "131"):
                devstate(ext, "INUSE")
            await sv.engine.reconcile_all("test")
            w.call("79000088888")
            await w.wait(lambda e: e.get("Event") == "DialBegin" and "Local/121@routing-noanswer" in e.get("DestChannel", ""), what="Carol's phone rings")
            devstate("111", "NOT_INUSE")  # Alice is free when the customer comes back
            t0 = time.monotonic()
            while sv.routing.pending and time.monotonic() - t0 < 15:
                await sv.routing.tick()
                await asyncio.sleep(0.5)
            expect(not sv.routing.pending, "still waiting for Carol")
            joins = [e for e in w.events if e.get("Event") == "QueueCallerJoin"]
            await w.wait(lambda e: e.get("Event") == "AgentConnect" and "111" in e.get("Interface", ""), timeout=15, what="Alice answers in the queue")
            expect(len([e for e in w.events if e.get("Event") == "QueueCallerJoin"]) >= 2 or len(joins) >= 2, "back into the queue")
            async with db.sessionmaker() as s:
                back = (await s.execute(select(AuditLog).where(AuditLog.action == "callroute_vip_back"))).scalars().all()
            expect(back and back[-1].details["reason"] == "timeout", "logged: back after the ring time")
            await hangup_all()
            await sv.routing.save({"vip": {"enabled": False}}, boss)
        await step("VIP: Carol does not answer → after the ring time the customer is back in the queue and answered there", vip_back())

        async def overflow():
            for ext in ("111", "112", "131"):
                devstate(ext, "INUSE")
            devstate("121", "NOT_INUSE")
            t = fz.add_ticket("Server down", owner_id=121, state="open")
            async with db.sessionmaker() as s:
                carol = await s.get(AgentMapping, 21)
            await sv.workflow.start_work(carol, t["id"], "blocking", Actor("agent", 21))
            await asyncio.sleep(0.5)
            expect(paused("121"), "Carol busy with a ticket is paused")
            await sv.routing.save({"queues": {"410": {"overflow": {"enabled": True, "waiting": 1, "wait_sec": 0, "add": ["level2"], "calm_sec": 10}}}}, boss)
            w.call("79000077777")
            await w.wait(lambda e: e.get("Event") == "QueueCallerJoin", what="the customer waits")
            await asyncio.sleep(1.5)
            expect(not any(e.get("Event") == "AgentCalled" for e in w.events), "nobody should ring before the overflow")
            await sv.routing.tick()
            expect("410" in sv.routing.active and not paused("121"), "overflow on: Carol takes calls in 410")
            try:
                await w.wait(lambda e: e.get("Event") == "AgentCalled" and "121" in e.get("Interface", ""), timeout=10, what="Asterisk rings Carol")
            except AssertionError as exc:
                raise AssertionError(f"{exc}\n{cli('queue show 410')}") from None
            await hangup_all()
            await sv.routing.tick()
            from datetime import timedelta
            from app.db import utcnow
            await sv.routing.tick(utcnow() + timedelta(seconds=11))
            expect("410" not in sv.routing.active and paused("121"), "calm again: Carol back to her ticket (paused)")
            await sv.routing.save({"queues": {"410": {"overflow": {"enabled": False, "add": ["level2"]}}}}, boss)
        await step("Overflow: a waiting customer + Level 1 busy → Carol (Level 2, busy with a ticket) is unpaused in 410 and rung; paused again when calm", overflow())
    finally:
        await w.stop()
        for _, _, _, ext in AGENTS:
            devstate(ext, "NOT_INUSE")
        consumer.cancel()
        await sv.stop()
        subprocess.run([AST, "stop"], timeout=60)  # queues.conf was changed: the next test gets a fresh one
    failed = [r for r in RESULTS if not r[1]]
    print(f"\nReal Asterisk call routing: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
