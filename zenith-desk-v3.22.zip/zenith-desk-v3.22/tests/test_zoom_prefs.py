"""v3.22: the interface size is a personal preference saved to the account (auto by default)."""
import pytest


@pytest.mark.asyncio
async def test_zoom_preference(env):
    h = await env.login("anna")
    p = (await env.client.get("/api/agents/me/preferences", headers=h)).json()
    assert p.get("zoom", "auto") == "auto"
    r = await env.client.put("/api/agents/me/preferences", json={**p, "zoom": "90"}, headers=h)
    assert r.status_code == 200
    assert (await env.client.get("/api/agents/me/preferences", headers=h)).json()["zoom"] == "90"
    for bad in ("300", "0", "big", 90):
        assert (await env.client.put("/api/agents/me/preferences", json={**p, "zoom": bad}, headers=h)).status_code == 422
