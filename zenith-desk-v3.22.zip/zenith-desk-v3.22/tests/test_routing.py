"""v3.11 — call routing by level: penalties set from the levels, routing panel (real Asterisk: tests/realstack/routing_e2e.py)."""
from app.models import AgentMapping

from .conftest import IF1, IF2


async def set_levels(env, **levels):
    """…and make them Ready (unpaused), so the queue state depends only on what the test does."""
    from app.models import AgentState
    async with env.services.db.sessionmaker() as s:
        for uid, level in levels.items():
            (await s.get(AgentMapping, int(uid[1:]))).level = level
            (await s.get(AgentState, int(uid[1:]))).manual_state = "ready"
        await s.commit()


async def test_off_by_default_no_penalty_commands(env):
    await env.services.engine.reconcile_all("test")
    assert not [c for c in env.pbx.commands if "penalty" in c]


async def test_penalties_follow_levels_and_settings(env):
    h = await env.login("root")
    await set_levels(env, a1="level1", a2="level2")
    r = await env.client.put("/api/admin/settings", json={"values": {"level_routing": True}}, headers=h)
    assert r.status_code == 200, r.text
    await env.services.engine.reconcile_all("test")
    for q in ("400", "401"):
        assert env.pbx.members[q][IF1]["penalty"] == 0
        assert env.pbx.members[q][IF2]["penalty"] == 1
    # the administrator changes the numbers: Level 2 → 5
    await env.client.put("/api/admin/settings", json={"values": {"penalty_level2": 5}}, headers=h)
    await env.services.engine.reconcile_all("test")
    assert env.pbx.members["400"][IF2]["penalty"] == 5
    # a level change through the users page moves the penalty at once
    r = await env.client.get("/api/admin/users", headers=h)
    boris = next(u for u in r.json() if u["username"] == "boris")
    body = {k: boris[k] for k in ("last_name", "username", "position", "active", "zammad_user_id", "extension",
                                  "asterisk_interface", "enabled")}
    body["first_name"] = boris["first_name"] or "Boris"
    r = await env.client.put(f"/api/admin/users/{boris['id']}", json={**body, "level": "level3"}, headers=h)
    assert r.status_code == 200, r.text
    assert env.pbx.members["400"][IF2]["penalty"] == 2
    async with env.services.db.sessionmaker() as s:
        from sqlalchemy import select

        from app.models import AuditLog
        rows = (await s.execute(select(AuditLog).where(AuditLog.action == "queue_penalty"))).scalars().all()
    assert rows and rows[-1].details["penalty"] == 2


async def test_penalty_not_confirmed_is_a_sync_error(env):
    await set_levels(env, a2="level2")
    await env.services.engine.recompute(2, "test")  # unpaused and in sync first
    env.settings.level_routing = True
    env.pbx.ignore_commands = True
    view = await env.services.engine.recompute(2, "test")
    assert view["sync_status"] == "error" and "penalty" in view["sync_error"]


async def test_routing_panel(env):
    await set_levels(env, a1="level1", a2="level2")
    env.settings.level_routing = True
    await env.services.engine.reconcile_all("test")
    h = await env.login("boss")  # managers see it too
    r = await env.client.get("/api/admin/routing", headers=h)
    assert r.status_code == 200, r.text
    q = r.json()["queues"][0]
    assert q["strategy"] == "rrmemory" and q["next_penalty"] == 0 and q["next_members"] == ["Анна"]
    assert [m["level"] for m in q["members"]] == ["level1", "level2"]
    assert q["free_by_level"] == {"level1": 1, "level2": 1, "level3": 0}
    # Anna on a call → the next call goes to Level 2
    for qq in env.pbx.members.values():
        qq[IF1]["in_call"] = True
    q = (await env.client.get("/api/admin/routing", headers=h)).json()["queues"][0]
    assert q["next_penalty"] == 1 and q["next_members"] == ["Борис"]
    # ringall rings every Level 1 at once: warned; a penalty that is not ours: warned
    env.pbx.strategy = "ringall"
    env.pbx.members["400"][IF2]["penalty"] = 7
    q = (await env.client.get("/api/admin/routing", headers=h)).json()["queues"][0]
    kinds = {w["kind"] for w in q["warnings"]}
    assert {"strategy", "penalty"} <= kinds
    # operators may not
    assert (await env.client.get("/api/admin/routing", headers=await env.login("anna"))).status_code == 403


async def test_penalty_set_even_without_pause_automation(env):
    """A user whose pauses are not automated still gets the routing penalty of his level."""
    await set_levels(env, a2="level3")
    async with env.services.db.sessionmaker() as s:
        (await s.get(AgentMapping, 2)).enabled = False
        await s.commit()
    env.settings.level_routing = True
    await env.services.engine.recompute(2, "test")
    assert env.pbx.members["400"][IF2]["penalty"] == 2
    assert not [c for c in env.pbx.commands if c[1] == IF2 and c[2] in (True, False)]  # no pause commands for him
