"""Audit phase 4 (requirement 2): vertical authorization across EVERY route of the application.

The route list is read from the running app, so a new endpoint is covered automatically:
  * a route without any sign-in requirement must be on the reviewed PUBLIC list (else the test fails → review it);
  * without a token every protected route answers 401;
  * an operator gets 403 on every supervisor / admin route, a supervisor gets 403 on every admin route.
Refused requests never reach the handler, so the walk has no side effects. Horizontal (same role, other owner)
checks live next to each feature: chat (test_chat_groups_files), drafts / tabs (test_ticket_views), recordings
(test_v39_misc), backup (test_sec_backup_upload). Users: 1 anna (operator), 3 boss (supervisor), 4 root (admin)."""
import re

import pytest
from fastapi.routing import APIRoute

# reviewed: each one either needs no identity or checks its own credential (signature / ticket / shared secret)
PUBLIC = {
    ("POST", "/api/auth/login"),                       # throttled, timing-equalised
    ("GET", "/api/avatars/{key}"),                     # unguessable key, images only
    ("POST", "/api/integrations/zammad/webhook"),      # HMAC-SHA1 signature, refused unsigned
    ("POST", "/api/integrations/telegram/webhook"),    # secret-token header (compare_digest)
    ("GET", "/api/integrations/whatsapp/webhook"),     # verify-token handshake
    ("POST", "/api/integrations/whatsapp/webhook"),    # X-Hub-Signature-256
    ("GET", "/api/admin/backups/{name}/download"),     # 120-second signed ticket of an active administrator
    ("GET", "/api/health"),
    ("GET", "/api/desktop/hello"),
    ("GET", "/api/ui-language"),
    ("GET", "/"),                                      # the single-page app shell (no data)
    ("GET", "/sw.js"),                                 # service worker script (static)
}


def flat(routes):
    for r in routes:
        if type(r).__name__ == "_IncludedRouter":
            yield from flat(r.original_router.routes)
        else:
            yield r


def needs(dependant, out):
    for sub in dependant.dependencies:
        name = getattr(sub.call, "__qualname__", "")
        if name.endswith("require_role.<locals>.dep"):
            out.add(next(c.cell_contents for c in sub.call.__closure__ if isinstance(c.cell_contents, str)))
        elif name == "current_agent":
            out.add("signed-in")
        needs(sub, out)
    return out


def routes(env):
    app = env.client._transport.app
    for r in flat(app.routes):
        if isinstance(r, APIRoute):
            req = needs(r.dependant, set())
            level = "admin" if "admin" in req else "supervisor" if "supervisor" in req else "signed-in" if req else None
            for m in sorted(r.methods - {"HEAD"}):
                yield m, r.path, level


def concrete(path):
    return re.sub(r"\{[^}]+\}", "1", path)


@pytest.mark.asyncio
async def test_every_unprotected_route_has_been_reviewed(env):
    open_routes = {(m, p) for m, p, level in routes(env) if level is None}
    assert open_routes <= PUBLIC, f"routes without sign-in that nobody reviewed: {sorted(open_routes - PUBLIC)}"


@pytest.mark.asyncio
async def test_role_matrix(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    checked, wrong = 0, []
    for method, path, level in routes(env):
        if level is None:
            continue
        url = concrete(path)
        r = await env.client.request(method, url, json={})
        if r.status_code != 401:
            wrong.append(("no token", method, path, r.status_code))
        if level in ("supervisor", "admin"):
            r = await env.client.request(method, url, json={}, headers=anna)
            if r.status_code != 403:
                wrong.append(("operator", method, path, r.status_code))
        if level == "admin":
            r = await env.client.request(method, url, json={}, headers=boss)
            if r.status_code != 403:
                wrong.append(("supervisor", method, path, r.status_code))
        checked += 1
    assert not wrong, wrong
    assert checked > 150  # the walk really covered the application


@pytest.mark.asyncio
async def test_a_role_in_the_token_is_not_trusted(env):
    """The role comes from the database on every request: a token whose "role" claim says admin does not help."""
    import jwt
    from datetime import timedelta
    from app.auth import password_version
    from app.db import utcnow
    from app.models import AgentMapping
    async with env.services.db.sessionmaker() as s:
        anna = await s.get(AgentMapping, 1)
    token = jwt.encode({"sub": "1", "role": "admin", "pv": password_version(anna), "typ": "session",
                        "exp": utcnow() + timedelta(hours=1)}, env.settings.jwt_secret, algorithm="HS256")
    h = {"Authorization": f"Bearer {token}"}
    assert (await env.client.get("/api/auth/me", headers=h)).status_code == 200
    assert (await env.client.get("/api/admin/users", headers=h)).status_code == 403


@pytest.mark.asyncio
async def test_stream_tickets_are_not_sessions_and_sessions_are_not_in_urls(env):
    h = await env.login("anna")
    ticket = (await env.client.post("/api/auth/stream-token", headers=h)).json()["token"]
    assert (await env.client.get("/api/auth/me", headers={"Authorization": f"Bearer {ticket}"})).status_code == 401
    session = h["Authorization"][7:]
    assert (await env.client.get(f"/api/auth/me?token={session}")).status_code == 401
