"""In-memory fakes of Asterisk queues and the Zammad REST API used by the tests."""
import base64
import json
import re
from itertools import count

import httpx

from app.ami import AMINotConnected, AMIError
from app.pbx import MemberStatus


class FakePbx:
    def __init__(self, queues: list[str], members: list[str]):
        self.connected_flag = True
        self.members = {q: {m: {"paused": False, "reason": "", "penalty": 0, "in_call": False} for m in members} for q in queues}
        self.strategy = "rrmemory"
        self.commands: list[tuple] = []
        self.ignore_commands = False  # simulate Asterisk not applying a command
        self.spies: list[dict] = []  # v3.15 call supervision sessions started over "AMI"
        self.hangups: list[str] = []
        self.on_spy = None  # demo: ring the manager's simulated phone
        self.redirects: list[tuple] = []  # v3.18 VIP routing
        self.on_redirect = None  # demo: the phone of the person rings
        self.strategies: dict[str, str] = {}

    @property
    def connected(self) -> bool:
        return self.connected_flag

    def is_paused(self, interface: str) -> bool:
        return all(self.members[q][interface]["paused"] for q in self.members if interface in self.members[q])

    async def member_status(self, interface: str, queues: list[str]) -> dict[str, MemberStatus]:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        out = {}
        for q in queues:
            m = self.members.get(q, {}).get(interface)
            out[q] = MemberStatus(queue=q, present=m is not None, paused=bool(m and m["paused"]),
                                  paused_reason=m["reason"] if m else "", penalty=m.get("penalty", 0) if m else None)
        return out

    async def set_paused(self, interface: str, queue: str, paused: bool, reason: str) -> None:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        m = self.members.get(queue, {}).get(interface)
        if m is None:
            raise AMIError("Interface not found")
        self.commands.append((queue, interface, paused))
        if not self.ignore_commands:
            m["paused"], m["reason"] = paused, (reason if paused else "")

    async def set_penalty(self, interface: str, queue: str, penalty: int) -> None:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        m = self.members.get(queue, {}).get(interface)
        if m is None:
            raise AMIError("Interface not found")
        self.commands.append((queue, interface, "penalty", penalty))
        if not self.ignore_commands:
            m["penalty"] = penalty

    async def spy(self, dial: str, target: str, mode: str, caller_id: str, channel_id: str) -> None:
        from app.pbx import SPY_OPTIONS
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        self.spies.append({"dial": dial, "target": target, "mode": mode, "options": SPY_OPTIONS[mode], "caller_id": caller_id,
                           "channel_id": channel_id})
        if self.on_spy:
            await self.on_spy(dial, caller_id, channel_id)

    async def hangup(self, channel: str) -> None:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        self.hangups.append(channel)

    async def redirect(self, channel: str, context: str, exten: str, priority: int = 1) -> None:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        self.redirects.append((channel, context, exten))
        if self.on_redirect:
            await self.on_redirect(channel, context, exten)

    async def set_strategy(self, queue: str, strategy: str, filename: str) -> None:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        self.commands.append((queue, "strategy", strategy, filename))
        self.strategies[queue] = strategy

    async def queue_info(self, queues: list[str]):
        from app.pbx import QueueInfo, QueueMember
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        return [QueueInfo(queue=q, strategy=self.strategies.get(q, self.strategy), members=[
            QueueMember(interface=i, name=i, penalty=m.get("penalty", 0), paused=m["paused"], paused_reason=m["reason"],
                        in_call=m.get("in_call", False), status="2" if m.get("in_call") else "1")
            for i, m in self.members.get(q, {}).items()]) for q in queues]


class FakeZammad:
    """Implements the subset of the Zammad API the service uses, with Zammad's own rules where they matter
    (owner needs full group access, state types, search paging, expanded names, "From" impersonation)."""

    STATES = {1: "new", 2: "open", 3: "pending reminder", 4: "closed", 5: "merged", 6: "pending close"}
    STATE_TYPES = {1: "new", 2: "open", 3: "pending reminder", 4: "closed", 5: "merged", 6: "pending action"}
    PRIORITIES = {1: "1 low", 2: "2 normal", 3: "3 high"}
    GROUPS = {1: "Users", 2: "Sales"}

    def __init__(self):
        self.ids = count(100)
        self.aids = count(5000)  # articles and files: ticket numbers stay 31100, 31101, … as in Zammad
        self.users: dict[int, dict] = {}
        self.passwords: dict[str, int] = {}
        self.tickets: dict[int, dict] = {}
        self.articles: list[dict] = []
        self.files: dict[int, bytes] = {}
        self.fail = False
        self.requests: list[tuple[str, str]] = []
        self.no_access: set[tuple[int, int]] = set()  # (user_id, ticket_id) hidden from that user
        self.clock = 0
        # v3.11
        self.GROUPS = dict(FakeZammad.GROUPS)  # per instance: tests create groups
        self.group_active: dict[int, bool] = {i: True for i in self.GROUPS}
        self.tags: dict[int, list[str]] = {}
        self.orgs: dict[int, dict] = {}
        self.overview_limit = 2000
        self.overviews = self._default_overviews()

    # ------------------------------------------------------------------ v3.11 overviews (Ticket::Overviews.index)
    def _default_overviews(self) -> list[dict]:
        """Zammad's seeded overviews (db/seeds/overviews.rb, same links and order) plus two custom ones as a company has them."""
        open_types = ("new", "open", "pending reminder", "pending action")
        o = lambda st: self.STATE_TYPES[st] in open_types  # noqa: E731
        reached = lambda t: self.STATE_TYPES[t["state_id"]].startswith("pending") and str(t.get("pending_time") or "9") <= self._now()  # noqa: E731
        return [
            {"id": 1, "prio": 1000, "link": "my_assigned", "name": "My Assigned Tickets",
             "cond": lambda t, uid: t.get("owner_id") == uid and o(t["state_id"]), "order": ("created_at", "ASC")},
            {"id": 2, "prio": 1010, "link": "all_unassigned", "name": "Unassigned & Open Tickets",
             "cond": lambda t, uid: t.get("owner_id") in (None, 1) and o(t["state_id"]), "order": ("created_at", "ASC")},
            {"id": 3, "prio": 1020, "link": "my_pending_reached", "name": "My Pending Reached Tickets",
             "cond": lambda t, uid: t.get("owner_id") == uid and reached(t), "order": ("created_at", "ASC")},
            {"id": 4, "prio": 1025, "link": "my_subscribed_tickets", "name": "My Subscribed Tickets",
             "cond": lambda t, uid: uid in (t.get("mention_user_ids") or []), "order": ("created_at", "ASC")},
            {"id": 5, "prio": 1030, "link": "all_open", "name": "Open Tickets",
             "cond": lambda t, uid: o(t["state_id"]), "order": ("created_at", "ASC")},
            {"id": 6, "prio": 1040, "link": "all_pending_reached", "name": "Pending Reached Tickets",
             "cond": lambda t, uid: reached(t), "order": ("created_at", "ASC")},
            {"id": 7, "prio": 1050, "link": "all_escalated", "name": "Escalated Tickets",
             "cond": lambda t, uid: bool(t.get("escalation_at")) and o(t["state_id"]), "order": ("escalation_at", "ASC")},
            {"id": 8, "prio": 1060, "link": "my_closed_tickets", "name": "My Closed Tickets",
             "cond": lambda t, uid: t.get("owner_id") == uid and self.STATE_TYPES[t["state_id"]] == "closed", "order": ("close_at", "DESC")},
            {"id": 9, "prio": 1070, "link": "on_site_requests", "name": "On-site Requests",
             "cond": lambda t, uid: "on-site" in self.tags.get(t["id"], []) and o(t["state_id"]), "order": ("created_at", "ASC")},
        ]

    def rename_overviews(self, names: dict[str, str]) -> None:
        """A Zammad in another language: overview names as the company sees them."""
        for ov in self.overviews:
            ov["name"] = names.get(ov["link"], ov["name"])

    def _overview_index(self, uid: int | None) -> list[dict]:
        out = []
        for ov in sorted(self.overviews, key=lambda x: (x["prio"], x["name"])):
            match = [t for t in self.tickets.values() if self._can_read(uid, t) and ov["cond"](t, uid)]
            by, direction = ov["order"]
            match.sort(key=lambda t: (str(t.get(by) or t.get("created_at") or ""), t["id"]), reverse=direction == "DESC")
            out.append({"overview": {"name": ov["name"], "id": ov["id"], "view": ov["link"], "updated_at": "2026-10-01T00:00:00Z"},
                        "tickets": [{"id": t["id"], "updated_at": t["updated_at"]} for t in match[: self.overview_limit]],
                        "count": len(match)})
        return out

    def _user_asset(self, u: dict) -> dict:
        return {k: v for k, v in u.items() if k not in ("groups", "roles")}

    # helpers for tests
    def _now(self) -> str:
        from datetime import datetime, timedelta, timezone
        self.clock += 1
        return (datetime(2026, 10, 1, tzinfo=timezone.utc) + timedelta(seconds=self.clock)).isoformat().replace("+00:00", "Z")

    def add_user(self, uid: int, login: str, password: str = "pw", **kw) -> dict:
        roles = kw.pop("roles", None) or (["Customer"] if uid >= 50 else ["Agent"])
        groups = kw.pop("groups", None)
        if groups is None:
            groups = {"Users": ["full"]} if "Agent" in roles else {}
        u = {"id": uid, "login": login, "firstname": kw.pop("firstname", login), "lastname": kw.pop("lastname", ""),
             "email": kw.pop("email", f"{login}@example.test"), "active": True, "roles": roles, "groups": groups,
             "created_at": self._now(), **kw}
        u["updated_at"] = u["created_at"]
        self.users[uid] = u
        self.passwords[f"{login.lower()}:{password}"] = uid
        return u

    def touch_user(self, uid: int, **kw) -> dict:
        self.users[uid].update(kw, updated_at=self._now())
        return self.users[uid]

    def add_ticket(self, title: str, owner_id: int = 1, state: str = "new", article_type: str = "email", **kw) -> dict:
        tid = next(self.ids)
        group = kw.pop("group", "Users")
        priority = kw.pop("priority", "2 normal")
        now = self._now()
        t = {"id": tid, "number": str(31000 + tid), "title": title, "owner_id": owner_id, "customer_id": 50,
             "state_id": self._state_id(state), "create_article_type": article_type, "group": group,
             "group_id": self._gid(group), "priority_id": self._pid(priority), "created_at": now, "updated_at": now,
             "article_count": 0, **kw}
        self.tickets[tid] = t
        return t

    def add_article(self, tid: int, body: str, *, sender: str = "Customer", type: str = "email", internal: bool = False,
                    created_by_id: int | None = None, files: list[tuple[str, bytes]] | None = None, **kw) -> dict:
        t = self.tickets[tid]
        aid = next(self.aids)
        atts = []
        for name, data in files or []:
            fid = next(self.aids)
            self.files[fid] = data
            atts.append({"id": fid, "filename": name, "size": len(data), "preferences": {"Content-Type": "application/octet-stream"}})
        a = {"id": aid, "ticket_id": tid, "body": body, "sender": sender, "type": type, "internal": internal,
             "content_type": kw.pop("content_type", "text/plain"), "from": kw.pop("from", ""), "to": kw.pop("to", ""),
             "subject": kw.pop("subject", t["title"]), "created_by_id": created_by_id or t.get("customer_id"),
             "created_at": self._now(), "attachments": atts, **kw}
        self.articles.append(a)
        t["article_count"] = t.get("article_count", 0) + 1
        t["updated_at"] = a["created_at"]
        return a

    def _state_id(self, name: str) -> int:
        return next(i for i, n in self.STATES.items() if n == name)

    def _gid(self, name) -> int:
        return next((i for i, n in self.GROUPS.items() if n == name), 1)

    def _pid(self, name) -> int:
        return next((i for i, n in self.PRIORITIES.items() if n == name), 2)

    def state_of(self, tid: int) -> str:
        return self.STATES[self.tickets[tid]["state_id"]]

    def _expand(self, t: dict) -> dict:
        owner = self.users.get(t.get("owner_id") or 0, {})
        cust = self.users.get(t.get("customer_id") or 0, {})
        return {**t, "state": self.STATES[t["state_id"]], "priority": self.PRIORITIES.get(t.get("priority_id"), "2 normal"),
                "group": self.GROUPS.get(t.get("group_id"), t.get("group")), "owner": owner.get("login", "-"),
                "customer": cust.get("email") or cust.get("login", "")}

    def _can_read(self, uid: int | None, t: dict) -> bool:
        """Zammad's TicketPolicy::ReadScope: agents see tickets of their groups (and the ones they own)."""
        if not uid or uid not in self.users or (uid, t["id"]) in self.no_access:
            return not (uid and (uid, t["id"]) in self.no_access)
        u = self.users[uid]
        return t.get("owner_id") == uid or self.GROUPS.get(t.get("group_id"), t.get("group")) in (u.get("groups") or {})

    def _full_access(self, uid: int, group_id: int) -> bool:
        u = self.users.get(uid)
        return bool(u and "Agent" in u.get("roles", []) and "full" in (u.get("groups") or {}).get(self.GROUPS.get(group_id, ""), []))

    def _apply_update(self, t: dict, body: dict, actor: int | None) -> None:
        body = dict(body)
        article = body.pop("article", None)
        if "state" in body:
            body["state_id"] = self._state_id(body.pop("state"))
        if "priority" in body:
            body["priority_id"] = self._pid(body.pop("priority"))
        if "group" in body:
            body["group_id"] = self._gid(body["group"])
        t.update(body)
        if t.get("owner_id") not in (None, 1) and not self._full_access(t["owner_id"], t.get("group_id", 1)):
            t["owner_id"] = 1  # Zammad: Ticket#check_owner_active resets an owner without full access
        t["updated_at"] = self._now()
        if article:
            self._create_article(t["id"], article, actor)

    def _create_article(self, tid: int, body: dict, actor: int | None) -> dict:
        files = []
        for f in body.pop("attachments", None) or []:
            for key in ("filename", "data", "mime-type"):
                if key not in f:
                    raise ValueError(f"Attachment needs '{key}' param")
            files.append((f["filename"], base64.b64decode(f["data"])))
        body.pop("ticket_id", None)
        a = self.add_article(tid, body.pop("body"), sender=body.pop("sender", "Agent"), type=body.pop("type", "note"),
                             internal=body.pop("internal", False), created_by_id=actor or 1, files=files, **body)
        return a

    def transport(self) -> httpx.MockTransport:
        return httpx.MockTransport(self._handle)

    def _handle(self, req: httpx.Request) -> httpx.Response:
        path, method = req.url.path, req.method
        self.requests.append((method, path))
        if self.fail:
            return httpx.Response(503, json={"error": "down"})
        body = json.loads(req.content) if req.content else {}
        params = req.url.params
        obo = req.headers.get("from") or req.headers.get("x-on-behalf-of")
        actor = int(obo) if obo else None

        if path == "/api/v1/users/me":
            auth = req.headers.get("authorization", "")
            if auth.startswith("Token "):  # service token -> the service user
                return httpx.Response(200, json={"id": 1, "login": "ops-service", "email": "ops@zammad.test"})
            if auth.startswith("Basic "):
                login, _, pw = base64.b64decode(auth[6:]).decode().partition(":")
                uid = self.passwords.get(f"{login.lower()}:{pw}")
                if uid:
                    return httpx.Response(200, json=self.users[uid])
            return httpx.Response(401, json={"error": "auth"})
        if path == "/api/v1/ticket_states":
            return httpx.Response(200, json=[{"id": i, "name": n, "active": True, "state_type": self.STATE_TYPES[i]}
                                             for i, n in self.STATES.items()])
        if path == "/api/v1/ticket_priorities":
            return httpx.Response(200, json=[{"id": i, "name": n, "active": True, "default_create": i == 2}
                                             for i, n in self.PRIORITIES.items()])
        if path == "/api/v1/groups" and method == "POST":
            if not body.get("name"):
                return httpx.Response(422, json={"error": "name missing"})
            if body["name"] in self.GROUPS.values():
                return httpx.Response(422, json={"error": "Name has already been taken"})
            gid = max(self.GROUPS) + 1
            self.GROUPS[gid] = body["name"]
            self.group_active[gid] = body.get("active", True)
            return httpx.Response(201, json={"id": gid, "name": body["name"], "active": self.group_active[gid], "note": body.get("note", "")})
        if m := re.fullmatch(r"/api/v1/groups/(\d+)", path):
            gid = int(m.group(1))
            if gid not in self.GROUPS:
                return httpx.Response(404, json={"error": "not found"})
            if method == "PUT":
                old = self.GROUPS[gid]
                if "name" in body and body["name"] != old:
                    self.GROUPS[gid] = body["name"]
                    for u in self.users.values():  # access follows the group (Zammad keeps it by id)
                        g = u.get("groups") or {}
                        if old in g:
                            g[body["name"]] = g.pop(old)
                if "active" in body:
                    self.group_active[gid] = bool(body["active"])
            return httpx.Response(200, json={"id": gid, "name": self.GROUPS[gid], "active": self.group_active[gid]})
        if path == "/api/v1/groups":
            allowed = self.GROUPS.items()
            if actor and actor in self.users:
                access = self.users[actor].get("groups") or {}
                allowed = [(i, n) for i, n in self.GROUPS.items() if n in access]
            return httpx.Response(200, json=[{"id": i, "name": n, "active": self.group_active.get(i, True)} for i, n in allowed])
        if m := re.fullmatch(r"/api/v1/tickets/(\d+)", path):
            tid = int(m.group(1))
            if tid in self.tickets and not self._can_read(actor, self.tickets[tid]):
                return httpx.Response(403, json={"error": "Not authorized"})
            if tid not in self.tickets:
                return httpx.Response(404, json={"error": "not found"})
            if method == "PUT":
                try:
                    self._apply_update(self.tickets[tid], body, actor)
                except ValueError as exc:
                    return httpx.Response(422, json={"error": str(exc)})
            return httpx.Response(200, json=self._expand(self.tickets[tid]))
        if path == "/api/v1/tickets" and method == "POST":
            article = body.pop("article", None)
            t = self.add_ticket(body.pop("title"), owner_id=body.pop("owner_id", 1), state=body.pop("state", "new"),
                                article_type=(article or {}).get("type", "note"), **body)
            if t.get("owner_id") not in (None, 1) and not self._full_access(t["owner_id"], t["group_id"]):
                t["owner_id"] = 1
            if article:
                self._create_article(t["id"], dict(article), actor)
            if t.get("tags"):
                self.tags[t["id"]] = [x.strip() for x in str(t.pop("tags")).split(",") if x.strip()]
            return httpx.Response(201, json=self._expand(t))
        if m := re.fullmatch(r"/api/v1/ticket_articles/by_ticket/(\d+)", path):
            tid = int(m.group(1))
            if actor and (actor, tid) in self.no_access:
                return httpx.Response(403, json={"error": "Not authorized"})
            arts = [a for a in self.articles if a.get("ticket_id") == tid and "id" in a]
            return httpx.Response(200, json=arts)
        if m := re.fullmatch(r"/api/v1/ticket_attachment/(\d+)/(\d+)/(\d+)", path):
            data = self.files.get(int(m.group(3)))
            if data is None:
                return httpx.Response(404, json={"error": "not found"})
            return httpx.Response(200, content=data, headers={"content-type": "application/octet-stream",
                                                              "content-disposition": "attachment; filename=f"})
        if path == "/api/v1/ticket_articles":
            if "ticket_id" in body and int(body["ticket_id"]) in self.tickets and "body" in body:
                try:
                    a = self._create_article(int(body["ticket_id"]), dict(body), actor)
                except ValueError as exc:
                    return httpx.Response(422, json={"error": str(exc)})
                self.tickets[int(body["ticket_id"])]["updated_at"] = a["created_at"]
                return httpx.Response(201, json=a)
            self.articles.append(body)
            return httpx.Response(201, json={"id": next(self.aids), **body})
        if path == "/api/v1/tickets/search":
            cond = body.get("condition", {})
            q = str(body.get("query") or "").lower().strip("*")
            res = []
            for t in self.tickets.values():
                if not self._can_read(actor, t):
                    continue
                ok = True
                for key, c in cond.items():
                    field = key.split(".", 1)[1]
                    if c.get("pre_condition") == "not_set":
                        ok &= t.get(field) in (None, 1)
                    else:
                        ok &= str(t.get(field)) in [str(v) for v in c.get("value", [])]
                if ok and q:
                    ok = q in (t["title"] + " " + t["number"]).lower()
                if ok:
                    res.append(self._expand(t))
            if body.get("with_total_count"):  # the paged ticket lists (v3.3) are sorted like in Zammad
                res.sort(key=lambda x: (str(x.get(body.get("sort_by") or "updated_at") or ""), x["id"]), reverse=body.get("order_by", "desc") == "desc")
            per = int(body.get("per_page") or body.get("limit") or 50)
            page = int(body.get("page") or 1)
            chunk = res[(page - 1) * per: page * per]
            if body.get("with_total_count"):
                return httpx.Response(200, json={"records": chunk, "total_count": len(res)})
            return httpx.Response(200, json=chunk)
        if path == "/api/v1/users/search":
            q = params.get("query", "")
            digits = lambda s: re.sub(r"\D", "", s or "")  # noqa: E731
            if q == "*" or not q.isdigit():
                hay = lambda u: " ".join(str(u.get(k) or "") for k in ("login", "firstname", "lastname", "email", "note")).lower()  # noqa: E731
                res = [u for u in self.users.values() if q == "*" or q.lower() in hay(u)]
            else:
                res = [u for u in self.users.values() if q in digits(u.get("phone")) or q in digits(u.get("mobile"))]
            if params.get("sort_by") == "updated_at":
                res.sort(key=lambda u: (u.get("updated_at") or "", u["id"]), reverse=params.get("order_by") != "asc")
            if params.get("per_page"):
                per, page = int(params["per_page"]), int(params.get("page") or 1)
                res = res[(page - 1) * per: page * per]
            return httpx.Response(200, json=res)
        if m := re.fullmatch(r"/api/v1/users/(\d+)", path):
            u = self.users.get(int(m.group(1)))
            if u is None:
                return httpx.Response(404, json={"error": "not found"})
            if method == "PUT":
                if "group_ids" in body:  # HasGroups#group_ids_access_map= replaces the whole map
                    u["groups"] = {self.GROUPS[int(k)]: (v if isinstance(v, list) else [v]) for k, v in body["group_ids"].items()
                                   if int(k) in self.GROUPS}
                u["updated_at"] = self._now()
            if params.get("expand") == "true" or method == "PUT":
                return httpx.Response(200, json=u)
            ids = {str(i): (u.get("groups") or {})[n] for i, n in self.GROUPS.items() if n in (u.get("groups") or {})}
            return httpx.Response(200, json={**{k: v for k, v in u.items() if k != "groups"}, "group_ids": ids})
        # ---------------- v3.11 overviews and tags
        if path == "/api/v1/ticket_overviews":
            index = self._overview_index(actor)
            if "view" not in params:
                return httpx.Response(200, json=[{"id": i["overview"]["id"], "name": i["overview"]["name"],
                                                  "prio": next(o["prio"] for o in self.overviews if o["id"] == i["overview"]["id"]),
                                                  "link": i["overview"]["view"], "count": i["count"]} for i in index])
            result, assets = {}, {}
            for i in index:
                if i["overview"]["view"] != params["view"]:
                    continue
                result = i
                for meta in i["tickets"]:
                    t = self.tickets[meta["id"]]
                    assets.setdefault("Ticket", {})[str(t["id"])] = {k: v for k, v in t.items() if k not in ("group", "tags")}
                    for key in ("created_by_id", "updated_by_id", "owner_id", "customer_id"):
                        u = self.users.get(t.get(key) or 0)
                        if u:
                            assets.setdefault("User", {})[str(u["id"])] = self._user_asset(u)
                            if u.get("organization_id") in self.orgs:
                                assets.setdefault("Organization", {})[str(u["organization_id"])] = self.orgs[u["organization_id"]]
                    if t.get("organization_id") in self.orgs:
                        assets.setdefault("Organization", {})[str(t["organization_id"])] = self.orgs[t["organization_id"]]
            return httpx.Response(200, json={"assets": assets, "index": result})
        if path == "/api/v1/tags":
            return httpx.Response(200, json={"tags": list(self.tags.get(int(params.get("o_id") or 0), []))})
        if path == "/api/v1/tags/add" and method == "POST":
            if body.get("object") != "Ticket" or not body.get("item"):
                return httpx.Response(422, json={"error": "bad tag"})
            tl = self.tags.setdefault(int(body["o_id"]), [])
            if body["item"] not in tl:
                tl.append(body["item"])
            return httpx.Response(201, json=True)
        if path == "/api/v1/tags/remove" and method == "DELETE":
            tl = self.tags.get(int(params.get("o_id") or 0), [])
            if params.get("item") in tl:
                tl.remove(params.get("item"))
            return httpx.Response(200, json=True)
        if path == "/api/v1/tag_search":
            term = (params.get("term") or "").lower()
            allt = sorted({x for v in self.tags.values() for x in v})
            return httpx.Response(200, json=[{"id": i, "value": x} for i, x in enumerate(allt) if term in x.lower()][:10])
        if path == "/api/v1/users" and method == "POST":
            uid = next(self.ids)
            self.users[uid] = {"id": uid, "roles": ["Customer"], "created_at": self._now(), **body}
            self.users[uid]["updated_at"] = self.users[uid]["created_at"]
            return httpx.Response(201, json=self.users[uid])
        return httpx.Response(404, json={"error": f"unhandled {method} {path}"})
