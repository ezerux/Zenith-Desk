"""v3.18 API keys: another program works with Zenith Desk as the chosen user."""
import httpx
from sqlalchemy import select

from app import api_keys
from app.models import ApiKey, AuditLog


async def make(env, h, **body):
    r = await env.client.post("/api/admin/api-keys", json={"name": "CRM", "agent_id": 3, **body}, headers=h)
    assert r.status_code == 200, r.text
    return r.json()


async def test_create_use_and_revoke(env):
    root, boss = await env.login("root"), await env.login("boss")
    assert (await env.client.get("/api/admin/api-keys", headers=boss)).status_code == 403  # administrators only
    d = await make(env, root, read_only=False)
    key = d["created"]["key"]
    assert key.startswith("zdk_") and len(key) > 40
    row = next(k for k in d["keys"] if k["id"] == d["created"]["id"])
    assert row["state"] == "active" and row["agent"] == "Руководитель" and key not in str(d["keys"])
    async with env.services.db.sessionmaker() as s:
        k = (await s.execute(select(ApiKey))).scalars().one()
    assert k.secret_hash == api_keys.digest(key) and key not in (k.secret_hash + k.prefix)  # only a hash is stored
    c = env.client
    # both headers; the key has the user's rights (a manager: the team yes, the administration no)
    assert (await c.get("/api/auth/me", headers={"X-API-Key": key})).json()["username"] == "boss"
    assert (await c.get("/api/admin/agents", headers={"Authorization": f"Bearer {key}"})).status_code == 200
    assert (await c.get("/api/admin/users", headers={"X-API-Key": key})).status_code == 403
    # a key can never make keys or change the password
    assert (await c.get("/api/admin/api-keys", headers={"X-API-Key": key})).status_code in (403,)
    assert (await c.post("/api/auth/change-password", json={"current_password": "pw", "new_password": "x" * 10},
                         headers={"X-API-Key": key})).status_code == 403
    assert (await c.get("/api/auth/me", headers={"X-API-Key": key[:-2] + "xx"})).status_code == 401
    assert (await c.get("/api/auth/me", headers={"X-API-Key": "zdk_nope_x"})).status_code == 401
    # the live stream with a key: the stream ticket comes from the key's user
    r = await c.post("/api/auth/stream-token", headers={"X-API-Key": key})
    assert r.status_code == 200 and r.json()["token"]
    # revoked: refused at once
    r = await c.delete(f"/api/admin/api-keys/{d['created']['id']}", headers=root)
    assert next(k for k in r.json()["keys"] if k["id"] == d["created"]["id"])["state"] == "revoked"
    assert (await c.get("/api/auth/me", headers={"X-API-Key": key})).status_code == 401
    async with env.services.db.sessionmaker() as s:
        acts = [a.action for a in (await s.execute(select(AuditLog).where(AuditLog.action.like("api_key_%")))).scalars().all()]
    assert acts == ["api_key_created", "api_key_revoked"]


async def test_read_only_ip_expiry_and_rate(env, monkeypatch):
    root = await env.login("root")
    ro = (await make(env, root, read_only=True))["created"]["key"]
    c = env.client
    assert (await c.get("/api/admin/agents", headers={"X-API-Key": ro})).status_code == 200
    r = await c.post("/api/admin/agents/1/reconcile", headers={"X-API-Key": ro})
    assert r.status_code == 403 and "read" in r.text.lower()
    assert (await c.post("/api/auth/stream-token", headers={"X-API-Key": ro})).status_code == 200  # reading the stream is reading
    # allowed addresses (the test client is 127.0.0.1)
    assert (await c.post("/api/admin/api-keys", json={"name": "x", "agent_id": 3, "allowed_ips": "not an ip"}, headers=root)).status_code == 422
    other = (await make(env, root, allowed_ips="10.0.0.0/8"))["created"]["key"]
    assert (await c.get("/api/auth/me", headers={"X-API-Key": other})).status_code == 403
    here = (await make(env, root, allowed_ips="10.0.0.5, 127.0.0.1"))["created"]["key"]
    assert (await c.get("/api/auth/me", headers={"X-API-Key": here})).status_code == 200
    remote = httpx.AsyncClient(transport=httpx.ASGITransport(app=c._transport.app, client=("10.0.0.5", 4000)), base_url="http://t")
    assert (await remote.get("/api/auth/me", headers={"X-API-Key": here})).status_code == 200
    assert (await remote.get("/api/auth/me", headers={"X-API-Key": other})).status_code == 200
    await remote.aclose()
    # expiry
    d = await make(env, root, expires_days=1)
    async with env.services.db.sessionmaker() as s:
        k = await s.get(ApiKey, d["created"]["id"])
        from datetime import timedelta
        k.expires_at = k.expires_at - timedelta(days=2)
        await s.commit()
    r = await c.get("/api/auth/me", headers={"X-API-Key": d["created"]["key"]})
    assert r.status_code == 401 and "expired" in r.text
    # rate limit
    monkeypatch.setattr(api_keys, "RATE", 3)
    fresh = (await make(env, root))["created"]["key"]
    codes = [(await c.get("/api/auth/me", headers={"X-API-Key": fresh})).status_code for _ in range(4)]
    assert codes == [200, 200, 200, 429]
    # a disabled user: his keys stop
    u = (await make(env, root, agent_id=2))["created"]["key"]
    r = await c.put("/api/admin/users/2", json={"first_name": "Борис", "last_name": "", "username": "boris", "position": "", "level": "level1",
                                                "role": "operator", "active": False}, headers=root)
    if r.status_code == 200:
        assert (await c.get("/api/auth/me", headers={"X-API-Key": u})).status_code == 401


async def test_usage_is_recorded_and_openapi(env):
    root = await env.login("root")
    key = (await make(env, root))["created"]["key"]
    for _ in range(3):
        await env.client.get("/api/auth/me", headers={"X-API-Key": key})
    api_keys._written.clear()
    await env.client.get("/api/auth/me", headers={"X-API-Key": key})
    row = (await env.client.get("/api/admin/api-keys", headers=root)).json()["keys"][0]
    assert row["last_used_at"] and row["last_used_ip"] == "127.0.0.1" and row["uses"] == 4
    r = await env.client.get("/api/admin/api-keys/openapi.json", headers=root)
    assert r.status_code == 200 and "/api/admin/team/live" in r.json()["paths"] and r.json()["components"]["securitySchemes"]["apiKey"]["name"] == "X-API-Key"
    assert (await env.client.get("/openapi.json")).status_code == 404  # still not public
