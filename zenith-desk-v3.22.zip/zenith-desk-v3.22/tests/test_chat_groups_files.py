"""v3.20 internal messenger: files, group conversations and the «typing…» indicator.

Users of the test environment: 1 anna (operator), 2 boris (operator), 3 boss (manager), 4 root (administrator).
"""
import base64

import pytest
from sqlalchemy import select

from app.api import chat as chat_api
from app.models import AgentMapping, ChatFile

PNG = base64.b64encode(b"\x89PNG\r\n\x1a\n" + b"\x00" * 64).decode()


def spy_on(env):
    spy = []
    orig = env.services.broker.publish_agent
    env.services.broker.publish_agent = lambda aid, ev, data: (spy.append((aid, ev, data)), orig(aid, ev, data))
    return spy


@pytest.fixture(autouse=True)
def fresh_typing_throttle():
    chat_api._typing_sent.clear()
    yield
    chat_api._typing_sent.clear()


@pytest.mark.asyncio
async def test_files_in_a_direct_message(env):
    anna, boss, boris, root = await env.login("anna"), await env.login("boss"), await env.login("boris"), await env.login("root")
    r = await env.client.post("/api/chat/1/messages", json={"body": "", "files": [
        {"name": "../../etc/screen shot.png", "mime": "image/png", "data": PNG},
        {"name": "report.html", "mime": "text/html", "data": base64.b64encode(b"<script>alert(1)</script>").decode()}]}, headers=boss)
    assert r.status_code == 200, r.text
    files = r.json()["files"]
    assert [f["name"] for f in files] == ["screen shot.png", "report.html"]  # no folders in the name
    assert r.json()["body"] == ""
    # both people of the conversation can download; the picture is shown inline, HTML only ever as a download
    img = await env.client.get(f"/api/chat/files/{files[0]['key']}", headers=anna)
    assert img.status_code == 200 and img.headers["content-type"] == "image/png" and img.content.startswith(b"\x89PNG")
    assert img.headers["x-content-type-options"] == "nosniff" and "sandbox" in img.headers["content-security-policy"]
    html = await env.client.get(f"/api/chat/files/{files[1]['key']}", headers=boss)
    assert html.headers["content-type"] == "application/octet-stream" and html.headers["content-disposition"].startswith("attachment")
    # nobody else — not a colleague, not the administrator — and nobody without signing in
    assert (await env.client.get(f"/api/chat/files/{files[0]['key']}", headers=boris)).status_code == 404
    assert (await env.client.get(f"/api/chat/files/{files[0]['key']}", headers=root)).status_code == 404
    assert (await env.client.get(f"/api/chat/files/{files[0]['key']}")).status_code == 401
    assert (await env.client.get("/api/chat/files/not-a-key", headers=anna)).status_code == 404
    # stored encrypted
    async with env.services.db.sessionmaker() as s:
        row = (await s.execute(select(ChatFile).where(ChatFile.key == files[0]["key"]))).scalars().one()
        assert b"PNG" not in row.data and row.size == 72
    # the list shows the file as the last message; the history carries the files
    last = next(c for c in (await env.client.get("/api/chat/contacts", headers=anna)).json()["contacts"] if c["id"] == 3)["last"]
    assert len(last["files"]) == 2
    hist = (await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"]
    assert hist[-1]["files"][0]["key"] == files[0]["key"]
    # deleting the message for everyone deletes its files
    assert (await env.client.delete(f"/api/chat/messages/{r.json()['id']}?scope=all", headers=boss)).status_code == 200
    assert (await env.client.get(f"/api/chat/files/{files[0]['key']}", headers=anna)).status_code == 404


@pytest.mark.asyncio
async def test_file_limits_and_bad_files(env):
    boss = await env.login("boss")
    send = lambda files, body="": env.client.post("/api/chat/1/messages", json={"body": body, "files": files}, headers=boss)  # noqa: E731
    assert (await send([])).status_code == 422                                   # nothing to send
    assert (await send([{"name": "x.bin", "data": "@@not base64@@"}])).status_code == 422
    assert (await send([{"name": "f.txt", "data": PNG}] * 11)).status_code == 422  # more than 10 files
    big = base64.b64encode(b"a" * (chat_api.MAX_FILE_MB * 1024 * 1024 + 1)).decode()
    assert (await send([{"name": "big.bin", "data": big}])).status_code == 413
    ok = (await send([{"name": "", "data": PNG}], "x")).status_code
    assert ok == 422  # a file needs a name
    r = await send([{"name": "notes.txt", "mime": "text/plain; <script>", "data": base64.b64encode(b"hello").decode()}], "see")
    assert r.status_code == 200 and r.json()["files"][0]["mime"] == "application/octet-stream"  # a strange type is not trusted


@pytest.mark.asyncio
async def test_group_conversation(env):
    anna, boris, boss, root = await env.login("anna"), await env.login("boris"), await env.login("boss"), await env.login("root")
    spy = spy_on(env)
    r = await env.client.post("/api/chat/groups", json={"name": "  Night   shift ", "members": [1, 2, 3, 1]}, headers=boss)
    assert r.status_code == 200, r.text
    g = r.json()
    assert g["name"] == "Night shift" and g["role"] == "owner"
    assert sorted(m["id"] for m in g["members"]) == [1, 2, 3]
    assert {a for a, e, _ in spy if e == "chat_group"} == {1, 2, 3}
    gid = g["id"]
    # a message with a file reaches every member, also the sender's other tabs
    spy.clear()
    m = (await env.client.post(f"/api/chat/groups/{gid}/messages", json={"body": "Who takes the phone?",
                                                                          "files": [{"name": "plan.png", "mime": "image/png", "data": PNG}]}, headers=boss)).json()
    assert m["group"] == gid and m["to"] is None
    assert {a for a, e, _ in spy if e == "chat"} == {1, 2, 3}
    ev = next(d for a, e, d in spy if e == "chat" and a == 1)
    assert ev["group"] == {"id": gid, "name": "Night shift"} and ev["sender"]["name"] == "Руководитель"
    # in the list of every member, unread for the others
    c = next(x for x in (await env.client.get("/api/chat/contacts", headers=anna)).json()["contacts"] if x.get("kind") == "group")
    assert c["id"] == gid and c["unread"] == 1 and c["members"] == 3 and c["last"]["sender_name"] == "Руководитель"
    assert (await env.client.get("/api/chat/unread", headers=anna)).json() == {"unread": 1}
    assert (await env.client.post(f"/api/chat/groups/{gid}/read", headers=anna)).json()["read"] == m["id"]
    assert (await env.client.get("/api/chat/unread", headers=anna)).json() == {"unread": 0}
    # members read the history and the file; the administrator (not a member) sees nothing of it
    assert [x["body"] for x in (await env.client.get(f"/api/chat/groups/{gid}/messages", headers=boris)).json()["messages"]] == ["Who takes the phone?"]
    assert (await env.client.get(f"/api/chat/files/{m['files'][0]['key']}", headers=boris)).status_code == 200
    for path in (f"/api/chat/groups/{gid}", f"/api/chat/groups/{gid}/messages", f"/api/chat/files/{m['files'][0]['key']}"):
        assert (await env.client.get(path, headers=root)).status_code == 404, path
    assert (await env.client.post(f"/api/chat/groups/{gid}/messages", json={"body": "hi"}, headers=root)).status_code == 404
    assert not [c for c in (await env.client.get("/api/chat/contacts", headers=root)).json()["contacts"] if c.get("kind") == "group"]
    # reactions and edits reach the group; only the author edits; in a group a message is deleted only for everyone
    assert (await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "👍"}, headers=anna)).status_code == 200
    assert (await env.client.patch(f"/api/chat/messages/{m['id']}", json={"body": "x"}, headers=anna)).status_code == 403
    assert (await env.client.delete(f"/api/chat/messages/{m['id']}?scope=me", headers=anna)).status_code == 403
    assert (await env.client.delete(f"/api/chat/messages/{m['id']}?scope=all", headers=anna)).status_code == 403
    assert (await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "👍"}, headers=root)).status_code == 404
    # only the owner renames, adds and removes; anybody may leave
    assert (await env.client.patch(f"/api/chat/groups/{gid}", json={"name": "Hack"}, headers=anna)).status_code == 403
    assert (await env.client.post(f"/api/chat/groups/{gid}/members", json={"user_ids": [4]}, headers=anna)).status_code == 403
    assert (await env.client.delete(f"/api/chat/groups/{gid}/members/2", headers=anna)).status_code == 403
    assert (await env.client.patch(f"/api/chat/groups/{gid}", json={"name": "Night team"}, headers=boss)).json()["name"] == "Night team"
    assert (await env.client.delete(f"/api/chat/groups/{gid}/members/2", headers=boss)).status_code == 200
    assert (await env.client.get(f"/api/chat/groups/{gid}/messages", headers=boris)).status_code == 404  # removed = no access
    added = (await env.client.post(f"/api/chat/groups/{gid}/members", json={"user_ids": [2]}, headers=boss)).json()
    assert 2 in [x["id"] for x in added["members"]]
    assert (await env.client.get("/api/chat/unread", headers=boris)).json() == {"unread": 0}  # old history is not «unread»
    # the owner leaves: the longest member becomes the owner
    assert (await env.client.delete(f"/api/chat/groups/{gid}/members/3", headers=boss)).status_code == 200
    info = (await env.client.get(f"/api/chat/groups/{gid}", headers=anna)).json()
    assert info["role"] == "owner" and 3 not in [x["id"] for x in info["members"]]


@pytest.mark.asyncio
async def test_group_validation(env):
    boss = await env.login("boss")
    post = lambda body: env.client.post("/api/chat/groups", json=body, headers=boss)  # noqa: E731
    assert (await post({"name": "Only me", "members": [3]})).status_code == 422       # nobody else
    assert (await post({"name": "   ", "members": [1]})).status_code == 422
    assert (await post({"name": "x" * 101, "members": [1]})).status_code == 422
    assert (await post({"name": "Ghost", "members": [1, 999]})).status_code == 404     # unknown colleague
    async with env.services.db.sessionmaker() as s:
        (await s.get(AgentMapping, 2)).active = False
        await s.commit()
    assert (await post({"name": "Disabled", "members": [2]})).status_code == 404       # disabled account
    assert (await env.client.get("/api/chat/groups/12345", headers=boss)).status_code == 404
    assert (await env.client.post("/api/chat/groups", json={"name": "x", "members": [1]})).status_code == 401


@pytest.mark.asyncio
async def test_typing_goes_only_to_the_right_people(env):
    anna, boris, boss, root = await env.login("anna"), await env.login("boris"), await env.login("boss"), await env.login("root")
    spy = spy_on(env)
    # direct: the colleague gets the name of who types
    assert (await env.client.post("/api/chat/3/typing", headers=anna)).status_code == 200
    assert [(a, d) for a, e, d in spy if e == "chat_typing"] == [(3, {"from": 1, "name": "Анна"})]
    # not to yourself, not to nobody, not to a disabled account, not without signing in, not with a bad id
    assert (await env.client.post("/api/chat/1/typing", headers=anna)).status_code == 400
    assert (await env.client.post("/api/chat/999/typing", headers=anna)).status_code == 404
    assert (await env.client.post("/api/chat/abc/typing", headers=anna)).status_code == 422
    assert (await env.client.post("/api/chat/3/typing")).status_code == 401
    async with env.services.db.sessionmaker() as s:
        (await s.get(AgentMapping, 2)).active = False
        await s.commit()
    assert (await env.client.post("/api/chat/2/typing", headers=anna)).status_code == 409
    assert [a for a, e, _ in spy if e == "chat_typing"] == [3]
    # a flood is throttled: many requests, one event
    spy.clear()
    for _ in range(20):
        await env.client.post("/api/chat/3/typing", headers=root)
    assert len([1 for a, e, _ in spy if e == "chat_typing"]) == 1
    # group: to the other members only, with the group; a stranger may not type into it
    async with env.services.db.sessionmaker() as s:
        (await s.get(AgentMapping, 2)).active = True
        await s.commit()
    gid = (await env.client.post("/api/chat/groups", json={"name": "Shift", "members": [1, 2]}, headers=boss)).json()["id"]
    spy.clear()
    assert (await env.client.post(f"/api/chat/groups/{gid}/typing", headers=anna)).status_code == 200
    got = [(a, d) for a, e, d in spy if e == "chat_typing"]
    assert sorted(a for a, _ in got) == [2, 3] and all(d == {"from": 1, "name": "Анна", "group": gid} for _, d in got)
    assert (await env.client.post(f"/api/chat/groups/{gid}/typing", headers=root)).status_code == 404
    assert (await env.client.post("/api/chat/groups/999/typing", headers=anna)).status_code == 404
