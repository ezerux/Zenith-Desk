"""v3.18 call routing for managers: overflow, ring strategy per queue, VIP / the last operator."""
import asyncio
from datetime import timedelta

from sqlalchemy import select

from app.db import utcnow
from app.models import AgentMapping, AuditLog, CallRecord, QueueCall

from .conftest import IF1, IF2


async def ev(env, **e):
    await env.services.calls.handle_event(e)
    await env.services.routing.on_event(e)
    await asyncio.sleep(0.05)  # VIP decisions run in their own task


async def put(env, h, **cfg):
    return await env.client.put("/api/admin/call-routing", json=cfg, headers=h)


async def set_level(env, aid, level):
    async with env.services.db.sessionmaker() as s:
        (await s.get(AgentMapping, aid)).level = level
        await s.commit()


async def qrow(env, linkedid):
    async with env.services.db.sessionmaker() as s:
        return (await s.execute(select(QueueCall).where(QueueCall.linkedid == linkedid))).scalars().first()


async def test_rights_and_validation(env):
    boss, anna = await env.login("boss"), await env.login("anna")
    assert (await env.client.get("/api/admin/call-routing", headers=anna)).status_code == 403
    v = (await env.client.get("/api/admin/call-routing", headers=boss)).json()
    assert [q["queue"] for q in v["queues"]] == ["400", "401"] and v["modes"] == ["rrmemory", "leastrecent", "fewestcalls", "ringall"]
    assert (await put(env, boss, queues={"999": {"mode": ""}})).status_code == 422
    assert (await put(env, boss, queues={"400": {"mode": "linear"}})).status_code == 422
    assert (await put(env, boss, queues={"400": {"overflow": {"enabled": True, "add": []}}})).status_code == 422
    assert (await put(env, boss, queues={"400": {"overflow": {"enabled": True, "waiting": 0, "add": ["level2"]}}})).status_code == 422
    assert (await put(env, boss, vip={"enabled": True, "rules": [{"match": "12", "target": "level1"}]})).status_code == 422
    assert (await put(env, boss, vip={"enabled": True, "rules": [{"match": "+37491123456", "target": "agent:999"}]})).status_code == 422
    r = await put(env, boss, vip={"enabled": True, "rules": [{"match": "+37491123456", "target": "agent:2", "note": "Director"}]})
    assert r.status_code == 200 and r.json()["vip"]["rules"][0]["note"] == "Director"
    # kept in the database: a restart (or a restored backup) has the same rules
    env.services.routing.cfg = {"queues": {}, "vip": {"enabled": False, "rules": []}}
    await env.services.routing.load()
    assert env.services.routing.cfg["vip"]["rules"][0]["target"] == "agent:2"


async def test_overflow_adds_level2_and_goes_back(env):
    cfg, sv = env.settings, env.services
    cfg.level_routing, cfg.penalty_level1, cfg.penalty_level2, cfg.penalty_level3 = True, 0, 1, 2
    await set_level(env, 2, "level2")
    boss = await env.login("boss")
    for h in (await env.login("anna"), await env.login("boris")):
        await env.client.post("/api/agents/me/ready", headers=h)
    await sv.engine.recompute(2, "test")
    assert env.pbx.members["400"][IF2]["penalty"] == 1 and env.pbx.members["400"][IF1]["penalty"] == 0
    r = await put(env, boss, queues={"400": {"overflow": {"enabled": True, "waiting": 2, "wait_sec": 0, "add": ["level2"], "calm_sec": 10}}})
    assert r.status_code == 200, r.text
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+1001", Uniqueid="o1", Linkedid="o1", Channel="PJSIP/trunk-o1")
    await sv.routing.tick()
    assert "400" not in sv.routing.active  # one waiting: not yet
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+1002", Uniqueid="o2", Linkedid="o2", Channel="PJSIP/trunk-o2")
    await sv.routing.tick()
    assert "400" in sv.routing.active
    # Boris (Level 2) rings in the first line of queue 400 — only there
    assert env.pbx.members["400"][IF2]["penalty"] == 0 and env.pbx.members["401"][IF2]["penalty"] == 1
    assert env.pbx.members["400"][IF1]["penalty"] == 0
    v = (await env.client.get("/api/admin/call-routing", headers=boss)).json()
    q = next(x for x in v["queues"] if x["queue"] == "400")
    assert q["overflow_active_since"] and q["waiting"] == 2
    rt = (await env.client.get("/api/admin/routing", headers=boss)).json()
    m = next(x for x in next(x for x in rt["queues"] if x["queue"] == "400")["members"] if x["interface"] == IF2)
    assert m["expected_penalty"] == 0 and m["penalty"] == 0
    # calm again: back after calm_sec
    for lid in ("o1", "o2"):
        await ev(env, Event="QueueCallerAbandon", Queue="400", HoldTime="9", Uniqueid=lid, Linkedid=lid)
        await ev(env, Event="Hangup", Uniqueid=lid, Linkedid=lid)
    await sv.routing.tick()
    assert "400" in sv.routing.active  # not at once
    await sv.routing.tick(utcnow() + timedelta(seconds=11))
    assert "400" not in sv.routing.active and env.pbx.members["400"][IF2]["penalty"] == 1
    async with sv.db.sessionmaker() as s:
        acts = [a.action for a in (await s.execute(select(AuditLog).where(AuditLog.action.like("callroute_overflow%")))).scalars().all()]
    assert acts == ["callroute_overflow_on", "callroute_overflow_off"]
    # a long wait alone switches it on too; switching the rule off ends an active overflow at once
    await put(env, boss, queues={"400": {"overflow": {"enabled": True, "waiting": 5, "wait_sec": 30, "add": ["level2"], "calm_sec": 10}}})
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+1003", Uniqueid="o3", Linkedid="o3", Channel="PJSIP/trunk-o3")
    await sv.routing.tick()
    assert "400" not in sv.routing.active
    await sv.routing.tick(utcnow() + timedelta(seconds=31))
    assert "400" in sv.routing.active and env.pbx.members["400"][IF2]["penalty"] == 0
    await put(env, boss, queues={"400": {"overflow": {"enabled": False, "add": ["level2"]}}})
    assert "400" not in sv.routing.active and env.pbx.members["400"][IF2]["penalty"] == 1


async def test_ring_strategy(env):
    boss, sv = await env.login("boss"), env.services
    env.settings.routing_strategy_via_ami = False
    r = await put(env, boss, queues={"400": {"mode": "leastrecent"}})
    q = next(x for x in r.json()["queues"] if x["queue"] == "400")
    assert q["mode"] == "leastrecent" and "FreePBX" in q["strategy_error"] and "400" not in env.pbx.strategies
    env.settings.routing_strategy_via_ami = True
    r = await put(env, boss, queues={"400": {"mode": "fewestcalls"}})
    q = next(x for x in r.json()["queues"] if x["queue"] == "400")
    assert env.pbx.strategies["400"] == "fewestcalls" and q["strategy_now"] == "fewestcalls" and not q["strategy_error"]
    assert ("400", "strategy", "fewestcalls", "queues_additional.conf") in env.pbx.commands
    # FreePBX «Apply config» writes its own strategy again → Zenith Desk puts it back
    env.pbx.strategies["400"] = "ringall"
    await sv.routing.keep_strategies()
    assert env.pbx.strategies["400"] == "fewestcalls"


async def test_vip_goes_straight_to_the_employee(env):
    sv, boss = env.services, await env.login("boss")
    boris = await env.login("boris")
    await env.client.post("/api/agents/me/ready", headers=boris)
    await put(env, boss, vip={"enabled": True, "ring_sec": 15, "rules": [{"match": "+37491123456", "target": "agent:2", "note": "Director"}]})
    t = (await env.client.get("/api/admin/call-routing/test?number=%2B37491123456", headers=boss)).json()
    assert t["agent"]["id"] == 2 and t["reason"] == "rule"
    assert (await env.client.get("/api/admin/call-routing/test?number=%2B37499999999", headers=boss)).json()["agent"] is None
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37491123456", Uniqueid="v1", Linkedid="v1", Channel="PJSIP/trunk-0001")
    assert env.pbx.redirects == [("PJSIP/trunk-0001", "from-internal", "102")]
    assert (await qrow(env, "v1")).outcome == "redirected"
    live = (await env.client.get("/api/admin/team/live", headers=boss)).json()
    assert live["waiting_total"] == 0 and next(x for x in live["feed"] if x["id"] == "v1")["result"] == "waiting"
    # boris answers on his phone (DialEnd of the customer's channel)
    await ev(env, Event="DialBegin", Channel="PJSIP/trunk-0001", DestChannel="PJSIP/102-0009", CallerIDNum="+37491123456", Uniqueid="v1", Linkedid="v1")
    await ev(env, Event="DialEnd", Channel="PJSIP/trunk-0001", DestChannel="PJSIP/102-0009", DialStatus="ANSWER", Uniqueid="v1", Linkedid="v1")
    row = await qrow(env, "v1")
    assert row.outcome == "answered" and row.agent_id == 2 and not sv.routing.pending
    live = (await env.client.get("/api/admin/team/live", headers=boss)).json()
    assert next(x for x in live["feed"] if x["id"] == "v1")["result"] in ("talking", "answered") and live["today"]["answered"] == 1
    # the same call coming back into a queue is never routed twice
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37491123456", Uniqueid="v1", Linkedid="v1", Channel="PJSIP/trunk-0001")
    assert len(env.pbx.redirects) == 1


async def test_vip_nobody_answers_back_to_the_queue(env):
    sv, boss = env.services, await env.login("boss")
    anna = await env.login("anna")
    await env.client.post("/api/agents/me/ready", headers=anna)
    await put(env, boss, vip={"enabled": True, "ring_sec": 20, "rules": [{"match": "+3741*", "target": "level1"}]})
    await ev(env, Event="QueueCallerJoin", Queue="401", CallerIDNum="+37410555000", Uniqueid="v2", Linkedid="v2", Channel="PJSIP/trunk-0002")
    assert env.pbx.redirects[-1] == ("PJSIP/trunk-0002", "from-internal", "101")
    await sv.routing.tick()
    assert sv.routing.pending  # still ringing
    await sv.routing.tick(utcnow() + timedelta(seconds=21))
    assert env.pbx.redirects[-1] == ("PJSIP/trunk-0002", "from-internal", "401") and not sv.routing.pending
    await ev(env, Event="QueueCallerJoin", Queue="401", CallerIDNum="+37410555000", Uniqueid="v2", Linkedid="v2", Channel="PJSIP/trunk-0002")
    assert (await qrow(env, "v2")).outcome == "waiting" and len(env.pbx.redirects) == 2
    # busy / no answer from the phone: back at once
    await ev(env, Event="QueueCallerJoin", Queue="401", CallerIDNum="+37410555001", Uniqueid="v3", Linkedid="v3", Channel="PJSIP/trunk-0003")
    await ev(env, Event="DialEnd", Channel="PJSIP/trunk-0003", DialStatus="BUSY", Uniqueid="v3", Linkedid="v3")
    assert env.pbx.redirects[-1] == ("PJSIP/trunk-0003", "from-internal", "401")
    # the customer hangs up while it rings: an abandoned call
    await ev(env, Event="QueueCallerJoin", Queue="401", CallerIDNum="+37410555002", Uniqueid="v4", Linkedid="v4", Channel="PJSIP/trunk-0004")
    await ev(env, Event="Hangup", Uniqueid="v4", Linkedid="v4")
    assert (await qrow(env, "v4")).outcome == "abandoned" and "v4" not in sv.routing.pending
    async with sv.db.sessionmaker() as s:
        backs = (await s.execute(select(AuditLog).where(AuditLog.action == "callroute_vip_back"))).scalars().all()
    assert [b.details["reason"] for b in backs] == ["timeout", "busy"]


async def test_target_busy_stays_in_queue_and_sticky_operator(env):
    sv, boss = env.services, await env.login("boss")
    anna = await env.login("anna")
    await put(env, boss, vip={"enabled": True, "sticky": True, "sticky_days": 30, "rules": [{"match": "+37491000001", "target": "agent:2"}]})
    # Boris is not ready: the VIP stays in the queue (and the log says why)
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37491000001", Uniqueid="s1", Linkedid="s1", Channel="PJSIP/trunk-s1")
    assert env.pbx.redirects == [] and (await qrow(env, "s1")).outcome == "waiting"
    async with sv.db.sessionmaker() as s:
        row = (await s.execute(select(AuditLog).where(AuditLog.action == "callroute_vip"))).scalars().first()
    assert row.details["result"] == "queue" and row.details["reason"] == "busy"
    # Anna talked to this customer last week: he goes to her (she is free)
    async with sv.db.sessionmaker() as s:
        s.add(CallRecord(linkedid="old1", agent_id=1, direction="in", caller_number="+37477123123", caller_normalized="37477123123",
                         state="ended", started_at=utcnow() - timedelta(days=6), answered_at=utcnow() - timedelta(days=6),
                         ended_at=utcnow() - timedelta(days=6)))
        await s.commit()
    await env.client.post("/api/agents/me/ready", headers=anna)
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37477123123", Uniqueid="s2", Linkedid="s2", Channel="PJSIP/trunk-s2")
    assert env.pbx.redirects == [("PJSIP/trunk-s2", "from-internal", "101")]
    t = (await env.client.get("/api/admin/call-routing/test?number=%2B37477123123", headers=boss)).json()
    assert t["reason"] in ("sticky", "busy")  # anna's phone rings now
    # switched off: nothing happens
    await put(env, boss, vip={"enabled": False})
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+37477123123", Uniqueid="s3", Linkedid="s3", Channel="PJSIP/trunk-s3")
    assert len(env.pbx.redirects) == 1


async def test_overflow_lets_ticket_busy_helpers_take_calls(env):
    """A Level 2 colleague busy with a ticket normally gets no calls (paused); in an overloaded queue he helps there."""
    cfg, sv = env.settings, env.services
    cfg.level_routing = True
    await set_level(env, 2, "level2")
    boss, boris = await env.login("boss"), await env.login("boris")
    await env.client.post("/api/agents/me/ready", headers=boris)
    t = env.zammad.add_ticket("Printer", owner_id=11, state="open")
    r = await env.client.post(f"/api/tickets/{t['id']}/start", json={"work_mode": "blocking"}, headers=boris)
    assert r.status_code == 200, r.text
    assert env.pbx.members["400"][IF2]["paused"] and env.pbx.members["401"][IF2]["paused"]
    await put(env, boss, queues={"400": {"overflow": {"enabled": True, "waiting": 1, "wait_sec": 0, "add": ["level2"], "calm_sec": 10}}})
    await ev(env, Event="QueueCallerJoin", Queue="400", CallerIDNum="+1009", Uniqueid="h1", Linkedid="h1", Channel="PJSIP/trunk-h1")
    await sv.routing.tick()
    assert not env.pbx.members["400"][IF2]["paused"] and env.pbx.members["401"][IF2]["paused"]  # helps only where it is needed
    b = {a["agent_id"]: a for a in (await env.client.get("/api/admin/agents", headers=boss)).json()["agents"]}
    assert b[2]["computed_state"] == "busy_task" and b[2]["phone_status"] == "receiving"
    await ev(env, Event="QueueCallerAbandon", Queue="400", HoldTime="9", Uniqueid="h1", Linkedid="h1")
    await ev(env, Event="Hangup", Uniqueid="h1", Linkedid="h1")
    await sv.routing.tick()  # calm from now on
    await sv.routing.tick(utcnow() + timedelta(seconds=11))
    assert env.pbx.members["400"][IF2]["paused"] and env.pbx.members["401"][IF2]["paused"]  # back to his ticket
