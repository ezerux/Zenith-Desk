"""SEC-04: CR/LF injection into Asterisk AMI (CWE-93) — the encoder refuses control characters, and the admin
form only accepts characters a channel / extension can contain. Users: 1 anna, 2 boris, 3 boss, 4 root."""

import pytest

from app.ami import AMIClient, AMIError, AMIUnsafeField, build_message

INJECT = "101\r\n\r\nAction: Originate\r\nChannel: PJSIP/900\r\nApplication: System\r\nData: id"


def test_normal_messages_are_unchanged():
    assert build_message({"Action": "Ping", "ActionID": "aws-1"}) == b"Action: Ping\r\nActionID: aws-1\r\n\r\n"
    assert build_message({"Interface": "Local/101@from-queue/n"}) == b"Interface: Local/101@from-queue/n\r\n\r\n"


@pytest.mark.parametrize("fields", [
    {"Action": "QueuePause", "Interface": INJECT},
    {"Action": "Redirect", "Exten": "1\n"},
    {"Action": "Ping", "Variable": "a\rb"},
    {"Action": "Ping", "Data": "x\0y"},
    {"Bad\r\nKey": "v"},
    {"Action: Originate\r\nX": "v"},
    {"Na:me": "v"},
])
def test_the_encoder_refuses_framing_characters(fields):
    with pytest.raises(AMIUnsafeField):
        build_message(fields)
    assert issubclass(AMIUnsafeField, AMIError)  # callers that already handle AMIError keep working


class _Writer:
    def __init__(self):
        self.data = b""

    def write(self, b):
        self.data += b

    async def drain(self):
        pass


@pytest.mark.asyncio
async def test_nothing_reaches_the_socket_and_nothing_is_left_pending():
    c = AMIClient.__new__(AMIClient)
    import itertools
    c._ids, c._pending, c._writer, c.action_timeout = itertools.count(1), {}, _Writer(), 1
    with pytest.raises(AMIUnsafeField):
        await c._send({"Action": "QueuePause", "Interface": INJECT})
    assert c._writer.data == b"" and c._pending == {}


async def anna_body(env, root):
    users = (await env.client.get("/api/admin/users", headers=root)).json()
    a = next(u for u in users if u["username"] == "anna")
    body = {k: a[k] for k in ("last_name", "username", "position", "role", "level", "zammad_user_id",
                              "extension", "asterisk_interface", "enabled")}
    return a, {**body, "first_name": "Anna"}


@pytest.mark.asyncio
@pytest.mark.parametrize("field,value", [
    ("extension", INJECT), ("extension", "10 1"), ("extension", "101;drop"),
    ("asterisk_interface", "Local/101@from-queue/n\r\nAction: Command"), ("asterisk_interface", "PJSIP/101 x"),
    ("sip_user", "anna\nAction: Logoff"), ("sip_user", "a b"),
])
async def test_admin_form_refuses_unsafe_telephony_values(env, field, value):
    root = await env.login("root")
    user, body = await anna_body(env, root)
    body[field] = value
    r = await env.client.put(f"/api/admin/users/{user['id']}", json=body, headers=root)
    assert r.status_code == 422 and field in r.text, (field, r.status_code, r.text[:200])


@pytest.mark.asyncio
@pytest.mark.parametrize("field,value", [
    ("extension", "105"), ("extension", "*72"), ("extension", "sales-1"),
    ("asterisk_interface", "Local/105@from-queue/n"), ("asterisk_interface", "PJSIP/105"), ("asterisk_interface", ""),
    ("sip_user", "anna.k"), ("sip_user", ""),
])
async def test_admin_form_keeps_accepting_real_values(env, field, value):
    root = await env.login("root")
    user, body = await anna_body(env, root)
    body[field] = value
    r = await env.client.put(f"/api/admin/users/{user['id']}", json=body, headers=root)
    assert r.status_code == 200, (field, r.status_code, r.text[:300])
