"""v3.21: the administrator's users panel — sign-in attempts, lock / unlock with the address it came from,
presence and live connections, «sign out everywhere», groups and access. Users: 1 anna, 2 boris, 3 boss, 4 root."""
from datetime import timedelta

import httpx
import pytest
from sqlalchemy import select

from app.db import utcnow
from app.models import AuditLog, LoginAttempt
from app.user_insight import access_for, device

WIN = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36"
IPHONE = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"


def client_from(env, ip: str) -> httpx.AsyncClient:
    """A second browser on another computer of the office network."""
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=env.client._transport.app, client=(ip, 50000)), base_url="http://test")


async def attempts(env, **where):
    async with env.services.db.sessionmaker() as s:
        q = select(LoginAttempt).order_by(LoginAttempt.id)
        for k, v in where.items():
            q = q.where(getattr(LoginAttempt, k) == v)
        return (await s.execute(q)).scalars().all()


def test_device_names():
    assert device(WIN) == "Chrome · Windows"
    assert device(IPHONE) == "Safari · iPhone"
    assert device("Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 Chrome/141 Safari/537.36 Edg/141.0") == "Edge · Windows"
    assert device("Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0") == "Firefox · Linux"
    assert device("python-httpx/0.28") == "Script" and device("") == ""


def test_access_by_role():
    op = {a["key"]: a["allowed"] for a in access_for("operator")}
    adm = {a["key"]: a["allowed"] for a in access_for("admin")}
    assert op["work"] and op["mail"] and not op["sup"] and not op["admin"]
    assert adm["admin"] and adm["sup"] and not adm["work"]
    assert {a["key"]: a["allowed"] for a in access_for("supervisor")}["overview"]


@pytest.mark.asyncio
async def test_every_attempt_is_recorded_with_address_and_device(env):
    pc = client_from(env, "10.0.0.15")
    try:
        assert (await pc.post("/api/auth/login", json={"username": "anna", "password": "pw"}, headers={"User-Agent": WIN})).status_code == 200
        assert (await pc.post("/api/auth/login", json={"username": "anna", "password": "bad"})).status_code == 401
        assert (await pc.post("/api/auth/login", json={"username": "nobody", "password": "x"})).status_code == 401
    finally:
        await pc.aclose()
    rows = await attempts(env)
    assert [(r.username, r.ip, r.result) for r in rows] == [
        ("anna", "10.0.0.15", "ok"), ("anna", "10.0.0.15", "bad_password"), ("nobody", "10.0.0.15", "unknown_user")]
    assert rows[0].agent_id == 1 and rows[2].agent_id is None and "Windows" in rows[0].user_agent


@pytest.mark.asyncio
async def test_lock_shows_where_the_attempts_came_from_and_admin_unlocks(env):
    boris_pc, other_pc, mariam_pc = client_from(env, "10.0.0.16"), client_from(env, "10.0.0.23"), client_from(env, "10.0.0.23")
    try:
        assert (await boris_pc.post("/api/auth/login", json={"username": "boris", "password": "pw"})).status_code == 200
        assert (await mariam_pc.post("/api/auth/login", json={"username": "anna", "password": "pw"})).status_code == 200  # anna's own sign-in from .23
        for _ in range(5):
            assert (await other_pc.post("/api/auth/login", json={"username": "boris", "password": "guess"})).status_code == 401
        r = await boris_pc.post("/api/auth/login", json={"username": "boris", "password": "pw"})
        assert r.status_code == 429  # locked: even the right password waits
    finally:
        for c in (boris_pc, other_pc, mariam_pc):
            await c.aclose()

    root = await env.login("root")
    users = {u["username"]: u for u in (await env.client.get("/api/admin/users", headers=root)).json()}
    assert users["boris"]["locked"] and users["boris"]["failed_24h"] >= 5 and users["boris"]["last_login_ip"] == "10.0.0.16"
    assert users["anna"]["locked"] is None

    d = (await env.client.get("/api/admin/users/2/details", headers=root)).json()
    lock = d["lock"]
    assert lock["ip"] == "10.0.0.23" and lock["usual_ip"] == "10.0.0.16" and lock["foreign"] is True
    assert lock["last_user_on_ip"]["name"] == "Анна" and lock["last_user_on_ip"]["same_user"] is False
    assert [a["result"] for a in d["attempts"]][:2] == ["locked", "bad_password"] and d["attempts"][-1]["result"] == "ok"

    async with env.services.db.sessionmaker() as s:
        locked = (await s.execute(select(AuditLog).where(AuditLog.action == "login_locked"))).scalars().all()
    assert len(locked) == 1 and locked[0].details["ip"] == "10.0.0.23" and locked[0].agent_id == 2
    ntf = (await env.client.get("/api/agents/me/notifications", headers=root)).json()["items"]
    assert any("10.0.0.23" in i["text"] for i in ntf)  # the administrator's bell

    assert (await env.client.post("/api/admin/users/2/unlock", headers=await env.login("boss"))).status_code == 403
    r = await env.client.post("/api/admin/users/2/unlock", headers=root)
    assert r.status_code == 200 and r.json()["was_locked"] is True
    assert (await env.client.post("/api/auth/login", json={"username": "boris", "password": "pw"})).status_code == 200
    async with env.services.db.sessionmaker() as s:
        un = (await s.execute(select(AuditLog).where(AuditLog.action == "login_unlocked"))).scalars().one()
    assert un.actor_id == 4 and un.agent_id == 2


@pytest.mark.asyncio
async def test_own_typos_are_not_foreign(env):
    pc = client_from(env, "10.0.0.16")
    try:
        await pc.post("/api/auth/login", json={"username": "boris", "password": "pw"})
        for _ in range(5):
            await pc.post("/api/auth/login", json={"username": "boris", "password": "typo"})
    finally:
        await pc.aclose()
    d = (await env.client.get("/api/admin/users/2/details", headers=await env.login("root"))).json()
    assert d["lock"]["ip"] == "10.0.0.16" and d["lock"]["foreign"] is False and d["lock"]["last_user_on_ip"]["same_user"] is True


@pytest.mark.asyncio
async def test_presence_and_connections(env):
    root = await env.login("root")
    b = env.services.broker
    g1 = b.stream(1, False, heartbeat=60, meta={"ip": "10.0.0.15", "ua": WIN, "since": utcnow()})
    g2 = b.stream(1, False, heartbeat=60, meta={"ip": "10.0.0.41", "ua": IPHONE, "since": utcnow()})
    for g in (g1, g2):
        await g.__anext__(); await g.__anext__()
    try:
        users = {u["username"]: u for u in (await env.client.get("/api/admin/users", headers=root)).json()}
        assert users["anna"]["online"] and users["anna"]["connections"] == 2
        assert users["boris"]["online"] is False and users["boris"]["state"] == "offline"
        d = (await env.client.get("/api/admin/users/1/details", headers=root)).json()
        assert {(c["ip"], c["device"]) for c in d["connections"]} == {("10.0.0.15", "Chrome · Windows"), ("10.0.0.41", "Safari · iPhone")}
        assert d["now"]["online"] and d["now"]["online_since"]
        assert d["telephony"]["extension"] == "101" and {a["key"] for a in d["access"] if a["allowed"]} >= {"work", "mail"}
        assert d["account"]["zammad_user_id"] == 10
    finally:
        await g1.aclose(); await g2.aclose()
    assert (await env.client.get("/api/admin/users", headers=root)).json()[0]["connections"] >= 0


@pytest.mark.asyncio
async def test_sign_out_everywhere(env):
    root = await env.login("root")
    desk, phone = await env.login("anna"), await env.login("anna")
    boris = await env.login("boris")
    r = await env.client.post("/api/admin/users/1/sign-out", headers=root)
    assert r.status_code == 200
    for h in (desk, phone):
        assert (await env.client.get("/api/auth/me", headers=h)).status_code == 401
    assert (await env.client.get("/api/auth/me", headers=boris)).status_code == 200  # only anna
    again = await env.login("anna")  # she can sign in again at once
    assert (await env.client.get("/api/auth/me", headers=again)).status_code == 200
    assert (await env.client.post("/api/admin/users/4/sign-out", headers=root)).status_code == 409  # not yourself
    assert (await env.client.post("/api/admin/users/1/sign-out", headers=await env.login("boss"))).status_code == 403
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(AuditLog).where(AuditLog.action == "sessions_revoked"))).scalars().one().actor_id == 4


@pytest.mark.asyncio
async def test_old_attempts_are_cleaned_up(env):
    await env.client.post("/api/auth/login", json={"username": "anna", "password": "x"})
    async with env.services.db.sessionmaker() as s:
        for a in (await s.execute(select(LoginAttempt))).scalars().all():
            a.ts = utcnow() - timedelta(days=31)
        await s.commit()
    done = await env.services.retention_cleanup()
    assert done.get("login_attempts") == 1 and not await attempts(env)


@pytest.mark.asyncio
async def test_a_locked_flood_is_written_once_a_minute(env):
    for _ in range(5):
        await env.client.post("/api/auth/login", json={"username": "boris", "password": "x"})
    for _ in range(30):
        assert (await env.client.post("/api/auth/login", json={"username": "boris", "password": "x"})).status_code == 429
    assert len(await attempts(env, result="locked")) == 1
