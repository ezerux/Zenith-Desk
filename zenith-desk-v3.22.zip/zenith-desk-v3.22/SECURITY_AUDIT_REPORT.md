# Zenith Desk — Security Audit Report

| | |
|---|---|
| Audited code | `v3.20.1` (tag) — findings also re-checked on `v3.18.1` |
| Patched code | branch `security-audit` → `v3.20.2` |
| Audit window | 2026-10-25 21:11 UTC → 2026-10-26 01:04 UTC (3 h 53 min) |
| Environment | isolated cloud container, local PostgreSQL 16 test database, simulated Zammad / Telegram / WhatsApp, the repository's Asterisk test container. No production system, data or credential was touched. |
| Method | full endpoint / task inventory, code review of every security-relevant module, multi-role tests, a reproduction script run against old and new code, static scanners, dependency audit, dynamic checks against a local instance |

> **This audit does not show that Zenith Desk is secure.** It shows that the issues listed here were found, that the
> ones marked FIXED no longer reproduce, and which areas were not or only partly tested (section 6). New code, a
> different deployment or a test method not used here can reveal further problems.

Status words used in this report: **FIXED** (fix + regression test, test ran and passed, reproduction now fails),
**OPEN** (known, not fixed — accepted risk or needs a decision), **VERIFIED** (checked by a test or a command that
actually ran), **PARTIALLY VERIFIED** (some evidence, not complete), **NOT TESTED**, **BLOCKED** (the tool or access
was not available here).

---

## 1. Summary

| ID | Finding | Severity | Status |
|---|---|---|---|
| SEC-02 | Production started with the published default `JWT_SECRET` (and default DB password) — anyone could forge an administrator session and decrypt stored secrets | **High** (if deployed with defaults) | FIXED |
| SEC-04 | CR/LF injection into Asterisk AMI commands (extension / interface / settings) | **Medium** | FIXED |
| SEC-07 | Sign-out did not end the session token (valid for 12 h more) | **Medium** | FIXED |
| SEC-09 | Password hashing ran on the server's event loop — unauthenticated sign-in attempts froze the whole server | **Medium** | FIXED |
| SEC-01 | Backup upload had no size limit and no free-space check (disk exhaustion) | **Medium** (admin) | FIXED |
| SEC-05 | Unlimited live-update (SSE) connections per user (memory / socket exhaustion) | **Low–Medium** | FIXED |
| SEC-08 | scrypt cost below the current OWASP recommendation | **Low** | FIXED |
| SEC-06 | Recording lookup treated `* ? [` in a file name as wildcards; walked the whole archive | **Low** | FIXED |
| SEC-03 | «typing…» event could be sent to any user id, unthrottled (v3.18.1) | **Low** | FIXED in v3.20 (evidence below) |
| SEC-10 | Log export (CSV) did not neutralise spreadsheet formulas | **Info** (hardening; not exploitable via current inputs) | FIXED |
| SEC-11 | Recording link template accepted `javascript:` / `data:` links that the browser opens | **Info** (admin-only input) | FIXED |
| R-01 … R-16 | Residual risks and design decisions | Low / Info | OPEN — section 5 |

Reproduction on the three versions (same script, `audit/repro.py`, results in `audit/repro-*.json`):

| ID | v3.18.1 | v3.20.1 | v3.20.2 |
|---|---|---|---|
| SEC-01 | VULNERABLE — 3 MB upload accepted with MAX_REQUEST_MB=1 (HTTP 200) | VULNERABLE (200) | FIXED — 413 |
| SEC-02 | VULNERABLE — production start with `change-me…` accepted | VULNERABLE | FIXED — start refused |
| SEC-03 | VULNERABLE — typing to non-existent user 999 → 200 | FIXED — 404 | FIXED — 404 |
| SEC-04a | VULNERABLE — encoder emitted a second AMI action | VULNERABLE | FIXED — refused (`AMIUnsafeField`) |
| SEC-04b | VULNERABLE — admin form stored an interface with CR/LF (200) | VULNERABLE (200) | FIXED — 422 |
| SEC-05 | VULNERABLE — 30 of 30 streams held for one user | VULNERABLE (30) | FIXED — 12 held, rest refused |
| SEC-06 | VULNERABLE — stored name `*.wav` served another call's recording | VULNERABLE | FIXED — nothing |
| SEC-07 | VULNERABLE — token after sign-out → 200 | VULNERABLE (200) | FIXED — 401 |
| SEC-08 | VULNERABLE — new hashes p=1 | VULNERABLE | FIXED — p=5 |
| SEC-09 | VULNERABLE — other work ran 16 % of the time during 4 wrong sign-ins | VULNERABLE (15 %) | FIXED — 89 % |

---

## 2. Scope and inventory (requirement 1)

* **185 routes** (from the running application's router, `audit/endpoints.json`): 108 need a signed-in user,
  31 need supervisor or higher, 33 need administrator, 13 are public. Every public route was reviewed and is
  pinned in `tests/test_sec_authz_matrix.py::PUBLIC` — a new public route makes that test fail until it is reviewed:

  | Public route | Own protection |
  |---|---|
  | `POST /api/auth/login` | throttled (5 per user, 20 per IP / 5 min), constant-time dummy hash |
  | `GET /api/avatars/{key}` | random key, images only |
  | `POST /api/integrations/zammad/webhook` | HMAC-SHA1 signature (constant-time), unsigned refused, delivery de-duplicated |
  | `POST /api/integrations/telegram/webhook` | secret-token header, `compare_digest` |
  | `GET/POST /api/integrations/whatsapp/webhook` | verify token / `X-Hub-Signature-256` |
  | `GET /api/admin/backups/{name}/download` | 120-second signed ticket of an active administrator |
  | `GET /api/health`, `/api/desktop/hello`, `/api/ui-language`, `/`, `/sw.js`, `/static/*` | no data |
* **SSE**: one handler, `GET /api/events/stream` (60-second stream ticket only; never the session token in the URL).
* **Background tasks** (reviewed): AMI client / event consumer, sync tick, sync hub, Zammad reconcile, ticket poll,
  team / shift watch, call routing, idle watchdog, retention, backup scheduler and jobs, mail housekeeping / IDLE,
  messenger outbox and Telegram receiver, system log, web push, presence timers, per-event webhook processing.
  None takes input from an unauthenticated source except the signed webhooks.
* **Unreviewed**: the Windows client (`windows/`) was only scanned (detect-secrets), not reviewed — NOT TESTED.

## 3. Authorization (requirement 2)

* **Vertical** — VERIFIED for every route: `tests/test_sec_authz_matrix.py::test_role_matrix` walks all protected
  routes from the live router: no token → 401, operator → 403 on every supervisor / admin route, supervisor → 403 on
  every admin route (more than 150 route/method pairs). The role is read from the database on every request; a token
  claiming `role=admin` does not help (`test_a_role_in_the_token_is_not_trusted`). Stream tickets are not accepted as
  sessions, and session tokens are not accepted in the URL.
* **Horizontal** — VERIFIED by feature tests: chat messages / files / groups / typing (`test_chat_groups_files.py`),
  ticket drafts and tabs (`test_ticket_views.py`), call recordings (`test_v39_misc.py`), backups
  (`test_sec_backup_upload.py`). Tickets are changed in Zammad *as the operator* (Zammad's own rights apply).
* **By design, needs a business decision** — the messenger inbox (Telegram / WhatsApp) and the mail box are shared by
  every signed-in user, including new-message previews (R-07).

## 4. Findings

Each finding: severity and why · location · root cause · reproduction · fix · regression test · actual result ·
residual risk. File / line references are to v3.20.1 unless noted.

### SEC-02 — Fail-open production configuration (High, conditional) — FIXED
* **Why High**: `JWT_SECRET` signs every session *and* is the key from which stored secrets (Zammad token, AMI, SIP,
  mail passwords) and chat / mail / messenger bodies are encrypted. The default value is public (in this repository).
  Whoever knows it can sign `{"sub": "<admin id>", …}` and is administrator; with a database copy they can decrypt
  everything. Conditional on a deployment that kept the default — the installer asks for a value, but nothing stopped
  a server from starting without one.
* **Location**: `app/config.py:20` (default value), `app/main.py:67` (only a warning); `.env.example`
  (`POSTGRES_PASSWORD=change-me`), `app/config.py` default `DATABASE_URL` with `aws:aws`.
* **Root cause**: fail-open default; a security-critical setting validated only for length.
* **Repro**: `Settings()` with no `JWT_SECRET` in production → accepted (all three old versions).
* **Fix**: new `ZD_ENV` (default **production**). In production the start is refused when `JWT_SECRET` is missing,
  a published / demo / test value, contains a placeholder word, is shorter than 32 characters or has fewer than 8
  different characters, or when the database password is a placeholder or equals the user name. Empty or short is
  refused in development too. The error never prints the value (`hide_input_in_errors`). Docker Compose sets
  `ZD_ENV: production` explicitly.
* **Tests**: `tests/test_sec_config.py` (15 tests incl. env-var and `.env` bypass attempts, an unknown `ZD_ENV`, a
  real subprocess start, no secret fragments in the error, key rotation consequences). PASSED.
* **Residual**: a strong but leaked secret is not detectable; key rotation needs the procedure in
  `SECURITY_FIXES.md` (R-04).

### SEC-04 — CR/LF injection into Asterisk AMI (Medium) — FIXED
* **Why Medium**: AMI is a line-based protocol. `build_message` (`app/ami.py:39`) wrote `f"{k}: {v}\r\n"` without
  checking. An agent's `extension`, `asterisk_interface`, `sip_user` (`app/api/admin_panel.py:35-38`, only a length
  limit) and string settings reach AMI actions (queue pause / add, redirect, spy). A value with `\r\n` adds a second
  action — e.g. `Originate … Application: System` or `Command`, which on many PBXs runs shell commands. Needs a Zenith
  Desk administrator account, but crosses into the PBX, which is a different system with its own administrators.
* **Repro**: encoder with `Interface: "101\r\n\r\nAction: Originate…"` → bytes contain the second action; the admin
  form stored such an interface (HTTP 200).
* **Fix**: (1) the encoder refuses CR, LF, NUL in any key or value and `:` in keys (`AMIUnsafeField`, a subclass of
  `AMIError`, so existing error handling still applies) — before anything is queued or written; (2) the admin form
  accepts only channel characters: extension `[0-9A-Za-z*#+_.-]{1,40}`, interface `[\w/@.\-:;#*+]{1,200}`,
  SIP user `[\w.\-+@]{1,100}` (422 otherwise).
* **Tests**: `tests/test_sec_ami.py` (24: encoder cases, nothing written / nothing left pending, 7 hostile and 8
  legitimate form values). PASSED. **Live PBX injection: NOT TESTED** (no authorisation to attack a real PBX; the
  encoder-level test proves no such bytes leave the server).
* **Residual**: values already stored before the upgrade are not re-validated, but cannot pass the encoder.

### SEC-07 — Sign-out did not revoke the session (Medium) — FIXED
* **Location**: `app/api/auth_routes.py:115` set the state to offline only; JWTs (`app/auth.py`) had no id.
* **Impact**: a token copied from a shared / lost device, a proxy log or an XSS kept working for up to
  `JWT_TTL_HOURS` (12) after the user signed out.
* **Fix**: every session token gets a random `jti`; sign-out stores it in the new table `revoked_token` (migration
  `0019`) until the token's own expiry; every request checks it; the retention job deletes expired rows. Sign-out also
  closes the user's open live streams (other devices reconnect with their own session). Other sessions of the user
  stay valid (a phone sign-out does not sign out the desk).
* **Tests**: `tests/test_sec_logout.py` (6). PASSED.
* **Residual**: tokens issued *before* the upgrade carry no `jti` and end at their normal expiry (≤ 12 h after
  deploy); a stream ticket already issued lives ≤ 60 s; there is no «sign out everywhere» button yet (changing the
  password does that). One extra primary-key lookup per request.

### SEC-09 — Password hashing blocked the event loop (Medium) — FIXED
* **Location**: `app/api/auth_routes.py:59` called the CPU-bound scrypt directly inside the async handler.
* **Impact**: the whole server (all users, SSE, AMI events) stops for every sign-in attempt; anyone on the network can
  send them without an account. The per-IP throttle (20 per 5 min) does not help against many source addresses.
* **Fix**: hashing runs in worker threads, at most 4 at a time per process (`crypto.verify_password_async`,
  `hash_password_async`); admin password changes too.
* **Tests**: `tests/test_sec_passwords.py::test_hashing_does_not_freeze_the_server`; repro: other work ran 15–16 % of
  the time before, 89 % after. PASSED.
* **Residual**: a large distributed flood still queues sign-ins (they wait for a slot) — rate limiting at the reverse
  proxy / firewall is recommended (checklist).

### SEC-01 — Backup upload without limits (Medium, admin) — FIXED
* **Location**: `app/security.py:73` exempts `/api/admin/backups/upload` from the 64 MB request limit (needed for big
  backups); `app/backup_service.py:174` streamed into one fixed `.part` name without a size or disk check.
* **Impact**: an administrator session (or a stolen one) fills the disk → the database and the server stop. Two
  parallel uploads wrote into the same part file.
* **Fix**: `BACKUP_UPLOAD_MAX_MB` (4096) checked on Content-Length *and* while streaming (413), `BACKUP_MIN_FREE_MB`
  reserve (507), one upload at a time (409), unique part file `O_EXCL` 0600, folder 0700, cleanup on any error and of
  stale parts, symlinks in the backup folder never served.
* **Tests**: `tests/test_sec_backup_upload.py` (9). PASSED.

### SEC-05 — Unlimited SSE connections (Low–Medium) — FIXED
* **Location**: `app/events.py:98`, `app/api/agents.py:158`. Each stream holds a socket and a 200-event queue.
* **Fix**: `SSE_MAX_PER_USER` (12) → 429 with `Retry-After`; `SSE_MAX_TOTAL` (2000) → 503. Checked again inside the
  broker without an `await` between check and registration, so parallel requests cannot slip past.
  The browser already retries with back-off.
* **Tests**: `tests/test_sec_sse.py` (3, incl. 10 parallel openings → exactly 2 accepted). PASSED.

### SEC-08 — scrypt parameters (Low) — FIXED
* N=2^14, r=8, **p=1** → **p=5** (OWASP). Old hashes keep working and are upgraded at the next successful sign-in.
  A stored hash asking for absurd parameters is refused instead of exhausting memory / CPU.
* **Tests**: `tests/test_sec_passwords.py` (5). PASSED. Cost measured here: 53 ms → 226 ms per hash.
* **Residual**: the upgrade changes the stored hash, so that user's *other* sessions end once (first sign-in after
  the upgrade).

### SEC-06 — Recording lookup with wildcards (Low) — FIXED
* **Location**: `app/api/tickets.py:284` `base.rglob(candidate.name)`; the name comes from the PBX (call record).
* **Impact**: a name containing `*` / `?` / `[` matched another call's recording (the access check is done on the
  call, not on the file); every miss walked the complete archive (slow on years of recordings).
* **Fix**: the name is matched literally (`glob.escape`), only audio extensions, only the FreePBX date folders
  (≤ 3 levels), symlinks out of the folder refused.
* **Tests**: `tests/test_sec_recordings.py` (5). PASSED.

### SEC-03 — Typing event to any id (Low) — FIXED in v3.20
* v3.18.1 `app/api/chat.py:208` published `chat_typing` to any user id without checking it or throttling.
  v3.20 checks the conversation and throttles (`tests/test_chat_groups_files.py::test_typing_goes_only_to_the_right_people`).
  Evidence: repro 200 on v3.18.1, 404 on v3.20.1 and v3.20.2.

### SEC-10 — CSV formula neutralisation (Info, hardening) — FIXED
* `app/api/manage.py:501`. Cells starting with `= + - @ TAB CR` are now prefixed with `'`. With the current inputs no
  cell could start with a formula (names are admin-set; details begin with a fixed key) — **not reproducible as an
  attack**, fixed as defence in depth. `tests/test_sec_csv.py` (2). PASSED.

### SEC-11 — Recording link template scheme (Info) — FIXED
* `app/calls.py:52`: the admin template was used as-is and opened by the browser (`window.open`). Only `https://`,
  `http://` and `/…` links are produced now. `tests/test_sec_recordings.py::test_recording_link_template_only_gives_web_links`.

## 5. Residual risks and design decisions (OPEN)

| ID | Item | Severity | Recommendation |
|---|---|---|---|
| R-01 | Login lock-out is per user name: anyone can lock a known user out for 5 min (VERIFIED on the local demo: 5 wrong → 429) | Low–Medium | throttle per (user, IP) + growing delay; alert on many lock-outs |
| R-02 | Session token in `localStorage` — readable by any script that runs in the page | Low (no HTML sinks found, strict CSP) | consider an HttpOnly SameSite cookie + CSRF token |
| R-03 | CSP has `'unsafe-eval'` (Vue in-browser template compiler) and `img-src https:` | Low | pre-compile templates to drop `unsafe-eval` |
| R-04 | One master key `JWT_SECRET` signs three token kinds (separated by `typ`) and derives the encryption keys | Info | rotation only via backup → new key → restore (SECURITY_FIXES.md); a separate encryption key would allow rotating signatures alone |
| R-05 | Backup download ticket is in the URL (120 s, admin, active) and not bound to the password version | Low | bind to `pv`, keep 120 s |
| R-06 | Zammad webhook: signature does not cover the delivery id, a captured body can be re-sent with a new id | Low (it only triggers a re-read from Zammad) | add a timestamp window |
| R-07 | Messenger inbox and mail box shared by all signed-in users, incl. message previews | Info (design) | confirm with the business; restrict by group if needed |
| R-08 | Administrators can point integrations at any URL (server-side requests) | Low (admin) | optional allow-list of hosts |
| R-09 | Docker: no CPU / memory limits, images by tag (not digest), health check skips TLS verification on localhost, a generated first admin password is printed to the log | Low | see checklist |
| R-10 | Recording endpoint answers 403 vs 404 → reveals which call ids exist | Info | answer 404 for both |
| R-11 | Tokens from before v3.20.2 (no `jti`) cannot be revoked until they expire | Info, ≤ 12 h | — |
| R-12 | First sign-in after the upgrade ends the user's other sessions (hash upgrade) | Info (operational) | announce |
| R-13 | `me_changed` SSE data is merged with `Object.assign` (prototype-pollution pattern; data comes from the server) | Info | copy known keys only |
| R-14 | Per-event webhook tasks are not bounded (signed sources only) | Info | bounded queue |
| R-15 | Demo enables `/docs`; production default off (VERIFIED by `tests/test_security.py`) | Info | keep `API_DOCS` off |
| R-16 | Pydantic / FastAPI versions are very new; framework-level bugs are not covered by this audit | Info | follow advisories |

## 6. Not tested / blocked / partly verified (requirement 12)

| Area | Status | Why |
|---|---|---|
| Container image vulnerability scan (Trivy / Grype) | **BLOCKED** | release binaries not downloadable here, no Docker daemon |
| JsSIP 3.13.8 against an advisory database | **NOT TESTED** | OSV API not reachable from this environment |
| Vue 3.5.13 advisories | **PARTIALLY VERIFIED** | one public package-insight page shows 0 known issues; no database query |
| Live AMI injection against a real PBX | **NOT TESTED** | testing external systems was not authorised; encoder-level proof only |
| Real Zammad / Telegram / WhatsApp / mail servers | **NOT TESTED** | simulators only |
| Production host: firewall, open ports, DB roles, file permissions, log retention, monitoring, backups off-site | **NOT TESTED** | no access — covered as a checklist |
| TLS scan of a deployed server (cipher suites, certificate) | **NOT TESTED** | configuration reviewed only (`app/serve.py`: TLS ≥ 1.2, explicit ciphers, no compression) |
| Browser DOM-XSS fuzzing | **PARTIALLY VERIFIED** | static review: no `v-html`, the only `innerHTML` is the built-in icon set, mail HTML sanitised by nh3 and shown in a sandboxed iframe with its own CSP; e2e UI tests ran, no fuzzing |
| Load / DoS at scale | **PARTIALLY VERIFIED** | unit-level concurrency tests and the reproduction script; no load test |
| Windows client (`windows/`) | **NOT TESTED** | only secret scanning |
| Semgrep registry rule packs | **BLOCKED** | registry not reachable; ran 652 rules from the semgrep-rules GitHub repository instead |

## 7. Tools and results (requirement 7)

| Tool | Version / data | Result |
|---|---|---|
| pip-audit | 2.10.1, PyPI/OSV data as of 2026-10-25 22:14 UTC | 35 dependencies, **0 known vulnerabilities** |
| bandit | 1.9.4 | 19 LOW: B110 (intended `try/except: pass` around optional features), B105/B106 (words like «password» in labels) — false positives |
| ruff `S` rules | 0.16.8 | S608 (SQL built from model metadata, not input) and S104 (bind 0.0.0.0 in the container) — false positive / intended |
| semgrep | 1.182.1, semgrep-rules @ 16b9e6d (2026-10-21), 652 rules | 121 results; security-relevant ones triaged: CSV export (→ SEC-10 hardening), `Object.assign` (R-13), first-admin password log (R-09); the rest false positives (simulated tokens / SHA-1 in the Zammad simulator, `ws://` in labels, `text()` with table names, explicit TLS cipher list, test-script subprocess calls) |
| detect-secrets | 1.5.0 | 78 hits in 27 files: test fixtures, UI labels, simulator tokens, the public published defaults (now refused in production), Windows manifest public-key tokens — no real secret |
| gitleaks | 8.21.2, whole history (47 commits) | 2 hits, both test secrets — no real secret |
| hadolint | 2.12.0 | Dockerfile: no findings |
| Dynamic checks (local demo) | curl | security headers present (CSP, XFO DENY, nosniff, COOP, Referrer-Policy, Permissions-Policy); no CORS; path traversal on `/static` and `/api/avatars` → 404; `alg: none` token → 401; login throttle → 429 after 5; 70 MB body → 413 |

## 8. Test results

* Unit / integration suite: **284 passed** (211 before the audit; 73 new security tests in `tests/test_sec_*.py`).
* Reproduction script: all findings VULNERABLE on v3.20.1 (and v3.18.1), FIXED on v3.20.2 (table in section 1).
* Full release check (PostgreSQL, Asterisk, browser e2e in three styles, backup, phone, Windows): **ALL CHECKS PASSED**
  (`SECURITY_TEST_PLAN.md` §4). Two problems it found on the way were fixed (§3 there).

## 9. Duration

Started 2026-10-25 21:11:48 UTC, finished 2026-10-26 01:04:33 UTC: **3 hours 53 minutes**.
