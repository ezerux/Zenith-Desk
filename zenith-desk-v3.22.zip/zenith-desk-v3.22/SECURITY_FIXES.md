# Zenith Desk 3.20.2 — Security Fixes, Migration, Key Rotation, Rollback

Branch `security-audit`, based on `v3.20.1`. Review the patch with:

```bash
git diff v3.20.1 v3.20.2 -- app migrations docker-compose.yml .env.example     # code
git diff v3.20.1 v3.20.2 --stat
```

## 1. Changes by finding

| ID | Files | Change |
|---|---|---|
| SEC-01 | `app/backup_service.py`, `app/api/backup.py`, `app/config.py`, `app/i18n.py` | `save_upload`: size limit on Content-Length and while streaming (413), free-space reserve (507), one upload at a time (409), unique `O_EXCL` 0600 part file, folder 0700, cleanup on every error and of stale parts, symlinks never served |
| SEC-02 | `app/config.py`, `docker-compose.yml`, `.env.example`, test / demo set-ups | `ZD_ENV` (default `production`); production refuses weak / published / placeholder `JWT_SECRET` and placeholder DB passwords; errors never echo secrets |
| SEC-04 | `app/ami.py`, `app/api/admin_panel.py` | AMI encoder refuses CR / LF / NUL (`AMIUnsafeField`), built before anything is queued; extension / interface / SIP user character validation |
| SEC-05 | `app/events.py`, `app/api/agents.py`, `app/services.py`, `app/config.py`, `app/i18n.py` | per-user (429) and total (503) SSE caps, race-free in the broker |
| SEC-06 | `app/api/tickets.py` | literal file-name match, audio files only, bounded folder depth |
| SEC-07 | `app/auth.py`, `app/api/auth_routes.py`, `app/static/app.js`, `app/models.py`, `app/events.py`, `app/services.py`, `migrations/versions/0019_revoked_token.py` | session `jti`, revocation table, checked per request, cleanup, streams closed at sign-out; the page closes its live stream before it revokes the token and drops its own late 401s during sign-out |
| SEC-08 | `app/crypto.py`, `app/api/auth_routes.py` | scrypt p=5, upgrade at sign-in, refuse absurd stored parameters |
| SEC-09 | `app/crypto.py`, `app/api/auth_routes.py`, `app/api/admin_panel.py` | hashing in worker threads, max 4 concurrent per process |
| SEC-10 | `app/api/manage.py` | CSV cells neutralised against formulas |
| SEC-11 | `app/calls.py` | recording link template: web links only |

New tests: `tests/test_sec_*.py` (73 tests). No existing test was weakened; test set-ups that use the published
test secrets now say `ZD_ENV=development` explicitly.

## 2. New settings (all optional)

| Variable | Default | Meaning |
|---|---|---|
| `ZD_ENV` | `production` | `development` only on test machines (allows demo secrets) |
| `BACKUP_UPLOAD_MAX_MB` | `4096` | largest backup upload |
| `BACKUP_MIN_FREE_MB` | `512` | disk reserve kept free during uploads |
| `SSE_MAX_PER_USER` | `12` | live connections per user |
| `SSE_MAX_TOTAL` | `2000` | live connections per server process |

## 3. Migration (upgrade 3.20.1 → 3.20.2)

1. **Before**: make a backup in the admin panel (Backup → Create) and copy it off the server.
2. **Check `.env`**: `JWT_SECRET` must be ≥ 32 random characters and not a placeholder; `POSTGRES_PASSWORD` must not be
   `change-me` / `aws` / equal to the user name. If the server ran with a default `JWT_SECRET`, treat it as
   compromised and follow §4 (key rotation) — do not just edit the value.
3. Deploy the new version. Migrations (`alembic`) read the same settings, so they are refused too while a secret is weak. The start applies database migration **`0019_revoked_token`** (adds one table; no existing
   data is changed). A refused start prints `refusing to start in production: …` with the reason (never the value).
4. Expected effects for users:
   * sessions continue; tokens issued before the upgrade end at their normal expiry (≤ `JWT_TTL_HOURS`);
   * each user's first sign-in after the upgrade upgrades the password hash, which ends that user's *other* sessions once;
   * sign-in takes ≈ 0.2 s of CPU instead of ≈ 0.05 s.
5. Admin form: an extension / interface / SIP user with spaces or control characters is now refused (422) — fix such
   values if any appear when saving a user.

## 4. Key rotation (`JWT_SECRET`)

`JWT_SECRET` signs sessions, stream tickets, backup download tickets, and is the master from which the settings
encryption key (`SecretBox`) and the message encryption key (`MessageCipher`) are derived. **Changing it in `.env`
alone signs everyone out and makes every stored secret and every encrypted message unreadable**
(proved by `tests/test_sec_config.py::test_rotating_the_key_ends_sessions_and_old_data_needs_the_old_key`).

Safe rotation:
1. Admin panel → Backup → **Create** a backup with the current key; download it.
2. Stop the app; put the new key into `.env` (`openssl rand -hex 32`).
3. Start; sign in with the initial administrator (or `python -m app.cli reset-password admin`).
4. Admin panel → Backup → **Restore** the backup. The restore re-encrypts every secret, message and chat file with the
   new key (`rekeyed` in the result) and keeps sessions signed by the old key valid until they expire
   (`previous_session_keys`). If the old key was compromised, immediately reset all passwords afterwards — that ends
   those old sessions too.
5. Destroy old copies of `.env`.

## 5. Rollback (3.20.2 → 3.20.1)

1. Stop the app.
2. Downgrade the database one step: `docker compose run --rm app alembic downgrade 0018` (drops `revoked_token` only).
3. Deploy v3.20.1 (`git checkout v3.20.1`, rebuild).
4. Effects: signed-out tokens are valid again until expiry; hashes upgraded to p=5 keep working on 3.20.1 (the
   parameters are stored in each hash); the new `.env` variables are ignored.
5. If anything else went wrong: restore the backup from §3 step 1.

## 6. What this patch does not change

The residual risks R-01 … R-16 in `SECURITY_AUDIT_REPORT.md` §5 remain; none was weakened to make tests pass.
