# Zenith Desk 3.20.2 — Security Test Plan and Results

How to run everything:

```bash
python3 -m pytest -q tests/test_sec_*.py                       # the security regression tests (73)
python3 -m pytest -q                                           # the whole suite
TEST_DATABASE_URL=postgresql+asyncpg://aws:aws@localhost/aws_test ZD_DEBUG=1 python3 -m scripts.release_check
cd <checkout of any version> && python3 -I <this checkout>/audit/repro.py <label>   # old vs new (report §1)
```

Only local resources are used: SQLite / a local PostgreSQL test database, simulated Zammad / messengers, the
repository's Asterisk test container. No production system or credential.

## 1. Regression tests — expected vs actual

| Test file | Finding | What it proves | Expected | Actual |
|---|---|---|---|---|
| `test_sec_config.py` (15) | SEC-02 | production refuses missing / published / placeholder / short / low-variety secrets and placeholder or user=password DB passwords; env vars and `.env` cannot bypass; unknown `ZD_ENV` refused; real subprocess start refused / accepted; no secret fragment in the error; key change ends sessions and old ciphertext needs the old key | pass | **PASSED** |
| `test_sec_ami.py` (24) | SEC-04 | encoder refuses CR/LF/NUL/«:» in keys, nothing written or left pending; admin form refuses 7 hostile values and accepts 8 real ones | pass | **PASSED** |
| `test_sec_logout.py` (6) | SEC-07 | signed-out token → 401 on several endpoints and for new stream tickets; other sessions unaffected; unique `jti`; forged tokens cannot revoke; cleanup; streams closed | pass | **PASSED** |
| `test_sec_passwords.py` (5) | SEC-08/09 | p=5, old hashes verify and are upgraded at sign-in, failed sign-in changes nothing, hostile parameters refused, event loop keeps running during hashing | pass | **PASSED** |
| `test_sec_backup_upload.py` (9) | SEC-01 | below / at / above limit, chunked, misleading Content-Length, interrupted upload, concurrency, disk reserve, malformed, traversal names, symlinks, roles | pass | **PASSED** |
| `test_sec_sse.py` (3) | SEC-05 | per-user and total caps, 10 parallel openings → exactly 2, endpoint 429 + Retry-After, other users unaffected | pass | **PASSED** |
| `test_sec_recordings.py` (5) | SEC-06/11 | wildcards literal, audio only, inside the folder, bounded depth, link scheme | pass | **PASSED** |
| `test_sec_csv.py` (2) | SEC-10 | formula cells neutralised, export with a formula name | pass | **PASSED** |
| `test_sec_authz_matrix.py` (4) | authz | every protected route: 401 / 403 by role; public routes pinned to a reviewed list; role claim not trusted; stream ticket ≠ session; no session in URL | pass | **PASSED** |
| `test_chat_groups_files.py::test_typing_goes_only_to_the_right_people` | SEC-03 | typing only inside a real conversation | pass | **PASSED** (existing, v3.20) |

## 2. Before / after evidence

The new test files were also run against the unpatched v3.20.1 tree (copied in, unchanged):

| File | On v3.20.1 | Meaning |
|---|---|---|
| `test_sec_config.py` | 12 failed, 3 passed | the 3 that pass check behaviour that already existed (32-character minimum, demo values usable, key-rotation consequences) |
| `test_sec_recordings.py` (before SEC-11 was added) | 3 failed, 1 passed | the passing one is the normal lookup of real names |
| `test_sec_passwords.py` | 3 failed, 2 passed (7 min 26 s: a stored hash with p=10 000 was computed instead of refused) | |
| `test_sec_backup_upload.py` | 9 errors | the limit settings do not exist |
| `test_sec_ami.py`, `test_sec_logout.py` | collection error | the fix's API does not exist |
| `test_sec_sse.py` | hung (no cap → the refused stream never ends), stopped manually | |
| `test_sec_authz_matrix.py` | 4 passed | role checks were already correct |

Version-independent reproduction (`audit/repro.py`): VULNERABLE on v3.18.1 and v3.20.1, FIXED on v3.20.2 for every
finding — table in `SECURITY_AUDIT_REPORT.md` §1.

## 3. Regression found by the release check

The first full release check after the fixes found one regression: the browser e2e step «Sign out sets the operator
offline» reported a JavaScript error «Session expired». Cause: with SEC-07 the token dies at sign-out, and requests the
page itself started in that moment (live-stream reconnect, refreshes) now got 401. Fix in `app/static/app.js`: the page closes its live stream first, revokes the token, and only then clears its state; a request of this page that meets the revoked token during sign-out is dropped quietly. (A first variant that cleared the state before revoking made the next check fail — the server had not yet set the operator offline — and was replaced.) Re-run of every style: 90 / 90 passed. No test was changed.

The second run found that `alembic upgrade head` in the release check itself was refused: the migration tool reads
the same settings and the test database uses test credentials — the production check working as intended. The release
check now runs its migration steps with `ZD_ENV=development` (like the other test set-ups); without it the refusal was
confirmed again by hand. Upgrade, model check, downgrade to base and upgrade again then passed.

## 4. Results of the final run (2026-10-26 01:04 UTC, code as tagged v3.20.2)

`RESULT: ALL CHECKS PASSED`

| Step | Result |
|---|---|
| Tests on SQLite | 284 passed |
| Tests on PostgreSQL 16 | 284 passed |
| Migrations: upgrade head · model matches schema · downgrade base · upgrade again | PASS (incl. `0019_revoked_token`) |
| Backup / restore on the real stack (other `JWT_SECRET`, CLI) | 14 checks passed |
| Browser e2e — Classic / Studio / Flow | 90 / 90 · 90 / 90 · 90 / 90 |
| Backup page in the browser | 11 / 11 |
| Phone (WebRTC against a SIP server) | 12 / 12 |
| Real Asterisk 20: AMI, recovery, phone, queue, recording, supervision | 9 / 9 |
| Real Asterisk 20: routing by level · manager routing | 8 / 8 · 4 / 4 |
| Windows client (Mono) | 28 / 28 |

Audit duration: started 2026-10-25 21:11:48 UTC, finished 2026-10-26 01:04:33 UTC — **3 h 53 min** (about 1 h 50 min
of it the full release check, run three times).
