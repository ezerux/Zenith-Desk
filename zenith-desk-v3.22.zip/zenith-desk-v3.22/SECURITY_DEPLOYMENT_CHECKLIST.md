# Zenith Desk 3.20.2 — Deployment Checklist

Nothing in this audit was deployed. Tick each line on the real server; the audit could **not** check these items
(no access to the production host) unless marked «verified in the repository».

## Before the upgrade
- [ ] Backup created in the admin panel and copied off the server; restore tested on a spare machine.
- [ ] `.env`: `JWT_SECRET` = 64 hex characters from `openssl rand -hex 32`, never a value from documentation.
      If the server ever ran with a default → rotate as in `SECURITY_FIXES.md` §4 and reset all passwords.
- [ ] `.env`: `POSTGRES_PASSWORD` long and random (`openssl rand -hex 24`).
- [ ] `.env` is readable by root / the deploy user only (`chmod 600 .env`), not in git, not in tickets or chats.
- [ ] `ZD_ENV` is not set to `development` on the server (docker-compose sets `production` — verified in the repository).
- [ ] `INITIAL_ADMIN_PASSWORD` set (otherwise a generated password is printed once to `docker compose logs app`;
      then rotate it at the first sign-in and limit who can read the logs).
- [ ] `API_DOCS` off (default).

## Network
- [ ] Only 443 (HTTPS) and 80 (redirect only) reachable from users' networks; nothing else published
      (`docker compose ps`, `ss -tlnp`, an external port scan).
- [ ] PostgreSQL not published (no `ports:` on `db` — verified in the repository); app ↔ DB with `ssl=verify-full`.
- [ ] AMI (5038 / 5039) reachable only from the Zenith Desk host; TLS AMI where possible; the AMI user has only the
      permissions it needs (no `system`, no `command` if not used).
- [ ] A rate limit for `POST /api/auth/login` at the firewall / reverse proxy (SEC-09 residual, R-01).
- [ ] Own certificate (`TLS_CERT_FILE` / `TLS_KEY_FILE`) or the self-signed one distributed to clients; `FORCE_HTTPS=true`.

## Host and container
- [ ] Docker resource limits for `app` and `db` (CPU, memory) — not set in the shipped compose file (R-09).
- [ ] Images pinned by digest for production builds; rebuild monthly with updated base images; scan the built image
      (Trivy / Grype — could not be run in the audit, BLOCKED).
- [ ] Disk space alerts for the Docker volume holding backups and the database; `BACKUP_MIN_FREE_MB` fits the disk.
- [ ] Recording folder mounted read-only (`:ro`).

## Database
- [ ] The `aws` role owns only the `aws` database; no superuser; nobody else connects.
- [ ] Database backups (pg_dump or the app backup) stored off the server, encrypted, with retention.

## Logs, monitoring, incident response
- [ ] Log retention set (Docker log rotation: `max-size` / `max-file`); logs never contain tokens (sessions are not in
      URLs; stream tickets live 60 s).
- [ ] Alerts on: many `login_failed` / lock-outs, `recording_denied`, `backup_restore`, `api_key_*` events in the audit log,
      the app restarting, disk > 80 %.
- [ ] Incident steps written down: rotate `JWT_SECRET` (§4 of SECURITY_FIXES.md), reset passwords, revoke API keys,
      restore from a known-good backup, review the audit log export.

## The upgrade itself
- [ ] Deploy 3.20.2; the start log shows migration `0019` and no «refusing to start».
- [ ] Sign in as operator, manager and administrator; sign out → the old tab is signed out; live updates work.
- [ ] Upload a backup larger than the limit on a test machine → 413; restore still works.
- [ ] Save a user with a normal extension / interface → OK.
- [ ] Rollback plan ready: `SECURITY_FIXES.md` §5.
