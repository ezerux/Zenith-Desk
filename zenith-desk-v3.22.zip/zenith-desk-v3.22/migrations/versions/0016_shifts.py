"""v3.15: shift schedule

Revision ID: 0016
Revises: 0015
Create Date: 2026-10-16
"""
import sqlalchemy as sa
from alembic import op


revision = '0016'
down_revision = '0015'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        'shift',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), nullable=False),
        sa.Column('starts_at', TS, nullable=False),
        sa.Column('ends_at', TS, nullable=False),
        sa.Column('note', sa.String(200), nullable=False),
        sa.Column('alerts', sa.JSON(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('created_at', TS, nullable=False),
    )
    op.create_index('ix_shift_agent_start', 'shift', ['agent_id', 'starts_at'])
    op.create_index('ix_shift_start', 'shift', ['starts_at'])
    op.create_table(
        'shift_template',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('name', sa.String(60), nullable=False),
        sa.Column('start', sa.String(5), nullable=False),
        sa.Column('end', sa.String(5), nullable=False),
        sa.Column('color', sa.String(20), nullable=False),
    )


def downgrade() -> None:
    op.drop_table('shift_template')
    op.drop_index('ix_shift_start', table_name='shift')
    op.drop_index('ix_shift_agent_start', table_name='shift')
    op.drop_table('shift')
