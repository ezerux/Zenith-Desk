"""SEC-07: sign-out revokes the session token (denylist by token id until it expires)

Revision ID: 0019
Revises: 0018
Create Date: 2026-10-26
"""
import sqlalchemy as sa
from alembic import op


revision = '0019'
down_revision = '0018'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        'revoked_token',
        sa.Column('jti', sa.String(32), primary_key=True),
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), nullable=False),
        sa.Column('expires_at', TS, nullable=False),
        sa.Column('created_at', TS, nullable=False),
    )
    op.create_index('ix_revoked_token_agent_id', 'revoked_token', ['agent_id'])
    op.create_index('ix_revoked_token_expires_at', 'revoked_token', ['expires_at'])


def downgrade() -> None:
    op.drop_index('ix_revoked_token_expires_at', table_name='revoked_token')
    op.drop_index('ix_revoked_token_agent_id', table_name='revoked_token')
    op.drop_table('revoked_token')
