"""v3.18: API keys for other programs

Revision ID: 0017
Revises: 0016
Create Date: 2026-10-25
"""
import sqlalchemy as sa
from alembic import op


revision = '0017'
down_revision = '0016'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        'api_key',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('prefix', sa.String(16), nullable=False),
        sa.Column('secret_hash', sa.String(64), nullable=False),
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), nullable=False),
        sa.Column('read_only', sa.Boolean(), nullable=False),
        sa.Column('allowed_ips', sa.String(500), nullable=False),
        sa.Column('expires_at', TS, nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('created_at', TS, nullable=False),
        sa.Column('last_used_at', TS, nullable=True),
        sa.Column('last_used_ip', sa.String(64), nullable=False),
        sa.Column('uses', sa.Integer(), nullable=False),
        sa.Column('revoked_at', TS, nullable=True),
        sa.UniqueConstraint('prefix'),
    )
    op.create_index('ix_api_key_agent_id', 'api_key', ['agent_id'])


def downgrade() -> None:
    op.drop_index('ix_api_key_agent_id', table_name='api_key')
    op.drop_table('api_key')
