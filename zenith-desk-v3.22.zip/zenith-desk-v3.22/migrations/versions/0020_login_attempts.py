"""v3.21: sign-in attempts (who / from where / result) and «sign out everywhere»

Revision ID: 0020
Revises: 0019
Create Date: 2026-10-26
"""
import sqlalchemy as sa
from alembic import op


revision = '0020'
down_revision = '0019'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        'login_attempt',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('ts', TS, nullable=False),
        sa.Column('username', sa.String(100), nullable=False),
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), nullable=True),
        sa.Column('ip', sa.String(64), nullable=False),
        sa.Column('user_agent', sa.String(300), nullable=False),
        sa.Column('result', sa.String(20), nullable=False),
    )
    for col in ('ts', 'username', 'agent_id', 'ip'):
        op.create_index(f'ix_login_attempt_{col}', 'login_attempt', [col])
    op.add_column('agent_mapping', sa.Column('sessions_valid_after', TS, nullable=True))


def downgrade() -> None:
    op.drop_column('agent_mapping', 'sessions_valid_after')
    for col in ('ip', 'agent_id', 'username', 'ts'):
        op.drop_index(f'ix_login_attempt_{col}', table_name='login_attempt')
    op.drop_table('login_attempt')
