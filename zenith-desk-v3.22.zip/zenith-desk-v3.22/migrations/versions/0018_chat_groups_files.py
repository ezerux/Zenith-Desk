"""v3.20: internal messenger — group conversations and files

Revision ID: 0018
Revises: 0017
Create Date: 2026-10-25
"""
import sqlalchemy as sa
from alembic import op


revision = '0018'
down_revision = '0017'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        'chat_group',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('created_by', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='SET NULL'), nullable=True),
        sa.Column('created_at', TS, nullable=False),
    )
    op.create_table(
        'chat_group_member',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('group_id', sa.Integer(), sa.ForeignKey('chat_group.id', ondelete='CASCADE'), nullable=False),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), nullable=False),
        sa.Column('role', sa.String(10), nullable=False),
        sa.Column('joined_at', TS, nullable=False),
        sa.Column('last_read_id', sa.Integer(), nullable=False, server_default=sa.text('0')),
        sa.UniqueConstraint('group_id', 'user_id', name='uq_chat_group_member'),
    )
    op.create_index('ix_chat_group_member_group_id', 'chat_group_member', ['group_id'])
    op.create_index('ix_chat_group_member_user_id', 'chat_group_member', ['user_id'])
    # a group message has a group and no recipient (direct messages keep both sender and recipient)
    with op.batch_alter_table('chat_message') as batch:
        batch.alter_column('recipient_id', existing_type=sa.Integer(), nullable=True)
        batch.add_column(sa.Column('group_id', sa.Integer(), nullable=True))
        batch.create_foreign_key('fk_chat_message_group', 'chat_group', ['group_id'], ['id'], ondelete='CASCADE')
    op.create_index('ix_chat_group', 'chat_message', ['group_id', 'id'])
    op.create_table(
        'chat_file',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('key', sa.String(64), nullable=False),
        sa.Column('message_id', sa.Integer(), sa.ForeignKey('chat_message.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('mime', sa.String(150), nullable=False),
        sa.Column('size', sa.Integer(), nullable=False),
        sa.Column('data', sa.LargeBinary(), nullable=False),
        sa.Column('created_at', TS, nullable=False),
        sa.UniqueConstraint('key'),
    )
    op.create_index('ix_chat_file_message_id', 'chat_file', ['message_id'])


def downgrade() -> None:
    op.drop_index('ix_chat_file_message_id', table_name='chat_file')
    op.drop_table('chat_file')
    op.drop_index('ix_chat_group', table_name='chat_message')
    op.execute("DELETE FROM chat_message WHERE group_id IS NOT NULL")
    with op.batch_alter_table('chat_message') as batch:
        batch.drop_constraint('fk_chat_message_group', type_='foreignkey')
        batch.drop_column('group_id')
        batch.alter_column('recipient_id', existing_type=sa.Integer(), nullable=False)
    op.drop_index('ix_chat_group_member_user_id', table_name='chat_group_member')
    op.drop_index('ix_chat_group_member_group_id', table_name='chat_group_member')
    op.drop_table('chat_group_member')
    op.drop_table('chat_group')
