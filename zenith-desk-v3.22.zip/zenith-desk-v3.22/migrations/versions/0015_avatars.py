"""v3.12: account pictures (photo or initials)

Revision ID: 0015
Revises: 0014
Create Date: 2026-10-14
"""
import sqlalchemy as sa
from alembic import op


revision = '0015'
down_revision = '0014'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.add_column('agent_mapping', sa.Column('avatar_key', sa.String(40), nullable=False, server_default=''))
    op.add_column('agent_mapping', sa.Column('avatar_mode', sa.String(10), nullable=False, server_default='initials'))
    op.create_table(
        'agent_avatar',
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('key', sa.String(40), nullable=False, unique=True),
        sa.Column('mime', sa.String(40), nullable=False),
        sa.Column('data', sa.LargeBinary(), nullable=False),
        sa.Column('updated_at', TS, nullable=False),
    )


def downgrade() -> None:
    op.drop_table('agent_avatar')
    op.drop_column('agent_mapping', 'avatar_mode')
    op.drop_column('agent_mapping', 'avatar_key')
