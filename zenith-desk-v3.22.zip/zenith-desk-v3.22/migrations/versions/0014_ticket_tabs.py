"""v3.11: open tickets and ticket drafts of every operator (task bar)

Revision ID: 0014
Revises: 0013
Create Date: 2026-10-12
"""
import sqlalchemy as sa
from alembic import op


revision = '0014'
down_revision = '0013'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        'ticket_tab',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), nullable=False),
        sa.Column('kind', sa.String(10), nullable=False),
        sa.Column('ticket_id', sa.Integer(), nullable=True),
        sa.Column('number', sa.String(50), nullable=False),
        sa.Column('title', sa.String(255), nullable=False),
        sa.Column('draft', sa.JSON(), nullable=True),
        sa.Column('opened_at', TS, nullable=False),
        sa.Column('updated_at', TS, nullable=False),
        sa.UniqueConstraint('agent_id', 'ticket_id', name='uq_ticket_tab_agent_ticket'),
    )
    op.create_index('ix_ticket_tab_agent_id', 'ticket_tab', ['agent_id'])


def downgrade() -> None:
    op.drop_index('ix_ticket_tab_agent_id', table_name='ticket_tab')
    op.drop_table('ticket_tab')
