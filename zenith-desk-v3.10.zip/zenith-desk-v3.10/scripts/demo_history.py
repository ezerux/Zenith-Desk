"""Demo only: a realistic working day for the manager overview (v2.5).

Four extra operators work a 6.5-hour shift up to "now": state history (ready / tasks / breaks), queue calls with
waiting, answers, abandons, rings that were not picked up, completed tickets and call-backs. The real demo users
(anna, boris) are not touched, so the interactive demo and the browser test behave exactly as before.
"""
import random
from datetime import datetime, timedelta

from app.db import Database, utcnow
from app.models import AgentMapping, AgentState, AuditLog, CallRecord, ChatMessage, QueueCall, WorkSession

EXTRA = [  # id, login, first, last, level, ext, position, profile
    (5, "mariam", "Mariam", "Sargsyan", "level3", "104", "Senior support", "star"),
    (6, "davit", "Davit", "Hovhannisyan", "level2", "105", "Support operator", "avoider"),
    (7, "narek", "Narek", "Avetisyan", "level3", "106", "Senior sales", "steady"),
    (8, "sona", "Sona", "Grigoryan", "level2", "107", "Support operator", "steady"),
]
TOPICS = ["Delivery delay", "Refund request", "Change of address", "Invoice copy", "Wrong item received",
          "Promo code problem", "Account access", "Warranty question", "Order cancellation", "Payment failed"]
CHANNELS = ["phone", "email", "telegram", "whatsapp", "email", "phone"]


def _timeline(rng: random.Random, start: datetime, end: datetime, profile: str):
    """List of (from, to, state) covering [start, end)."""
    t = start + timedelta(minutes=rng.randint(0, 20))
    out = [(start, t, "offline")]
    breaks = 3 if profile == "avoider" else 2
    plan = []
    shift = (end - t).total_seconds()
    for k in range(breaks):
        at = t + timedelta(seconds=shift * (k + 1) / (breaks + 1) + rng.randint(-900, 900))
        length = rng.randint(25, 40) if profile == "avoider" else rng.randint(10, 20)
        plan.append((at, timedelta(minutes=length), "break"))
    for _ in range(4 if profile == "star" else 3):
        at = t + timedelta(seconds=rng.randint(600, int(shift) - 1800))
        plan.append((at, timedelta(minutes=rng.randint(8, 22)), "busy_task"))
    plan.sort()
    cur = t
    for at, length, st in plan:
        if at <= cur:
            at = cur + timedelta(minutes=5)
        if at + length >= end:
            continue
        out.append((cur, at, "ready"))
        out.append((at, at + length, st))
        cur = at + length
    out.append((cur, end, "ready"))
    return [(a, b, s) for a, b, s in out if b > a]


def _state_at(tl, ts: datetime) -> str:
    for a, b, s in tl:
        if a <= ts < b:
            return s
    return "offline"


async def seed_history(db: Database, seed: int = 7) -> None:
    rng = random.Random(seed)
    end = utcnow() - timedelta(minutes=2)
    start = end - timedelta(hours=6, minutes=30)
    async with db.sessionmaker() as s:
        for aid, login, first, last, level, ext, pos, _ in EXTRA:
            s.add(AgentMapping(id=aid, username=login, password_hash="!", first_name=first, last_name=last,
                               display_name=f"{first} {last}", position=pos, level=level, extension=ext,
                               asterisk_interface=f"Local/{ext}@from-queue/n", enabled=False))
        await s.flush()
        timelines = {}
        for aid, *_rest, profile in EXTRA:
            tl = _timeline(rng, start, end, profile)
            timelines[aid] = (tl, profile)
            prev = "offline"
            for a, _b, st in tl:
                if st != prev:
                    s.add(AuditLog(ts=a, action="availability_changed", agent_id=aid, actor_type="system",
                                   details={"cause": "demo_history", "old": prev, "new": st, "reason": ""}))
                    prev = st
            last = tl[-1][2]
            s.add(AgentState(agent_id=aid, manual_state="ready" if last == "ready" else "offline",
                             computed_state=last, sync_status="ok", queue_paused=last != "ready"))
            # tickets: every blocking-task interval is a completed ticket; plus background tickets done while ready
            n = 0
            for a, b, st in tl:
                if st == "busy_task":
                    n += 1
                    s.add(WorkSession(ticket_id=40000 + aid * 100 + n, ticket_number=str(30500 + aid * 100 + n),
                                      ticket_title=rng.choice(TOPICS), source=rng.choice(CHANNELS), agent_id=aid,
                                      work_mode="blocking", state="completed", started_at=a, ended_at=b, end_reason="completed"))
            for _ in range(rng.randint(2, 5) if profile != "avoider" else 1):
                a = start + timedelta(minutes=rng.randint(40, 330))
                n += 1
                s.add(WorkSession(ticket_id=40000 + aid * 100 + n, ticket_number=str(30500 + aid * 100 + n),
                                  ticket_title=rng.choice(TOPICS), source=rng.choice(CHANNELS), agent_id=aid,
                                  work_mode="background", state="completed", started_at=a,
                                  ended_at=a + timedelta(minutes=rng.randint(15, 70)), end_reason="completed"))

        # ------------------------------------------------ calls
        pool = [f"79{rng.randint(100000000, 999999999)}" for _ in range(45)]
        busy_until = {aid: start for aid in timelines}
        t, k = start + timedelta(minutes=5), 0
        missed_numbers = []
        while t < end - timedelta(minutes=3):
            frac = (t - start) / (end - start)
            per_hour = 9 + 14 * (1 - abs(frac - 0.45) * 2)  # peak in the middle of the shift
            t += timedelta(seconds=rng.expovariate(per_hour / 3600))
            if t >= end - timedelta(minutes=3):
                break
            k += 1
            link, number = f"H{k}", rng.choice(pool)
            patience = rng.choice([4, 45, 90, 150, 240, 300])
            free = [aid for aid, (tl, _) in timelines.items() if _state_at(tl, t) == "ready" and busy_until[aid] <= t]
            if not free:  # everybody is talking: the caller waits for the first operator to finish
                soon = sorted((busy_until[aid], aid) for aid, (tl, _) in timelines.items()
                              if _state_at(tl, t) == "ready" and busy_until[aid] - t < timedelta(seconds=patience))
                if soon:
                    free = [soon[0][1]]
                rng.shuffle(free)
            free.sort(key=lambda a: timelines[a][1] == "avoider")  # not first in line, but rings when others are busy
            if rng.random() < 0.25:
                free.reverse()
            wait, records, answered_by = rng.randint(2, 14), [], None
            if free and busy_until[free[0]] > t:
                wait = int((busy_until[free[0]] - t).total_seconds()) + rng.randint(2, 6)
            for aid in free:
                ring_from = t + timedelta(seconds=wait)
                profile = timelines[aid][1]
                if (profile == "avoider" and rng.random() < 0.55) or rng.random() < 0.04:  # did not pick up
                    records.append(CallRecord(linkedid=link, uniqueid=link, agent_id=aid, queue="400", direction="in",
                                              caller_number=number, caller_normalized=number, state="missed",
                                              started_at=ring_from, ended_at=ring_from + timedelta(seconds=15)))
                    wait += 16
                    if wait > patience:
                        break
                    continue
                if wait > patience:
                    break
                answered_by = aid
                ans = ring_from + timedelta(seconds=rng.randint(2, 6))
                wait = int((ans - t).total_seconds())
                talk = int(rng.triangular(40, 480, 140))
                records.append(CallRecord(linkedid=link, uniqueid=link, agent_id=aid, queue="400", direction="in",
                                          caller_number=number, caller_normalized=number, state="ended",
                                          started_at=ring_from, answered_at=ans, ended_at=ans + timedelta(seconds=talk)))
                busy_until[aid] = ans + timedelta(seconds=talk + 20)
                break
            if answered_by is None:
                wait = max(wait, patience if free else rng.choice([3, 25, 60, 95]))
            s.add_all(records)
            qc = QueueCall(linkedid=link, uniqueid=link, queue="400", caller_number=number, caller_normalized=number,
                           joined_at=t, wait_sec=wait, left_at=t + timedelta(seconds=wait))
            if answered_by:
                r = records[-1]
                qc.outcome, qc.agent_id, qc.answered_at, qc.ended_at = "answered", answered_by, r.answered_at, r.ended_at
                qc.talk_sec = int((r.ended_at - r.answered_at).total_seconds())
            else:
                qc.outcome = "exited" if wait >= 180 else "abandoned"
                if wait > 5:
                    missed_numbers.append((t + timedelta(seconds=wait), number))
            s.add(qc)

        # call-backs: most missed callers are called back by somebody who is free
        for when, number in missed_numbers:
            if rng.random() < 0.65:
                at = when + timedelta(minutes=rng.randint(3, 40))
                if at >= end:
                    continue
                free = [aid for aid, (tl, _) in timelines.items() if _state_at(tl, at) == "ready"]
                if not free:
                    continue
                aid = rng.choice(free)
                talk = rng.randint(30, 200)
                s.add(CallRecord(linkedid=f"O{at.timestamp():.0f}{aid}", uniqueid="o", agent_id=aid, direction="out",
                                 caller_number=number, caller_normalized=number, state="ended", started_at=at,
                                 answered_at=at + timedelta(seconds=8), ended_at=at + timedelta(seconds=8 + talk)))
        # ------------------------------------------------ a few conversations for the messenger (v3.0)
        chats = [  # minutes ago, from, to, text, read
            (240, 3, 5, "Mariam, can you help Davit with the refund cases today?", True),
            (236, 5, 3, "Sure, I'll sit with him after lunch.", True),
            (180, 6, 5, "Hi! How do I move a ticket to background without closing it?", True),
            (178, 5, 6, "Press “Background task” on the active ticket — calls start coming again.", True),
            (177, 6, 5, "Got it, thanks 🙏", True),
            (95, 3, 1, "Anna, great job this morning — the queue was empty all the time.", True),
            (94, 1, 3, "Thank you! Boris helped a lot with the sales calls.", True),
            (40, 2, 1, "Anna, do you have the new promo-code list?", True),
            (38, 1, 2, "Yes, I'll send it in Zammad as a note to #31109", True),
            (12, 7, 3, "Peak hour is coming, I'm staying online until 19:00.", False),
            (6, 3, 1, "Could you take the WhatsApp tickets after 18:00?", False),
            (5, 3, 1, "Boris will cover the phone.", False),
        ]
        now_ = utcnow()
        for ago, a, b, text, read in chats:
            at = now_ - timedelta(minutes=ago)
            s.add(ChatMessage(sender_id=a, recipient_id=b, body=text, created_at=at,
                              read_at=at + timedelta(minutes=1) if read else None))
        await s.commit()
