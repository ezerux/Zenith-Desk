"""Simulators of the Telegram Bot API and of the WhatsApp Business Cloud API (Meta Graph API).

They answer exactly like the real services for the calls Zenith Desk makes (same URLs, parameters, JSON, errors,
webhook headers and signatures), so the whole chain — receiving, answering, files, delivery statuses, webhooks,
long polling, missed webhooks — is tested without internet access and without the company's real bot or number.

Control endpoints (what a customer would do on his phone):
    POST /sim/telegram/message   {chat_id, first_name, last_name, username, text, photo: base64?, document: {name, data}?}
    POST /sim/whatsapp/message   {from, name, text, image: base64?, document: {name, data}?, minutes_ago?}
    GET  /sim/telegram/sent  ·  GET /sim/whatsapp/sent      what the bot / number sent to customers
    POST /sim/whatsapp/config    {webhook_url, app_secret}  (what is entered at Meta → WhatsApp → Configuration)
    POST /sim/whatsapp/redeliver  Meta re-sends webhooks that failed
    POST /sim/telegram/break_webhook {on}   the webhook URL becomes unreachable (network failure)
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import itertools
import json
import secrets
import time

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

TG_TOKEN = "7012345678:AAH-simulated-bot-token-0123456789ab"
WA_TOKEN = "EAAG-simulated-system-user-token"
WA_PHONE_ID = "106540352242922"
WA_DISPLAY = "+374 10 555 000"


def build_sim() -> FastAPI:
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(_app):
        yield
        await http.aclose()

    app = FastAPI(title="Telegram + WhatsApp simulator", lifespan=lifespan)
    tg = {"webhook": None, "secret": "", "updates": [], "undelivered": [], "uid": itertools.count(700000001), "mid": itertools.count(5001),
          "sent": [], "files": {}, "last_error": None, "broken": False, "cond": asyncio.Condition()}
    wa = {"webhook": "", "secret": "", "sent": [], "media": {}, "failed": [], "mid": itertools.count(1)}
    app.state.tg, app.state.wa = tg, wa
    http = httpx.AsyncClient(timeout=10)

    def ok(result):
        return JSONResponse({"ok": True, "result": result})

    def tg_err(code, desc, **params):
        body = {"ok": False, "error_code": code, "description": desc}
        if params:
            body["parameters"] = params
        return JSONResponse(body, status_code=code)

    async def args(request: Request) -> dict:
        ct = request.headers.get("content-type", "")
        if ct.startswith("application/json"):
            return await request.json()
        form = await request.form()
        out = {}
        for k, v in form.multi_items():
            out[k] = v
        return out

    # ------------------------------------------------------------------ Telegram Bot API
    async def deliver_tg(update: dict) -> bool:
        if tg["broken"]:
            tg["last_error"] = (int(time.time()), "Connection refused")
            return False
        try:
            r = await http.post(tg["webhook"], json=update, headers={"X-Telegram-Bot-Api-Secret-Token": tg["secret"]})
            if r.status_code == 200:
                return True
            tg["last_error"] = (int(time.time()), f"Wrong response from the webhook: {r.status_code}")
        except httpx.HTTPError as exc:
            tg["last_error"] = (int(time.time()), f"Connection failed: {type(exc).__name__}")
        return False

    @app.api_route("/telegram/bot{token}/{method}", methods=["GET", "POST"])
    async def bot_api(token: str, method: str, request: Request):
        if token != TG_TOKEN:
            return tg_err(401, "Unauthorized")
        a = await args(request)
        if method == "getMe":
            return ok({"id": 7012345678, "is_bot": True, "first_name": "Zenith Shop", "username": "zenith_shop_bot", "can_join_groups": False})
        if method == "setWebhook":
            url = a.get("url", "")
            if url and not url.startswith("http"):
                return tg_err(400, "Bad Request: bad webhook: Webhook can be set up only on ports 80, 88, 443 or 8443")
            tg["webhook"], tg["secret"] = url or None, a.get("secret_token", "")
            return ok(True)
        if method == "deleteWebhook":
            tg["webhook"] = None
            tg["updates"] = tg["undelivered"] + tg["updates"]
            tg["undelivered"] = []
            return ok(True)
        if method == "getWebhookInfo":
            info = {"url": tg["webhook"] or "", "has_custom_certificate": False, "pending_update_count": len(tg["undelivered"]) if tg["webhook"] else len(tg["updates"])}
            if tg["last_error"] and tg["webhook"]:
                info["last_error_date"], info["last_error_message"] = tg["last_error"]
            return ok(info)
        if method == "getUpdates":
            if tg["webhook"]:
                return tg_err(409, "Conflict: can't use getUpdates method while webhook is active; use deleteWebhook to delete the webhook first")
            offset = int(a.get("offset") or 0)
            if offset:
                tg["updates"] = [u for u in tg["updates"] if u["update_id"] >= offset]
            wait = float(a.get("timeout") or 0)
            deadline = time.monotonic() + wait
            async with tg["cond"]:
                while not tg["updates"] and time.monotonic() < deadline and not tg["webhook"]:
                    try:
                        await asyncio.wait_for(tg["cond"].wait(), timeout=max(0.05, deadline - time.monotonic()))
                    except asyncio.TimeoutError:
                        break
            return ok(list(tg["updates"][:100]))
        if method in ("sendMessage", "sendPhoto", "sendDocument"):
            chat = str(a.get("chat_id", ""))
            if not chat:
                return tg_err(400, "Bad Request: chat_id is empty")
            if chat == "403":
                return tg_err(403, "Forbidden: bot was blocked by the user")
            mid = next(tg["mid"])
            rec = {"method": method, "chat_id": chat, "message_id": mid, "text": a.get("text") or a.get("caption") or ""}
            for field in ("photo", "document"):
                f = a.get(field)
                if f is not None and hasattr(f, "read"):
                    data = await f.read()
                    rec["file"] = {"name": f.filename, "size": len(data), "sha1": hashlib.sha1(data).hexdigest()}
            tg["sent"].append(rec)
            return ok({"message_id": mid, "chat": {"id": int(chat), "type": "private"}, "date": int(time.time()), "text": rec["text"]})
        if method == "getFile":
            f = tg["files"].get(a.get("file_id"))
            if not f:
                return tg_err(400, "Bad Request: invalid file_id")
            return ok({"file_id": a.get("file_id"), "file_unique_id": a.get("file_id")[:8], "file_size": len(f[1]), "file_path": f[0]})
        return tg_err(404, "Not Found")

    @app.get("/telegram/file/bot{token}/{path:path}")
    async def bot_file(token: str, path: str):
        if token != TG_TOKEN:
            return Response(status_code=401)
        for fid, (p, data, mime) in tg["files"].items():
            if p == path:
                return Response(data, media_type=mime)
        return Response(status_code=404)

    @app.post("/sim/telegram/message")
    async def tg_customer(request: Request):
        b = await request.json()
        chat = int(b.get("chat_id") or 555001)
        frm = {"id": chat, "is_bot": False, "first_name": b.get("first_name", "Maria"), "language_code": "ru"}
        if b.get("last_name"):
            frm["last_name"] = b["last_name"]
        if b.get("username"):
            frm["username"] = b["username"]
        msg = {"message_id": next(tg["mid"]), "from": frm, "chat": {**frm, "type": "private"}, "date": int(time.time())}
        if b.get("photo"):
            data = base64.b64decode(b["photo"])
            fid = "AgAC" + secrets.token_hex(8)
            tg["files"][fid] = (f"photos/file_{len(tg['files'])}.jpg", data, "image/jpeg")
            msg["photo"] = [{"file_id": fid + "s", "file_unique_id": "s", "width": 90, "height": 90, "file_size": 100},
                            {"file_id": fid, "file_unique_id": "x", "width": 800, "height": 600, "file_size": len(data)}]
            tg["files"][fid + "s"] = tg["files"][fid]
            if b.get("text"):
                msg["caption"] = b["text"]
        elif b.get("document"):
            d = b["document"]
            data = base64.b64decode(d["data"])
            fid = "BQAC" + secrets.token_hex(8)
            tg["files"][fid] = (f"documents/{d['name']}", data, d.get("mime", "application/pdf"))
            msg["document"] = {"file_id": fid, "file_unique_id": fid[:8], "file_name": d["name"], "mime_type": d.get("mime", "application/pdf"), "file_size": len(data)}
            if b.get("text"):
                msg["caption"] = b["text"]
        else:
            msg["text"] = b.get("text", "")
        key = "edited_message" if b.get("edit_of") else "message"
        if b.get("edit_of"):
            msg["message_id"] = int(b["edit_of"])
            msg["edit_date"] = int(time.time())
        update = {"update_id": next(tg["uid"]), key: msg}
        if tg["webhook"]:
            if not await deliver_tg(update):
                tg["undelivered"].append(update)
        else:
            tg["updates"].append(update)
            async with tg["cond"]:
                tg["cond"].notify_all()
        return {"update_id": update["update_id"], "message_id": msg["message_id"]}

    @app.post("/sim/reset")
    async def reset():
        """Tests: forget everything (pending updates, sent messages, webhooks, failures)."""
        tg.update(webhook=None, secret="", updates=[], undelivered=[], sent=[], broken=False, last_error=None)
        wa.update(webhook="", secret="", sent=[], failed=[])
        return {"ok": True}

    @app.post("/sim/telegram/break_webhook")
    async def tg_break(request: Request):
        tg["broken"] = bool((await request.json()).get("on"))
        return {"broken": tg["broken"]}

    @app.get("/sim/telegram/sent")
    async def tg_sent():
        return {"sent": tg["sent"], "webhook": tg["webhook"], "pending": len(tg["undelivered"]) + len(tg["updates"])}

    # ------------------------------------------------------------------ WhatsApp Cloud API (Graph)
    def graph_err(status, code, message, kind="OAuthException"):
        return JSONResponse({"error": {"message": message, "type": kind, "code": code, "fbtrace_id": secrets.token_hex(6)}}, status_code=status)

    def authorized(request: Request) -> bool:
        return request.headers.get("authorization", "") == f"Bearer {WA_TOKEN}"

    async def wa_post(payload: dict) -> bool:
        if not wa["webhook"]:
            wa["failed"].append(payload)
            return False
        raw = json.dumps(payload).encode()
        sig = "sha256=" + hmac.new(wa["secret"].encode(), raw, hashlib.sha256).hexdigest()
        try:
            r = await http.post(wa["webhook"], content=raw, headers={"Content-Type": "application/json", "X-Hub-Signature-256": sig})
            if r.status_code == 200:
                return True
        except httpx.HTTPError:
            pass
        wa["failed"].append(payload)
        return False

    def envelope(value: dict) -> dict:
        return {"object": "whatsapp_business_account", "entry": [{"id": "102290129340398", "changes": [{"field": "messages", "value": {
            "messaging_product": "whatsapp", "metadata": {"display_phone_number": WA_DISPLAY.replace(" ", "").replace("+", ""), "phone_number_id": WA_PHONE_ID},
            **value}}]}]}

    async def statuses(msg_id: str, to: str, fail: bool = False):
        for st in (["failed"] if fail else ["sent", "delivered", "read"]):
            await asyncio.sleep(0.25)
            s = {"id": msg_id, "status": st, "timestamp": str(int(time.time())), "recipient_id": to}
            if st == "failed":
                s["errors"] = [{"code": 131026, "title": "Message undeliverable"}]
            await wa_post(envelope({"statuses": [s]}))

    @app.get("/graph/{version}/{obj}")
    async def graph_get(version: str, obj: str, request: Request):
        if not authorized(request):
            return graph_err(401, 190, "Error validating access token: The session is invalid.")
        if obj == WA_PHONE_ID:
            return {"display_phone_number": WA_DISPLAY, "verified_name": "Zenith Shop", "quality_rating": "GREEN", "status": "CONNECTED", "id": WA_PHONE_ID}
        if obj in wa["media"]:
            data, mime = wa["media"][obj]
            return {"url": str(request.base_url).rstrip("/") + f"/graph/media-download/{obj}", "mime_type": mime, "sha256": hashlib.sha256(data).hexdigest(),
                    "file_size": len(data), "id": obj, "messaging_product": "whatsapp"}
        return graph_err(400, 100, f"Unsupported get request. Object with ID '{obj}' does not exist", "GraphMethodException")

    @app.get("/graph/media-download/{media_id}")
    async def media_download(media_id: str, request: Request):
        if not authorized(request):
            return Response(status_code=401)
        data, mime = wa["media"].get(media_id, (None, None))
        return Response(data, media_type=mime) if data is not None else Response(status_code=404)

    @app.post("/graph/{version}/{obj}/{edge}")
    async def graph_post(version: str, obj: str, edge: str, request: Request):
        if not authorized(request):
            return graph_err(401, 190, "Error validating access token: The session is invalid.")
        if obj != WA_PHONE_ID:
            return graph_err(400, 100, "Invalid parameter", "GraphMethodException")
        if edge == "media":
            form = await request.form()
            f = form.get("file")
            data = await f.read()
            mid = str(1000000000000 + next(wa["mid"]))
            wa["media"][mid] = (data, form.get("type") or f.content_type)
            return {"id": mid}
        if edge == "messages":
            b = await request.json()
            if b.get("status") == "read":
                return {"success": True}
            to = b.get("to", "")
            if b.get("type") not in ("text", "template", "image", "document", "audio", "video"):
                return graph_err(400, 100, "Invalid parameter")
            if to == "37400000000":
                return graph_err(400, 131030, "Recipient phone number not in allowed list")
            mid = f"wamid.HBgL{secrets.token_hex(12).upper()}"
            rec = {"to": to, "type": b["type"], "id": mid, "text": (b.get("text") or {}).get("body", ""), "template": b.get("template"),
                   "media": b.get(b["type"]) if b["type"] in ("image", "document", "audio", "video") else None}
            wa["sent"].append(rec)
            asyncio.get_running_loop().create_task(statuses(mid, to))
            return {"messaging_product": "whatsapp", "contacts": [{"input": to, "wa_id": to}], "messages": [{"id": mid}]}
        return graph_err(400, 100, "Unknown edge")

    @app.post("/sim/whatsapp/config")
    async def wa_config(request: Request):
        b = await request.json()
        wa["webhook"], wa["secret"] = b.get("webhook_url", ""), b.get("app_secret", "")
        return {"ok": True}

    @app.post("/sim/whatsapp/message")
    async def wa_customer(request: Request):
        b = await request.json()
        frm = b.get("from") or "37491123456"
        mid = f"wamid.HBgL{secrets.token_hex(12).upper()}"
        msg = {"from": frm, "id": mid, "timestamp": str(int(time.time()) - int(b.get("minutes_ago") or 0) * 60)}
        if b.get("image"):
            data = base64.b64decode(b["image"])
            media = str(2000000000000 + next(wa["mid"]))
            wa["media"][media] = (data, "image/jpeg")
            msg.update(type="image", image={"id": media, "mime_type": "image/jpeg", "sha256": hashlib.sha256(data).hexdigest(), "caption": b.get("text", "")})
        elif b.get("document"):
            d = b["document"]
            data = base64.b64decode(d["data"])
            media = str(2000000000000 + next(wa["mid"]))
            wa["media"][media] = (data, d.get("mime", "application/pdf"))
            msg.update(type="document", document={"id": media, "filename": d["name"], "mime_type": d.get("mime", "application/pdf")})
        else:
            msg.update(type="text", text={"body": b.get("text", "")})
        delivered = await wa_post(envelope({"contacts": [{"profile": {"name": b.get("name", "Aram")}, "wa_id": frm}], "messages": [msg]}))
        return {"id": mid, "delivered": delivered}

    @app.post("/sim/whatsapp/redeliver")
    async def wa_redeliver():
        failed, wa["failed"] = wa["failed"], []
        n = 0
        for p in failed:
            if await wa_post(p):
                n += 1
        return {"redelivered": n, "still_failed": len(wa["failed"])}

    @app.get("/sim/whatsapp/sent")
    async def wa_sent():
        return {"sent": wa["sent"], "failed_webhooks": len(wa["failed"])}

    return app


if __name__ == "__main__":
    import sys

    import uvicorn
    uvicorn.run(build_sim(), host="127.0.0.1", port=int(sys.argv[1]) if len(sys.argv) > 1 else 8990, log_level="warning")
