"""In-process pub/sub for Server-Sent Events to the operator UI.

The service is designed to run as a single process (≤10 operators), so an in-memory
broker is enough. Supervisors receive all agent-state events.
"""
import asyncio
import json
import logging
import weakref
from collections import defaultdict
from collections.abc import AsyncIterator, Awaitable, Callable

log = logging.getLogger("events")

_CLOSE = ("__close__", {})
_brokers: "weakref.WeakSet[EventBroker]" = weakref.WeakSet()


def close_all_streams() -> None:
    """Server is stopping: end every SSE stream now, so a restart is instant and browsers reconnect at once."""
    for b in list(_brokers):
        b.close_streams()


def _patch_uvicorn() -> None:
    # uvicorn waits for open connections before it stops; an SSE stream never ends by itself.
    try:
        from uvicorn.server import Server
    except Exception:  # noqa: BLE001
        return
    if getattr(Server.handle_exit, "_agentix", False):
        return
    original = Server.handle_exit

    def handle_exit(self, sig, frame):
        original(self, sig, frame)
        try:
            loop = asyncio.get_event_loop()
            loop.call_soon_threadsafe(close_all_streams)
        except Exception:  # noqa: BLE001
            close_all_streams()
    handle_exit._agentix = True
    Server.handle_exit = handle_exit


_patch_uvicorn()


class EventBroker:
    def __init__(self) -> None:
        self._agent_subs: dict[int, set[asyncio.Queue]] = defaultdict(set)
        self._supervisor_subs: set[asyncio.Queue] = set()
        self.on_presence_change: Callable[[int, int], Awaitable[None]] | None = None
        _brokers.add(self)

    def close_streams(self) -> None:
        seen: set[int] = set()
        for qs in list(self._agent_subs.values()):
            for q in list(qs):
                if id(q) not in seen:
                    seen.add(id(q))
                    try:
                        q.put_nowait(_CLOSE)
                    except asyncio.QueueFull:
                        q.get_nowait()
                        q.put_nowait(_CLOSE)

    def online_agents(self) -> list[int]:
        return [a for a, qs in self._agent_subs.items() if qs]

    def connections(self, agent_id: int) -> int:
        return len(self._agent_subs.get(agent_id, ()))

    def publish_agent(self, agent_id: int, event: str, data: dict) -> None:
        msg = (event, data)
        for q in list(self._agent_subs.get(agent_id, ())):
            self._put(q, msg)

    def publish_all(self, event: str, data: dict) -> None:
        seen: set[int] = set()
        for qs in list(self._agent_subs.values()):
            for q in list(qs):
                if id(q) not in seen:
                    seen.add(id(q))
                    self._put(q, (event, data))

    def publish_supervisors(self, event: str, data: dict) -> None:
        for q in list(self._supervisor_subs):
            self._put(q, (event, data))

    @staticmethod
    def _put(q: asyncio.Queue, msg) -> None:
        try:
            q.put_nowait(msg)
        except asyncio.QueueFull:
            log.warning("SSE queue full, dropping event %s", msg[0])

    async def stream(self, agent_id: int, supervisor: bool, heartbeat: float = 15.0) -> AsyncIterator[str]:
        q: asyncio.Queue = asyncio.Queue(maxsize=200)
        self._agent_subs[agent_id].add(q)
        if supervisor:
            self._supervisor_subs.add(q)
        await self._presence(agent_id)
        try:
            yield "retry: 1000\n\n"  # reconnect after 1 s if the connection drops
            yield "event: hello\ndata: {}\n\n"
            while True:
                try:
                    event, data = await asyncio.wait_for(q.get(), heartbeat)
                    if (event, data) == _CLOSE:
                        return  # server shutdown: the browser reconnects to the new process within ~1 s
                    yield f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False, default=str)}\n\n"
                except asyncio.TimeoutError:
                    # a real event (not an SSE comment), so the browser can detect a silently dead connection
                    yield "event: ping\ndata: {}\n\n"
        finally:
            self._agent_subs[agent_id].discard(q)
            self._supervisor_subs.discard(q)
            await self._presence(agent_id)

    async def _presence(self, agent_id: int) -> None:
        if self.on_presence_change:
            try:
                await self.on_presence_change(agent_id, self.connections(agent_id))
            except Exception:  # noqa: BLE001
                log.exception("presence handler failed")
