"""v3.10 — backup and restore of the whole system in ONE file.

A backup file (``*.zdb``) holds everything Zenith Desk keeps: every table of the database (users, settings and
integrations, tickets links, calls, team chat, Telegram / WhatsApp conversations with their files, mail, audit …)
and the server key that encrypts the secrets and the chats. With this one file and its password the whole system can
be brought back — on the same server or on a brand-new one with a different ``JWT_SECRET``: on restore every encrypted
value is re-encrypted for the key of the server that restores it.

File format (all integers big-endian)::

    b"ZDBK" 0x01                      magic + format version
    uint32 n, n bytes                 header: JSON, NOT encrypted (date, version, kind, row counts, KDF salt)
    repeated:  uint32 n, n bytes      chunk = 12-byte nonce + AES-256-GCM(ciphertext + tag)

The plaintext of the chunks is a zlib stream of JSON lines (meta, then per table a "table" line and its rows,
then "end"). Every chunk is authenticated together with the header, its number and a "last chunk" flag, so a
changed, truncated or reordered file is refused. The key comes from the password with scrypt.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import struct
import zlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterator

from cryptography.exceptions import InvalidTag
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from sqlalchemy import JSON, Boolean, DateTime, Integer, LargeBinary, delete, func, select, text

from .db import Base, Database, as_utc
from . import models  # noqa: F401  (registers every table on Base.metadata)

MAGIC = b"ZDBK\x01"
FORMAT = 1
CHUNK = 1 << 20  # 1 MiB of compressed plaintext per encrypted chunk
SCRYPT_N, SCRYPT_R, SCRYPT_P = 2**15, 8, 1
SUFFIX = ".zdb"
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,150}\.zdb$")
KINDS = ("manual", "scheduled", "pre-restore", "uploaded", "cli")
MIN_PASSWORD = 8

# Columns encrypted with the server key (crypto.SecretBox / crypto.MessageCipher). On restore they are re-encrypted
# from the key of the server that made the backup to the key of the server that restores it.
SETTINGS_KEY_COLUMNS = {("agent_mapping", "sip_secret"), ("mail_account", "secret"), ("system_setting", "value")}
MESSAGE_KEY_COLUMNS = {("chat_message", "body"), ("msg_message", "body"), ("msg_conversation", "last_text"),
                       ("mail_local", "raw")}
MESSAGE_PREFIX = "v1:"


class BackupError(Exception):
    """Something the administrator has to fix (wrong password, damaged file …). ``code`` is a message key."""

    def __init__(self, code: str, **params):
        super().__init__(code)
        self.code, self.params = code, params


# ====================================================================== key derivation / re-encryption
def _derive(password: str, salt: bytes, n: int = SCRYPT_N, r: int = SCRYPT_R, p: int = SCRYPT_P) -> bytes:
    return hashlib.scrypt(password.encode(), salt=salt, n=n, r=r, p=p, dklen=32, maxmem=128 * 1024 * 1024)


def _fernet(purpose: bytes, master: str) -> Fernet:
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(purpose + master.encode()).digest()))


class Rekeyer:
    """Moves encrypted values from the old server key to the new one (no-op when both keys are the same)."""

    def __init__(self, old_master: str, new_master: str):
        self.active = bool(old_master) and old_master != new_master
        if self.active:
            self.old_s, self.new_s = _fernet(b"agentix-settings:", old_master), _fernet(b"agentix-settings:", new_master)
            self.old_m, self.new_m = _fernet(b"agentix-chat:", old_master), _fernet(b"agentix-chat:", new_master)
        self.failed = 0

    def _settings(self, value: str) -> str:
        try:
            return self.new_s.encrypt(self.old_s.decrypt(value.encode())).decode()
        except (InvalidToken, ValueError):
            self.failed += 1
            return value

    def _message(self, value: str) -> str:
        if not value.startswith(MESSAGE_PREFIX):
            return value  # plain text written before v3.1 — encrypted at start-up
        try:
            plain = self.old_m.decrypt(value[len(MESSAGE_PREFIX):].encode())
        except (InvalidToken, ValueError):
            self.failed += 1
            return value
        return MESSAGE_PREFIX + self.new_m.encrypt(plain).decode()

    def row(self, table: str, row: dict) -> dict:
        if not self.active:
            return row
        for (t, col) in SETTINGS_KEY_COLUMNS:
            if t == table and row.get(col):
                if table == "system_setting" and not row.get("is_secret"):
                    continue
                row[col] = self._settings(row[col])
        for (t, col) in MESSAGE_KEY_COLUMNS:
            if t == table and row.get(col):
                row[col] = self._message(row[col])
        return row


# ====================================================================== the encrypted container
def _check(key: bytes) -> str:
    """Tells a wrong password from a damaged file (reveals nothing about the key)."""
    return base64.b64encode(hmac.new(key, b"zenith-desk-backup-password-check", hashlib.sha256).digest()[:12]).decode()


def _aad(header: bytes, index: int, last: bool) -> bytes:
    return hashlib.sha256(header).digest() + struct.pack(">IB", index, 1 if last else 0)


class Writer:
    """Streams JSON lines → zlib → AES-GCM chunks into a file. Write to ``path + '.part'`` and rename at the end."""

    def __init__(self, path: Path, password: str, header: dict):
        if len(password or "") < MIN_PASSWORD:
            raise BackupError("bk.password_short", n=MIN_PASSWORD)
        salt = os.urandom(16)
        key = _derive(password, salt)
        header = {**header, "format": FORMAT, "kdf": {"name": "scrypt", "n": SCRYPT_N, "r": SCRYPT_R, "p": SCRYPT_P,
                                                       "salt": base64.b64encode(salt).decode(), "check": _check(key)}}
        self.header = json.dumps(header, ensure_ascii=False, sort_keys=True).encode()
        self.aes = AESGCM(key)
        self.path = path
        self.f = open(path, "wb")  # noqa: SIM115
        self.f.write(MAGIC + struct.pack(">I", len(self.header)) + self.header)
        self.z = zlib.compressobj(6)
        self.buf = bytearray()
        self.index = 0
        self.plain_bytes = 0

    def line(self, obj: Any) -> None:
        data = (json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
        self.plain_bytes += len(data)
        self.buf += self.z.compress(data)
        while len(self.buf) >= CHUNK:
            self._chunk(bytes(self.buf[:CHUNK]), last=False)
            del self.buf[:CHUNK]

    def _chunk(self, data: bytes, last: bool) -> None:
        nonce = os.urandom(12)
        ct = self.aes.encrypt(nonce, data, _aad(self.header, self.index, last))
        self.f.write(struct.pack(">I", len(nonce) + len(ct)) + nonce + ct)
        self.index += 1

    def close(self) -> None:
        self.buf += self.z.flush()
        while len(self.buf) > CHUNK:
            self._chunk(bytes(self.buf[:CHUNK]), last=False)
            del self.buf[:CHUNK]
        self._chunk(bytes(self.buf), last=True)
        self.f.flush()
        os.fsync(self.f.fileno())
        self.f.close()

    def abort(self) -> None:
        try:
            self.f.close()
        finally:
            self.path.unlink(missing_ok=True)


def read_header(path: Path) -> dict:
    """The unencrypted header: shown in the list without the password."""
    with open(path, "rb") as f:
        head = f.read(len(MAGIC) + 4)
        if len(head) < len(MAGIC) + 4 or head[: len(MAGIC)] != MAGIC:
            raise BackupError("bk.not_backup")
        (n,) = struct.unpack(">I", head[len(MAGIC):])
        if n > 1 << 20:
            raise BackupError("bk.not_backup")
        raw = f.read(n)
    try:
        return json.loads(raw)
    except ValueError as exc:
        raise BackupError("bk.not_backup") from exc


class Reader:
    """Decrypts and yields the JSON lines. Raises BackupError on a wrong password or a damaged / cut file."""

    def __init__(self, path: Path, password: str):
        self.path = path
        self.f = open(path, "rb")  # noqa: SIM115
        head = self.f.read(len(MAGIC) + 4)
        if len(head) < len(MAGIC) + 4 or head[: len(MAGIC)] != MAGIC:
            self.f.close()
            raise BackupError("bk.not_backup")
        (n,) = struct.unpack(">I", head[len(MAGIC):])
        if n > 1 << 20:
            self.f.close()
            raise BackupError("bk.not_backup")
        self.header_raw = self.f.read(n)
        try:
            self.header = json.loads(self.header_raw)
            kdf = self.header["kdf"]
            if self.header.get("format") != FORMAT or kdf.get("name") != "scrypt":
                raise BackupError("bk.unsupported")
            key = _derive(password or "", base64.b64decode(kdf["salt"]), int(kdf["n"]), int(kdf["r"]), int(kdf["p"]))
            if not hmac.compare_digest(_check(key), str(kdf.get("check", ""))):
                raise BackupError("bk.wrong_password")
        except BackupError:
            self.f.close()
            raise
        except (ValueError, KeyError, TypeError) as exc:
            self.f.close()
            raise BackupError("bk.not_backup") from exc
        self.aes = AESGCM(key)

    def _chunks(self) -> Iterator[bytes]:
        index, pending = 0, None
        while True:
            size_raw = self.f.read(4)
            if not size_raw:
                break
            if len(size_raw) < 4:
                raise BackupError("bk.damaged")
            (size,) = struct.unpack(">I", size_raw)
            blob = self.f.read(size)
            if len(blob) != size or size < 28:
                raise BackupError("bk.damaged")
            if pending is not None:  # the previous chunk is not the last one
                yield self._open(pending, index - 1, last=False)
            pending = blob
            index += 1
        if pending is None:
            raise BackupError("bk.damaged")
        yield self._open(pending, index - 1, last=True)

    def _open(self, blob: bytes, index: int, last: bool) -> bytes:
        try:
            return self.aes.decrypt(blob[:12], blob[12:], _aad(self.header_raw, index, last))
        except InvalidTag as exc:
            raise BackupError("bk.damaged") from exc

    def lines(self) -> Iterator[dict]:
        z = zlib.decompressobj()
        rest = b""
        try:
            for chunk in self._chunks():
                data = rest + z.decompress(chunk)
                *full, rest = data.split(b"\n")
                for ln in full:
                    if ln:
                        yield json.loads(ln)
            data = rest + z.flush()
            for ln in data.split(b"\n"):
                if ln:
                    yield json.loads(ln)
        except zlib.error as exc:
            raise BackupError("bk.damaged") from exc
        except ValueError as exc:
            raise BackupError("bk.damaged") from exc
        finally:
            self.f.close()


# ====================================================================== values <-> JSON
def _kind(col) -> str:
    t = col.type
    if isinstance(t, DateTime):
        return "ts"
    if isinstance(t, LargeBinary):
        return "bin"
    if isinstance(t, JSON):
        return "json"
    if isinstance(t, Boolean):
        return "bool"
    if isinstance(t, Integer):
        return "int"
    return "str"


def _enc(kind: str, v: Any) -> Any:
    if v is None:
        return None
    if kind == "ts":
        return as_utc(v).isoformat()
    if kind == "bin":
        return base64.b64encode(bytes(v)).decode()
    return v


def _dec(kind: str, v: Any) -> Any:
    if v is None:
        return None
    if kind == "ts":
        return datetime.fromisoformat(v)
    if kind == "bin":
        return base64.b64decode(v)
    if kind == "bool":
        return bool(v)
    return v


def _batch(kinds: list[str]) -> int:
    """Rows per round trip: few for tables with files in them (up to tens of MB per row), many otherwise."""
    return 8 if "bin" in kinds else 500


def _version_tuple(v: str) -> tuple:
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", str(v or "0"))[:3])


# ====================================================================== dump
@dataclass
class DumpResult:
    path: Path
    header: dict
    rows: int = 0
    tables: dict = field(default_factory=dict)


async def _alembic_revision(conn) -> str:
    """Schema revision (empty when the schema was not made by Alembic, e.g. in tests)."""
    def has_table(sync_conn) -> bool:
        from sqlalchemy import inspect  # noqa: PLC0415
        return inspect(sync_conn).has_table("alembic_version")
    if not await conn.run_sync(has_table):
        return ""
    return (await conn.execute(text("SELECT version_num FROM alembic_version"))).scalar() or ""


async def dump(db: Database, path: Path, password: str, *, master_key: str, app_version: str, kind: str,
               created_by: str = "", note: str = "") -> DumpResult:
    """Write a consistent snapshot of every table to ``path`` (atomically: ``.part`` then rename)."""
    tables = list(Base.metadata.sorted_tables)
    created = datetime.now(timezone.utc)
    part = path.with_name(path.name + ".part")
    async with db.engine.connect() as conn:
        if db.engine.dialect.name == "postgresql":  # one snapshot for all tables
            await conn.execution_options(isolation_level="REPEATABLE READ")
        async with conn.begin():
            counts = {}
            for t in tables:
                counts[t.name] = int((await conn.execute(select(func.count()).select_from(t))).scalar() or 0)
            revision = await _alembic_revision(conn)
            header = {"product": "Zenith Desk", "app_version": app_version, "schema": revision, "kind": kind,
                      "created_at": created.isoformat(), "created_by": created_by, "note": note[:200],
                      "tables": counts, "rows": sum(counts.values())}
            w = Writer(part, password, header)
            try:
                w.line({"t": "meta", "master_key": master_key, "app_version": app_version, "schema": revision,
                        "created_at": created.isoformat(), "nonce": secrets.token_hex(8)})
                done = {}
                for t in tables:
                    cols = list(t.columns)
                    kinds = [_kind(c) for c in cols]
                    w.line({"t": "table", "name": t.name, "columns": [[c.name, k] for c, k in zip(cols, kinds)]})
                    n = 0
                    order = [c for c in t.primary_key.columns] or cols[:1]
                    result = await conn.stream(select(*cols).order_by(*order))
                    async for part_rows in result.partitions(_batch(kinds)):
                        for row in part_rows:
                            w.line({"r": [_enc(k, v) for k, v in zip(kinds, row)]})
                            n += 1
                    done[t.name] = n
                w.line({"t": "end", "tables": done})
                w.close()
            except BaseException:
                w.abort()
                raise
    os.replace(part, path)
    return DumpResult(path, json.loads(w.header), sum(done.values()), done)


# ====================================================================== verify / restore
@dataclass
class Plan:
    header: dict
    meta: dict
    tables: dict  # name -> rows
    app_version: str


def verify(path: Path, password: str, *, app_version: str) -> Plan:
    """Decrypt the whole file once (password, integrity, completeness, version) without touching the database."""
    r = Reader(path, password)
    meta, counts, cur, ended = None, {}, None, False
    for obj in r.lines():
        t = obj.get("t")
        if t == "meta":
            meta = obj
        elif t == "table":
            cur = obj["name"]
            counts[cur] = 0
        elif t == "end":
            ended = obj.get("tables") == counts
        elif "r" in obj and cur is not None:
            counts[cur] += 1
    if meta is None or not ended:
        raise BackupError("bk.damaged")
    if _version_tuple(meta.get("app_version")) > _version_tuple(app_version):
        raise BackupError("bk.newer", version=meta.get("app_version"), current=app_version)
    return Plan(r.header, meta, counts, meta.get("app_version", ""))


def check_password(path: Path, password: str) -> dict:
    """Quick check: only the first chunk is decrypted (a wrong password is reported at once)."""
    r = Reader(path, password)
    try:
        next(r._chunks())
    finally:
        r.f.close()
    return r.header


async def restore(db: Database, path: Path, password: str, *, master_key: str, app_version: str,
                  progress: Callable[[str, int], None] | None = None, plan: Plan | None = None) -> dict:
    """Replace the content of every table with the backup — in ONE transaction (all or nothing).

    Columns the backup does not have get their defaults; columns this version does not know are skipped;
    encrypted values are moved to this server's key."""
    if plan is None:  # never start deleting with a bad file
        plan = verify(path, password, app_version=app_version)
    tables = {t.name: t for t in Base.metadata.sorted_tables}
    rekey = Rekeyer(plan.meta.get("master_key", ""), master_key)
    restored: dict[str, int] = {}
    async with db.engine.begin() as conn:
        if db.engine.dialect.name == "sqlite":
            await conn.execute(text("PRAGMA defer_foreign_keys = ON"))
        for t in reversed(Base.metadata.sorted_tables):
            await conn.execute(delete(t))
        reader = Reader(path, password)
        cur, cols, batch, limit = None, [], [], 500

        async def flush() -> None:
            if batch and cur is not None:
                await conn.execute(cur.insert(), list(batch))
                restored[cur.name] = restored.get(cur.name, 0) + len(batch)
                if progress:
                    progress(cur.name, restored[cur.name])
                batch.clear()

        for obj in reader.lines():
            t = obj.get("t")
            if t == "table":
                await flush()
                cur = tables.get(obj["name"])
                cols = [(name, kind) for name, kind in obj["columns"]]
                limit = _batch([k for _, k in cols])
                if cur is not None:
                    restored.setdefault(cur.name, 0)
            elif "r" in obj:
                if cur is None:
                    continue  # a table this version no longer has
                row = {}
                for (name, kind), v in zip(cols, obj["r"]):
                    if name in cur.c:
                        row[name] = _dec(kind, v)
                batch.append(rekey.row(cur.name, row))
                if len(batch) >= limit:
                    await flush()
        await flush()
        if db.engine.dialect.name == "postgresql":  # explicit ids do not move the sequences
            for t in Base.metadata.sorted_tables:
                pk = list(t.primary_key.columns)
                if len(pk) == 1 and isinstance(pk[0].type, Integer) and pk[0].autoincrement in (True, "auto"):
                    await conn.execute(text(
                        f"SELECT setval(pg_get_serial_sequence('{t.name}', '{pk[0].name}'), "
                        f"COALESCE((SELECT MAX({pk[0].name}) FROM {t.name}), 0) + 1, false)"))
    return {"tables": restored, "rows": sum(restored.values()), "rekeyed": rekey.active, "rekey_failed": rekey.failed,
            "backup_version": plan.app_version, "created_at": plan.header.get("created_at")}


# ====================================================================== files on disk
def safe_name(name: str) -> str:
    if not NAME_RE.match(name or "") or ".." in name:
        raise BackupError("bk.not_found")
    return name


def new_name(kind: str, now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    return f"zenith-backup-{now.strftime('%Y%m%d-%H%M%S')}-{kind}-{secrets.token_hex(2)}{SUFFIX}"


def list_files(folder: Path) -> list[dict]:
    out = []
    if not folder.is_dir():
        return out
    for p in folder.glob("*" + SUFFIX):
        try:
            st = p.stat()
            h = read_header(p)
            out.append({"name": p.name, "size": st.st_size, "created_at": h.get("created_at"), "kind": h.get("kind", ""),
                        "app_version": h.get("app_version", ""), "rows": h.get("rows", 0), "created_by": h.get("created_by", ""),
                        "note": h.get("note", ""), "ok": True})
        except (OSError, BackupError):
            try:
                st = p.stat()
                out.append({"name": p.name, "size": st.st_size, "ok": False,
                            "created_at": datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(), "kind": "unknown"})
            except OSError:
                continue
    out.sort(key=lambda x: x.get("created_at") or "", reverse=True)
    return out


def prune(folder: Path, keep: int, kinds: tuple[str, ...] = ("scheduled",)) -> list[str]:
    """Keep the newest ``keep`` automatic backups; manual, uploaded and pre-restore copies are never deleted here."""
    if keep <= 0:
        return []
    items = [b for b in list_files(folder) if b.get("kind") in kinds]
    removed = []
    for b in items[keep:]:
        try:
            (folder / b["name"]).unlink()
            removed.append(b["name"])
        except OSError:
            pass
    return removed
