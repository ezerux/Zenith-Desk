"""Reading and writing e-mail messages: headers, safe HTML, attachments, replies."""
from __future__ import annotations

import base64
import html as htmllib
import re
from datetime import datetime, timezone
from email import policy
from email.header import decode_header, make_header
from email.message import EmailMessage
from email.parser import BytesParser
from email.utils import formataddr, getaddresses, make_msgid, parsedate_to_datetime

import nh3

ALLOWED_TAGS = {
    "a", "abbr", "b", "blockquote", "br", "caption", "center", "code", "col", "colgroup", "dd", "del", "div", "dl", "dt", "em",
    "font", "h1", "h2", "h3", "h4", "h5", "h6", "hr", "i", "img", "ins", "li", "ol", "p", "pre", "q", "s", "small", "span",
    "strike", "strong", "sub", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "tr", "u", "ul",
}
ALLOWED_ATTRS = {
    "*": {"style", "class", "align", "valign", "width", "height", "dir", "title", "bgcolor", "color", "border"},
    "a": {"href", "name", "target"}, "img": {"src", "alt", "data-src"}, "font": {"face", "size"},
    "td": {"colspan", "rowspan"}, "th": {"colspan", "rowspan"}, "table": {"cellpadding", "cellspacing"},
}


def header_text(value) -> str:
    if value is None:
        return ""
    try:
        return str(make_header(decode_header(str(value)))).strip()
    except Exception:  # noqa: BLE001
        return str(value).strip()


def addresses(value) -> list[dict]:
    out = []
    for name, addr in getaddresses([header_text(value)] if value else []):
        if addr or name:
            out.append({"name": name, "email": addr})
    return out


def fmt_addresses(items: list[dict]) -> str:
    return ", ".join(formataddr((a.get("name") or "", a.get("email") or "")) if a.get("name") else a.get("email", "") for a in items)


def parse_date(value) -> str:
    try:
        d = parsedate_to_datetime(str(value))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d.astimezone(timezone.utc).isoformat()
    except Exception:  # noqa: BLE001
        return ""


def parse(raw: bytes) -> EmailMessage:
    return BytesParser(policy=policy.default).parsebytes(raw)


def _payload_text(part) -> str:
    try:
        return part.get_content()
    except Exception:  # noqa: BLE001 — unknown charset etc.
        data = part.get_payload(decode=True) or b""
        return data.decode("utf-8", "replace")


def walk_attachments(msg: EmailMessage) -> list:
    """Attachments and inline files (with a Content-ID), in a stable order (their index is used in URLs)."""
    out = []
    for part in msg.walk():
        if part.is_multipart():
            continue
        disp = part.get_content_disposition()
        ctype = part.get_content_type()
        if disp == "attachment" or (part.get_filename() and ctype not in ("text/plain", "text/html")) or \
           (disp == "inline" and not ctype.startswith("text/")) or (part.get("Content-ID") and not ctype.startswith("text/")):
            out.append(part)
    return out


def body_parts(msg: EmailMessage) -> tuple[str, str]:
    text = html = ""
    try:
        b = msg.get_body(preferencelist=("html",))
        if b is not None:
            html = _payload_text(b)
        t = msg.get_body(preferencelist=("plain",))
        if t is not None:
            text = _payload_text(t)
    except Exception:  # noqa: BLE001
        pass
    if not text and not html and not msg.is_multipart():
        text = _payload_text(msg)
    return text, html


def text_to_html(text: str) -> str:
    esc = htmllib.escape(text)
    esc = re.sub(r"(https?://[^\s<]+)", r'<a href="\1" target="_blank" rel="noopener">\1</a>', esc)
    return '<div style="white-space:pre-wrap;font-family:inherit">' + esc + "</div>"


def safe_html(html: str, cid_url) -> tuple[str, bool]:
    """Clean HTML (no scripts, forms, frames, event handlers); inline images (cid:) point to our attachment URL;
    images from the internet are blocked until the reader allows them (tracking pixels)."""
    clean = nh3.clean(html, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRS, url_schemes={"http", "https", "mailto", "cid", "data"},
                      link_rel="noopener noreferrer", strip_comments=True)
    remote = False

    def img(m):
        nonlocal remote
        tag = m.group(0)
        src = re.search(r'src="([^"]*)"', tag)
        if not src:
            return tag
        url = htmllib.unescape(src.group(1))
        if url.lower().startswith("cid:"):
            return tag.replace(src.group(0), f'src="{htmllib.escape(cid_url(url[4:]))}"')
        if url.lower().startswith(("http://", "https://")):
            remote = True
            return tag.replace(src.group(0), f'data-src="{src.group(1)}"')
        return tag

    clean = re.sub(r"<img\b[^>]*>", img, clean, flags=re.I)
    clean = re.sub(r'url\(\s*[\'"]?https?:[^)]*\)', "none", clean, flags=re.I)  # remote CSS backgrounds
    clean = re.sub(r"<a\b", '<a target="_blank"', clean)
    return clean, remote


def snippet(text: str, html: str, n: int = 160) -> str:
    s = text or re.sub(r"<[^>]+>", " ", re.sub(r"(?is)<(style|script)[^>]*>.*?</\1>", " ", html))
    s = htmllib.unescape(re.sub(r"\s+", " ", s)).strip()
    return s[:n]


def view(raw: bytes, cid_url, att_url) -> dict:
    msg = parse(raw)
    text, html = body_parts(msg)
    atts = []
    cids = {}
    for i, part in enumerate(walk_attachments(msg)):
        name = header_text(part.get_filename()) or f"file-{i + 1}"
        data = part.get_payload(decode=True) or b""
        cid = (part.get("Content-ID") or "").strip("<> ")
        if cid and part.get_content_type().startswith("image/") and len(data) < 3 * 1024 * 1024:
            # inline pictures (logos, signatures) go into the message itself: the sandboxed frame cannot authenticate
            cids[cid] = f"data:{part.get_content_type()};base64,{base64.b64encode(data).decode()}"
        atts.append({"idx": i, "name": name, "mime": part.get_content_type(), "size": len(data), "inline": bool(cid) and part.get_content_disposition() != "attachment",
                     "url": att_url(i)})
    remote = False
    if html:
        body, remote = safe_html(html, lambda cid: cids.get(cid, ""))
    else:
        body = text_to_html(text)
    return {
        "subject": header_text(msg["Subject"]), "from": addresses(msg["From"]), "to": addresses(msg["To"]),
        "cc": addresses(msg["Cc"]), "reply_to": addresses(msg["Reply-To"]), "date": parse_date(msg["Date"]),
        "message_id": (msg["Message-ID"] or "").strip(), "references": (msg["References"] or "").strip(),
        "html": body, "text": text or snippet("", html, 100000), "remote_images": remote,
        "attachments": [a for a in atts if not a["inline"] or not html], "inline_count": sum(1 for a in atts if a["inline"]),
    }


def attachment(raw: bytes, idx: int) -> tuple[str, str, bytes]:
    parts = walk_attachments(parse(raw))
    part = parts[idx]
    return header_text(part.get_filename()) or f"file-{idx + 1}", part.get_content_type(), part.get_payload(decode=True) or b""


def build(sender_name: str, sender: str, to: list[dict], cc: list[dict], bcc: list[dict], subject: str, text: str,
          files: list[tuple[str, str, bytes]], in_reply_to: str = "", references: str = "", draft: bool = False) -> EmailMessage:
    m = EmailMessage(policy=policy.SMTP)
    m["From"] = formataddr((sender_name, sender)) if sender_name else sender
    if to:
        m["To"] = fmt_addresses(to)
    if cc:
        m["Cc"] = fmt_addresses(cc)
    if bcc and draft:
        m["Bcc"] = fmt_addresses(bcc)
    m["Subject"] = subject
    m["Date"] = datetime.now(timezone.utc)
    m["Message-ID"] = make_msgid(domain=sender.rsplit("@", 1)[-1] if "@" in sender else None)
    if in_reply_to:
        m["In-Reply-To"] = in_reply_to
        m["References"] = (references + " " + in_reply_to).strip()
    m["X-Mailer"] = "Zenith Desk"
    m.set_content(text or "")
    m.add_alternative("<html><body>" + text_to_html(text or "") + "</body></html>", subtype="html")
    for name, mime, data in files:
        maintype, _, subtype = (mime or "application/octet-stream").partition("/")
        m.add_attachment(data, maintype=maintype or "application", subtype=subtype or "octet-stream", filename=name)
    return m


def quote_reply(view_: dict, mode: str) -> dict:
    """Prepared fields for Reply / Reply all / Forward."""
    subj = view_["subject"] or ""
    frm = view_["from"][0] if view_["from"] else {"name": "", "email": ""}
    head = f"{view_['date'][:16].replace('T', ' ')}, {frm.get('name') or frm.get('email')} <{frm.get('email')}>:"
    quoted = "\n".join("> " + line for line in (view_["text"] or "").splitlines())
    if mode == "forward":
        return {"subject": subj if subj.lower().startswith(("fwd:", "fw:")) else f"Fwd: {subj}", "to": [], "cc": [],
                "text": f"\n\n---------- Forwarded message ----------\n{head}\n{view_['text']}", "in_reply_to": "", "references": ""}
    return {"subject": subj if subj.lower().startswith("re:") else f"Re: {subj}",
            "to": view_["reply_to"] or view_["from"], "cc": view_["cc"] if mode == "reply_all" else [],
            "text": f"\n\n{head}\n{quoted}", "in_reply_to": view_["message_id"], "references": view_["references"]}


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode()
