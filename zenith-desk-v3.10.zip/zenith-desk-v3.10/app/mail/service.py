"""v3.9 E-mail inside Zenith Desk.

The administrator configures the company mail server once (IMAP or POP3 + SMTP, ports, encryption). Every employee
then only signs in with his e-mail and password: folders, reading, writing, replies, attachments, and "create a ticket
from this e-mail" work on the employee's own mailbox.

Real time: IMAP IDLE for everybody who has Zenith Desk open — new mail arrives within a second.
Fallback: every sync_fallback_min the INBOX of every mailbox is checked (UIDNEXT); POP3 mailboxes are downloaded.
"""
from __future__ import annotations

import asyncio
import base64
import imaplib
import logging
import re
import threading
import time
from collections import OrderedDict
from datetime import datetime, timezone

from sqlalchemy import delete, func, select

from ..audit import audit
from ..db import as_utc, utcnow
from ..i18n import t as tr
from ..models import AgentMapping, MailAccount, MailLocal
from . import message as mm
from .proto import Imap, MailError, Server, imap_idle_wait, pop3_fetch_new, pop3_open, probe, smtp_open, smtp_send

log = logging.getLogger("mail")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
LOCAL_FOLDERS = [("INBOX", "inbox"), ("Drafts", "drafts"), ("Sent", "sent"), ("Trash", "trash")]


class MailUserError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


class MailService:
    def __init__(self, sv):
        self.sv = sv
        self.boxes: dict[int, Imap] = {}
        self.idle: dict[int, tuple[threading.Thread, threading.Event]] = {}
        self.idle_state: dict[int, tuple[bool, str]] = {}
        self.cache: OrderedDict = OrderedDict()   # (agent, folder, uid) -> raw message
        self._loop: asyncio.AbstractEventLoop | None = None
        self._tasks: list[asyncio.Task] = []
        self._side: set[asyncio.Task] = set()  # inbox checks started by the IDLE threads
        self._closing = False
        self._accounts: dict[int, tuple[str, str]] = {}  # agent -> (login, password)  (decrypted, in memory only)
        sv.hub.register("mail", "E-mail", self.fallback, self.enabled)

    # ------------------------------------------------------------------ configuration
    @property
    def cfg(self):
        return self.sv.settings

    def enabled(self) -> bool:
        return bool(self.cfg.mail_enabled and self.cfg.mail_in_host and self.cfg.mail_smtp_host)

    @property
    def pop3(self) -> bool:
        return self.cfg.mail_protocol == "pop3"

    def server(self, values: dict | None = None) -> Server:
        v = {**{k: getattr(self.cfg, k) for k in dir(self.cfg) if k.startswith("mail_")}, **(values or {})}
        return Server(v["mail_protocol"], v["mail_in_host"], int(v["mail_in_port"]), v["mail_in_security"], v["mail_smtp_host"],
                      int(v["mail_smtp_port"]), v["mail_smtp_security"], bool(v["mail_smtp_auth"]), bool(v["mail_verify_tls"]))

    async def start(self) -> None:
        self._closing = False
        self._loop = asyncio.get_running_loop()
        self._tasks.append(asyncio.create_task(self._housekeeping(), name="mail-housekeeping"))
        await self.configure()

    def _spawn(self, coro) -> None:
        if self._closing:  # a late IDLE callback during shutdown
            coro.close()
            return
        task = asyncio.create_task(coro)
        self._side.add(task)
        task.add_done_callback(self._side.discard)

    async def stop(self) -> None:
        self._closing = True
        await self._drop_all()  # stop the IDLE threads first: nothing new can be started after this
        for t in [*self._tasks, *self._side]:
            t.cancel()
        await asyncio.gather(*self._tasks, *self._side, return_exceptions=True)
        self._tasks.clear()

    async def _drop_all(self) -> None:
        for agent_id in list(self.idle):
            self._stop_idle(agent_id)
        boxes, self.boxes = self.boxes, {}
        for b in boxes.values():
            await asyncio.to_thread(b.close)
        self.cache.clear()

    async def configure(self) -> None:
        await self._drop_all()
        self._accounts.clear()
        self._update_realtime()
        if self.enabled() and not self.pop3 and self.cfg.mail_idle:
            for agent_id in self.sv.broker.online_agents():
                await self.presence(agent_id, 1)

    def _update_realtime(self) -> None:
        if not self.enabled():
            self.sv.hub.realtime("mail", False, "")
        elif self.pop3:
            self.sv.hub.realtime("mail", "n/a", tr("rt.pop3"))
        elif not self.cfg.mail_idle:
            self.sv.hub.realtime("mail", "n/a", tr("rt.idle_off"))
        else:
            on = sum(1 for ok, _ in self.idle_state.values() if ok)
            if not self.idle_state:
                self.sv.hub.realtime("mail", "n/a", tr("rt.idle_wait"))
            else:
                self.sv.hub.realtime("mail", "on" if on else "off", tr("rt.idle", on=on, n=len(self.idle_state)))

    # ------------------------------------------------------------------ account of the employee
    def normalize_email(self, raw: str) -> str:
        e = (raw or "").strip().lower()
        dom = (self.cfg.mail_domain or "").strip().lower().lstrip("@")
        if "@" not in e and dom:
            e = f"{e}@{dom}"
        if not EMAIL_RE.match(e):
            raise MailUserError("invalid e-mail address", 422)
        if dom and not e.endswith("@" + dom):
            raise MailUserError(f"only addresses @{dom}", 422)
        return e

    def login_for(self, email: str) -> str:
        return email.split("@", 1)[0] if self.cfg.mail_login_format == "local" else email

    async def connect(self, agent: AgentMapping, email: str, password: str) -> dict:
        if not self.enabled():
            raise MailUserError("mail is not configured by the administrator", 409)
        email = self.normalize_email(email)
        login = self.login_for(email)
        server = self.server()

        def check():
            if self.pop3:
                p = pop3_open(server, login, password)
                p.quit()
            else:
                Imap(server, login, password).open().logout()
            if server.smtp_auth:
                c = smtp_open(server, login, password)
                c.quit()

        try:
            await asyncio.to_thread(check)
        except MailError as exc:
            raise MailUserError(str(exc), 422 if exc.auth else 502) from exc
        async with self.sv.db.sessionmaker() as s:
            acc = await s.get(MailAccount, agent.id)
            if acc is None:
                acc = MailAccount(agent_id=agent.id, email=email, login=login, secret="", status="ok", last_error="",
                                  uidvalidity=0, uidnext=0, unseen=0)
                s.add(acc)
            if acc.email != email:
                acc.uidvalidity = acc.uidnext = 0
                await s.execute(delete(MailLocal).where(MailLocal.agent_id == agent.id))
            acc.email, acc.login, acc.secret, acc.status, acc.last_error = email, login, self.sv.store.box.encrypt(password), "ok", ""
            audit(s, "mail_connected", agent_id=agent.id, actor_type="agent", actor_id=agent.id, email=email)
            await s.commit()
        await self._forget(agent.id)
        self._accounts[agent.id] = (login, password)
        await self.presence(agent.id, max(1, self.sv.broker.connections(agent.id)))
        if self.pop3:
            await self._pop3_sync(agent.id)
        else:
            await self._check_inbox(agent.id, notify=False)
        return await self.account(agent)

    async def disconnect(self, agent: AgentMapping) -> dict:
        await self._forget(agent.id)
        async with self.sv.db.sessionmaker() as s:
            await s.execute(delete(MailLocal).where(MailLocal.agent_id == agent.id))
            acc = await s.get(MailAccount, agent.id)
            if acc:
                await s.delete(acc)
                audit(s, "mail_disconnected", agent_id=agent.id, actor_type="agent", actor_id=agent.id)
            await s.commit()
        return await self.account(agent)

    async def _forget(self, agent_id: int) -> None:
        self._stop_idle(agent_id)
        self._accounts.pop(agent_id, None)
        b = self.boxes.pop(agent_id, None)
        if b:
            await asyncio.to_thread(b.close)
        for k in [k for k in self.cache if k[0] == agent_id]:
            self.cache.pop(k, None)

    async def account(self, agent: AgentMapping) -> dict:
        async with self.sv.db.sessionmaker() as s:
            acc = await s.get(MailAccount, agent.id)
        return {"enabled": self.enabled(), "protocol": self.cfg.mail_protocol, "domain": self.cfg.mail_domain,
                "connected": acc is not None, "email": acc.email if acc else "", "status": acc.status if acc else "",
                "error": acc.last_error if acc else "", "unseen": acc.unseen if acc else 0,
                "realtime": self.idle_state.get(agent.id, (False, ""))[0], "max_attach_mb": self.cfg.mail_max_attach_mb}

    async def _creds(self, agent_id: int) -> tuple[str, str, str]:
        async with self.sv.db.sessionmaker() as s:
            acc = await s.get(MailAccount, agent_id)
        if acc is None:
            raise MailUserError("no mailbox connected", 409)
        if agent_id not in self._accounts:
            pw = self.sv.store.box.decrypt(acc.secret)
            if pw is None:
                raise MailUserError("mailbox password cannot be read — sign in to the mailbox again", 409)
            self._accounts[agent_id] = (acc.login, pw)
        login, pw = self._accounts[agent_id]
        return acc.email, login, pw

    async def _box(self, agent_id: int) -> Imap:
        if not self.enabled():
            raise MailUserError("mail is not configured by the administrator", 409)
        b = self.boxes.get(agent_id)
        if b is None:
            _, login, pw = await self._creds(agent_id)
            b = self.boxes[agent_id] = Imap(self.server(), login, pw)
        return b

    async def _run(self, agent_id: int, fn):
        b = await self._box(agent_id)
        try:
            return await asyncio.to_thread(b.run, fn)
        except MailError as exc:
            await self._set_status(agent_id, str(exc))
            raise MailUserError(str(exc), 422 if exc.auth else 502) from exc

    async def _set_status(self, agent_id: int, error: str) -> None:
        async with self.sv.db.sessionmaker() as s:
            acc = await s.get(MailAccount, agent_id)
            if acc and (acc.last_error != error):
                acc.status, acc.last_error = ("error" if error else "ok"), error[:500]
                await s.commit()

    # ------------------------------------------------------------------ folders and lists
    async def folders(self, agent: AgentMapping) -> list[dict]:
        if self.pop3:
            return await self._local_folders(agent.id)

        def work(b: Imap):
            out = []
            for f in b.folders(refresh=True)[:40]:
                st = b.status(f["name"])
                out.append({**f, "unseen": st.get("unseen", 0), "total": st.get("messages", 0)})
            return out
        return await self._run(agent.id, work)

    async def messages(self, agent: AgentMapping, folder: str, page: int = 1, q: str = "", size: int = 50) -> dict:
        if self.pop3:
            return await self._local_list(agent.id, folder, page, q, size)

        def work(b: Imap):
            total = b.select(folder, readonly=True)
            c = b.conn
            if q.strip():
                if q.isascii():
                    typ, data = c.uid("SEARCH", None, "TEXT", '"' + q.replace('"', "") + '"')
                else:
                    c.literal = q.encode()
                    typ, data = c.uid("SEARCH", "CHARSET", "UTF-8", "TEXT")
            else:
                typ, data = c.uid("SEARCH", None, "ALL")
            uids = sorted((int(x) for x in (data[0] or b"").split()), reverse=True)
            found = len(uids)
            chunk = uids[(page - 1) * size: page * size]
            items = []
            if chunk:
                typ, resp = c.uid("FETCH", ",".join(map(str, chunk)),
                                  "(UID FLAGS INTERNALDATE RFC822.SIZE BODYSTRUCTURE BODY.PEEK[HEADER.FIELDS (FROM TO CC SUBJECT DATE)])")
                items = _parse_fetch(resp)
                items.sort(key=lambda m: m["uid"], reverse=True)
            return {"items": items, "total": found if q.strip() else total, "page": page, "size": size, "folder": folder}
        return await self._run(agent.id, work)

    async def read(self, agent: AgentMapping, folder: str, uid: int) -> dict:
        raw = await self._raw(agent.id, folder, uid, mark_seen=True)
        base = f"/api/mail/messages/{folder_url(folder)}/{uid}/attachments/"
        v = mm.view(raw, cid_url=lambda cid: "", att_url=lambda i: base + str(i))
        v.update({"uid": uid, "folder": folder, "size": len(raw)})
        v["reply"] = mm.quote_reply(v, "reply")
        v["reply_all"] = mm.quote_reply(v, "reply_all")
        v["forward"] = mm.quote_reply(v, "forward")
        return v

    async def _raw(self, agent_id: int, folder: str, uid: int, mark_seen: bool = False) -> bytes:
        key = (agent_id, folder, uid)
        if self.pop3:
            row = await self._local_row(agent_id, uid)
            if row is None:
                raise MailUserError("message not found", 404)
            if mark_seen and not row.seen:
                await self._local_flags(agent_id, [uid], seen=True)
            return self._decrypt(row.raw)
        if key in self.cache and not mark_seen:
            self.cache.move_to_end(key)
            return self.cache[key]

        def work(b: Imap):
            b.select(folder, readonly=False)
            typ, resp = b.conn.uid("FETCH", str(uid), "(FLAGS BODY.PEEK[])")
            raw = next((p[1] for p in resp or [] if isinstance(p, tuple)), None)
            if raw is None:
                raise MailError("message not found")
            if mark_seen and b"\\Seen" not in (resp[0][0] if isinstance(resp[0], tuple) else b""):
                b.conn.uid("STORE", str(uid), "+FLAGS.SILENT", "(\\Seen)")
            return raw
        raw = await self._run(agent_id, work)
        self.cache[key] = raw
        while len(self.cache) > 40 or sum(len(v) for v in self.cache.values()) > 80 * 1024 * 1024:
            self.cache.popitem(last=False)
        return raw

    async def attachment(self, agent: AgentMapping, folder: str, uid: int, idx: int) -> tuple[str, str, bytes]:
        raw = await self._raw(agent.id, folder, uid)
        try:
            return mm.attachment(raw, idx)
        except IndexError as exc:
            raise MailUserError("attachment not found", 404) from exc

    async def flags(self, agent: AgentMapping, folder: str, uids: list[int], seen: bool | None = None, flagged: bool | None = None) -> dict:
        if self.pop3:
            await self._local_flags(agent.id, uids, seen, flagged)
            return {"ok": True}

        def work(b: Imap):
            b.select(folder)
            s = ",".join(map(str, uids))
            if seen is not None:
                b.conn.uid("STORE", s, ("+" if seen else "-") + "FLAGS.SILENT", "(\\Seen)")
            if flagged is not None:
                b.conn.uid("STORE", s, ("+" if flagged else "-") + "FLAGS.SILENT", "(\\Flagged)")
            return True
        await self._run(agent.id, work)
        await self._check_inbox(agent.id, notify=False)
        return {"ok": True}

    async def move(self, agent: AgentMapping, folder: str, uids: list[int], target: str) -> dict:
        if self.pop3:
            await self._local_move(agent.id, uids, target)
            return {"ok": True}

        def work(b: Imap):
            b.select(folder)
            s = ",".join(map(str, uids))
            if "MOVE" in b.caps:
                typ, data = b.conn.uid("MOVE", s, quote(target))
                if typ != "OK":
                    raise MailError(f"move: {data}")
            else:
                b.conn.uid("COPY", s, quote(target))
                b.conn.uid("STORE", s, "+FLAGS.SILENT", "(\\Deleted)")
                b.conn.expunge()
            return True
        await self._run(agent.id, work)
        for u in uids:
            self.cache.pop((agent.id, folder, u), None)
        await self._check_inbox(agent.id, notify=False)
        return {"ok": True}

    async def delete(self, agent: AgentMapping, folder: str, uids: list[int]) -> dict:
        """Into Trash; in Trash itself — deleted for good."""
        if self.pop3:
            if folder == "Trash":
                async with self.sv.db.sessionmaker() as s:
                    await s.execute(delete(MailLocal).where(MailLocal.agent_id == agent.id, MailLocal.id.in_(uids)))
                    await s.commit()
            else:
                await self._local_move(agent.id, uids, "Trash")
            return {"ok": True}
        trash = await self._run(agent.id, lambda b: b.ensure_folder("trash", "Trash"))
        if folder == trash:
            def work(b: Imap):
                b.select(folder)
                b.conn.uid("STORE", ",".join(map(str, uids)), "+FLAGS.SILENT", "(\\Deleted)")
                b.conn.expunge()
                return True
            await self._run(agent.id, work)
            return {"ok": True}
        return await self.move(agent, folder, uids, trash)

    # ------------------------------------------------------------------ writing
    async def send(self, agent: AgentMapping, data: dict, draft: bool = False) -> dict:
        email, login, pw = await self._creds(agent.id)
        to = _addr_list(data.get("to"))
        cc = _addr_list(data.get("cc"))
        bcc = _addr_list(data.get("bcc"))
        if not draft and not (to or cc or bcc):
            raise MailUserError("no recipient", 422)
        for a in to + cc + bcc:
            if not EMAIL_RE.match(a["email"]):
                raise MailUserError(f"invalid address: {a['email']}", 422)
        limit = self.cfg.mail_max_attach_mb * 1024 * 1024
        files, total = [], 0
        for f in data.get("files") or []:
            try:
                raw = base64.b64decode(f.get("data") or "", validate=True)
            except ValueError as exc:
                raise MailUserError("bad attachment", 422) from exc
            total += len(raw)
            files.append((str(f.get("name") or "file")[:200], str(f.get("mime") or "application/octet-stream"), raw))
        for fw in data.get("forward_files") or []:  # attachments of the original message (Forward)
            name, mime, raw = await self.attachment(agent, fw["folder"], int(fw["uid"]), int(fw["idx"]))
            total += len(raw)
            files.append((name, mime, raw))
        if total > limit:
            raise MailUserError(f"attachments > {self.cfg.mail_max_attach_mb} MB", 413)
        msg = mm.build(agent.display_name or "", email, to, cc, bcc, str(data.get("subject") or ""), str(data.get("text") or ""), files,
                       str(data.get("in_reply_to") or ""), str(data.get("references") or ""), draft=draft)
        raw = msg.as_bytes()
        old_draft = data.get("draft_uid")
        if not draft:
            server = self.server()
            try:
                await asyncio.to_thread(smtp_send, server, login, pw, msg, [a["email"] for a in to + cc + bcc])
            except MailError as exc:
                raise MailUserError(str(exc), 422 if exc.auth else 502) from exc
            async with self.sv.db.sessionmaker() as s:
                audit(s, "mail_sent", agent_id=agent.id, actor_type="agent", actor_id=agent.id, to=len(to + cc + bcc), size=len(raw))
                await s.commit()
        if self.pop3:
            await self._local_store(agent.id, "Drafts" if draft else "Sent", raw, seen=True)
            if old_draft:
                async with self.sv.db.sessionmaker() as s:
                    await s.execute(delete(MailLocal).where(MailLocal.agent_id == agent.id, MailLocal.id == int(old_draft)))
                    await s.commit()
            return {"ok": True}
        if draft or self.cfg.mail_save_sent:
            def work(b: Imap):
                folder = b.ensure_folder("drafts", "Drafts") if draft else b.ensure_folder("sent", "Sent")
                flags = "(\\Seen \\Draft)" if draft else "(\\Seen)"
                b.conn.append(quote(folder), flags, imaplib.Time2Internaldate(time.time()), raw)
                if old_draft:
                    dr = b.role("drafts")
                    if dr:
                        b.select(dr)
                        b.conn.uid("STORE", str(int(old_draft)), "+FLAGS.SILENT", "(\\Deleted)")
                        b.conn.expunge()
                return folder
            try:
                await self._run(agent.id, work)
            except MailUserError as exc:
                if draft:
                    raise
                log.warning("sent mail could not be stored in Sent: %s", exc)  # the mail itself went out
        return {"ok": True}

    async def ticket_from_mail(self, agent: AgentMapping, folder: str, uid: int) -> dict:
        """Create a Zammad ticket from an e-mail: customer by the sender's address (found or created), the text and files."""
        raw = await self._raw(agent.id, folder, uid)
        msg = mm.parse(raw)
        v = mm.view(raw, lambda c: "", lambda i: "")
        sender = (v["reply_to"] or v["from"] or [{"name": "", "email": ""}])[0]
        z = self.sv.zammad
        cust = None
        if sender.get("email"):
            for u in await z.search_users(sender["email"]):
                if (u.get("email") or "").lower() == sender["email"].lower():
                    cust = u
                    break
            if cust is None:
                first, _, last = (sender.get("name") or "").partition(" ")
                cust = await z.create_user({"email": sender["email"], "firstname": first or sender["email"].split("@")[0], "lastname": last, "roles": ["Customer"]})
                try:
                    await self.sv.directory.upsert_one({"roles": ["Customer"], **cust})
                except Exception:  # noqa: BLE001
                    pass
        atts = []
        for i, part in enumerate(mm.walk_attachments(msg)):
            data = part.get_payload(decode=True) or b""
            atts.append({"filename": mm.header_text(part.get_filename()) or f"file-{i + 1}", "data": base64.b64encode(data).decode(),
                         "mime-type": part.get_content_type()})
        body = (v["text"] or "").strip() or "(no text)"
        article = {"subject": v["subject"] or "(no subject)", "body": body[:100000], "type": "email", "internal": False,
                   "sender": "Customer", "content_type": "text/plain", "from": mm.fmt_addresses([sender])}
        if atts:
            article["attachments"] = atts
        payload = {"title": v["subject"] or "(no subject)", "group": self.cfg.zammad_default_group, "customer_id": (cust or {}).get("id"),
                   "article": article}
        if agent.zammad_user_id:
            payload["owner_id"] = agent.zammad_user_id
        ticket = await self.sv.desk.create(agent, payload)
        return {"ticket_id": ticket.get("id"), "number": ticket.get("number")}

    # ------------------------------------------------------------------ real time (IMAP IDLE) and checks
    async def presence(self, agent_id: int, connections: int) -> None:
        """Somebody opened / closed Zenith Desk: keep an IDLE connection only while he is online."""
        if connections > 0:
            if agent_id in self.idle or not self.enabled() or self.pop3 or not self.cfg.mail_idle:
                return
            try:
                _, login, pw = await self._creds(agent_id)
            except MailUserError:
                return
            stop = threading.Event()
            loop = self._loop or asyncio.get_running_loop()

            def on_change():
                if not loop.is_closed() and not stop.is_set():
                    try:
                        loop.call_soon_threadsafe(lambda: self._spawn(self._check_inbox(agent_id, notify=True, source="idle")))
                    except RuntimeError:  # the loop closed meanwhile (shutdown)
                        pass

            def on_state(ok: bool, detail: str):
                if stop.is_set() or loop.is_closed():
                    return
                self.idle_state[agent_id] = (ok, detail)
                try:
                    loop.call_soon_threadsafe(self._update_realtime)
                    if detail:
                        loop.call_soon_threadsafe(self.sv.hub.error, "mail", detail)
                except RuntimeError:
                    pass

            t = threading.Thread(target=imap_idle_wait, args=(self.server(), login, pw, stop, on_change, on_state), daemon=True,
                                 name=f"imap-idle-{agent_id}")
            self.idle[agent_id] = (t, stop)
            t.start()
        else:
            self._stop_idle(agent_id)

    def _stop_idle(self, agent_id: int) -> None:
        it = self.idle.pop(agent_id, None)
        if it:
            it[1].set()
        self.idle_state.pop(agent_id, None)
        self._update_realtime()

    async def _check_inbox(self, agent_id: int, notify: bool, source: str = "check") -> int:
        """Looks at INBOX (UIDNEXT / UNSEEN). Returns how many new messages arrived since the last look."""
        if self.pop3:
            return await self._pop3_sync(agent_id, notify)

        def work(b: Imap):
            st = b.status("INBOX")
            return st
        try:
            st = await self._run(agent_id, work)
        except MailUserError:
            return 0
        new_uids = []
        async with self.sv.db.sessionmaker() as s:
            acc = await s.get(MailAccount, agent_id)
            if acc is None:
                return 0
            first = acc.uidnext == 0 or acc.uidvalidity != st.get("uidvalidity", 0)
            if not first and st.get("uidnext", 0) > acc.uidnext:
                new_uids = list(range(acc.uidnext, st["uidnext"]))
            acc.uidnext, acc.uidvalidity, acc.unseen = st.get("uidnext", 0), st.get("uidvalidity", 0), st.get("unseen", 0)
            acc.last_check_at, acc.status, acc.last_error = utcnow(), "ok", ""
            await s.commit()
        self.sv.hub.event("mail") if source == "idle" else None
        if new_uids and notify:
            await self._announce(agent_id, new_uids, st.get("unseen", 0))
        self.sv.broker.publish_agent(agent_id, "mail", {"unseen": st.get("unseen", 0), "new": len(new_uids)})
        return len(new_uids)

    async def _announce(self, agent_id: int, uids: list[int], unseen: int) -> None:
        try:
            page = await self._run(agent_id, lambda b: _headers(b, "INBOX", uids[-5:]))
        except MailUserError:
            page = []
        latest = page[0] if page else {}
        frm = (latest.get("from") or [{}])[0] if latest else {}
        payload = {"unseen": unseen, "new": len(uids), "from": frm.get("name") or frm.get("email", ""), "subject": latest.get("subject", ""),
                   "uid": latest.get("uid")}
        self.sv.broker.publish_agent(agent_id, "mail_new", payload)
        self.sv.push.notify_later(agent_id, {"type": "mail", "title": payload["from"] or "E-mail", "body": payload["subject"]})

    async def fallback(self) -> int:
        """Every few minutes: new mail that the real-time channel did not announce (or POP3 mailboxes)."""
        async with self.sv.db.sessionmaker() as s:
            ids = (await s.execute(select(MailAccount.agent_id))).scalars().all()
        recovered = 0
        for agent_id in ids:
            if self.pop3:
                recovered += await self._pop3_sync(agent_id, notify=True)
            else:
                recovered += await self._check_inbox(agent_id, notify=True, source="fallback")
        self._update_realtime()
        return recovered

    async def _housekeeping(self) -> None:
        while True:
            await asyncio.sleep(120)
            idle_limit = time.time() - 600
            for agent_id, b in list(self.boxes.items()):   # close connections nobody used for 10 minutes
                if b.used < idle_limit:
                    self.boxes.pop(agent_id, None)
                    await asyncio.to_thread(b.close)
            if self.enabled() and self.pop3:  # POP3 has no push: check online people every 2 minutes
                for agent_id in list(self.sv.broker.online_agents()):
                    try:
                        await self._pop3_sync(agent_id, notify=True)
                    except Exception:  # noqa: BLE001
                        pass

    # ------------------------------------------------------------------ POP3: local folders
    def _decrypt(self, stored: str) -> bytes:
        text = self.sv.cipher.open(stored)
        return base64.b64decode(text) if text else b""

    async def _local_store(self, agent_id: int, folder: str, raw: bytes, uidl: str | None = None, seen: bool = False) -> int:
        msg = mm.parse(raw)
        text, html = mm.body_parts(msg)
        frm = mm.header_text(msg["From"])
        date = mm.parse_date(msg["Date"])
        async with self.sv.db.sessionmaker() as s:
            row = MailLocal(agent_id=agent_id, uidl=uidl or f"local-{time.time_ns()}", folder=folder,
                            raw=self.sv.cipher.seal(base64.b64encode(raw).decode()), sender=frm[:500],
                            recipients=mm.header_text(msg["To"])[:5000], subject=mm.header_text(msg["Subject"])[:1000],
                            snippet=mm.snippet(text, html, 280), date=datetime.fromisoformat(date) if date else utcnow(), size=len(raw),
                            seen=seen, flagged=False, has_files=bool(mm.walk_attachments(msg)))
            s.add(row)
            await s.commit()
            return row.id

    async def _pop3_sync(self, agent_id: int, notify: bool = False) -> int:
        try:
            _, login, pw = await self._creds(agent_id)
        except MailUserError:
            return 0
        async with self.sv.db.sessionmaker() as s:
            known = set((await s.execute(select(MailLocal.uidl).where(MailLocal.agent_id == agent_id))).scalars().all())
        try:
            new = await asyncio.to_thread(pop3_fetch_new, self.server(), login, pw, known)
        except MailError as exc:
            await self._set_status(agent_id, str(exc))
            self.sv.hub.error("mail", str(exc))
            return 0
        for uidl, raw in new:
            await self._local_store(agent_id, "INBOX", raw, uidl)
        async with self.sv.db.sessionmaker() as s:
            unseen = (await s.execute(select(func.count()).select_from(MailLocal).where(MailLocal.agent_id == agent_id, MailLocal.folder == "INBOX",
                                                                                         MailLocal.seen.is_(False)))).scalar()
            acc = await s.get(MailAccount, agent_id)
            if acc:
                acc.unseen, acc.last_check_at, acc.status, acc.last_error = unseen, utcnow(), "ok", ""
            await s.commit()
        if new and notify:
            m = mm.parse(new[-1][1])
            frm = (mm.addresses(m["From"]) or [{}])[0]
            payload = {"unseen": unseen, "new": len(new), "from": frm.get("name") or frm.get("email", ""), "subject": mm.header_text(m["Subject"])}
            self.sv.broker.publish_agent(agent_id, "mail_new", payload)
            self.sv.push.notify_later(agent_id, {"type": "mail", "title": payload["from"] or "E-mail", "body": payload["subject"]})
        if new:
            self.sv.broker.publish_agent(agent_id, "mail", {"unseen": unseen, "new": len(new)})
        return len(new)

    async def _local_folders(self, agent_id: int) -> list[dict]:
        async with self.sv.db.sessionmaker() as s:
            rows = (await s.execute(select(MailLocal.folder, func.count()).where(MailLocal.agent_id == agent_id)
                                    .group_by(MailLocal.folder))).all()
            unseen = dict((await s.execute(select(MailLocal.folder, func.count()).where(MailLocal.agent_id == agent_id, MailLocal.seen.is_(False))
                                           .group_by(MailLocal.folder))).all())
        totals = {r[0]: r[1] for r in rows}
        return [{"name": n, "display": n, "role": r, "unseen": unseen.get(n, 0), "total": totals.get(n, 0), "delim": "/"} for n, r in LOCAL_FOLDERS]

    async def _local_list(self, agent_id: int, folder: str, page: int, q: str, size: int) -> dict:
        async with self.sv.db.sessionmaker() as s:
            stmt = select(MailLocal).where(MailLocal.agent_id == agent_id, MailLocal.folder == folder)
            if q.strip():
                like = f"%{q.strip().lower()}%"
                stmt = stmt.where(func.lower(MailLocal.subject).like(like) | func.lower(MailLocal.sender).like(like) | func.lower(MailLocal.snippet).like(like))
            total = (await s.execute(select(func.count()).select_from(stmt.subquery()))).scalar()
            rows = (await s.execute(stmt.order_by(MailLocal.date.desc()).offset((page - 1) * size).limit(size))).scalars().all()
        items = [{"uid": r.id, "from": mm.addresses(r.sender), "to": mm.addresses(r.recipients), "subject": r.subject, "date": as_utc(r.date).isoformat(),
                  "seen": r.seen, "flagged": r.flagged, "answered": False, "has_files": r.has_files, "size": r.size, "snippet": r.snippet} for r in rows]
        return {"items": items, "total": total, "page": page, "size": size, "folder": folder}

    async def _local_row(self, agent_id: int, uid: int) -> MailLocal | None:
        async with self.sv.db.sessionmaker() as s:
            r = await s.get(MailLocal, uid)
            return r if r and r.agent_id == agent_id else None

    async def _local_flags(self, agent_id: int, uids: list[int], seen: bool | None = None, flagged: bool | None = None) -> None:
        async with self.sv.db.sessionmaker() as s:
            for r in (await s.execute(select(MailLocal).where(MailLocal.agent_id == agent_id, MailLocal.id.in_(uids)))).scalars().all():
                if seen is not None:
                    r.seen = seen
                if flagged is not None:
                    r.flagged = flagged
            await s.commit()

    async def _local_move(self, agent_id: int, uids: list[int], target: str) -> None:
        if target not in dict(LOCAL_FOLDERS):
            raise MailUserError("unknown folder", 422)
        async with self.sv.db.sessionmaker() as s:
            for r in (await s.execute(select(MailLocal).where(MailLocal.agent_id == agent_id, MailLocal.id.in_(uids)))).scalars().all():
                r.folder = target
            await s.commit()

    # ------------------------------------------------------------------ administrator's test
    async def test(self, values: dict) -> dict:
        server = self.server({k: v for k, v in values.items() if v not in (None, "") and k.startswith("mail_")})
        if not server.host or not server.smtp_host:
            return {"ok": False, "detail": "incoming and outgoing servers are required"}
        r = await asyncio.to_thread(probe, server)
        detail = ("✔ " if r["incoming"]["ok"] else "✖ ") + r["incoming"]["detail"] + "  ·  " + ("✔ " if r["smtp"]["ok"] else "✖ ") + r["smtp"]["detail"]
        login, pw = values.get("test_email"), values.get("test_password")
        if r["ok"] and login and pw:
            try:
                email = self.normalize_email(login)
                lg = email.split("@")[0] if (values.get("mail_login_format") or self.cfg.mail_login_format) == "local" else email

                def check():
                    if server.protocol == "pop3":
                        pop3_open(server, lg, pw).quit()
                    else:
                        Imap(server, lg, pw).open().logout()
                    if server.smtp_auth:
                        smtp_open(server, lg, pw).quit()
                await asyncio.to_thread(check)
                detail += f"  ·  ✔ {email}: sign-in OK"
            except (MailError, MailUserError) as exc:
                r["ok"] = False
                detail += f"  ·  ✖ {login}: {exc}"
        return {"ok": r["ok"], "detail": detail}


# ---------------------------------------------------------------------- helpers
def quote(name: str) -> str:
    from .proto import quote_mailbox
    return quote_mailbox(name)


def folder_url(folder: str) -> str:
    return base64.urlsafe_b64encode(folder.encode()).decode().rstrip("=")


def folder_from_url(token: str) -> str:
    try:
        return base64.urlsafe_b64decode(token + "=" * (-len(token) % 4)).decode()
    except Exception as exc:  # noqa: BLE001
        raise MailUserError("bad folder", 400) from exc


def _addr_list(value) -> list[dict]:
    if not value:
        return []
    if isinstance(value, str):
        return [a for a in mm.addresses(value) if a["email"]]
    out = []
    for a in value:
        if isinstance(a, dict) and a.get("email"):
            out.append({"name": str(a.get("name") or ""), "email": str(a["email"]).strip()})
        elif isinstance(a, str):
            out += [x for x in mm.addresses(a) if x["email"]]
    return out


def _parse_fetch(resp) -> list[dict]:
    """UID FETCH answer → list rows. The literal (headers) is in the tuple; BODYSTRUCTURE may come before or after it."""
    items, cur = [], None
    for part in resp or []:
        if isinstance(part, tuple):
            if cur:
                items.append(cur)
            cur = {"meta": part[0].decode("utf-8", "replace"), "hdr": part[1]}
        elif isinstance(part, bytes) and cur is not None:
            cur["meta"] += part.decode("utf-8", "replace")
    if cur:
        items.append(cur)
    out = []
    for it in items:
        meta = it["meta"]
        uid = re.search(r"UID (\d+)", meta)
        if not uid:
            continue
        flags = (re.search(r"FLAGS \(([^)]*)\)", meta) or [None, ""])[1]
        idate = re.search(r'INTERNALDATE "([^"]+)"', meta)
        size = re.search(r"RFC822\.SIZE (\d+)", meta)
        h = mm.parse(it["hdr"] or b"")
        date = mm.parse_date(h["Date"])
        if not date and idate:
            try:
                date = datetime.strptime(idate.group(1), "%d-%b-%Y %H:%M:%S %z").astimezone(timezone.utc).isoformat()
            except ValueError:
                date = ""
        out.append({"uid": int(uid.group(1)), "from": mm.addresses(h["From"]), "to": mm.addresses(h["To"]), "subject": mm.header_text(h["Subject"]),
                    "date": date, "seen": "\\Seen" in flags, "flagged": "\\Flagged" in flags, "answered": "\\Answered" in flags,
                    "has_files": bool(re.search(r'"attachment"', meta, re.I)), "size": int(size.group(1)) if size else 0})
    return out


def _headers(b: Imap, folder: str, uids: list[int]) -> list[dict]:
    b.select(folder, readonly=True)
    typ, resp = b.conn.uid("FETCH", ",".join(map(str, uids)), "(UID FLAGS RFC822.SIZE BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
    rows = _parse_fetch(resp)
    rows.sort(key=lambda r: r["uid"], reverse=True)
    return rows
