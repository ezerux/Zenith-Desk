"""Talking to the company mail server (IMAP / POP3 / SMTP). Synchronous standard-library clients, run in threads."""
from __future__ import annotations

import imaplib
import poplib
import re
import select
import smtplib
import socket
import ssl
import threading
import time
from dataclasses import dataclass

TIMEOUT = 20


class MailError(Exception):
    def __init__(self, message: str, auth: bool = False):
        super().__init__(message)
        self.auth = auth


@dataclass
class Server:
    protocol: str            # imap | pop3
    host: str
    port: int
    security: str            # ssl | starttls | none
    smtp_host: str
    smtp_port: int
    smtp_security: str
    smtp_auth: bool
    verify: bool

    def ctx(self) -> ssl.SSLContext:
        c = ssl.create_default_context()
        if not self.verify:
            c.check_hostname = False
            c.verify_mode = ssl.CERT_NONE
        return c


def explain(exc: Exception) -> str:
    if isinstance(exc, MailError):
        return str(exc)
    if isinstance(exc, ssl.SSLCertVerificationError):
        return f"certificate: {exc.verify_message}"
    if isinstance(exc, ssl.SSLError):
        return f"TLS: {exc.reason or exc}"
    if isinstance(exc, socket.gaierror):
        return "server name not found"
    if isinstance(exc, ConnectionRefusedError):
        return "connection refused (port closed)"
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return "no answer (timeout)"
    return f"{type(exc).__name__}: {exc}"


# ------------------------------------------------------------------ IMAP modified UTF-7 (RFC 3501 5.1.3)
def utf7_decode(s: str) -> str:
    out, i = [], 0
    while i < len(s):
        if s[i] == "&":
            j = s.index("-", i)
            if j == i + 1:
                out.append("&")
            else:
                import base64
                b = s[i + 1:j].replace(",", "/")
                b += "=" * (-len(b) % 4)
                out.append(base64.b64decode(b).decode("utf-16-be"))
            i = j + 1
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def quote_mailbox(name: str) -> str:
    return '"' + name.replace("\\", "\\\\").replace('"', '\\"') + '"'


LIST_RE = re.compile(r'\((?P<flags>[^)]*)\) (?P<delim>"[^"]*"|NIL) (?P<name>.+)')
ROLE_FLAGS = {"\\sent": "sent", "\\drafts": "drafts", "\\trash": "trash", "\\junk": "junk", "\\archive": "archive"}
ROLE_NAMES = {
    "sent": ("sent", "sent items", "sent messages", "отправленные", "inbox.sent", "[gmail]/sent mail"),
    "drafts": ("drafts", "черновики", "inbox.drafts", "[gmail]/drafts"),
    "trash": ("trash", "deleted", "deleted items", "deleted messages", "корзина", "удаленные", "удалённые", "inbox.trash", "[gmail]/trash", "[gmail]/bin"),
    "junk": ("junk", "spam", "junk e-mail", "спам", "inbox.junk", "inbox.spam", "[gmail]/spam"),
    "archive": ("archive", "архив", "[gmail]/all mail"),
}


class Imap:
    """One logged-in IMAP connection of one employee, shared by his requests (a lock keeps it single-threaded)."""

    def __init__(self, server: Server, login: str, password: str):
        self.server, self.login_name, self.password = server, login, password
        self.lock = threading.RLock()
        self.conn: imaplib.IMAP4 | None = None
        self.selected: tuple[str, bool] | None = None
        self.caps: set[str] = set()
        self.used = 0.0
        self._folders: list[dict] | None = None
        self._folders_at = 0.0

    def open(self) -> imaplib.IMAP4:
        s = self.server
        try:
            if s.security == "ssl":
                c = imaplib.IMAP4_SSL(s.host, s.port, ssl_context=s.ctx(), timeout=TIMEOUT)
            else:
                c = imaplib.IMAP4(s.host, s.port, timeout=TIMEOUT)
                if s.security == "starttls":
                    c.starttls(ssl_context=s.ctx())
        except Exception as exc:  # noqa: BLE001
            raise MailError(explain(exc)) from exc
        try:
            c.login(self.login_name, self.password)
        except imaplib.IMAP4.error as exc:
            try:
                c.logout()
            except Exception:  # noqa: BLE001
                pass
            raise MailError("wrong e-mail or password", auth=True) from exc
        self.caps = {x.upper() for x in c.capabilities}
        return c

    def close(self) -> None:
        with self.lock:
            if self.conn is not None:
                try:
                    self.conn.logout()
                except Exception:  # noqa: BLE001
                    pass
            self.conn, self.selected = None, None

    def run(self, fn):
        """fn(conn) with one reconnect if the server dropped the connection meanwhile."""
        with self.lock:
            for attempt in (1, 2):
                try:
                    if self.conn is None:
                        self.conn = self.open()
                        self.selected = None
                    self.used = time.time()
                    return fn(self)
                except MailError:
                    raise
                except (imaplib.IMAP4.abort, OSError, EOFError) as exc:
                    self.conn, self.selected = None, None
                    if attempt == 2:
                        raise MailError(explain(exc)) from exc
                except imaplib.IMAP4.error as exc:
                    raise MailError(f"IMAP: {exc}") from exc

    # ---- helpers used inside run()
    def select(self, folder: str, readonly: bool = False) -> int:
        typ, data = self.conn.select(quote_mailbox(folder), readonly=readonly)
        if typ != "OK":
            raise MailError(f"folder {folder}: {data[0].decode(errors='replace') if data and data[0] else typ}")
        self.selected = (folder, readonly)
        return int(data[0] or 0)

    def folders(self, refresh: bool = False) -> list[dict]:
        if self._folders is not None and not refresh and time.time() - self._folders_at < 300:
            return self._folders
        typ, data = self.conn.list()
        out = []
        for raw in data or []:
            if not raw:
                continue
            line = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else str(raw)
            m = LIST_RE.match(line)
            if not m:
                continue
            flags = m.group("flags").lower().split()
            if "\\noselect" in flags or "\\nonexistent" in flags:
                continue
            name = m.group("name").strip()
            if name.startswith('"') and name.endswith('"'):
                name = name[1:-1].replace('\\"', '"').replace("\\\\", "\\")
            role = "inbox" if name.upper() == "INBOX" else next((ROLE_FLAGS[f] for f in flags if f in ROLE_FLAGS), "")
            out.append({"name": name, "display": utf7_decode(name), "role": role, "delim": m.group("delim").strip('"')})
        for f in out:  # servers without SPECIAL-USE: guess by the usual names
            if not f["role"]:
                low = f["display"].lower()
                f["role"] = next((r for r, names in ROLE_NAMES.items() if low in names and not any(x["role"] == r for x in out)), "other")
        order = {"inbox": 0, "drafts": 1, "sent": 2, "junk": 3, "trash": 4, "archive": 5, "other": 6}
        out.sort(key=lambda f: (order.get(f["role"], 9), f["display"].lower()))
        self._folders, self._folders_at = out, time.time()
        return out

    def role(self, role: str) -> str | None:
        for f in self.folders():
            if f["role"] == role:
                return f["name"]
        return None

    def ensure_folder(self, role: str, default: str) -> str:
        name = self.role(role)
        if name:
            return name
        self.conn.create(quote_mailbox(default))
        self._folders = None
        return default

    def status(self, folder: str) -> dict:
        if self.selected and self.selected[0] == folder:
            # STATUS of the selected mailbox may return the numbers of when it was selected: leave it first
            try:
                self.conn.unselect() if "UNSELECT" in self.caps else self.conn.noop()  # never CLOSE: it would expunge
            except imaplib.IMAP4.error:
                pass
            self.selected = None
        typ, data = self.conn.status(quote_mailbox(folder), "(MESSAGES UNSEEN UIDNEXT UIDVALIDITY)")
        out = {}
        if typ == "OK" and data and data[0]:
            line = data[0].decode() if isinstance(data[0], bytes) else str(data[0])
            for k, v in re.findall(r"(MESSAGES|UNSEEN|UIDNEXT|UIDVALIDITY) (\d+)", line):
                out[k.lower()] = int(v)
        return out


class _IdleReader:
    """Line reader on the raw socket for the IDLE phase.

    imaplib's buffered file must never see a socket timeout: after one, every later read fails with
    "cannot read from timed out object". So while idling we wait with select() (1 s steps, to notice `stop`)
    and read the socket ourselves.
    """

    def __init__(self, sock: socket.socket):
        self.sock, self.buf = sock, b""

    def _ready(self, timeout: float) -> bool:
        if isinstance(self.sock, ssl.SSLSocket) and self.sock.pending():
            return True
        return bool(select.select([self.sock], [], [], timeout)[0])

    def readline(self, timeout: float) -> bytes | None:
        """A full line, b"" when the server closed the connection, None when nothing came within `timeout`."""
        end = time.monotonic() + timeout
        while b"\r\n" not in self.buf:
            left = end - time.monotonic()
            if left <= 0 or not self._ready(min(left, 1.0)):
                if left <= 0:
                    return None
                continue
            try:
                data = self.sock.recv(65536)
            except (ssl.SSLWantReadError, BlockingIOError):
                continue  # only part of a TLS record arrived
            if not data:
                return b""
            self.buf += data
        line, self.buf = self.buf.split(b"\r\n", 1)
        return line + b"\r\n"


def imap_idle_wait(server: Server, login: str, password: str, stop: threading.Event, on_change, on_state) -> None:
    """IMAP IDLE (RFC 2177) on INBOX: on_change() whenever the server announces new mail; reconnects by itself.
    IDLE is renewed every 25 minutes (servers drop it after 30)."""
    delay = 5
    while not stop.is_set():
        conn = None
        try:
            box = Imap(server, login, password)
            conn = box.open()
            if "IDLE" not in box.caps:
                on_state(False, "server has no IDLE")
                return
            conn.select("INBOX", readonly=True)
            on_state(True, "")
            delay = 5
            reader = _IdleReader(conn.sock)
            while not stop.is_set():
                tag = conn._new_tag().decode()
                conn.send(f"{tag} IDLE\r\n".encode())
                line = reader.readline(TIMEOUT)
                if not line or not line.startswith(b"+"):
                    raise MailError(f"IDLE refused: {line!r}")
                started, changed = time.monotonic(), False
                while not stop.is_set() and time.monotonic() - started < 25 * 60:
                    line = reader.readline(1.0)
                    if line is None:
                        continue  # nothing yet — look at `stop` again
                    if not line:
                        raise EOFError("connection closed by the server")
                    if re.match(rb"\* \d+ (EXISTS|RECENT)", line):
                        changed = True
                        break
                conn.send(b"DONE\r\n")
                while True:  # read up to the tagged OK of IDLE
                    line = reader.readline(TIMEOUT)
                    if line is None:
                        raise TimeoutError("no answer to DONE")
                    if not line or line.startswith(tag.encode()):
                        break
                if changed:
                    on_change()
        except Exception as exc:  # noqa: BLE001
            on_state(False, explain(exc))
            if isinstance(exc, MailError) and exc.auth:
                return
        finally:
            if conn is not None:
                try:
                    conn.shutdown()  # no LOGOUT round trip: the reader may own unread bytes
                except Exception:  # noqa: BLE001
                    pass
        stop.wait(delay)
        delay = min(delay * 2, 300)


# ------------------------------------------------------------------ POP3
def pop3_open(server: Server, login: str, password: str) -> poplib.POP3:
    try:
        if server.security == "ssl":
            p = poplib.POP3_SSL(server.host, server.port, context=server.ctx(), timeout=TIMEOUT)
        else:
            p = poplib.POP3(server.host, server.port, timeout=TIMEOUT)
            if server.security == "starttls":
                p.stls(context=server.ctx())
    except Exception as exc:  # noqa: BLE001
        raise MailError(explain(exc)) from exc
    try:
        p.user(login)
        p.pass_(password)
    except poplib.error_proto as exc:
        try:
            p.quit()
        except Exception:  # noqa: BLE001
            pass
        raise MailError("wrong e-mail or password", auth=True) from exc
    return p


def pop3_fetch_new(server: Server, login: str, password: str, known: set[str], limit: int = 200) -> list[tuple[str, bytes]]:
    p = pop3_open(server, login, password)
    try:
        _, items, _ = p.uidl()
        out = []
        # v3.10: newest first — a big mailbox must not hide today's mail behind hundreds of old messages
        # (the older ones are downloaded by the next checks); returned oldest → newest
        for it in reversed(items):
            num, uid = it.decode().split(" ", 1)
            if uid in known:
                continue
            _, lines, _ = p.retr(int(num))
            out.append((uid, b"\r\n".join(lines) + b"\r\n"))
            if len(out) >= limit:
                break
        return list(reversed(out))
    finally:
        try:
            p.quit()
        except Exception:  # noqa: BLE001
            pass


# ------------------------------------------------------------------ SMTP
def smtp_open(server: Server, login: str | None, password: str | None) -> smtplib.SMTP:
    try:
        if server.smtp_security == "ssl":
            c = smtplib.SMTP_SSL(server.smtp_host, server.smtp_port, context=server.ctx(), timeout=TIMEOUT)
        else:
            c = smtplib.SMTP(server.smtp_host, server.smtp_port, timeout=TIMEOUT)
            c.ehlo()
            if server.smtp_security == "starttls":
                c.starttls(context=server.ctx())
                c.ehlo()
    except Exception as exc:  # noqa: BLE001
        raise MailError("SMTP: " + explain(exc)) from exc
    if server.smtp_auth and login:
        try:
            c.login(login, password or "")
        except smtplib.SMTPAuthenticationError as exc:
            c.close()
            raise MailError("SMTP: wrong e-mail or password", auth=True) from exc
        except smtplib.SMTPException as exc:
            c.close()
            raise MailError(f"SMTP: {exc}") from exc
    return c


def smtp_send(server: Server, login: str, password: str, msg, rcpts: list[str]) -> None:
    c = smtp_open(server, login, password)
    try:
        refused = c.send_message(msg, to_addrs=rcpts)
        if refused:
            raise MailError("not accepted: " + ", ".join(refused))
    except smtplib.SMTPRecipientsRefused as exc:
        raise MailError("not accepted: " + ", ".join(exc.recipients)) from exc
    except smtplib.SMTPSenderRefused as exc:
        raise MailError(f"SMTP refused the sender: {exc.smtp_error.decode(errors='replace')}") from exc
    except smtplib.SMTPException as exc:
        raise MailError(f"SMTP: {exc}") from exc
    finally:
        try:
            c.quit()
        except Exception:  # noqa: BLE001
            pass


def probe(server: Server) -> dict:
    """Administrator's test: can the servers be reached, TLS, what they offer (no user password needed)."""
    out = {}
    try:
        if server.protocol == "imap":
            if server.security == "ssl":
                c = imaplib.IMAP4_SSL(server.host, server.port, ssl_context=server.ctx(), timeout=10)
            else:
                c = imaplib.IMAP4(server.host, server.port, timeout=10)
                if server.security == "starttls":
                    c.starttls(ssl_context=server.ctx())
            caps = sorted(x for x in c.capabilities if x in ("IDLE", "MOVE", "UIDPLUS", "SPECIAL-USE", "IMAP4REV1", "STARTTLS", "AUTH=PLAIN", "AUTH=LOGIN"))
            c.logout()
            out["incoming"] = {"ok": True, "detail": f"IMAP {server.host}:{server.port} ({server.security}) · " + " ".join(caps)}
        else:
            p = poplib.POP3_SSL(server.host, server.port, context=server.ctx(), timeout=10) if server.security == "ssl" else poplib.POP3(server.host, server.port, timeout=10)
            if server.security == "starttls":
                p.stls(context=server.ctx())
            welcome = p.getwelcome().decode(errors="replace")[:80]
            p.quit()
            out["incoming"] = {"ok": True, "detail": f"POP3 {server.host}:{server.port} ({server.security}) · {welcome}"}
    except Exception as exc:  # noqa: BLE001
        out["incoming"] = {"ok": False, "detail": explain(exc)}
    try:
        c = smtp_open(Server(**{**server.__dict__, "smtp_auth": False}), None, None)
        ext = [x for x in ("auth", "starttls", "size", "8bitmime", "smtputf8") if c.has_extn(x)]
        name = c.ehlo_resp.decode(errors="replace").splitlines()[0][:60] if c.ehlo_resp else server.smtp_host
        c.quit()
        out["smtp"] = {"ok": True, "detail": f"SMTP {server.smtp_host}:{server.smtp_port} ({server.smtp_security}) · {name} · {' '.join(ext).upper()}"}
    except Exception as exc:  # noqa: BLE001
        out["smtp"] = {"ok": False, "detail": explain(exc)}
    out["ok"] = out["incoming"]["ok"] and out["smtp"]["ok"]
    return out
