/* Zenith Desk service worker (v3.1): background notifications for new messages.
   It only shows notifications — it does not cache the app, so Zenith Desk always loads its latest version. */
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

self.addEventListener("push", (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { title: "Zenith Desk", body: event.data ? event.data.text() : "" }; }
  const title = data.title || "Zenith Desk";
  const options = {
    body: data.body || "",
    tag: data.type === "chat" ? "agentix-chat-" + data.from : data.type === "ticket" ? "agentix-ticket-" + data.ticket_id : "agentix",
    renotify: true,
    icon: "/static/logo-192.png",
    badge: "/static/logo-192.png",
    data: { from: data.from || null, type: data.type || "", ticket_id: data.ticket_id || null },
  };
  event.waitUntil((async () => {
    // a visible Zenith Desk window already shows the message itself
    const wins = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    if (wins.some((w) => w.visibilityState === "visible")) return;
    await self.registration.showNotification(title, options);
  })());
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const d = event.notification.data || {};
  const from = d.from;
  const ticket = d.type === "ticket" ? d.ticket_id : null;
  const url = from ? "/?chat=" + from : ticket ? "/?ticket=" + ticket : "/";
  event.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const w of wins) {
      if (new URL(w.url).origin === self.location.origin) {
        await w.focus();
        if (from) w.postMessage({ type: "open-chat", from });
        if (ticket) w.postMessage({ type: "open-ticket", ticket });
        return;
      }
    }
    await self.clients.openWindow(url);
  })());
});
