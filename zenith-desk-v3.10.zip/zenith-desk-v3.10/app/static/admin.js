/* Zenith Desk — administrator panel (users, integrations, settings, ticket types, system status). */
window.AgentixAdmin = (() => {
  const i18n = {
    en: {
      "nav.admin": "Administration",
      "nav.users": "Users",
      "nav.integrations": "Integrations (API)",
      "nav.sys_settings": "System settings",
      "nav.types": "Ticket types",
      "nav.system": "System status",
      "nav.backup": "Backup",
      "bk.title": "Backup", "bk.lead": "One file holds the whole system: users, settings and integrations, chats, Telegram and WhatsApp conversations with their files, mail, calls and the audit log. With this file and its password Zenith Desk can be restored here or on a new server.",
      "bk.create": "Create backup now", "bk.upload": "Upload a backup file", "bk.uploading": "Uploading… {p}%",
      "bk.last": "Last backup", "bk.next": "Next automatic", "bk.off": "off", "bk.never": "never", "bk.disk": "Free disk space",
      "bk.failed": "Last failure", "bk.no_pw_banner": "Set the backup password first — every backup file is encrypted with it.",
      "bk.settings": "Automatic backups", "bk.enabled": "Make backups automatically", "bk.frequency": "How often", "bk.daily": "Every day", "bk.weekly": "Every week",
      "bk.time": "At", "bk.weekday": "Day", "bk.keep": "Keep the last N automatic copies",
      "bk.password": "Backup password", "bk.password_saved": "•••••• saved — type to replace", "bk.password_none": "not set — at least 8 characters",
      "bk.password_hint": "Encrypts every file (AES-256). Without it a backup cannot be restored: keep it in a safe place, not only on this server.",
      "bk.tz": "Time zone: {tz}", "bk.save": "Save", "bk.saved": "Backup settings saved",
      "bk.files": "Backup files", "bk.empty": "No backups yet", "bk.folder": "Folder on the server: {f}",
      "bk.col.date": "Date", "bk.col.kind": "Type", "bk.col.size": "Size", "bk.col.version": "Version", "bk.col.by": "Created by",
      "bk.kind.manual": "Manual", "bk.kind.scheduled": "Automatic", "bk.kind.pre-restore": "Before restore", "bk.kind.uploaded": "Uploaded", "bk.kind.cli": "Command line", "bk.kind.unknown": "Unreadable",
      "bk.download": "Download", "bk.verify": "Check", "bk.restore": "Restore", "bk.delete": "Delete",
      "bk.confirm_delete": "Delete the backup {name}?", "bk.deleted": "Backup deleted",
      "bk.running.backup": "Creating the backup…", "bk.running.restore": "Restoring the system — do not close this page…", "bk.running.verify": "Checking the file…",
      "bk.done.backup": "Backup created", "bk.done.upload": "File uploaded — choose “Restore” to bring the system back from it",
      "bk.verify_title": "Check the backup", "bk.verify_ok": "The file is complete and the password is right: {rows} rows, Zenith Desk {version}.",
      "bk.restore_title": "Restore the whole system", "bk.restore_warn": "ALL current data of Zenith Desk will be replaced by the content of this backup: users and passwords, settings, integrations, chats, conversations, mail, statistics. Everybody will be signed out and has to sign in again with the passwords from the backup.",
      "bk.restore_safety": "Before that, a copy of the current state is saved automatically (type “Before restore”, encrypted with the same password).",
      "bk.file_pw": "Password of this backup", "bk.type_restore": "Type RESTORE to confirm", "bk.restore_go": "Restore the system",
      "bk.restored": "The system was restored. The page will reload — sign in with the users and passwords of the backup.",
      "bk.restored_reload": "The system was restored from a backup — the page reloads",
      "bk.date_created": "made {d}", "bk.size_total": "{n} files · {size}",
      "users.title": "Users",
      "users.add": "Add user",
      "users.search": "Search by name, login, position…",
      "users.col.name": "Name",
      "users.col.username": "Login",
      "users.col.role": "Role",
      "users.col.phone": "Extension",
      "users.col.zammad": "Zammad",
      "users.col.status": "Status",
      "users.col.login": "Last sign-in",
      "users.active": "active",
      "users.disabled": "disabled",
      "users.edit": "Edit",
      "users.password": "Password",
      "users.not_linked": "not linked",
      "users.never": "never",
      "role.operator": "Operator", "role.supervisor": "Supervisor", "role.admin": "Administrator",
      "level.admin": "Administrator", "level.level1": "Level 1 (Entry-Level)", "level.level2": "Level 2 (Mid-Level)",
      "level.level3": "Level 3 & Above (Senior)", "level.manager": "Manager",
      "form.level": "Level",
      "form.new_user": "New user",
      "form.edit_user": "Edit user",
      "form.first_name": "First name",
      "form.last_name": "Last name",
      "form.username": "Login (username)",
      "form.username_hint": "Latin letters, digits, . _ -",
      "form.position": "Position",
      "form.role": "Role",
      "form.access": "Access (follows the level)",
      "access.operator": "Operator workplace",
      "access.supervisor": "Operator workplace + Manager panel (leads Level 1–3 staff)",
      "access.admin": "Administrator panel + Manager panel",
      "form.password": "Password",
      "form.password_hint": "At least 8 characters",
      "form.generate": "Generate",
      "form.must_change": "Ask to change the password at first sign-in",
      "form.active": "Account is active (can sign in)",
      "form.section_phone": "Zammad and telephony",
      "form.zammad_user": "Zammad user (tickets are assigned to this user)",
      "form.zammad_search": "Search Zammad users by name or email…",
      "form.zammad_none": "Not linked",
      "form.unlink": "Unlink",
      "form.extension": "Extension",
      "form.interface": "Queue member in Asterisk",
      "form.interface_hint": "Usually Local/<extension>@from-queue/n — see “queue show” in FreePBX",
      "form.fill_from_ext": "Fill from extension",
      "form.automation": "Pause in queues automatically (blocking tasks, breaks)",
      "form.sip_user": "SIP login (empty = the extension)", "form.sip_password": "SIP password of the extension (for Zenith Phone)",
      "form.sip_keep": "saved — leave empty to keep it", "form.sip_none": "not set", "form.sip_clear": "Remove the SIP password",
      "form.sip_hint": "FreePBX → Applications → Extensions → the extension → Secret. The extension needs WebRTC enabled (Advanced → Enable WebRTC defaults: Yes).",
      "form.save": "Save",
      "form.cancel": "Cancel",
      "form.set_password": "Set a new password",
      "form.password_set": "Password saved. Give it to the user:",
      "form.copy": "Copy",
      "form.copied": "Copied",
      "settings.save": "Save changes",
      "settings.saved": "Settings saved and applied",
      "settings.nothing": "Nothing changed",
      "settings.secret_saved": "•••••• saved — type to replace",
      "settings.secret_empty": "not set",
      "settings.from_panel": "set in the panel",
      "settings.from_server": "server default",
      "settings.test": "Test connection",
      "itab.zammad": "Zammad", "itab.telephony": "Telephony", "itab.telegram": "Telegram", "itab.whatsapp": "WhatsApp", "itab.mail": "E-mail", "itab.sync": "Synchronisation",
      "wh.telegram": "Telegram webhook URL (only for the “webhook” mode)", "wh.telegram_hint": "Zenith Desk registers it at Telegram by itself when you save. In “polling” mode no public address is needed.",
      "wh.whatsapp": "WhatsApp webhook: Callback URL", "wh.verify": "Verify token", "wh.whatsapp_hint": "Meta for Developers → your app → WhatsApp → Configuration → Webhook: paste the Callback URL and the Verify token, then subscribe to the field “messages”.",
      "wh.no_public": "Set “Public address of Zenith Desk” (Chats: common rules) — Meta must reach this server over HTTPS.",
      "mail.test_login": "Optional: check a mailbox too", "mail.test_email": "E-mail", "mail.test_password": "Password",
      "sync.title": "Integrations: real time and fallback checks", "sync.interval": "Fallback check every {n} min", "sync.rt": "Real time", "sync.last_event": "Last event",
      "sync.last_poll": "Last check", "sync.next": "Next check", "sync.recovered": "Recovered", "sync.backlog": "In retry queue", "sync.error": "Last error", "sync.poll": "Check now", "sync.off": "not configured",
      "sync.rt.on": "connected", "sync.rt.off": "not connected", "sync.rt.n/a": "polling only", "sync.never": "—",
      "settings.test_ok": "Connection OK",
      "settings.test_fail": "Connection failed",
      "settings.webhook": "Webhook URL for Zammad",
      "settings.webhook_hint": "In Zammad: Manage → Webhook → New. Endpoint = this URL, HMAC token = the webhook token above. Then Manage → Trigger: on ticket create/update → this webhook.",
      "types.title": "Ticket types and required fields",
      "types.add": "Add ticket type",
      "types.name": "Name (shown to operators)",
      "types.value": "Value of the type attribute in Zammad",
      "types.enabled": "Enabled",
      "types.fields": "Required fields",
      "types.field_name": "Zammad attribute",
      "types.field_label": "Label",
      "types.field_type": "Type",
      "types.field_options": "Options (comma separated)",
      "types.add_field": "Add field",
      "types.delete": "Delete",
      "types.confirm_delete": "Delete ticket type “{name}”?",
      "types.empty": "No ticket types yet",
      "types.saved": "Ticket type saved",
      "sys.title": "System status",
      "sys.version": "Version",
      "sys.zammad": "Zammad",
      "sys.ami": "Telephony (AMI)",
      "sys.ok": "connected",
      "sys.fail": "no connection",
      "sys.users": "Users",
      "sys.online": "Operators online",
      "sys.sessions": "Active tasks",
      "sys.failed_events": "Failed webhook events",
      "sys.queues": "Managed queues",
      "sys.sync_problems": "Telephony sync problems",
      "sys.errors": "Recent errors",
      "sys.none": "none",
      "sys.refresh": "Refresh",
      "saved": "Saved",
    },
    ru: {
      "nav.admin": "Администрирование",
      "nav.users": "Пользователи",
      "nav.integrations": "Интеграции (API)",
      "nav.sys_settings": "Системные настройки",
      "nav.types": "Типы тикетов",
      "nav.system": "Состояние системы",
      "nav.backup": "Резервные копии",
      "bk.title": "Резервные копии", "bk.lead": "Один файл содержит всю систему: пользователей, настройки и интеграции, чаты, переписки Telegram и WhatsApp с файлами, почту, звонки и журнал аудита. По этому файлу и его паролю Zenith Desk восстанавливается здесь или на новом сервере.",
      "bk.create": "Создать копию сейчас", "bk.upload": "Загрузить файл копии", "bk.uploading": "Загрузка… {p}%",
      "bk.last": "Последняя копия", "bk.next": "Следующая автоматическая", "bk.off": "выключено", "bk.never": "ещё не было", "bk.disk": "Свободно на диске",
      "bk.failed": "Последняя ошибка", "bk.no_pw_banner": "Сначала задайте пароль резервных копий — им шифруется каждый файл.",
      "bk.settings": "Автоматическое копирование", "bk.enabled": "Создавать копии автоматически", "bk.frequency": "Как часто", "bk.daily": "Каждый день", "bk.weekly": "Каждую неделю",
      "bk.time": "Во сколько", "bk.weekday": "День", "bk.keep": "Хранить последних N автоматических копий",
      "bk.password": "Пароль резервных копий", "bk.password_saved": "•••••• сохранён — введите, чтобы заменить", "bk.password_none": "не задан — минимум 8 символов",
      "bk.password_hint": "Шифрует каждый файл (AES-256). Без него копию нельзя восстановить: храните его в надёжном месте, не только на этом сервере.",
      "bk.tz": "Часовой пояс: {tz}", "bk.save": "Сохранить", "bk.saved": "Настройки копирования сохранены",
      "bk.files": "Файлы копий", "bk.empty": "Копий пока нет", "bk.folder": "Папка на сервере: {f}",
      "bk.col.date": "Дата", "bk.col.kind": "Тип", "bk.col.size": "Размер", "bk.col.version": "Версия", "bk.col.by": "Кто создал",
      "bk.kind.manual": "Вручную", "bk.kind.scheduled": "Автоматическая", "bk.kind.pre-restore": "Перед восстановлением", "bk.kind.uploaded": "Загружена", "bk.kind.cli": "Командная строка", "bk.kind.unknown": "Не читается",
      "bk.download": "Скачать", "bk.verify": "Проверить", "bk.restore": "Восстановить", "bk.delete": "Удалить",
      "bk.confirm_delete": "Удалить копию {name}?", "bk.deleted": "Копия удалена",
      "bk.running.backup": "Создаётся копия…", "bk.running.restore": "Идёт восстановление системы — не закрывайте страницу…", "bk.running.verify": "Проверка файла…",
      "bk.done.backup": "Копия создана", "bk.done.upload": "Файл загружен — нажмите «Восстановить», чтобы вернуть из него систему",
      "bk.verify_title": "Проверка копии", "bk.verify_ok": "Файл целый, пароль верный: {rows} строк, Zenith Desk {version}.",
      "bk.restore_title": "Восстановление всей системы", "bk.restore_warn": "ВСЕ текущие данные Zenith Desk будут заменены содержимым этой копии: пользователи и пароли, настройки, интеграции, чаты, переписки, почта, статистика. Все пользователи выйдут из системы и войдут снова с паролями из копии.",
      "bk.restore_safety": "Перед этим текущее состояние автоматически сохраняется в копию (тип «Перед восстановлением», с тем же паролем).",
      "bk.file_pw": "Пароль этой копии", "bk.type_restore": "Для подтверждения введите RESTORE", "bk.restore_go": "Восстановить систему",
      "bk.restored": "Система восстановлена. Страница перезагрузится — войдите с пользователями и паролями из копии.",
      "bk.restored_reload": "Система восстановлена из резервной копии — страница перезагружается",
      "bk.date_created": "создана {d}", "bk.size_total": "файлов: {n} · {size}",
      "users.title": "Пользователи",
      "users.add": "Добавить пользователя",
      "users.search": "Поиск по имени, логину, должности…",
      "users.col.name": "Имя",
      "users.col.username": "Логин",
      "users.col.role": "Роль",
      "users.col.phone": "Внутр. номер",
      "users.col.zammad": "Zammad",
      "users.col.status": "Статус",
      "users.col.login": "Последний вход",
      "users.active": "активен",
      "users.disabled": "отключён",
      "users.edit": "Изменить",
      "users.password": "Пароль",
      "users.not_linked": "не связан",
      "users.never": "не входил",
      "role.operator": "Оператор", "role.supervisor": "Руководитель", "role.admin": "Администратор",
      "level.admin": "Администратор", "level.level1": "Уровень 1 (начальный)", "level.level2": "Уровень 2 (средний)",
      "level.level3": "Уровень 3 и выше (старший)", "level.manager": "Менеджер",
      "form.level": "Уровень",
      "form.new_user": "Новый пользователь",
      "form.edit_user": "Изменить пользователя",
      "form.first_name": "Имя",
      "form.last_name": "Фамилия",
      "form.username": "Логин",
      "form.username_hint": "Латинские буквы, цифры, . _ -",
      "form.position": "Должность",
      "form.role": "Роль",
      "form.access": "Доступ (определяется уровнем)",
      "access.operator": "Рабочее место оператора",
      "access.supervisor": "Рабочее место + панель руководителя (управляет сотрудниками уровней 1–3)",
      "access.admin": "Панель администратора + панель руководителя",
      "form.password": "Пароль",
      "form.password_hint": "Не менее 8 символов",
      "form.generate": "Сгенерировать",
      "form.must_change": "Попросить сменить пароль при первом входе",
      "form.active": "Учётная запись активна (может входить)",
      "form.section_phone": "Zammad и телефония",
      "form.zammad_user": "Пользователь Zammad (на него назначаются тикеты)",
      "form.zammad_search": "Поиск пользователей Zammad по имени или email…",
      "form.zammad_none": "Не связан",
      "form.unlink": "Отвязать",
      "form.extension": "Внутренний номер",
      "form.interface": "Участник очереди в Asterisk",
      "form.interface_hint": "Обычно Local/<номер>@from-queue/n — см. «queue show» во FreePBX",
      "form.fill_from_ext": "Заполнить по номеру",
      "form.automation": "Автоматически ставить паузу в очередях (блокирующие задачи, перерыв)",
      "form.sip_user": "SIP-логин (пусто = внутренний номер)", "form.sip_password": "SIP-пароль номера (для Zenith Phone)",
      "form.sip_keep": "сохранён — оставьте пустым, чтобы не менять", "form.sip_none": "не задан", "form.sip_clear": "Удалить SIP-пароль",
      "form.sip_hint": "FreePBX → Applications → Extensions → номер → Secret. Для номера нужно включить WebRTC (Advanced → Enable WebRTC defaults: Yes).",
      "form.save": "Сохранить",
      "form.cancel": "Отмена",
      "form.set_password": "Задать новый пароль",
      "form.password_set": "Пароль сохранён. Передайте его пользователю:",
      "form.copy": "Копировать",
      "form.copied": "Скопировано",
      "settings.save": "Сохранить изменения",
      "settings.saved": "Настройки сохранены и применены",
      "settings.nothing": "Изменений нет",
      "settings.secret_saved": "•••••• сохранено — введите, чтобы заменить",
      "settings.secret_empty": "не задано",
      "settings.from_panel": "задано в панели",
      "settings.from_server": "значение сервера",
      "settings.test": "Проверить подключение",
      "itab.zammad": "Zammad", "itab.telephony": "Телефония", "itab.telegram": "Telegram", "itab.whatsapp": "WhatsApp", "itab.mail": "Почта", "itab.sync": "Синхронизация",
      "wh.telegram": "URL webhook для Telegram (только для режима «webhook»)", "wh.telegram_hint": "Zenith Desk сам регистрирует его в Telegram при сохранении. В режиме «polling» внешний адрес не нужен.",
      "wh.whatsapp": "Webhook WhatsApp: Callback URL", "wh.verify": "Verify token", "wh.whatsapp_hint": "Meta for Developers → приложение → WhatsApp → Configuration → Webhook: вставьте Callback URL и Verify token, затем подпишитесь на поле «messages».",
      "wh.no_public": "Укажите «Внешний адрес Zenith Desk» (Чаты: общие правила) — Meta должна достучаться до сервера по HTTPS.",
      "mail.test_login": "Необязательно: проверить и почтовый ящик", "mail.test_email": "E-mail", "mail.test_password": "Пароль",
      "sync.title": "Интеграции: реальное время и резервные проверки", "sync.interval": "Резервная проверка каждые {n} мин", "sync.rt": "Реальное время", "sync.last_event": "Последнее событие",
      "sync.last_poll": "Последняя проверка", "sync.next": "Следующая", "sync.recovered": "Восстановлено", "sync.backlog": "В очереди повторов", "sync.error": "Последняя ошибка", "sync.poll": "Проверить сейчас", "sync.off": "не настроено",
      "sync.rt.on": "подключено", "sync.rt.off": "нет подключения", "sync.rt.n/a": "только проверки", "sync.never": "—",
      "settings.test_ok": "Подключение работает",
      "settings.test_fail": "Нет подключения",
      "settings.webhook": "URL webhook для Zammad",
      "settings.webhook_hint": "В Zammad: Manage → Webhook → New. Endpoint = этот URL, HMAC-токен = токен webhook выше. Затем Manage → Trigger: при создании/изменении тикета → этот webhook.",
      "types.title": "Типы тикетов и обязательные поля",
      "types.add": "Добавить тип",
      "types.name": "Название (видят операторы)",
      "types.value": "Значение атрибута типа в Zammad",
      "types.enabled": "Включён",
      "types.fields": "Обязательные поля",
      "types.field_name": "Атрибут Zammad",
      "types.field_label": "Подпись",
      "types.field_type": "Тип",
      "types.field_options": "Варианты (через запятую)",
      "types.add_field": "Добавить поле",
      "types.delete": "Удалить",
      "types.confirm_delete": "Удалить тип тикета «{name}»?",
      "types.empty": "Типов тикетов пока нет",
      "types.saved": "Тип тикета сохранён",
      "sys.title": "Состояние системы",
      "sys.version": "Версия",
      "sys.zammad": "Zammad",
      "sys.ami": "Телефония (AMI)",
      "sys.ok": "подключено",
      "sys.fail": "нет подключения",
      "sys.users": "Пользователи",
      "sys.online": "Операторов онлайн",
      "sys.sessions": "Активных задач",
      "sys.failed_events": "Ошибочных событий webhook",
      "sys.queues": "Управляемые очереди",
      "sys.sync_problems": "Проблемы синхронизации с телефонией",
      "sys.errors": "Последние ошибки",
      "sys.none": "нет",
      "sys.refresh": "Обновить",
      "saved": "Сохранено",
    },
  };

  const component = {
    props: ["view", "api", "t", "toast", "fmt", "me", "upload"],
    data() {
      return {
        busy: false, users: [], filter: "", modal: null, form: {}, zq: "", zresults: [], zsearching: false,
        groups: [], edits: {}, webhookUrl: "", tests: {}, types: [], system: null, newPassword: "",
        itab: "zammad", hooks: {}, mailTest: { email: "", password: "" }, sync: null,
        bk: null, bkEdits: {}, bkUpload: -1, bkResult: null,
      };
    },
    computed: {
      filteredUsers() {
        const q = this.filter.trim().toLowerCase();
        if (!q) return this.users;
        return this.users.filter((u) => [u.name, u.username, u.position, u.extension].join(" ").toLowerCase().includes(q));
      },
      visibleGroups() {
        const tabs = { zammad: ["zammad"], telephony: ["telephony", "phone"], telegram: ["telegram", "messengers"], whatsapp: ["whatsapp", "messengers"],
                       mail: ["mail"], sync: ["sync"] };
        const ids = this.view === "integrations" ? tabs[this.itab] || [] : ["tickets", "reports", "general", "privacy"];
        return this.groups.filter((g) => ids.includes(g.id));
      },
      dirty() { return Object.keys(this.edits).length > 0; },
    },
    watch: { view: { immediate: true, handler() { this.load(); } } },
    // live mode (v2.7): reload the open page when the server reports a change (never over unsaved edits)
    mounted() {
      this._live = (ev) => {
        const tp = (ev.detail && ev.detail.topics) || [];
        const want = { users: ["users"], system: ["team", "users", "config"], types: ["config"], settings: ["config"], integrations: ["config"] }[this.view] || [];
        if (!tp.some((x) => want.includes(x)) || this.modal) return;
        if ((this.view === "settings" || this.view === "integrations") && Object.keys(this.edits || {}).length) return;
        clearTimeout(this._liveT); this._liveT = setTimeout(() => this.load(), 150);
      };
      window.addEventListener("agentix:changed", this._live);
    },
    unmounted() { window.removeEventListener("agentix:changed", this._live); clearTimeout(this._bkPoll); },
    methods: {
      async run(fn, okKey) {
        if (this.busy) return;
        this.busy = true;
        try { const r = await fn(); if (okKey) this.toast(this.t(okKey)); return r; }
        catch (e) { this.toast(e.message, "error"); }
        finally { this.busy = false; }
      },
      async load() {
        try {
          if (this.view === "users") this.users = await this.api("GET", "/api/admin/users");
          if (this.view === "integrations" || this.view === "settings") await this.loadSettings();
          if (this.view === "types") this.types = await this.api("GET", "/api/admin/ticket-types");
          if (this.view === "system") this.system = await this.api("GET", "/api/admin/system");
          if (this.view === "backup") await this.loadBackup();
        } catch (e) { this.toast(e.message, "error"); }
      },
      roleText(r) { return this.t(`role.${r}`); },
      levelText(l) { return l ? this.t(`level.${l}`) : ""; },
      onLevel() {  // suggest the role that matches the level
        const map = { admin: "admin", manager: "supervisor", level1: "operator", level2: "operator", level3: "operator" };
        if (map[this.form.level]) this.form.role = map[this.form.level];
      },

      // ---------------- users
      openUser(u) {
        this.form = u ? { ...u, password: "", must_change_password: false, sip_password: "", sip_password_clear: false }
          : { id: null, first_name: "", last_name: "", username: "", position: "", role: "operator", active: true,
              zammad_user_id: null, extension: "", asterisk_interface: "", enabled: true, password: "", must_change_password: false, level: "",
              sip_user: "", sip_password: "", sip_password_clear: false, has_sip_password: false };
        this.zq = ""; this.zresults = []; this.newPassword = "";
        this.modal = "user";
      },
      genPassword() {
        const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        const arr = new Uint32Array(12);
        crypto.getRandomValues(arr);
        return Array.from(arr, (n) => chars[n % chars.length]).join("");
      },
      fillInterface() { if (this.form.extension) this.form.asterisk_interface = `Local/${this.form.extension.trim()}@from-queue/n`; },
      async searchZammad() {
        this.zsearching = true;
        try { this.zresults = await this.api("GET", `/api/admin/zammad-users?q=${encodeURIComponent(this.zq)}`); }
        catch (e) { this.toast(e.message, "error"); }
        finally { this.zsearching = false; }
      },
      pickZammad(z) { this.form.zammad_user_id = z.id; this.form.zammad_label = `${z.name || z.login} (${z.email || z.login})`; this.zresults = []; },
      saveUser() {
        return this.run(async () => {
          const f = this.form;
          const body = {
            first_name: f.first_name, last_name: f.last_name, username: f.username, position: f.position, role: f.role, level: f.level,
            active: f.active, zammad_user_id: f.zammad_user_id || null, extension: f.extension || "",
            asterisk_interface: f.asterisk_interface || "", enabled: f.enabled,
            password: f.password || null, must_change_password: f.must_change_password,
            sip_user: f.sip_user || "", sip_password: f.sip_password || null, sip_password_clear: !!f.sip_password_clear,
          };
          if (f.id) await this.api("PUT", `/api/admin/users/${f.id}`, body);
          else await this.api("POST", "/api/admin/users", body);
          this.modal = null;
          this.users = await this.api("GET", "/api/admin/users");
        }, "saved");
      },
      openPassword(u) { this.form = { id: u.id, name: u.name, username: u.username, password: this.genPassword(), must_change_password: false }; this.newPassword = ""; this.modal = "password"; },
      savePassword() {
        return this.run(async () => {
          await this.api("POST", `/api/admin/users/${this.form.id}/password`, { password: this.form.password, must_change_password: this.form.must_change_password });
          this.newPassword = this.form.password;
          this.users = await this.api("GET", "/api/admin/users");
        });
      },
      copy(text) { navigator.clipboard && navigator.clipboard.writeText(text).then(() => this.toast(this.t("form.copied"))); },

      // ---------------- settings
      async loadSettings() {
        const r = await this.api("GET", "/api/admin/settings");
        this.groups = r.groups; this.webhookUrl = r.webhook_url; this.edits = {};
        this.hooks = { telegram: r.telegram_webhook_url, whatsapp: r.whatsapp_webhook_url, verify: r.whatsapp_verify_token, public: r.public_url_set };
        if (this.view === "integrations" && this.itab === "sync") this.loadSync();
      },
      value(item) { return item.key in this.edits ? this.edits[item.key] : item.value; },
      setValue(item, v) {
        if (item.type !== "secret" && v === item.value) delete this.edits[item.key];
        else if (item.type === "secret" && v === "") delete this.edits[item.key];
        else this.edits[item.key] = v;
      },
      saveSettings() {
        if (!this.dirty) { this.toast(this.t("settings.nothing")); return; }
        return this.run(async () => {
          const r = await this.api("PUT", "/api/admin/settings", { values: this.edits });
          this.groups = r.groups; this.edits = {};
          this.toast(r.changed.length ? this.t("settings.saved") : this.t("settings.nothing"));
          if (r.changed.includes("ui_language")) setTimeout(() => location.reload(), 600);
        });
      },
      async loadSync() { try { this.sync = await this.api("GET", "/api/admin/sync"); } catch (e) { this.toast(e.message, "error"); } },
      pollNow(name) { return this.run(async () => { this.sync = await this.api("POST", `/api/admin/sync/${name}/poll`); }); },
      setTab(tab) { this.itab = tab; this.tests = {}; if (tab === "sync") this.loadSync(); },
      testConnection(group) {
        if (["telegram", "whatsapp", "mail"].includes(group)) {
          return this.run(async () => {
            const values = { ...this.edits };
            if (group === "mail" && this.mailTest.email) Object.assign(values, { test_email: this.mailTest.email, test_password: this.mailTest.password });
            this.tests = { ...this.tests, [group]: await this.api("POST", `/api/admin/settings/test/${group}`, { values }) };
          });
        }
        return this.run(async () => {
          const pick = (k) => this.edits[k];
          const r = group === "zammad"
            ? await this.api("POST", "/api/admin/settings/test-zammad", { zammad_url: pick("zammad_url"), zammad_token: pick("zammad_token"), zammad_verify_tls: pick("zammad_verify_tls") })
            : await this.api("POST", "/api/admin/settings/test-ami", { ami_host: pick("ami_host"), ami_port: pick("ami_port") ? Number(pick("ami_port")) : null, ami_user: pick("ami_user"), ami_secret: pick("ami_secret") });
          this.tests = { ...this.tests, [group]: r };
        });
      },

      // ---------------- backup (v3.10)
      async loadBackup() {
        this.bk = await this.api("GET", "/api/admin/backups");
        this.watchJob();
      },
      watchJob() {
        clearTimeout(this._bkPoll);
        const job = this.bk && this.bk.job;
        if (!job || job.state !== "running" || this.view !== "backup") return;
        this._bkPoll = setTimeout(async () => {
          let v = null;
          try { v = await this.api("GET", "/api/admin/backups"); } catch (e) { /* the server restarts its jobs during a restore */ }
          if (v) { this.bk = v; this.jobFinished(v.job); }
          this.watchJob();
        }, 1200);
      },
      jobFinished(job) {
        if (!job || job.state === "running" || this._bkSeen === job.id) return;
        this._bkSeen = job.id;
        if (job.state === "failed") { this.toast(job.error || "error", "error"); return; }
        if (job.kind === "backup") this.toast(this.t("bk.done.backup"));
        if (job.kind === "restore") { this.modal = null; this.bkResult = "restored"; setTimeout(() => location.reload(), 2500); }
      },
      bkVal(k) { return k in this.bkEdits ? this.bkEdits[k] : this.bk[{ backup_enabled: "enabled", backup_frequency: "frequency", backup_time: "time", backup_weekday: "weekday", backup_keep: "keep" }[k]]; },
      bkSet(k, v) { this.bkEdits = { ...this.bkEdits, [k]: v }; },
      saveBackupSettings() {
        const values = { ...this.bkEdits };
        if (!values.backup_password) delete values.backup_password;
        if ("backup_keep" in values) values.backup_keep = Number(values.backup_keep);
        return this.run(async () => {
          const v = await this.api("PUT", "/api/admin/backups/settings", { values });
          this.bk = { ...v, job: this.bk.job }; this.bkEdits = {};
        }, "bk.saved");
      },
      createBackup() {
        return this.run(async () => { this.bk = await this.api("POST", "/api/admin/backups", {}); this._bkSeen = null; this.watchJob(); });
      },
      async downloadBackup(b) {
        try { const r = await this.api("POST", `/api/admin/backups/${encodeURIComponent(b.name)}/link`); const a = document.createElement("a"); a.href = r.url; a.download = b.name; document.body.appendChild(a); a.click(); a.remove(); }
        catch (e) { this.toast(e.message, "error"); }
      },
      deleteBackup(b) {
        if (!confirm(this.t("bk.confirm_delete", { name: b.name }))) return;
        return this.run(async () => { this.bk = { ...(await this.api("DELETE", `/api/admin/backups/${encodeURIComponent(b.name)}`)) }; }, "bk.deleted");
      },
      pickUpload() { this.$refs.bkFile && this.$refs.bkFile.click(); },
      async doUpload(ev) {
        const f = ev.target.files && ev.target.files[0];
        ev.target.value = "";
        if (!f || !this.upload) return;
        this.bkUpload = 0;
        try {
          const v = await this.upload(`/api/admin/backups/upload?filename=${encodeURIComponent(f.name)}`, f, (p) => { this.bkUpload = p; });
          this.bk = { ...v, job: this.bk.job }; this.toast(this.t("bk.done.upload"));
          const up = v.uploaded && (v.items || []).find((x) => x.name === v.uploaded.name);
          if (up) this.openRestore(up);
        } catch (e) { this.toast(e.message, "error"); }
        finally { this.bkUpload = -1; }
      },
      openVerify(b) { this.form = { name: b.name, password: "", result: null }; this.modal = "bk-verify"; },
      verifyBackup() {
        return this.run(async () => { this.form.result = await this.api("POST", `/api/admin/backups/${encodeURIComponent(this.form.name)}/verify`, { password: this.form.password }); });
      },
      openRestore(b) { this.form = { name: b.name, created_at: b.created_at, password: "", confirm: "" }; this.modal = "bk-restore"; },
      restoreBackup() {
        return this.run(async () => {
          const r = await this.api("POST", `/api/admin/backups/${encodeURIComponent(this.form.name)}/restore`, { password: this.form.password, confirm: this.form.confirm });
          this.bk = { ...this.bk, job: r.job, busy: "restore" }; this._bkSeen = null; this.modal = null; this.watchJob();
        });
      },
      size(n) {
        if (n == null) return "—";
        const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0; let v = n;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i += 1; }
        return `${v >= 10 || i === 0 ? Math.round(v) : v.toFixed(1)} ${u[i]}`;
      },
      weekdayName(i) { try { return new Date(Date.UTC(2026, 9, 12 + i)).toLocaleDateString(document.documentElement.lang || undefined, { weekday: "long", timeZone: "UTC" }); } catch { return ["mon","tue","wed","thu","fri","sat","sun"][i]; } },
      bkRunning() { return this.bk && this.bk.job && this.bk.job.state === "running" ? this.bk.job.kind : (this.bk && this.bk.busy) || ""; },

      // ---------------- ticket types
      openType(tt) {
        this.form = tt ? JSON.parse(JSON.stringify(tt)) : { id: 0, name: "", zammad_value: "", enabled: true, required_fields: [] };
        this.form.required_fields = this.form.required_fields.map((f) => ({ ...f, options: (f.options || []).join(", ") }));
        this.modal = "type";
      },
      addField() { this.form.required_fields.push({ name: "", label: "", type: "text", options: "" }); },
      saveType() {
        return this.run(async () => {
          const f = this.form;
          await this.api("PUT", `/api/admin/ticket-types/${f.id || 0}`, {
            name: f.name, zammad_value: f.zammad_value, enabled: f.enabled,
            required_fields: f.required_fields.filter((x) => x.name.trim()).map((x) => ({ ...x, options: x.options.split(",").map((o) => o.trim()).filter(Boolean) })),
          });
          this.modal = null;
          this.types = await this.api("GET", "/api/admin/ticket-types");
        }, "types.saved");
      },
      deleteType(tt) {
        if (!confirm(this.t("types.confirm_delete", { name: tt.name }))) return;
        return this.run(async () => { await this.api("DELETE", `/api/admin/ticket-types/${tt.id}`); this.types = await this.api("GET", "/api/admin/ticket-types"); });
      },
    },

    template: `
<div class="admin">
  <!-- ======================= USERS ======================= -->
  <section v-if="view==='users'" class="panel">
    <h2>{{ t('users.title') }} <span class="count">{{ users.length }}</span></h2>
    <div class="body">
      <div class="toolbar">
        <input v-model="filter" :placeholder="t('users.search')" class="search">
        <button class="btn primary" @click="openUser(null)">+ {{ t('users.add') }}</button>
      </div>
      <div class="table-wrap"><table class="users">
        <thead><tr><th>{{ t('users.col.name') }}</th><th>{{ t('users.col.username') }}</th><th>{{ t('users.col.role') }}</th>
          <th>{{ t('users.col.phone') }}</th><th>{{ t('users.col.zammad') }}</th><th>{{ t('users.col.status') }}</th><th>{{ t('users.col.login') }}</th><th></th></tr></thead>
        <tbody>
          <tr v-for="u in filteredUsers" :key="u.id" :class="{muted: !u.active}">
            <td><b>{{ u.name || '—' }}</b><div class="lvl">{{ levelText(u.level) }}</div><div class="empty">{{ u.position }}</div></td>
            <td><code>{{ u.username || '—' }}</code></td>
            <td><span class="tag" :class="'role-' + u.role">{{ roleText(u.role) }}</span></td>
            <td>{{ u.extension || '—' }}</td>
            <td><span v-if="u.zammad_user_id">#{{ u.zammad_user_id }}</span><span v-else class="empty">{{ t('users.not_linked') }}</span></td>
            <td><span class="tag" :class="u.active ? 'ok' : 'off'">{{ u.active ? t('users.active') : t('users.disabled') }}</span></td>
            <td class="empty">{{ u.last_login_at ? fmt(u.last_login_at, true) : t('users.never') }}</td>
            <td class="nowrap"><button class="btn sm" @click="openUser(u)">{{ t('users.edit') }}</button> <button class="btn sm" @click="openPassword(u)">{{ t('users.password') }}</button></td>
          </tr>
        </tbody>
      </table></div>
    </div>
  </section>

  <!-- ======================= SETTINGS / INTEGRATIONS ======================= -->
  <template v-if="view==='integrations' || view==='settings'">
    <div v-if="view==='integrations'" class="itabs">
      <button v-for="tb in ['zammad','telephony','telegram','whatsapp','mail','sync']" :key="tb" :class="{on: itab===tb}" @click="setTab(tb)" :data-itab="tb">{{ t('itab.' + tb) }}</button>
    </div>
    <section v-if="view==='integrations' && itab==='sync' && sync" class="panel sync-panel">
      <h2>{{ t('sync.title') }} <span class="count">{{ t('sync.interval', {n: sync.interval_min}) }}</span> <button class="btn sm" @click="loadSync">{{ t('sys.refresh') }}</button></h2>
      <div class="body"><div class="table-wrap"><table class="sync">
        <thead><tr><th></th><th>{{ t('sync.rt') }}</th><th>{{ t('sync.last_event') }}</th><th>{{ t('sync.last_poll') }}</th><th>{{ t('sync.next') }}</th><th>{{ t('sync.recovered') }}</th><th>{{ t('sync.backlog') }}</th><th>{{ t('sync.error') }}</th><th></th></tr></thead>
        <tbody><tr v-for="it in sync.items" :key="it.name" :class="{muted: !it.enabled}" :data-sync="it.name">
          <td><b><span class="sdot" :class="!it.enabled ? '' : it.ok ? 'ok' : 'bad'"></span>{{ it.title }}</b></td>
          <td>{{ it.enabled ? t('sync.rt.' + it.realtime) : t('sync.off') }}<div class="hint">{{ it.realtime_detail }}</div></td>
          <td>{{ it.last_event_at ? fmt(it.last_event_at, true) : t('sync.never') }}<div class="hint" v-if="it.events">{{ it.events }}</div></td>
          <td>{{ it.last_poll_at ? fmt(it.last_poll_at, true) : t('sync.never') }}<div class="hint" v-if="it.last_poll_at">{{ it.last_poll_ms }} ms</div></td>
          <td>{{ it.next_poll_at ? fmt(it.next_poll_at, true) : '—' }}</td>
          <td><b>{{ it.last_recovered }}</b> <span class="hint">/ {{ it.recovered_total }}</span></td>
          <td :class="{err: it.backlog > 20}" :data-backlog="it.name">{{ it.backlog }}</td>
          <td :class="{err: it.last_error}">{{ it.last_error || '—' }}</td>
          <td><button class="btn sm" :disabled="busy || !it.enabled" @click="pollNow(it.name)" :data-poll="it.name">{{ t('sync.poll') }}</button></td>
        </tr></tbody>
      </table></div></div>
    </section>
    <section v-for="g in visibleGroups" :key="g.id" class="panel settings-group" :data-group="g.id">
      <h2>{{ g.title }}
        <button v-if="['zammad','telephony','telegram','whatsapp','mail'].includes(g.id)" class="btn sm" :disabled="busy" @click="testConnection(g.id)" :data-test="g.id">{{ t('settings.test') }}</button>
      </h2>
      <div class="body">
        <div v-if="tests[g.id]" class="banner" :class="tests[g.id].ok ? 'ok' : 'error'">
          {{ tests[g.id].ok ? t('settings.test_ok') : t('settings.test_fail') }}: {{ tests[g.id].detail }}
        </div>
        <div class="settings-grid">
          <div v-for="it in g.items" :key="it.key" class="setting" :class="{changed: it.key in edits}">
            <label v-if="it.type!=='bool'">{{ it.label }}</label>
            <label v-else class="check"><input type="checkbox" :checked="value(it)" @change="setValue(it, $event.target.checked)"> {{ it.label }}</label>
            <select v-if="it.type==='choice'" :value="value(it)" @change="setValue(it, $event.target.value)">
              <option v-for="o in it.options" :key="o" :value="o">{{ o }}</option>
            </select>
            <input v-else-if="it.type==='secret'" type="password" autocomplete="new-password" :value="edits[it.key] || ''"
                   :placeholder="it.has_value ? t('settings.secret_saved') : t('settings.secret_empty')" @input="setValue(it, $event.target.value)">
            <input v-else-if="it.type==='int'" type="number" min="0" :value="value(it)" @input="setValue(it, $event.target.value)">
            <textarea v-else-if="it.type==='text'" rows="4" :value="value(it)" @input="setValue(it, $event.target.value)"></textarea>
            <input v-else-if="it.type!=='bool'" :value="value(it)" @input="setValue(it, $event.target.value)" :name="it.key">
            <div class="hint" v-if="it.help">{{ it.help }}</div>
            <div class="hint src">{{ it.source==='panel' ? t('settings.from_panel') : t('settings.from_server') }}</div>
          </div>
        </div>
        <div v-if="g.id==='mail'" class="webhook">
          <label>{{ t('mail.test_login') }}</label>
          <div class="row"><input v-model="mailTest.email" :placeholder="t('mail.test_email')" autocomplete="off" name="mail-test-email">
            <input v-model="mailTest.password" type="password" :placeholder="t('mail.test_password')" autocomplete="new-password" name="mail-test-password"></div>
        </div>
        <div v-if="g.id==='telegram'" class="webhook">
          <label>{{ t('wh.telegram') }}</label>
          <div class="row"><input :value="hooks.telegram || '—'" readonly><button class="btn" style="flex:0 0 auto" @click="copy(hooks.telegram)" :disabled="!hooks.telegram">{{ t('form.copy') }}</button></div>
          <div class="hint">{{ t('wh.telegram_hint') }}</div>
        </div>
        <div v-if="g.id==='whatsapp'" class="webhook">
          <label>{{ t('wh.whatsapp') }}</label>
          <div class="row"><input :value="hooks.whatsapp || '—'" readonly><button class="btn" style="flex:0 0 auto" @click="copy(hooks.whatsapp)" :disabled="!hooks.whatsapp">{{ t('form.copy') }}</button></div>
          <label>{{ t('wh.verify') }}</label>
          <div class="row"><input :value="hooks.verify" readonly name="wa-verify"><button class="btn" style="flex:0 0 auto" @click="copy(hooks.verify)">{{ t('form.copy') }}</button></div>
          <div class="hint">{{ t('wh.whatsapp_hint') }}</div>
          <div v-if="!hooks.public" class="banner" style="margin-top:8px">{{ t('wh.no_public') }}</div>
        </div>
        <div v-if="g.id==='zammad'" class="webhook">
          <label>{{ t('settings.webhook') }}</label>
          <div class="row"><input :value="webhookUrl" readonly><button class="btn" style="flex:0 0 auto" @click="copy(webhookUrl)">{{ t('form.copy') }}</button></div>
          <div class="hint">{{ t('settings.webhook_hint') }}</div>
        </div>
      </div>
    </section>
    <div class="savebar" :class="{show: dirty}">
      <span>{{ Object.keys(edits).length }} ✎</span>
      <button class="btn" @click="edits = {}">{{ t('form.cancel') }}</button>
      <button class="btn primary" :disabled="busy" @click="saveSettings">{{ t('settings.save') }}</button>
    </div>
  </template>

  <!-- ======================= TICKET TYPES ======================= -->
  <section v-if="view==='types'" class="panel">
    <h2>{{ t('types.title') }} <button class="btn sm primary" @click="openType(null)">+ {{ t('types.add') }}</button></h2>
    <div class="body">
      <div v-if="!types.length" class="empty">{{ t('types.empty') }}</div>
      <div v-for="tt in types" :key="tt.id" class="item">
        <div class="title">{{ tt.name }} <span class="tag">{{ tt.zammad_value }}</span> <span v-if="!tt.enabled" class="tag off">off</span></div>
        <div class="meta"><span v-for="f in tt.required_fields" :key="f.name" class="tag">{{ f.label }} ({{ f.name }})</span></div>
        <div class="actions"><button class="btn sm" @click="openType(tt)">{{ t('users.edit') }}</button> <button class="btn sm danger" @click="deleteType(tt)">{{ t('types.delete') }}</button></div>
      </div>
    </div>
  </section>

  <!-- ======================= SYSTEM ======================= -->
  <template v-if="view==='system' && system">
    <div class="cards">
      <div class="panel card"><div class="k">{{ t('sys.version') }}</div><div class="v">v{{ system.version }}</div></div>
      <div class="panel card" :class="system.zammad.ok ? 'good' : 'bad'"><div class="k">{{ t('sys.zammad') }}</div>
        <div class="v">{{ system.zammad.ok ? t('sys.ok') : t('sys.fail') }}</div><div class="hint">{{ system.zammad.url }} · {{ system.zammad.detail }}</div></div>
      <div class="panel card" :class="system.ami.connected ? 'good' : 'bad'"><div class="k">{{ t('sys.ami') }}</div>
        <div class="v">{{ system.ami.connected ? t('sys.ok') : t('sys.fail') }}</div><div class="hint">{{ system.ami.host }} {{ system.ami.last_error }}</div></div>
      <div class="panel card"><div class="k">{{ t('sys.users') }}</div><div class="v">{{ system.users.active }} / {{ system.users.total }}</div></div>
      <div class="panel card"><div class="k">{{ t('sys.online') }}</div><div class="v">{{ system.online }}</div></div>
      <div class="panel card"><div class="k">{{ t('sys.sessions') }}</div><div class="v">{{ system.active_sessions }}</div></div>
      <div class="panel card" :class="{bad: system.failed_events}"><div class="k">{{ t('sys.failed_events') }}</div><div class="v">{{ system.failed_events }}</div></div>
      <div class="panel card"><div class="k">{{ t('sys.queues') }}</div><div class="v small">{{ system.managed_queues.join(', ') || '—' }}</div></div>
      <div class="panel card" v-if="system.backup" :class="system.backup.error ? 'bad' : system.backup.last_at ? 'good' : ''" data-sys="backup"><div class="k">{{ t('bk.last') }}</div>
        <div class="v small">{{ system.backup.last_at ? fmt(system.backup.last_at, true) : t('bk.never') }}</div>
        <div class="hint">{{ t('bk.next') }}: {{ system.backup.next_run_at ? fmt(system.backup.next_run_at, true) : t('bk.off') }}</div>
        <div class="hint err" v-if="system.backup.error">{{ system.backup.error.error }}</div></div>
    </div>
    <section class="panel" style="margin-top:16px" v-if="system.integrations">
      <h2>{{ t('sync.title') }} <span class="count">{{ t('sync.interval', {n: system.sync_interval_min}) }}</span></h2>
      <div class="body sys-int">
        <div v-for="it in system.integrations" :key="it.name" class="sys-it" :class="{muted: !it.enabled}">
          <span class="sdot" :class="!it.enabled ? '' : it.ok ? 'ok' : 'bad'"></span><b>{{ it.title }}</b>
          <span class="hint">{{ it.enabled ? t('sync.rt.' + it.realtime) + (it.realtime_detail ? ' · ' + it.realtime_detail : '') : t('sync.off') }}</span>
          <span class="hint err" v-if="it.last_error">{{ it.last_error }}</span>
        </div>
      </div>
    </section>
    <div class="grid" style="grid-template-columns: minmax(0,1fr) minmax(0,1fr); margin-top:16px">
      <section class="panel"><h2>{{ t('sys.sync_problems') }} <button class="btn sm" @click="load">{{ t('sys.refresh') }}</button></h2><div class="body">
        <div v-if="!system.sync_problems.length" class="empty">{{ t('sys.none') }}</div>
        <div v-for="p in system.sync_problems" :key="p.name" class="item"><b>{{ p.name }}</b><div class="meta">{{ p.error }}</div></div>
      </div></section>
      <section class="panel"><h2>{{ t('sys.errors') }}</h2><div class="body">
        <div v-if="!system.recent_errors.length" class="empty">{{ t('sys.none') }}</div>
        <div v-for="(e, i) in system.recent_errors" :key="i" class="item"><b>{{ e.action }}</b> <span class="empty">{{ fmt(e.ts, true) }}</span><div class="meta">{{ JSON.stringify(e.details) }}</div></div>
      </div></section>
    </div>
  </template>


  <!-- ======================= BACKUP (v3.10) ======================= -->
  <template v-if="view==='backup' && bk">
    <div v-if="bkResult==='restored'" class="banner ok" data-bk="restored">{{ t('bk.restored') }}</div>
    <div v-if="bkRunning()" class="banner bk-running" data-bk="running"><span class="spin"></span> {{ t('bk.running.' + bkRunning()) }}</div>
    <div v-if="!bk.has_password" class="banner" data-bk="no-password">{{ t('bk.no_pw_banner') }}</div>
    <div class="cards bk-cards">
      <div class="panel card" :class="bk.last_ok ? 'good' : ''"><div class="k">{{ t('bk.last') }}</div>
        <div class="v small">{{ bk.last_ok ? fmt(bk.last_ok.created_at || bk.last_ok.at, true) : t('bk.never') }}</div>
        <div class="hint" v-if="bk.last_ok">{{ size(bk.last_ok.size) }} · {{ t('bk.kind.' + (bk.last_ok.kind || 'manual')) }}</div></div>
      <div class="panel card"><div class="k">{{ t('bk.next') }}</div>
        <div class="v small" data-bk="next">{{ bk.next_run_at ? fmt(bk.next_run_at, true) : t('bk.off') }}</div>
        <div class="hint" v-if="bk.enabled">{{ bk.frequency==='weekly' ? t('bk.weekly') : t('bk.daily') }} · {{ bk.time }}</div></div>
      <div class="panel card" :class="bk.last_error ? 'bad' : ''"><div class="k">{{ t('bk.failed') }}</div>
        <div class="v small">{{ bk.last_error ? fmt(bk.last_error.at, true) : '—' }}</div>
        <div class="hint err" v-if="bk.last_error">{{ bk.last_error.error }}</div></div>
      <div class="panel card"><div class="k">{{ t('bk.disk') }}</div>
        <div class="v small">{{ bk.disk ? size(bk.disk.free) : '—' }}</div>
        <div class="hint">{{ t('bk.size_total', {n: bk.items.length, size: size(bk.total_size)}) }}</div></div>
    </div>

    <div class="bk-grid">
      <section class="panel bk-files">
        <h2>{{ t('bk.files') }}
          <span class="bk-actions">
            <input type="file" ref="bkFile" accept=".zdb,application/octet-stream" style="display:none" @change="doUpload">
            <button class="btn sm" :disabled="busy || bkUpload >= 0 || !!bkRunning()" @click="pickUpload" data-bk="upload">{{ bkUpload >= 0 ? t('bk.uploading', {p: bkUpload}) : t('bk.upload') }}</button>
            <button class="btn sm primary" :disabled="busy || !bk.has_password || !!bkRunning()" @click="createBackup" data-bk="create">{{ t('bk.create') }}</button>
          </span>
        </h2>
        <div class="body">
          <p class="bk-lead">{{ t('bk.lead') }}</p>
          <div v-if="!bk.items.length" class="empty">{{ t('bk.empty') }}</div>
          <div class="table-wrap" v-else><table class="bk-table">
            <thead><tr><th>{{ t('bk.col.date') }}</th><th>{{ t('bk.col.kind') }}</th><th>{{ t('bk.col.size') }}</th><th>{{ t('bk.col.version') }}</th><th>{{ t('bk.col.by') }}</th><th></th></tr></thead>
            <tbody><tr v-for="b in bk.items" :key="b.name" :data-backup="b.name" :class="{muted: !b.ok}">
              <td><b>{{ fmt(b.created_at, true) }}</b><div class="hint mono">{{ b.name }}</div><div class="hint" v-if="b.note">{{ b.kind === 'pre-restore' ? '↩ ' + b.note : b.note }}</div></td>
              <td><span class="tag" :class="'bk-' + b.kind">{{ t('bk.kind.' + (b.kind || 'unknown')) }}</span></td>
              <td class="nowrap bk-meta">{{ size(b.size) }}</td>
              <td class="bk-meta">{{ b.app_version ? 'v' + b.app_version : '—' }}</td>
              <td class="bk-meta">{{ b.created_by || '—' }}</td>
              <td class="bk-row-actions">
                <button class="btn sm" @click="downloadBackup(b)" data-act="download">{{ t('bk.download') }}</button>
                <button class="btn sm" :disabled="!b.ok" @click="openVerify(b)" data-act="verify">{{ t('bk.verify') }}</button>
                <button class="btn sm warn" :disabled="!b.ok || !!bkRunning()" @click="openRestore(b)" data-act="restore">{{ t('bk.restore') }}</button>
                <button class="btn sm danger" :disabled="!!bkRunning()" @click="deleteBackup(b)" data-act="delete">{{ t('bk.delete') }}</button>
              </td>
            </tr></tbody>
          </table></div>
          <div class="hint" style="margin-top:10px">{{ t('bk.folder', {f: bk.folder}) }}</div>
        </div>
      </section>

      <section class="panel bk-settings">
        <h2>{{ t('bk.settings') }}</h2>
        <div class="body">
          <label class="check bk-switch"><input type="checkbox" name="backup_enabled" :checked="bkVal('backup_enabled')" @change="bkSet('backup_enabled', $event.target.checked)"> {{ t('bk.enabled') }}</label>
          <div class="row">
            <div><label>{{ t('bk.frequency') }}</label>
              <select name="backup_frequency" :value="bkVal('backup_frequency')" @change="bkSet('backup_frequency', $event.target.value)">
                <option value="daily">{{ t('bk.daily') }}</option><option value="weekly">{{ t('bk.weekly') }}</option></select></div>
            <div><label>{{ t('bk.time') }}</label><input name="backup_time" type="time" :value="bkVal('backup_time')" @input="bkSet('backup_time', $event.target.value)"></div>
          </div>
          <div class="row">
            <div v-if="bkVal('backup_frequency')==='weekly'"><label>{{ t('bk.weekday') }}</label>
              <select name="backup_weekday" :value="bkVal('backup_weekday')" @change="bkSet('backup_weekday', $event.target.value)">
                <option v-for="(d, i) in ['mon','tue','wed','thu','fri','sat','sun']" :key="d" :value="d">{{ weekdayName(i) }}</option></select></div>
          </div>
          <label>{{ t('bk.keep') }}</label>
          <input class="bk-keep" name="backup_keep" type="number" min="1" max="365" :value="bkVal('backup_keep')" @input="bkSet('backup_keep', $event.target.value)">
          <label>{{ t('bk.password') }}</label>
          <input name="backup_password" type="password" autocomplete="new-password" :value="bkEdits.backup_password || ''" @input="bkSet('backup_password', $event.target.value)"
                 :placeholder="bk.has_password ? t('bk.password_saved') : t('bk.password_none')">
          <div class="hint">{{ t('bk.password_hint') }}</div>
          <div class="hint">{{ t('bk.tz', {tz: bk.timezone}) }}</div>
          <div class="footer"><button class="btn primary" :disabled="busy || !Object.keys(bkEdits).length" @click="saveBackupSettings" data-bk="save">{{ t('bk.save') }}</button></div>
        </div>
      </section>
    </div>
  </template>

  <!-- ======================= MODALS ======================= -->
  <div v-if="modal" class="overlay" @click.self="modal=null">
    <div class="panel modal wide" v-if="modal==='user'">
      <h3>{{ form.id ? t('form.edit_user') : t('form.new_user') }}</h3>
      <div class="row"><div><label>{{ t('form.first_name') }} *</label><input name="first_name" v-model="form.first_name"></div><div><label>{{ t('form.last_name') }}</label><input name="last_name" v-model="form.last_name"></div></div>
      <div class="row"><div><label>{{ t('form.username') }} *</label><input name="username" v-model="form.username" autocomplete="off" autocapitalize="off"><div class="hint">{{ t('form.username_hint') }}</div></div>
        <div><label>{{ t('form.position') }}</label><input name="position" v-model="form.position"></div></div>
      <div class="row"><div><label>{{ t('form.level') }} *</label><select name="level" v-model="form.level" @change="onLevel">
          <option value="" disabled>—</option>
          <option v-for="l in ['level1','level2','level3','manager','admin']" :key="l" :value="l">{{ levelText(l) }}</option></select></div>
        <div></div></div>
      <div class="row"><div><label>{{ t('form.access') }}</label><div class="access" :class="'role-' + form.role">{{ form.level ? t('access.' + form.role) : '—' }}</div></div>
        <div v-if="!form.id"><label>{{ t('form.password') }} *</label><div class="row"><input name="password" v-model="form.password" autocomplete="new-password"><button class="btn" style="flex:0 0 auto" @click="form.password = genPassword()">{{ t('form.generate') }}</button></div><div class="hint">{{ t('form.password_hint') }}</div></div></div>
      <label class="check" v-if="!form.id"><input type="checkbox" v-model="form.must_change_password"> {{ t('form.must_change') }}</label>
      <label class="check"><input name="active" type="checkbox" v-model="form.active"> {{ t('form.active') }}</label>

      <div class="section-title">{{ t('form.section_phone') }}</div>
      <label>{{ t('form.zammad_user') }}</label>
      <div class="linked" v-if="form.zammad_user_id">#{{ form.zammad_user_id }} {{ form.zammad_label || '' }} <button class="btn sm" @click="form.zammad_user_id = null; form.zammad_label = ''">{{ t('form.unlink') }}</button></div>
      <div class="row"><input name="zammad_search" v-model="zq" :placeholder="t('form.zammad_search')" @keyup.enter="searchZammad"><button class="btn zsearch" style="flex:0 0 auto" :disabled="zsearching" @click="searchZammad" aria-label="Search"><ico name="search" style="width:17px;height:17px"></ico></button></div>
      <div v-if="zresults.length" class="zresults"><div v-for="z in zresults" :key="z.id" class="zitem" @click="pickZammad(z)"><b>{{ z.name || z.login }}</b> <span class="empty">{{ z.email }} · #{{ z.id }}</span></div></div>
      <div class="row"><div><label>{{ t('form.extension') }}</label><input name="extension" v-model="form.extension"></div>
        <div><label>{{ t('form.interface') }}</label><div class="row"><input name="asterisk_interface" v-model="form.asterisk_interface"><button class="btn fill-iface" style="flex:0 0 auto" @click="fillInterface">{{ t('form.fill_from_ext') }}</button></div></div></div>
      <div class="hint">{{ t('form.interface_hint') }}</div>
      <label class="check"><input type="checkbox" v-model="form.enabled"> {{ t('form.automation') }}</label>
      <div class="row"><div><label>{{ t('form.sip_user') }}</label><input name="sip_user" v-model="form.sip_user" :placeholder="form.extension" autocomplete="off"></div>
        <div><label>{{ t('form.sip_password') }}</label><input name="sip_password" type="password" v-model="form.sip_password" autocomplete="new-password"
          :placeholder="form.has_sip_password ? t('form.sip_keep') : t('form.sip_none')"></div></div>
      <div class="hint">{{ t('form.sip_hint') }}</div>
      <label v-if="form.has_sip_password" class="check"><input type="checkbox" v-model="form.sip_password_clear"> {{ t('form.sip_clear') }}</label>
      <div class="footer"><button class="btn" @click="modal=null">{{ t('form.cancel') }}</button><button class="btn primary" :disabled="busy || !form.first_name || !form.username || !form.level || (!form.id && (form.password || '').length < 8)" @click="saveUser">{{ t('form.save') }}</button></div>
    </div>

    <div class="panel modal" v-if="modal==='password'">
      <h3>{{ t('form.set_password') }}</h3><div class="empty">{{ form.name }} · {{ form.username }}</div>
      <template v-if="!newPassword">
        <label>{{ t('form.password') }}</label>
        <div class="row"><input v-model="form.password" autocomplete="new-password"><button class="btn" style="flex:0 0 auto" @click="form.password = genPassword()">{{ t('form.generate') }}</button></div>
        <div class="hint">{{ t('form.password_hint') }}</div>
        <label class="check"><input type="checkbox" v-model="form.must_change_password"> {{ t('form.must_change') }}</label>
        <div class="footer"><button class="btn" @click="modal=null">{{ t('form.cancel') }}</button><button class="btn primary" :disabled="busy || form.password.length < 8" @click="savePassword">{{ t('form.save') }}</button></div>
      </template>
      <template v-else>
        <p>{{ t('form.password_set') }}</p>
        <div class="row"><input :value="form.username + ' / ' + newPassword" readonly><button class="btn" style="flex:0 0 auto" @click="copy(newPassword)">{{ t('form.copy') }}</button></div>
        <div class="footer"><button class="btn primary" @click="modal=null">OK</button></div>
      </template>
    </div>

    <div class="panel modal wide" v-if="modal==='type'">
      <h3>{{ form.id ? form.name : t('types.add') }}</h3>
      <div class="row"><div><label>{{ t('types.name') }} *</label><input v-model="form.name"></div><div><label>{{ t('types.value') }} *</label><input v-model="form.zammad_value"></div></div>
      <label class="check"><input type="checkbox" v-model="form.enabled"> {{ t('types.enabled') }}</label>
      <div class="section-title">{{ t('types.fields') }}</div>
      <div v-for="(f, i) in form.required_fields" :key="i" class="field-row">
        <input v-model="f.name" :placeholder="t('types.field_name')">
        <input v-model="f.label" :placeholder="t('types.field_label')">
        <select v-model="f.type"><option value="text">text</option><option value="textarea">textarea</option><option value="select">select</option></select>
        <input v-if="f.type==='select'" v-model="f.options" :placeholder="t('types.field_options')">
        <button class="btn sm danger" @click="form.required_fields.splice(i, 1)">✕</button>
      </div>
      <button class="btn sm" @click="addField">+ {{ t('types.add_field') }}</button>
      <div class="footer"><button class="btn" @click="modal=null">{{ t('form.cancel') }}</button><button class="btn primary" :disabled="busy || !form.name || !form.zammad_value" @click="saveType">{{ t('form.save') }}</button></div>
    </div>

    <div class="panel modal" v-if="modal==='bk-verify'">
      <h3>{{ t('bk.verify_title') }}</h3><div class="empty mono">{{ form.name }}</div>
      <label>{{ t('bk.file_pw') }}</label>
      <input type="password" name="bk-verify-password" v-model="form.password" autocomplete="off" @keyup.enter="form.password && verifyBackup()">
      <div v-if="form.result" class="banner ok" style="margin-top:12px" data-bk="verified">{{ t('bk.verify_ok', {rows: form.result.rows, version: form.result.app_version}) }}</div>
      <div class="footer"><button class="btn" @click="modal=null">{{ t('form.cancel') }}</button><button class="btn primary" :disabled="busy || !form.password" @click="verifyBackup">{{ t('bk.verify') }}</button></div>
    </div>

    <div class="panel modal" v-if="modal==='bk-restore'">
      <h3>{{ t('bk.restore_title') }}</h3>
      <div class="empty mono">{{ form.name }}<span v-if="form.created_at"> · {{ t('bk.date_created', {d: fmt(form.created_at, true)}) }}</span></div>
      <div class="banner error" style="margin-top:12px">{{ t('bk.restore_warn') }}</div>
      <div class="hint">{{ t('bk.restore_safety') }}</div>
      <label>{{ t('bk.file_pw') }}</label>
      <input type="password" name="bk-restore-password" v-model="form.password" autocomplete="off">
      <label>{{ t('bk.type_restore') }}</label>
      <input name="bk-restore-confirm" v-model="form.confirm" autocomplete="off" placeholder="RESTORE">
      <div class="footer"><button class="btn" @click="modal=null">{{ t('form.cancel') }}</button>
        <button class="btn danger-fill" :disabled="busy || !form.password || form.confirm.trim().toUpperCase() !== 'RESTORE'" @click="restoreBackup" data-bk="restore-go">{{ t('bk.restore_go') }}</button></div>
    </div>
  </div>
</div>`,
  };

  return { i18n, component };
})();
