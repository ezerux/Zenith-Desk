/* Zenith Desk v3.9 — e-mail of the employee. The server is configured by the administrator; the employee only signs in
   with e-mail + password. <mail-page>: folders · list (search, unread, flag, attachments) · reading (safe HTML in a
   sandboxed frame, images from the internet only on request, attachments) · reply / reply all / forward / new mail,
   drafts, move, delete, "create a ticket from this e-mail". New mail arrives instantly (IMAP IDLE) — SSE "mail". */
window.ZenithMail = (() => {
  const { reactive, computed, watch, onMounted, onBeforeUnmount, nextTick } = Vue;

  const i18n = {
    en: {
      "nav.mail": "Mail", "ml.title": "Mail", "ml.compose": "New message", "ml.search": "Search in this folder…", "ml.none": "No messages",
      "ml.connect": "Sign in to your mailbox", "ml.connect_sub": "Enter your work e-mail and its password. The mail server is already set up by the administrator.",
      "ml.email": "E-mail", "ml.password": "Password", "ml.signin": "Sign in", "ml.signing": "Checking on the mail server…",
      "ml.not_enabled": "Mail is not set up yet", "ml.not_enabled_sub": "The administrator connects the company mail server in Integrations (API) → E-mail.",
      "ml.signout": "Sign out of the mailbox", "ml.signed_as": "Mailbox", "ml.pick": "Select a message",
      "ml.reply": "Reply", "ml.reply_all": "Reply all", "ml.forward": "Forward", "ml.delete": "Delete", "ml.unread": "Mark unread", "ml.flag": "Flag",
      "ml.move": "Move to…", "ml.ticket": "Create ticket", "ml.ticket_done": "Ticket #{n} created in Zammad", "ml.images": "Show images from the internet",
      "ml.images_hint": "Images from the internet are blocked to protect your privacy.",
      "ml.to": "To", "ml.cc": "Cc", "ml.bcc": "Bcc", "ml.subject": "Subject", "ml.send": "Send", "ml.draft": "Save draft", "ml.discard": "Discard",
      "ml.sent": "Message sent", "ml.saved": "Draft saved", "ml.attach": "Attach files", "ml.from": "From", "ml.date": "Date",
      "ml.f.inbox": "Inbox", "ml.f.sent": "Sent", "ml.f.drafts": "Drafts", "ml.f.trash": "Trash", "ml.f.junk": "Spam", "ml.f.archive": "Archive",
      "ml.new_mail": "New mail from {from}", "ml.page": "{a}–{b} of {n}", "ml.cc_show": "Cc / Bcc", "ml.orig_files": "Attachments of the original",
      "ml.recipient_hint": "Name or e-mail — customers and colleagues are suggested", "ml.realtime": "new mail arrives instantly", "ml.poll": "checked every few minutes",
    },
    ru: {
      "nav.mail": "Почта", "ml.title": "Почта", "ml.compose": "Новое письмо", "ml.search": "Поиск в папке…", "ml.none": "Писем нет",
      "ml.connect": "Вход в почтовый ящик", "ml.connect_sub": "Введите свой рабочий e-mail и пароль от него. Почтовый сервер уже настроен администратором.",
      "ml.email": "E-mail", "ml.password": "Пароль", "ml.signin": "Войти", "ml.signing": "Проверяем на почтовом сервере…",
      "ml.not_enabled": "Почта ещё не настроена", "ml.not_enabled_sub": "Администратор подключает почтовый сервер компании в разделе «Интеграции (API)» → «Почта».",
      "ml.signout": "Выйти из почтового ящика", "ml.signed_as": "Ящик", "ml.pick": "Выберите письмо",
      "ml.reply": "Ответить", "ml.reply_all": "Ответить всем", "ml.forward": "Переслать", "ml.delete": "Удалить", "ml.unread": "Непрочитанное", "ml.flag": "Пометить",
      "ml.move": "Переместить…", "ml.ticket": "Создать тикет", "ml.ticket_done": "Тикет #{n} создан в Zammad", "ml.images": "Показать изображения из интернета",
      "ml.images_hint": "Изображения из интернета скрыты для защиты вашей конфиденциальности.",
      "ml.to": "Кому", "ml.cc": "Копия", "ml.bcc": "Скрытая", "ml.subject": "Тема", "ml.send": "Отправить", "ml.draft": "В черновики", "ml.discard": "Отменить",
      "ml.sent": "Письмо отправлено", "ml.saved": "Черновик сохранён", "ml.attach": "Прикрепить файлы", "ml.from": "От", "ml.date": "Дата",
      "ml.f.inbox": "Входящие", "ml.f.sent": "Отправленные", "ml.f.drafts": "Черновики", "ml.f.trash": "Корзина", "ml.f.junk": "Спам", "ml.f.archive": "Архив",
      "ml.new_mail": "Новое письмо от {from}", "ml.page": "{a}–{b} из {n}", "ml.cc_show": "Копия / скрытая", "ml.orig_files": "Вложения исходного письма",
      "ml.recipient_hint": "Имя или e-mail — подсказываются клиенты и коллеги", "ml.realtime": "новые письма приходят сразу", "ml.poll": "проверка каждые несколько минут",
    },
  };

  const b64url = (s) => btoa(unescape(encodeURIComponent(s))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  const ROLE_ICON = { inbox: "inbox", sent: "send", drafts: "edit", trash: "trash", junk: "ban", archive: "layers", other: "folder" };

  const MailPage = {
    props: ["api", "t", "toast", "fmt", "me", "token"],
    emits: ["open-ticket", "unseen"],
    setup(props, { emit }) {
      const t = props.t;
      const s = reactive({
        acc: null, login: { email: "", password: "" }, busy: false, folders: [], folder: "INBOX", items: [], total: 0, page: 1, q: "",
        loading: false, sel: null, msg: null, images: false, compose: null, sugg: { field: "", items: [] }, moveOpen: false, mobile: "list",
      });
      const frame = { el: null };

      async function account() {
        try { s.acc = await props.api("GET", "/api/mail/account"); } catch (e) { props.toast(e.message, "error"); return; }
        if (s.acc.connected) { await folders(); await list(); }
      }
      async function signIn() {
        s.busy = true;
        try { s.acc = await props.api("POST", "/api/mail/account", s.login); s.login.password = ""; await folders(); await list(); }
        catch (e) { props.toast(e.message, "error"); }
        finally { s.busy = false; }
      }
      async function signOut() {
        if (!confirm(t("ml.signout") + "?")) return;
        s.acc = await props.api("DELETE", "/api/mail/account"); s.folders = []; s.items = []; s.msg = null;
      }
      async function folders() {
        try {
          s.folders = (await props.api("GET", "/api/mail/folders")).folders;
          const inbox = s.folders.find((f) => f.role === "inbox");
          emit("unseen", inbox ? inbox.unseen : 0);
        } catch (e) { props.toast(e.message, "error"); }
      }
      async function list(keep) {
        s.loading = true;
        try {
          const r = await props.api("GET", `/api/mail/folders/${b64url(s.folder)}/messages?page=${s.page}&q=${encodeURIComponent(s.q)}`);
          s.items = r.items; s.total = r.total;
          if (!keep) { s.sel = null; s.msg = null; }
        } catch (e) { props.toast(e.message, "error"); }
        finally { s.loading = false; }
      }
      function openFolder(f) { s.folder = f.name; s.page = 1; s.q = ""; s.mobile = "list"; list(); }
      let qt = null;
      function search() { clearTimeout(qt); qt = setTimeout(() => { s.page = 1; list(); }, 300); }

      async function read(it) {
        if (folderRole.value === "drafts") return editDraft(it);
        s.sel = it.uid; s.images = false; s.moveOpen = false; s.mobile = "read";
        try {
          s.msg = await props.api("GET", `/api/mail/messages/${b64url(s.folder)}/${it.uid}`);
          if (!it.seen) { it.seen = true; folders(); }
          nextTick(render);
        } catch (e) { props.toast(e.message, "error"); }
      }
      function render() {
        const el = frame.el; if (!el || !s.msg) return;
        let html = s.msg.html;
        if (s.images) html = html.replace(/data-src="/g, 'src="');
        const css = "body{font:14px/1.55 -apple-system,Segoe UI,Inter,Arial,sans-serif;color:#1f2937;margin:16px;word-wrap:break-word}img{max-width:100%;height:auto}blockquote{border-left:3px solid #ccd;margin:0;padding-left:12px;color:#556}a{color:#2563eb}table{max-width:100%}";
        el.srcdoc = `<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob: ${s.images ? "https: http:" : ""}; style-src 'unsafe-inline'"><base target="_blank"><style>${css}</style>${html}`;
        el.onload = () => { try { el.style.height = Math.max(200, el.contentDocument.documentElement.scrollHeight + 20) + "px"; } catch { /* sandbox */ } };
      }
      watch(() => s.images, render);

      async function download(a) {
        const r = await fetch(a.url, { headers: { Authorization: `Bearer ${props.token}` } });
        if (!r.ok) { props.toast(t("err.status", { status: r.status }), "error"); return; }
        const url = URL.createObjectURL(await r.blob()), el = document.createElement("a");
        el.href = url; el.download = a.name; document.body.appendChild(el); el.click(); setTimeout(() => { URL.revokeObjectURL(url); el.remove(); }, 1500);
      }

      // ---------------------------------------------------------------- actions
      const uids = () => [s.sel];
      async function act(path, body, after) {
        try { await props.api("POST", path, body); if (after) after(); } catch (e) { props.toast(e.message, "error"); }
      }
      const markUnread = () => act("/api/mail/flags", { folder: b64url(s.folder), uids: uids(), seen: false }, () => { list(); folders(); });
      const flag = () => { const it = s.items.find((x) => x.uid === s.sel); act("/api/mail/flags", { folder: b64url(s.folder), uids: uids(), flagged: !(it && it.flagged) }, () => list(true)); };
      const remove = () => act("/api/mail/delete", { folder: b64url(s.folder), uids: uids() }, () => { s.msg = null; s.sel = null; list(); folders(); });
      const moveTo = (f) => act("/api/mail/move", { folder: b64url(s.folder), uids: uids(), target: b64url(f.name) }, () => { s.msg = null; s.sel = null; s.moveOpen = false; list(); folders(); });
      async function ticket() {
        try {
          const r = await props.api("POST", `/api/mail/messages/${b64url(s.folder)}/${s.sel}/ticket`);
          props.toast(t("ml.ticket_done", { n: r.number || r.ticket_id }));
          emit("open-ticket", r.ticket_id);
        } catch (e) { props.toast(e.message, "error"); }
      }

      // ---------------------------------------------------------------- writing
      const addrText = (list_) => (list_ || []).map((a) => (a.name ? `${a.name} <${a.email}>` : a.email)).join(", ");
      function compose(mode) {
        const base = { to: "", cc: "", bcc: "", subject: "", text: "", files: [], forward_files: [], in_reply_to: "", references: "", draft_uid: null, showCc: false, busy: false };
        if (mode && s.msg) {
          const r = s.msg[mode];
          Object.assign(base, { to: addrText(r.to), cc: addrText(r.cc), subject: r.subject, text: r.text, in_reply_to: r.in_reply_to, references: r.references, showCc: !!(r.cc && r.cc.length) });
          if (mode === "forward") base.forward_files = s.msg.attachments.map((a) => ({ folder: b64url(s.folder), uid: s.msg.uid, idx: a.idx, name: a.name }));
        }
        s.compose = base;
        nextTick(() => { const el = document.querySelector(mode && mode !== "forward" ? ".ml-cbody" : ".ml-cto"); if (el) { el.focus(); if (el.setSelectionRange) el.setSelectionRange(0, 0); } });
      }
      async function editDraft(it) {
        try {
          const m = await props.api("GET", `/api/mail/messages/${b64url(s.folder)}/${it.uid}`);
          s.compose = { to: addrText(m.to), cc: addrText(m.cc), bcc: "", subject: m.subject, text: m.text, files: [], forward_files: [], in_reply_to: "", references: "",
                        draft_uid: it.uid, showCc: !!m.cc.length, busy: false };
        } catch (e) { props.toast(e.message, "error"); }
      }
      function attach(e) {
        for (const file of e.target.files) {
          const rd = new FileReader();
          rd.onload = () => s.compose.files.push({ name: file.name, mime: file.type || "application/octet-stream", size: file.size, data: String(rd.result).split(",")[1] });
          rd.readAsDataURL(file);
        }
        e.target.value = "";
      }
      async function sendMail(draft) {
        const c = s.compose; if (!c || c.busy) return;
        c.busy = true;
        try {
          await props.api("POST", draft ? "/api/mail/draft" : "/api/mail/send", {
            to: c.to, cc: c.cc, bcc: c.bcc, subject: c.subject, text: c.text, files: c.files.map(({ name, mime, data }) => ({ name, mime, data })),
            forward_files: c.forward_files.map(({ folder, uid, idx }) => ({ folder, uid, idx })), in_reply_to: c.in_reply_to, references: c.references, draft_uid: c.draft_uid,
          });
          props.toast(t(draft ? "ml.saved" : "ml.sent"));
          s.compose = null; folders(); list(true);
        } catch (e) { props.toast(e.message, "error"); c.busy = false; }
      }
      // recipient suggestions: Zammad customers and colleagues by name / e-mail
      let st = null;
      function suggest(field) {
        clearTimeout(st);
        const value = s.compose[field], q = value.split(",").pop().trim();
        if (q.length < 2) { s.sugg = { field: "", items: [] }; return; }
        st = setTimeout(async () => {
          try {
            const [c, w] = await Promise.all([props.api("GET", `/api/directory?kind=customers&q=${encodeURIComponent(q)}&limit=6`), props.api("GET", `/api/directory?kind=staff&q=${encodeURIComponent(q)}&limit=4`)]);
            s.sugg = { field, items: [...w.items, ...c.items].filter((u) => u.email).slice(0, 8) };
          } catch { s.sugg = { field: "", items: [] }; }
        }, 180);
      }
      function useSugg(u) {
        const f = s.sugg.field, parts = s.compose[f].split(",").slice(0, -1).map((x) => x.trim()).filter(Boolean);
        parts.push(u.name ? `${u.name} <${u.email}>` : u.email);
        s.compose[f] = parts.join(", ") + ", "; s.sugg = { field: "", items: [] };
      }

      // ---------------------------------------------------------------- live
      const onMail = () => { folders(); if (folderRole.value === "inbox" && s.page === 1 && !s.q) list(true); };
      onMounted(() => { window.addEventListener("zenith:mail", onMail); account(); });
      onBeforeUnmount(() => window.removeEventListener("zenith:mail", onMail));

      const folderRole = computed(() => (s.folders.find((f) => f.name === s.folder) || { role: "inbox" }).role);
      const folderName = (f) => (f.role !== "other" ? t("ml.f." + f.role) : f.display);
      const curItem = computed(() => s.items.find((x) => x.uid === s.sel));
      const who = (it) => {
        const list_ = folderRole.value === "sent" || folderRole.value === "drafts" ? it.to : it.from;
        return (list_ || []).map((a) => a.name || a.email).join(", ") || "—";
      };
      const when = (iso) => {
        if (!iso) return "";
        const d = new Date(iso), now = new Date();
        return d.toDateString() === now.toDateString() ? props.fmt(iso) : props.fmt(iso, true);
      };
      const size = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB");
      const pageText = computed(() => t("ml.page", { a: s.total ? (s.page - 1) * 50 + 1 : 0, b: Math.min(s.page * 50, s.total), n: s.total }));

      return { s, t, frame, signIn, signOut, openFolder, search, read, download, markUnread, flag, remove, moveTo, ticket, compose, attach, sendMail,
        suggest, useSugg, folderRole, folderName, curItem, who, when, size, pageText, list, ROLE_ICON, render };
    },
    template: `
<div class="ml" :class="'show-' + s.mobile">
  <div v-if="s.acc && !s.acc.enabled" class="ml-center"><div class="ml-card"><ico name="mail"></ico><h2>{{ t('ml.not_enabled') }}</h2><p>{{ t('ml.not_enabled_sub') }}</p></div></div>
  <div v-else-if="s.acc && !s.acc.connected" class="ml-center">
    <form class="ml-card" @submit.prevent="signIn" data-mail-login>
      <ico name="mail"></ico><h2>{{ t('ml.connect') }}</h2><p>{{ t('ml.connect_sub') }}</p>
      <label>{{ t('ml.email') }}</label>
      <input v-model="s.login.email" autocomplete="username" :placeholder="s.acc.domain ? 'name@' + s.acc.domain : 'name@company.com'" name="mail-email" required>
      <label>{{ t('ml.password') }}</label>
      <input v-model="s.login.password" type="password" autocomplete="current-password" name="mail-password" required>
      <button class="btn primary" :disabled="s.busy">{{ s.busy ? t('ml.signing') : t('ml.signin') }}</button>
    </form>
  </div>
  <template v-else-if="s.acc">
    <!-- folders -->
    <nav class="ml-folders">
      <button class="btn primary ml-new" @click="compose(null)" data-act="ml-compose"><ico name="edit"></ico><span>{{ t('ml.compose') }}</span></button>
      <button v-for="f in s.folders" :key="f.name" class="ml-folder" :class="{on: f.name===s.folder}" @click="openFolder(f)" :data-folder="f.role">
        <ico :name="ROLE_ICON[f.role] || 'folder'"></ico><span>{{ folderName(f) }}</span><b v-if="f.unseen && f.role!=='sent' && f.role!=='trash'">{{ f.unseen }}</b></button>
      <div class="ml-acc"><small>{{ t('ml.signed_as') }}</small><b>{{ s.acc.email }}</b>
        <small class="ml-rt" :class="{on: s.acc.realtime}">● {{ s.acc.protocol==='imap' ? t('ml.realtime') : t('ml.poll') }}</small>
        <a @click="signOut">{{ t('ml.signout') }}</a></div>
    </nav>
    <!-- list -->
    <section class="ml-list">
      <div class="ml-lh"><input v-model="s.q" @input="search" :placeholder="t('ml.search')" name="ml-search"><span class="ml-pg">{{ pageText }}</span>
        <button class="btn sm" :disabled="s.page<=1" @click="s.page--; list()">‹</button><button class="btn sm" :disabled="s.page*50>=s.total" @click="s.page++; list()">›</button></div>
      <div class="ml-items">
        <div v-if="!s.items.length && !s.loading" class="ib-none">{{ t('ml.none') }}</div>
        <button v-for="it in s.items" :key="it.uid" class="ml-item" :class="{on: it.uid===s.sel, unread: !it.seen}" @click="read(it)" :data-uid="it.uid">
          <span class="ml-r1"><b>{{ who(it) }}</b><small>{{ when(it.date) }}</small></span>
          <span class="ml-r2"><i v-if="it.flagged" class="ml-flag">⚑</i><i v-if="it.has_files">📎</i>{{ it.subject || '—' }}</span>
          <span v-if="it.snippet" class="ml-r3">{{ it.snippet }}</span>
        </button>
      </div>
    </section>
    <!-- reading -->
    <section class="ml-read">
      <div v-if="!s.msg" class="ib-pick"><ico name="mail"></ico><b>{{ t('ml.pick') }}</b></div>
      <template v-else>
        <div class="ml-tools">
          <button class="ib-back" @click="s.mobile='list'" aria-label="Back"><ico name="back"></ico></button>
          <button class="btn sm" @click="compose('reply')" data-act="ml-reply"><ico name="reply"></ico><span>{{ t('ml.reply') }}</span></button>
          <button class="btn sm" @click="compose('reply_all')" data-act="ml-reply-all"><span>{{ t('ml.reply_all') }}</span></button>
          <button class="btn sm" @click="compose('forward')" data-act="ml-forward"><ico name="fwd"></ico><span>{{ t('ml.forward') }}</span></button>
          <span class="spacer"></span>
          <button class="btn sm go" @click="ticket" data-act="ml-ticket"><ico name="ticket"></ico><span>{{ t('ml.ticket') }}</span></button>
          <button class="btn sm" @click="markUnread" :title="t('ml.unread')" data-act="ml-unread">●</button>
          <button class="btn sm" @click="flag" :title="t('ml.flag')" data-act="ml-flag">⚑</button>
          <div class="ib-tr-wrap"><button class="btn sm" @click="s.moveOpen = !s.moveOpen" data-act="ml-move">{{ t('ml.move') }}</button>
            <div v-if="s.moveOpen" class="ib-tr"><button v-for="f in s.folders.filter(f => f.name !== s.folder)" :key="f.name" class="ib-tra" @click="moveTo(f)" :data-target="f.role"><b>{{ folderName(f) }}</b></button></div></div>
          <button class="btn sm danger" @click="remove" :title="t('ml.delete')" data-act="ml-delete"><ico name="trash"></ico></button>
        </div>
        <div class="ml-head">
          <h2>{{ s.msg.subject || '—' }}</h2>
          <div class="ml-from"><b>{{ (s.msg.from[0] || {}).name || (s.msg.from[0] || {}).email }}</b> <span class="mono">&lt;{{ (s.msg.from[0] || {}).email }}&gt;</span><span class="spacer"></span><small>{{ fmt(s.msg.date, true) }}</small></div>
          <div class="ml-to">{{ t('ml.to') }}: {{ s.msg.to.map(a => a.name || a.email).join(', ') }}<template v-if="s.msg.cc.length"> · {{ t('ml.cc') }}: {{ s.msg.cc.map(a => a.name || a.email).join(', ') }}</template></div>
        </div>
        <div v-if="s.msg.remote_images && !s.images" class="ml-imgs">{{ t('ml.images_hint') }} <a @click="s.images = true" data-act="ml-images">{{ t('ml.images') }}</a></div>
        <iframe class="ml-frame" sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox" :ref="(el) => frame.el = el" title="message"></iframe>
        <div v-if="s.msg.attachments.length" class="ml-atts">
          <button v-for="a in s.msg.attachments" :key="a.idx" class="ib-file" @click="download(a)" :data-att="a.idx"><i>{{ (a.name.split('.').pop() || 'file').slice(0,4).toUpperCase() }}</i><span><b>{{ a.name }}</b><small>{{ size(a.size) }}</small></span></button>
        </div>
      </template>
    </section>
  </template>

  <!-- compose -->
  <div v-if="s.compose" class="ml-compose" data-compose>
    <div class="ml-ch"><b>{{ s.compose.subject || t('ml.compose') }}</b><span class="spacer"></span><button class="ib-round" @click="s.compose = null" aria-label="Close"><ico name="close"></ico></button></div>
    <div class="ml-cf"><label>{{ t('ml.to') }}</label><input class="ml-cto" v-model="s.compose.to" @input="suggest('to')" :placeholder="t('ml.recipient_hint')" name="ml-to" autocomplete="off">
      <a v-if="!s.compose.showCc" @click="s.compose.showCc = true">{{ t('ml.cc_show') }}</a></div>
    <template v-if="s.compose.showCc">
      <div class="ml-cf"><label>{{ t('ml.cc') }}</label><input v-model="s.compose.cc" @input="suggest('cc')" name="ml-cc" autocomplete="off"></div>
      <div class="ml-cf"><label>{{ t('ml.bcc') }}</label><input v-model="s.compose.bcc" @input="suggest('bcc')" name="ml-bcc" autocomplete="off"></div>
    </template>
    <div v-if="s.sugg.items.length" class="ml-sugg"><button v-for="u in s.sugg.items" :key="u.id" @mousedown.prevent="useSugg(u)"><b>{{ u.name }}</b><small>{{ u.email }}{{ u.organization ? ' · ' + u.organization : '' }}</small></button></div>
    <div class="ml-cf"><label>{{ t('ml.subject') }}</label><input v-model="s.compose.subject" name="ml-subject"></div>
    <textarea class="ml-cbody" v-model="s.compose.text" name="ml-body"></textarea>
    <div v-if="s.compose.files.length || s.compose.forward_files.length" class="ib-files">
      <span v-for="(f, i) in s.compose.forward_files" :key="'o' + i" class="ib-chip">📎 {{ f.name }} <a @click="s.compose.forward_files.splice(i, 1)">✕</a></span>
      <span v-for="(f, i) in s.compose.files" :key="i" class="ib-chip">📎 {{ f.name }} ({{ size(f.size) }}) <a @click="s.compose.files.splice(i, 1)">✕</a></span>
    </div>
    <div class="ml-cfoot">
      <button class="btn primary" :disabled="s.compose.busy" @click="sendMail(false)" data-act="ml-send"><ico name="send"></ico> {{ t('ml.send') }}</button>
      <label class="btn"><ico name="clip"></ico> {{ t('ml.attach') }}<input type="file" multiple hidden @change="attach"></label>
      <span class="spacer"></span>
      <button class="btn" :disabled="s.compose.busy" @click="sendMail(true)" data-act="ml-draft">{{ t('ml.draft') }}</button>
      <button class="btn" @click="s.compose = null">{{ t('ml.discard') }}</button>
    </div>
  </div>
</div>`,
  };

  return { i18n, MailPage };
})();
