/* Zenith Desk v3.7 — Zenith Phone: a full softphone in the browser (WebRTC to FreePBX / Asterisk via JsSIP),
   laid out like the classic MicroSIP desktop phone, drawn in the Command Center design.

   Phone · Logs · Contacts tabs, number box with history, keypad with R (redial) + C, Call / End, transfer, chat,
   speaker and microphone sliders with mute and a level meter, AC (auto-conference) · AA (auto-answer) · CONF · REC ·
   voicemail, several lines at once (auto-hold, switch, attended transfer, 3-way conference mixed in the browser),
   call recording, Do Not Disturb, device selection, local call log, status bar, pop-out always-on-top window.
   Engines: "webrtc" (real SIP over WSS) and "demo" (simulated calls for the demo server).
   v3.7: the minimized phone lives in the top bar (dialer + DND), a slim call strip under the top bar on every page during a
   call, server-side Do Not Disturb, collapsible controls, keypad on demand, resize from the corner, three window styles
   (classic / compact / side panel) chosen in My settings. */
window.ZenithPhone = (() => {
  const { reactive, computed, onMounted, onBeforeUnmount, nextTick, watch } = Vue;
  const LAYOUTS = ["classic", "compact", "docked"];
  const PREF_DEFAULTS = { layout: "classic", bar: true, strip: true, hideCtl: false, pad: true, scale: 1 };
  const LAYOUT_DEFAULTS = { classic: { pad: true, hideCtl: false }, compact: { pad: false, hideCtl: true }, docked: { pad: true, hideCtl: false } };
  const clampScale = (v) => Math.round(Math.min(1.6, Math.max(0.8, Number(v) || 1)) * 100) / 100;

  const i18n = {
    en: {
      "ph.tb.placeholder": "Number or name…", "ph.tb.no_match": "Nobody found — type a number", "ph.dnd_on": "Do not disturb: turn on",
      "ph.dnd_off": "Do not disturb is on — click to receive calls again", "ph.dnd_on_toast": "Do not disturb is on: no calls will reach you",
      "ph.dnd_off_toast": "Do not disturb is off: you receive calls again", "ph.keypad": "Keypad", "ph.hide_ctl": "Hide", "ph.show_ctl": "Volume & options",
      "ph.resize": "Drag to resize", "ph.strip_open": "Open the phone", "ph.more_lines": "{n} more on hold",
      "ph.set.title": "Phone", "ph.set.layout": "Window style", "ph.lay.classic": "Classic", "ph.lay.classic_d": "The full phone like MicroSIP: keypad, volume, AC · AA · CONF · REC · VM",
      "ph.lay.compact": "Compact", "ph.lay.compact_d": "A narrow window: number, lines and call buttons; keypad and controls open on demand",
      "ph.lay.docked": "Side panel", "ph.lay.docked_d": "Fixed to the right edge — the page moves aside instead of being covered",
      "ph.set.minimize": "When the phone is minimized", "ph.set.min_bar": "Dialer in the top bar", "ph.set.min_btn": "Phone button only",
      "ph.set.strip": "Call strip under the top bar during a call (on every page)", "ph.set.hidectl": "Hide volume sliders and AC · AA · CONF · REC · VM",
      "ph.set.pad": "Show the keypad", "ph.set.size": "Window size", "ph.set.reset": "Reset", "ph.set.dnd": "Do not disturb — no calls at all (queues are paused, the browser phone rejects calls)",
      "ph.set.hint": "These settings are kept on this computer for your account.",
      "ph.title": "Phone", "ph.brand": "Zenith Phone", "ph.tab.phone": "Phone", "ph.tab.logs": "Logs", "ph.tab.contacts": "Contacts",
      "ph.ext": "Ext {ext}", "ph.st.off": "Offline", "ph.st.connecting": "Connecting…", "ph.st.registered": "Online",
      "ph.st.failed": "Not connected", "ph.st.demo": "Online (demo)", "ph.st.other_tab": "Open in another tab", "ph.st.dnd": "Do not disturb",
      "ph.input": "Number or name", "ph.call": "Call", "ph.end": "End", "ph.answer": "Answer", "ph.decline": "Decline",
      "ph.redial": "Redial the last number", "ph.plus": "+ (international)", "ph.clear": "Delete (double click: clear all)",
      "ph.transfer": "Transfer", "ph.chat": "Message (colleague)", "ph.contacts_btn": "Contacts",
      "ph.speaker": "Speaker volume", "ph.mic": "Microphone volume", "ph.mute_spk": "Mute the speaker", "ph.mute_mic": "Mute the microphone",
      "ph.ac": "Auto-conference: a new call joins the current one", "ph.aa": "Auto-answer incoming calls", "ph.conf": "Conference: join all lines",
      "ph.rec": "Record the call", "ph.vm": "Voicemail",
      "ph.hold": "Hold", "ph.resume": "Resume", "ph.mute": "Mute", "ph.unmute": "Unmute", "ph.on_hold": "on hold", "ph.conference": "conference",
      "ph.calling": "Calling…", "ph.ringing": "Incoming…", "ph.line": "Line {n}",
      "ph.tr.title": "Transfer {who}", "ph.tr.to": "Extension or number", "ph.tr.blind": "Transfer", "ph.tr.attended": "Connect with line {n}",
      "ph.tr.cancel": "Cancel",
      "ph.logs.all": "All", "ph.logs.missed": "Missed", "ph.logs.empty": "No calls yet", "ph.logs.clear": "Clear the log",
      "ph.st_in": "incoming", "ph.st_out": "outgoing", "ph.st_missed": "missed", "ph.st_rejected": "rejected", "ph.st_busy": "busy", "ph.st_failed": "failed",
      "ph.ct.search": "Search colleagues and customers…", "ph.ct.colleagues": "Colleagues", "ph.ct.customers": "Customers", "ph.ct.none": "Nobody found",
      "ph.menu.dnd": "Do not disturb", "ph.menu.aa": "Auto-answer", "ph.menu.ac": "Auto-conference", "ph.menu.ring": "Ring sound",
      "ph.menu.mic": "Microphone", "ph.menu.spk": "Speaker", "ph.menu.default": "System default", "ph.menu.popout": "Own window (always on top)",
      "ph.menu.popin": "Back into Zenith Desk", "ph.minimize": "Minimize",
      "ph.use_here": "Use the phone in this tab", "ph.unknown": "Unknown number", "ph.colleague": "Colleague", "ph.customer": "Customer",
      "ph.mic_denied": "Allow the microphone for Zenith Desk in the browser to make calls",
      "ph.problem.disabled": "The phone is switched off by the administrator",
      "ph.problem.no_extension": "You have no extension — ask the administrator",
      "ph.problem.no_server": "The FreePBX WebSocket address is not set (administrator: Integrations → Zenith Phone)",
      "ph.problem.no_password": "The SIP password of your extension is not set (administrator: Users → edit)",
      "ph.failed": "Call failed: {reason}", "ph.transferred": "Call transferred to {to}", "ph.rec_saved": "Recording saved: {file}",
      "ph.dial": "Call {number}", "ph.lines_full": "All lines are busy", "ph.dnd_rejected": "Call from {number} rejected (do not disturb)",
      "ph.incoming": "Incoming call",
    },
    ru: {
      "ph.tb.placeholder": "Номер или имя…", "ph.tb.no_match": "Никого не нашли — введите номер", "ph.dnd_on": "Не беспокоить: включить",
      "ph.dnd_off": "Включено «Не беспокоить» — нажмите, чтобы снова принимать звонки", "ph.dnd_on_toast": "«Не беспокоить» включено: звонки к вам не поступают",
      "ph.dnd_off_toast": "«Не беспокоить» выключено: вы снова принимаете звонки", "ph.keypad": "Клавиатура", "ph.hide_ctl": "Скрыть", "ph.show_ctl": "Громкость и опции",
      "ph.resize": "Потяните, чтобы изменить размер", "ph.strip_open": "Открыть телефон", "ph.more_lines": "ещё {n} на удержании",
      "ph.set.title": "Телефон", "ph.set.layout": "Вид окна", "ph.lay.classic": "Классический", "ph.lay.classic_d": "Полный телефон как MicroSIP: клавиатура, громкость, AC · AA · CONF · REC · VM",
      "ph.lay.compact": "Компактный", "ph.lay.compact_d": "Узкое окно: номер, линии и кнопки звонка; клавиатура и настройки — по кнопке",
      "ph.lay.docked": "Боковая панель", "ph.lay.docked_d": "Закреплён у правого края — страница сдвигается, а не перекрывается",
      "ph.set.minimize": "Когда телефон свёрнут", "ph.set.min_bar": "Набор номера в верхней панели", "ph.set.min_btn": "Только кнопка телефона",
      "ph.set.strip": "Полоса звонка под верхней панелью во время разговора (на всех страницах)", "ph.set.hidectl": "Скрыть громкость и AC · AA · CONF · REC · VM",
      "ph.set.pad": "Показывать клавиатуру", "ph.set.size": "Размер окна", "ph.set.reset": "Сбросить", "ph.set.dnd": "Не беспокоить — никаких звонков (очереди на паузе, телефон в браузере отклоняет вызовы)",
      "ph.set.hint": "Эти настройки хранятся на этом компьютере для вашей учётной записи.",
      "ph.title": "Телефон", "ph.brand": "Zenith Phone", "ph.tab.phone": "Телефон", "ph.tab.logs": "Журнал", "ph.tab.contacts": "Контакты",
      "ph.ext": "Вн. {ext}", "ph.st.off": "Не в сети", "ph.st.connecting": "Подключение…", "ph.st.registered": "В сети",
      "ph.st.failed": "Нет подключения", "ph.st.demo": "В сети (демо)", "ph.st.other_tab": "Открыт в другой вкладке", "ph.st.dnd": "Не беспокоить",
      "ph.input": "Номер или имя", "ph.call": "Позвонить", "ph.end": "Завершить", "ph.answer": "Ответить", "ph.decline": "Отклонить",
      "ph.redial": "Повторить последний номер", "ph.plus": "+ (международный)", "ph.clear": "Стереть (двойной щелчок — всё)",
      "ph.transfer": "Перевести", "ph.chat": "Сообщение (коллеге)", "ph.contacts_btn": "Контакты",
      "ph.speaker": "Громкость динамика", "ph.mic": "Громкость микрофона", "ph.mute_spk": "Выключить звук", "ph.mute_mic": "Выключить микрофон",
      "ph.ac": "Автоконференция: новый звонок присоединяется к текущему", "ph.aa": "Автоответ на входящие", "ph.conf": "Конференция: объединить линии",
      "ph.rec": "Записать разговор", "ph.vm": "Голосовая почта",
      "ph.hold": "Удержание", "ph.resume": "Вернуть", "ph.mute": "Без звука", "ph.unmute": "Включить звук", "ph.on_hold": "на удержании", "ph.conference": "конференция",
      "ph.calling": "Вызов…", "ph.ringing": "Входящий…", "ph.line": "Линия {n}",
      "ph.tr.title": "Перевести: {who}", "ph.tr.to": "Внутренний или номер", "ph.tr.blind": "Перевести", "ph.tr.attended": "Соединить с линией {n}",
      "ph.tr.cancel": "Отмена",
      "ph.logs.all": "Все", "ph.logs.missed": "Пропущенные", "ph.logs.empty": "Звонков пока нет", "ph.logs.clear": "Очистить журнал",
      "ph.st_in": "входящий", "ph.st_out": "исходящий", "ph.st_missed": "пропущен", "ph.st_rejected": "отклонён", "ph.st_busy": "занято", "ph.st_failed": "не удался",
      "ph.ct.search": "Поиск коллег и клиентов…", "ph.ct.colleagues": "Коллеги", "ph.ct.customers": "Клиенты", "ph.ct.none": "Никого не найдено",
      "ph.menu.dnd": "Не беспокоить", "ph.menu.aa": "Автоответ", "ph.menu.ac": "Автоконференция", "ph.menu.ring": "Звук звонка",
      "ph.menu.mic": "Микрофон", "ph.menu.spk": "Динамик", "ph.menu.default": "Системный по умолчанию", "ph.menu.popout": "Отдельное окно (поверх всех)",
      "ph.menu.popin": "Вернуть в Zenith Desk", "ph.minimize": "Свернуть",
      "ph.use_here": "Использовать телефон в этой вкладке", "ph.unknown": "Неизвестный номер", "ph.colleague": "Коллега", "ph.customer": "Клиент",
      "ph.mic_denied": "Разрешите микрофон для Zenith Desk в браузере, чтобы звонить",
      "ph.problem.disabled": "Телефон выключен администратором",
      "ph.problem.no_extension": "У вас нет внутреннего номера — обратитесь к администратору",
      "ph.problem.no_server": "Не задан WebSocket-адрес FreePBX (администратор: Integrations → Zenith Phone)",
      "ph.problem.no_password": "Не задан SIP-пароль вашего номера (администратор: Users → изменить)",
      "ph.failed": "Звонок не удался: {reason}", "ph.transferred": "Звонок переведён: {to}", "ph.rec_saved": "Запись сохранена: {file}",
      "ph.dial": "Позвонить {number}", "ph.lines_full": "Все линии заняты", "ph.dnd_rejected": "Звонок с {number} отклонён (не беспокоить)",
      "ph.incoming": "Входящий звонок",
    },
  };

  const MAX_LINES = 3;
  const loadScript = (src) => new Promise((ok, fail) => {
    if (window.JsSIP) return ok();
    const el = document.createElement("script"); el.src = src; el.onload = ok; el.onerror = () => fail(new Error("JsSIP")); document.head.appendChild(el);
  });

  // ================================================================== audio: mic gain, per-line send mix, conference, recording
  class AudioHub {
    constructor() { this.ctx = null; this.lines = new Map(); this.volume = 0.8; this.spkMuted = false; this.sink = ""; this.micDevice = ""; this.rec = null; }
    async init(deviceId, allowSilent) {
      if (!this.ctx) {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        this.micGain = this.ctx.createGain(); this.micGain.gain.value = 1;
        this.analyser = this.ctx.createAnalyser(); this.analyser.fftSize = 512;
        this.micGain.connect(this.analyser);
        this.buf = new Uint8Array(this.analyser.fftSize);
      }
      if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
      if (this.src && deviceId === this.micDevice) return;
      let stream = null;
      try { stream = await navigator.mediaDevices.getUserMedia({ audio: deviceId ? { deviceId: { exact: deviceId } } : true, video: false }); }
      catch (e) { if (!allowSilent) throw e; }
      if (this.src) { try { this.src.disconnect(); } catch { /* ignore */ } }
      if (this.micStream) this.micStream.getTracks().forEach((x) => x.stop());
      this.micStream = stream; this.micDevice = deviceId || "";
      if (stream) this.src = this.ctx.createMediaStreamSource(stream);
      else { this.src = this.ctx.createConstantSource(); this.src.offset.value = 0; this.src.start(); }  // demo without a microphone
      this.src.connect(this.micGain);
    }
    setMic(level, muted) { if (this.micGain) this.micGain.gain.value = muted ? 0 : level; }
    level() {
      if (!this.analyser) return 0;
      this.analyser.getByteTimeDomainData(this.buf);
      let peak = 0; for (const v of this.buf) peak = Math.max(peak, Math.abs(v - 128));
      return Math.min(1, peak / 64);
    }
    lineStream(id) {
      const dest = this.ctx.createMediaStreamDestination();
      this.micGain.connect(dest);
      this.lines.set(id, { dest, el: null, remote: null });
      return dest.stream;
    }
    attachRemote(id, stream) {
      const l = this.lines.get(id); if (!l) return;
      if (!l.el) { l.el = new Audio(); l.el.autoplay = true; }
      l.el.srcObject = stream; this.applyOut(l.el); l.el.play().catch(() => {});
      try { l.remote = this.ctx.createMediaStreamSource(stream); } catch { l.remote = null; }
      if (this.rec && l.remote) l.remote.connect(this.rec.dest);
      if (this.confIds && this.confIds.includes(id)) this.conference(this.confIds);
    }
    applyOut(el) {
      el.volume = this.spkMuted ? 0 : this.volume;
      if (this.sink && el.setSinkId) el.setSinkId(this.sink).catch(() => {});
    }
    setSpeaker(volume, muted, sink) {
      this.volume = volume; this.spkMuted = muted; if (sink !== undefined) this.sink = sink;
      for (const l of this.lines.values()) if (l.el) this.applyOut(l.el);
    }
    /** Mix every line into every other line's outgoing audio (3-way conference in the browser). */
    conference(ids) {
      for (const [, l] of this.lines) if (l.remote) { try { l.remote.disconnect(); } catch { /* ignore */ } if (this.rec) l.remote.connect(this.rec.dest); }
      this.confIds = ids && ids.length > 1 ? ids.slice() : null;
      if (!this.confIds) return;
      for (const a of this.confIds) for (const b of this.confIds) {
        const la = this.lines.get(a), lb = this.lines.get(b);
        if (a !== b && la && lb && la.remote) la.remote.connect(lb.dest);
      }
    }
    release(id) {
      const l = this.lines.get(id); if (!l) return;
      try { this.micGain.disconnect(l.dest); } catch { /* ignore */ }
      if (l.remote) try { l.remote.disconnect(); } catch { /* ignore */ }
      if (l.el) { l.el.srcObject = null; l.el = null; }
      this.lines.delete(id);
      if (this.confIds) { this.confIds = this.confIds.filter((x) => x !== id); if (this.confIds.length < 2) this.conference(null); }
    }
    startRec() {
      if (this.rec || !this.ctx) return false;
      const dest = this.ctx.createMediaStreamDestination();
      this.micGain.connect(dest);
      for (const l of this.lines.values()) if (l.remote) l.remote.connect(dest);
      const type = ["audio/webm;codecs=opus", "audio/ogg;codecs=opus", "audio/webm"].find((x) => window.MediaRecorder && MediaRecorder.isTypeSupported(x)) || "";
      const rec = new MediaRecorder(dest.stream, type ? { mimeType: type } : undefined);
      const chunks = []; rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      rec.start(1000);
      this.rec = { dest, rec, chunks, type: type || "audio/webm" };
      return true;
    }
    stopRec() {
      const r = this.rec; if (!r) return Promise.resolve(null);
      this.rec = null;
      return new Promise((ok) => {
        r.rec.onstop = () => { try { this.micGain.disconnect(r.dest); } catch { /* ignore */ } ok(new Blob(r.chunks, { type: r.type })); };
        try { r.rec.stop(); } catch { ok(new Blob(r.chunks, { type: r.type })); }
      });
    }
    close() {
      for (const id of [...this.lines.keys()]) this.release(id);
      if (this.micStream) this.micStream.getTracks().forEach((x) => x.stop());
      if (this.ctx) this.ctx.close().catch(() => {});
      this.ctx = null; this.src = null; this.micStream = null;
    }
  }

  // ================================================================== engines (events: status, line, audio, refer)
  let seq = 0;
  const newId = () => "L" + (++seq);

  /** Real SIP over WebSocket (FreePBX / Asterisk PJSIP with WebRTC enabled). */
  class WebRtcEngine {
    constructor(cfg, ev) { this.cfg = cfg; this.ev = ev; this.ua = null; this.sessions = new Map(); }
    async start() {
      await loadScript("/static/vendor/jssip-3.13.8.min.js");
      const JsSIP = window.JsSIP;
      this.ev.status("connecting");
      this.ua = new JsSIP.UA({ sockets: [new JsSIP.WebSocketInterface(this.cfg.wss_url)], uri: this.cfg.sip_uri,
        authorization_user: this.cfg.authorization_user, password: this.cfg.password, display_name: this.cfg.display_name,
        register: true, session_timers: false, user_agent: "Zenith Desk Phone" });
      this.ua.on("registered", () => this.ev.status("registered"));
      this.ua.on("unregistered", () => this.ev.status("off"));
      this.ua.on("registrationFailed", (e) => this.ev.status("failed", e.cause));
      this.ua.on("disconnected", () => this.ev.status("failed", "WebSocket"));
      this.ua.on("newRTCSession", (e) => { if (e.originator === "remote") this.attach(newId(), e.session, true); });
      this.ua.start();
    }
    stop() { for (const s of this.sessions.values()) try { s.terminate(); } catch { /* ignore */ } try { this.ua && this.ua.stop(); } catch { /* ignore */ } this.ua = null; }
    attach(id, session, incoming) {
      this.sessions.set(id, session);
      const uri = session.remote_identity.uri;
      const info = { number: (uri && uri.user) || "", name: session.remote_identity.display_name || "", dir: incoming ? "in" : "out" };
      const media = (pc) => pc.addEventListener("track", (t) => this.ev.audio(id, t.streams[0]));
      if (session.connection) media(session.connection); else session.on("peerconnection", (e) => media(e.peerconnection));
      session.on("confirmed", () => this.ev.line(id, { state: "active" }));
      session.on("hold", (e) => e.originator === "local" && this.ev.line(id, { state: "held" }));
      session.on("unhold", (e) => e.originator === "local" && this.ev.line(id, { state: "active" }));
      const end = (e) => { this.sessions.delete(id); this.ev.line(id, { state: "ended", cause: e && e.cause, originator: e && e.originator }); };
      session.on("ended", end); session.on("failed", end);
      this.ev.line(id, { ...info, state: incoming ? "ringing" : "outgoing" });
    }
    opts(stream) {
      return { mediaStream: stream, mediaConstraints: { audio: true, video: false }, pcConfig: { iceServers: this.cfg.ice_servers || [] },
        rtcOfferConstraints: { offerToReceiveAudio: true, offerToReceiveVideo: false } };
    }
    call(number, stream) { const id = newId(); const session = this.ua.call(number, this.opts(stream)); this.attach(id, session, false); return id; }
    answer(id, stream) { const s = this.sessions.get(id); s && s.answer(this.opts(stream)); }
    reject(id, code = 486) { const s = this.sessions.get(id); try { s && s.terminate({ status_code: code }); } catch { /* ignore */ } }
    hangup(id) { const s = this.sessions.get(id); try { s && s.terminate(); } catch { /* ignore */ } }
    hold(id, on) { const s = this.sessions.get(id); if (!s) return; if (on && !s.isOnHold().local) s.hold(); else if (!on && s.isOnHold().local) s.unhold(); }
    dtmf(id, d) {
      const s = this.sessions.get(id); if (!s) return;
      const sender = s.connection && s.connection.getSenders().find((x) => x.dtmf);
      // RFC 4733 in the media (FreePBX default); SIP INFO when the media path cannot carry it
      s.sendDTMF(d, { transportType: sender && sender.dtmf && sender.dtmf.canInsertDTMF ? "RFC2833" : "INFO" });
    }
    transfer(id, target) {
      const s = this.sessions.get(id); if (!s) return;
      s.refer(target, { eventHandlers: {
        accepted: () => { try { s.terminate(); } catch { /* gone */ } this.ev.refer(id, true, target); },
        failed: (e) => this.ev.refer(id, false, e && e.cause),
      } });
    }
    /** Attended transfer: connect the remote party of line a with the remote party of line b. */
    attended(a, b) {
      const sa = this.sessions.get(a), sb = this.sessions.get(b); if (!sa || !sb) return;
      sa.refer(sb.remote_identity.uri, { replaces: sb, eventHandlers: {
        accepted: () => { for (const x of [sa, sb]) try { x.terminate(); } catch { /* gone */ } this.ev.refer(a, true, sb.remote_identity.uri.user); },
        failed: (e) => this.ev.refer(a, false, e && e.cause),
      } });
    }
  }

  /** Demo server: no PBX. The demo API plays the PBX and feeds the same AMI events a PBX would. */
  class DemoEngine {
    constructor(cfg, ev, post) { this.cfg = cfg; this.ev = ev; this.post = post; this.lines = new Map(); }
    async start() {
      this.ev.status("connecting"); setTimeout(() => this.ev.status("registered"), 300);
      window.addEventListener("zenith:phone_demo", this.onDemo = (e) => this.incoming(e.detail));
      window.addEventListener("zenith:call_update", this.onUpdate = (e) => this.update(e.detail));
    }
    stop() { window.removeEventListener("zenith:phone_demo", this.onDemo); window.removeEventListener("zenith:call_update", this.onUpdate); for (const l of this.lines.values()) clearTimeout(l.timer); }
    async pbx(l, kind, extra = {}) {
      const q = new URLSearchParams({ kind, ext: this.cfg.extension, linkedid: l.link || "", ...extra });
      try { const r = await this.post(`/demo/phone?${q}`); if (r && r.linkedid) l.link = r.linkedid; } catch { /* demo only */ }
    }
    incoming(d) {
      const id = newId(), l = { link: d.linkedid, state: "ringing" };
      this.lines.set(id, l);
      this.ev.line(id, { number: d.number, name: "", dir: "in", state: "ringing" });
      l.timer = setTimeout(() => { if (l.state === "ringing") this.end(id, "Canceled", "remote"); }, 25000);  // the PBX gives up (RONA)
    }
    update(call) {  // like a PBX CANCEL: the caller hung up or the call was taken elsewhere
      for (const [id, l] of this.lines) if (l.state === "ringing" && call && call.linkedid === l.link && ["answered", "ended", "missed"].includes(call.state)) this.end(id, "Canceled", "remote");
    }
    end(id, cause, originator = "local") {
      const l = this.lines.get(id); if (!l) return;
      clearTimeout(l.timer); this.lines.delete(id); this.ev.line(id, { state: "ended", cause, originator });
    }
    call(number) {
      const id = newId(), l = { link: "", state: "outgoing" };
      this.lines.set(id, l);
      this.ev.line(id, { number, name: "", dir: "out", state: "outgoing" });
      (async () => {
        await this.pbx(l, "dial", { number });
        l.timer = setTimeout(async () => {
          if (l.state !== "outgoing") return;
          if (number === "486") { await this.pbx(l, "hangup"); return this.end(id, "Busy", "remote"); }
          l.state = "active"; await this.pbx(l, "answered"); this.ev.line(id, { state: "active" });
        }, 1500);
      })();
      return id;
    }
    async answer(id) { const l = this.lines.get(id); if (!l) return; clearTimeout(l.timer); l.state = "active"; await this.pbx(l, "answer_in"); this.ev.line(id, { state: "active" }); }
    async reject(id) { const l = this.lines.get(id); if (!l) return; await this.pbx(l, "hangup"); this.end(id, "Rejected"); }
    async hangup(id) { const l = this.lines.get(id); if (!l) return; await this.pbx(l, "hangup"); this.end(id, l.state === "ringing" ? "Rejected" : "Terminated"); }
    hold(id, on) { const l = this.lines.get(id); if (!l || l.state === "ringing" || l.state === "outgoing") return; l.state = on ? "held" : "active"; this.ev.line(id, { state: l.state }); }
    dtmf() {}
    async transfer(id, target) { const l = this.lines.get(id); if (!l) return; await this.pbx(l, "hangup"); this.end(id, "Transferred"); this.ev.refer(id, true, target); }
    async attended(a, b) { const lb = this.lines.get(b); await this.transfer(a, ""); if (lb) { await this.pbx(lb, "hangup"); this.end(b, "Transferred"); } }
  }

  // ================================================================== one phone per browser (several tabs)
  const TAB = Math.random().toString(36).slice(2);
  const LOCK = "zenith_phone_owner";
  const readLock = () => { try { return JSON.parse(localStorage.getItem(LOCK) || "null"); } catch { return null; } };
  const writeLock = () => { try { localStorage.setItem(LOCK, JSON.stringify({ id: TAB, ts: Date.now() })); } catch { /* ignore */ } };
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* ignore */ } },
  };

  // ================================================================== component
  const PhoneWidget = {
    props: ["api", "t", "toast", "fmt", "me", "open", "dnd"],
    emits: ["update:open", "state"],
    setup(props, { emit }) {
      const t = props.t;
      const uid = (props.me && props.me.id) || 0;
      const PREFS = `zenith_phone_prefs_${uid}`, LOGK = `zenith_phone_log_${uid}`, SEEN = `zenith_phone_seen_${uid}`;
      const prefs = { ...PREF_DEFAULTS, ...store.get(PREFS, {}) };
      const s = reactive({
        cfg: null, status: "off", reason: "", problem: "", owner: true, now: Date.now(),
        tab: "phone", menu: false, input: "", results: [], sel: 0, history: false,
        lines: [], cur: null, conf: false, rec: false, recStart: 0, trOpen: false, trTo: "", dtmf: "",
        spk: prefs.spk ?? 80, spkMuted: false, mic: prefs.mic ?? 100, micMuted: false, level: 0,
        aa: !!prefs.aa, ac: !!prefs.ac, dnd: !!props.dnd, ring: prefs.ring !== false, micDev: prefs.micDev || "", spkDev: prefs.spkDev || "",
        devices: { mic: [], spk: [] }, log: store.get(LOGK, []), seen: store.get(SEEN, 0), logFilter: "all",
        contacts: [], ctQ: "", ctCustomers: [], pip: null, x: null, y: null,
        layout: LAYOUTS.includes(prefs.layout) ? prefs.layout : "classic", bar: prefs.bar !== false, strip: prefs.strip !== false,
        hideCtl: !!prefs.hideCtl, pad: prefs.pad !== false, scale: clampScale(prefs.scale), vh: innerHeight, vw: innerWidth, stripPad: false,
      });
      const tb = reactive({ input: "", results: [], sel: 0 });  // the dialer in the top bar
      let engine = null, ringTimer = null, ringCtx = null, lockTimer = null, autoOpened = false, raf = 0;
      const hub = new AudioHub();
      hub.setSpeaker(s.spk / 100, false, s.spkDev);

      // ------------------------------------------------------------ lines
      const line = (id) => s.lines.find((l) => l.id === id);
      const current = computed(() => line(s.cur) || s.lines[0] || null);
      const live = (l) => l && (l.state === "active" || l.state === "held");
      const ringingLine = computed(() => s.lines.find((l) => l.state === "ringing") || null);

      const ev = {
        status: (st, reason = "") => { s.status = st; s.reason = reason || ""; emitState(); },
        audio: (id, stream) => hub.attachRemote(id, stream),
        refer: (id, ok, info) => { if (ok) props.toast(t("ph.transferred", { to: info || "" })); else props.toast(t("ph.failed", { reason: info || "REFER" }), "error"); },
        line: (id, patch) => {
          let l = line(id);
          if (!l) {
            if (patch.state === "ended") return;
            l = reactive({ id, number: "", name: "", dir: "out", state: "outgoing", who: null, startedAt: Date.now(), answeredAt: 0, n: nextLineNo() });
            s.lines.push(l);
            if (patch.state === "outgoing" || !s.cur) s.cur = id;
          }
          const prev = l.state;
          if (patch.number && !l.number) l.number = patch.number;
          if (patch.name && !l.name) l.name = patch.name;
          if (patch.dir) l.dir = patch.dir;
          if (patch.state && patch.state !== "ended") l.state = patch.state;
          if (patch.state === "active" && !l.answeredAt) { l.answeredAt = Date.now(); afterAnswered(l); }
          if (patch.state === "ringing" && prev !== "ringing" || (patch.state === "ringing" && !prev)) onIncoming(l);
          if (patch.number && !l.who) whois(l);
          if (patch.state === "ended") onEnded(l, patch.cause, patch.originator);
          if (!ringingLine.value) stopRing();
          emitState();
        },
      };
      let lineNo = 0;
      function nextLineNo() { const used = new Set(s.lines.map((l) => l.n)); for (let n = 1; n <= MAX_LINES + 1; n++) if (!used.has(n)) return n; return ++lineNo; }

      function onIncoming(l) {
        if (s.dnd) { engine && engine.reject(l.id, 486); props.toast(t("ph.dnd_rejected", { number: l.number || "?" })); l.rejected = true; return; }
        if (s.lines.filter((x) => x.state !== "ringing").length >= MAX_LINES) { engine && engine.reject(l.id, 486); l.rejected = true; return; }
        if (!props.open && !s.strip) { autoOpened = true; emit("update:open", true); }
        s.tab = "phone";
        const busy = s.lines.some((x) => x !== l && live(x));
        if (!busy) s.cur = l.id;
        startRing(busy);
        notifyIncoming(l);
        if (s.aa && !busy) setTimeout(() => { if (line(l.id) && l.state === "ringing") answer(l); }, 1000);
      }
      function afterAnswered(l) {
        autoOpened = false;
        if (s.ac && s.lines.filter((x) => live(x)).length > 1) nextTick(() => setConference(true));
      }
      function onEnded(l, cause, originator) {
        const status = l.rejected ? "rejected" : l.answeredAt ? "answered"
          : l.dir === "in" ? (cause === "Rejected" && originator === "local" ? "rejected" : "missed")
          : cause === "Busy" ? "busy" : ["Canceled", "Terminated", "Bye", "BYE"].includes(cause) ? "cancelled" : "failed";
        if (l.dir === "out" && !l.answeredAt && status !== "cancelled") props.toast(t("ph.failed", { reason: cause || "?" }), "error");
        addLog({ number: l.number, name: (l.who && l.who.name) || l.name, dir: l.dir, status, at: l.startedAt, dur: l.answeredAt ? Math.round((Date.now() - l.answeredAt) / 1000) : 0 });
        hub.release(l.id);
        s.lines = s.lines.filter((x) => x.id !== l.id);
        if (s.cur === l.id) s.cur = (s.lines.find((x) => live(x)) || s.lines[0] || {}).id || null;
        if (s.lines.filter((x) => live(x)).length < 2 && s.conf) setConference(false);
        if (!s.lines.length) { s.trOpen = false; s.dtmf = ""; s.stripPad = false; if (s.rec) toggleRec(); }
        if (!s.lines.length && autoOpened) { autoOpened = false; emit("update:open", false); }
      }
      function emitState() {
        const c = current.value;
        emit("state", { status: s.dnd && s.status === "registered" ? "dnd" : s.status, call: c ? c.state : "idle", startedAt: c ? c.answeredAt : 0,
                        name: c ? ((c.who && c.who.name) || c.name || c.number) : "", lines: s.lines.length });
      }

      async function whois(l) {
        if (!l.number) return;
        try { const w = await props.api("GET", `/api/phone/whois?number=${encodeURIComponent(l.number)}`); if (w && w.kind !== "unknown") l.who = w; } catch { /* ignore */ }
      }
      function startRing(waiting) {
        stopRing();
        if (!s.ring) return;
        const beep = () => {
          try {
            ringCtx = ringCtx || new (window.AudioContext || window.webkitAudioContext)();
            (waiting ? [0] : [0, 0.35]).forEach((at) => { const o = ringCtx.createOscillator(), g = ringCtx.createGain(); o.frequency.value = waiting ? 440 : 480; o.connect(g); g.connect(ringCtx.destination);
              g.gain.setValueAtTime(waiting ? 0.05 : 0.12, ringCtx.currentTime + at); g.gain.exponentialRampToValueAtTime(0.001, ringCtx.currentTime + at + 0.3);
              o.start(ringCtx.currentTime + at); o.stop(ringCtx.currentTime + at + 0.31); });
          } catch { /* no audio */ }
        };
        beep(); ringTimer = setInterval(beep, waiting ? 3000 : 2000);
      }
      function stopRing() { clearInterval(ringTimer); ringTimer = null; }
      function notifyIncoming(l) {
        if ((document.hidden || !document.hasFocus()) && !s.pip && window.Notification && Notification.permission === "granted") {
          try { new Notification(t("ph.incoming"), { body: l.number, tag: "zenith-phone" }); } catch { /* ignore */ }
        }
      }

      // ------------------------------------------------------------ log (like MicroSIP: kept on this computer)
      function addLog(e) {
        s.log.unshift({ id: Date.now() + Math.random(), ...e });
        s.log = s.log.slice(0, 200); store.set(LOGK, s.log);
      }
      const missedNew = computed(() => s.log.filter((e) => e.status === "missed" && e.at > s.seen).length);
      const logRows = computed(() => (s.logFilter === "missed" ? s.log.filter((e) => e.status === "missed") : s.log));
      function openTab(tab) {
        s.tab = tab; s.menu = false;
        if (tab === "logs") { s.seen = Date.now(); store.set(SEEN, s.seen); }
        if (tab === "contacts") loadContacts();
      }
      const lastOut = computed(() => (s.log.find((e) => e.dir === "out") || {}).number || "");
      const historyNumbers = computed(() => { const seen = new Set(); return s.log.filter((e) => e.number && !seen.has(e.number) && seen.add(e.number)).slice(0, 10); });

      // ------------------------------------------------------------ lifecycle
      async function boot() {
        try { s.cfg = await props.api("GET", "/api/phone/config"); } catch { return; }
        s.problem = s.cfg.ready ? "" : s.cfg.problem;
        if (!s.cfg.ready) { s.status = "off"; emitState(); return; }
        const lock = readLock();
        if (lock && lock.id !== TAB && Date.now() - lock.ts < 6000) { s.owner = false; s.status = "other_tab"; emitState(); watchLock(); return; }
        await takeOver();
      }
      function watchLock() {
        clearInterval(lockTimer);
        lockTimer = setInterval(() => {
          const lock = readLock();
          if (s.owner) { if (lock && lock.id !== TAB && Date.now() - lock.ts < 6000) { stopEngine(); s.owner = false; s.status = "other_tab"; emitState(); } else writeLock(); }
          else if (!lock || Date.now() - lock.ts > 6000) takeOver();
        }, 2000);
      }
      async function takeOver() {
        writeLock(); s.owner = true; watchLock();
        const post = (path) => props.api("POST", path);
        engine = s.cfg.mode === "demo" ? new DemoEngine(s.cfg, ev, post) : new WebRtcEngine(s.cfg, ev);
        try { await engine.start(); } catch (e) { ev.status("failed", e.message); }
      }
      function stopEngine() { if (engine) { engine.stop(); engine = null; } }
      const unload = () => { const lock = readLock(); if (lock && lock.id === TAB) try { localStorage.removeItem(LOCK); } catch { /* ignore */ } stopEngine(); };

      // ------------------------------------------------------------ audio
      async function ensureAudio() {
        try { await hub.init(s.micDev, s.cfg && s.cfg.mode === "demo"); hub.setMic(s.mic / 100, s.micMuted); listDevices(); return true; }
        catch { props.toast(t("ph.mic_denied"), "error"); return false; }
      }
      async function listDevices() {
        try {
          const all = await navigator.mediaDevices.enumerateDevices();
          s.devices.mic = all.filter((d) => d.kind === "audioinput" && d.deviceId !== "default").map((d, i) => ({ id: d.deviceId, label: d.label || `Mic ${i + 1}` }));
          s.devices.spk = all.filter((d) => d.kind === "audiooutput" && d.deviceId !== "default").map((d, i) => ({ id: d.deviceId, label: d.label || `Speaker ${i + 1}` }));
        } catch { /* ignore */ }
      }
      function savePrefs() {
        store.set(PREFS, { spk: s.spk, mic: s.mic, aa: s.aa, ac: s.ac, ring: s.ring, micDev: s.micDev, spkDev: s.spkDev,
                           layout: s.layout, bar: s.bar, strip: s.strip, hideCtl: s.hideCtl, pad: s.pad, scale: s.scale });
      }
      function loadPrefs() {  // My settings changed the look (same tab or another tab)
        const p = { ...PREF_DEFAULTS, ...store.get(PREFS, {}) };
        Object.assign(s, { layout: LAYOUTS.includes(p.layout) ? p.layout : "classic", bar: p.bar !== false, strip: p.strip !== false,
                           hideCtl: !!p.hideCtl, pad: p.pad !== false, scale: clampScale(p.scale) });
      }
      watch(() => [s.hideCtl, s.pad, s.layout, s.bar, s.strip], savePrefs);
      watch(() => [s.spk, s.spkMuted, s.spkDev], () => { hub.setSpeaker(s.spk / 100, s.spkMuted, s.spkDev); savePrefs(); });
      watch(() => [s.mic, s.micMuted], () => { hub.setMic(s.mic / 100, s.micMuted); savePrefs(); });
      watch(() => s.micDev, async () => { savePrefs(); if (hub.ctx) { try { await hub.init(s.micDev, s.cfg && s.cfg.mode === "demo"); hub.setMic(s.mic / 100, s.micMuted); } catch { props.toast(t("ph.mic_denied"), "error"); } } });
      watch(() => [s.aa, s.ac, s.ring], () => { savePrefs(); emitState(); });
      // ------------------------------------------------------------ Do not disturb (kept on the server: queues are paused too)
      watch(() => props.dnd, (v) => { s.dnd = !!v; emitState(); });
      async function toggleDnd(on) {
        s.dnd = on;
        try {
          const v = await props.api("POST", "/api/agents/me/dnd", { on });
          window.dispatchEvent(new CustomEvent("zenith:agent_state", { detail: v }));
          props.toast(t(on ? "ph.dnd_on_toast" : "ph.dnd_off_toast"));
        } catch (e) { s.dnd = !on; props.toast(e.message, "error"); }
        emitState();
      }
      function meter() {
        if (props.open || s.pip) { const v = hub.level(); s.level = s.level * 0.6 + v * 0.4; }
        raf = requestAnimationFrame(meter);
      }

      // ------------------------------------------------------------ calls
      async function dial(number, name) {
        number = String(number || "").replace(/[^\d+*#]/g, "");
        if (!number || !engine) return;
        if (s.lines.length >= MAX_LINES) { props.toast(t("ph.lines_full"), "error"); return; }
        if (!(await ensureAudio())) return;
        clearTimeout(st); searchSeq++;
        s.input = ""; s.results = []; s.history = false; s.tab = "phone";
        if (!s.conf) for (const l of s.lines) if (l.state === "active") engine.hold(l.id, true);  // auto-hold, like a desk phone
        const tmp = newId();
        try {
          const stream = hub.lineStream(tmp);
          const id = engine.call(number, stream);
          if (id !== tmp) { const l = hub.lines.get(tmp); hub.lines.delete(tmp); hub.lines.set(id, l); }
          const l = line(id); if (l && name && !l.name) l.name = name;
          s.cur = id;
          if (s.ac && s.lines.some((x) => x.id !== id && live(x))) s.conf = true;
        } catch (e) { hub.release(tmp); props.toast(t("ph.failed", { reason: e.message }), "error"); }
      }
      async function answer(l) {
        l = l || ringingLine.value; if (!l || !engine) return;
        if (!(await ensureAudio())) return;
        stopRing();
        if (!s.ac) for (const x of s.lines) if (x !== l && x.state === "active") engine.hold(x.id, true);
        const stream = hub.lineStream(l.id);
        engine.answer(l.id, stream);
        s.cur = l.id;
      }
      function decline(l) { l = l || ringingLine.value; if (l && engine) { l.rejected = true; engine.reject(l.id, 486); } }
      function hangup(l) { l = l || current.value; if (l && engine) engine.hangup(l.id); }
      function callButton() {
        const c = current.value;
        if (c && c.state === "ringing") return answer(c);
        if (s.input.trim()) { const r = s.results[s.sel]; return r && s.results.length ? dial(r.number, r.name) : dial(s.input); }
        if (c) return hangup(c);
        if (lastOut.value) s.input = lastOut.value;  // like MicroSIP: Call with an empty box recalls the last number
      }
      function switchTo(l) {
        if (!engine || s.cur === l.id && l.state !== "held") { s.cur = l.id; return; }
        if (l.state === "ringing") return answer(l);
        if (!s.conf) for (const x of s.lines) if (x !== l && x.state === "active") engine.hold(x.id, true);
        if (l.state === "held") engine.hold(l.id, false);
        s.cur = l.id;
      }
      function toggleHold() { const c = current.value; if (c && engine && live(c)) engine.hold(c.id, c.state === "active"); }
      function setConference(on) {
        const ids = s.lines.filter((l) => live(l)).map((l) => l.id);
        if (on && ids.length < 2) return;
        s.conf = on;
        if (on) for (const id of ids) engine.hold(id, false);
        hub.conference(on ? ids : null);
      }
      async function toggleRec() {
        if (!s.rec) { if (!s.lines.some((l) => live(l))) return; if (hub.startRec()) { s.rec = true; s.recStart = Date.now(); } return; }
        s.rec = false;
        const blob = await hub.stopRec();
        if (!blob) return;
        const c = current.value, num = (c && c.number) || (s.log[0] && s.log[0].number) || "call";
        const d = new Date(), pad = (n) => String(n).padStart(2, "0");
        const file = `call-${num.replace(/[^\d+]/g, "")}-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}.${blob.type.includes("ogg") ? "ogg" : "webm"}`;
        const url = URL.createObjectURL(blob), a = document.createElement("a");
        a.href = url; a.download = file; document.body.appendChild(a); a.click();
        setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 2000);
        props.toast(t("ph.rec_saved", { file }));
      }
      function voicemail() { if (s.cfg && s.cfg.voicemail) dial(s.cfg.voicemail, t("ph.vm")); }
      function key(d) {
        const c = current.value;
        if (c && c.state === "active" && !s.input) { engine && engine.dtmf(c.id, d); s.dtmf = (s.dtmf + d).slice(-16); tone(d); return; }
        s.input += d; search();
      }
      const DTMF_F = { 1: [697, 1209], 2: [697, 1336], 3: [697, 1477], 4: [770, 1209], 5: [770, 1336], 6: [770, 1477], 7: [852, 1209], 8: [852, 1336], 9: [852, 1477], "*": [941, 1209], 0: [941, 1336], "#": [941, 1477] };
      function tone(d) {
        try {
          ringCtx = ringCtx || new (window.AudioContext || window.webkitAudioContext)();
          for (const f of DTMF_F[d] || []) { const o = ringCtx.createOscillator(), g = ringCtx.createGain(); o.frequency.value = f; g.gain.value = 0.04; o.connect(g); g.connect(ringCtx.destination); o.start(); o.stop(ringCtx.currentTime + 0.12); }
        } catch { /* ignore */ }
      }
      function sendDtmf(d) { const c = current.value; if (c && c.state === "active" && engine) { engine.dtmf(c.id, d); s.dtmf = (s.dtmf + d).slice(-16); tone(d); } }
      function backspace() { s.input = s.input.slice(0, -1); search(); }
      function clearAll() { s.input = ""; s.results = []; }
      function openTransfer() {
        const c = current.value;
        if (!c || !live(c)) { openTab("contacts"); return; }
        s.trOpen = !s.trOpen; s.trTo = "";
        nextTick(() => { const i = rootEl() && rootEl().querySelector(".ph-tr input"); if (i) i.focus(); });
      }
      function blindTransfer() { const c = current.value, to = s.trTo.trim(); if (c && to && engine) { engine.transfer(c.id, to); s.trOpen = false; } }
      function attendedTransfer(other) { const c = current.value; if (c && other && engine) { engine.attended(c.id, other.id); s.trOpen = false; } }
      const chatTarget = computed(() => {
        const c = current.value;
        if (c && c.who && c.who.kind === "colleague") return c.who.id;
        const q = s.input.trim(); const m = s.contacts.find((x) => x.number === q && !x.me);
        return m ? m.id : null;
      });
      function openChat() { if (chatTarget.value) window.dispatchEvent(new CustomEvent("zenith:chat", { detail: { id: chatTarget.value } })); }

      // ------------------------------------------------------------ search / contacts
      let st = null, searchSeq = 0;
      function search() {
        clearTimeout(st); s.sel = 0; s.results = []; s.history = false;  // never dial a suggestion that belongs to older text
        const q = s.input.trim(); if (!q) return;
        const my = ++searchSeq;
        st = setTimeout(async () => {
          try { const items = (await props.api("GET", `/api/phone/search?q=${encodeURIComponent(q)}`)).items; if (my === searchSeq && s.input.trim() === q) s.results = items; }
          catch { /* ignore */ }
        }, 150);
      }
      function onInputKey(e) {
        if (e.key === "ArrowDown") { if (!s.results.length && !s.input) { s.history = true; return; } s.sel = Math.min(s.sel + 1, s.results.length - 1); e.preventDefault(); }
        else if (e.key === "ArrowUp") { s.sel = Math.max(s.sel - 1, 0); e.preventDefault(); }
        else if (e.key === "Enter") { e.preventDefault(); callButton(); }
        else if (e.key === "Escape") { s.results = []; s.history = false; }
      }
      async function loadContacts() {
        try { s.contacts = (await props.api("GET", "/api/phone/contacts")).colleagues; } catch { /* ignore */ }
        ctSearch();
      }
      let ct = null;
      function ctSearch() {
        clearTimeout(ct);
        const q = s.ctQ.trim(); if (!q) { s.ctCustomers = []; return; }
        ct = setTimeout(async () => {
          try { s.ctCustomers = (await props.api("GET", `/api/phone/search?q=${encodeURIComponent(q)}`)).items.filter((x) => x.kind === "customer"); } catch { /* ignore */ }
        }, 200);
      }
      const ctColleagues = computed(() => { const q = s.ctQ.trim().toLowerCase(); return s.contacts.filter((c) => !c.me && (!q || (c.name + " " + c.number + " " + c.position).toLowerCase().includes(q))); });

      // ------------------------------------------------------------ top bar dialer (the minimized phone)
      let tbt = null, tbSeq = 0;
      function tbSearch() {
        clearTimeout(tbt); tb.sel = 0; tb.results = [];
        const q = tb.input.trim(); if (!q) return;
        const my = ++tbSeq;
        tbt = setTimeout(async () => {
          try { const items = (await props.api("GET", `/api/phone/search?q=${encodeURIComponent(q)}`)).items; if (my === tbSeq && tb.input.trim() === q) tb.results = items; }
          catch { /* ignore */ }
        }, 150);
      }
      function tbCall(r) {
        const q = tb.input.trim(); if (!q && !r) return;
        r = r || (tb.results.length ? tb.results[tb.sel] : null);
        const digits = q.replace(/[^\d+*#]/g, "");
        if (!r && (!digits || /[a-zа-яё]/i.test(q))) { props.toast(t("ph.tb.no_match"), "error"); return; }
        clearTimeout(tbt); tbSeq++;
        tb.input = ""; tb.results = [];
        if (r) dial(r.number, r.name); else dial(digits);
      }
      function tbKey(e) {
        if (e.key === "ArrowDown") { tb.sel = Math.min(tb.sel + 1, tb.results.length - 1); e.preventDefault(); }
        else if (e.key === "ArrowUp") { tb.sel = Math.max(tb.sel - 1, 0); e.preventDefault(); }
        else if (e.key === "Enter") { e.preventDefault(); tbCall(); }
        else if (e.key === "Escape") { tb.results = []; }
      }
      const tbBlur = () => setTimeout(() => { tb.results = []; }, 200);
      function toggleOpen() { if (s.pip) { try { s.pip.focus(); } catch { /* ignore */ } return; } emit("update:open", !props.open); }
      function stripOpen() { s.tab = "phone"; if (s.pip) { try { s.pip.focus(); } catch { /* ignore */ } return; } emit("update:open", true); }
      function stripTransfer() { stripOpen(); s.trOpen = true; s.trTo = ""; nextTick(() => { const i = rootEl() && rootEl().querySelector(".ph-tr input"); if (i) i.focus(); }); }
      const barStatus = computed(() => (s.problem ? "off" : s.dnd && s.status === "registered" ? "dnd" : s.status));

      // ------------------------------------------------------------ window: drag + pop-out (Document Picture-in-Picture)
      const root = { el: null };
      const rootEl = () => (s.pip ? s.pip.document : root.el);
      const canPip = "documentPictureInPicture" in window;
      async function popOut() {
        s.menu = false;
        if (!canPip || s.pip) return;
        try {
          const pip = await window.documentPictureInPicture.requestWindow({ width: 330, height: 640 });
          for (const link of document.querySelectorAll('link[rel="stylesheet"]')) { const l = pip.document.createElement("link"); l.rel = "stylesheet"; l.href = link.href; pip.document.head.appendChild(l); }
          pip.document.documentElement.dataset.theme = document.documentElement.dataset.theme || "dark";
          pip.document.title = "Zenith Phone";
          pip.document.body.classList.add("ph-pip-body");
          const el = root.el.querySelector(".ph-card"); pip.document.body.appendChild(el);
          s.pip = pip;
          pip.addEventListener("pagehide", () => { const host = root.el; if (host && el) host.appendChild(el); s.pip = null; });
        } catch (e) { props.toast(e.message, "error"); }
      }
      function popIn() { s.menu = false; if (s.pip) s.pip.close(); }
      function dragStart(e) {
        if (s.pip || s.layout === "docked" || e.button !== 0 || e.target.closest("button, input, select")) return;
        const card = root.el.querySelector(".ph-card"), r = card.getBoundingClientRect();
        const dx = e.clientX - r.left, dy = e.clientY - r.top;
        const move = (m) => { s.x = Math.max(4, Math.min(innerWidth - r.width - 4, m.clientX - dx)); s.y = Math.max(4, Math.min(innerHeight - 80, m.clientY - dy)); };
        const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); store.set("zenith_phone_pos", [s.x, s.y]); };
        window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
      }
      // resize from the corner: the whole phone scales (keys, text, sliders), like zooming a desktop window
      function resizeStart(e) {
        if (s.pip || e.button !== 0) return;
        const card = root.el.querySelector(".ph-card"), r = card.getBoundingClientRect();
        if (s.x === null) { s.x = r.left; s.y = r.top; }
        const x0 = e.clientX, y0 = e.clientY, w0 = r.width, h0 = r.height, z0 = s.scale;
        const maxK = (innerWidth - 4 - s.x) / w0;  // never grow past the right edge of the screen
        const move = (m) => { const k = Math.min(maxK, Math.max((w0 + m.clientX - x0) / w0, (h0 + m.clientY - y0) / h0)); s.scale = clampScale(z0 * k); };
        const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); savePrefs(); store.set("zenith_phone_pos", [s.x, s.y]); };
        window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
      }
      const pos = computed(() => {
        if (s.pip) return {};
        const z = s.scale;
        if (s.layout === "docked") return { zoom: z };
        const top = s.x === null ? 80 : s.y;
        const w = (s.layout === "compact" ? 264 : 300) * z;  // keep the whole window on the screen (size set in My settings)
        const left = s.x === null ? 0 : Math.max(4, Math.min(s.x, s.vw - w - 4));
        const at = s.x === null ? { right: 24 / z + "px", top: 80 / z + "px" } : { left: left / z + "px", top: s.y / z + "px", right: "auto" };
        return { ...at, zoom: z, maxHeight: Math.max(320, s.vh - top - 12) / z + "px" };
      });
      // the side panel moves the page aside instead of covering it
      watch(() => [props.open, s.layout, s.pip, s.scale], () => {
        const on = !!(props.open && s.layout === "docked" && !s.pip);
        document.documentElement.classList.toggle("ph-docked", on);
        document.documentElement.style.setProperty("--ph-dock-w", on ? Math.round(320 * s.scale) + "px" : "0px");
      }, { immediate: true });

      // ------------------------------------------------------------ derived for the template
      const clock = (from) => { if (!from) return ""; const sec = Math.max(0, Math.floor((s.now - from) / 1000)); return `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`; };
      const lineTitle = (l) => (l.who && l.who.name) || l.name || l.number || t("ph.unknown");
      const lineState = (l) => (l.state === "ringing" ? t("ph.ringing") : l.state === "outgoing" ? t("ph.calling") : l.state === "held" ? t("ph.on_hold") : s.conf ? t("ph.conference") : clock(l.answeredAt));
      const statusText = computed(() => {
        if (s.problem) return t("ph.problem." + s.problem);
        if (s.status === "registered") return s.dnd ? t("ph.st.dnd") : s.cfg && s.cfg.mode === "demo" ? t("ph.st.demo") : t("ph.st.registered");
        return t("ph.st." + s.status);
      });
      const dotClass = computed(() => (s.problem ? "d-off" : s.status === "registered" && s.dnd ? "d-dnd" : "d-" + s.status));
      const canCall = computed(() => s.status === "registered");
      const callMode = computed(() => { const c = current.value; if (c && c.state === "ringing") return "answer"; if (s.input.trim()) return "call"; return c ? "end" : "call"; });
      const others = computed(() => s.lines.filter((l) => current.value && l.id !== current.value.id && live(l)));
      const fmtDur = (sec) => (sec ? `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}` : "");
      const initials = (n) => (n || "#").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase();
      const KEYS = [["1", ""], ["2", "ABC"], ["3", "DEF"], ["4", "GHI"], ["5", "JKL"], ["6", "MNO"], ["7", "PQRS"], ["8", "TUV"], ["9", "WXYZ"], ["*", ""], ["0", "+"], ["#", ""]];

      // ------------------------------------------------------------ mount
      let tick = null;
      const onDial = (e) => { const d = e.detail || {}; if (!props.open && !s.strip) emit("update:open", true); nextTick(() => dial(d.number, d.name)); };
      const onPrefs = () => loadPrefs();
      const onStorage = (e) => { if (e.key === PREFS) loadPrefs(); };
      const onResize = () => { s.vh = innerHeight; s.vw = innerWidth; };
      const onKey = (e) => {  // typing digits while the phone is open (focus not in another field)
        if (!(props.open || s.pip) || s.tab !== "phone") return;
        const tag = (e.target && e.target.tagName) || "";
        if (["INPUT", "TEXTAREA", "SELECT"].includes(tag) && !(e.target.closest && e.target.closest(".ph-card"))) return;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        if (/^[0-9*#]$/.test(e.key)) { key(e.key); e.preventDefault(); }
        else if (e.key === "Backspace") { backspace(); e.preventDefault(); }
        else if (e.key === "Enter" && (s.input || current.value)) { callButton(); e.preventDefault(); }
      };
      onMounted(() => {
        root.el = document.querySelector(".ph-host");
        const p = store.get("zenith_phone_pos", null); if (p) { s.x = Math.min(p[0], innerWidth - 340); s.y = Math.min(p[1], innerHeight - 120); }
        window.addEventListener("zenith:dial", onDial);
        window.addEventListener("beforeunload", unload);
        window.addEventListener("keydown", onKey);
        window.addEventListener("zenith:phone_prefs", onPrefs); window.addEventListener("storage", onStorage); window.addEventListener("resize", onResize);
        tick = setInterval(() => { s.now = Date.now(); }, 1000);
        raf = requestAnimationFrame(meter);
        boot();
      });
      onBeforeUnmount(() => {
        window.removeEventListener("zenith:dial", onDial); window.removeEventListener("beforeunload", unload); window.removeEventListener("keydown", onKey);
        window.removeEventListener("zenith:phone_prefs", onPrefs); window.removeEventListener("storage", onStorage); window.removeEventListener("resize", onResize);
        document.documentElement.classList.remove("ph-docked");
        clearInterval(tick); clearInterval(lockTimer); cancelAnimationFrame(raf); stopRing(); popIn(); unload(); hub.close();
      });
      watch(() => props.open, (o) => { if (o) { listDevices(); nextTick(() => { const i = root.el && root.el.querySelector(".ph-num input"); if (i && !s.lines.length) i.focus(); }); } });

      return { s, t, current, ringingLine, others, statusText, dotClass, canCall, callMode, missedNew, logRows, historyNumbers, lastOut, chatTarget,
        ctColleagues, KEYS, canPip, pos, dial, answer, decline, hangup, callButton, switchTo, toggleHold, setConference, toggleRec, voicemail, key,
        backspace, clearAll, openTransfer, blindTransfer, attendedTransfer, openChat, search, onInputKey, openTab, loadContacts, ctSearch,
        popOut, popIn, dragStart, takeOver, tb, tbSearch, tbCall, tbKey, tbBlur, toggleOpen, stripOpen, stripTransfer, barStatus, toggleDnd,
        sendDtmf, resizeStart, lineTitle, lineState, clock, fmtDur, initials, live, fmt: props.fmt,
        clearLog: () => { s.log = []; store.set(LOGK, []); }, close: () => { s.menu = false; emit("update:open", false); } };
    },
    template: `
<div class="ph-host">
  <!-- the minimized phone: lives in the top bar (phone button · number or name · call · DND) -->
  <Teleport to="#ph-bar-slot" defer>
    <div class="ph-bar" :class="{'with-dial': s.bar}">
      <button class="phone-btn" :class="['p-' + barStatus, 'c-' + (current ? current.state : 'idle'), {on: open}]" @click="toggleOpen"
              :title="t('ph.title')" :aria-label="t('ph.title')" data-act="phone">
        <ico name="phone"></ico><span class="pb-dot"></span><span class="pb-lbl" v-if="!s.bar || (current && !s.strip)">{{ current ? (current.answeredAt && current.state !== 'held' ? clock(current.answeredAt) : lineState(current)) : t('ph.title') }}</span><span v-if="s.lines.length > 1" class="pb-lines">{{ s.lines.length }}</span></button>
      <div v-if="s.bar" class="ph-tb">
        <input v-model="tb.input" @input="tbSearch" @keydown="tbKey" @blur="tbBlur" :placeholder="t('ph.tb.placeholder')" autocomplete="off" name="ph-tb" data-tb :disabled="!canCall">
        <button class="ph-tbcall" :disabled="!canCall || !tb.input.trim()" @click="tbCall()" :title="t('ph.call')" :aria-label="t('ph.call')" data-act="tb-call"><ico name="phone"></ico></button>
        <div v-if="tb.results.length" class="ph-drop ph-tbdrop">
          <button v-for="(r, i) in tb.results" :key="r.kind + r.number" class="ph-res" :class="{on: i===tb.sel}" @mousedown.prevent="tbCall(r)" @mouseenter="tb.sel=i" :data-kind="r.kind">
            <span class="ph-av" :class="'k-' + r.kind">{{ r.kind==='number' ? '#' : initials(r.name) }}</span>
            <span class="ph-rtext"><b>{{ r.name }}</b><small>{{ [r.kind==='colleague' ? t('ph.colleague') : r.kind==='customer' ? t('ph.customer') : '', r.number !== r.name ? r.number : '', r.detail].filter(Boolean).join(' · ') }}</small></span>
          </button>
        </div>
      </div>
      <button class="ph-dndbtn" :class="{on: s.dnd}" @click="toggleDnd(!s.dnd)" :title="s.dnd ? t('ph.dnd_off') : t('ph.dnd_on')" :aria-label="s.dnd ? t('ph.dnd_off') : t('ph.dnd_on')"
              :aria-pressed="s.dnd ? 'true' : 'false'" data-act="dnd"><ico name="dnd"></ico><span>DND</span></button>
    </div>
  </Teleport>

  <!-- during a call: a slim strip under the top bar on every page; click it to open the phone -->
  <Teleport to="#ph-strip-slot" defer>
    <div v-if="s.strip && current" class="ph-strip" :class="['cs-' + current.state, {muted: s.micMuted}]" @click="stripOpen" :title="t('ph.strip_open')" data-strip role="status">
      <span class="ph-sdot" aria-hidden="true"></span>
      <span class="ph-stext"><b>{{ lineTitle(current) }}</b><small>{{ [lineTitle(current) !== current.number ? current.number : '', current.who && current.who.detail].filter(Boolean).join(' · ') }}</small></span>
      <span class="ph-stime">{{ lineState(current) }}</span>
      <span v-if="s.lines.length > 1" class="ph-smore" :title="t('ph.more_lines', {n: s.lines.length - 1})">+{{ s.lines.length - 1 }}</span>
      <span class="ph-sacts">
        <template v-if="current.state==='ringing'">
          <button class="ph-sb accept wide" @click.stop="answer(current)" data-act="strip-answer"><ico name="phone"></ico>{{ t('ph.answer') }}</button>
          <button class="ph-sb decline" @click.stop="decline(current)" :title="t('ph.decline')" :aria-label="t('ph.decline')" data-act="strip-decline"><ico name="phone"></ico></button>
        </template>
        <template v-else>
          <button class="ph-sb" :class="{on: s.micMuted}" @click.stop="s.micMuted = !s.micMuted" :title="s.micMuted ? t('ph.unmute') : t('ph.mute')" :aria-label="t('ph.mute')" data-act="strip-mute"><ico :name="s.micMuted ? 'micoff' : 'mic'"></ico></button>
          <button class="ph-sb" :class="{on: current.state==='held'}" @click.stop="toggleHold" :disabled="!live(current)" :title="current.state==='held' ? t('ph.resume') : t('ph.hold')" :aria-label="t('ph.hold')" data-act="strip-hold"><ico name="pause"></ico></button>
          <button class="ph-sb" @click.stop="stripTransfer" :disabled="!live(current)" :title="t('ph.transfer')" :aria-label="t('ph.transfer')" data-act="strip-transfer"><ico name="fwd"></ico></button>
          <button class="ph-sb" :class="{on: s.stripPad}" @click.stop="s.stripPad = !s.stripPad" :disabled="current.state!=='active'" :title="t('ph.keypad')" :aria-label="t('ph.keypad')" data-act="strip-keypad"><ico name="grid"></ico></button>
          <button class="ph-sb decline" @click.stop="hangup(current)" :title="t('ph.end')" :aria-label="t('ph.end')" data-act="strip-hangup"><ico name="phone"></ico></button>
        </template>
      </span>
      <div v-if="s.stripPad && current.state==='active'" class="ph-spad" @click.stop>
        <div class="ph-sdtmf mono">{{ s.dtmf || 'DTMF' }}</div>
        <button v-for="k in KEYS" :key="k[0]" class="ph-key" @click="sendDtmf(k[0])" :data-skey="k[0]"><b>{{ k[0] }}</b></button>
      </div>
    </div>
  </Teleport>

  <div class="ph-card" v-show="open || s.pip" :class="[current ? 'ph-' + current.state : 'ph-idle', 'lay-' + s.layout, {pip: s.pip, 'ph-conf': s.conf}]"
       :style="pos" role="dialog" :aria-label="t('ph.title')">
    <header class="ph-head" @pointerdown="dragStart">
      <span class="ph-logo" aria-hidden="true"></span>
      <b class="ph-brand">{{ t('ph.brand') }}</b>
      <span class="spacer"></span>
      <button v-if="!s.pip" class="ph-hbtn" @click="close" :title="t('ph.minimize')" :aria-label="t('ph.minimize')" data-act="minimize"><ico name="minus"></ico></button>
      <button v-else class="ph-hbtn" @click="popIn" :title="t('ph.menu.popin')" :aria-label="t('ph.menu.popin')"><ico name="popin"></ico></button>
    </header>
    <nav class="ph-tabs">
      <button :class="{on: s.tab==='phone'}" @click="openTab('phone')" data-tab="phone">{{ t('ph.tab.phone') }}</button>
      <button :class="{on: s.tab==='logs'}" @click="openTab('logs')" data-tab="logs">{{ t('ph.tab.logs') }}<i v-if="missedNew" class="ph-badge">{{ missedNew }}</i></button>
      <button :class="{on: s.tab==='contacts'}" @click="openTab('contacts')" data-tab="contacts">{{ t('ph.tab.contacts') }}</button>
      <span class="spacer"></span>
      <button class="ph-menu-btn" :class="{on: s.menu}" @click="s.menu = !s.menu" aria-label="Menu" data-act="menu">▾</button>
    </nav>

    <div v-if="s.menu" class="ph-menu">
      <label class="ph-mi"><input type="checkbox" :checked="s.dnd" @change="toggleDnd($event.target.checked)" data-opt="dnd"> {{ t('ph.menu.dnd') }}</label>
      <label class="ph-mi"><input type="checkbox" v-model="s.aa" data-opt="aa"> {{ t('ph.menu.aa') }}</label>
      <label class="ph-mi"><input type="checkbox" v-model="s.ac" data-opt="ac"> {{ t('ph.menu.ac') }}</label>
      <label class="ph-mi"><input type="checkbox" v-model="s.ring"> {{ t('ph.menu.ring') }}</label>
      <label class="ph-ml">{{ t('ph.menu.mic') }}</label>
      <select v-model="s.micDev"><option value="">{{ t('ph.menu.default') }}</option><option v-for="d in s.devices.mic" :key="d.id" :value="d.id">{{ d.label }}</option></select>
      <label class="ph-ml">{{ t('ph.menu.spk') }}</label>
      <select v-model="s.spkDev"><option value="">{{ t('ph.menu.default') }}</option><option v-for="d in s.devices.spk" :key="d.id" :value="d.id">{{ d.label }}</option></select>
      <button v-if="canPip && !s.pip" class="ph-mi ph-mbtn" @click="popOut" data-act="popout"><ico name="popout"></ico> {{ t('ph.menu.popout') }}</button>
      <button v-if="s.pip" class="ph-mi ph-mbtn" @click="popIn"><ico name="popin"></ico> {{ t('ph.menu.popin') }}</button>
    </div>

    <!-- ===================== PHONE ===================== -->
    <section v-show="s.tab==='phone'" class="ph-body">
      <div v-if="s.problem" class="ph-problem">{{ statusText }}</div>
      <div v-else-if="s.status==='other_tab'" class="ph-problem"><p>{{ t('ph.st.other_tab') }}</p><button class="btn sm" @click="takeOver">{{ t('ph.use_here') }}</button></div>
      <template v-else>
        <div v-if="s.lines.length" class="ph-lines">
          <button v-for="l in s.lines" :key="l.id" class="ph-line" :class="['l-' + l.state, {on: current && l.id===current.id}]" @click="switchTo(l)" :data-line="l.n">
            <span class="ph-ln">{{ l.n }}</span>
            <span class="ph-lt"><b>{{ lineTitle(l) }}</b><small>{{ lineState(l) }}</small></span>
            <span v-if="l.state==='ringing'" class="ph-lact">
              <i class="ph-mini accept" @click.stop="answer(l)" :title="t('ph.answer')" data-act="answer"><ico name="phone"></ico></i>
              <i class="ph-mini decline" @click.stop="decline(l)" :title="t('ph.decline')" data-act="decline"><ico name="phone"></ico></i>
            </span>
            <i v-else class="ph-mini decline" @click.stop="hangup(l)" :title="t('ph.end')" data-act="hangup-line"><ico name="phone"></ico></i>
          </button>
        </div>
        <div v-if="current && s.lines.length" class="ph-who-box">
          <div class="ph-who">{{ lineTitle(current) }}</div>
          <div class="ph-sub">{{ [current.who && current.who.name ? current.number : '', current.who && current.who.detail].filter(Boolean).join(' · ') }}</div>
        </div>

        <div class="ph-num" :class="{dtmf: current && current.state==='active' && !s.input}">
          <input v-model="s.input" @input="search" @keydown="onInputKey" :placeholder="current && current.state==='active' ? (s.dtmf || 'DTMF') : t('ph.input')"
                 inputmode="tel" autocomplete="off" name="ph-number" @focus="s.menu=false">
          <button class="ph-hist" @click="s.history = !s.history; s.results = []" :aria-label="t('ph.tab.logs')" tabindex="-1">▾</button>
          <div v-if="s.results.length || (s.history && historyNumbers.length)" class="ph-drop">
            <template v-if="s.results.length">
              <button v-for="(r, i) in s.results" :key="r.kind + r.number" class="ph-res" :class="{on: i===s.sel}" @click="dial(r.number, r.name)" @mouseenter="s.sel=i" :data-kind="r.kind">
                <span class="ph-av" :class="'k-' + r.kind">{{ r.kind==='number' ? '#' : initials(r.name) }}</span>
                <span class="ph-rtext"><b>{{ r.name }}</b><small>{{ [r.kind==='colleague' ? t('ph.colleague') : r.kind==='customer' ? t('ph.customer') : '', r.number !== r.name ? r.number : '', r.detail].filter(Boolean).join(' · ') }}</small></span>
              </button>
            </template>
            <template v-else>
              <button v-for="e in historyNumbers" :key="e.id" class="ph-res" @click="s.input = e.number; s.history = false"><span class="ph-rtext"><b class="mono">{{ e.number }}</b><small>{{ e.name }}</small></span></button>
            </template>
          </div>
        </div>

        <div class="ph-pad" v-if="s.pad">
          <button v-for="k in KEYS" :key="k[0]" class="ph-key" @click="key(k[0])" :data-key="k[0]"><b>{{ k[0] }}</b><small>{{ k[1] || ' ' }}</small></button>
          <button class="ph-key ph-fn" @click="s.input.trim() ? null : lastOut && dial(lastOut)" :disabled="!lastOut || !!s.input.trim()" :title="t('ph.redial')" data-key="R"><b>R</b></button>
          <button class="ph-key ph-fn" @click="s.input += '+'" :title="t('ph.plus')" data-key="+"><b>+</b></button>
          <button class="ph-key ph-fn" @click="backspace" @dblclick="clearAll" :title="t('ph.clear')" data-key="C"><b>C</b></button>
        </div>

        <div class="ph-callrow">
          <button class="ph-side" @click="openTransfer" :class="{on: s.trOpen}" :title="current && live(current) ? t('ph.transfer') : t('ph.contacts_btn')" data-act="transfer"><ico :name="current && live(current) ? 'fwd' : 'users'"></ico></button>
          <button class="ph-callbtn" :class="'m-' + callMode" :disabled="!canCall" @click="callButton" data-act="call">
            <ico name="phone"></ico>{{ callMode==='answer' ? t('ph.answer') : callMode==='end' ? t('ph.end') : t('ph.call') }}</button>
          <button class="ph-side" @click="openChat" :disabled="!chatTarget" :title="t('ph.chat')" data-act="chat"><ico name="chat"></ico></button>
        </div>
        <div v-if="s.trOpen && current" class="ph-tr">
          <div class="ph-trt">{{ t('ph.tr.title', {who: lineTitle(current)}) }}</div>
          <div class="ph-trrow"><input v-model="s.trTo" :placeholder="t('ph.tr.to')" @keydown.enter="blindTransfer" name="ph-transfer">
            <button class="btn sm primary" @click="blindTransfer" :disabled="!s.trTo.trim()" data-act="blind">{{ t('ph.tr.blind') }}</button></div>
          <button v-for="o in others" :key="o.id" class="btn sm ph-att" @click="attendedTransfer(o)" data-act="attended">{{ t('ph.tr.attended', {n: o.n}) }} · {{ lineTitle(o) }}</button>
        </div>

        <div class="ph-incall" v-if="current && live(current)">
          <button :class="{on: current.state==='held'}" @click="toggleHold" data-act="hold"><ico name="pause"></ico>{{ current.state==='held' ? t('ph.resume') : t('ph.hold') }}</button>
          <button :class="{on: s.micMuted}" @click="s.micMuted = !s.micMuted" data-act="mute"><ico :name="s.micMuted ? 'micoff' : 'mic'"></ico>{{ s.micMuted ? t('ph.unmute') : t('ph.mute') }}</button>
        </div>

        <div class="ph-toggles">
          <button class="ph-tg" :class="{on: s.pad}" @click="s.pad = !s.pad" :aria-pressed="s.pad ? 'true' : 'false'" data-act="toggle-pad"><ico name="grid"></ico>{{ t('ph.keypad') }}</button>
          <span class="spacer"></span>
          <button class="ph-tg" @click="s.hideCtl = !s.hideCtl" :aria-expanded="s.hideCtl ? 'false' : 'true'" data-act="toggle-ctl">{{ s.hideCtl ? t('ph.show_ctl') : t('ph.hide_ctl') }}<span class="ph-chev" :class="{up: !s.hideCtl}">▾</span></button>
        </div>
        <template v-if="!s.hideCtl">
        <div class="ph-vol">
          <button class="ph-vbtn" :class="{off: s.spkMuted}" @click="s.spkMuted = !s.spkMuted" :title="t('ph.mute_spk')" data-act="spk-mute"><ico :name="s.spkMuted ? 'spkoff' : 'spk'"></ico></button>
          <input type="range" min="0" max="100" v-model.number="s.spk" :aria-label="t('ph.speaker')" :title="t('ph.speaker')" data-vol="spk">
        </div>
        <div class="ph-vol">
          <button class="ph-vbtn" :class="{off: s.micMuted}" @click="s.micMuted = !s.micMuted" :title="t('ph.mute_mic')" data-act="mic-mute"><ico :name="s.micMuted ? 'micoff' : 'mic'"></ico></button>
          <div class="ph-micwrap"><span class="ph-meter" :style="{width: Math.round((s.micMuted ? 0 : s.level) * 100) + '%'}"></span>
            <input type="range" min="0" max="200" v-model.number="s.mic" :aria-label="t('ph.mic')" :title="t('ph.mic')" data-vol="mic"></div>
        </div>

        <div class="ph-flags">
          <button :class="{on: s.ac}" @click="s.ac = !s.ac" :title="t('ph.ac')" data-flag="ac">AC</button>
          <button :class="{on: s.aa}" @click="s.aa = !s.aa" :title="t('ph.aa')" data-flag="aa">AA</button>
          <button :class="{on: s.conf}" :disabled="s.lines.filter(l => live(l)).length < 2" @click="setConference(!s.conf)" :title="t('ph.conf')" data-flag="conf">CONF</button>
          <button :class="{on: s.rec, rec: s.rec}" :disabled="!s.lines.some(l => live(l))" @click="toggleRec" :title="t('ph.rec')" data-flag="rec">{{ s.rec ? 'REC ' + clock(s.recStart) : 'REC' }}</button>
          <button :disabled="!s.cfg || !s.cfg.voicemail || !canCall" @click="voicemail" :title="t('ph.vm')" data-flag="vm"><ico name="voicemail"></ico></button>
        </div>
        </template>
      </template>
    </section>

    <!-- ===================== LOGS ===================== -->
    <section v-show="s.tab==='logs'" class="ph-body ph-list">
      <div class="ph-seg"><button :class="{on: s.logFilter==='all'}" @click="s.logFilter='all'">{{ t('ph.logs.all') }}</button>
        <button :class="{on: s.logFilter==='missed'}" @click="s.logFilter='missed'" data-filter="missed">{{ t('ph.logs.missed') }}</button>
        <span class="spacer"></span><button v-if="s.log.length" class="ph-link" @click="clearLog">{{ t('ph.logs.clear') }}</button></div>
      <div v-if="!logRows.length" class="ph-none">{{ t('ph.logs.empty') }}</div>
      <button v-for="e in logRows" :key="e.id" class="ph-logrow" :class="'s-' + e.status" @click="dial(e.number, e.name)" :title="t('ph.dial', {number: e.number})">
        <i class="ph-dir">{{ e.dir==='out' ? '↗' : '↙' }}</i>
        <span class="ph-rtext"><b>{{ e.name || e.number }}</b><small>{{ [e.name ? e.number : '', e.status==='answered' ? (e.dir==='out' ? t('ph.st_out') : t('ph.st_in')) : t('ph.st_' + (e.status==='cancelled' ? 'out' : e.status))].filter(Boolean).join(' · ') }}</small></span>
        <span class="ph-when"><small>{{ fmt(new Date(e.at).toISOString(), true) }}</small><small>{{ fmtDur(e.dur) }}</small></span>
      </button>
    </section>

    <!-- ===================== CONTACTS ===================== -->
    <section v-show="s.tab==='contacts'" class="ph-body ph-list">
      <div class="ph-ctsearch"><input v-model="s.ctQ" @input="ctSearch" :placeholder="t('ph.ct.search')" name="ph-ct"></div>
      <h4>{{ t('ph.ct.colleagues') }}</h4>
      <div v-for="c in ctColleagues" :key="'c' + c.id" class="ph-ctrow" :data-colleague="c.number">
        <span class="ph-av k-colleague">{{ initials(c.name) }}<i class="ph-pres" :class="'st-' + c.state"></i></span>
        <span class="ph-rtext"><b>{{ c.name }}</b><small>{{ [c.number, c.position].filter(Boolean).join(' · ') }}</small></span>
        <button class="ph-ctbtn" @click="dial(c.number, c.name)" :title="t('ph.call')" data-act="ct-call"><ico name="phone"></ico></button>
      </div>
      <template v-if="s.ctCustomers.length"><h4>{{ t('ph.ct.customers') }}</h4>
        <div v-for="c in s.ctCustomers" :key="'u' + c.id + c.number" class="ph-ctrow">
          <span class="ph-av k-customer">{{ initials(c.name) }}</span>
          <span class="ph-rtext"><b>{{ c.name }}</b><small>{{ [c.number, c.detail].filter(Boolean).join(' · ') }}</small></span>
          <button class="ph-ctbtn" @click="dial(c.number, c.name)" :title="t('ph.call')"><ico name="phone"></ico></button>
        </div></template>
      <div v-if="!ctColleagues.length && !s.ctCustomers.length" class="ph-none">{{ t('ph.ct.none') }}</div>
    </section>

    <footer class="ph-status">
      <span class="ph-dot" :class="dotClass"></span><span class="ph-stxt" data-status>{{ statusText }}</span>
      <span class="spacer"></span><span class="mono" v-if="s.cfg">{{ s.cfg.extension }}</span>
    </footer>
    <span v-if="!s.pip && s.layout !== 'docked'" class="ph-resize" @pointerdown.prevent="resizeStart" :title="t('ph.resize')" aria-hidden="true" data-act="resize"></span>
  </div>
</div>`,
  };

  // ================================================================== My settings → Phone (v3.7)
  const PhoneSettings = {
    props: ["t", "me", "api", "dnd"],
    setup(props) {
      const KEY = `zenith_phone_prefs_${(props.me && props.me.id) || 0}`;
      const p = reactive({ ...PREF_DEFAULTS, ...store.get(KEY, {}) });
      p.scale = clampScale(p.scale);
      const busy = reactive({ dnd: false });
      function save(patch) {
        Object.assign(p, patch);
        store.set(KEY, { ...store.get(KEY, {}), layout: p.layout, bar: p.bar, strip: p.strip, hideCtl: p.hideCtl, pad: p.pad, scale: p.scale });
        window.dispatchEvent(new CustomEvent("zenith:phone_prefs"));
      }
      const setLayout = (l) => save({ layout: l, ...LAYOUT_DEFAULTS[l] });
      async function setDnd(on) {
        busy.dnd = true;
        try { const v = await props.api("POST", "/api/agents/me/dnd", { on }); window.dispatchEvent(new CustomEvent("zenith:agent_state", { detail: v })); }
        finally { busy.dnd = false; }
      }
      return { p, t: props.t, LAYOUTS, save, setLayout, setDnd, busy };
    },
    template: `
<section class="panel ph-settings" data-phone-settings>
  <h2>{{ t('ph.set.title') }}</h2>
  <div class="body">
    <label>{{ t('ph.set.layout') }}</label>
    <div class="ph-lays">
      <button v-for="l in LAYOUTS" :key="l" class="ph-lay" :class="{on: p.layout===l}" @click="setLayout(l)" :data-layout="l">
        <span class="ph-lay-pic" :class="'pic-' + l" aria-hidden="true"><i class="pg"></i><i class="pp"><em></em><em></em><em></em><em></em><em></em><em></em></i></span>
        <b>{{ t('ph.lay.' + l) }}</b><span v-if="p.layout===l" class="tag ok">✓</span>
        <span class="hint">{{ t('ph.lay.' + l + '_d') }}</span>
      </button>
    </div>
    <label>{{ t('ph.set.minimize') }}</label>
    <div class="seg">
      <button :class="{on: p.bar}" @click="save({bar: true})" data-min="bar">{{ t('ph.set.min_bar') }}</button>
      <button :class="{on: !p.bar}" @click="save({bar: false})" data-min="button">{{ t('ph.set.min_btn') }}</button>
    </div>
    <label class="check"><input type="checkbox" :checked="p.strip" @change="save({strip: $event.target.checked})" name="ph-strip"> {{ t('ph.set.strip') }}</label>
    <label class="check"><input type="checkbox" :checked="p.pad" @change="save({pad: $event.target.checked})" name="ph-pad"> {{ t('ph.set.pad') }}</label>
    <label class="check"><input type="checkbox" :checked="p.hideCtl" @change="save({hideCtl: $event.target.checked})" name="ph-hidectl"> {{ t('ph.set.hidectl') }}</label>
    <label>{{ t('ph.set.size') }} <span class="mono">{{ Math.round(p.scale * 100) }}%</span></label>
    <div class="ph-size"><input type="range" min="0.8" max="1.6" step="0.05" :value="p.scale" @input="save({scale: Number($event.target.value)})" name="ph-scale">
      <button class="btn sm" @click="save({scale: 1})" :disabled="p.scale===1">{{ t('ph.set.reset') }}</button></div>
    <label class="check ph-dndset"><input type="checkbox" :checked="!!dnd" :disabled="busy.dnd" @change="setDnd($event.target.checked)" name="ph-dnd"> {{ t('ph.set.dnd') }}</label>
    <div class="hint">{{ t('ph.set.hint') }}</div>
  </div>
</section>`,
  };

  return { i18n, PhoneWidget, PhoneSettings };
})();
