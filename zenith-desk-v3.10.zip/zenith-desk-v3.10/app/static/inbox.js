/* Zenith Desk v3.9 — chats with customers from Telegram and WhatsApp (one company bot / number for the whole team).
   <inbox-page>: list (channel, Open / Mine / Unassigned / Closed, search) · conversation (bubbles, files, delivery ticks,
   quick replies, internal notes, WhatsApp 24-hour window and templates, take / transfer / close, Start / Background of
   the Zammad ticket) · customer card. Live through the SSE events "msg" and "msg_new". */
window.ZenithInbox = (() => {
  const { reactive, computed, watch, onMounted, onBeforeUnmount, nextTick } = Vue;

  const i18n = {
    en: {
      "nav.whatsapp": "WhatsApp", "nav.telegram": "Telegram", "in.title": "Chats", "in.all": "All",
      "in.view.open": "Open", "in.view.mine": "Mine", "in.view.unassigned": "Unassigned", "in.view.closed": "Closed",
      "in.search": "Name, phone, @username, ticket…", "in.none": "No chats here", "in.pick": "Select a chat on the left",
      "in.pick_sub": "Customers write to the company's WhatsApp number and Telegram bot. Answer here — they get it in their messenger.",
      "in.off": "{ch} is not connected yet", "in.off_sub": "The administrator connects it in Integrations (API) → {ch}.",
      "in.you": "You", "in.note": "Note", "in.unassigned": "unassigned", "in.take": "Take", "in.transfer": "Transfer", "in.release": "Back to the team",
      "in.close": "Close", "in.reopen": "Reopen", "in.call": "Call", "in.start": "Start", "in.background": "Background",
      "in.ticket": "Ticket #{n}", "in.no_ticket": "the ticket appears with the first message", "in.customer": "Customer card",
      "in.placeholder": "Message to {name}…", "in.placeholder_note": "Internal note — the customer does not see it…",
      "in.send": "Send", "in.attach": "Attach", "in.note_toggle": "Internal note", "in.hint": "Enter — send · Shift+Enter — new line",
      "in.window_open": "WhatsApp 24-hour window is open until {t}.",
      "in.window_closed": "More than 24 hours since the customer's last message: WhatsApp allows only an approved template now.",
      "in.template": "Send template", "in.no_templates": "No templates — the administrator adds them in Integrations → WhatsApp.",
      "in.st.queued": "waiting to be sent", "in.st.sent": "sent", "in.st.delivered": "delivered", "in.st.read": "read", "in.st.failed": "not delivered",
      "in.resend": "Send again", "in.taken_by": "{name} answers this chat", "in.assigned": "assigned to {name}", "in.closed_by": "chat closed",
      "in.transfer_to": "Pass the chat to…", "in.tr_done": "Chat passed to {name}", "in.started": "Work started ({mode})",
      "in.new_msg": "{ch}: {name}", "in.open": "Open", "in.more": "Earlier messages", "in.file_failed": "file not received",
      "in.loading": "Loading…", "in.window": "24 h window", "in.handle": "Telegram", "in.phone": "WhatsApp",
      "in.quick": "Quick replies", "in.mirror": "Copied to the Zammad ticket",
    },
    ru: {
      "nav.whatsapp": "WhatsApp", "nav.telegram": "Telegram", "in.title": "Чаты", "in.all": "Все",
      "in.view.open": "Открытые", "in.view.mine": "Мои", "in.view.unassigned": "Свободные", "in.view.closed": "Закрытые",
      "in.search": "Имя, телефон, @username, тикет…", "in.none": "Здесь нет чатов", "in.pick": "Выберите чат слева",
      "in.pick_sub": "Клиенты пишут на номер WhatsApp и в Telegram-бот компании. Отвечайте здесь — ответ придёт им в мессенджер.",
      "in.off": "{ch} ещё не подключён", "in.off_sub": "Администратор подключает его в разделе «Интеграции (API)» → {ch}.",
      "in.you": "Вы", "in.note": "Заметка", "in.unassigned": "свободен", "in.take": "Взять", "in.transfer": "Передать", "in.release": "Вернуть команде",
      "in.close": "Закрыть", "in.reopen": "Открыть снова", "in.call": "Позвонить", "in.start": "Приступить", "in.background": "Фоновая задача",
      "in.ticket": "Тикет #{n}", "in.no_ticket": "тикет появится с первым сообщением", "in.customer": "Карточка клиента",
      "in.placeholder": "Сообщение для {name}…", "in.placeholder_note": "Внутренняя заметка — клиент её не видит…",
      "in.send": "Отправить", "in.attach": "Прикрепить", "in.note_toggle": "Внутренняя заметка", "in.hint": "Enter — отправить · Shift+Enter — новая строка",
      "in.window_open": "Окно WhatsApp 24 часа открыто до {t}.",
      "in.window_closed": "С последнего сообщения клиента прошло больше 24 часов: WhatsApp разрешает только одобренный шаблон.",
      "in.template": "Отправить шаблон", "in.no_templates": "Шаблонов нет — администратор добавляет их в «Интеграции» → WhatsApp.",
      "in.st.queued": "ждёт отправки", "in.st.sent": "отправлено", "in.st.delivered": "доставлено", "in.st.read": "прочитано", "in.st.failed": "не доставлено",
      "in.resend": "Отправить ещё раз", "in.taken_by": "Этот чат ведёт {name}", "in.assigned": "передан: {name}", "in.closed_by": "чат закрыт",
      "in.transfer_to": "Передать чат…", "in.tr_done": "Чат передан: {name}", "in.started": "Работа начата ({mode})",
      "in.new_msg": "{ch}: {name}", "in.open": "Открыть", "in.more": "Ранние сообщения", "in.file_failed": "файл не получен",
      "in.loading": "Загрузка…", "in.window": "окно 24 ч", "in.handle": "Telegram", "in.phone": "WhatsApp",
      "in.quick": "Быстрые ответы", "in.mirror": "Скопировано в тикет Zammad",
    },
  };

  const CH = { whatsapp: "WhatsApp", telegram: "Telegram" };

  const InboxPage = {
    props: ["api", "t", "toast", "fmt", "me", "token", "channel", "openReq"],
    emits: ["open-ticket", "open-customer", "counts"],
    setup(props, { emit }) {
      const t = props.t;
      const s = reactive({
        view: "open", ch: props.channel || "", q: "", items: [], counts: {}, loading: false, sel: null, conv: null, msgs: [], more: false,
        quick: [], templates: [], text: "", note: false, files: [], sending: false, trOpen: false, agents: [], blobs: {}, mobileThread: false,
        tplOpen: false, now: Date.now(),
      });
      const thread = { el: null };

      async function load() {
        s.loading = true;
        try {
          const r = await props.api("GET", `/api/msg/conversations?view=${s.view}&channel=${s.ch}&q=${encodeURIComponent(s.q)}`);
          s.items = r.items; s.counts = r.counts; emit("counts", r.counts);
        } catch (e) { props.toast(e.message, "error"); }
        finally { s.loading = false; }
      }
      let qt = null;
      function search() { clearTimeout(qt); qt = setTimeout(load, 250); }

      async function open(id, keepScroll) {
        if (s.sel !== id) { s.text = ""; s.files = []; s.note = false; s.trOpen = false; s.tplOpen = false; }
        s.sel = id; s.mobileThread = true;
        try {
          const d = await props.api("GET", `/api/msg/conversations/${id}`);
          if (s.sel !== id) return;
          s.conv = d.conversation; s.msgs = d.messages; s.more = d.more; s.quick = d.quick_replies; s.templates = d.templates;
          loadBlobs();
          if (!keepScroll) nextTick(() => scrollEnd());
          if (d.conversation.unread) { await props.api("POST", `/api/msg/conversations/${id}/read`); load(); }
        } catch (e) { props.toast(e.message, "error"); }
      }
      async function older() {
        if (!s.msgs.length) return;
        const el = thread.el, h = el ? el.scrollHeight : 0;
        const d = await props.api("GET", `/api/msg/conversations/${s.sel}?before=${s.msgs[0].id}`);
        s.msgs = [...d.messages, ...s.msgs]; s.more = d.more; loadBlobs();
        nextTick(() => { if (el) el.scrollTop = el.scrollHeight - h; });
      }
      function scrollEnd() { const el = thread.el; if (el) el.scrollTop = el.scrollHeight; }

      // images / audio are loaded with the token (the file URLs are not public)
      async function loadBlobs() {
        for (const m of s.msgs) for (const f of m.files) {
          if (!f.key || s.blobs[f.key] || !/^(image|audio|video)\//.test(f.mime || "")) continue;
          s.blobs[f.key] = "loading";
          try {
            const r = await fetch(`/api/msg/files/${f.key}`, { headers: { Authorization: `Bearer ${props.token}` } });
            s.blobs[f.key] = URL.createObjectURL(await r.blob());
          } catch { delete s.blobs[f.key]; }
        }
      }
      async function download(f) {
        const r = await fetch(`/api/msg/files/${f.key}?download=1`, { headers: { Authorization: `Bearer ${props.token}` } });
        if (!r.ok) { props.toast(t("err.status", { status: r.status }), "error"); return; }
        const url = URL.createObjectURL(await r.blob()), a = document.createElement("a");
        a.href = url; a.download = f.name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1500);
      }

      // ---------------------------------------------------------------- sending
      function pick(e) {
        for (const file of e.target.files) {
          const rd = new FileReader();
          rd.onload = () => s.files.push({ name: file.name, mime: file.type || "application/octet-stream", size: file.size, data: String(rd.result).split(",")[1] });
          rd.readAsDataURL(file);
        }
        e.target.value = "";
      }
      const canSend = computed(() => !s.sending && (s.text.trim() || s.files.length) && (s.note || !s.conv || s.conv.window_open));
      async function send(template) {
        if (!template && !canSend.value) return;
        s.sending = true;
        try {
          const body = template ? { template: `${template.name}:${template.language}` } : { text: s.text, files: s.files.map(({ name, mime, data }) => ({ name, mime, data })), note: s.note };
          const m = await props.api("POST", `/api/msg/conversations/${s.sel}/messages`, body);
          s.msgs.push(m); s.text = ""; s.files = []; s.tplOpen = false;
          nextTick(scrollEnd);
          if (m.status === "failed" || m.status === "queued") props.toast(t("in.st." + m.status) + (m.error ? ": " + m.error : ""), m.status === "failed" ? "error" : undefined);
          open(s.sel, true); load();
        } catch (e) {
          props.toast(e.message === "whatsapp_window" ? t("in.window_closed") : e.message, "error");
        } finally { s.sending = false; }
      }
      function onKey(e) { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } }
      function useQuick(q) { s.text = (s.text ? s.text + " " : "") + q.text.replace(/\{name\}/g, (s.conv && s.conv.name.split(" ")[0]) || ""); }
      async function resend(m) { try { await props.api("POST", `/api/msg/messages/${m.id}/resend`); open(s.sel, true); } catch (e) { props.toast(e.message, "error"); } }

      // ---------------------------------------------------------------- chat actions
      async function assign(agentId, name) {
        try {
          s.conv = await props.api("POST", `/api/msg/conversations/${s.sel}/assign`, { agent_id: agentId });
          s.trOpen = false;
          if (agentId && agentId !== props.me.id) props.toast(t("in.tr_done", { name }));
          load(); open(s.sel, true);
        } catch (e) { props.toast(e.message, "error"); }
      }
      async function openTransfer() {
        s.trOpen = !s.trOpen;
        if (s.trOpen) try { s.agents = (await props.api("GET", "/api/msg/agents")).agents; } catch (e) { props.toast(e.message, "error"); }
      }
      async function setStatus(st) {
        try { s.conv = await props.api("POST", `/api/msg/conversations/${s.sel}/status`, { status: st }); load(); open(s.sel, true); }
        catch (e) { props.toast(e.message, "error"); }
      }
      async function startWork(mode) {
        if (!s.conv || !s.conv.ticket_id) return;
        try {
          await props.api("POST", `/api/tickets/${s.conv.ticket_id}/start`, { work_mode: mode }, { idem: `msg-${s.conv.ticket_id}-${mode}-${Date.now()}` });
          props.toast(t("in.started", { mode: mode === "blocking" ? t("in.start") : t("in.background") }));
        } catch (e) { props.toast(e.message, "error"); }
      }
      function call() { if (s.conv && s.conv.phone && window.zenithDial) window.zenithDial(s.conv.phone, s.conv.name); }

      // ---------------------------------------------------------------- live
      let lt = null;
      const onMsg = (e) => {
        const d = e.detail || {};
        clearTimeout(lt); lt = setTimeout(load, 120);
        if (d.conversation_id && d.conversation_id === s.sel) open(s.sel, d.what !== "message");
      };
      const tick = setInterval(() => { s.now = Date.now(); }, 30000);
      onMounted(() => { window.addEventListener("zenith:msg", onMsg); load(); if (props.openReq && props.openReq.id) open(props.openReq.id); });
      onBeforeUnmount(() => { window.removeEventListener("zenith:msg", onMsg); clearInterval(tick); Object.values(s.blobs).forEach((u) => u && u !== "loading" && URL.revokeObjectURL(u)); });
      watch(() => props.channel, (c) => { s.ch = c || ""; s.sel = null; s.conv = null; s.mobileThread = false; load(); });
      watch(() => props.openReq, (r) => { if (r && r.id) open(r.id); });
      watch(() => [s.view], load);

      // ---------------------------------------------------------------- view helpers
      const initials = (n) => (n || "#").replace(/^[@+]/, "").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase() || "#";
      const when = (iso) => {
        const d = new Date(iso), now = new Date();
        return d.toDateString() === now.toDateString() ? props.fmt(iso) : props.fmt(iso, true);
      };
      const time = (iso) => props.fmt(iso);
      const dayOf = (iso) => new Date(iso).toDateString();
      const ticks = (m) => ({ queued: "🕓", sent: "✓", delivered: "✓✓", read: "✓✓", failed: "⚠" })[m.status] || "";
      const eventText = (m) => {
        if (m.text.startsWith("assigned:")) { const id = +m.text.split(":")[1]; const a = s.agents.find((x) => x.id === id); return t("in.assigned", { name: a ? a.name : (s.conv && s.conv.assignee_name) || "#" + id }); }
        return m.text;
      };
      const mine = computed(() => s.conv && s.conv.assignee_id === props.me.id);
      const takenByOther = computed(() => s.conv && s.conv.assignee_id && s.conv.assignee_id !== props.me.id);
      const windowText = computed(() => s.conv && s.conv.window_until ? new Date(s.conv.window_until).toLocaleString([], { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "");
      const enabledCh = computed(() => (s.counts.enabled || {}));
      const sizeText = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB");

      return { s, t, thread, CH, load, search, open, older, send, onKey, pick, useQuick, resend, assign, openTransfer, setStatus, startWork, call, download,
        initials, when, time, dayOf, ticks, eventText, mine, takenByOther, windowText, enabledCh, sizeText, canSend,
        back: () => { s.mobileThread = false; }, emit };
    },
    template: `
<div class="ib" :class="{'thread-open': s.mobileThread}" :data-channel="s.ch || 'all'">
  <!-- ============ list ============ -->
  <aside class="ib-list">
    <div class="ib-head">
      <h2><span v-if="s.ch" class="ib-chico" :class="s.ch"><ico :name="s.ch==='whatsapp' ? 'wa' : 'tg'"></ico></span>{{ s.ch ? CH[s.ch] : t('in.title') }}</h2>
      <input class="ib-search" v-model="s.q" @input="search" :placeholder="t('in.search')" name="ib-search">
      <div class="ib-tabs">
        <button v-for="v in ['open','mine','unassigned','closed']" :key="v" :class="{on: s.view===v}" @click="s.view=v" :data-view="v">
          {{ t('in.view.' + v) }}<b v-if="v==='mine' && s.counts.mine">{{ s.counts.mine }}</b><b v-if="v==='unassigned' && s.counts.unassigned">{{ s.counts.unassigned }}</b></button>
      </div>
    </div>
    <div v-if="s.ch && enabledCh[s.ch] === false" class="ib-off"><b>{{ t('in.off', {ch: CH[s.ch]}) }}</b><span>{{ t('in.off_sub', {ch: CH[s.ch]}) }}</span></div>
    <div class="ib-items">
      <div v-if="!s.items.length && !s.loading" class="ib-none">{{ t('in.none') }}</div>
      <button v-for="c in s.items" :key="c.id" class="ib-item" :class="{on: c.id===s.sel, unread: c.unread}" @click="open(c.id)" :data-conv="c.id">
        <span class="ib-av">{{ initials(c.name) }}<i class="ib-badge" :class="c.channel"><ico :name="c.channel==='whatsapp' ? 'wa' : 'tg'"></ico></i></span>
        <span class="ib-it">
          <span class="ib-r1"><b>{{ c.name }}</b><small>{{ when(c.last_message_at) }}</small></span>
          <span class="ib-r2">{{ c.last_direction==='out' ? t('in.you') + ': ' : '' }}{{ c.last_text }}</span>
          <span class="ib-r3"><span v-if="c.ticket_number" class="ib-chip">#{{ c.ticket_number }}</span>
            <span v-if="c.assignee_id" class="ib-chip" :class="{me: c.assignee_id===me.id}">{{ c.assignee_id===me.id ? t('in.view.mine') : c.assignee_name }}</span>
            <span v-else-if="c.status==='open'" class="ib-chip new">{{ t('in.unassigned') }}</span>
            <span v-if="c.unread" class="ib-unread">{{ c.unread }}</span></span>
        </span>
      </button>
    </div>
  </aside>

  <!-- ============ conversation ============ -->
  <section class="ib-thread">
    <div v-if="!s.conv" class="ib-pick"><ico name="chat"></ico><b>{{ t('in.pick') }}</b><span>{{ t('in.pick_sub') }}</span></div>
    <template v-else>
      <header class="ib-th">
        <button class="ib-back" @click="back" aria-label="Back"><ico name="back"></ico></button>
        <span class="ib-av">{{ initials(s.conv.name) }}<i class="ib-badge" :class="s.conv.channel"><ico :name="s.conv.channel==='whatsapp' ? 'wa' : 'tg'"></ico></i></span>
        <div class="ib-tht"><b>{{ s.conv.name }}</b>
          <small>{{ [CH[s.conv.channel], s.conv.handle || s.conv.phone, s.conv.ticket_number ? t('in.ticket', {n: s.conv.ticket_number}) : t('in.no_ticket')].filter(Boolean).join(' · ') }}</small></div>
        <div class="ib-acts">
          <button v-if="s.conv.phone" class="btn sm" @click="call" data-act="in-call"><ico name="phone"></ico><span>{{ t('in.call') }}</span></button>
          <button v-if="!mine && s.conv.status==='open'" class="btn sm" @click="assign(me.id, me.name)" data-act="in-take">{{ t('in.take') }}</button>
          <div class="ib-tr-wrap">
            <button class="btn sm" @click="openTransfer" data-act="in-transfer"><ico name="users"></ico><span>{{ t('in.transfer') }}</span></button>
            <div v-if="s.trOpen" class="ib-tr">
              <div class="ib-trt">{{ t('in.transfer_to') }}</div>
              <button v-for="a in s.agents.filter(x => !x.me)" :key="a.id" class="ib-tra" @click="assign(a.id, a.name)" :data-agent="a.id">
                <i class="ib-pres" :class="'st-' + a.state"></i><b>{{ a.name }}</b><small>{{ a.position }}</small></button>
              <button v-if="s.conv.assignee_id" class="ib-tra" @click="assign(null, '')"><b>{{ t('in.release') }}</b></button>
            </div>
          </div>
          <button v-if="s.conv.ticket_id" class="btn sm go" @click="startWork('blocking')" data-act="in-start">{{ t('in.start') }}</button>
          <button v-if="s.conv.ticket_id" class="btn sm" @click="startWork('background')" data-act="in-bg">{{ t('in.background') }}</button>
          <button v-if="s.conv.status==='open'" class="btn sm" @click="setStatus('closed')" data-act="in-close">{{ t('in.close') }}</button>
          <button v-else class="btn sm" @click="setStatus('open')" data-act="in-reopen">{{ t('in.reopen') }}</button>
        </div>
      </header>
      <div v-if="s.conv.channel==='whatsapp'" class="ib-window" :class="{closed: !s.conv.window_open}">
        <ico name="wa"></ico><span>{{ s.conv.window_open ? t('in.window_open', {t: windowText}) : t('in.window_closed') }}</span></div>
      <div v-if="takenByOther" class="ib-taken">{{ t('in.taken_by', {name: s.conv.assignee_name}) }}</div>

      <div class="ib-msgs" :ref="(el) => thread.el = el">
        <button v-if="s.more" class="btn sm ib-older" @click="older">{{ t('in.more') }}</button>
        <template v-for="(m, i) in s.msgs" :key="m.id">
          <div v-if="i===0 || dayOf(m.created_at) !== dayOf(s.msgs[i-1].created_at)" class="ib-day">{{ new Date(m.created_at).toLocaleDateString() }}</div>
          <div v-if="m.direction==='event'" class="ib-event">{{ eventText(m) }} · {{ time(m.created_at) }}</div>
          <div v-else class="ib-b" :class="m.direction" :data-dir="m.direction">
            <div v-if="m.direction!=='in'" class="ib-who">{{ m.direction==='note' ? t('in.note') + ' · ' : '' }}{{ m.author_name }}</div>
            <template v-for="f in m.files" :key="f.key || f.name">
              <img v-if="f.key && /^image\\//.test(f.mime) && s.blobs[f.key] && s.blobs[f.key]!=='loading'" :src="s.blobs[f.key]" class="ib-img" :alt="f.name" @click="download(f)">
              <audio v-else-if="f.key && /^audio\\//.test(f.mime) && s.blobs[f.key] && s.blobs[f.key]!=='loading'" :src="s.blobs[f.key]" controls class="ib-audio"></audio>
              <button v-else-if="f.key" class="ib-file" @click="download(f)"><i>{{ (f.name.split('.').pop() || 'file').slice(0,4).toUpperCase() }}</i><span><b>{{ f.name }}</b><small>{{ sizeText(f.size) }}</small></span></button>
              <div v-else-if="f.pending" class="ib-file pending"><i>…</i><span><b>{{ f.name }}</b><small>{{ t('in.loading') }}</small></span></div>
              <div v-else class="ib-file bad"><i>!</i><span><b>{{ f.name }}</b><small>{{ t('in.file_failed') }}</small></span></div>
            </template>
            <div v-if="m.text" class="ib-text">{{ m.text }}</div>
            <div class="ib-meta"><span>{{ time(m.created_at) }}</span>
              <span v-if="m.direction==='out'" class="ib-tick" :class="'s-' + m.status" :title="t('in.st.' + m.status) + (m.error ? ': ' + m.error : '')">{{ ticks(m) }}</span></div>
            <button v-if="m.direction==='out' && m.status==='failed'" class="ib-resend" @click="resend(m)">{{ t('in.resend') }}</button>
          </div>
        </template>
      </div>

      <footer class="ib-comp" :class="{note: s.note}">
        <div v-if="s.quick.length" class="ib-quick"><button v-for="q in s.quick" :key="q.title" @click="useQuick(q)">⚡ {{ q.title }}</button></div>
        <div v-if="s.files.length" class="ib-files"><span v-for="(f, i) in s.files" :key="i" class="ib-chip">📎 {{ f.name }} <a @click="s.files.splice(i, 1)">✕</a></span></div>
        <div v-if="s.conv.channel==='whatsapp' && !s.conv.window_open && !s.note" class="ib-tpl">
          <span v-if="!s.templates.length">{{ t('in.no_templates') }}</span>
          <button v-for="tp in s.templates" :key="tp.name" class="btn sm primary" @click="send(tp)" :disabled="s.sending" data-act="in-template">{{ t('in.template') }}: {{ tp.name }} ({{ tp.language }})</button>
        </div>
        <div class="ib-inp">
          <label class="ib-round" :title="t('in.attach')"><ico name="clip"></ico><input type="file" multiple hidden @change="pick"></label>
          <button class="ib-round" :class="{on: s.note}" @click="s.note = !s.note" :title="t('in.note_toggle')" data-act="in-note"><ico name="note"></ico></button>
          <textarea v-model="s.text" @keydown="onKey" rows="1" :placeholder="s.note ? t('in.placeholder_note') : t('in.placeholder', {name: s.conv.name})" name="ib-text"
                    :disabled="s.conv.channel==='whatsapp' && !s.conv.window_open && !s.note"></textarea>
          <button class="ib-round send" :disabled="!canSend" @click="send()" :title="t('in.send')" data-act="in-send"><ico name="send"></ico></button>
        </div>
        <div class="ib-hint">{{ s.note ? t('in.placeholder_note') : t('in.hint') }}</div>
      </footer>
    </template>
  </section>

  <!-- ============ customer ============ -->
  <aside class="ib-side" v-if="s.conv">
    <div class="ib-card">
      <div class="ib-cbig"><span class="ib-av lg">{{ initials(s.conv.name) }}</span><div><b>{{ s.conv.name }}</b><small>{{ CH[s.conv.channel] }}</small></div></div>
      <dl>
        <template v-if="s.conv.handle && s.conv.channel==='telegram'"><dt>{{ t('in.handle') }}</dt><dd>{{ s.conv.handle }}</dd></template>
        <template v-if="s.conv.phone"><dt>{{ t('in.phone') }}</dt><dd class="mono">{{ s.conv.phone }}</dd></template>
        <template v-if="s.conv.ticket_number"><dt>Zammad</dt><dd><a @click="emit('open-ticket', s.conv.ticket_id)" class="mono">#{{ s.conv.ticket_number }}</a></dd></template>
      </dl>
      <button v-if="s.conv.customer_id" class="btn sm" @click="emit('open-customer', s.conv.customer_id)">{{ t('in.customer') }}</button>
      <p class="hint">{{ t('in.mirror') }}</p>
    </div>
  </aside>
</div>`,
  };

  return { i18n, InboxPage };
})();
