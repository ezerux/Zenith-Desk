/* Zenith Desk v3.3 — ticketing inside Zenith Desk (Zammad stays the system of record) and the read-only directory
   of Zammad customers and staff. Two components: <tickets-page> and <contacts-page>. */
window.AgentixTickets = (() => {
  const { reactive, computed, watch, onMounted, onBeforeUnmount, nextTick } = Vue;

  const i18n = {
    en: {
      "nav.tickets": "Tickets", "nav.contacts": "Customers",
      "tk.view.mine": "Mine", "tk.view.unassigned": "Unassigned", "tk.view.all": "All open", "tk.view.closed": "Closed",
      "tk.search": "Search by number, title, text…", "tk.f.state": "Any state", "tk.f.priority": "Any priority", "tk.f.group": "Any group",
      "tk.new": "New ticket", "tk.count": "{n} tickets", "tk.more": "Show more", "tk.none": "No tickets here", "tk.loading": "Loading…",
      "tk.pick": "Select a ticket on the left", "tk.pick_sub": "Everything you do here is saved in Zammad at once — in your name.",
      "tk.cat.new": "new", "tk.cat.open": "open", "tk.cat.pending": "waiting", "tk.cat.closed": "closed",
      "tk.unassigned": "unassigned", "tk.in_work": "in work", "tk.in_bg": "background",
      "tk.state": "State", "tk.priority": "Priority", "tk.group": "Group", "tk.owner": "Owner", "tk.customer": "Customer",
      "tk.created": "Created", "tk.updated": "Updated", "tk.pending_until": "Waiting until", "tk.days": "days",
      "tk.transfer": "Transfer", "tk.take": "Take it", "tk.open_zammad": "Open in Zammad", "tk.props": "Details",
      "tk.work": "Work", "tk.start": "Start", "tk.background": "Background", "tk.complete": "Complete",
      "tk.note": "Internal note", "tk.reply": "Reply to customer", "tk.public_note": "Public note",
      "tk.reply_via": "via {ch}", "tk.reply_to": "to {to}",
      "tk.placeholder.note": "Note for colleagues — the customer does not see it…",
      "tk.placeholder.reply": "Answer to the customer…",
      "tk.attach": "Attach files", "tk.send": "Send", "tk.send_hint": "Ctrl+Enter", "tk.and_state": "and set state",
      "tk.keep_state": "keep state", "tk.sent": "Saved in Zammad", "tk.updated_toast": "Ticket updated",
      "tk.internal": "internal", "tk.empty_thread": "No messages yet",
      "tk.edit_title": "Click to edit the title", "tk.download": "Download",
      "tk.tr.title": "Transfer ticket #{n}", "tk.tr.hint": "Colleagues with full access to the group in Zammad.",
      "tk.tr.search": "Find a colleague…", "tk.tr.nobody": "Unassigned (for the team)", "tk.tr.note": "Comment for the colleague (internal note)",
      "tk.tr.go": "Transfer", "tk.tr.done": "Ticket transferred to {name}", "tk.tr.me": "you", "tk.tr.owner": "owner now",
      "tk.tr.none": "Nobody found. The list comes from Zammad users with access to this group.",
      "tk.tr.group": "Move to group", "tk.tr.keep_group": "keep the group",
      "tk.nw.title": "New ticket", "tk.nw.customer": "Customer", "tk.nw.find": "Name, phone or e-mail…", "tk.nw.subject": "Subject",
      "tk.nw.body": "Description", "tk.nw.assign": "Assign to me", "tk.nw.create": "Create", "tk.nw.create_start": "Create and start",
      "tk.nw.state": "State", "tk.nw.type": "Type", "tk.nw.created": "Ticket #{n} created", "tk.nw.need_customer": "Choose a customer",
      "tk.nw.no_customer": "Nobody found — customers are added in Zammad.",
      "tk.gone": "The ticket moved to a group you have no access to", "tk.owner_reset": "The owner had no access to the new group — the ticket is now unassigned",
      "tk.changed_by_other": "Updated just now",
      "tk.not_linked": "Your account is not linked to a Zammad user — ask the administrator.",
      "tk.assigned_toast": "{by} transferred ticket #{n} to you", "tk.assigned_open": "Open",
      "ct.customers": "Customers", "ct.staff": "Zammad users", "ct.search": "Search by name, phone, e-mail, company…",
      "ct.readonly": "Customers and users are created and edited in Zammad — Zenith Desk shows them automatically.",
      "ct.synced": "Synced {t}", "ct.sync": "Sync now", "ct.syncing": "Syncing…", "ct.never": "not synced yet",
      "ct.pick": "Select a person on the left", "ct.tickets": "Tickets", "ct.no_tickets": "No tickets",
      "ct.new_ticket": "New ticket", "ct.org": "Company", "ct.email": "E-mail", "ct.phone": "Phone", "ct.mobile": "Mobile",
      "ct.note": "Note", "ct.groups": "Groups", "ct.roles": "Roles", "ct.since": "In Zammad since", "ct.inactive": "inactive",
      "ct.new_toast": "New in Zammad: {name}", "ct.none": "Nobody found", "ct.more": "Show more",
    },
    ru: {
      "nav.tickets": "Тикеты", "nav.contacts": "Клиенты",
      "tk.view.mine": "Мои", "tk.view.unassigned": "Свободные", "tk.view.all": "Все открытые", "tk.view.closed": "Закрытые",
      "tk.search": "Поиск по номеру, теме, тексту…", "tk.f.state": "Любой статус", "tk.f.priority": "Любой приоритет", "tk.f.group": "Любая группа",
      "tk.new": "Новый тикет", "tk.count": "Тикетов: {n}", "tk.more": "Показать ещё", "tk.none": "Здесь нет тикетов", "tk.loading": "Загрузка…",
      "tk.pick": "Выберите тикет слева", "tk.pick_sub": "Всё, что вы делаете здесь, сразу сохраняется в Zammad — от вашего имени.",
      "tk.cat.new": "новый", "tk.cat.open": "открыт", "tk.cat.pending": "ожидание", "tk.cat.closed": "закрыт",
      "tk.unassigned": "не назначен", "tk.in_work": "в работе", "tk.in_bg": "фоном",
      "tk.state": "Статус", "tk.priority": "Приоритет", "tk.group": "Группа", "tk.owner": "Ответственный", "tk.customer": "Клиент",
      "tk.created": "Создан", "tk.updated": "Изменён", "tk.pending_until": "Ожидание до", "tk.days": "дн.",
      "tk.transfer": "Передать", "tk.take": "Взять себе", "tk.open_zammad": "Открыть в Zammad", "tk.props": "Свойства",
      "tk.work": "Работа", "tk.start": "Приступить", "tk.background": "Фоновая задача", "tk.complete": "Завершить",
      "tk.note": "Внутренняя заметка", "tk.reply": "Ответ клиенту", "tk.public_note": "Публичная заметка",
      "tk.reply_via": "через {ch}", "tk.reply_to": "кому: {to}",
      "tk.placeholder.note": "Заметка для коллег — клиент её не видит…",
      "tk.placeholder.reply": "Ответ клиенту…",
      "tk.attach": "Прикрепить файлы", "tk.send": "Отправить", "tk.send_hint": "Ctrl+Enter", "tk.and_state": "и сменить статус",
      "tk.keep_state": "не менять статус", "tk.sent": "Сохранено в Zammad", "tk.updated_toast": "Тикет изменён",
      "tk.internal": "внутр.", "tk.empty_thread": "Сообщений пока нет",
      "tk.edit_title": "Нажмите, чтобы изменить тему", "tk.download": "Скачать",
      "tk.tr.title": "Передать тикет #{n}", "tk.tr.hint": "Коллеги с полным доступом к группе в Zammad.",
      "tk.tr.search": "Найти коллегу…", "tk.tr.nobody": "Не назначен (для команды)", "tk.tr.note": "Комментарий коллеге (внутренняя заметка)",
      "tk.tr.go": "Передать", "tk.tr.done": "Тикет передан: {name}", "tk.tr.me": "вы", "tk.tr.owner": "сейчас ответственный",
      "tk.tr.none": "Никого не найдено. Список — это пользователи Zammad с доступом к этой группе.",
      "tk.tr.group": "Перенести в группу", "tk.tr.keep_group": "оставить группу",
      "tk.nw.title": "Новый тикет", "tk.nw.customer": "Клиент", "tk.nw.find": "Имя, телефон или e-mail…", "tk.nw.subject": "Тема",
      "tk.nw.body": "Описание", "tk.nw.assign": "Назначить на меня", "tk.nw.create": "Создать", "tk.nw.create_start": "Создать и приступить",
      "tk.nw.state": "Статус", "tk.nw.type": "Тип", "tk.nw.created": "Тикет #{n} создан", "tk.nw.need_customer": "Выберите клиента",
      "tk.nw.no_customer": "Никого не найдено — клиенты добавляются в Zammad.",
      "tk.gone": "Тикет перенесён в группу, к которой у вас нет доступа", "tk.owner_reset": "У ответственного нет доступа к новой группе — тикет теперь не назначен",
      "tk.changed_by_other": "Только что изменён",
      "tk.not_linked": "Ваша учётная запись не связана с пользователем Zammad — обратитесь к администратору.",
      "tk.assigned_toast": "{by} передал(а) вам тикет #{n}", "tk.assigned_open": "Открыть",
      "ct.customers": "Клиенты", "ct.staff": "Пользователи Zammad", "ct.search": "Поиск по имени, телефону, e-mail, компании…",
      "ct.readonly": "Клиенты и пользователи создаются и редактируются в Zammad — Zenith Desk показывает их автоматически.",
      "ct.synced": "Синхронизировано {t}", "ct.sync": "Синхронизировать", "ct.syncing": "Синхронизация…", "ct.never": "ещё не синхронизировано",
      "ct.pick": "Выберите человека слева", "ct.tickets": "Тикеты", "ct.no_tickets": "Тикетов нет",
      "ct.new_ticket": "Новый тикет", "ct.org": "Компания", "ct.email": "E-mail", "ct.phone": "Телефон", "ct.mobile": "Мобильный",
      "ct.note": "Заметка", "ct.groups": "Группы", "ct.roles": "Роли", "ct.since": "В Zammad с", "ct.inactive": "неактивен",
      "ct.new_toast": "Новый в Zammad: {name}", "ct.none": "Никого не найдено", "ct.more": "Показать ещё",
    },
  };

  const AV = 6;
  const avClass = (id) => "av-" + (Math.abs(+id || 0) % AV);
  const initials = (name) => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase();
  const URL_RE = /(https?:\/\/[^\s<>"')]+|mailto:[^\s<>"')]+)/g;
  /** Text -> [{text}|{url}] so links are clickable without ever rendering HTML from a customer. */
  function linkify(text) {
    const out = []; let last = 0;
    (text || "").replace(URL_RE, (m, _x, i) => { if (i > last) out.push({ text: text.slice(last, i) }); out.push({ url: m }); last = i + m.length; return m; });
    if (last < (text || "").length) out.push({ text: text.slice(last) });
    return out;
  }
  const CH_ICON = { email: "at", phone: "phone", note: "edit", web: "work", sms: "chat", "telegram personal-message": "send",
                    "whatsapp message": "chat", "facebook direct-message": "chat", chat: "chat" };
  const chName = (type) => ({ email: "E-mail", phone: "Phone", note: "Note", web: "Web", sms: "SMS", "telegram personal-message": "Telegram",
                              "whatsapp message": "WhatsApp", "facebook direct-message": "Facebook", chat: "Chat" }[type] || type);
  const dial = (number, name) => window.zenithDial && window.zenithDial(number, name);
  const fileSize = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : n > 1024 ? Math.round(n / 1024) + " KB" : n + " B");
  const readFile = (f) => new Promise((ok, fail) => {
    const r = new FileReader();
    r.onload = () => ok({ filename: f.name, mime: f.type || "application/octet-stream", size: f.size, data: String(r.result).split(",", 2)[1] || "" });
    r.onerror = () => fail(r.error); r.readAsDataURL(f);
  });

  // ==================================================================== <tickets-page>
  const TicketsPage = {
    props: ["api", "t", "toast", "fmt", "me", "config", "token", "openReq", "newReq", "stateText"],
    emits: ["open-customer"],
    setup(props) {
      const t = props.t;
      const s = reactive({
        meta: null, err: "", view: "mine", q: "", state: "", priority: "", group: "", page: 1, total: 0, list: [], loading: false,
        sel: null, d: null, dLoading: false, flash: false,
        kind: "note", internal: true, text: "", files: [], sendState: "", pendingDays: 1, sending: false,
        editTitle: false, title: "",
        tr: null, nw: null, busy: false, side: false,
      });
      const api = props.api;
      let seq = 0, dseq = 0;

      async function loadMeta() {
        try { s.meta = await api("GET", "/api/tk/meta"); s.err = ""; }
        catch (e) { s.err = e.status === 409 ? t("tk.not_linked") : e.message; }
      }
      async function loadList(keep) {
        if (!s.meta) return;
        const my = ++seq;
        if (!keep) s.loading = true;
        const per = 30, pages = keep ? s.page : 1;
        const qs = new URLSearchParams({ view: s.view, q: s.q, state: s.state, priority: s.priority, group: s.group,
                                         page: "1", per_page: String(per * pages) });
        try {
          const r = await api("GET", "/api/tk/tickets?" + qs);
          if (my !== seq) return;
          s.list = r.tickets; s.total = r.total; if (!keep) s.page = 1;
        } catch (e) { if (my === seq) props.toast(e.message, "error"); }
        finally { if (my === seq) s.loading = false; }
      }
      async function more() {
        const qs = new URLSearchParams({ view: s.view, q: s.q, state: s.state, priority: s.priority, group: s.group, page: String(s.page + 1), per_page: "30" });
        try { const r = await api("GET", "/api/tk/tickets?" + qs); s.page += 1; s.list = s.list.concat(r.tickets.filter((x) => !s.list.some((y) => y.id === x.id))); s.total = r.total; }
        catch (e) { props.toast(e.message, "error"); }
      }
      let qTimer = null;
      function onSearch() { clearTimeout(qTimer); qTimer = setTimeout(() => loadList(), 250); }
      function setView(v) { s.view = v; s.state = ""; loadList(); }

      async function open(id, silent) {
        if (!id) return;
        const my = ++dseq;
        if (s.sel !== id) { s.kind = "note"; s.internal = true; s.text = ""; s.files = []; s.sendState = ""; s.editTitle = false; s.d = null; }
        s.sel = id;
        if (!silent) s.dLoading = true;
        try {
          const d = await api("GET", `/api/tk/tickets/${id}`);
          if (my !== dseq) return;
          s.d = d;
          if (silent) { s.flash = true; setTimeout(() => { s.flash = false; }, 900); }
          if (!silent) nextTick(scrollThread);
        } catch (e) {
          if (my !== dseq) return;
          if (!silent) props.toast(e.message, "error");
          if (e.status === 403 || e.status === 404) { s.sel = null; s.d = null; }
        } finally { if (my === dseq) s.dLoading = false; }
      }
      function close() { s.sel = null; s.d = null; }
      function scrollThread() { const el = document.querySelector(".tk-thread"); if (el) el.scrollTop = el.scrollHeight; }

      const tk = computed(() => (s.d ? s.d.ticket : null));
      const openStates = computed(() => (s.meta ? s.meta.states : []));
      const replyLabel = computed(() => {
        if (!s.d) return "";
        const r = s.d.reply;
        if (r.type === "note") return t("tk.public_note");
        return t("tk.reply_via", { ch: chName(r.type) }) + (r.to ? " · " + t("tk.reply_to", { to: r.to }) : "");
      });
      const catText = (c) => t("tk.cat." + (c || "open"));

      // ---------------------------------------------------------- writing
      async function addFiles(ev) {
        const max = ((s.meta && s.meta.attachment_max_mb) || 10) * 1048576;
        for (const f of Array.from(ev.target.files || [])) {
          if (f.size > max) { props.toast(`${f.name}: > ${(s.meta && s.meta.attachment_max_mb) || 10} MB`, "error"); continue; }
          try { s.files.push(await readFile(f)); } catch (e) { props.toast(e.message, "error"); }
        }
        ev.target.value = "";
      }
      async function send() {
        if (s.sending || (!s.text.trim() && !s.files.length)) return;
        s.sending = true;
        try {
          s.d = await api("POST", `/api/tk/tickets/${s.sel}/articles`, {
            body: s.text, kind: s.kind, internal: s.kind === "note" ? s.internal : false,
            attachments: s.files.map((f) => ({ filename: f.filename, mime: f.mime, data: f.data })),
            state: s.sendState || null, pending_days: s.sendState && isPending(s.sendState) ? +s.pendingDays || 1 : null,
          });
          s.text = ""; s.files = []; s.sendState = "";
          props.toast(t("tk.sent")); nextTick(scrollThread); loadList(true);
        } catch (e) { props.toast(e.message, "error"); }
        finally { s.sending = false; }
      }
      function onKey(ev) { if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); send(); } }
      const isPending = (name) => { const st = openStates.value.find((x) => x.name === name); return st && st.category === "pending"; };

      async function patch(body, okText) {
        if (s.busy) return;
        s.busy = true;
        try {
          const r = await api("PATCH", `/api/tk/tickets/${s.sel}`, body);
          if (r.gone) { props.toast(t("tk.gone")); close(); }
          else { s.d = r; if (r.owner_reset) props.toast(t("tk.owner_reset")); else if (okText) props.toast(okText); }
          loadList(true);
          return r;
        } catch (e) { props.toast(e.message, "error"); if (s.sel) open(s.sel, true); }
        finally { s.busy = false; }
      }
      function setState(name) {
        if (!name || (tk.value && name === tk.value.state)) return;
        patch({ state: name, pending_days: isPending(name) ? 1 : null }, t("tk.updated_toast"));
      }
      function startTitle() { s.title = tk.value.title; s.editTitle = true; nextTick(() => { const el = document.querySelector(".tk-title-input"); if (el) el.focus(); }); }
      function saveTitle() { s.editTitle = false; if (s.title.trim() && s.title.trim() !== tk.value.title) patch({ title: s.title.trim() }, t("tk.updated_toast")); }
      const takeIt = () => patch({ owner_id: props.me.zammad_user_id || (s.meta && s.meta.zammad_user_id) }, t("tk.updated_toast"));

      // ---------------------------------------------------------- transfer
      async function openTransfer() {
        s.tr = { people: [], q: "", note: "", group: "", sel: null, loading: true, group_name: tk.value.group };
        await loadAssignees();
      }
      async function loadAssignees() {
        s.tr.loading = true;
        try {
          const r = await api("GET", `/api/tk/tickets/${s.sel}/assignees` + (s.tr.group ? `?group=${encodeURIComponent(s.tr.group)}` : ""));
          s.tr.people = r.people; s.tr.group_name = r.group;
        } catch (e) { props.toast(e.message, "error"); }
        finally { if (s.tr) s.tr.loading = false; }
      }
      const trPeople = computed(() => {
        if (!s.tr) return [];
        const q = s.tr.q.trim().toLowerCase();
        return s.tr.people.filter((p) => !q || (p.name + " " + p.email + " " + (p.position || "")).toLowerCase().includes(q));
      });
      async function doTransfer() {
        const tr = s.tr; if (!tr || tr.sel === null) return;
        const body = { owner_id: tr.sel, note: tr.note || null };
        if (tr.group) body.group = tr.group;
        const who = tr.sel === 0 ? t("tk.tr.nobody") : (tr.people.find((p) => p.id === tr.sel) || {}).name;
        const r = await patch(body, t("tk.tr.done", { name: who }));
        if (r) s.tr = null;
      }

      // ---------------------------------------------------------- work sessions (existing Zenith Desk flow)
      async function work(mode) {
        try {
          await api("POST", `/api/tickets/${s.sel}/start`, { work_mode: mode }, { idem: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) });
          props.toast(t(mode === "blocking" ? "toast.started_blocking" : "toast.started_background"));
          await open(s.sel, true);
        } catch (e) { props.toast(e.message, "error"); }
      }

      // ---------------------------------------------------------- attachments
      async function download(a, f) {
        try {
          const r = await fetch(`/api/tk/tickets/${s.sel}/articles/${a.id}/attachments/${f.id}`, { headers: { Authorization: `Bearer ${props.token}` } });
          if (!r.ok) throw new Error(r.status);
          const url = URL.createObjectURL(await r.blob());
          const link = document.createElement("a"); link.href = url; link.download = f.filename; document.body.appendChild(link); link.click();
          setTimeout(() => { URL.revokeObjectURL(url); link.remove(); }, 1000);
        } catch (e) { props.toast(e.message, "error"); }
      }

      // ---------------------------------------------------------- new ticket
      function openNew(customer) {
        const g = (s.meta && (s.meta.groups.find((x) => x.name === s.meta.default_group) || s.meta.groups[0])) || {};
        const p = (s.meta && (s.meta.priorities.find((x) => x.default) || s.meta.priorities[0])) || {};
        s.nw = { customer: customer || null, q: "", found: [], title: "", body: "", group: g.name || "", priority: p.name || "2 normal",
                 state: "", assign: true, type: "", fields: {}, busy: false };
      }
      let cTimer = null;
      function findCustomer() {
        clearTimeout(cTimer);
        cTimer = setTimeout(async () => {
          const q = s.nw.q.trim(); if (!q) { s.nw.found = []; return; }
          try { s.nw.found = (await api("GET", `/api/directory?kind=customers&limit=8&q=${encodeURIComponent(q)}`)).items; } catch { s.nw.found = []; }
        }, 200);
      }
      const nwType = computed(() => (s.nw && props.config.ticket_types || []).find((x) => s.nw && x.name === s.nw.type));
      async function createTicket(startMode) {
        const n = s.nw; if (!n || n.busy) return;
        if (!n.customer) { props.toast(t("tk.nw.need_customer"), "error"); return; }
        n.busy = true;
        try {
          const r = await api("POST", "/api/tickets", {
            title: n.title, body: n.body, customer_id: n.customer.id, group: n.group || null, priority: n.priority || null,
            ticket_type: n.type || null, fields: n.fields, start_mode: startMode || null, assign_to_me: n.assign, state: n.state || null,
          }, { idem: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) });
          props.toast(t("tk.nw.created", { n: r.ticket.number }));
          s.nw = null;
          if (n.assign || startMode) s.view = "mine"; else s.view = "unassigned";
          await loadList(); open(r.ticket.id);
        } catch (e) { props.toast(e.message, "error"); }
        finally { if (s.nw) s.nw.busy = false; }
      }

      // ---------------------------------------------------------- live
      let liveTimer = null;
      function onTicketChanged(ev) {
        const ids = (ev.detail && ev.detail.ids) || [];
        clearTimeout(liveTimer);
        liveTimer = setTimeout(() => loadList(true), 120);
        if (s.sel && ids.includes(s.sel) && !s.sending && !s.busy) open(s.sel, true);
      }
      function onChanged(ev) { const tp = (ev.detail && ev.detail.topics) || []; if (tp.includes("tickets")) { clearTimeout(liveTimer); liveTimer = setTimeout(() => loadList(true), 150); } }
      onMounted(async () => {
        window.addEventListener("agentix:ticket_changed", onTicketChanged);
        window.addEventListener("agentix:changed", onChanged);
        await loadMeta();
        await loadList();
      });
      onBeforeUnmount(() => {
        window.removeEventListener("agentix:ticket_changed", onTicketChanged);
        window.removeEventListener("agentix:changed", onChanged);
      });
      watch(() => props.openReq, (r) => { if (r && r.id) open(r.id); }, { immediate: true });
      watch(() => props.newReq, (r) => { if (r) { const go = () => openNew(r.customer || null); s.meta ? go() : loadMeta().then(go); } }, { immediate: true });

      return { s, t, tk, openStates, replyLabel, catText, loadList, more, onSearch, setView, open, close, addFiles, send, onKey, isPending,
        setState, startTitle, saveTitle, takeIt, patch, openTransfer, loadAssignees, trPeople, doTransfer, work, download, openNew,
        findCustomer, nwType, createTicket, linkify, avClass, initials, CH_ICON, chName, fileSize, dial, fmt: props.fmt };
    },
    template: `
<div class="tk" :class="{'has-sel': s.sel}">
  <div v-if="s.err" class="tk-err banner">{{ s.err }}</div>
  <section class="tk-list" v-else>
    <div class="tk-views" role="tablist">
      <button v-for="v in ['mine','unassigned','all','closed']" :key="v" role="tab" :data-view="v" :class="{on: s.view===v}" @click="setView(v)">{{ t('tk.view.' + v) }}</button>
    </div>
    <div class="tk-tools">
      <label class="chat-search tk-search"><ico name="search"></ico><input v-model="s.q" @input="onSearch" :placeholder="t('tk.search')" :aria-label="t('tk.search')"></label>
      <button class="btn primary sm tk-new" @click="openNew()" :disabled="!s.meta"><span aria-hidden="true">＋</span> {{ t('tk.new') }}</button>
    </div>
    <div class="tk-filters" v-if="s.meta">
      <select v-model="s.state" @change="loadList()" :aria-label="t('tk.state')"><option value="">{{ t('tk.f.state') }}</option>
        <option v-for="st in s.meta.states.filter(x => s.view==='closed' ? x.category==='closed' : x.category!=='closed')" :key="st.id" :value="st.name">{{ st.name }}</option></select>
      <select v-model="s.priority" @change="loadList()" :aria-label="t('tk.priority')"><option value="">{{ t('tk.f.priority') }}</option>
        <option v-for="p in s.meta.priorities" :key="p.id" :value="p.name">{{ p.name }}</option></select>
      <select v-if="s.meta.groups.length > 1" v-model="s.group" @change="loadList()" :aria-label="t('tk.group')"><option value="">{{ t('tk.f.group') }}</option>
        <option v-for="g in s.meta.groups" :key="g.id" :value="g.name">{{ g.name }}</option></select>
    </div>
    <div class="tk-count"><span>{{ t('tk.count', {n: s.total}) }}</span><span v-if="s.loading" class="tk-spin" aria-hidden="true"></span></div>
    <div class="tk-items">
      <transition-group name="cl">
        <button v-for="x in s.list" :key="x.id" class="tk-row" :class="['c-' + x.category, {on: s.sel===x.id}]" @click="open(x.id)" :data-id="x.id">
          <div class="tr-top"><span class="tr-num">#{{ x.number }}</span><span class="tr-title">{{ x.title }}</span><time>{{ fmt(x.updated_at, true) }}</time></div>
          <div class="tr-bot">
            <span class="tk-chip" :class="'c-' + x.category">{{ x.state }}</span>
            <span v-if="x.priority && x.priority.startsWith('3')" class="tk-prio" :title="x.priority">!</span>
            <span class="tr-cust">{{ x.customer_name }}</span>
            <span v-if="x.session" class="tag" :class="x.session.work_mode">{{ x.session.work_mode==='blocking' ? t('tk.in_work') : t('tk.in_bg') }}</span>
            <span v-if="s.view!=='mine'" class="tr-owner">{{ x.owner_name || t('tk.unassigned') }}</span>
          </div>
        </button>
      </transition-group>
      <div v-if="!s.loading && !s.list.length" class="chat-none">{{ t('tk.none') }}</div>
      <button v-if="s.list.length < s.total" class="btn sm tk-more" @click="more">{{ t('tk.more') }} ({{ s.total - s.list.length }})</button>
    </div>
  </section>

  <section class="tk-main" v-if="!s.err">
    <div v-if="!s.sel" class="chat-hello tk-hello"><div><ico name="tag"></ico><b>{{ t('tk.pick') }}</b><p>{{ t('tk.pick_sub') }}</p></div></div>
    <template v-else>
      <header class="tk-head">
        <button class="chat-back" @click="close" :aria-label="t('chat.back')"><ico name="back"></ico></button>
        <div class="tk-htext" v-if="tk">
          <div class="tk-hnum">#{{ tk.number }} <span class="tk-chip" :class="'c-' + tk.category">{{ tk.state }}</span>
            <span v-if="s.d.session" class="tag" :class="s.d.session.work_mode">{{ s.d.session.work_mode==='blocking' ? t('tk.in_work') : t('tk.in_bg') }}</span></div>
          <input v-if="s.editTitle" class="tk-title-input" v-model="s.title" @keydown.enter.prevent="saveTitle" @keydown.esc="s.editTitle=false" @blur="saveTitle" maxlength="250">
          <h1 v-else class="tk-title" :title="t('tk.edit_title')" @click="startTitle">{{ tk.title }}</h1>
        </div>
        <span class="spacer"></span>
        <button v-if="s.d" class="ch-btn tk-side-btn" :class="{on: s.side}" @click="s.side = !s.side" :title="t('tk.props')" :aria-label="t('tk.props')" data-act="props"><ico name="sidebar"></ico></button>
        <a v-if="s.d" class="ch-btn" :href="s.d.zammad_url" target="_blank" rel="noopener" :title="t('tk.open_zammad')" :aria-label="t('tk.open_zammad')"><ico name="ext"></ico></a>
      </header>
      <div v-if="s.dLoading && !s.d" class="tk-loading">{{ t('tk.loading') }}</div>
      <div v-if="s.d" class="tk-body" :class="{flash: s.flash, 'side-open': s.side}">
        <div class="tk-conv">
          <div class="tk-thread">
            <div v-if="!s.d.articles.length" class="chat-none">{{ t('tk.empty_thread') }}</div>
            <article v-for="a in s.d.articles" :key="a.id" class="tk-art" :class="[a.sender === 'customer' ? 'from-cust' : 'from-agent', {internal: a.internal}]" :data-type="a.type">
              <div class="ta-head">
                <span class="av sm" :class="avClass(a.author_id)">{{ initials(a.author) }}</span>
                <div class="ta-who"><b>{{ a.author }}</b>
                  <small><ico :name="CH_ICON[a.type] || 'chat'"></ico>{{ chName(a.type) }}<template v-if="a.to"> → {{ a.to }}</template></small></div>
                <span v-if="a.internal" class="tag ta-int">{{ t('tk.internal') }}</span>
                <time>{{ fmt(a.created_at, true) }}</time>
              </div>
              <div class="ta-body"><template v-for="(p, i) in linkify(a.body)" :key="i"><a v-if="p.url" :href="p.url" target="_blank" rel="noopener noreferrer">{{ p.url }}</a><template v-else>{{ p.text }}</template></template></div>
              <div v-if="a.attachments.length" class="ta-files">
                <button v-for="f in a.attachments" :key="f.id" class="ta-file" @click="download(a, f)" :title="t('tk.download')"><ico name="copy"></ico>{{ f.filename }} <small>{{ fileSize(f.size) }}</small></button>
              </div>
            </article>
          </div>
          <div class="tk-compose" :class="'k-' + s.kind">
            <div class="tc-modes">
              <button :class="{on: s.kind==='note'}" @click="s.kind='note'" data-kind="note"><ico name="edit"></ico>{{ t('tk.note') }}</button>
              <button :class="{on: s.kind==='reply'}" @click="s.kind='reply'" data-kind="reply"><ico :name="CH_ICON[s.d.reply.type] || 'send'"></ico>{{ t('tk.reply') }}</button>
              <span class="tc-target" v-if="s.kind==='reply'">{{ replyLabel }}</span>
            </div>
            <textarea v-model="s.text" @keydown="onKey" :placeholder="s.kind==='note' ? t('tk.placeholder.note') : t('tk.placeholder.reply')" rows="3"></textarea>
            <div v-if="s.files.length" class="tc-files"><span v-for="(f, i) in s.files" :key="i" class="ta-file">{{ f.filename }} <small>{{ fileSize(f.size) }}</small><button @click="s.files.splice(i, 1)" aria-label="✕">✕</button></span></div>
            <div class="tc-bar">
              <label class="btn sm tc-attach" :title="t('tk.attach')"><ico name="copy"></ico><span>{{ t('tk.attach') }}</span><input type="file" multiple @change="addFiles" hidden></label>
              <select v-model="s.sendState" class="tc-state" :aria-label="t('tk.and_state')"><option value="">{{ t('tk.keep_state') }}</option>
                <option v-for="st in openStates" :key="st.id" :value="st.name">→ {{ st.name }}</option></select>
              <input v-if="s.sendState && isPending(s.sendState)" type="number" min="1" max="365" v-model="s.pendingDays" class="tc-days" :title="t('tk.days')">
              <span class="spacer"></span>
              <small class="tc-hint">{{ t('tk.send_hint') }}</small>
              <button class="btn primary tc-send" :disabled="s.sending || (!s.text.trim() && !s.files.length)" @click="send"><ico name="send"></ico>{{ t('tk.send') }}</button>
            </div>
          </div>
        </div>
        <aside class="tk-side">
          <div class="ts-sec">
            <label>{{ t('tk.state') }}</label>
            <select :value="tk.state" @change="setState($event.target.value)" :disabled="s.busy" data-f="state">
              <option v-for="st in openStates" :key="st.id" :value="st.name">{{ st.name }}</option>
              <option v-if="!openStates.some(x => x.name === tk.state)" :value="tk.state">{{ tk.state }}</option></select>
            <div v-if="tk.category==='pending' && tk.pending_time" class="hint">{{ t('tk.pending_until') }} {{ fmt(tk.pending_time, true) }}</div>
            <label>{{ t('tk.priority') }}</label>
            <select :value="tk.priority" @change="patch({priority: $event.target.value}, t('tk.updated_toast'))" :disabled="s.busy" data-f="priority">
              <option v-for="p in s.meta.priorities" :key="p.id" :value="p.name">{{ p.name }}</option></select>
            <label>{{ t('tk.group') }}</label>
            <select :value="tk.group" @change="patch({group: $event.target.value}, t('tk.updated_toast'))" :disabled="s.busy" data-f="group">
              <option v-for="g in s.meta.groups" :key="g.id" :value="g.name">{{ g.name }}</option>
              <option v-if="!s.meta.groups.some(x => x.name === tk.group)" :value="tk.group">{{ tk.group }}</option></select>
            <label>{{ t('tk.owner') }}</label>
            <div class="ts-owner">
              <span class="av sm" :class="avClass(tk.owner_id)" v-if="tk.owner_id">{{ initials(tk.owner_name) }}</span>
              <b>{{ tk.owner_name || t('tk.unassigned') }}</b>
            </div>
            <div class="ts-actions">
              <button class="btn sm" @click="openTransfer" :disabled="s.busy" data-act="transfer">{{ t('tk.transfer') }}</button>
              <button v-if="!tk.mine && tk.category!=='closed'" class="btn sm" @click="takeIt" :disabled="s.busy" data-act="take">{{ t('tk.take') }}</button>
            </div>
          </div>
          <div class="ts-sec" v-if="tk.category!=='closed' && !s.d.session && (tk.mine || !tk.owner_id)">
            <label>{{ t('tk.work') }}</label>
            <div class="ts-actions"><button class="btn primary sm" @click="work('blocking')" data-act="start">{{ t('tk.start') }}</button>
              <button class="btn sm" @click="work('background')">{{ t('tk.background') }}</button></div>
          </div>
          <div class="ts-sec ts-cust">
            <label>{{ t('tk.customer') }}</label>
            <button class="ts-person" @click="$emit('open-customer', tk.customer.id)">
              <span class="av sm" :class="avClass(tk.customer.id)">{{ initials(tk.customer.name) }}</span>
              <span><b>{{ tk.customer.name }}</b><small v-if="tk.customer.organization">{{ tk.customer.organization }}</small></span></button>
            <div v-if="tk.customer.phone" class="ts-line"><ico name="phone"></ico>{{ tk.customer.phone }}
              <button class="btn sm dial-btn" @click="dial(tk.customer.phone, tk.customer.name)" data-act="dial-customer">{{ t('ph.call') }}</button></div>
            <div v-if="tk.customer.email" class="ts-line"><ico name="at"></ico><a :href="'mailto:' + tk.customer.email">{{ tk.customer.email }}</a></div>
            <div v-if="tk.customer.note" class="ts-note">{{ tk.customer.note }}</div>
          </div>
          <div class="ts-sec ts-dates">
            <div><span>{{ t('tk.created') }}</span><b>{{ fmt(tk.created_at, true) }}</b></div>
            <div><span>{{ t('tk.updated') }}</span><b>{{ fmt(tk.updated_at, true) }}</b></div>
          </div>
        </aside>
      </div>
    </template>
  </section>

  <!-- transfer -->
  <div class="overlay" v-if="s.tr" @click.self="s.tr=null">
    <div class="panel modal tk-transfer" role="dialog" aria-modal="true">
      <h3>{{ t('tk.tr.title', {n: tk.number}) }}</h3>
      <div class="hint">{{ t('tk.tr.hint') }}</div>
      <div class="row">
        <div><label>{{ t('tk.tr.group') }}</label>
          <select v-model="s.tr.group" @change="loadAssignees"><option value="">{{ t('tk.tr.keep_group') }} ({{ tk.group }})</option>
            <option v-for="g in s.meta.groups.filter(x => x.name !== tk.group)" :key="g.id" :value="g.name">{{ g.name }}</option></select></div>
      </div>
      <label class="chat-search tr-search"><ico name="search"></ico><input v-model="s.tr.q" :placeholder="t('tk.tr.search')"></label>
      <div class="tr-list">
        <button class="tr-person" :class="{on: s.tr.sel===0}" @click="s.tr.sel=0"><span class="av sm av-5">—</span><span><b>{{ t('tk.tr.nobody') }}</b></span></button>
        <button v-for="p in trPeople" :key="p.id" class="tr-person" :class="{on: s.tr.sel===p.id}" @click="s.tr.sel=p.id" :data-person="p.id">
          <span class="av sm" :class="avClass(p.id)">{{ initials(p.name) }}<i v-if="p.state" class="tr-dot" :class="'st-' + p.state"></i></span>
          <span class="tr-text"><b>{{ p.name }}<em v-if="p.me"> ({{ t('tk.tr.me') }})</em></b><small>{{ [p.position, p.state ? stateText(p.state) : p.email].filter(Boolean).join(' · ') }}</small></span>
          <span v-if="p.owner" class="tag">{{ t('tk.tr.owner') }}</span>
        </button>
        <div v-if="!s.tr.loading && !trPeople.length" class="empty">{{ t('tk.tr.none') }}</div>
      </div>
      <label>{{ t('tk.tr.note') }}</label><textarea v-model="s.tr.note" rows="2"></textarea>
      <div class="footer"><button class="btn" @click="s.tr=null">{{ t('modal.cancel') }}</button>
        <button class="btn primary" :disabled="s.busy || s.tr.sel===null" @click="doTransfer" data-act="do-transfer">{{ t('tk.tr.go') }}</button></div>
    </div>
  </div>

  <!-- new ticket -->
  <div class="overlay" v-if="s.nw" @click.self="s.nw=null">
    <div class="panel modal wide tk-newform" role="dialog" aria-modal="true">
      <h3>{{ t('tk.nw.title') }}</h3>
      <label>{{ t('tk.nw.customer') }} *</label>
      <div v-if="s.nw.customer" class="nw-cust"><span class="av sm" :class="avClass(s.nw.customer.id)">{{ initials(s.nw.customer.name) }}</span>
        <span><b>{{ s.nw.customer.name }}</b><small>{{ [s.nw.customer.organization, s.nw.customer.phone || s.nw.customer.mobile, s.nw.customer.email].filter(Boolean).join(' · ') }}</small></span>
        <button class="btn sm" @click="s.nw.customer=null">✕</button></div>
      <template v-else>
        <input v-model="s.nw.q" @input="findCustomer" :placeholder="t('tk.nw.find')" name="customer-q">
        <div class="zresults" v-if="s.nw.q">
          <div v-for="c in s.nw.found" :key="c.id" class="zitem" @click="s.nw.customer=c; s.nw.found=[]">{{ c.name }} <span class="empty">{{ [c.organization, c.phone || c.mobile, c.email].filter(Boolean).join(' · ') }}</span></div>
          <div v-if="!s.nw.found.length" class="zitem empty">{{ t('tk.nw.no_customer') }}</div>
        </div>
      </template>
      <label>{{ t('tk.nw.subject') }} *</label><input v-model="s.nw.title" maxlength="250" name="title">
      <div class="row">
        <div><label>{{ t('tk.group') }}</label><select v-model="s.nw.group"><option v-for="g in s.meta.groups" :key="g.id" :value="g.name">{{ g.name }}</option></select></div>
        <div><label>{{ t('tk.priority') }}</label><select v-model="s.nw.priority"><option v-for="p in s.meta.priorities" :key="p.id" :value="p.name">{{ p.name }}</option></select></div>
        <div><label>{{ t('tk.nw.state') }}</label><select v-model="s.nw.state"><option value="">new</option>
          <option v-for="st in s.meta.states.filter(x => x.category==='open')" :key="st.id" :value="st.name">{{ st.name }}</option></select></div>
      </div>
      <div class="row" v-if="(config.ticket_types || []).length">
        <div><label>{{ t('tk.nw.type') }}</label><select v-model="s.nw.type"><option value="">—</option><option v-for="tt in config.ticket_types" :key="tt.name" :value="tt.name">{{ tt.name }}</option></select></div>
      </div>
      <template v-if="nwType"><div v-for="f in nwType.required_fields" :key="f.name">
        <label>{{ f.label || f.name }} *</label>
        <select v-if="f.type==='select'" v-model="s.nw.fields[f.name]"><option v-for="o in f.options || []" :key="o" :value="o">{{ o }}</option></select>
        <input v-else v-model="s.nw.fields[f.name]"></div></template>
      <label>{{ t('tk.nw.body') }}</label><textarea v-model="s.nw.body" rows="4" name="body"></textarea>
      <label class="check"><input type="checkbox" v-model="s.nw.assign"> {{ t('tk.nw.assign') }}</label>
      <div class="footer"><button class="btn" @click="s.nw=null">{{ t('modal.cancel') }}</button>
        <button class="btn" :disabled="s.nw.busy || !s.nw.title.trim() || !s.nw.customer" @click="createTicket(null)" data-act="create">{{ t('tk.nw.create') }}</button>
        <button class="btn primary" :disabled="s.nw.busy || !s.nw.title.trim() || !s.nw.customer" @click="createTicket('blocking')">{{ t('tk.nw.create_start') }}</button></div>
    </div>
  </div>
</div>`,
  };

  // ==================================================================== <contacts-page>
  const ContactsPage = {
    props: ["api", "t", "toast", "fmt", "me", "openReq"],
    emits: ["open-ticket", "new-ticket"],
    setup(props) {
      const t = props.t, api = props.api;
      const s = reactive({ kind: "customers", q: "", items: [], total: 0, counts: { customers: 0, staff: 0 }, synced_at: null, error: "",
                           loading: false, sel: null, card: null, syncing: false });
      let seq = 0;
      async function load(keep) {
        const my = ++seq; if (!keep) s.loading = true;
        try {
          const r = await api("GET", `/api/directory?kind=${s.kind}&limit=${keep ? Math.max(50, s.items.length) : 50}&q=${encodeURIComponent(s.q)}`);
          if (my !== seq) return;
          s.items = r.items; s.total = r.total; s.counts = r.counts; s.synced_at = r.synced_at; s.error = r.error || "";
        } catch (e) { if (my === seq) props.toast(e.message, "error"); }
        finally { if (my === seq) s.loading = false; }
      }
      async function more() {
        try { const r = await api("GET", `/api/directory?kind=${s.kind}&offset=${s.items.length}&limit=50&q=${encodeURIComponent(s.q)}`); s.items = s.items.concat(r.items); }
        catch (e) { props.toast(e.message, "error"); }
      }
      let qt = null;
      const onSearch = () => { clearTimeout(qt); qt = setTimeout(() => load(), 200); };
      function setKind(k) { s.kind = k; s.sel = null; s.card = null; load(); }
      async function open(id) {
        s.sel = id;
        try { s.card = await api("GET", `/api/directory/${id}`); } catch (e) { props.toast(e.message, "error"); }
      }
      async function sync() {
        s.syncing = true;
        try { await api("POST", "/api/directory/sync"); await load(true); } catch (e) { props.toast(e.message, "error"); }
        finally { s.syncing = false; }
      }
      let lt = null;
      function onChanged(ev) {
        const tp = (ev.detail && ev.detail.topics) || [];
        if (tp.includes("directory")) { clearTimeout(lt); lt = setTimeout(() => { load(true); if (s.sel) open(s.sel); }, 150); }
      }
      function onTicket() { if (s.sel && s.card) { clearTimeout(lt); lt = setTimeout(() => open(s.sel), 200); } }
      onMounted(() => { window.addEventListener("agentix:changed", onChanged); window.addEventListener("agentix:ticket_changed", onTicket); load(); });
      onBeforeUnmount(() => { window.removeEventListener("agentix:changed", onChanged); window.removeEventListener("agentix:ticket_changed", onTicket); });
      watch(() => props.openReq, (r) => { if (r && r.id) { if (r.kind && r.kind !== s.kind) { s.kind = r.kind; load(); } open(r.id); } }, { immediate: true });
      const u = computed(() => (s.card ? s.card.user : null));
      return { s, t, u, load, more, onSearch, setKind, open, sync, avClass, initials, dial, fmt: props.fmt };
    },
    template: `
<div class="tk ct" :class="{'has-sel': s.sel}">
  <section class="tk-list">
    <div class="tk-views" role="tablist">
      <button role="tab" data-kind="customers" :class="{on: s.kind==='customers'}" @click="setKind('customers')">{{ t('ct.customers') }} <b>{{ s.counts.customers }}</b></button>
      <button role="tab" data-kind="staff" :class="{on: s.kind==='staff'}" @click="setKind('staff')">{{ t('ct.staff') }} <b>{{ s.counts.staff }}</b></button>
    </div>
    <div class="tk-tools"><label class="chat-search tk-search"><ico name="search"></ico><input v-model="s.q" @input="onSearch" :placeholder="t('ct.search')" :aria-label="t('ct.search')"></label></div>
    <div class="ct-sync">
      <span>{{ s.synced_at ? t('ct.synced', {t: fmt(s.synced_at, true)}) : t('ct.never') }}</span>
      <button class="btn sm" @click="sync" :disabled="s.syncing" data-act="sync">{{ s.syncing ? t('ct.syncing') : t('ct.sync') }}</button>
    </div>
    <div v-if="s.error" class="banner error ct-errline">Zammad: {{ s.error }}</div>
    <div class="tk-items">
      <transition-group name="cl">
        <button v-for="p in s.items" :key="p.id" class="chat-item ct-row" :class="{on: s.sel===p.id, off: !p.active}" @click="open(p.id)" :data-id="p.id">
          <span class="av sm" :class="avClass(p.id)">{{ initials(p.name) }}</span>
          <div class="ci-text"><div class="ci-top"><span class="ci-name">{{ p.name }}</span></div>
            <div class="ci-bottom"><span class="ci-prev">{{ [p.organization, p.phone || p.mobile, p.email].filter(Boolean).join(' · ') }}</span></div></div>
        </button>
      </transition-group>
      <div v-if="!s.loading && !s.items.length" class="chat-none">{{ t('ct.none') }}</div>
      <button v-if="s.items.length < s.total" class="btn sm tk-more" @click="more">{{ t('ct.more') }} ({{ s.total - s.items.length }})</button>
    </div>
    <div class="ct-ro">{{ t('ct.readonly') }}</div>
  </section>
  <section class="tk-main ct-main">
    <div v-if="!s.sel || !u" class="chat-hello tk-hello"><div><ico name="users"></ico><b>{{ t('ct.pick') }}</b><p>{{ t('ct.readonly') }}</p></div></div>
    <template v-else>
      <header class="tk-head"><button class="chat-back" @click="s.sel=null" :aria-label="t('chat.back')"><ico name="back"></ico></button><span class="spacer"></span>
        <button v-if="u.is_customer" class="btn primary sm" @click="$emit('new-ticket', u)" data-act="new-ticket"><span aria-hidden="true">＋</span> {{ t('ct.new_ticket') }}</button></header>
      <div class="ct-card">
        <div class="ct-hero"><span class="av xl" :class="avClass(u.id)">{{ initials(u.name) }}</span>
          <div><h1>{{ u.name }}</h1><div class="hint">{{ u.organization }}<span v-if="!u.active" class="tag off">{{ t('ct.inactive') }}</span></div></div></div>
        <div class="ct-fields">
          <div v-if="u.email"><span>{{ t('ct.email') }}</span><a :href="'mailto:' + u.email">{{ u.email }}</a></div>
          <div v-if="u.phone"><span>{{ t('ct.phone') }}</span><b class="mono">{{ u.phone }} <button class="btn sm dial-btn" @click="dial(u.phone, u.name)" data-act="dial-phone">{{ t('ph.call') }}</button></b></div>
          <div v-if="u.mobile"><span>{{ t('ct.mobile') }}</span><b class="mono">{{ u.mobile }} <button class="btn sm dial-btn" @click="dial(u.mobile, u.name)" data-act="dial-mobile">{{ t('ph.call') }}</button></b></div>
          <div v-if="u.organization"><span>{{ t('ct.org') }}</span><b>{{ u.organization }}</b></div>
          <div v-if="u.roles.length"><span>{{ t('ct.roles') }}</span><b>{{ u.roles.join(', ') }}</b></div>
          <div v-if="u.is_agent && Object.keys(u.groups).length"><span>{{ t('ct.groups') }}</span><b>{{ Object.entries(u.groups).map(([g, a]) => g + ' (' + a.join(', ') + ')').join('; ') }}</b></div>
          <div v-if="u.created_at"><span>{{ t('ct.since') }}</span><b>{{ fmt(u.created_at, true) }}</b></div>
          <div v-if="u.note" class="ct-note"><span>{{ t('ct.note') }}</span><p>{{ u.note }}</p></div>
        </div>
        <h2 class="ct-h">{{ t('ct.tickets') }} <span class="count">{{ s.card.tickets.length }}</span></h2>
        <div v-if="s.card.error" class="hint">{{ s.card.error }}</div>
        <div v-if="!s.card.tickets.length" class="empty">{{ t('ct.no_tickets') }}</div>
        <button v-for="x in s.card.tickets" :key="x.id" class="tk-row" :class="'c-' + x.category" @click="$emit('open-ticket', x.id)">
          <div class="tr-top"><span class="tr-num">#{{ x.number }}</span><span class="tr-title">{{ x.title }}</span><time>{{ fmt(x.updated_at, true) }}</time></div>
          <div class="tr-bot"><span class="tk-chip" :class="'c-' + x.category">{{ x.state }}</span><span class="tr-owner">{{ x.owner_name || t('tk.unassigned') }}</span></div>
        </button>
      </div>
    </template>
  </section>
</div>`,
  };

  return { i18n, TicketsPage, ContactsPage };
})();
