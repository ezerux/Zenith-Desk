"""Web Push (v3.1): notifications that reach the browser even when Zenith Desk is closed.

Standards, implemented with `cryptography` + `httpx` (no extra dependency):
* RFC 8291 — message encryption for Web Push (aes128gcm): only the subscribed browser can read the text;
  the push service (Google / Mozilla / Apple) only relays an encrypted blob.
* RFC 8292 — VAPID: the server proves who it is with an ES256-signed token.

The VAPID key pair is generated once and stored encrypted in `system_setting` (key `vapid_private_key`).
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import struct
import time
from urllib.parse import urlsplit

import httpx
import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from sqlalchemy import delete, select

from .db import Database, utcnow
from .models import PushSubscription, SystemSetting

log = logging.getLogger("webpush")
VAPID_SETTING = "vapid_private_key"


def b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _hkdf_expand(prk: bytes, info: bytes, length: int) -> bytes:
    return hmac.new(prk, info + b"\x01", hashlib.sha256).digest()[:length]


def encrypt_payload(payload: bytes, p256dh: str, auth: str, *, salt: bytes | None = None,
                    server_key: ec.EllipticCurvePrivateKey | None = None) -> bytes:
    """RFC 8291 aes128gcm content encoding."""
    ua_public = b64u_dec(p256dh)
    auth_secret = b64u_dec(auth)
    salt = salt or os.urandom(16)
    server_key = server_key or ec.generate_private_key(ec.SECP256R1())
    as_public = server_key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    ua_key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), ua_public)
    ecdh_secret = server_key.exchange(ec.ECDH(), ua_key)
    prk_key = hmac.new(auth_secret, ecdh_secret, hashlib.sha256).digest()
    ikm = _hkdf_expand(prk_key, b"WebPush: info\x00" + ua_public + as_public, 32)
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    cek = _hkdf_expand(prk, b"Content-Encoding: aes128gcm\x00", 16)
    nonce = _hkdf_expand(prk, b"Content-Encoding: nonce\x00", 12)
    ciphertext = AESGCM(cek).encrypt(nonce, payload + b"\x02", None)
    return salt + struct.pack("!L", 4096) + bytes([len(as_public)]) + as_public + ciphertext


class WebPush:
    def __init__(self, db: Database, box, subject: str = "mailto:admin@zenith-desk.local",
                 transport: httpx.AsyncBaseTransport | None = None):
        self.db, self.box, self.subject = db, box, subject
        self._key: ec.EllipticCurvePrivateKey | None = None
        self._client = httpx.AsyncClient(timeout=10, transport=transport)
        self._tasks: set[asyncio.Task] = set()  # notifications in flight: finished (or cancelled) before shutdown
        self._closed = False

    async def private_key(self) -> ec.EllipticCurvePrivateKey:
        if self._key is not None:
            return self._key
        async with self.db.sessionmaker() as s:
            row = await s.get(SystemSetting, VAPID_SETTING)
            pem = self.box.decrypt(row.value) if row else None
            if pem:
                self._key = serialization.load_pem_private_key(pem.encode(), password=None)
            else:
                self._key = ec.generate_private_key(ec.SECP256R1())
                pem = self._key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                              serialization.NoEncryption()).decode()
                if row is None:
                    s.add(SystemSetting(key=VAPID_SETTING, value=self.box.encrypt(pem), is_secret=True))
                else:
                    row.value, row.is_secret = self.box.encrypt(pem), True
                await s.commit()
        return self._key

    async def public_key(self) -> str:
        k = await self.private_key()
        return b64u(k.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint))

    async def _vapid_headers(self, endpoint: str) -> dict:
        u = urlsplit(endpoint)
        token = jwt.encode({"aud": f"{u.scheme}://{u.netloc}", "exp": int(time.time()) + 12 * 3600, "sub": self.subject},
                           await self.private_key(), algorithm="ES256")
        return {"Authorization": f"vapid t={token}, k={await self.public_key()}"}

    async def send(self, sub: PushSubscription, data: dict, ttl: int = 3600) -> int:
        body = encrypt_payload(json.dumps(data, ensure_ascii=False, default=str).encode(), sub.p256dh, sub.auth)
        headers = {"Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", "TTL": str(ttl),
                   "Urgency": "high", **(await self._vapid_headers(sub.endpoint))}
        r = await self._client.post(sub.endpoint, content=body, headers=headers)
        return r.status_code

    async def notify(self, agent_id: int, data: dict) -> int:
        """Send to every browser the person subscribed; forget subscriptions the push service rejects."""
        async with self.db.sessionmaker() as s:
            subs = (await s.execute(select(PushSubscription).where(PushSubscription.agent_id == agent_id))).scalars().all()
        sent, gone = 0, []
        for sub in subs:
            try:
                code = await self.send(sub, data)
            except Exception as exc:  # noqa: BLE001
                log.warning("push to agent %s failed: %s", agent_id, exc)
                continue
            if code in (404, 410):
                gone.append(sub.id)
            elif 200 <= code < 300:
                sent += 1
                async with self.db.sessionmaker() as s:
                    row = await s.get(PushSubscription, sub.id)
                    if row:
                        row.last_ok_at = utcnow()
                        await s.commit()
            else:
                log.warning("push service answered %s for agent %s", code, agent_id)
        if gone:
            async with self.db.sessionmaker() as s:
                await s.execute(delete(PushSubscription).where(PushSubscription.id.in_(gone)))
                await s.commit()
        return sent

    def notify_later(self, agent_id: int, data: dict) -> None:
        if self._closed:
            return
        task = asyncio.create_task(self.notify(agent_id, data), name=f"push-{agent_id}")
        self._tasks.add(task)

        def done(t: asyncio.Task) -> None:
            self._tasks.discard(t)
            if not t.cancelled() and t.exception():
                log.warning("push task: %s", t.exception())
        task.add_done_callback(done)

    async def drain(self) -> None:
        """Let notifications in flight finish (v3.10: before a restore replaces the database)."""
        pending = list(self._tasks)
        if pending:
            _, still = await asyncio.wait(pending, timeout=3)
            for t in still:
                t.cancel()
            if still:
                await asyncio.gather(*still, return_exceptions=True)

    async def close(self) -> None:
        self._closed = True
        # never leave a database transaction open behind us (a half-finished task would hold its connection)
        pending = list(self._tasks)
        if pending:
            _, still = await asyncio.wait(pending, timeout=3)
            for t in still:
                t.cancel()
            if still:
                await asyncio.gather(*still, return_exceptions=True)
        await self._client.aclose()
