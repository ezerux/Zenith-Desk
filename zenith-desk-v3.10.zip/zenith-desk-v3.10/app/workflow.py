"""Ticket work sessions: «Приступить», «Фоновая задача», «Завершить», перерыв, override,
reaction to ticket changes made directly in Zammad (FR-03..FR-08, FR-10, FR-11).
"""
import asyncio
import logging
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from .audit import audit
from .config import Settings
from .db import Database, as_utc, utcnow
from .i18n import t as tr
from .models import AgentMapping, AuditLog, CallRecord, TicketType, WorkSession
from .sync import StateEngine
from .views import session_view
from .zammad import ZammadClient, ZammadError

log = logging.getLogger("workflow")

SOURCE_MAP = {
    "phone": "phone",
    "email": "email",
    "telegram personal-message": "telegram",
    "whatsapp message": "whatsapp",
    "web": "web",
    "note": "internal",
    "sms": "sms",
    "facebook feed post": "facebook",
}


class WorkflowError(Exception):
    def __init__(self, status: int, message: str, details: dict | None = None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.details = details or {}


class Actor:
    def __init__(self, kind: str, agent_id: int | None):
        self.kind = kind  # agent / supervisor / system / zammad
        self.agent_id = agent_id


def ticket_state_name(ticket: dict, states: dict[int, str] | None = None) -> str:
    st = ticket.get("state")
    if isinstance(st, str):
        return st
    if states and ticket.get("state_id") is not None:
        return states.get(int(ticket["state_id"]), "")
    return ""


def ticket_source(ticket: dict) -> str:
    raw = ticket.get("create_article_type")
    if isinstance(raw, str):
        return SOURCE_MAP.get(raw.lower(), raw.lower())
    return ""


class Workflow:
    def __init__(self, db: Database, zammad: ZammadClient, engine: StateEngine, settings: Settings):
        self.db = db
        self.zammad = zammad
        self.engine = engine
        self.settings = settings
        self._ticket_locks: dict[int, asyncio.Lock] = {}
        self._task: asyncio.Task | None = None

    def _lock(self, ticket_id: int) -> asyncio.Lock:
        return self._ticket_locks.setdefault(ticket_id, asyncio.Lock())

    async def _get_ticket(self, ticket_id: int, on_behalf_of: int | None = None) -> tuple[dict, str]:
        try:
            ticket = await self.zammad.get_ticket(ticket_id, on_behalf_of)
            states = None if isinstance(ticket.get("state"), str) else await self.zammad.ticket_states()
        except ZammadError as exc:
            if exc.status in (403, 404):
                raise WorkflowError(404, tr("err.ticket_not_found")) from exc
            raise WorkflowError(502, str(exc)) from exc
        return ticket, ticket_state_name(ticket, states).lower()

    @staticmethod
    async def _active_session(s: AsyncSession, ticket_id: int) -> WorkSession | None:
        return (await s.execute(
            select(WorkSession).where(WorkSession.ticket_id == ticket_id, WorkSession.state == "active")
        )).scalars().first()

    # ------------------------------------------------------------------ FR-11
    async def validate_ticket_fields(self, ticket: dict) -> None:
        type_value = ticket.get(self.settings.zammad_ticket_type_attribute)
        async with self.db.sessionmaker() as s:
            types = (await s.execute(select(TicketType).where(TicketType.enabled.is_(True)))).scalars().all()
        if not types:
            return
        if not type_value:
            if self.settings.zammad_require_ticket_type:
                raise WorkflowError(422, tr("err.no_ticket_type"), {"missing": [self.settings.zammad_ticket_type_attribute]})
            return
        tt = next((t for t in types if t.zammad_value == type_value), None)
        if tt is None:
            return
        missing = [f.get("label") or f["name"] for f in (tt.required_fields or [])
                   if ticket.get(f["name"]) in (None, "", [], "-")]
        if missing:
            raise WorkflowError(422, tr("err.required_fields_type", type=tt.name, fields=", ".join(missing)),
                                {"missing": missing, "ticket_type": tt.name})

    # ------------------------------------------------------------------ FR-03 / FR-06
    async def start_work(self, agent: AgentMapping, ticket_id: int, mode: str, actor: Actor) -> dict:
        if mode not in ("blocking", "background"):
            raise WorkflowError(422, tr("err.bad_mode"))
        if not agent.zammad_user_id:
            raise WorkflowError(409, tr("err.not_linked"))
        async with self._lock(ticket_id):
            # read on behalf of the operator: Zammad itself checks group permissions
            ticket, state = await self._get_ticket(ticket_id, agent.zammad_user_id if actor.kind == "agent" else None)
            if state in self.settings.final_states:
                raise WorkflowError(409, tr("err.ticket_final", state=state))
            owner_id = ticket.get("owner_id")
            update: dict = {}
            if owner_id != agent.zammad_user_id:
                unassigned = owner_id in (None, self.settings.zammad_unassigned_owner_id)
                if unassigned and self.settings.auto_assign_on_start:
                    update["owner_id"] = agent.zammad_user_id
                elif actor.kind == "supervisor":
                    update["owner_id"] = agent.zammad_user_id
                else:
                    raise WorkflowError(409, tr("err.ticket_other_owner"))
            await self.validate_ticket_fields(ticket)

            stale_agents: list[int] = []
            async with self.db.sessionmaker() as s:
                existing = await self._active_session(s, ticket_id)
                if existing and existing.agent_id == agent.id and not update:
                    if existing.work_mode == mode:
                        return {"session": session_view(existing), "idempotent": True}
                    return await self._change_mode_in_tx(s, existing, mode, actor)

            in_progress = self.settings.zammad_state_in_progress
            if in_progress and state != in_progress.lower() and (state == "new" or state in self.settings.pending_states):
                update["state"] = in_progress
            if update:
                try:
                    await self.zammad.update_ticket(ticket_id, update)
                except ZammadError as exc:
                    raise WorkflowError(502, tr("err.zammad_update", error=exc)) from exc

            async with self.db.sessionmaker() as s:
                existing = await self._active_session(s, ticket_id)
                if existing is not None:  # session of a previous owner is stale now
                    existing.state, existing.ended_at, existing.end_reason = "cancelled", utcnow(), "reassigned"
                    stale_agents.append(existing.agent_id)
                    audit(s, "work_cancelled", agent_id=existing.agent_id, ticket_id=ticket_id,
                          actor_type=actor.kind, actor_id=actor.agent_id, reason="reassigned")
                    await s.flush()
                ws = WorkSession(
                    ticket_id=ticket_id, ticket_number=str(ticket.get("number", "")),
                    ticket_title=str(ticket.get("title", ""))[:500], source=ticket_source(ticket),
                    agent_id=agent.id, work_mode=mode, state="active",
                )
                s.add(ws)
                st = await self.engine.ensure_state(s, agent.id)
                if mode == "blocking" and st.override_ready:
                    st.override_ready, st.override_reason = False, ""
                audit(s, "work_started", agent_id=agent.id, ticket_id=ticket_id, actor_type=actor.kind,
                      actor_id=actor.agent_id, work_mode=mode, assigned=bool(update.get("owner_id")),
                      zammad_state=update.get("state"))
                try:
                    await s.commit()
                except IntegrityError as exc:
                    raise WorkflowError(409, tr("err.parallel")) from exc
                view = session_view(ws)
        for other in stale_agents:
            await self.engine.recompute(other, "ticket_reassigned")
        state_view = await self.engine.recompute(agent.id, f"start:{ticket_id}")
        return {"session": view, "agent_state": state_view}

    # ------------------------------------------------------------------ FR-05
    async def change_mode(self, agent: AgentMapping, ticket_id: int, mode: str, actor: Actor) -> dict:
        if mode not in ("blocking", "background"):
            raise WorkflowError(422, tr("err.bad_mode"))
        async with self._lock(ticket_id):
            async with self.db.sessionmaker() as s:
                ws = await self._active_session(s, ticket_id)
                if ws is None or (ws.agent_id != agent.id and actor.kind != "supervisor"):
                    raise WorkflowError(404, tr("err.no_active_work"))
                if ws.work_mode == mode:
                    return {"session": session_view(ws), "idempotent": True}
                return await self._change_mode_in_tx(s, ws, mode, actor)

    async def _change_mode_in_tx(self, s: AsyncSession, ws: WorkSession, mode: str, actor: Actor) -> dict:
        old = ws.work_mode
        ws.work_mode = mode
        audit(s, "mode_changed", agent_id=ws.agent_id, ticket_id=ws.ticket_id, actor_type=actor.kind,
              actor_id=actor.agent_id, old=old, new=mode)
        await s.commit()
        view = session_view(ws)
        state_view = await self.engine.recompute(ws.agent_id, f"mode:{ws.ticket_id}")
        return {"session": view, "agent_state": state_view}

    # ------------------------------------------------------------------ FR-04
    async def complete_work(self, agent: AgentMapping, ticket_id: int, actor: Actor, *,
                            ticket_state: str | None = None, note: str | None = None,
                            pending_days: int | None = None) -> dict:
        allowed = self.settings.complete_states
        target = ticket_state or (allowed[0] if allowed else "closed")
        if allowed and target not in allowed:
            raise WorkflowError(422, tr("err.bad_final_state", allowed=", ".join(allowed)))
        async with self._lock(ticket_id):
            async with self.db.sessionmaker() as s:
                ws = await self._active_session(s, ticket_id)
                if ws is None or (ws.agent_id != agent.id and actor.kind != "supervisor"):
                    # Idempotent repeat: already completed by this agent?
                    last = (await s.execute(
                        select(WorkSession).where(WorkSession.ticket_id == ticket_id, WorkSession.agent_id == agent.id)
                        .order_by(WorkSession.id.desc())
                    )).scalars().first()
                    if last is not None and last.state == "completed":
                        return {"session": session_view(last), "idempotent": True,
                                "agent_state": await self.engine.state_view(agent.id)}
                    raise WorkflowError(404, tr("err.no_active_work"))
            update: dict = {"state": target}
            if target.lower() in self.settings.pending_states:
                update["pending_time"] = (utcnow() + timedelta(days=pending_days or 1)).isoformat()
            try:
                if note:
                    await self.zammad.add_note(ticket_id, note)
                await self.zammad.update_ticket(ticket_id, update)
            except ZammadError as exc:
                raise WorkflowError(502, tr("err.zammad_update", error=exc)) from exc
            async with self.db.sessionmaker() as s:
                ws = await self._active_session(s, ticket_id)
                if ws is None:
                    raise WorkflowError(409, tr("err.already_completed"))
                ws.state, ws.ended_at, ws.end_reason = "completed", utcnow(), f"completed:{target}"
                audit(s, "work_completed", agent_id=ws.agent_id, ticket_id=ticket_id, actor_type=actor.kind,
                      actor_id=actor.agent_id, work_mode=ws.work_mode, zammad_state=target,
                      duration_sec=int((utcnow() - as_utc(ws.started_at)).total_seconds()))
                await s.commit()
                view, owner = session_view(ws), ws.agent_id
        state_view = await self.engine.recompute(owner, f"complete:{ticket_id}")
        return {"session": view, "agent_state": state_view}

    async def release(self, agent: AgentMapping, ticket_id: int, actor: Actor, reason: str = "released") -> dict:
        """Stop working on a ticket without changing it in Zammad."""
        async with self._lock(ticket_id):
            async with self.db.sessionmaker() as s:
                ws = await self._active_session(s, ticket_id)
                if ws is None or (ws.agent_id != agent.id and actor.kind != "supervisor"):
                    raise WorkflowError(404, tr("err.no_active_work"))
                ws.state, ws.ended_at, ws.end_reason = "cancelled", utcnow(), reason
                audit(s, "work_cancelled", agent_id=ws.agent_id, ticket_id=ticket_id, actor_type=actor.kind,
                      actor_id=actor.agent_id, reason=reason)
                await s.commit()
                view, owner = session_view(ws), ws.agent_id
        return {"session": view, "agent_state": await self.engine.recompute(owner, f"release:{ticket_id}")}

    # ------------------------------------------------------------------ FR-08
    async def set_manual_state(self, agent_id: int, new_state: str, actor: Actor, reason: str = "") -> dict:
        if new_state not in ("ready", "break", "offline"):
            raise WorkflowError(422, tr("err.bad_state"))
        async with self.db.sessionmaker() as s:
            st = await self.engine.ensure_state(s, agent_id)
            if new_state == "ready" and actor.kind == "agent":
                blocking = await self.engine.blocking_tickets(s, agent_id)
                if blocking:
                    raise WorkflowError(409, tr("err.ready_blocked"),
                                        {"blocking_tickets": blocking})
            old = st.manual_state
            st.manual_state = new_state
            if new_state != "offline":
                st.idle_since = None  # back at work
            if actor.kind == "agent":
                st.override_ready, st.override_reason = False, ""
                if new_state == "ready":
                    st.wrap_up_until = None  # operator finished post-processing early
                    st.dnd = False  # "Ready" means: I want calls again
            audit(s, "manual_state", agent_id=agent_id, actor_type=actor.kind, actor_id=actor.agent_id,
                  old=old, new=new_state, reason=reason or None)
            await s.commit()
        return await self.engine.recompute(agent_id, f"manual:{new_state}")

    # ------------------------------------------------------------------ inactivity (v2.8)
    async def go_idle(self, agent_id: int, minutes: int, cause: str) -> dict | None:
        """Nobody used Zenith Desk for `minutes`: stop calls (offline) and mark the person as away.
        Tasks stay as they are. Returns None if the person is already offline or is on a call."""
        async with self.db.sessionmaker() as s:
            st = await self.engine.ensure_state(s, agent_id)
            if st.idle_since is not None:
                return None
            on_call = (await s.execute(select(CallRecord.id).where(
                CallRecord.agent_id == agent_id, CallRecord.answered_at.is_not(None), CallRecord.ended_at.is_(None),
                CallRecord.answered_at > utcnow() - timedelta(hours=4)).limit(1))).first()
            if on_call:
                return None  # a long conversation is work, not absence
            agent = await s.get(AgentMapping, agent_id)
            st.idle_since = utcnow()
            old = st.manual_state
            if agent and agent.role != "admin":
                st.manual_state = "offline"
                st.override_ready, st.override_reason = False, ""
            audit(s, "idle_offline", agent_id=agent_id, level="warning", actor_type="system",
                  minutes=minutes, cause=cause, old=old,
                  last_activity=st.last_activity_at.isoformat() if st.last_activity_at else None)
            await s.commit()
        return await self.engine.recompute(agent_id, "idle")

    async def resume_from_idle(self, agent: AgentMapping) -> dict:
        async with self.db.sessionmaker() as s:
            st = await self.engine.ensure_state(s, agent.id)
            was_idle = st.idle_since is not None
            target = None
            if was_idle:
                # continue exactly where the person was before going away (Ready or Break)
                last = (await s.execute(select(AuditLog).where(AuditLog.agent_id == agent.id, AuditLog.action == "idle_offline")
                                        .order_by(AuditLog.id.desc()).limit(1))).scalars().first()
                target = (last.details or {}).get("old") if last else None
                audit(s, "idle_returned", agent_id=agent.id, actor_type="agent", actor_id=agent.id, restored=target)
            st.idle_since, st.last_activity_at = None, utcnow()
            await s.commit()
        if was_idle and agent.role != "admin" and target in ("ready", "break"):
            return await self.set_manual_state(agent.id, target, Actor("system", agent.id), "idle_return")
        return await self.engine.publish(agent.id)

    async def supervisor_override(self, agent_id: int, manual_state: str, ignore_blocking: bool,
                                  reason: str, actor: Actor) -> dict:
        if not reason.strip():
            raise WorkflowError(422, tr("err.override_reason"))
        if manual_state not in ("ready", "break", "offline"):
            raise WorkflowError(422, tr("err.bad_state"))
        async with self.db.sessionmaker() as s:
            st = await self.engine.ensure_state(s, agent_id)
            old = st.manual_state
            st.manual_state = manual_state
            if manual_state != "offline":
                st.idle_since = None
            st.override_ready = bool(ignore_blocking and manual_state == "ready")
            st.override_reason = reason.strip()[:500] if st.override_ready else ""
            audit(s, "supervisor_override", agent_id=agent_id, actor_type="supervisor", actor_id=actor.agent_id,
                  level="warning", old=old, new=manual_state, ignore_blocking=ignore_blocking, reason=reason.strip())
            await s.commit()
        return await self.engine.recompute(agent_id, "supervisor_override")

    async def supervisor_assign(self, ticket_id: int, target: AgentMapping, mode: str | None, actor: Actor) -> dict:
        try:
            await self.zammad.update_ticket(ticket_id, {"owner_id": target.zammad_user_id})
        except ZammadError as exc:
            raise WorkflowError(502, tr("err.zammad_update", error=exc)) from exc
        async with self.db.sessionmaker() as s:
            audit(s, "ticket_reassigned", agent_id=target.id, ticket_id=ticket_id, actor_type="supervisor",
                  actor_id=actor.agent_id, work_mode=mode)
            await s.commit()
        if mode:
            return await self.start_work(target, ticket_id, mode, actor)
        await self.on_ticket_changed(ticket_id, "supervisor_assign")
        return {"assigned": True}

    # ------------------------------------------------------------------ Zammad -> us
    async def on_ticket_changed(self, ticket_id: int, origin: str) -> None:
        """React to changes made directly in Zammad (webhook or periodic reconcile)."""
        async with self.db.sessionmaker() as s:
            sessions = (await s.execute(
                select(WorkSession).where(WorkSession.ticket_id == ticket_id, WorkSession.state == "active")
            )).scalars().all()
        if not sessions:
            return
        try:
            ticket, state = await self._get_ticket(ticket_id)
        except WorkflowError as exc:
            if exc.status != 404:
                log.warning("cannot load ticket %s: %s", ticket_id, exc.message)
                return
            ticket, state = {}, "removed"
        affected: set[int] = set()
        async with self._lock(ticket_id):
            async with self.db.sessionmaker() as s:
                for ws in (await s.execute(
                    select(WorkSession).where(WorkSession.ticket_id == ticket_id, WorkSession.state == "active")
                )).scalars().all():
                    agent = await s.get(AgentMapping, ws.agent_id)
                    if ticket:
                        ws.ticket_title = str(ticket.get("title", ws.ticket_title))[:500]
                    if state in self.settings.final_states:
                        ws.state, ws.ended_at, ws.end_reason = "completed", utcnow(), f"zammad:{state}"
                        audit(s, "work_completed", agent_id=ws.agent_id, ticket_id=ticket_id, actor_type="zammad",
                              origin=origin, zammad_state=state)
                    elif ticket and agent and ticket.get("owner_id") != agent.zammad_user_id:
                        ws.state, ws.ended_at, ws.end_reason = "cancelled", utcnow(), "reassigned_in_zammad"
                        audit(s, "work_cancelled", agent_id=ws.agent_id, ticket_id=ticket_id, actor_type="zammad",
                              origin=origin, reason="reassigned", new_owner=ticket.get("owner_id"))
                    elif state in self.settings.pending_states and ws.work_mode == "blocking":
                        action = self.settings.pending_state_action
                        if action == "background":
                            ws.work_mode = "background"
                            audit(s, "mode_changed", agent_id=ws.agent_id, ticket_id=ticket_id, actor_type="zammad",
                                  origin=origin, old="blocking", new="background", zammad_state=state)
                        elif action == "complete":
                            ws.state, ws.ended_at, ws.end_reason = "completed", utcnow(), f"zammad:{state}"
                            audit(s, "work_completed", agent_id=ws.agent_id, ticket_id=ticket_id,
                                  actor_type="zammad", origin=origin, zammad_state=state)
                        else:
                            continue
                    else:
                        continue
                    affected.add(ws.agent_id)
                await s.commit()
        for agent_id in affected:
            await self.engine.recompute(agent_id, f"zammad:{origin}")

    async def reconcile_zammad(self) -> None:
        async with self.db.sessionmaker() as s:
            ids = (await s.execute(
                select(WorkSession.ticket_id).where(WorkSession.state == "active").distinct()
            )).scalars().all()
        for tid in ids:
            try:
                await self.on_ticket_changed(tid, "periodic")
            except Exception:  # noqa: BLE001
                log.exception("zammad reconcile failed for ticket %s", tid)

    def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="zammad-reconcile")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _loop(self) -> None:
        while True:
            await asyncio.sleep(self.settings.zammad_reconcile_interval_sec)
            try:
                await self.reconcile_zammad()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("zammad reconcile loop failed")
