"""Phone number normalisation for customer lookup (FR-01)."""
import re


def normalize_phone(raw: str | None, country_code: str = "7", national_prefix: str = "8") -> str:
    """Return digits in international form without '+', or '' if nothing usable.

    Examples (country 7, prefix 8): '+7 (912) 345-67-89' -> '79123456789',
    '89123456789' -> '79123456789', '9123456789' -> '79123456789', '00374 91 123456' -> '37491123456'.
    Short internal numbers (<= 6 digits) are returned as-is.
    """
    if not raw:
        return ""
    digits = re.sub(r"\D", "", raw)
    if not digits:
        return ""
    if digits.startswith("00"):
        return digits[2:]
    if len(digits) <= 6:
        return digits
    if raw.strip().startswith("+"):
        return digits
    national_len = 10 if country_code == "7" else None
    if national_prefix and digits.startswith(national_prefix) and national_len and len(digits) == national_len + 1:
        return country_code + digits[1:]
    if national_len and len(digits) == national_len:
        return country_code + digits
    return digits


def phone_matches(a: str | None, b: str | None, **kw) -> bool:
    na, nb = normalize_phone(a, **kw), normalize_phone(b, **kw)
    if not na or not nb:
        return False
    if na == nb:
        return True
    # tolerate missing country code on one side
    tail = min(len(na), len(nb), 10)
    return tail >= 7 and na[-tail:] == nb[-tail:]
