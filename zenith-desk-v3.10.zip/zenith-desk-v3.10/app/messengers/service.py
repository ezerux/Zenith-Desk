"""v3.9 Telegram and WhatsApp chats inside Zenith Desk — one company bot / number for the whole team.

Real time
    Telegram: long polling (works on a LAN server without a public address) or a webhook (instant, needs public_url);
    WhatsApp: Meta's webhook (signed with the app secret).
Fallback (sync hub, every sync_fallback_min)
    Telegram: webhook still registered? undelivered updates waiting at Telegram (failed webhooks)? → drained via
    getUpdates; polling loop alive? WhatsApp: number reachable, token valid. Both: outgoing messages that could not be
    sent are retried (outbox), messages not yet copied to Zammad are copied.
Zammad
    Every conversation is also a Zammad ticket (customer found by phone / created), every message an article —
    so history, reports and “Start” (blocking / background) work exactly as for e-mail (ТЗ, сценарий B).
Idempotency
    A message id of Telegram / WhatsApp is stored with a unique index: a repeated webhook or update never doubles it.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import mimetypes
import re
import secrets
import time
from datetime import timedelta

from sqlalchemy import func, or_, select, update

from ..audit import audit
from ..db import as_utc, utcnow
from ..i18n import t as tr
from ..models import AgentMapping, MsgConversation, MsgFile, MsgMessage
from ..phone import normalize_phone, phone_matches
from ..zammad import ZammadError
from .telegram import TelegramClient, TelegramError
from .whatsapp import WhatsAppClient, WhatsAppError

log = logging.getLogger("messengers")

CHANNELS = ("telegram", "whatsapp")
WINDOW = timedelta(hours=24)  # WhatsApp customer service window


class MsgError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status




class MessengerService:
    def __init__(self, sv):
        self.sv = sv
        self.tg: TelegramClient | None = None
        self.wa: WhatsAppClient | None = None
        self.bot: dict = {}            # getMe of the Telegram bot
        self.wa_phone: dict = {}       # display number of the WhatsApp line
        self._tg_task: asyncio.Task | None = None
        self._tasks: list[asyncio.Task] = []
        self._side: set[asyncio.Task] = set()
        self._kick = asyncio.Event()
        self._mirror_lock = asyncio.Lock()
        self._tg_offset: int | None = None
        self.running = False
        sv.hub.register("telegram", "Telegram", self.fallback_telegram, self.tg_ready)
        sv.hub.register("whatsapp", "WhatsApp", self.fallback_whatsapp, self.wa_ready)

    # ------------------------------------------------------------------ configuration
    @property
    def cfg(self):
        return self.sv.settings

    def tg_ready(self) -> bool:
        return bool(self.cfg.telegram_enabled and self.cfg.telegram_bot_token)

    def wa_ready(self) -> bool:
        return bool(self.cfg.whatsapp_enabled and self.cfg.whatsapp_access_token and self.cfg.whatsapp_phone_number_id)

    def webhook_urls(self, base: str = "") -> dict:
        root = (self.cfg.public_url or base or "").rstrip("/")
        return {"telegram": f"{root}/api/integrations/telegram/webhook" if root else "",
                "whatsapp": f"{root}/api/integrations/whatsapp/webhook" if root else ""}

    async def ensure_secrets(self) -> None:
        """Webhook secrets are generated once and kept (encrypted) with the other settings."""
        need = {}
        if not self.cfg.telegram_webhook_secret:
            need["telegram_webhook_secret"] = secrets.token_urlsafe(24)
        if not self.cfg.whatsapp_verify_token:
            need["whatsapp_verify_token"] = secrets.token_urlsafe(18)
        for k, v in need.items():  # not editable in the panel: stored directly
            setattr(self.cfg, k, v)
        if need:
            await self.sv.store.save_internal(need)

    def _spawn(self, coro) -> asyncio.Task:
        """Fire-and-forget work (downloads, read receipts): referenced until done, finished or cancelled on stop."""
        task = asyncio.create_task(coro)
        self._side.add(task)
        task.add_done_callback(self._side.discard)
        return task

    async def start(self) -> None:
        self.running = True
        await self.ensure_secrets()
        await self.configure()
        self._tasks.append(asyncio.create_task(self._outbox_loop(), name="msg-outbox"))

    async def stop(self) -> None:
        self.running = False
        side = list(self._side)
        if side:  # let downloads in progress finish (short), then cancel
            _, still = await asyncio.wait(side, timeout=3)
            for t in still:
                t.cancel()
            await asyncio.gather(*still, return_exceptions=True)
        for t in [self._tg_task, *self._tasks]:
            if t:
                t.cancel()
        for t in [self._tg_task, *self._tasks]:
            if t:
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass
        self._tg_task, self._tasks = None, []
        await self._close_clients()

    async def _close_clients(self) -> None:
        for c in (self.tg, self.wa):
            if c:
                await c.close()
        self.tg = self.wa = None

    async def configure(self) -> None:
        """(Re)connect after start or after the administrator changed the settings."""
        if self._tg_task:
            self._tg_task.cancel()
            try:
                await self._tg_task
            except (asyncio.CancelledError, Exception):
                pass
            self._tg_task = None
        await self._close_clients()
        hub = self.sv.hub
        if self.tg_ready():
            self.tg = TelegramClient(self.cfg.telegram_bot_token, self.cfg.telegram_api_base)
            if self.running:
                self._tg_task = asyncio.create_task(self._telegram_receiver(), name="telegram")
        else:
            hub.realtime("telegram", False, "")
        if self.wa_ready():
            self.wa = WhatsAppClient(self.cfg.whatsapp_access_token, self.cfg.whatsapp_phone_number_id,
                                     self.cfg.whatsapp_api_version, self.cfg.whatsapp_api_base)
            hub.realtime("whatsapp", "on" if self.cfg.public_url else "off",
                         tr("rt.webhook") if self.cfg.public_url else tr("rt.no_public"))
        else:
            hub.realtime("whatsapp", False, "")

    # ------------------------------------------------------------------ Telegram: receiving
    async def _telegram_receiver(self) -> None:
        hub = self.sv.hub
        delay = 2
        while True:
            try:
                self.bot = await self.tg.get_me()
                if self.cfg.telegram_mode == "webhook" and self.cfg.public_url:
                    url = self.webhook_urls()["telegram"]
                    await self.tg.set_webhook(url, self.cfg.telegram_webhook_secret)
                    hub.realtime("telegram", True, tr("rt.tg_webhook", bot=self.bot.get('username', '')))
                    hub.clear_error("telegram")
                    return  # updates now come to /api/integrations/telegram/webhook
                await self.tg.delete_webhook()
                hub.realtime("telegram", True, tr("rt.tg_polling", bot=self.bot.get('username', '')))
                hub.clear_error("telegram")
                delay = 2
                while True:
                    updates = await self.tg.get_updates(self._tg_offset, 25)
                    for u in updates:
                        await self.handle_telegram_update(u)
                        self._tg_offset = int(u["update_id"]) + 1
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("Telegram receiver: %s", exc)
                hub.realtime("telegram", False, tr("rt.reconnecting"))
                hub.error("telegram", str(exc))
                if isinstance(exc, TelegramError) and exc.code == 409:   # webhook set by someone else / other getUpdates
                    delay = 30
                await asyncio.sleep(delay)
                delay = min(delay * 2, 60)

    async def fallback_telegram(self) -> int:
        """Fallback: repair the webhook, fetch updates Telegram could not deliver, revive the polling loop."""
        if not self.tg:
            return 0
        recovered = 0
        if self.cfg.telegram_mode == "webhook" and self.cfg.public_url:
            info = await self.tg.webhook_info()
            url = self.webhook_urls()["telegram"]
            if info.get("url") != url:
                await self.tg.set_webhook(url, self.cfg.telegram_webhook_secret)
                recovered += 1
            pending = int(info.get("pending_update_count") or 0)
            if pending and info.get("last_error_date") and time.time() - int(info["last_error_date"]) < 3600:
                # Telegram keeps failing to reach us: take the waiting updates ourselves, then restore the webhook
                log.warning("Telegram has %s undelivered update(s): %s", pending, info.get("last_error_message"))
                await self.tg.delete_webhook()
                try:
                    offset = None
                    for _ in range(20):
                        ups = await self.tg.get_updates(offset, 0)
                        if not ups:
                            break
                        for u in ups:
                            if await self.handle_telegram_update(u):
                                recovered += 1
                            offset = int(u["update_id"]) + 1
                    if offset is not None:
                        await self.tg.get_updates(offset, 0)  # confirm
                finally:
                    await self.tg.set_webhook(url, self.cfg.telegram_webhook_secret)
            self.sv.hub.realtime("telegram", True, tr("rt.tg_webhook", bot=self.bot.get('username', '')))
        elif self._tg_task is None or self._tg_task.done():
            self._tg_task = asyncio.create_task(self._telegram_receiver(), name="telegram")
            recovered += 0
        recovered += await self.retry_outbox(force=True)
        recovered += await self.mirror_pending()
        return recovered

    async def handle_telegram_update(self, u: dict) -> bool:
        """One update from Telegram (webhook or getUpdates). Returns True if it was new."""
        self.sv.hub.event("telegram")
        edited = "edited_message" in u
        m = u.get("message") or u.get("edited_message")
        if not m or (m.get("chat") or {}).get("type") != "private":
            return False  # only private chats with the company bot
        chat, frm = m["chat"], m.get("from") or {}
        name = " ".join(filter(None, [frm.get("first_name"), frm.get("last_name")])) or frm.get("username") or str(chat["id"])
        handle = f"@{frm['username']}" if frm.get("username") else ""
        ext = f"{chat['id']}:{m['message_id']}"
        text = m.get("text") or m.get("caption") or ""
        kind, file_ref = "text", None
        if m.get("photo"):
            kind, file_ref = "image", (max(m["photo"], key=lambda p: p.get("file_size") or 0)["file_id"], "photo.jpg", "image/jpeg")
        elif m.get("document"):
            d = m["document"]
            kind, file_ref = "document", (d["file_id"], d.get("file_name") or "file", d.get("mime_type") or "application/octet-stream")
        elif m.get("voice"):
            kind, file_ref = "audio", (m["voice"]["file_id"], "voice.ogg", m["voice"].get("mime_type") or "audio/ogg")
        elif m.get("audio"):
            a = m["audio"]
            kind, file_ref = "audio", (a["file_id"], a.get("file_name") or "audio.mp3", a.get("mime_type") or "audio/mpeg")
        elif m.get("video"):
            v = m["video"]
            kind, file_ref = "video", (v["file_id"], v.get("file_name") or "video.mp4", v.get("mime_type") or "video/mp4")
        elif m.get("sticker"):
            kind, text = "sticker", (m["sticker"].get("emoji") or "") + " [sticker]"
        elif m.get("location"):
            loc = m["location"]
            kind, text = "location", f"📍 https://maps.google.com/?q={loc['latitude']},{loc['longitude']}"
        elif m.get("contact"):
            c = m["contact"]
            kind, text = "text", f"👤 {c.get('first_name', '')} {c.get('last_name', '')} {c.get('phone_number', '')}".strip()
        if edited:
            return await self._edited("telegram", ext, text)
        msg = await self.add_inbound("telegram", str(chat["id"]), name, handle, "", ext, text, kind, file_ref[1] if file_ref else "")
        if msg and file_ref:
            self._spawn(self._fetch_telegram_file(msg.id, msg.conversation_id, *file_ref))
        return msg is not None

    async def _fetch_telegram_file(self, msg_id: int, conv_id: int, file_id: str, name: str, mime: str) -> None:
        try:
            path = await self.tg.file_path(file_id)
            data = await self.tg.download(path, self.cfg.messenger_media_max_mb * 1024 * 1024)
            if name in ("photo.jpg", "file") and "." in path:
                name = path.rsplit("/", 1)[-1]
            await self._attach(msg_id, conv_id, name, mime, data)
        except Exception as exc:  # noqa: BLE001
            log.warning("Telegram file %s: %s", file_id, exc)
            await self._attach_failed(msg_id, name, str(exc))

    # ------------------------------------------------------------------ WhatsApp: receiving
    async def handle_whatsapp(self, body: dict) -> int:
        """The webhook body of Meta (messages and delivery statuses). Returns how many new messages it had."""
        new = 0
        for entry in body.get("entry") or []:
            for ch in entry.get("changes") or []:
                v = ch.get("value") or {}
                pid = str((v.get("metadata") or {}).get("phone_number_id") or "")
                if self.cfg.whatsapp_phone_number_id and pid and pid != str(self.cfg.whatsapp_phone_number_id):
                    continue  # another number of the same app
                names = {c.get("wa_id"): (c.get("profile") or {}).get("name", "") for c in v.get("contacts") or []}
                for m in v.get("messages") or []:
                    self.sv.hub.event("whatsapp")
                    if await self._whatsapp_message(m, names):
                        new += 1
                for st in v.get("statuses") or []:
                    await self._whatsapp_status(st)
        return new

    async def _whatsapp_message(self, m: dict, names: dict) -> bool:
        wa_id = m.get("from", "")
        t = m.get("type", "text")
        text, kind, media = "", "text", None
        if t == "text":
            text = (m.get("text") or {}).get("body", "")
        elif t in ("image", "document", "audio", "video", "sticker"):
            o = m.get(t) or {}
            kind = "image" if t == "sticker" else t
            text = o.get("caption", "")
            ext = mimetypes.guess_extension((o.get("mime_type") or "").split(";")[0]) or ""
            media = (o.get("id"), o.get("filename") or f"{t}{ext}", o.get("mime_type") or "application/octet-stream")
        elif t == "location":
            loc = m.get("location") or {}
            kind, text = "location", f"📍 {loc.get('name') or ''} https://maps.google.com/?q={loc.get('latitude')},{loc.get('longitude')}".strip()
        elif t == "button":
            text = (m.get("button") or {}).get("text", "")
        elif t == "interactive":
            i = m.get("interactive") or {}
            text = (i.get("button_reply") or i.get("list_reply") or {}).get("title", "")
        elif t == "reaction":
            return False
        elif t == "contacts":
            cs = m.get("contacts") or []
            text = "👤 " + ", ".join(f"{(c.get('name') or {}).get('formatted_name', '')} {' '.join(p.get('phone', '') for p in c.get('phones') or [])}" for c in cs)
        else:
            text = f"[{t}]"
        phone = "+" + wa_id if wa_id and not wa_id.startswith("+") else wa_id
        msg = await self.add_inbound("whatsapp", wa_id, names.get(wa_id) or phone, phone, phone, m.get("id"), text, kind,
                                     media[1] if media and media[0] else "")
        if msg and media and media[0]:
            self._spawn(self._fetch_whatsapp_media(msg.id, msg.conversation_id, *media))
        if msg and self.wa:
            self._spawn(self._safe(self.wa.mark_read(m.get("id"))))  # blue ticks for the customer
        return msg is not None

    async def _fetch_whatsapp_media(self, msg_id: int, conv_id: int, media_id: str, name: str, mime: str) -> None:
        try:
            data, real_mime = await self.wa.download_media(media_id, self.cfg.messenger_media_max_mb * 1024 * 1024)
            await self._attach(msg_id, conv_id, name, real_mime or mime, data)
        except Exception as exc:  # noqa: BLE001
            log.warning("WhatsApp media %s: %s", media_id, exc)
            await self._attach_failed(msg_id, name, str(exc))

    async def _whatsapp_status(self, st: dict) -> None:
        order = {"queued": 0, "sent": 1, "delivered": 2, "read": 3}
        status = st.get("status", "")
        async with self.sv.db.sessionmaker() as s:
            msg = (await s.execute(select(MsgMessage).where(MsgMessage.channel == "whatsapp", MsgMessage.external_id == st.get("id")))).scalars().first()
            if msg is None:
                return
            if status == "failed":
                err = (st.get("errors") or [{}])[0]
                msg.status, msg.error = "failed", f"{err.get('title') or err.get('message') or 'failed'} ({err.get('code', '')})"[:500]
            elif order.get(status, -1) > order.get(msg.status, -1):
                msg.status = status
            else:
                return
            await s.commit()
            conv_id = msg.conversation_id
        self._publish(conv_id, "status")

    # ------------------------------------------------------------------ storing incoming messages
    async def add_inbound(self, channel: str, external_id: str, name: str, handle: str, phone: str,
                          ext_msg_id: str | None, text: str, kind: str = "text", pending_file: str = "") -> MsgMessage | None:
        cipher = self.sv.cipher
        async with self.sv.db.sessionmaker() as s:
            if ext_msg_id and (await s.execute(select(MsgMessage.id).where(MsgMessage.channel == channel, MsgMessage.external_id == ext_msg_id))).first():
                return None  # the same message again (repeated webhook / update): ignore
            conv = (await s.execute(select(MsgConversation).where(MsgConversation.channel == channel, MsgConversation.external_id == external_id))).scalars().first()
            now = utcnow()
            reopened = False
            if conv is None:
                conv = MsgConversation(channel=channel, external_id=external_id, name=name[:255], handle=handle[:255], phone=phone[:50],
                                       status="open", unread=0, last_text="", last_direction="in", last_message_at=now,
                                       zammad_ticket_number="")
                s.add(conv)
                await s.flush()
                audit(s, "msg_conversation_new", channel=channel, conversation_id=conv.id)
            else:
                if name and conv.name != name and conv.name in ("", conv.handle, conv.phone, conv.external_id):
                    conv.name = name[:255]
                if handle and not conv.handle:
                    conv.handle = handle[:255]
                if conv.status == "closed":
                    conv.status, conv.closed_at, reopened = "open", None, True
            preview = text or {"image": "🖼", "document": "📎", "audio": "🎤", "video": "🎬"}.get(kind, "")
            msg = MsgMessage(conversation_id=conv.id, channel=channel, direction="in", external_id=ext_msg_id, body=cipher.seal(text),
                             files=[{"name": pending_file, "pending": True}] if pending_file else [], kind=kind, status="received", error="", attempts=0, mirrored=False, created_at=now)
            s.add(msg)
            conv.unread += 1
            conv.last_text, conv.last_direction, conv.last_message_at, conv.last_inbound_at = cipher.seal(preview[:300]), "in", now, now
            try:
                await s.commit()
            except Exception:  # noqa: BLE001 — a parallel delivery of the same message won the race
                await s.rollback()
                return None
            await s.refresh(msg)
            assignee = conv.assignee_id
            conv_id, conv_name = conv.id, conv.name
        self._publish(conv_id, "message", reopened=reopened)
        self._notify(conv_id, channel, conv_name, preview, assignee)
        self.kick_mirror()
        return msg

    async def _edited(self, channel: str, ext: str, text: str) -> bool:
        async with self.sv.db.sessionmaker() as s:
            msg = (await s.execute(select(MsgMessage).where(MsgMessage.channel == channel, MsgMessage.external_id == ext))).scalars().first()
            if msg is None:
                return False
            msg.body = self.sv.cipher.seal(text + " ✎")
            await s.commit()
            conv_id = msg.conversation_id
        self._publish(conv_id, "message")
        return False

    async def _attach(self, msg_id: int, conv_id: int, name: str, mime: str, data: bytes) -> None:
        key = secrets.token_urlsafe(24)
        async with self.sv.db.sessionmaker() as s:
            s.add(MsgFile(key=key, conversation_id=conv_id, name=name[:255], mime=mime[:150], size=len(data), data=data))
            msg = await s.get(MsgMessage, msg_id)
            files = [f for f in (msg.files or []) if not f.get("pending")]
            msg.files = files + [{"name": name, "mime": mime, "size": len(data), "key": key}]
            await s.commit()
        self._publish(conv_id, "file")
        self.kick_mirror()

    async def _attach_failed(self, msg_id: int, name: str, error: str) -> None:
        async with self.sv.db.sessionmaker() as s:
            msg = await s.get(MsgMessage, msg_id)
            if msg:
                msg.files = [f for f in (msg.files or []) if not f.get("pending")] + [{"name": name, "error": error[:200]}]
                await s.commit()
                conv_id = msg.conversation_id
        if msg:
            self._publish(conv_id, "file")
            self.kick_mirror()

    # ------------------------------------------------------------------ live updates and notifications
    def _publish(self, conv_id: int, what: str, **extra) -> None:
        self.sv.broker.publish_all("msg", {"conversation_id": conv_id, "what": what, **extra})

    def _notify(self, conv_id: int, channel: str, name: str, text: str, assignee: int | None) -> None:
        payload = {"conversation_id": conv_id, "channel": channel, "name": name, "text": text[:140], "assignee_id": assignee}
        if assignee:
            self.sv.broker.publish_agent(assignee, "msg_new", payload)
            self.sv.push.notify_later(assignee, {"type": "msg", "title": f"{channel.title()}: {name}", "body": text[:140],
                                                 "conversation_id": conv_id, "channel": channel})
        else:
            self.sv.broker.publish_all("msg_new", payload)

    @staticmethod
    async def _safe(coro) -> None:
        try:
            await coro
        except Exception as exc:  # noqa: BLE001
            log.debug("background: %s", exc)

    # ------------------------------------------------------------------ operator actions
    async def send(self, agent: AgentMapping, conv_id: int, text: str = "", files: list[dict] | None = None,
                   note: bool = False, template: str = "") -> dict:
        text = (text or "").strip()
        files = files or []
        if not text and not files and not template:
            raise MsgError("empty message", 422)
        limit = self.cfg.messenger_media_max_mb * 1024 * 1024
        decoded = []
        for f in files[:10]:
            try:
                data = base64.b64decode(f.get("data") or "", validate=True)
            except ValueError as exc:
                raise MsgError("bad file", 422) from exc
            if len(data) > limit:
                raise MsgError(f"{f.get('name')}: > {self.cfg.messenger_media_max_mb} MB", 413)
            decoded.append((str(f.get("name") or "file")[:200], str(f.get("mime") or mimetypes.guess_type(f.get("name") or "")[0] or "application/octet-stream"), data))
        async with self.sv.db.sessionmaker() as s:
            conv = await s.get(MsgConversation, conv_id)
            if conv is None:
                raise MsgError("not found", 404)
            if not note:
                if conv.assignee_id and conv.assignee_id != agent.id and agent.role == "operator":
                    other = await s.get(AgentMapping, conv.assignee_id)
                    raise MsgError(f"taken by {other.display_name if other else '?'}", 409)
                if conv.channel == "whatsapp" and not template and (conv.last_inbound_at is None or utcnow() - as_utc(conv.last_inbound_at) > WINDOW):
                    raise MsgError("whatsapp_window", 409)
                if conv.channel == "telegram" and not self.tg or conv.channel == "whatsapp" and not self.wa:
                    raise MsgError(f"{conv.channel} is not connected", 503)
                if conv.assignee_id is None:
                    conv.assignee_id = agent.id  # whoever answers first takes the chat
                    audit(s, "msg_taken", agent_id=agent.id, actor_type="agent", actor_id=agent.id, conversation_id=conv.id)
                if conv.status == "closed":
                    conv.status, conv.closed_at = "open", None
            stored = []
            for name, mime, data in decoded:
                key = secrets.token_urlsafe(24)
                s.add(MsgFile(key=key, conversation_id=conv.id, name=name, mime=mime, size=len(data), data=data))
                stored.append({"name": name, "mime": mime, "size": len(data), "key": key})
            body = text if not template else f"[template] {template}"
            msg = MsgMessage(conversation_id=conv.id, channel=conv.channel, direction="note" if note else "out", author_id=agent.id,
                             body=self.sv.cipher.seal(body), files=stored, kind="template" if template else ("document" if stored and not text else "text"),
                             status="sent" if note else "queued", error="", attempts=0, mirrored=False, created_at=utcnow(),
                             next_try_at=None if note else utcnow())
            s.add(msg)
            if not note:
                conv.last_text, conv.last_direction, conv.last_message_at = self.sv.cipher.seal((body or "📎")[:300]), "out", utcnow()
                conv.unread = 0
            await s.commit()
            msg_id = msg.id
        if not note:
            await self.deliver(msg_id)
        self._publish(conv_id, "message")
        self.kick_mirror()
        return await self.message_view(msg_id)

    async def deliver(self, msg_id: int) -> bool:
        """Send one outgoing message to Telegram / WhatsApp. Temporary problems → retried by the outbox."""
        async with self.sv.db.sessionmaker() as s:
            msg = await s.get(MsgMessage, msg_id)
            if msg is None or msg.status not in ("queued",):
                return False
            conv = await s.get(MsgConversation, msg.conversation_id)
            files = []
            for f in msg.files or []:
                row = (await s.execute(select(MsgFile).where(MsgFile.key == f.get("key")))).scalars().first()
                if row:
                    files.append((row.name, row.mime, row.data))
            text = self.sv.cipher.open(msg.body)
            channel, to = conv.channel, conv.external_id
        ext_ids, error, retry = [], "", False
        try:
            if channel == "telegram":
                if not self.tg:
                    raise TelegramError("Telegram is not connected", 503)
                if files:
                    for i, (name, mime, data) in enumerate(files):
                        r = await self.tg.send_file(to, name, mime, data, text if i == 0 else "")
                        ext_ids.append(f"{to}:{r['message_id']}")
                else:
                    r = await self.tg.send_message(to, text)
                    ext_ids.append(f"{to}:{r['message_id']}")
            else:
                if not self.wa:
                    raise WhatsAppError("WhatsApp is not connected", 503, True)
                if msg.kind == "template":
                    name, _, lang = text.replace("[template] ", "").partition(":")
                    ext_ids.append(await self.wa.send_template(to, name.strip(), (lang or "en").strip()))
                elif files:
                    for i, (name, mime, data) in enumerate(files):
                        ext_ids.append(await self.wa.send_media(to, name, mime, data, text if i == 0 else ""))
                else:
                    ext_ids.append(await self.wa.send_text(to, text))
        except TelegramError as exc:
            error, retry = str(exc), exc.code in (0, 429, 500, 502, 503, 504) or exc.retry_after > 0
        except WhatsAppError as exc:
            error, retry = str(exc), exc.retryable
        except Exception as exc:  # noqa: BLE001
            error, retry = str(exc), True
        async with self.sv.db.sessionmaker() as s:
            msg = await s.get(MsgMessage, msg_id)
            msg.attempts += 1
            if not error:
                msg.status, msg.error, msg.sent_at, msg.next_try_at = "sent", "", utcnow(), None
                msg.external_id = ext_ids[0] if ext_ids else None
            elif retry and msg.attempts < 12:
                msg.status, msg.error = "queued", error[:500]
                msg.next_try_at = utcnow() + timedelta(seconds=min(15 * 2 ** (msg.attempts - 1), 1800))
            else:
                msg.status, msg.error, msg.next_try_at = "failed", error[:500], None
            await s.commit()
        if error:
            log.warning("send %s message %s: %s", channel, msg_id, error)
            self.sv.hub.error(channel, error)
        self._publish(msg.conversation_id, "status")
        return not error

    async def retry_outbox(self, force: bool = False) -> int:
        async with self.sv.db.sessionmaker() as s:
            q = select(MsgMessage.id).where(MsgMessage.status == "queued")
            if not force:
                q = q.where(MsgMessage.next_try_at <= utcnow())
            ids = (await s.execute(q.order_by(MsgMessage.id).limit(100))).scalars().all()
        n = 0
        for i in ids:
            if await self.deliver(i):
                n += 1
        return n

    async def resend(self, agent: AgentMapping, msg_id: int) -> dict:
        async with self.sv.db.sessionmaker() as s:
            msg = await s.get(MsgMessage, msg_id)
            if msg is None or msg.direction != "out":
                raise MsgError("not found", 404)
            msg.status, msg.attempts, msg.next_try_at, msg.error = "queued", 0, utcnow(), ""
            await s.commit()
        await self.deliver(msg_id)
        return await self.message_view(msg_id)

    async def _outbox_loop(self) -> None:
        while True:
            try:
                await asyncio.wait_for(self._kick.wait(), timeout=15)
            except asyncio.TimeoutError:
                pass
            self._kick.clear()
            try:
                await self.retry_outbox()
                await self.mirror_pending()
                await self.auto_close()
            except Exception:  # noqa: BLE001
                log.exception("messenger outbox")

    def kick_mirror(self) -> None:
        self._kick.set()

    async def assign(self, agent: AgentMapping, conv_id: int, to_agent: int | None) -> dict:
        async with self.sv.db.sessionmaker() as s:
            conv = await s.get(MsgConversation, conv_id)
            if conv is None:
                raise MsgError("not found", 404)
            if to_agent is not None and (await s.get(AgentMapping, to_agent)) is None:
                raise MsgError("no such user", 404)
            prev = conv.assignee_id
            conv.assignee_id = to_agent
            if to_agent and conv.status == "closed":
                conv.status, conv.closed_at = "open", None
            audit(s, "msg_assigned", agent_id=to_agent, actor_type="agent", actor_id=agent.id, conversation_id=conv.id, previous=prev)
            if to_agent and to_agent != agent.id:
                s.add(MsgMessage(conversation_id=conv.id, channel=conv.channel, direction="event", author_id=agent.id,
                                 body=self.sv.cipher.seal(f"assigned:{to_agent}"), files=[], kind="text", status="sent", error="",
                                 attempts=0, mirrored=True, created_at=utcnow()))
            await s.commit()
            name = conv.name
        self._publish(conv_id, "assign")
        if to_agent and to_agent != agent.id:
            self.sv.broker.publish_agent(to_agent, "msg_new", {"conversation_id": conv_id, "channel": "", "name": name, "text": "", "assigned_by": agent.display_name})
        return await self.conversation_view(conv_id)

    async def set_status(self, agent: AgentMapping, conv_id: int, status: str) -> dict:
        async with self.sv.db.sessionmaker() as s:
            conv = await s.get(MsgConversation, conv_id)
            if conv is None:
                raise MsgError("not found", 404)
            conv.status = status
            conv.closed_at = utcnow() if status == "closed" else None
            if status == "closed":
                conv.unread = 0
            audit(s, f"msg_{status}", actor_type="agent", actor_id=agent.id, conversation_id=conv.id)
            await s.commit()
            ticket_id = conv.zammad_ticket_id
        if status == "closed" and ticket_id and self.cfg.messenger_zammad_mirror:
            try:  # the chat ticket is finished too
                state = (self.cfg.complete_states or ["closed"])[0]
                await self.sv.zammad.update_ticket(ticket_id, {"state": state}, on_behalf_of=agent.zammad_user_id)
            except Exception as exc:  # noqa: BLE001
                log.warning("close ticket %s: %s", ticket_id, exc)
        self._publish(conv_id, "status")
        return await self.conversation_view(conv_id)

    async def mark_read(self, agent: AgentMapping, conv_id: int) -> None:
        async with self.sv.db.sessionmaker() as s:
            conv = await s.get(MsgConversation, conv_id)
            if conv is None or not conv.unread:
                return
            if conv.assignee_id in (None, agent.id):
                conv.unread = 0
                await s.commit()
                self._publish(conv_id, "read")

    async def auto_close(self) -> int:
        days = self.cfg.messenger_auto_close_days
        if days <= 0:
            return 0
        async with self.sv.db.sessionmaker() as s:
            res = await s.execute(update(MsgConversation).where(MsgConversation.status == "open",
                                  MsgConversation.last_message_at < utcnow() - timedelta(days=days)).values(status="closed", closed_at=utcnow(), unread=0))
            await s.commit()
            return res.rowcount or 0

    # ------------------------------------------------------------------ Zammad: every chat is a ticket
    async def mirror_pending(self) -> int:
        if not self.cfg.messenger_zammad_mirror:
            return 0
        async with self._mirror_lock:
            async with self.sv.db.sessionmaker() as s:
                rows = (await s.execute(select(MsgMessage).where(MsgMessage.mirrored.is_(False), MsgMessage.direction.in_(("in", "out", "note")),
                                                               MsgMessage.status != "queued")
                                        .order_by(MsgMessage.id).limit(200))).scalars().all()
                ids = [(m.id, m.conversation_id) for m in rows]
            done = 0
            failed_convs: set[int] = set()
            for mid, cid in ids:
                if cid in failed_convs:
                    continue
                try:
                    await self._mirror_one(mid)
                    done += 1
                except Exception as exc:  # noqa: BLE001 — Zammad down: tried again by the outbox / fallback check
                    failed_convs.add(cid)
                    log.warning("copy chat message %s to Zammad: %s", mid, exc)
                    self.sv.hub.error("zammad", f"chat → ticket: {exc}")
            return done

    async def _mirror_one(self, msg_id: int) -> None:
        z = self.sv.zammad
        async with self.sv.db.sessionmaker() as s:
            msg = await s.get(MsgMessage, msg_id)
            if msg is None or msg.mirrored:
                return
            conv = await s.get(MsgConversation, msg.conversation_id)
            author = await s.get(AgentMapping, msg.author_id) if msg.author_id else None
            text = self.sv.cipher.open(msg.body)
            atts = []
            if any(f.get("pending") for f in msg.files or []):
                if utcnow() - as_utc(msg.created_at) < timedelta(minutes=10):
                    return  # wait for the file to arrive
                msg.files = [f for f in msg.files if not f.get("pending")] + [{"name": "file", "error": "not received"}]
            for f in msg.files or []:
                row = (await s.execute(select(MsgFile).where(MsgFile.key == f.get("key")))).scalars().first() if f.get("key") else None
                if row:
                    atts.append({"filename": row.name, "data": base64.b64encode(row.data).decode(), "mime-type": row.mime})
            channel = "Telegram" if conv.channel == "telegram" else "WhatsApp"
            who = conv.name or conv.handle
            arrow = {"in": f"{channel} ← {who}", "out": f"{channel} → {who}", "note": f"{channel} · note"}[msg.direction]
            body = f"{arrow}\n\n{text}" if text else arrow
            obo = author.zammad_user_id if author else None
            ticket_id = conv.zammad_ticket_id
            if ticket_id:
                try:
                    t = await z.get_ticket(ticket_id)
                    state = (t.get("state") or "") if isinstance(t.get("state"), str) else ""
                    if not state and t.get("state_id"):
                        state = (await z.ticket_states()).get(int(t["state_id"]), "")
                    if state.lower() in self.sv.settings.final_states and msg.direction == "in":
                        ticket_id = None  # the old ticket is finished: a new message starts a new ticket
                except ZammadError as exc:
                    if exc.status == 404:
                        ticket_id = None
                    else:
                        raise
            article = {"body": body, "type": "note", "internal": msg.direction == "note", "content_type": "text/plain",
                       "sender": "Customer" if msg.direction == "in" else "Agent", "subject": f"{channel}: {who}"}
            if atts:
                article["attachments"] = atts
            if not ticket_id:
                customer_id = conv.zammad_customer_id or await self._find_or_create_customer(conv)
                group = self.cfg.messenger_zammad_group or self.cfg.zammad_default_group
                t = await z.create_ticket({"title": f"{channel}: {who}", "group": group, "customer_id": customer_id, "article": article})
                ticket_id = int(t["id"])
                conv.zammad_ticket_id, conv.zammad_ticket_number, conv.zammad_customer_id = ticket_id, str(t.get("number") or ""), customer_id
                msg.zammad_article_id = None
                self.sv.desk._mark_ours(ticket_id) if hasattr(self.sv.desk, "_mark_ours") else None
                audit(s, "msg_ticket_created", conversation_id=conv.id, ticket=conv.zammad_ticket_number)
            else:
                a = await z.add_article({"ticket_id": ticket_id, **article}, on_behalf_of=obo if msg.direction != "in" else None)
                msg.zammad_article_id = a.get("id")
            msg.mirrored = True
            await s.commit()
            conv_id = conv.id
        self._publish(conv_id, "ticket")

    async def _find_or_create_customer(self, conv: MsgConversation) -> int:
        z = self.sv.zammad
        if conv.phone:
            kw = {"country_code": self.cfg.phone_country_code, "national_prefix": self.cfg.phone_national_prefix}
            norm = normalize_phone(conv.phone, **kw)
            if len(norm) >= 5:
                for u in await z.search_users(norm[-10:]):
                    if any(phone_matches(norm, u.get(f), **kw) for f in ("phone", "mobile")):
                        return int(u["id"])
        if conv.channel == "telegram":
            for u in await z.search_users(f"telegram {conv.external_id}"):
                if f"telegram:{conv.external_id}" in (u.get("note") or ""):
                    return int(u["id"])
        first, _, last = (conv.name or conv.handle or "").partition(" ")
        data = {"firstname": first or conv.handle, "lastname": last, "roles": ["Customer"],
                "note": f"{conv.channel}:{conv.external_id} {conv.handle}".strip()}
        if conv.phone:
            data["mobile"] = conv.phone
        u = await z.create_user(data)
        try:
            await self.sv.directory.upsert_one({"roles": ["Customer"], **u})
        except Exception:  # noqa: BLE001
            pass
        return int(u["id"])

    async def fallback_whatsapp(self) -> int:
        """WhatsApp cannot be asked for missed messages (Meta retries webhooks for up to 7 days); the fallback checks the
        number and the token, re-sends what could not be sent and copies to Zammad what is not there yet."""
        if not self.wa:
            return 0
        info = await self.wa.phone_info()
        self.wa_phone = info
        self.sv.hub.realtime("whatsapp", "on" if self.cfg.public_url else "off",
                             tr("rt.wa_webhook", number=info.get('display_phone_number', '')) if self.cfg.public_url else tr("rt.no_public"))
        return await self.retry_outbox(force=True) + await self.mirror_pending()

    # ------------------------------------------------------------------ views for the API
    def _quick(self) -> list[dict]:
        out = []
        for line in (self.cfg.messenger_quick_replies or "").splitlines():
            if "|" in line:
                title, _, text = line.partition("|")
                if title.strip() and text.strip():
                    out.append({"title": title.strip(), "text": text.strip()})
        return out

    def templates(self) -> list[dict]:
        out = []
        for part in (self.cfg.whatsapp_templates or "").split(","):
            name, _, lang = part.strip().partition(":")
            if name:
                out.append({"name": name.strip(), "language": (lang or "en").strip()})
        return out

    async def conversation_view(self, conv_id: int, conv: MsgConversation | None = None, names: dict | None = None) -> dict:
        if conv is None:
            async with self.sv.db.sessionmaker() as s:
                conv = await s.get(MsgConversation, conv_id)
                if conv is None:
                    raise MsgError("not found", 404)
                if names is None and conv.assignee_id:
                    a = await s.get(AgentMapping, conv.assignee_id)
                    names = {a.id: a.display_name} if a else {}
        window = None
        if conv.channel == "whatsapp":
            window = (as_utc(conv.last_inbound_at) + WINDOW).isoformat() if conv.last_inbound_at else None
        return {
            "id": conv.id, "channel": conv.channel, "name": conv.name, "handle": conv.handle, "phone": conv.phone,
            "status": conv.status, "unread": conv.unread, "assignee_id": conv.assignee_id,
            "assignee_name": (names or {}).get(conv.assignee_id, "") if conv.assignee_id else "",
            "last_text": self.sv.cipher.open(conv.last_text) if conv.last_text else "", "last_direction": conv.last_direction,
            "last_message_at": as_utc(conv.last_message_at).isoformat(), "window_until": window,
            "window_open": bool(window) and utcnow() - as_utc(conv.last_inbound_at) < WINDOW if conv.channel == "whatsapp" else True,
            "ticket_id": conv.zammad_ticket_id, "ticket_number": conv.zammad_ticket_number, "customer_id": conv.zammad_customer_id,
        }

    async def message_view(self, msg_id: int, msg: MsgMessage | None = None, names: dict | None = None) -> dict:
        if msg is None:
            async with self.sv.db.sessionmaker() as s:
                msg = await s.get(MsgMessage, msg_id)
                if names is None and msg.author_id:
                    a = await s.get(AgentMapping, msg.author_id)
                    names = {a.id: a.display_name} if a else {}
        return {"id": msg.id, "direction": msg.direction, "kind": msg.kind, "text": self.sv.cipher.open(msg.body),
                "files": [{k: f.get(k) for k in ("name", "mime", "size", "key", "error", "pending")} for f in msg.files or []],
                "status": msg.status, "error": msg.error, "author_id": msg.author_id,
                "author_name": (names or {}).get(msg.author_id, "") if msg.author_id else "",
                "created_at": as_utc(msg.created_at).isoformat(), "ticket_article": msg.zammad_article_id, "mirrored": msg.mirrored}

    async def list(self, agent: AgentMapping, view: str = "open", channel: str = "", q: str = "", limit: int = 100) -> dict:
        async with self.sv.db.sessionmaker() as s:
            stmt = select(MsgConversation)
            if channel in CHANNELS:
                stmt = stmt.where(MsgConversation.channel == channel)
            if view == "mine":
                stmt = stmt.where(MsgConversation.assignee_id == agent.id, MsgConversation.status == "open")
            elif view == "unassigned":
                stmt = stmt.where(MsgConversation.assignee_id.is_(None), MsgConversation.status == "open")
            elif view == "closed":
                stmt = stmt.where(MsgConversation.status == "closed")
            else:
                stmt = stmt.where(MsgConversation.status == "open")
            if q.strip():
                like = f"%{q.strip().lower()}%"
                digits = re.sub(r"\D", "", q)
                conds = [func.lower(MsgConversation.name).like(like), func.lower(MsgConversation.handle).like(like),
                         MsgConversation.zammad_ticket_number.like(f"%{q.strip()}%")]
                if len(digits) >= 3:
                    conds.append(MsgConversation.external_id.like(f"%{digits}%"))
                stmt = stmt.where(or_(*conds))
            rows = (await s.execute(stmt.order_by(MsgConversation.last_message_at.desc()).limit(limit))).scalars().all()
            names = {a.id: a.display_name for a in (await s.execute(select(AgentMapping))).scalars().all()}
        return {"items": [await self.conversation_view(c.id, c, names) for c in rows], "counts": await self.counts(agent, channel)}

    async def counts(self, agent: AgentMapping, channel: str = "") -> dict:
        """Unread chats per messenger (side menu); Mine / Unassigned of the shown messenger (or of all)."""
        async with self.sv.db.sessionmaker() as s:
            rows = (await s.execute(select(MsgConversation.channel, MsgConversation.assignee_id, MsgConversation.unread)
                                    .where(MsgConversation.status == "open"))).all()
        out = {"telegram": 0, "whatsapp": 0, "mine": 0, "unassigned": 0, "open": len(rows),
               "enabled": {"telegram": self.tg_ready(), "whatsapp": self.wa_ready()}}
        for ch, who, unread in rows:
            visible = who in (None, agent.id)
            if unread and visible:
                out[ch] += 1
            if channel and ch != channel:
                continue
            if who == agent.id:
                out["mine"] += 1
            if who is None:
                out["unassigned"] += 1
        return out

    async def detail(self, agent: AgentMapping, conv_id: int, before: int | None = None, limit: int = 60) -> dict:
        async with self.sv.db.sessionmaker() as s:
            conv = await s.get(MsgConversation, conv_id)
            if conv is None:
                raise MsgError("not found", 404)
            q = select(MsgMessage).where(MsgMessage.conversation_id == conv_id)
            if before:
                q = q.where(MsgMessage.id < before)
            msgs = list(reversed((await s.execute(q.order_by(MsgMessage.id.desc()).limit(limit))).scalars().all()))
            names = {a.id: a.display_name for a in (await s.execute(select(AgentMapping))).scalars().all()}
        return {"conversation": await self.conversation_view(conv_id, conv, names),
                "messages": [await self.message_view(m.id, m, names) for m in msgs],
                "more": len(msgs) == limit, "quick_replies": self._quick(),
                "templates": self.templates() if conv.channel == "whatsapp" else []}

    async def file(self, key: str) -> MsgFile | None:
        async with self.sv.db.sessionmaker() as s:
            return (await s.execute(select(MsgFile).where(MsgFile.key == key))).scalars().first()

    async def test(self, channel: str, values: dict) -> dict:
        """Admin "Test connection" with the entered (or saved) values."""
        try:
            if channel == "telegram":
                token = values.get("telegram_bot_token") or self.cfg.telegram_bot_token
                if not token:
                    return {"ok": False, "detail": "bot token is empty"}
                c = TelegramClient(token, self.cfg.telegram_api_base, timeout=10)
                try:
                    me = await c.get_me()
                    info = await c.webhook_info()
                finally:
                    await c.close()
                hook = f" · webhook: {info.get('url')}" if info.get("url") else ""
                return {"ok": True, "detail": f"@{me.get('username')} ({me.get('first_name')}){hook}"}
            token = values.get("whatsapp_access_token") or self.cfg.whatsapp_access_token
            pid = values.get("whatsapp_phone_number_id") or self.cfg.whatsapp_phone_number_id
            if not token or not pid:
                return {"ok": False, "detail": "phone number ID and access token are required"}
            c = WhatsAppClient(token, pid, values.get("whatsapp_api_version") or self.cfg.whatsapp_api_version, self.cfg.whatsapp_api_base, timeout=10)
            try:
                info = await c.phone_info()
            finally:
                await c.close()
            return {"ok": True, "detail": f"{info.get('display_phone_number', '')} · {info.get('verified_name', '')} · quality {info.get('quality_rating', '?')}"}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "detail": str(exc)[:300]}
