"""WhatsApp Business Cloud API client (Meta Graph API) — only what Zenith Desk needs.

https://developers.facebook.com/docs/whatsapp/cloud-api
"""
from __future__ import annotations

import hashlib
import hmac

import httpx


class WhatsAppError(Exception):
    def __init__(self, message: str, code: int = 0, retryable: bool = False):
        super().__init__(message)
        self.code, self.retryable = code, retryable


def verify_signature(app_secret: str, body: bytes, header: str) -> bool:
    """X-Hub-Signature-256: sha256=<hex HMAC of the raw body with the app secret>."""
    if not app_secret or not header.startswith("sha256="):
        return False
    expect = hmac.new(app_secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expect, header[7:])


class WhatsAppClient:
    def __init__(self, token: str, phone_number_id: str, version: str = "v21.0", base: str = "https://graph.facebook.com",
                 timeout: float = 20.0):
        self.token, self.phone_id = token, phone_number_id
        self.root = f"{base.rstrip('/')}/{version}"
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0), headers={"Authorization": f"Bearer {token}"})

    async def close(self) -> None:
        await self.http.aclose()

    async def _req(self, method: str, path: str, **kw) -> dict:
        try:
            r = await self.http.request(method, f"{self.root}/{path.lstrip('/')}", **kw)
        except httpx.HTTPError as exc:
            raise WhatsAppError(f"WhatsApp: {type(exc).__name__}: {exc}", retryable=True) from exc
        try:
            data = r.json()
        except ValueError:
            data = {}
        if r.status_code >= 400 or "error" in data:
            err = data.get("error") or {}
            code = err.get("code") or r.status_code
            # 130429 rate limit, 131016 service unavailable, 5xx — try again later
            retry = r.status_code >= 500 or r.status_code == 429 or code in (4, 80007, 130429, 131016, 131048, 133004)
            raise WhatsAppError(f"WhatsApp: {err.get('message') or r.status_code} ({code})", code, retry)
        return data

    async def phone_info(self) -> dict:
        return await self._req("GET", self.phone_id, params={"fields": "display_phone_number,verified_name,quality_rating,status"})

    async def _send(self, payload: dict) -> str:
        data = await self._req("POST", f"{self.phone_id}/messages", json={"messaging_product": "whatsapp", "recipient_type": "individual", **payload})
        return (data.get("messages") or [{}])[0].get("id", "")

    async def send_text(self, to: str, text: str) -> str:
        return await self._send({"to": to, "type": "text", "text": {"body": text, "preview_url": True}})

    async def send_template(self, to: str, name: str, language: str) -> str:
        return await self._send({"to": to, "type": "template", "template": {"name": name, "language": {"code": language}}})

    async def upload(self, name: str, mime: str, data: bytes) -> str:
        res = await self._req("POST", f"{self.phone_id}/media", data={"messaging_product": "whatsapp", "type": mime},
                              files={"file": (name, data, mime)})
        return res["id"]

    async def send_media(self, to: str, name: str, mime: str, data: bytes, caption: str = "") -> str:
        media_id = await self.upload(name, mime, data)
        kind = "image" if mime in ("image/jpeg", "image/png") else "audio" if mime.startswith("audio/") else \
               "video" if mime in ("video/mp4", "video/3gpp") else "document"
        obj: dict = {"id": media_id}
        if kind == "document":
            obj["filename"] = name
        if caption and kind in ("image", "document", "video"):
            obj["caption"] = caption[:1024]
        return await self._send({"to": to, "type": kind, kind: obj})

    async def mark_read(self, message_id: str) -> None:
        await self._req("POST", f"{self.phone_id}/messages", json={"messaging_product": "whatsapp", "status": "read", "message_id": message_id})

    async def download_media(self, media_id: str, limit: int) -> tuple[bytes, str]:
        meta = await self._req("GET", media_id)
        url, mime = meta.get("url", ""), meta.get("mime_type", "application/octet-stream")
        try:
            async with self.http.stream("GET", url) as r:
                if r.status_code != 200:
                    raise WhatsAppError(f"WhatsApp media: HTTP {r.status_code}", r.status_code, r.status_code >= 500)
                out = bytearray()
                async for chunk in r.aiter_bytes():
                    out += chunk
                    if len(out) > limit:
                        raise WhatsAppError("file too large")
                return bytes(out), mime
        except httpx.HTTPError as exc:
            raise WhatsAppError(f"WhatsApp media: {exc}", retryable=True) from exc
