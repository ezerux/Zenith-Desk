"""Telegram Bot API client (https://core.telegram.org/bots/api) — only what Zenith Desk needs."""
from __future__ import annotations

import httpx


class TelegramError(Exception):
    def __init__(self, message: str, code: int = 0, retry_after: int = 0):
        super().__init__(message)
        self.code, self.retry_after = code, retry_after


class TelegramClient:
    def __init__(self, token: str, base: str = "https://api.telegram.org", timeout: float = 20.0):
        self.token = token
        self.base = base.rstrip("/")
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0))

    async def close(self) -> None:
        await self.http.aclose()

    def _url(self, method: str) -> str:
        return f"{self.base}/bot{self.token}/{method}"

    async def call(self, method: str, timeout: float | None = None, files: dict | None = None, **params):
        params = {k: v for k, v in params.items() if v is not None}
        try:
            if files:
                r = await self.http.post(self._url(method), data={k: str(v) for k, v in params.items()}, files=files, timeout=timeout)
            else:
                r = await self.http.post(self._url(method), json=params, timeout=timeout)
        except httpx.HTTPError as exc:
            raise TelegramError(f"Telegram: {type(exc).__name__}: {exc}".replace(self.token, "***")) from exc
        try:
            data = r.json()
        except ValueError as exc:
            raise TelegramError(f"Telegram: HTTP {r.status_code}", r.status_code) from exc
        if not data.get("ok"):
            raise TelegramError(f"Telegram: {data.get('description') or r.status_code}", data.get("error_code") or r.status_code,
                                (data.get("parameters") or {}).get("retry_after") or 0)
        return data.get("result")

    async def get_me(self) -> dict:
        return await self.call("getMe")

    async def set_webhook(self, url: str, secret: str) -> bool:
        return await self.call("setWebhook", url=url, secret_token=secret, allowed_updates=["message", "edited_message"],
                               max_connections=10)

    async def delete_webhook(self) -> bool:
        return await self.call("deleteWebhook", drop_pending_updates=False)

    async def webhook_info(self) -> dict:
        return await self.call("getWebhookInfo")

    async def get_updates(self, offset: int | None, wait: int = 25) -> list[dict]:
        params = {"timeout": wait, "allowed_updates": ["message", "edited_message"]}
        if offset is not None:
            params["offset"] = offset
        try:
            r = await self.http.post(self._url("getUpdates"), json=params, timeout=wait + 15)
            data = r.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise TelegramError(f"Telegram: {type(exc).__name__}".replace(self.token, "***")) from exc
        if not data.get("ok"):
            raise TelegramError(f"Telegram: {data.get('description')}", data.get("error_code") or r.status_code)
        return data["result"]

    async def send_message(self, chat_id: str, text: str) -> dict:
        return await self.call("sendMessage", chat_id=chat_id, text=text)

    async def send_file(self, chat_id: str, name: str, mime: str, data: bytes, caption: str = "") -> dict:
        method, field = ("sendPhoto", "photo") if mime in ("image/jpeg", "image/png") and len(data) < 10 * 1024 * 1024 else ("sendDocument", "document")
        return await self.call(method, files={field: (name, data, mime)}, chat_id=chat_id, caption=caption[:1024] or None)

    async def file_path(self, file_id: str) -> str:
        return (await self.call("getFile", file_id=file_id))["file_path"]

    async def download(self, path: str, limit: int) -> bytes:
        async with self.http.stream("GET", f"{self.base}/file/bot{self.token}/{path}") as r:
            if r.status_code != 200:
                raise TelegramError(f"Telegram file: HTTP {r.status_code}", r.status_code)
            out = bytearray()
            async for chunk in r.aiter_bytes():
                out += chunk
                if len(out) > limit:
                    raise TelegramError("file too large")
            return bytes(out)
