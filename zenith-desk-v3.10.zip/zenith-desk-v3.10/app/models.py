"""Database model (ТЗ, раздел 8) plus the extra tables the requirements need:

* audit_log      — FR-08/FR-12, аудит всех ручных и автоматических изменений
* call_record    — FR-01/FR-02, звонки и их связь с тикетами
* pause_interval — FR-12, время блокировки очереди
* ticket_type    — FR-11, типы тикетов и обязательные поля
* chat_message   — v3.0, внутренний мессенджер сотрудников
* queue_call     — v2.5, звонки в очереди для статистики руководителя (SL, ASA, пропущенные)
"""
from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Index, Integer, LargeBinary, String, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base, utcnow

TS = DateTime(timezone=True)

# Enumerations kept as plain strings for portability / readable SQL
WORK_MODES = ("blocking", "background")
SESSION_STATES = ("active", "completed", "cancelled")
MANUAL_STATES = ("ready", "break", "offline")
COMPUTED_STATES = ("ready", "busy_task", "break", "offline", "wrap_up")
SYNC_STATUSES = ("ok", "pending", "error")
ROLES = ("operator", "supervisor", "admin")
LEVELS = ("admin", "level1", "level2", "level3", "manager")
# The level decides the access rights: a Manager leads the Level 1-3 staff (supervisor panel).
LEVEL_ROLE = {"admin": "admin", "manager": "supervisor", "level1": "operator", "level2": "operator", "level3": "operator"}


class AgentMapping(Base):
    """A workplace user (operator / supervisor / admin). Created by the administrator in the admin panel."""
    __tablename__ = "agent_mapping"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str | None] = mapped_column(String(100), unique=True, nullable=True)
    password_hash: Mapped[str] = mapped_column(String(300), default="")
    first_name: Mapped[str] = mapped_column(String(100), default="")
    last_name: Mapped[str] = mapped_column(String(100), default="")
    position: Mapped[str] = mapped_column(String(150), default="")  # job title
    # grade: admin | level1 (Entry) | level2 (Mid) | level3 (Senior and above) | manager
    level: Mapped[str] = mapped_column(String(20), default="level1")
    ui_prefs: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # theme, dashboard layout, sound…
    active: Mapped[bool] = mapped_column(Boolean, default=True)  # may sign in
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=False)
    last_login_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    notifications_seen_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    zammad_user_id: Mapped[int | None] = mapped_column(Integer, unique=True, nullable=True)
    display_name: Mapped[str] = mapped_column(String(200), default="")
    asterisk_interface: Mapped[str] = mapped_column(String(200), default="")  # e.g. Local/101@from-queue/n
    extension: Mapped[str] = mapped_column(String(40), default="")
    # v3.5 Zenith Phone (WebRTC): SIP login of the extension (empty = the extension) and its password, encrypted
    sip_user: Mapped[str] = mapped_column(String(100), default="")
    sip_secret: Mapped[str] = mapped_column(Text, default="")
    role: Mapped[str] = mapped_column(String(20), default="operator")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)  # participates in automation
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow, onupdate=utcnow)


class AgentState(Base):
    __tablename__ = "agent_state"

    agent_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id", ondelete="CASCADE"), primary_key=True)
    manual_state: Mapped[str] = mapped_column(String(20), default="offline")
    computed_state: Mapped[str] = mapped_column(String(20), default="offline")
    reason: Mapped[str] = mapped_column(String(300), default="")
    override_ready: Mapped[bool] = mapped_column(Boolean, default=False)  # supervisor override
    override_reason: Mapped[str] = mapped_column(String(500), default="")
    wrap_up_until: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    queue_paused: Mapped[bool | None] = mapped_column(Boolean, nullable=True)  # last CONFIRMED value
    external_pause: Mapped[bool] = mapped_column(Boolean, default=False)  # paused by phone/other tool
    sync_status: Mapped[str] = mapped_column(String(20), default="pending")
    sync_error: Mapped[str] = mapped_column(Text, default="")
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    next_retry_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    last_asterisk_sync_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    # v2.8 inactivity: last time the person used Zenith Desk, and when they were paused for being away
    last_activity_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    idle_since: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    dnd: Mapped[bool] = mapped_column(Boolean, default=False)  # v3.7 "Do not disturb" (phone)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow, onupdate=utcnow)


class WorkSession(Base):
    __tablename__ = "work_session"
    __table_args__ = (
        # A ticket can have only one active work session at a time.
        Index(
            "uq_work_session_active_ticket",
            "ticket_id",
            unique=True,
            postgresql_where=text("state = 'active'"),
            sqlite_where=text("state = 'active'"),
        ),
        Index("ix_work_session_agent_state", "agent_id", "state"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(Integer, nullable=False)
    ticket_number: Mapped[str] = mapped_column(String(64), default="")
    ticket_title: Mapped[str] = mapped_column(String(500), default="")
    source: Mapped[str] = mapped_column(String(40), default="")  # phone/email/telegram/whatsapp/web/...
    agent_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id"), nullable=False)
    work_mode: Mapped[str] = mapped_column(String(20), nullable=False)
    state: Mapped[str] = mapped_column(String(20), default="active")
    started_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    end_reason: Mapped[str] = mapped_column(String(200), default="")


class IntegrationEvent(Base):
    __tablename__ = "integration_event"
    __table_args__ = (UniqueConstraint("source", "external_event_id", name="uq_integration_event_ext"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(20), nullable=False)  # zammad/asterisk/ui
    external_event_id: Mapped[str] = mapped_column(String(200), nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), default="")
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="new")  # new/processed/retry/failed
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    processed_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)


class AuditLog(Base):
    __tablename__ = "audit_log"
    __table_args__ = (Index("ix_audit_agent_ts", "agent_id", "ts"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    level: Mapped[str] = mapped_column(String(10), default="info")  # info/warning/error
    actor_type: Mapped[str] = mapped_column(String(20), default="system")  # agent/supervisor/system/zammad/asterisk
    actor_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    agent_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ticket_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(60), nullable=False)
    details: Mapped[dict] = mapped_column(JSON, default=dict)


class CallRecord(Base):
    __tablename__ = "call_record"
    __table_args__ = (
        UniqueConstraint("linkedid", "agent_id", name="uq_call_linkedid_agent"),
        Index("ix_call_agent_started", "agent_id", "started_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    linkedid: Mapped[str] = mapped_column(String(64), nullable=False)
    uniqueid: Mapped[str] = mapped_column(String(64), default="")
    agent_id: Mapped[int | None] = mapped_column(ForeignKey("agent_mapping.id"), nullable=True)
    direction: Mapped[str] = mapped_column(String(10), default="in")
    queue: Mapped[str] = mapped_column(String(40), default="")
    extension: Mapped[str] = mapped_column(String(40), default="")
    caller_number: Mapped[str] = mapped_column(String(64), default="")
    caller_normalized: Mapped[str] = mapped_column(String(32), default="", index=True)
    caller_name: Mapped[str] = mapped_column(String(200), default="")
    state: Mapped[str] = mapped_column(String(20), default="ringing")  # ringing/answered/ended/missed
    started_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    answered_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    ended_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    recording_file: Mapped[str] = mapped_column(String(500), default="")
    ticket_id: Mapped[int | None] = mapped_column(Integer, nullable=True)


class QueueCall(Base):
    """One customer call in an ACD queue (v2.5, contact-center statistics).

    Filled from AMI QueueCallerJoin / AgentConnect / AgentComplete / QueueCallerAbandon / QueueCallerLeave.
    One row per customer call (linkedid): a call that overflows to another queue is still one call.
    outcome: waiting -> answered | abandoned (caller hung up while waiting) | exited (left unanswered: timeout, exit key).
    """
    __tablename__ = "queue_call"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    linkedid: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)
    uniqueid: Mapped[str] = mapped_column(String(64), default="")
    queue: Mapped[str] = mapped_column(String(40), default="")
    caller_number: Mapped[str] = mapped_column(String(64), default="")
    caller_normalized: Mapped[str] = mapped_column(String(32), default="", index=True)
    caller_name: Mapped[str] = mapped_column(String(200), default="")
    outcome: Mapped[str] = mapped_column(String(20), default="waiting")
    joined_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    answered_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    left_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)  # left the queue (answered or not)
    ended_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)  # conversation finished
    agent_id: Mapped[int | None] = mapped_column(ForeignKey("agent_mapping.id"), nullable=True)
    wait_sec: Mapped[int | None] = mapped_column(Integer, nullable=True)  # Asterisk HoldTime
    talk_sec: Mapped[int | None] = mapped_column(Integer, nullable=True)  # Asterisk TalkTime


class ChatMessage(Base):
    """Internal messenger between employees (v3.0): one row per direct message, kept forever."""
    __tablename__ = "chat_message"
    __table_args__ = (
        Index("ix_chat_pair", "sender_id", "recipient_id", "id"),
        Index("ix_chat_unread", "recipient_id", "read_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id"), nullable=False)
    recipient_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id"), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)  # encrypted at rest (v3.1): "v1:" + Fernet token
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    read_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    edited_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    deleted_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)  # deleted for everyone
    hidden_sender: Mapped[bool] = mapped_column(Boolean, default=False, server_default=text("false"))     # "delete for me"
    hidden_recipient: Mapped[bool] = mapped_column(Boolean, default=False, server_default=text("false"))


class ChatReaction(Base):
    """One emoji reaction per person per message (like Telegram)."""
    __tablename__ = "chat_reaction"
    __table_args__ = (UniqueConstraint("message_id", "user_id", name="uq_reaction_message_user"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    message_id: Mapped[int] = mapped_column(ForeignKey("chat_message.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id"), nullable=False)
    emoji: Mapped[str] = mapped_column(String(16), nullable=False)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class PushSubscription(Base):
    """Web Push subscription of one browser (v3.1): notifications even when Zenith Desk is closed."""
    __tablename__ = "push_subscription"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id", ondelete="CASCADE"), nullable=False, index=True)
    endpoint: Mapped[str] = mapped_column(String(1000), nullable=False, unique=True)
    p256dh: Mapped[str] = mapped_column(String(200), nullable=False)
    auth: Mapped[str] = mapped_column(String(100), nullable=False)
    user_agent: Mapped[str] = mapped_column(String(300), default="")
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    last_ok_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)


class PauseInterval(Base):
    __tablename__ = "pause_interval"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id"), nullable=False, index=True)
    reason: Mapped[str] = mapped_column(String(40), default="")  # computed state that caused the pause
    started_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)


class TicketType(Base):
    __tablename__ = "ticket_type"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)  # shown in UI
    zammad_value: Mapped[str] = mapped_column(String(100), nullable=False)  # value of the type attribute
    # [{"name": "category", "label": "Категория", "type": "text|select|textarea", "options": [...]}]
    required_fields: Mapped[list] = mapped_column(JSON, default=list)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)


class SystemSetting(Base):
    """Settings edited by the administrator in the admin panel (override .env defaults).
    Secret values are stored encrypted (see app/crypto.py)."""
    __tablename__ = "system_setting"

    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")  # JSON-encoded value or encrypted token
    is_secret: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow, onupdate=utcnow)
    updated_by: Mapped[int | None] = mapped_column(Integer, nullable=True)


class ZammadUser(Base):
    """v3.3: read-only copy of Zammad's people (customers and staff), synchronised automatically.

    People are created and edited in Zammad only; Zenith Desk shows them in its lists and cards and uses them to
    show names, to pick who a ticket is transferred to (staff with access to the ticket's group) etc.
    """
    __tablename__ = "zammad_user"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=False)  # the Zammad user id
    login: Mapped[str] = mapped_column(String(255), default="")
    firstname: Mapped[str] = mapped_column(String(150), default="")
    lastname: Mapped[str] = mapped_column(String(150), default="")
    email: Mapped[str] = mapped_column(String(255), default="")
    phone: Mapped[str] = mapped_column(String(100), default="")
    mobile: Mapped[str] = mapped_column(String(100), default="")
    organization: Mapped[str] = mapped_column(String(255), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_agent: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    is_customer: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    roles: Mapped[list] = mapped_column(JSON, default=list)
    groups: Mapped[dict] = mapped_column(JSON, default=dict)  # group name -> ["full"] / ["read", "change", ...]
    search_text: Mapped[str] = mapped_column(Text, default="")  # lower-case name, login, e-mail, phones (digits)
    z_created_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    z_updated_at: Mapped[datetime | None] = mapped_column(TS, nullable=True, index=True)
    synced_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


# ====================================================================== v3.9 messengers (one company number / bot)
class MsgConversation(Base):
    """A chat with one customer in one channel (Telegram or WhatsApp). The number / bot belongs to the company: the
    whole team sees the conversations; one operator takes a chat (assignee) and can pass it to a colleague."""
    __tablename__ = "msg_conversation"
    __table_args__ = (UniqueConstraint("channel", "external_id", name="uq_msg_conv_channel_external"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    channel: Mapped[str] = mapped_column(String(20), index=True)  # telegram | whatsapp
    external_id: Mapped[str] = mapped_column(String(100))  # Telegram chat id / WhatsApp phone (wa_id)
    name: Mapped[str] = mapped_column(String(255), default="")
    handle: Mapped[str] = mapped_column(String(255), default="")  # @username / +phone
    phone: Mapped[str] = mapped_column(String(50), default="")
    zammad_customer_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    zammad_ticket_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    zammad_ticket_number: Mapped[str] = mapped_column(String(50), default="")
    assignee_id: Mapped[int | None] = mapped_column(ForeignKey("agent_mapping.id"), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(20), default="open", index=True)  # open | closed
    unread: Mapped[int] = mapped_column(Integer, default=0)
    last_text: Mapped[str] = mapped_column(Text, default="")  # preview in the list (encrypted)
    last_direction: Mapped[str] = mapped_column(String(10), default="in")
    last_message_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    last_inbound_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)  # WhatsApp 24-hour window
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)


class MsgMessage(Base):
    """One message of a conversation: from the customer (in), from an operator (out) or an internal note (note).
    Text is encrypted at rest. Outgoing messages wait in `queued` and are retried until sent (outbox)."""
    __tablename__ = "msg_message"
    __table_args__ = (Index("ix_msg_message_conv_id", "conversation_id", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    conversation_id: Mapped[int] = mapped_column(ForeignKey("msg_conversation.id", ondelete="CASCADE"))
    channel: Mapped[str] = mapped_column(String(20))
    direction: Mapped[str] = mapped_column(String(10))  # in | out | note | event
    external_id: Mapped[str | None] = mapped_column(String(200), nullable=True)  # message id at Telegram / WhatsApp
    author_id: Mapped[int | None] = mapped_column(ForeignKey("agent_mapping.id"), nullable=True)
    body: Mapped[str] = mapped_column(Text, default="")  # encrypted
    files: Mapped[list] = mapped_column(JSON, default=list)  # [{name, mime, size, key, media_id}]
    kind: Mapped[str] = mapped_column(String(20), default="text")  # text | image | document | audio | video | location | template | sticker
    status: Mapped[str] = mapped_column(String(20), default="received")  # received | queued | sent | delivered | read | failed
    error: Mapped[str] = mapped_column(String(500), default="")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_try_at: Mapped[datetime | None] = mapped_column(TS, nullable=True, index=True)
    zammad_article_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    mirrored: Mapped[bool] = mapped_column(Boolean, default=False, index=True)  # copied to the Zammad ticket
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    sent_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)


Index("uq_msg_message_external", MsgMessage.channel, MsgMessage.external_id, unique=True)


# ====================================================================== v3.9 e-mail
class MailAccount(Base):
    """The mailbox of one employee. The server is configured by the administrator; the employee only signs in.
    The password is encrypted (it is needed to talk to IMAP / SMTP on the employee's behalf)."""
    __tablename__ = "mail_account"

    agent_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id", ondelete="CASCADE"), primary_key=True)
    email: Mapped[str] = mapped_column(String(255))
    login: Mapped[str] = mapped_column(String(255))
    secret: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="ok")  # ok | error
    last_error: Mapped[str] = mapped_column(String(500), default="")
    uidvalidity: Mapped[int] = mapped_column(Integer, default=0)
    uidnext: Mapped[int] = mapped_column(Integer, default=0)  # INBOX: the next message id seen at the last check
    unseen: Mapped[int] = mapped_column(Integer, default=0)
    last_check_at: Mapped[datetime | None] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class MailLocal(Base):
    """POP3 mode: messages downloaded into Zenith Desk (POP3 has no folders), plus sent mail and drafts."""
    __tablename__ = "mail_local"
    __table_args__ = (UniqueConstraint("agent_id", "uidl", name="uq_mail_local_uidl"),
                      Index("ix_mail_local_folder", "agent_id", "folder", "date"))

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agent_mapping.id", ondelete="CASCADE"))
    uidl: Mapped[str] = mapped_column(String(255))
    folder: Mapped[str] = mapped_column(String(30), default="INBOX")  # INBOX | Sent | Drafts | Trash
    raw: Mapped[str] = mapped_column(Text)  # encrypted RFC 822 message
    sender: Mapped[str] = mapped_column(String(500), default="")
    recipients: Mapped[str] = mapped_column(Text, default="")
    subject: Mapped[str] = mapped_column(String(1000), default="")
    snippet: Mapped[str] = mapped_column(String(300), default="")
    date: Mapped[datetime] = mapped_column(TS, default=utcnow)
    size: Mapped[int] = mapped_column(Integer, default=0)
    seen: Mapped[bool] = mapped_column(Boolean, default=False)
    flagged: Mapped[bool] = mapped_column(Boolean, default=False)
    has_files: Mapped[bool] = mapped_column(Boolean, default=False)


class MsgFile(Base):
    """A file of a messenger message (photo, document, voice …), kept in the database so backups include it."""
    __tablename__ = "msg_file"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key: Mapped[str] = mapped_column(String(64), unique=True)  # random, used in the download URL
    conversation_id: Mapped[int] = mapped_column(ForeignKey("msg_conversation.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="file")
    mime: Mapped[str] = mapped_column(String(150), default="application/octet-stream")
    size: Mapped[int] = mapped_column(Integer, default=0)
    data: Mapped[bytes] = mapped_column(LargeBinary)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
