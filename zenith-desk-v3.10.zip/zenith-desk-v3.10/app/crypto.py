"""Password hashing (scrypt, stdlib) and encryption of secret settings (Fernet)."""
import base64
import hashlib
import hmac
import os

from cryptography.fernet import Fernet, InvalidToken

_N, _R, _P = 2**14, 8, 1


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P, dklen=32)
    return f"scrypt${_N}${_R}${_P}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, n, r, p, salt, dk = stored.split("$")
        if algo != "scrypt":
            return False
        calc = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p), dklen=32)
        return hmac.compare_digest(calc, base64.b64decode(dk))
    except (ValueError, TypeError):
        return False


class MessageCipher:
    """Chat messages are encrypted at rest (v3.1): a database dump or backup does not reveal conversations.
    Key derived from the server's secret (JWT_SECRET), separate from the settings key."""
    PREFIX = "v1:"

    def __init__(self, master_key: str):
        key = hashlib.sha256(b"agentix-chat:" + master_key.encode()).digest()
        self._f = Fernet(base64.urlsafe_b64encode(key))

    def seal(self, text: str) -> str:
        return self.PREFIX + self._f.encrypt(text.encode()).decode()

    def open(self, stored: str) -> str:
        if not stored.startswith(self.PREFIX):
            return stored  # written before v3.1; encrypted by the start-up migration
        try:
            return self._f.decrypt(stored[len(self.PREFIX):].encode()).decode()
        except (InvalidToken, ValueError):
            return ""


class SecretBox:
    """Encrypts secrets with a key derived from the server's SECRET_KEY (JWT_SECRET)."""

    def __init__(self, master_key: str):
        key = hashlib.sha256(b"agentix-settings:" + master_key.encode()).digest()
        self._f = Fernet(base64.urlsafe_b64encode(key))

    def encrypt(self, value: str) -> str:
        return self._f.encrypt(value.encode()).decode()

    def decrypt(self, token: str) -> str | None:
        try:
            return self._f.decrypt(token.encode()).decode()
        except (InvalidToken, ValueError):
            return None
