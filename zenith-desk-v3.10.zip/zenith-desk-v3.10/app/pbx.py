"""Queue-member control on top of AMI (ТЗ 7.2).

The service manages ONLY the queues listed in MANAGED_QUEUES and ONLY members that are
mapped in agent_mapping. Success of a command is verified by re-reading QueueStatus,
not by the fact that the command was sent.
"""
from dataclasses import dataclass
from typing import Protocol

from .ami import AMIClient, AMIError


@dataclass
class MemberStatus:
    queue: str
    present: bool
    paused: bool = False
    paused_reason: str = ""
    in_call: bool = False
    device_status: str = ""  # Asterisk device state code as string


class Pbx(Protocol):
    @property
    def connected(self) -> bool: ...

    async def member_status(self, interface: str, queues: list[str]) -> dict[str, MemberStatus]: ...

    async def set_paused(self, interface: str, queue: str, paused: bool, reason: str) -> None: ...


def _same_interface(a: str, b: str) -> bool:
    return a.strip().lower() == b.strip().lower()


class AmiPbx:
    def __init__(self, ami: AMIClient):
        self.ami = ami

    @property
    def connected(self) -> bool:
        return self.ami.connected

    async def member_status(self, interface: str, queues: list[str]) -> dict[str, MemberStatus]:
        result: dict[str, MemberStatus] = {}
        for queue in queues:
            resp, events = await self.ami.action_list("QueueStatus", "QueueStatusComplete", Queue=queue, Member=interface)
            if resp.get("Response") != "Success":
                raise AMIError(f"QueueStatus {queue}: {resp.get('Message', 'error')}")
            status = MemberStatus(queue=queue, present=False)
            for ev in events:
                if ev.get("Event") != "QueueMember" or ev.get("Queue") != queue:
                    continue
                candidates = [ev.get("Location", ""), ev.get("Interface", ""), ev.get("StateInterface", "")]
                if any(c and _same_interface(c, interface) for c in candidates):
                    status = MemberStatus(
                        queue=queue,
                        present=True,
                        paused=ev.get("Paused", "0") in ("1", "true", "yes"),
                        paused_reason=ev.get("PausedReason", ""),
                        in_call=ev.get("InCall", "0") == "1",
                        device_status=ev.get("Status", ""),
                    )
                    break
            result[queue] = status
        return result

    async def set_paused(self, interface: str, queue: str, paused: bool, reason: str) -> None:
        fields = {"Interface": interface, "Queue": queue, "Paused": "true" if paused else "false"}
        if paused and reason:
            fields["Reason"] = reason
        resp = await self.ami.action("QueuePause", **fields)
        if resp.get("Response") != "Success":
            raise AMIError(f"QueuePause {queue}/{interface}: {resp.get('Message', 'error')}")
