"""v3.3 ticketing API: the operator works with Zammad tickets entirely inside Zenith Desk."""
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field

from ..auth import current_agent, get_services
from ..directory import user_view
from ..models import AgentMapping
from ..services import Services
from ..ticketing import TicketError

router = APIRouter(prefix="/api/tk", tags=["ticketing"])
people = APIRouter(prefix="/api/directory", tags=["directory"])


def _http(exc: TicketError) -> HTTPException:
    return HTTPException(exc.status, exc.message)


@router.get("/meta", summary="States, priorities and groups for the ticket screens")
async def meta(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await services.desk.meta(agent)
    except TicketError as exc:
        raise _http(exc) from exc


@router.get("/tickets", summary="Ticket list (mine / unassigned / all open / closed) with search and filters")
async def tickets(view: Literal["mine", "unassigned", "all", "closed"] = "mine", q: str = "", state: str = "",
                  priority: str = "", group: str = "", page: int = Query(1, ge=1), per_page: int = Query(30, ge=5, le=100),
                  sort: Literal["updated", "created"] = "updated",
                  agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await services.desk.list(agent, view, q, state, priority, group, page, per_page, sort)
    except TicketError as exc:
        raise _http(exc) from exc


@router.get("/tickets/{ticket_id}", summary="Ticket with its whole conversation")
async def ticket(ticket_id: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        return await services.desk.detail(agent, ticket_id)
    except TicketError as exc:
        raise _http(exc) from exc


class FileIn(BaseModel):
    filename: str = Field(max_length=200)
    mime: str = "application/octet-stream"
    data: str  # base64


class ReplyIn(BaseModel):
    body: str = Field(default="", max_length=60000)
    kind: Literal["note", "reply"] = "note"
    internal: bool = True
    attachments: list[FileIn] = Field(default_factory=list, max_length=10)
    state: str | None = None  # change the state together with the message
    pending_days: int | None = Field(default=None, ge=1, le=365)


@router.post("/tickets/{ticket_id}/articles", summary="Write: internal note, public note or reply to the customer")
async def reply(ticket_id: int, body: ReplyIn, agent: AgentMapping = Depends(current_agent),
                services: Services = Depends(get_services)):
    try:
        return await services.desk.reply(agent, ticket_id, body=body.body, kind=body.kind, internal=body.internal,
                                         attachments=[f.model_dump() for f in body.attachments], state=body.state,
                                         pending_days=body.pending_days)
    except TicketError as exc:
        raise _http(exc) from exc


class UpdateIn(BaseModel):
    title: str | None = Field(default=None, max_length=250)
    state: str | None = None
    pending_days: int | None = Field(default=None, ge=1, le=365)
    priority: str | None = None
    group: str | None = None
    owner_id: int | None = Field(default=None, ge=0)  # Zammad user id; 0 = unassigned
    note: str | None = Field(default=None, max_length=20000)


@router.patch("/tickets/{ticket_id}", summary="Change state, priority, group, title or owner (transfer)")
async def update(ticket_id: int, body: UpdateIn, agent: AgentMapping = Depends(current_agent),
                 services: Services = Depends(get_services)):
    try:
        return await services.desk.update(agent, ticket_id, **body.model_dump())
    except TicketError as exc:
        raise _http(exc) from exc


@router.get("/tickets/{ticket_id}/assignees", summary="Colleagues the ticket can be transferred to")
async def assignees(ticket_id: int, group: str | None = None, agent: AgentMapping = Depends(current_agent),
                    services: Services = Depends(get_services)):
    try:
        return await services.desk.assignees(agent, ticket_id, group)
    except TicketError as exc:
        raise _http(exc) from exc


@router.get("/tickets/{ticket_id}/articles/{article_id}/attachments/{att_id}", summary="Download an attachment")
async def attachment(ticket_id: int, article_id: int, att_id: int, agent: AgentMapping = Depends(current_agent),
                     services: Services = Depends(get_services)):
    try:
        r = await services.desk.attachment(agent, ticket_id, article_id, att_id)
    except TicketError as exc:
        raise _http(exc) from exc
    headers = {"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff",
               "Content-Disposition": r.headers.get("content-disposition") or "attachment"}
    if not headers["Content-Disposition"].lower().startswith("attachment"):  # never render customer files inline
        headers["Content-Disposition"] = "attachment"
    return Response(r.content, media_type=r.headers.get("content-type", "application/octet-stream"), headers=headers)


# ---------------------------------------------------------------- directory (read-only copy of Zammad people)
@people.get("", summary="Customers or Zammad staff (kind=customers|staff), search")
async def directory(kind: Literal["customers", "staff"] = "customers", q: str = "", offset: int = Query(0, ge=0),
                    limit: int = Query(50, ge=1, le=200), agent: AgentMapping = Depends(current_agent),
                    services: Services = Depends(get_services)):
    return await services.directory.search("staff" if kind == "staff" else "customers", q, offset, limit)


@people.post("/sync", summary="Synchronise with Zammad now")
async def sync_now(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        res = await services.directory.sync(full=False)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(502, str(exc)[:300]) from exc
    return {**res, "synced_at": services.directory.last_sync}


@people.get("/{user_id}", summary="Person card with tickets")
async def person(user_id: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    u = await services.directory.get(user_id)
    if u is None:
        raise HTTPException(404, "not found")
    tickets, error = [], ""
    if agent.zammad_user_id:
        try:
            tickets = await services.desk.customer_tickets(agent, user_id, staff=u.is_agent and not u.is_customer)
        except TicketError as exc:
            error = exc.message
    return {"user": user_view(u), "tickets": tickets, "error": error}
