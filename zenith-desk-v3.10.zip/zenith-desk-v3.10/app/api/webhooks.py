"""Zammad webhook receiver (ТЗ 7.1, FR-13).

* authenticity: X-Hub-Signature = sha1=HMAC_SHA1(secret, raw body)
* de-duplication: X-Zammad-Delivery (unique per delivery) stored in integration_event
* the payload is only a hint — the ticket is always re-read from the Zammad API
"""
import asyncio
import hashlib
import hmac
import json
import logging

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from ..auth import get_services
from ..db import utcnow
from ..models import IntegrationEvent
from ..services import Services

router = APIRouter(prefix="/api/integrations", tags=["integrations"])
_background: set[asyncio.Task] = set()
log = logging.getLogger("webhook")


def verify_signature(secret: str, body: bytes, header: str | None) -> bool:
    if not secret:
        return True  # not configured (allowed only for tests / closed networks)
    if not header:
        return False
    expected = "sha1=" + hmac.new(secret.encode(), body, hashlib.sha1).hexdigest()
    return hmac.compare_digest(expected, header.strip())


@router.post("/zammad/webhook", summary="Zammad webhook receiver (HMAC signature, de-duplication)")
async def zammad_webhook(
    request: Request,
    services: Services = Depends(get_services),
    x_hub_signature: str | None = Header(None),
    x_zammad_delivery: str | None = Header(None),
    x_zammad_trigger: str | None = Header(None),
):
    raw = await request.body()
    if not verify_signature(services.settings.zammad_webhook_secret, raw, x_hub_signature):
        raise HTTPException(401, "Invalid signature")
    try:
        payload = json.loads(raw or b"{}")
    except ValueError as exc:
        raise HTTPException(400, "Invalid JSON") from exc
    ticket = payload.get("ticket") or {}
    ticket_id = ticket.get("id")
    delivery = x_zammad_delivery or hashlib.sha1(raw).hexdigest()

    async with services.db.sessionmaker() as s:
        ev = IntegrationEvent(source="zammad", external_event_id=delivery, event_type=x_zammad_trigger or "webhook",
                              payload={"ticket_id": ticket_id, "state": ticket.get("state"), "owner_id": ticket.get("owner_id")},
                              status="new")
        s.add(ev)
        try:
            await s.commit()
        except IntegrityError:
            return {"status": "duplicate"}
        event_id = ev.id

    services.hub.event("zammad")  # v3.9: real-time channel alive
    services.desk.kick()       # v3.3: every open ticket screen updates now
    services.directory.kick()  # a new customer usually arrives together with his first ticket
    if ticket_id:
        task = asyncio.create_task(_process(services, event_id, int(ticket_id)))
        _background.add(task)
        task.add_done_callback(_background.discard)
    else:
        await _finish(services, event_id, "processed", "")
    return {"status": "accepted"}


async def _process(services: Services, event_id: int, ticket_id: int) -> None:
    try:
        await services.workflow.on_ticket_changed(ticket_id, "webhook")
        await _finish(services, event_id, "processed", "")
    except Exception as exc:  # noqa: BLE001 — periodic reconcile will catch up
        log.exception("webhook processing failed")
        await _finish(services, event_id, "failed", str(exc)[:500])


async def _finish(services: Services, event_id: int, status: str, error: str) -> None:
    async with services.db.sessionmaker() as s:
        ev = (await s.execute(select(IntegrationEvent).where(IntegrationEvent.id == event_id))).scalars().first()
        if ev:
            ev.status, ev.error, ev.processed_at, ev.attempts = status, error, utcnow(), ev.attempts + 1
            await s.commit()
