from collections.abc import Awaitable, Callable

from fastapi import HTTPException
from fastapi.encoders import jsonable_encoder
from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError

from ..db import utcnow
from ..i18n import t as tr
from ..models import IntegrationEvent
from ..services import Services
from ..workflow import WorkflowError


async def run_idempotent(services: Services, agent_id: int, key: str | None, event_type: str, payload: dict,
                         fn: Callable[[], Awaitable[dict]]) -> dict:
    """FR-13 for UI commands: a repeated request with the same Idempotency-Key returns the
    stored result instead of executing the command again."""
    if not key:
        return jsonable_encoder(await fn())
    ext_id = f"{agent_id}:{event_type}:{key}"[:200]
    async with services.db.sessionmaker() as s:
        existing = (await s.execute(select(IntegrationEvent).where(
            IntegrationEvent.source == "ui", IntegrationEvent.external_event_id == ext_id))).scalars().first()
        if existing is not None:
            if existing.status == "processed":
                return {**(existing.result or {}), "idempotent_replay": True}
            raise HTTPException(409, tr("err.in_progress"))
        row = IntegrationEvent(source="ui", external_event_id=ext_id, event_type=event_type, payload=payload, status="new")
        s.add(row)
        try:
            await s.commit()
        except IntegrityError as exc:
            raise HTTPException(409, tr("err.in_progress")) from exc
        row_id = row.id
    try:
        result = jsonable_encoder(await fn())
    except BaseException:
        # failed commands may be retried with the same key
        async with services.db.sessionmaker() as s:
            await s.execute(delete(IntegrationEvent).where(IntegrationEvent.id == row_id))
            await s.commit()
        raise
    async with services.db.sessionmaker() as s:
        row = await s.get(IntegrationEvent, row_id)
        row.status, row.result, row.processed_at, row.attempts = "processed", result, utcnow(), 1
        await s.commit()
    return result


def workflow_http(exc: WorkflowError) -> HTTPException:
    return HTTPException(exc.status, {"message": exc.message, **exc.details})
