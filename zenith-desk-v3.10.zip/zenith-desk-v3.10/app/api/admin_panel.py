"""Administrator panel API: users, integrations & settings, ticket types, system status.
Everything here requires the admin role."""
import re

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from ..audit import audit
from ..auth import get_services, require_role
from ..crypto import hash_password
from ..db import as_utc
from ..i18n import get_language, t as tr
from ..models import LEVEL_ROLE, AgentMapping, AgentState, AuditLog, IntegrationEvent, TicketType, WorkSession
from ..services import Services
from ..settings_store import SettingsError
from ..views import agent_state_view
from ..zammad import ZammadError

router = APIRouter(prefix="/api/admin", tags=["administrator"])
admin = require_role("admin")
USERNAME_RE = re.compile(r"^[a-z0-9._-]{2,50}$")


# ================================================================== users
class UserIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(default="", max_length=100)
    username: str = Field(min_length=2, max_length=50)
    position: str = Field(default="", max_length=150)
    role: str | None = Field(default=None, pattern="^(operator|supervisor|admin)$")  # ignored: derived from level
    level: str = Field(pattern="^(admin|level1|level2|level3|manager)$")  # grade, required
    active: bool = True
    zammad_user_id: int | None = None
    extension: str = Field(default="", max_length=40)
    asterisk_interface: str = Field(default="", max_length=200)
    enabled: bool = True  # queue automation
    sip_user: str = Field(default="", max_length=100)  # v3.5: empty = the extension
    sip_password: str | None = Field(default=None, max_length=200)  # None/"" = keep the current one
    sip_password_clear: bool = False
    password: str | None = Field(default=None, min_length=8, max_length=200)  # required on create
    must_change_password: bool = False


class PasswordIn(BaseModel):
    password: str = Field(min_length=8, max_length=200)
    must_change_password: bool = False


def user_view(m: AgentMapping) -> dict:
    return {
        "id": m.id, "username": m.username, "first_name": m.first_name, "last_name": m.last_name,
        "name": m.display_name, "position": m.position, "level": m.level, "role": m.role, "active": m.active,
        "zammad_user_id": m.zammad_user_id, "extension": m.extension, "asterisk_interface": m.asterisk_interface,
        "enabled": m.enabled, "must_change_password": m.must_change_password, "has_password": bool(m.password_hash),
        "sip_user": m.sip_user or "", "has_sip_password": bool(m.sip_secret),
        "last_login_at": as_utc(m.last_login_at), "created_at": as_utc(m.created_at),
    }


async def _validate_user(s, body: UserIn, user_id: int | None) -> str:
    username = body.username.strip().lower()
    if not USERNAME_RE.match(username):
        raise HTTPException(422, "username: a-z 0-9 . _ - (2–50)")
    other = (await s.execute(select(AgentMapping).where(func.lower(AgentMapping.username) == username))).scalars().first()
    if other is not None and other.id != user_id:
        raise HTTPException(409, tr("err.username_taken"))
    if body.zammad_user_id:
        other = (await s.execute(select(AgentMapping).where(AgentMapping.zammad_user_id == body.zammad_user_id))).scalars().first()
        if other is not None and other.id != user_id:
            raise HTTPException(409, tr("err.zammad_user_taken", name=other.display_name or other.username))
    if body.extension.strip():
        other = (await s.execute(select(AgentMapping).where(AgentMapping.extension == body.extension.strip()))).scalars().first()
        if other is not None and other.id != user_id:
            raise HTTPException(409, tr("err.extension_taken", ext=body.extension.strip(), name=other.display_name))
    return username


async def _active_admins(s, exclude: int | None = None) -> int:
    q = select(func.count()).select_from(AgentMapping).where(AgentMapping.role == "admin", AgentMapping.active.is_(True))
    if exclude is not None:
        q = q.where(AgentMapping.id != exclude)
    return (await s.execute(q)).scalar()


def _apply_sip(m: AgentMapping, body: UserIn, box) -> None:
    m.sip_user = body.sip_user.strip()
    if body.sip_password_clear:
        m.sip_secret = ""
    elif body.sip_password:
        m.sip_secret = box.encrypt(body.sip_password)


def _apply(m: AgentMapping, body: UserIn, username: str) -> None:
    m.username = username
    m.first_name, m.last_name = body.first_name.strip(), body.last_name.strip()
    m.display_name = f"{m.first_name} {m.last_name}".strip()
    m.position, m.active, m.level = body.position.strip(), body.active, body.level
    m.role = LEVEL_ROLE[body.level]  # access rights follow the level
    m.zammad_user_id = body.zammad_user_id or None
    m.extension, m.asterisk_interface = body.extension.strip(), body.asterisk_interface.strip()
    m.enabled = body.enabled


@router.get("/users", summary="All users")
async def list_users(user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(AgentMapping).order_by(AgentMapping.active.desc(), AgentMapping.display_name))).scalars().all()
    return [user_view(m) for m in rows]


@router.post("/users", summary="Create a user (operator / supervisor / admin)")
async def create_user(body: UserIn, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    if not body.password:
        raise HTTPException(422, "password: min 8")
    async with services.db.sessionmaker() as s:
        username = await _validate_user(s, body, None)
        m = AgentMapping()
        _apply(m, body, username)
        _apply_sip(m, body, services.store.box)
        m.password_hash = hash_password(body.password)
        m.must_change_password = body.must_change_password
        s.add(m)
        await s.flush()
        s.add(AgentState(agent_id=m.id))
        audit(s, "user_created", agent_id=m.id, actor_type="admin", actor_id=user.id, username=username, role=m.role, level=m.level)
        await s.commit()
        view = user_view(m)
    await services.engine.recompute(m.id, "user_created")
    return view


@router.put("/users/{user_id}", summary="Update a user")
async def update_user(user_id: int, body: UserIn, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        m = await s.get(AgentMapping, user_id)
        if m is None:
            raise HTTPException(404, tr("err.not_found"))
        username = await _validate_user(s, body, user_id)
        if user_id == user.id and not body.active:
            raise HTTPException(409, tr("err.self_disable"))
        losing_admin = m.role == "admin" and m.active and (LEVEL_ROLE[body.level] != "admin" or not body.active)
        if losing_admin and await _active_admins(s, exclude=user_id) == 0:
            raise HTTPException(409, tr("err.last_admin"))
        _apply(m, body, username)
        _apply_sip(m, body, services.store.box)
        if body.password:
            m.password_hash = hash_password(body.password)
            m.must_change_password = body.must_change_password
        st = await services.engine.ensure_state(s, m.id)
        if not m.active:
            st.manual_state = "offline"
        audit(s, "user_updated", agent_id=m.id, actor_type="admin", actor_id=user.id, username=username,
              role=m.role, active=m.active, password_changed=bool(body.password))
        await s.commit()
        view = user_view(m)
    await services.engine.recompute(user_id, "user_updated")
    return view


@router.post("/users/{user_id}/password", summary="Set a new password for a user")
async def set_password(user_id: int, body: PasswordIn, user: AgentMapping = Depends(admin),
                       services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        m = await s.get(AgentMapping, user_id)
        if m is None:
            raise HTTPException(404, tr("err.not_found"))
        m.password_hash = hash_password(body.password)
        m.must_change_password = body.must_change_password
        audit(s, "password_reset", agent_id=m.id, actor_type="admin", actor_id=user.id)
        await s.commit()
        return user_view(m)


@router.get("/zammad-users", summary="Search Zammad users to link with a workplace user")
async def zammad_users(q: str = "", user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    try:
        users = await services.zammad.search_users(q.strip() or "*", limit=25)
    except ZammadError as exc:
        raise HTTPException(502, str(exc)) from exc
    return [{"id": u.get("id"), "login": u.get("login"), "email": u.get("email"),
             "name": " ".join(filter(None, [u.get("firstname"), u.get("lastname")]))} for u in users]


# ================================================================== settings & integrations
@router.get("/settings", summary="All settings editable in the panel")
async def get_settings(request: Request, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    base = str(request.base_url).rstrip("/")
    hooks = services.messengers.webhook_urls(base)
    return {
        "groups": services.store.describe(get_language()),
        "webhook_url": base + "/api/integrations/zammad/webhook",
        "telegram_webhook_url": hooks["telegram"],
        "whatsapp_webhook_url": hooks["whatsapp"],
        "whatsapp_verify_token": services.settings.whatsapp_verify_token,
        "public_url_set": bool(services.settings.public_url),
    }


class SettingsIn(BaseModel):
    values: dict


@router.put("/settings", summary="Save settings (applied immediately, no restart)")
async def save_settings(body: SettingsIn, request: Request, user: AgentMapping = Depends(admin),
                        services: Services = Depends(get_services)):
    try:
        changed = await services.store.save(body.values, user.id)
    except SettingsError as exc:
        raise HTTPException(422, str(exc)) from exc
    async with services.db.sessionmaker() as s:
        audit(s, "settings_changed", actor_type="admin", actor_id=user.id, keys=sorted(changed))
        await s.commit()
    await services.apply_settings(changed)
    return {"changed": sorted(changed), **(await get_settings(request, user, services))}


class ZammadTestIn(BaseModel):
    zammad_url: str | None = None
    zammad_token: str | None = None
    zammad_verify_tls: bool | None = None


@router.post("/settings/test-zammad", summary="Test the connection to Zammad (current or entered values)")
async def test_zammad(body: ZammadTestIn, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    cfg = services.settings
    return await services.test_zammad(body.zammad_url or cfg.zammad_url, body.zammad_token or cfg.zammad_token,
                                      cfg.zammad_verify_tls if body.zammad_verify_tls is None else body.zammad_verify_tls)


class AmiTestIn(BaseModel):
    ami_host: str | None = None
    ami_port: int | None = None
    ami_user: str | None = None
    ami_secret: str | None = None


@router.post("/settings/test-ami", summary="Test the connection to Asterisk AMI (current or entered values)")
async def test_ami(body: AmiTestIn, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    cfg = services.settings
    return await services.test_ami(body.ami_host or cfg.ami_host, body.ami_port or cfg.ami_port,
                                   body.ami_user or cfg.ami_user, body.ami_secret or cfg.ami_secret)


class GroupTestIn(BaseModel):
    values: dict = Field(default_factory=dict)


@router.post("/settings/test/{group}", summary="v3.9: test Telegram / WhatsApp / mail server with the entered (or saved) values")
async def test_group(group: str, body: GroupTestIn, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    if group in ("telegram", "whatsapp"):
        return await services.messengers.test(group, body.values)
    if group == "mail":
        return await services.mail.test(body.values)
    raise HTTPException(404, "unknown group")


@router.get("/sync", summary="v3.9: real-time state and fallback checks of every integration")
async def sync_status(user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    await services.refresh_backlog()
    return {"interval_min": services.hub.interval_min, "items": services.integrations_view()}


@router.post("/sync/{name}/poll", summary="v3.9: run the fallback check of one integration now")
async def sync_poll(name: str, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    if name not in services.hub.items:
        raise HTTPException(404, "unknown integration")
    await services.hub.poll(name)
    async with services.db.sessionmaker() as s:
        audit(s, "sync_poll", actor_type="admin", actor_id=user.id, integration=name)
        await s.commit()
    await services.refresh_backlog()
    return {"interval_min": services.hub.interval_min, "items": services.integrations_view()}


# ================================================================== ticket types
class TicketTypeIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    zammad_value: str = Field(min_length=1, max_length=100)
    required_fields: list[dict] = Field(default_factory=list)
    enabled: bool = True


@router.get("/ticket-types")
async def list_types(user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(TicketType).order_by(TicketType.name))).scalars().all()
    return [{"id": t.id, "name": t.name, "zammad_value": t.zammad_value, "required_fields": t.required_fields,
             "enabled": t.enabled} for t in rows]


@router.put("/ticket-types/{type_id}", summary="Create (id=0) or update a ticket type and its required fields")
async def upsert_type(type_id: int, body: TicketTypeIn, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    fields = []
    for f in body.required_fields:
        if not isinstance(f, dict) or not str(f.get("name", "")).strip():
            raise HTTPException(422, tr("err.field_name"))
        fields.append({"name": str(f["name"]).strip(), "label": str(f.get("label") or f["name"]).strip(),
                       "type": f.get("type") if f.get("type") in ("text", "textarea", "select") else "text",
                       "options": [str(o).strip() for o in f.get("options") or [] if str(o).strip()]})
    async with services.db.sessionmaker() as s:
        t = await s.get(TicketType, type_id) if type_id else None
        if type_id and t is None:
            raise HTTPException(404, tr("err.not_found"))
        dup = (await s.execute(select(TicketType).where(TicketType.name == body.name.strip()))).scalars().first()
        if dup is not None and (t is None or dup.id != t.id):
            raise HTTPException(409, "name exists")
        if t is None:
            t = TicketType(name=body.name.strip())
            s.add(t)
        t.name, t.zammad_value, t.required_fields, t.enabled = body.name.strip(), body.zammad_value.strip(), fields, body.enabled
        audit(s, "ticket_type_saved", actor_type="admin", actor_id=user.id, name=t.name)
        await s.commit()
        return {"id": t.id, "name": t.name, "zammad_value": t.zammad_value, "required_fields": t.required_fields, "enabled": t.enabled}


@router.delete("/ticket-types/{type_id}")
async def delete_type(type_id: int, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        t = await s.get(TicketType, type_id)
        if t is None:
            raise HTTPException(404, tr("err.not_found"))
        await s.delete(t)
        audit(s, "ticket_type_deleted", actor_type="admin", actor_id=user.id, name=t.name)
        await s.commit()
    return {"deleted": type_id}


# ================================================================== system status
@router.get("/system", summary="System status for the administrator")
async def system(request: Request, user: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    from ..main import VERSION  # noqa: PLC0415 — avoid import cycle

    async with services.db.sessionmaker() as s:
        users = (await s.execute(select(AgentMapping))).scalars().all()
        active_sessions = (await s.execute(select(func.count()).select_from(WorkSession).where(WorkSession.state == "active"))).scalar()
        failed_events = (await s.execute(select(func.count()).select_from(IntegrationEvent).where(IntegrationEvent.status == "failed"))).scalar()
        errors = (await s.execute(select(AuditLog).where(AuditLog.level == "error").order_by(AuditLog.id.desc()).limit(10))).scalars().all()
        states = []
        for m in users:
            if m.role != "admin" and m.active:
                states.append(agent_state_view(m, await services.engine.ensure_state(s, m.id), services.settings.queues))
        await s.commit()
    zammad_ok = await services.test_zammad(services.settings.zammad_url, services.settings.zammad_token,
                                           services.settings.zammad_verify_tls) if services.settings.zammad_token or not services._owns_zammad else {"ok": False, "detail": "not configured"}
    return {
        "version": VERSION,
        "ami": {"connected": services.pbx.connected, "host": services.settings.ami_host,
                "last_error": (getattr(services.ami, "last_error", "") if services.ami else "")
                or ("" if services.ami_configured or not services._owns_ami else "not configured")},
        "zammad": {**zammad_ok, "url": services.settings.zammad_url},
        "users": {"total": len(users), "active": sum(1 for u in users if u.active),
                  "operators": sum(1 for u in users if u.role == "operator" and u.active)},
        "online": sum(1 for st in states if st["manual_state"] != "offline"),
        "sync_problems": [{"name": st["name"], "error": st["sync_error"]} for st in states if st["sync_status"] == "error"],
        "active_sessions": active_sessions,
        "failed_events": failed_events,
        "recent_errors": [{"ts": as_utc(e.ts), "action": e.action, "agent_id": e.agent_id, "details": e.details} for e in errors],
        "webhook_url": str(request.base_url).rstrip("/") + "/api/integrations/zammad/webhook",
        "managed_queues": services.settings.queues,
        "integrations": (await services.refresh_backlog(), services.integrations_view())[1],
        "sync_interval_min": services.hub.interval_min,
        "backup": _backup_summary(services),  # v3.10
    }


def _backup_summary(services: Services) -> dict:
    v = services.backups.view()
    last = v["last_ok"]
    return {"last_at": last.get("created_at") if last else None, "enabled": v["enabled"] and v["has_password"],
            "next_run_at": v["next_run_at"], "error": v["last_error"]}
