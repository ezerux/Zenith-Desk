from typing import Literal

from fastapi import APIRouter, Depends, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy import select

from ..audit import audit
from ..auth import current_agent, get_services
from ..i18n import t as tr
from ..models import AgentMapping, CallRecord, TicketType, WorkSession
from ..services import Services
from ..ticketing import TicketError
from ..views import session_view
from ..workflow import Actor, WorkflowError, ticket_state_name
from ..zammad import ZammadError
from .common import run_idempotent

router = APIRouter(prefix="/api", tags=["tickets"])

WorkMode = Literal["blocking", "background"]


class StartIn(BaseModel):
    work_mode: WorkMode


class CompleteIn(BaseModel):
    ticket_state: str | None = None  # one of ZAMMAD_COMPLETE_STATES; default = first
    note: str | None = None  # internal note added to the ticket
    pending_days: int | None = None


class ReleaseIn(BaseModel):
    reason: str = "released"


@router.post("/tickets/{ticket_id}/start", summary="Start work on a ticket (blocking/background)")
async def start(ticket_id: int, body: StartIn, agent: AgentMapping = Depends(current_agent),
                services: Services = Depends(get_services), idempotency_key: str | None = Header(None)):
    return await run_idempotent(services, agent.id, idempotency_key, f"start:{ticket_id}", body.model_dump(),
                                lambda: services.workflow.start_work(agent, ticket_id, body.work_mode, Actor("agent", agent.id)))


@router.post("/tickets/{ticket_id}/mode", summary="Change work mode (e.g. to background)")
async def change_mode(ticket_id: int, body: StartIn, agent: AgentMapping = Depends(current_agent),
                      services: Services = Depends(get_services), idempotency_key: str | None = Header(None)):
    return await run_idempotent(services, agent.id, idempotency_key, f"mode:{ticket_id}", body.model_dump(),
                                lambda: services.workflow.change_mode(agent, ticket_id, body.work_mode, Actor("agent", agent.id)))


@router.post("/tickets/{ticket_id}/complete", summary="Complete: close the work session and move the ticket to a final state")
async def complete(ticket_id: int, body: CompleteIn | None = None, agent: AgentMapping = Depends(current_agent),
                   services: Services = Depends(get_services), idempotency_key: str | None = Header(None)):
    body = body or CompleteIn()
    return await run_idempotent(services, agent.id, idempotency_key, f"complete:{ticket_id}", body.model_dump(),
                                lambda: services.workflow.complete_work(
                                    agent, ticket_id, Actor("agent", agent.id), ticket_state=body.ticket_state,
                                    note=body.note, pending_days=body.pending_days))


@router.post("/tickets/{ticket_id}/release", summary="Stop working without changing the ticket")
async def release(ticket_id: int, body: ReleaseIn | None = None, agent: AgentMapping = Depends(current_agent),
                  services: Services = Depends(get_services)):
    return await services.workflow.release(agent, ticket_id, Actor("agent", agent.id), (body or ReleaseIn()).reason)


@router.get("/tickets/{ticket_id}", summary="Ticket from Zammad + current work session")
async def get_ticket(ticket_id: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        t = await services.zammad.get_ticket(ticket_id, agent.zammad_user_id)
        states = None if isinstance(t.get("state"), str) else await services.zammad.ticket_states()
    except ZammadError as exc:
        raise HTTPException(404 if exc.status in (403, 404) else 502, str(exc)) from exc
    t["state"] = ticket_state_name(t, states)
    async with services.db.sessionmaker() as s:
        ws = (await s.execute(select(WorkSession).where(
            WorkSession.ticket_id == ticket_id, WorkSession.state == "active"))).scalars().first()
    validation = None
    try:
        await services.workflow.validate_ticket_fields(t)
    except WorkflowError as exc:
        validation = {"message": exc.message, **exc.details}
    return {"ticket": t, "session": session_view(ws) if ws else None, "validation": validation,
            "zammad_url": f"{services.settings.zammad_url.rstrip('/')}/#ticket/zoom/{ticket_id}"}


class FieldsIn(BaseModel):
    fields: dict = Field(default_factory=dict)


@router.patch("/tickets/{ticket_id}/fields", summary="Fill in ticket fields (type, category, ...)")
async def update_fields(ticket_id: int, body: FieldsIn, agent: AgentMapping = Depends(current_agent),
                        services: Services = Depends(get_services)):
    allowed = await _allowed_fields(services)
    bad = [k for k in body.fields if k not in allowed]
    if bad:
        raise HTTPException(422, tr("err.fields_not_allowed", fields=", ".join(bad)))
    try:
        t = await services.zammad.update_ticket(ticket_id, body.fields)
    except ZammadError as exc:
        raise HTTPException(502, str(exc)) from exc
    return {"ticket": t}


async def _allowed_fields(services: Services) -> set[str]:
    allowed = {services.settings.zammad_ticket_type_attribute, "title", "priority"}
    async with services.db.sessionmaker() as s:
        for tt in (await s.execute(select(TicketType).where(TicketType.enabled.is_(True)))).scalars().all():
            allowed.update(f["name"] for f in tt.required_fields or [])
    return allowed


# ---------------------------------------------------------------- FR-02: ticket from a call
class TicketCreateIn(BaseModel):
    title: str = Field(min_length=1, max_length=250)
    customer_id: int
    body: str = ""
    group: str | None = None
    priority: str | None = None  # e.g. "2 normal"
    ticket_type: str | None = None  # TicketType.name
    fields: dict = Field(default_factory=dict)  # additional required fields
    call_id: int | None = None
    start_mode: WorkMode | None = None  # create and immediately «Приступить»
    assign_to_me: bool = True  # v3.3: False = leave it unassigned for the team
    state: str | None = None  # v3.3: e.g. "open"; empty = Zammad's default for new tickets


@router.post("/tickets", summary="Create a ticket (also after a call)")
async def create_ticket(body: TicketCreateIn, agent: AgentMapping = Depends(current_agent),
                        services: Services = Depends(get_services), idempotency_key: str | None = Header(None)):
    async def do() -> dict:
        cfg = services.settings
        attrs = dict(body.fields)
        if body.ticket_type:
            async with services.db.sessionmaker() as s:
                tt = (await s.execute(select(TicketType).where(TicketType.name == body.ticket_type))).scalars().first()
            if tt is None:
                raise HTTPException(422, tr("err.unknown_type"))
            attrs[cfg.zammad_ticket_type_attribute] = tt.zammad_value
            missing = [f.get("label") or f["name"] for f in tt.required_fields or [] if attrs.get(f["name"]) in (None, "", [])]
            if missing:
                raise HTTPException(422, {"message": tr("err.required_fields", fields=", ".join(missing)), "missing": missing})
        call_info = ""
        call = None
        if body.call_id:
            async with services.db.sessionmaker() as s:
                call = await s.get(CallRecord, body.call_id)
            if call is None or call.agent_id != agent.id:
                raise HTTPException(404, tr("err.call_not_found"))
            call_info = services.calls.call_info(call)
        payload = {
            "title": body.title,
            "group": body.group or cfg.zammad_default_group,
            "customer_id": body.customer_id,
            "owner_id": agent.zammad_user_id if body.assign_to_me or body.start_mode else None,
            "article": {
                "subject": body.title,
                "body": "\n\n".join(filter(None, [body.body, call_info])) or body.title,
                "type": "phone" if call else "note",
                "internal": False,
                "sender": "Agent",
                "content_type": "text/plain",
            },
            **attrs,
        }
        if payload["owner_id"] is None:
            payload.pop("owner_id")
        if body.priority:
            payload["priority"] = body.priority
        if body.state:
            payload["state"] = body.state
        try:
            ticket = await services.desk.create(agent, payload)  # in the operator's own name (v3.3)
        except TicketError as exc:
            raise HTTPException(exc.status, exc.message) from exc
        async with services.db.sessionmaker() as s:
            if call is not None:
                c = await s.get(CallRecord, call.id)
                c.ticket_id = ticket["id"]
            audit(s, "ticket_created", agent_id=agent.id, ticket_id=ticket["id"], actor_type="agent",
                  actor_id=agent.id, call_id=body.call_id)
            await s.commit()
        result: dict = {"ticket": {"id": ticket["id"], "number": ticket.get("number"), "title": ticket.get("title")}}
        if body.start_mode:
            result.update(await services.workflow.start_work(agent, ticket["id"], body.start_mode, Actor("agent", agent.id)))
        return result

    return await run_idempotent(services, agent.id, idempotency_key, "create_ticket", body.model_dump(), do)


# ---------------------------------------------------------------- customers (FR-01)
@router.get("/customers/lookup", summary="Find a customer by phone number")
async def lookup(phone: str, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return {"customers": await services.calls.lookup_customers(phone)}


@router.get("/customers/{customer_id}", summary="Customer card with recent tickets")
async def customer(customer_id: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    try:
        user = await services.zammad.get_user(customer_id, agent.zammad_user_id)
        tickets = await services.zammad.search_tickets(
            {"ticket.customer_id": {"operator": "is", "pre_condition": "specific", "value": [str(customer_id)]}},
            limit=10, on_behalf_of=agent.zammad_user_id)
        states = await services.zammad.ticket_states()
    except ZammadError as exc:
        raise HTTPException(502, str(exc)) from exc
    for t in tickets:
        if not isinstance(t.get("state"), str):
            t["state"] = states.get(int(t.get("state_id", 0)), "")
    return {
        "customer": {k: user.get(k) for k in ("id", "firstname", "lastname", "email", "phone", "mobile", "organization", "note")},
        "tickets": [{k: t.get(k) for k in ("id", "number", "title", "state", "created_at", "updated_at")} for t in tickets],
    }


class CustomerIn(BaseModel):
    firstname: str = ""
    lastname: str = ""
    phone: str = ""
    email: str = ""
    note: str = ""


@router.post("/customers", summary="Create a customer (contact) in Zammad")
async def create_customer(body: CustomerIn, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    if not (body.firstname or body.lastname or body.email or body.phone):
        raise HTTPException(422, tr("err.customer_data"))
    data = {k: v for k, v in body.model_dump().items() if v}
    data["roles"] = ["Customer"]
    try:
        user = await services.zammad.create_user(data)
    except ZammadError as exc:
        raise HTTPException(502, str(exc)) from exc
    async with services.db.sessionmaker() as s:
        audit(s, "customer_created", agent_id=agent.id, actor_type="agent", actor_id=agent.id, customer_id=user.get("id"))
        await s.commit()
    try:
        await services.directory.upsert_one({"roles": ["Customer"], **user})  # in the customer list at once (v3.3)
    except Exception:  # noqa: BLE001 — the regular sync will bring it
        pass
    return {"customer": user}


# ---------------------------------------------------------------- UI config
@router.get("/config", summary="UI settings")
async def ui_config(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    cfg = services.settings
    async with services.db.sessionmaker() as s:
        types = (await s.execute(select(TicketType).where(TicketType.enabled.is_(True)).order_by(TicketType.name))).scalars().all()
    return {
        "timezone": cfg.display_timezone,
        "complete_states": cfg.complete_states,
        "pending_states": cfg.pending_states,
        "default_group": cfg.zammad_default_group,
        "zammad_url": cfg.zammad_url.rstrip("/"),
        "wrap_up_seconds": cfg.wrap_up_seconds,
        "idle_timeout_min": cfg.idle_timeout_min,
        "phone_enabled": cfg.phone_enabled and bool(agent.extension),
        "ticket_types": [{"name": t.name, "zammad_value": t.zammad_value, "required_fields": t.required_fields} for t in types],
    }


# ---------------------------------------------------------------- v3.9 protected call recordings (ТЗ 10)
AUDIO = {".wav": "audio/wav", ".mp3": "audio/mpeg", ".gsm": "audio/x-gsm", ".ogg": "audio/ogg", ".wav49": "audio/wav"}


def find_recording(root: str, name: str):
    """The recording file inside the configured folder only (no ../ tricks); FreePBX keeps YYYY/MM/DD sub-folders."""
    from pathlib import Path  # noqa: PLC0415
    base = Path(root).resolve()
    if not name or not base.is_dir():
        return None
    candidate = Path(name)
    tries = [candidate] if candidate.is_absolute() else [base / candidate]
    tries.append(base / candidate.name)
    for p in tries:
        try:
            r = p.resolve()
        except OSError:
            continue
        if r.is_file() and base in r.parents:
            return r
    for p in base.rglob(candidate.name):  # date folders
        r = p.resolve()
        if r.is_file() and base in r.parents:
            return r
    return None


@router.get("/calls/{call_id}/recording", summary="Listen to a call recording (operator of the call or a manager; audited)")
async def recording(call_id: int, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    cfg = services.settings
    async with services.db.sessionmaker() as s:
        call = await s.get(CallRecord, call_id)
        if call is None or not call.recording_file:
            raise HTTPException(404, tr("err.not_found"))
        if call.agent_id != agent.id and agent.role not in ("supervisor", "admin"):
            audit(s, "recording_denied", agent_id=agent.id, actor_type="agent", actor_id=agent.id, level="warning", call_id=call_id)
            await s.commit()
            raise HTTPException(403, "no access to this recording")
        path = find_recording(cfg.recording_dir, call.recording_file) if cfg.recording_dir else None
        if path is None:
            raise HTTPException(404, "recording file not found")
        audit(s, "recording_played", agent_id=call.agent_id, actor_type="agent", actor_id=agent.id, call_id=call_id, file=path.name)
        await s.commit()
    return FileResponse(path, media_type=AUDIO.get(path.suffix.lower(), "application/octet-stream"),
                        headers={"Cache-Control": "private, no-store", "Content-Disposition": f'inline; filename="{path.name}"'})
