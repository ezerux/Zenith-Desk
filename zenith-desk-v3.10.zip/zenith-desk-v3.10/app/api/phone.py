"""v3.5 Zenith Phone: a softphone in the browser.

The browser registers the operator's own FreePBX extension over WebRTC (SIP over secure WebSocket) and makes and
receives calls itself — no desk phone needed. Calls still go through FreePBX, so queues, recordings and the
existing AMI tracking (call card, customer lookup, statistics) work exactly as for a desk phone.
"""
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from sqlalchemy import select

from ..auth import current_agent, get_services
from ..models import AgentMapping, AgentState
from ..phone import normalize_phone
from ..services import Services

router = APIRouter(prefix="/api/phone", tags=["phone"])


def ice_servers(cfg) -> list[dict]:
    out = []
    for url in [u.strip() for u in (cfg.phone_ice_servers or "").split(",") if u.strip()]:
        item: dict = {"urls": url}
        if url.startswith(("turn:", "turns:")) and cfg.phone_turn_username:
            item.update(username=cfg.phone_turn_username, credential=cfg.phone_turn_password)
        out.append(item)
    return out


@router.get("/config", summary="Softphone settings of the signed-in user (incl. his SIP password)")
async def phone_config(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    cfg = services.settings
    ext = (agent.extension or "").strip()
    sip_user = (agent.sip_user or "").strip() or ext
    password = services.store.box.decrypt(agent.sip_secret) if agent.sip_secret else ""
    domain = cfg.phone_sip_domain.strip() or (urlsplit(cfg.phone_wss_url).hostname or "")
    demo = cfg.phone_mode == "demo"
    problem = ""
    if not cfg.phone_enabled:
        problem = "disabled"
    elif not ext:
        problem = "no_extension"
    elif not demo and not cfg.phone_wss_url:
        problem = "no_server"
    elif not demo and not password:
        problem = "no_password"
    body = {
        "enabled": cfg.phone_enabled, "mode": "demo" if demo else "webrtc", "ready": not problem, "problem": problem,
        "extension": ext, "display_name": agent.display_name or agent.username or ext,
        "wss_url": "" if demo else cfg.phone_wss_url, "sip_uri": f"sip:{sip_user}@{domain}" if sip_user and domain else "",
        "authorization_user": sip_user, "password": "" if demo else password, "ice_servers": ice_servers(cfg),
        "voicemail": cfg.phone_voicemail_number or "",
    }
    # the SIP password is needed by the browser to register; never cache it anywhere
    return JSONResponse(body, headers={"Cache-Control": "no-store", "Pragma": "no-cache"})


@router.get("/search", summary="Whom to call: customers (Zammad) and colleagues (extensions)")
async def phone_search(q: str = "", agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    q = q.strip()
    out: list[dict] = []
    if not q:
        return {"items": out}
    ql = q.lower()
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True), AgentMapping.extension != "",
                                                           AgentMapping.id != agent.id))).scalars().all()
        states = {st.agent_id: st.computed_state for st in (await s.execute(select(AgentState))).scalars().all()}
    for m in rows:
        if ql in (m.display_name or "").lower() or ql in (m.username or "") or q == m.extension or m.extension.startswith(q):
            out.append({"kind": "colleague", "id": m.id, "name": m.display_name or m.username, "number": m.extension,
                        "detail": m.position, "state": states.get(m.id, "offline")})
    found = await services.directory.search("customers", q, 0, 8)
    for u in found["items"]:
        for num in filter(None, [u["phone"], u["mobile"]]):
            out.append({"kind": "customer", "id": u["id"], "name": u["name"], "number": num,
                        "detail": u["organization"] or u["email"], "state": None})
    if q.replace("+", "").replace(" ", "").replace("-", "").isdigit() and not any(o["number"] == q for o in out):
        out.insert(0, {"kind": "number", "id": None, "name": q, "number": q, "detail": "", "state": None})
    return {"items": out[:10]}


@router.get("/contacts", summary="Colleagues with an extension and their live state (phone book)")
async def phone_contacts(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(select(AgentMapping).where(AgentMapping.active.is_(True), AgentMapping.extension != "")
                                .order_by(AgentMapping.display_name))).scalars().all()
        states = {st.agent_id: st.computed_state for st in (await s.execute(select(AgentState))).scalars().all()}
    return {"colleagues": [{"id": m.id, "name": m.display_name or m.username, "number": m.extension, "position": m.position,
                            "state": states.get(m.id, "offline"), "me": m.id == agent.id} for m in rows]}


@router.get("/whois", summary="Who is this number (customer card on an incoming call)")
async def whois(number: str, agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        colleague = (await s.execute(select(AgentMapping).where(AgentMapping.extension == number.strip()))).scalars().first()
    if colleague is not None:
        return {"kind": "colleague", "name": colleague.display_name, "detail": colleague.position, "id": colleague.id}
    cfg = services.settings
    norm = normalize_phone(number, country_code=cfg.phone_country_code, national_prefix=cfg.phone_national_prefix)
    digits = norm[-9:] if norm else ""
    if digits:
        res = await services.directory.search("customers", digits, 0, 1)
        if res["items"]:
            u = res["items"][0]
            return {"kind": "customer", "name": u["name"], "detail": u["organization"] or u["email"], "id": u["id"]}
    return {"kind": "unknown", "name": "", "detail": "", "id": None}

