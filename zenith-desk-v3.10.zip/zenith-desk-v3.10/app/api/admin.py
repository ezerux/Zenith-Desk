from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select

from ..audit import audit
from ..auth import get_services, require_role
from ..db import as_utc, utcnow
from ..i18n import t as tr
from ..models import AgentMapping, AuditLog, IntegrationEvent, PauseInterval, WorkSession
from ..services import Services
from ..views import agent_state_view, session_view
from ..workflow import Actor

router = APIRouter(prefix="/api/admin", tags=["supervisor / admin"])
supervisor = require_role("supervisor")
admin = require_role("admin")


@router.get("/agents", summary="All operators: state, reason, tasks")
async def agents(user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        mappings = (await s.execute(select(AgentMapping).where(
            AgentMapping.role != "admin", AgentMapping.active.is_(True)).order_by(AgentMapping.display_name))).scalars().all()
        sessions = (await s.execute(select(WorkSession).where(WorkSession.state == "active"))).scalars().all()
        result = []
        for m in mappings:
            st = await services.engine.ensure_state(s, m.id)
            view = agent_state_view(m, st, services.settings.queues)
            mine = [session_view(w) for w in sessions if w.agent_id == m.id]
            view["blocking"] = [w for w in mine if w["work_mode"] == "blocking"]
            view["background"] = [w for w in mine if w["work_mode"] == "background"]
            result.append(view)
        await s.commit()
    return {"agents": result, "ami_connected": services.pbx.connected}


@router.post("/agents/{agent_id}/reconcile", summary="Reconcile state with Asterisk and Zammad")
async def reconcile(agent_id: int, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        if await s.get(AgentMapping, agent_id) is None:
            raise HTTPException(404, tr("err.agent_not_found"))
        tickets = (await s.execute(select(WorkSession.ticket_id).where(
            WorkSession.agent_id == agent_id, WorkSession.state == "active"))).scalars().all()
        audit(s, "manual_reconcile", agent_id=agent_id, actor_type="supervisor", actor_id=user.id)
        await s.commit()
    for tid in tickets:
        await services.workflow.on_ticket_changed(tid, "manual_reconcile")
    return await services.engine.reconcile(agent_id, "manual_reconcile")


class OverrideIn(BaseModel):
    manual_state: str = Field(pattern="^(ready|break|offline)$")
    ignore_blocking: bool = False
    reason: str = Field(min_length=3)


@router.post("/agents/{agent_id}/override", summary="Supervisor override (reason required, audited)")
async def override(agent_id: int, body: OverrideIn, user: AgentMapping = Depends(supervisor),
                   services: Services = Depends(get_services)):
    return await services.workflow.supervisor_override(agent_id, body.manual_state, body.ignore_blocking,
                                                       body.reason, Actor("supervisor", user.id))


class AssignIn(BaseModel):
    agent_id: int
    work_mode: str | None = Field(default=None, pattern="^(blocking|background)$")


@router.post("/tickets/{ticket_id}/assign", summary="Assign / reassign a ticket")
async def assign(ticket_id: int, body: AssignIn, user: AgentMapping = Depends(supervisor),
                 services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        target = await s.get(AgentMapping, body.agent_id)
    if target is None:
        raise HTTPException(404, tr("err.agent_not_found"))
    return await services.workflow.supervisor_assign(ticket_id, target, body.work_mode, Actor("supervisor", user.id))


class CancelIn(BaseModel):
    reason: str = Field(min_length=3)


@router.post("/sessions/{session_id}/cancel", summary="Cancel an operator's work session")
async def cancel_session(session_id: int, body: CancelIn, user: AgentMapping = Depends(supervisor),
                         services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        ws = await s.get(WorkSession, session_id)
        if ws is None or ws.state != "active":
            raise HTTPException(404, tr("err.session_not_found"))
        agent = await s.get(AgentMapping, ws.agent_id)
    return await services.workflow.release(agent, ws.ticket_id, Actor("supervisor", user.id), f"supervisor: {body.reason}")


@router.get("/audit", summary="Audit log")
async def audit_log(agent_id: int | None = None, ticket_id: int | None = None, level: str | None = None,
                    limit: int = 200, user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(min(limit, 1000))
    if agent_id is not None:
        q = q.where(AuditLog.agent_id == agent_id)
    if ticket_id is not None:
        q = q.where(AuditLog.ticket_id == ticket_id)
    if level:
        q = q.where(AuditLog.level == level)
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(q)).scalars().all()
    return [{"id": r.id, "ts": as_utc(r.ts), "level": r.level, "actor_type": r.actor_type, "actor_id": r.actor_id,
             "agent_id": r.agent_id, "ticket_id": r.ticket_id, "action": r.action, "details": r.details} for r in rows]


@router.get("/integration-events", summary="Integration events (errors, retries)")
async def integration_events(status: str | None = "failed", limit: int = 100, user: AgentMapping = Depends(supervisor),
                             services: Services = Depends(get_services)):
    q = select(IntegrationEvent).order_by(IntegrationEvent.id.desc()).limit(min(limit, 500))
    if status:
        q = q.where(IntegrationEvent.status == status)
    async with services.db.sessionmaker() as s:
        rows = (await s.execute(q)).scalars().all()
    return [{"id": r.id, "source": r.source, "external_event_id": r.external_event_id, "type": r.event_type,
             "status": r.status, "error": r.error, "payload": r.payload, "created_at": as_utc(r.created_at)} for r in rows]


@router.get("/reports/summary", summary="Report: work time, modes, queue pause time, errors")
async def report(date_from: datetime | None = None, date_to: datetime | None = None,
                 user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    end = as_utc(date_to) or utcnow()
    start = as_utc(date_from) or end - timedelta(days=1)

    def overlap(a, b) -> float:
        a, b = as_utc(a), as_utc(b) or utcnow()
        return max(0.0, (min(b, end) - max(a, start)).total_seconds())

    async with services.db.sessionmaker() as s:
        mappings = (await s.execute(select(AgentMapping).where(AgentMapping.role != "admin"))).scalars().all()
        sessions = (await s.execute(select(WorkSession).where(WorkSession.started_at < end))).scalars().all()
        pauses = (await s.execute(select(PauseInterval).where(PauseInterval.started_at < end))).scalars().all()
        errors = (await s.execute(select(AuditLog).where(
            AuditLog.action == "sync_error", AuditLog.ts >= start, AuditLog.ts < end))).scalars().all()
    out = []
    for m in mappings:
        ws = [w for w in sessions if w.agent_id == m.id and (w.ended_at is None or as_utc(w.ended_at) > start)]
        ps = [p for p in pauses if p.agent_id == m.id and (p.ended_at is None or as_utc(p.ended_at) > start)]
        out.append({
            "agent_id": m.id, "name": m.display_name,
            "sessions_started": sum(1 for w in ws if as_utc(w.started_at) >= start),
            "sessions_completed": sum(1 for w in ws if w.state == "completed" and w.ended_at and as_utc(w.ended_at) <= end),
            "blocking_work_sec": int(sum(overlap(w.started_at, w.ended_at) for w in ws if w.work_mode == "blocking")),
            "background_work_sec": int(sum(overlap(w.started_at, w.ended_at) for w in ws if w.work_mode == "background")),
            "queue_paused_sec": int(sum(overlap(p.started_at, p.ended_at) for p in ps)),
            "queue_paused_by_reason_sec": {r: int(sum(overlap(p.started_at, p.ended_at) for p in ps if p.reason == r))
                                           for r in sorted({p.reason for p in ps})},
            "sync_errors": sum(1 for e in errors if e.agent_id == m.id),
        })
    return {"from": start, "to": end, "agents": out}
