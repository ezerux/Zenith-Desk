"""Personal settings of the signed-in user (theme, sound, dashboard layout). Stored on the server,
so the workplace looks the same on any computer the user signs in from."""
from typing import Literal

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, field_validator

from ..auth import current_agent, get_services
from ..models import AgentMapping
from ..services import Services

router = APIRouter(prefix="/api/agents/me", tags=["preferences"])

WIDGETS = ("kpis", "active", "background", "notifications", "new", "mine", "pending", "calls")
PRESETS = ("default", "calls", "tickets", "compact", "focus", "custom")


class Widget(BaseModel):
    id: str
    w: int = Field(ge=1, le=3)  # columns out of 3
    h: Literal["auto", "s", "m", "l"] = "auto"
    hidden: bool = False

    @field_validator("id")
    @classmethod
    def known(cls, v: str) -> str:
        if v not in WIDGETS:
            raise ValueError(f"unknown widget {v}")
        return v


class Preferences(BaseModel):
    theme: Literal["", "light", "dark", "system"] = ""  # "" = default dark console
    sound: bool = True
    compact: bool = False
    motion: bool = True  # v2.6: page transitions and micro-animations
    preset: Literal[PRESETS] = "default"  # type: ignore[valid-type]
    layout: list[Widget] = Field(default_factory=list, max_length=len(WIDGETS))

    @field_validator("layout")
    @classmethod
    def unique(cls, v: list[Widget]) -> list[Widget]:
        ids = [w.id for w in v]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate widgets")
        return v


@router.get("/preferences", summary="Personal settings (theme, sound, dashboard layout)")
async def get_preferences(agent: AgentMapping = Depends(current_agent)):
    return Preferences(**(agent.ui_prefs or {})).model_dump()


@router.put("/preferences", summary="Save personal settings")
async def put_preferences(body: Preferences, agent: AgentMapping = Depends(current_agent),
                          services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, agent.id)
        user.ui_prefs = body.model_dump()
        await s.commit()
    return body.model_dump()
