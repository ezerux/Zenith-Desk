"""v3.10 — Backup page of the admin panel: create, schedule, download, upload, verify and restore backups."""
from datetime import timedelta

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ..auth import get_services, require_role
from ..backup import BackupError
from ..db import utcnow
from ..i18n import get_language, t as tr
from ..models import AgentMapping
from ..services import Services
from ..settings_store import SettingsError

router = APIRouter(prefix="/api/admin/backups", tags=["backup"])
admin = require_role("admin")
STATUS = {"bk.wrong_password": 422, "bk.password_short": 422, "bk.no_password": 409, "bk.busy": 409, "bk.not_found": 404,
          "bk.newer": 409}
SETTING_KEYS = ("backup_enabled", "backup_frequency", "backup_time", "backup_weekday", "backup_keep", "backup_password")


def fail(exc: BackupError) -> HTTPException:
    return HTTPException(STATUS.get(exc.code, 400), tr(exc.code, **exc.params))


async def view(services: Services) -> dict:
    v = services.backups.view()
    if v["last_error"] is None:
        v["last_error"] = await services.backups.last_failure_from_audit()
    v["job"] = services.backups.job
    return v


class CreateIn(BaseModel):
    note: str = Field(default="", max_length=200)
    wait: bool = False  # true: answer when the file is written (API clients / scripts)


class SettingsIn(BaseModel):
    values: dict


class PasswordIn(BaseModel):
    password: str = Field(min_length=1, max_length=500)


class RestoreIn(BaseModel):
    password: str = Field(min_length=1, max_length=500)
    confirm: str = Field(default="")
    wait: bool = False


@router.get("", summary="Backups, schedule, disk space, the running job")
async def list_backups(_: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    return await view(services)


@router.post("", summary="Create a backup now (whole system, encrypted with the backup password)")
async def create(body: CreateIn, me: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    b = services.backups
    if not services.settings.backup_password:
        raise fail(BackupError("bk.no_password"))
    try:
        b.start_job("backup", lambda: b.create("manual", me, note=body.note))
    except BackupError as exc:
        raise fail(exc) from exc
    if body.wait:
        job = await b.wait_job()
        if job and job["state"] == "failed":
            raise HTTPException(400, job.get("error", ""))
    return await view(services)


@router.put("/settings", summary="Schedule, number of copies and the backup password")
async def save_settings(body: SettingsIn, me: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    values = {k: v for k, v in body.values.items() if k in SETTING_KEYS}
    if set(body.values) - set(SETTING_KEYS):
        raise HTTPException(422, "unknown setting")
    try:
        changed = await services.store.save(values, me.id)
    except SettingsError as exc:
        raise HTTPException(422, str(exc)) from exc
    if changed:
        await services.apply_settings(changed)
    if services.settings.backup_enabled and not services.settings.backup_password:
        raise HTTPException(409, tr("bk.no_password"))
    return {**await view(services), "changed": sorted(changed)}


@router.post("/{name}/link", summary="A short-lived download link (the file can then be saved by the browser)")
async def link(name: str, me: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    try:
        services.backups.path(name)
    except BackupError as exc:
        raise fail(exc) from exc
    ticket = jwt.encode({"p": "backup", "n": name, "u": me.id, "exp": utcnow() + timedelta(seconds=120)},
                        services.settings.jwt_secret, algorithm="HS256")
    return {"url": f"/api/admin/backups/{name}/download?ticket={ticket}"}


@router.get("/{name}/download", summary="Download a backup file (ticket from /link)")
async def download(name: str, ticket: str, services: Services = Depends(get_services)):
    try:
        data = jwt.decode(ticket, services.settings.jwt_secret, algorithms=["HS256"])
    except jwt.PyJWTError as exc:
        raise HTTPException(401, tr("err.session_expired")) from exc
    if data.get("p") != "backup" or data.get("n") != name:
        raise HTTPException(403, tr("err.forbidden"))
    async with services.db.sessionmaker() as s:
        who = await s.get(AgentMapping, int(data.get("u") or 0))
    if who is None or who.role != "admin" or not who.active:
        raise HTTPException(403, tr("err.forbidden"))
    try:
        path = services.backups.path(name)
    except BackupError as exc:
        raise fail(exc) from exc
    return FileResponse(path, media_type="application/octet-stream", filename=name, headers={"Cache-Control": "no-store"})


@router.delete("/{name}", summary="Delete a backup file")
async def remove(name: str, _: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    try:
        services.backups.delete(name)
    except BackupError as exc:
        raise fail(exc) from exc
    return await view(services)


@router.put("/upload", summary="Upload a backup file (raw body, ?filename=…) — e.g. from another server")
async def upload(request: Request, filename: str = "", _: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    try:
        saved = await services.backups.save_upload(filename, request.stream())
    except BackupError as exc:
        raise fail(exc) from exc
    return {**await view(services), "uploaded": saved}


@router.post("/{name}/verify", summary="Check the password and that the file is complete (nothing is changed)")
async def verify(name: str, body: PasswordIn, _: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    try:
        return await services.backups.verify(name, body.password)
    except BackupError as exc:
        raise fail(exc) from exc


@router.post("/{name}/restore", summary="Restore the WHOLE system from this backup (a safety copy is made first)")
async def restore(name: str, body: RestoreIn, me: AgentMapping = Depends(admin), services: Services = Depends(get_services)):
    if body.confirm.strip().upper() != "RESTORE":
        raise HTTPException(422, tr("bk.confirm"))
    b = services.backups
    try:
        b.path(name)
        await b.check_password(name, body.password)  # a wrong password is answered right away
        b.start_job("restore", lambda: b.restore(name, body.password, me), name=name)
    except BackupError as exc:
        raise fail(exc) from exc
    if body.wait:
        job = await b.wait_job()
        if job and job["state"] == "failed":
            raise HTTPException(400, job.get("error", ""))
        return {"job": job, "language": get_language()}
    return {"job": b.job}
