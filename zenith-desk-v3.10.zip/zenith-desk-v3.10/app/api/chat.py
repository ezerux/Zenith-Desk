"""Internal messenger between employees (v3.0, extended in v3.1).

Direct 1:1 conversations, kept forever in `chat_message` (bodies encrypted at rest). Every user can write to any active
colleague; nobody — administrators included — can read conversations they are not part of.

Live over SSE: `chat` (new message), `chat_update` (edited / reacted / deleted), `chat_read` (✓✓), `chat_typing`.
When the recipient has no Zenith Desk window open, a Web Push notification is sent to their subscribed browsers.
"""
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import and_, delete, func, not_, or_, select, update

from ..auth import current_agent, get_services
from ..db import as_utc, utcnow
from ..i18n import t as tr
from ..models import AgentMapping, AgentState, ChatMessage, ChatReaction, PushSubscription
from ..services import Services
from ..views import state_label

router = APIRouter(prefix="/api/chat", tags=["messenger"])
push_router = APIRouter(prefix="/api/push", tags=["messenger"])
MAX_BODY = 4000
EDIT_WINDOW = timedelta(hours=48)
REACTIONS = ("❤️", "👍", "😂", "😮", "😢", "🔥", "👏", "🙏")


class MessageIn(BaseModel):
    body: str = Field(min_length=1, max_length=MAX_BODY)

    @field_validator("body")
    @classmethod
    def not_blank(cls, v: str) -> str:
        v = v.strip("\n\r ").replace("\r\n", "\n")
        if not v.strip():
            raise ValueError("empty message")
        return v


class ReactionIn(BaseModel):
    emoji: str = Field(max_length=16)


class SubscriptionIn(BaseModel):
    endpoint: str = Field(min_length=10, max_length=1000)
    keys: dict[str, str]


# ------------------------------------------------------------------ helpers
def _pair(a: int, b: int):
    return or_(and_(ChatMessage.sender_id == a, ChatMessage.recipient_id == b),
               and_(ChatMessage.sender_id == b, ChatMessage.recipient_id == a))


def _visible_to(me: int):
    """Not deleted for everyone, and not deleted "for me" by `me`."""
    return and_(ChatMessage.deleted_at.is_(None),
                not_(and_(ChatMessage.sender_id == me, ChatMessage.hidden_sender)),
                not_(and_(ChatMessage.recipient_id == me, ChatMessage.hidden_recipient)))


async def _reactions(s, ids: list[int]) -> dict[int, list[dict]]:
    out: dict[int, dict[str, list[int]]] = {}
    if ids:
        for r in (await s.execute(select(ChatReaction).where(ChatReaction.message_id.in_(ids))
                                  .order_by(ChatReaction.created_at))).scalars():
            out.setdefault(r.message_id, {}).setdefault(r.emoji, []).append(r.user_id)
    return {mid: [{"emoji": e, "users": u} for e, u in em.items()] for mid, em in out.items()}


def message_view(services: Services, m: ChatMessage, reactions: list[dict] | None = None) -> dict:
    return {"id": m.id, "from": m.sender_id, "to": m.recipient_id, "body": services.cipher.open(m.body),
            "at": as_utc(m.created_at), "read_at": as_utc(m.read_at), "edited_at": as_utc(m.edited_at),
            "reactions": reactions or []}


async def _peer(s, me: AgentMapping, user_id: int) -> AgentMapping:
    if user_id == me.id:
        raise HTTPException(400, tr("chat.self"))
    peer = await s.get(AgentMapping, user_id)
    if peer is None:
        raise HTTPException(404, tr("chat.no_user"))
    return peer


async def _own_message(s, me: AgentMapping, message_id: int) -> ChatMessage:
    m = await s.get(ChatMessage, message_id)
    if m is None or m.deleted_at is not None or me.id not in (m.sender_id, m.recipient_id):
        raise HTTPException(404, tr("chat.no_message"))
    return m


def _presence(services: Services, m: AgentMapping, st: AgentState | None) -> dict:
    online = services.broker.connections(m.id) > 0
    idle = bool(st and st.idle_since)
    last = as_utc(st.last_activity_at) if st and st.last_activity_at else as_utc(m.last_login_at)
    return {"online": online and not idle, "away": online and idle, "last_seen": last,
            "state": st.computed_state if st else "offline"}


def _person(services: Services, m: AgentMapping, st: AgentState | None) -> dict:
    return {"id": m.id, "name": m.display_name or m.username, "username": m.username, "position": m.position,
            "level": m.level, "role": m.role, "extension": m.extension, "active": m.active,
            **_presence(services, m, st)}


def _broadcast(services: Services, m: ChatMessage, event: str, data: dict) -> None:
    for uid in {m.sender_id, m.recipient_id}:
        services.broker.publish_agent(uid, event, data)


# ------------------------------------------------------------------ contacts & conversations
@router.get("/contacts", summary="Chats (people you have talked to), newest first; with q: search all colleagues")
async def contacts(q: str = "", me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        people = (await s.execute(select(AgentMapping).where(AgentMapping.id != me.id))).scalars().all()
        states = {st.agent_id: st for st in (await s.execute(select(AgentState))).scalars().all()}
        peer = func.coalesce(func.nullif(ChatMessage.sender_id, me.id), ChatMessage.recipient_id).label("peer")
        last_ids = (await s.execute(select(peer, func.max(ChatMessage.id)).where(
            or_(ChatMessage.sender_id == me.id, ChatMessage.recipient_id == me.id), _visible_to(me.id))
            .group_by(peer))).all()
        lasts = {}
        if last_ids:
            rows = (await s.execute(select(ChatMessage).where(ChatMessage.id.in_([i for _, i in last_ids])))).scalars().all()
            lasts = {(r.recipient_id if r.sender_id == me.id else r.sender_id): r for r in rows}
        unread = dict((await s.execute(select(ChatMessage.sender_id, func.count()).where(
            ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None), _visible_to(me.id))
            .group_by(ChatMessage.sender_id))).all())
    ql = q.strip().lower()
    out = []
    for m in people:
        last = lasts.get(m.id)
        if ql:
            if not m.active and not last:
                continue
            if not any(ql in (x or "").lower() for x in (m.display_name, m.username, m.position, m.extension)):
                continue
        elif not last:
            continue  # the list shows only conversations; search finds everybody else
        out.append({**_person(services, m, states.get(m.id)),
                    "last": message_view(services, last) if last else None, "unread": unread.get(m.id, 0)})
    out.sort(key=lambda c: (c["last"] is None, -(c["last"]["id"] if c["last"] else 0), c["name"].lower()))
    return {"contacts": out, "unread_total": sum(unread.values())}


@router.get("/unread", summary="Number of unread messages (badge in the menu)")
async def unread(me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        n = (await s.execute(select(func.count()).where(
            ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None), _visible_to(me.id)))).scalar_one()
    return {"unread": n}


@router.get("/{user_id}/messages", summary="Conversation with a colleague (newest page; older with before_id)")
async def messages(user_id: int, before_id: int | None = None, limit: int = 60,
                   me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    limit = max(1, min(limit, 200))
    async with services.db.sessionmaker() as s:
        await _peer(s, me, user_id)
        q = select(ChatMessage).where(_pair(me.id, user_id), _visible_to(me.id))
        if before_id:
            q = q.where(ChatMessage.id < before_id)
        rows = (await s.execute(q.order_by(ChatMessage.id.desc()).limit(limit + 1))).scalars().all()
        page = list(reversed(rows[:limit]))
        reacts = await _reactions(s, [m.id for m in page])
    return {"messages": [message_view(services, m, reacts.get(m.id)) for m in page], "has_more": len(rows) > limit}


@router.post("/{user_id}/messages", summary="Send a message")
async def send(user_id: int, body: MessageIn, me: AgentMapping = Depends(current_agent),
               services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        peer = await _peer(s, me, user_id)
        if not peer.active:
            raise HTTPException(409, tr("chat.inactive"))
        msg = ChatMessage(sender_id=me.id, recipient_id=peer.id, body=services.cipher.seal(body.body), created_at=utcnow())
        s.add(msg)
        await s.commit()
        view = message_view(services, msg)
    sender = {"id": me.id, "name": me.display_name or me.username}
    _broadcast(services, msg, "chat", {"message": view, "sender": sender})
    if services.broker.connections(peer.id) == 0:  # no Zenith Desk window open -> background notification
        services.push.notify_later(peer.id, {"type": "chat", "title": sender["name"], "body": body.body[:180],
                                             "from": me.id, "id": msg.id})
    return view


@router.post("/{user_id}/read", summary="Mark the conversation as read (sends read receipts)")
async def mark_read(user_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    now = utcnow()
    async with services.db.sessionmaker() as s:
        await _peer(s, me, user_id)
        top = (await s.execute(select(func.max(ChatMessage.id)).where(
            ChatMessage.sender_id == user_id, ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None)))).scalar()
        if top is None:
            return {"read": 0}
        res = await s.execute(update(ChatMessage).where(
            ChatMessage.sender_id == user_id, ChatMessage.recipient_id == me.id, ChatMessage.read_at.is_(None),
            ChatMessage.id <= top).values(read_at=now))
        await s.commit()
    data = {"reader": me.id, "peer": user_id, "up_to": top, "at": now}
    services.broker.publish_agent(user_id, "chat_read", data)
    services.broker.publish_agent(me.id, "chat_read", data)
    return {"read": res.rowcount}


@router.post("/{user_id}/typing", summary="“typing…” indicator for the colleague (not stored)")
async def typing(user_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    if user_id != me.id:
        services.broker.publish_agent(user_id, "chat_typing", {"from": me.id})
    return {"ok": True}


# ------------------------------------------------------------------ reactions, edit, delete (v3.1)
@router.post("/messages/{message_id}/react", summary="React with an emoji (same emoji again removes it)")
async def react(message_id: int, body: ReactionIn, me: AgentMapping = Depends(current_agent),
                services: Services = Depends(get_services)):
    if body.emoji not in REACTIONS:
        raise HTTPException(422, tr("chat.bad_reaction"))
    async with services.db.sessionmaker() as s:
        m = await _own_message(s, me, message_id)
        mine = (await s.execute(select(ChatReaction).where(
            ChatReaction.message_id == m.id, ChatReaction.user_id == me.id))).scalars().first()
        if mine and mine.emoji == body.emoji:
            await s.delete(mine)
        elif mine:
            mine.emoji, mine.created_at = body.emoji, utcnow()
        else:
            s.add(ChatReaction(message_id=m.id, user_id=me.id, emoji=body.emoji, created_at=utcnow()))
        await s.commit()
        view = message_view(services, m, (await _reactions(s, [m.id])).get(m.id))
    _broadcast(services, m, "chat_update", {"message": view})
    return view


@router.patch("/messages/{message_id}", summary="Edit your own message (within 48 hours)")
async def edit(message_id: int, body: MessageIn, me: AgentMapping = Depends(current_agent),
               services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        m = await _own_message(s, me, message_id)
        if m.sender_id != me.id:
            raise HTTPException(403, tr("chat.not_yours"))
        if utcnow() - as_utc(m.created_at) > EDIT_WINDOW:
            raise HTTPException(409, tr("chat.too_old"))
        if services.cipher.open(m.body) != body.body:
            m.body, m.edited_at = services.cipher.seal(body.body), utcnow()
            await s.commit()
        view = message_view(services, m, (await _reactions(s, [m.id])).get(m.id))
    _broadcast(services, m, "chat_update", {"message": view})
    return view


@router.delete("/messages/{message_id}", summary="Delete a message: for me, or for everyone (own messages)")
async def remove(message_id: int, scope: str = "me", me: AgentMapping = Depends(current_agent),
                 services: Services = Depends(get_services)):
    if scope not in ("me", "all"):
        raise HTTPException(422, "scope must be 'me' or 'all'")
    async with services.db.sessionmaker() as s:
        m = await _own_message(s, me, message_id)
        if scope == "all":
            if m.sender_id != me.id:
                raise HTTPException(403, tr("chat.not_yours"))
            m.deleted_at, m.body = utcnow(), services.cipher.seal("")  # the text is gone from the database too
            await s.execute(delete(ChatReaction).where(ChatReaction.message_id == m.id))
        elif m.sender_id == me.id:
            m.hidden_sender = True
        else:
            m.hidden_recipient = True
            if m.read_at is None:
                m.read_at = utcnow()  # a hidden message is not "unread" any more
        await s.commit()
    data = {"deleted": message_id, "peer": m.recipient_id if m.sender_id == me.id else m.sender_id, "by": me.id, "scope": scope}
    if scope == "all":
        _broadcast(services, m, "chat_update", data)
    else:
        services.broker.publish_agent(me.id, "chat_update", data)  # only my other tabs
    return {"ok": True}


@router.get("/{user_id}/profile", summary="Colleague's card: position, level, extension, state, shared history")
async def profile(user_id: int, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        peer = await _peer(s, me, user_id)
        st = await s.get(AgentState, peer.id)
        total, first = (await s.execute(select(func.count(), func.min(ChatMessage.created_at)).where(
            _pair(me.id, peer.id), _visible_to(me.id)))).one()
        week = (await s.execute(select(func.count()).where(
            _pair(me.id, peer.id), _visible_to(me.id), ChatMessage.created_at >= utcnow() - timedelta(days=7)))).scalar_one()
    return {**_person(services, peer, st), "state_label": state_label(st.computed_state) if st else state_label("offline"),
            "reason": (tr("reason.idle") if st and st.idle_since else st.reason) if st else "",
            "member_since": as_utc(peer.created_at), "messages_total": total, "messages_week": week,
            "first_message_at": as_utc(first)}


# ------------------------------------------------------------------ Web Push subscriptions (v3.1)
@push_router.get("/key", summary="Public VAPID key for subscribing this browser")
async def push_key(me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return {"key": await services.push.public_key()}


@push_router.post("/subscribe", summary="Receive notifications in this browser even when Zenith Desk is closed")
async def subscribe(body: SubscriptionIn, request: Request, me: AgentMapping = Depends(current_agent),
                    services: Services = Depends(get_services)):
    if not body.endpoint.startswith("https://") or not body.keys.get("p256dh") or not body.keys.get("auth"):
        raise HTTPException(422, "invalid subscription")
    async with services.db.sessionmaker() as s:
        row = (await s.execute(select(PushSubscription).where(PushSubscription.endpoint == body.endpoint))).scalars().first()
        if row is None:
            row = PushSubscription(endpoint=body.endpoint, created_at=utcnow())
            s.add(row)
        row.agent_id, row.p256dh, row.auth = me.id, body.keys["p256dh"], body.keys["auth"]
        row.user_agent = (request.headers.get("user-agent") or "")[:300]
        await s.commit()
    return {"ok": True}


@push_router.post("/unsubscribe", summary="Stop background notifications in this browser")
async def unsubscribe(body: SubscriptionIn, me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        await s.execute(delete(PushSubscription).where(PushSubscription.endpoint == body.endpoint,
                                                       PushSubscription.agent_id == me.id))
        await s.commit()
    return {"ok": True}


@push_router.get("/status", summary="How many browsers of mine receive background notifications")
async def push_status(me: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        n = (await s.execute(select(func.count()).where(PushSubscription.agent_id == me.id))).scalar_one()
    return {"subscriptions": n}
