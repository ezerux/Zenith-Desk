import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..audit import audit
from ..auth import current_agent, get_services, issue_token
from ..crypto import hash_password, verify_password
from ..db import utcnow
from ..i18n import t as tr
from ..models import AgentMapping
from ..services import Services
from ..workflow import Actor
from sqlalchemy import func, select

router = APIRouter(prefix="/api/auth", tags=["auth"])

_failures: dict[str, deque] = defaultdict(deque)
MAX_FAILURES, WINDOW_SEC = 5, 300


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=1, max_length=200)


def user_view(agent: AgentMapping) -> dict:
    return {"id": agent.id, "name": agent.display_name, "username": agent.username, "role": agent.role,
            "position": agent.position, "level": agent.level, "extension": agent.extension,
            "zammad_user_id": agent.zammad_user_id, "must_change_password": agent.must_change_password,
            "prefs": agent.ui_prefs or {}}


@router.post("/login", summary="Sign in with the login and password issued by the administrator")
async def login(body: LoginIn, services: Services = Depends(get_services)):
    username = body.username.strip().lower()
    now = time.monotonic()
    fails = _failures[username]
    while fails and now - fails[0] > WINDOW_SEC:
        fails.popleft()
    if len(fails) >= MAX_FAILURES:
        raise HTTPException(429, tr("err.too_many_attempts"))
    async with services.db.sessionmaker() as s:
        agent = (await s.execute(select(AgentMapping).where(func.lower(AgentMapping.username) == username))).scalars().first()
        if agent is None or not agent.password_hash or not verify_password(body.password, agent.password_hash):
            fails.append(now)
            raise HTTPException(401, tr("err.bad_credentials"))
        if not agent.active:
            raise HTTPException(403, tr("err.user_disabled"))
        fails.clear()
        agent.last_login_at = utcnow()
        st = await services.engine.ensure_state(s, agent.id)
        was_offline = st.manual_state == "offline"
        audit(s, "login", agent_id=agent.id, actor_type="agent", actor_id=agent.id)
        st = await services.engine.ensure_state(s, agent.id)
        st.last_activity_at, st.idle_since = utcnow(), None
        await s.commit()
    if was_offline and agent.role != "admin":
        target = "ready" if services.settings.login_sets_ready else "break"
        await services.workflow.set_manual_state(agent.id, target, Actor("system", agent.id), "login")
    return {"token": issue_token(services, agent), "agent": user_view(agent)}


@router.get("/me")
async def me(agent: AgentMapping = Depends(current_agent)):
    return user_view(agent)


class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=200)


@router.post("/change-password", summary="Change own password")
async def change_password(body: PasswordChangeIn, agent: AgentMapping = Depends(current_agent),
                          services: Services = Depends(get_services)):
    async with services.db.sessionmaker() as s:
        user = await s.get(AgentMapping, agent.id)
        if not verify_password(body.current_password, user.password_hash):
            raise HTTPException(400, tr("err.wrong_current_password"))
        if body.current_password == body.new_password:
            raise HTTPException(400, tr("err.same_password"))
        user.password_hash = hash_password(body.new_password)
        user.must_change_password = False
        audit(s, "password_changed", agent_id=user.id, actor_type="agent", actor_id=user.id)
        await s.commit()
        return {"token": issue_token(services, user), "agent": user_view(user)}


@router.post("/logout", summary="Sign out (operator goes OFFLINE)")
async def logout(agent: AgentMapping = Depends(current_agent), services: Services = Depends(get_services)):
    return await services.workflow.set_manual_state(agent.id, "offline", Actor("agent", agent.id), "logout")
