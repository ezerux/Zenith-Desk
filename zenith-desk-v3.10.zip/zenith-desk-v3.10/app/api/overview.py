"""Manager overview: the whole picture of the contact center for a day or a period (v2.5)."""
from datetime import date, datetime, time, timedelta, timezone
from typing import Literal
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, or_, select

from ..auth import get_services, require_role
from ..db import utcnow
from ..metrics import compute_overview
from ..models import AgentMapping, AgentState, AuditLog, CallRecord, QueueCall, WorkSession
from ..services import Services

router = APIRouter(prefix="/api/admin", tags=["supervisor / admin"])
supervisor = require_role("supervisor")


def period_bounds(period: str, day: date | None, tz_name: str) -> tuple[datetime, datetime]:
    try:
        tz = ZoneInfo(tz_name)
    except Exception:  # noqa: BLE001
        tz = timezone.utc

    def midnight(d: date) -> datetime:
        return datetime.combine(d, time.min, tzinfo=tz).astimezone(timezone.utc)

    today = datetime.now(tz).date()
    if day is not None:
        return midnight(day), midnight(day + timedelta(days=1))
    if period == "yesterday":
        return midnight(today - timedelta(days=1)), midnight(today)
    if period == "7d":
        return midnight(today - timedelta(days=6)), midnight(today + timedelta(days=1))
    if period == "30d":
        return midnight(today - timedelta(days=29)), midnight(today + timedelta(days=1))
    return midnight(today), midnight(today + timedelta(days=1))


@router.get("/overview", summary="Manager overview: calls, service level, missed calls, workload, operator ranking")
async def overview(period: Literal["today", "yesterday", "7d", "30d"] = "today", day: date | None = None,
                   user: AgentMapping = Depends(supervisor), services: Services = Depends(get_services)):
    cfg = services.settings
    start, end = period_bounds(period, day, cfg.display_timezone)
    now = utcnow()
    if start > now:
        raise HTTPException(400, "period is in the future")
    async with services.db.sessionmaker() as s:
        agents = (await s.execute(select(AgentMapping).where(AgentMapping.role != "admin")
                                  .order_by(AgentMapping.display_name))).scalars().all()
        states = {st.agent_id: st for st in (await s.execute(select(AgentState))).scalars().all()}
        queue_calls = (await s.execute(select(QueueCall).where(QueueCall.joined_at >= start))).scalars().all()
        records = (await s.execute(select(CallRecord).where(CallRecord.started_at >= start - timedelta(hours=1)))).scalars().all()
        sessions = (await s.execute(select(WorkSession).where(
            WorkSession.started_at < end, or_(WorkSession.ended_at.is_(None), WorkSession.ended_at >= start)))).scalars().all()
        events = (await s.execute(select(AuditLog).where(
            AuditLog.action == "availability_changed", AuditLog.ts >= start, AuditLog.ts < min(end, now))
            .order_by(AuditLog.ts, AuditLog.id))).scalars().all()
        last_ids = select(func.max(AuditLog.id)).where(
            AuditLog.action == "availability_changed", AuditLog.ts < start, AuditLog.agent_id.is_not(None)
        ).group_by(AuditLog.agent_id)
        before = (await s.execute(select(AuditLog).where(AuditLog.id.in_(last_ids)))).scalars().all()
    initial = {a.id: "offline" for a in agents}
    for e in before:
        initial[e.agent_id] = (e.details or {}).get("new", "offline")
    # inactive accounts are listed only if they did something in the period
    active_ids = {r.agent_id for r in records} | {w.agent_id for w in sessions} | {e.agent_id for e in events}
    agents = [a for a in agents if a.active or a.id in active_ids]
    return compute_overview(
        start=start, end=end, now=now, tz=cfg.display_timezone, agents=agents, states_now=states,
        queue_calls=queue_calls, records=records, sessions=sessions, events=events, initial_states=initial,
        sla_sec=cfg.sla_answer_seconds, short_sec=cfg.short_abandon_seconds, sla_target=cfg.sla_target_percent / 100,
    )
