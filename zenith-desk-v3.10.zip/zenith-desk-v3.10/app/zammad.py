"""Zammad REST API client (ТЗ 7.1). Only the official API is used — never Zammad's DB.

Endpoints used (verify on the installed version during stage 0):
  GET  /api/v1/users/me
  GET  /api/v1/users/search?query=
  POST /api/v1/users
  GET  /api/v1/tickets/{id}?expand=true
  PUT  /api/v1/tickets/{id}
  POST /api/v1/tickets
  POST /api/v1/ticket_articles
  GET  /api/v1/ticket_states
  POST /api/v1/tickets/search   (with "condition", as used by Zammad overviews)
v3.3 ticketing (checked against the Zammad source, see tests/test_zammad_contract.py):
  GET  /api/v1/ticket_states?expand=true          state names + state types (new/open/pending/closed/merged)
  GET  /api/v1/ticket_priorities?expand=true
  GET  /api/v1/groups?expand=true                 (on behalf of the operator: only the groups he may use)
  GET  /api/v1/ticket_articles/by_ticket/{id}?expand=true
  GET  /api/v1/ticket_attachment/{ticket}/{article}/{id}
  GET  /api/v1/users/search?query=*&sort_by=updated_at&order_by=desc&page=&per_page=&expand=true
"""
import base64
import logging
import time
from typing import Any

import httpx

from .i18n import t as tr

log = logging.getLogger("zammad")


class ZammadError(Exception):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class ZammadClient:
    def __init__(self, base_url: str, token: str, *, verify_tls: bool = True, timeout: float = 10.0,
                 transport: httpx.AsyncBaseTransport | None = None):
        self.base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Token token={token}", "Content-Type": "application/json"},
            verify=verify_tls,
            timeout=timeout,
            transport=transport,
        )
        self._transport = transport
        self._verify = verify_tls
        self._timeout = timeout
        self._states_cache: tuple[float, list[dict]] | None = None
        self._cache: dict[str, tuple[float, Any]] = {}

    async def close(self) -> None:
        await self._client.aclose()

    async def _request(self, method: str, path: str, **kwargs) -> Any:
        try:
            r = await self._client.request(method, path, **kwargs)
        except httpx.HTTPError as exc:
            raise ZammadError(tr("err.zammad_unavailable", error=exc)) from exc
        if r.status_code >= 400:
            try:
                detail = r.json().get("error_human") or r.json().get("error") or r.text
            except ValueError:
                detail = r.text
            raise ZammadError(f"Zammad {method} {path}: {r.status_code} {detail}"[:500], r.status_code)
        if not r.content:
            return None
        return r.json()

    async def _raw(self, path: str, headers: dict | None = None) -> httpx.Response:
        try:
            r = await self._client.get(path, headers=headers)
        except httpx.HTTPError as exc:
            raise ZammadError(tr("err.zammad_unavailable", error=exc)) from exc
        if r.status_code >= 400:
            raise ZammadError(f"Zammad GET {path}: {r.status_code}", r.status_code)
        return r

    async def _cached(self, key: str, ttl: float, fetch):
        hit = self._cache.get(key)
        now = time.monotonic()
        if hit and now - hit[0] < ttl:
            return hit[1]
        value = await fetch()
        self._cache[key] = (now, value)
        return value

    def forget_cache(self) -> None:
        self._cache.clear()
        self._states_cache = None

    # ------------------------------------------------------------------ auth
    async def authenticate_user(self, login: str, password: str | None = None, token: str | None = None) -> dict:
        """Validate operator credentials against Zammad and return the Zammad user."""
        if token:
            headers = {"Authorization": f"Token token={token}"}
        else:
            raw = base64.b64encode(f"{login}:{password}".encode()).decode()
            headers = {"Authorization": f"Basic {raw}"}
        async with httpx.AsyncClient(base_url=self.base_url, verify=self._verify, timeout=self._timeout,
                                     transport=self._transport) as c:
            try:
                r = await c.get("/api/v1/users/me", headers=headers)
            except httpx.HTTPError as exc:
                raise ZammadError(tr("err.zammad_unavailable", error=exc)) from exc
        if r.status_code in (401, 403):
            raise ZammadError(tr("err.bad_credentials"), 401)
        if r.status_code >= 400:
            raise ZammadError(f"Zammad: {r.status_code}", r.status_code)
        return r.json()

    async def me(self) -> dict:
        """The service user (used by the admin panel connection test)."""
        return await self._request("GET", "/api/v1/users/me")

    # ------------------------------------------------------------------ tickets
    @staticmethod
    def _obo(user_id: int | None) -> dict | None:
        # Zammad 6+ reads "From"; older versions only know "X-On-Behalf-Of" (deprecated, still accepted).
        return {"From": str(user_id), "X-On-Behalf-Of": str(user_id)} if user_id else None

    async def get_ticket(self, ticket_id: int, on_behalf_of: int | None = None) -> dict:
        return await self._request("GET", f"/api/v1/tickets/{ticket_id}", params={"expand": "true"},
                                   headers=self._obo(on_behalf_of))

    async def update_ticket(self, ticket_id: int, data: dict, on_behalf_of: int | None = None) -> dict:
        return await self._request("PUT", f"/api/v1/tickets/{ticket_id}", params={"expand": "true"}, json=data,
                                   headers=self._obo(on_behalf_of))

    async def create_ticket(self, data: dict, on_behalf_of: int | None = None) -> dict:
        return await self._request("POST", "/api/v1/tickets", json=data, headers=self._obo(on_behalf_of))

    async def articles(self, ticket_id: int, on_behalf_of: int | None = None) -> list[dict]:
        return await self._request("GET", f"/api/v1/ticket_articles/by_ticket/{ticket_id}", params={"expand": "true"},
                                   headers=self._obo(on_behalf_of)) or []

    async def add_article(self, data: dict, on_behalf_of: int | None = None) -> dict:
        return await self._request("POST", "/api/v1/ticket_articles", json=data, headers=self._obo(on_behalf_of))

    async def attachment(self, ticket_id: int, article_id: int, attachment_id: int,
                         on_behalf_of: int | None = None) -> httpx.Response:
        return await self._raw(f"/api/v1/ticket_attachment/{ticket_id}/{article_id}/{attachment_id}",
                               headers=self._obo(on_behalf_of))

    async def priorities(self) -> list[dict]:
        async def fetch():
            rows = await self._request("GET", "/api/v1/ticket_priorities", params={"expand": "true"}) or []
            return [{"id": int(p["id"]), "name": p["name"], "active": p.get("active", True) is not False,
                     "default": bool(p.get("default_create"))} for p in rows]
        return await self._cached("priorities", 600, fetch)

    async def groups(self, on_behalf_of: int | None = None) -> list[dict]:
        async def fetch():
            rows = await self._request("GET", "/api/v1/groups", params={"expand": "true", "per_page": 500},
                                       headers=self._obo(on_behalf_of)) or []
            return [{"id": int(g["id"]), "name": g.get("name_last") or g["name"], "full_name": g["name"],
                     "active": g.get("active", True) is not False} for g in rows]
        return await self._cached(f"groups:{on_behalf_of}", 300, fetch)

    async def search_tickets_page(self, condition: dict, *, query: str = "", page: int = 1, per_page: int = 50,
                                  on_behalf_of: int | None = None, sort_by: str = "updated_at",
                                  order_by: str = "desc") -> tuple[list[dict], int]:
        body: dict = {"condition": condition, "page": page, "per_page": per_page, "expand": True,
                      "with_total_count": True, "sort_by": sort_by, "order_by": order_by}
        if query:
            body["query"] = query
        data = await self._request("POST", "/api/v1/tickets/search", headers=self._obo(on_behalf_of), json=body)
        records = self._search_records(data, "Ticket")
        total = data.get("total_count", len(records)) if isinstance(data, dict) else len(records)
        return records, int(total or 0)

    async def add_note(self, ticket_id: int, body: str, internal: bool = True) -> dict:
        return await self._request("POST", "/api/v1/ticket_articles", json={
            "ticket_id": ticket_id, "body": body, "type": "note", "internal": internal, "content_type": "text/plain",
        })

    async def state_list(self) -> list[dict]:
        """[{id, name, type, active}] — type is Zammad's state type: new, open, pending reminder,
        pending action, closed, merged, removed."""
        now = time.monotonic()
        if self._states_cache and now - self._states_cache[0] < 600:
            return self._states_cache[1]
        states = await self._request("GET", "/api/v1/ticket_states", params={"expand": "true"}) or []
        out = [{"id": int(s["id"]), "name": s["name"], "active": s.get("active", True) is not False,
                "type": str(s.get("state_type") or s["name"]).lower()} for s in states]
        self._states_cache = (now, out)
        return out

    async def ticket_states(self) -> dict[int, str]:
        return {s["id"]: s["name"] for s in await self.state_list()}

    async def state_ids(self, names: list[str]) -> list[int]:
        wanted = {n.lower() for n in names}
        return [sid for sid, name in (await self.ticket_states()).items() if name.lower() in wanted]

    async def search_tickets(self, condition: dict, limit: int = 50, on_behalf_of: int | None = None) -> list[dict]:
        data = await self._request("POST", "/api/v1/tickets/search", headers=self._obo(on_behalf_of), json={
            "condition": condition, "limit": limit, "expand": True, "sort_by": "updated_at", "order_by": "desc",
        })
        return self._search_records(data, "Ticket")

    @staticmethod
    def _search_records(data: Any, model: str) -> list[dict]:
        """Accept every search response shape Zammad has used:
        expand → [..]; expand + with_total_count → {records, total_count};
        full → {record_ids, assets, total_count} (older releases: {tickets, assets})."""
        if isinstance(data, list):
            return data
        if not isinstance(data, dict):
            return []
        if isinstance(data.get("records"), list):
            return data["records"]
        if "assets" in data:
            objs = data.get("assets", {}).get(model, {})
            ids = data.get("record_ids") or data.get("tickets") or data.get("users") or []
            return [objs[str(i)] for i in ids if str(i) in objs]
        return []

    # ------------------------------------------------------------------ users
    async def search_users(self, query: str, limit: int = 20) -> list[dict]:
        data = await self._request("GET", "/api/v1/users/search", params={"query": query, "limit": limit, "expand": "true"})
        return self._search_records(data, "User")

    async def create_user(self, data: dict) -> dict:
        return await self._request("POST", "/api/v1/users", json=data)

    async def users_page(self, page: int, per_page: int = 200) -> list[dict]:
        """Everybody (customers and staff), most recently changed first — used by the directory sync."""
        data = await self._request("GET", "/api/v1/users/search", params={
            "query": "*", "sort_by": "updated_at", "order_by": "desc", "page": page, "per_page": per_page,
            "expand": "true"})
        return self._search_records(data, "User")

    async def get_user(self, user_id: int, on_behalf_of: int | None = None) -> dict:
        return await self._request("GET", f"/api/v1/users/{user_id}", headers=self._obo(on_behalf_of))
