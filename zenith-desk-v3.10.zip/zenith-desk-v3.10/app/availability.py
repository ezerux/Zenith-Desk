"""Pure availability rules (ТЗ 4.3, FR-07, FR-08). No I/O here — easy to unit-test.

Priority: OFFLINE > BREAK > blocking tasks > WRAP_UP > READY.
Background tasks never affect availability.
"""
from dataclasses import dataclass

from .i18n import t as tr


@dataclass(frozen=True)
class Availability:
    state: str  # ready/busy_task/break/offline/wrap_up
    reason: str

    @property
    def should_be_paused(self) -> bool:
        return self.state != "ready"


def compute_availability(
    manual_state: str,
    blocking_tickets: list[str] | tuple[str, ...],
    *,
    override_ready: bool = False,
    wrap_up_active: bool = False,
    dnd: bool = False,
) -> Availability:
    if manual_state == "offline":
        return Availability("offline", tr("reason.offline"))
    if manual_state == "break":
        return Availability("break", tr("reason.break"))
    if dnd:  # v3.7 "Do not disturb" from the phone: no calls at all (queues paused, browser phone rejects)
        return Availability("break", tr("reason.dnd"))
    if blocking_tickets and not override_ready:
        n = len(blocking_tickets)
        listed = ", ".join(f"#{t}" for t in blocking_tickets[:3]) + ("…" if n > 3 else "")
        return Availability("busy_task", tr("reason.blocking", n=n, tickets=listed))
    if wrap_up_active:
        return Availability("wrap_up", tr("reason.wrap_up"))
    if blocking_tickets and override_ready:
        return Availability("ready", tr("reason.ready_override"))
    return Availability("ready", tr("reason.ready"))
