"""Server-side CLI for emergencies only — normal administration is done in the admin panel.

    python -m app.cli reset-password admin           # prints a new random password
    python -m app.cli create-admin --username boss   # creates another administrator
    python -m app.cli list-users
    python -m app.cli backup                         # v3.10: write a backup now (password asked or BACKUP_PASSWORD)
    python -m app.cli restore FILE.zdb --yes         # v3.10: restore the WHOLE system (stop the app first)
    python -m app.cli backups                        # list the backup files
"""
import argparse
import asyncio
import getpass
import os
import secrets
import sys
from pathlib import Path

from sqlalchemy import func, select

from .config import get_settings
from .crypto import hash_password
from .db import Database
from .models import AgentMapping, AgentState


async def reset_password(a) -> None:
    db = Database(get_settings().database_url)
    async with db.sessionmaker() as s:
        m = (await s.execute(select(AgentMapping).where(func.lower(AgentMapping.username) == a.username.lower()))).scalars().first()
        if m is None:
            print("user not found")
        else:
            password = a.password or secrets.token_urlsafe(9)
            m.password_hash, m.must_change_password, m.active = hash_password(password), not a.password, True
            await s.commit()
            print(f"login: {m.username}\npassword: {password}")
    await db.dispose()


async def create_admin(a) -> None:
    db = Database(get_settings().database_url)
    async with db.sessionmaker() as s:
        if (await s.execute(select(AgentMapping).where(func.lower(AgentMapping.username) == a.username.lower()))).scalars().first():
            print("username taken")
        else:
            password = a.password or secrets.token_urlsafe(9)
            m = AgentMapping(username=a.username.lower(), password_hash=hash_password(password), first_name=a.name,
                             display_name=a.name, role="admin", level="admin", enabled=False, must_change_password=not a.password)
            s.add(m)
            await s.flush()
            s.add(AgentState(agent_id=m.id))
            await s.commit()
            print(f"login: {m.username}\npassword: {password}")
    await db.dispose()


async def list_users(_) -> None:
    db = Database(get_settings().database_url)
    async with db.sessionmaker() as s:
        for m in (await s.execute(select(AgentMapping).order_by(AgentMapping.id))).scalars().all():
            print(f"{m.id:>3}  {m.username or '-':<16} {m.role:<10} {'active' if m.active else 'disabled':<8} "
                  f"ext={m.extension or '-':<6} zammad={m.zammad_user_id or '-':<5} {m.display_name}")
    await db.dispose()


def _password(a, confirm: bool = False) -> str:
    pw = a.password or os.environ.get("BACKUP_PASSWORD", "")
    if not pw and sys.stdin.isatty():
        pw = getpass.getpass("Backup password: ")
        if confirm and getpass.getpass("Repeat the password: ") != pw:
            raise SystemExit("passwords do not match")
    return pw


async def backup_now(a) -> None:
    from . import backup as bk  # noqa: PLC0415
    from .backup_service import app_version  # noqa: PLC0415
    from .settings_store import SettingsStore  # noqa: PLC0415
    cfg = get_settings()
    db = Database(cfg.database_url)
    try:
        store = SettingsStore(db, cfg)
        await store.load()  # the backup password and folder saved in the panel
        pw = _password(a, confirm=True) if (a.password or not cfg.backup_password) else cfg.backup_password
        folder = Path(a.dir or cfg.backup_dir or "backups").resolve()
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / bk.new_name("cli")
        res = await bk.dump(db, path, pw, master_key=cfg.jwt_secret, app_version=app_version(), kind="cli", created_by="cli")
        print(f"{path}\n{path.stat().st_size} bytes, {res.rows} rows")
    except bk.BackupError as exc:
        raise SystemExit(f"error: {exc.code}") from exc
    finally:
        await db.dispose()


async def restore_file(a) -> None:
    from . import backup as bk  # noqa: PLC0415
    from .backup_service import app_version  # noqa: PLC0415
    cfg = get_settings()
    path = Path(a.file)
    if not path.is_file():
        raise SystemExit(f"file not found: {path}")
    pw = _password(a)
    try:
        plan = bk.verify(path, pw, app_version=app_version())
    except bk.BackupError as exc:
        raise SystemExit(f"error: {exc.code}") from exc
    print(f"backup of {plan.header.get('created_at')} (Zenith Desk {plan.app_version}), {sum(plan.tables.values())} rows")
    if not a.yes:
        if input("ALL current data will be replaced. Type RESTORE to continue: ").strip() != "RESTORE":
            raise SystemExit("cancelled")
    db = Database(cfg.database_url)
    try:
        res = await bk.restore(db, path, pw, master_key=cfg.jwt_secret, app_version=app_version(), plan=plan)
    finally:
        await db.dispose()
    print(f"restored {res['rows']} rows" + (" (secrets re-encrypted for this server's key)" if res["rekeyed"] else ""))
    print("Start (or restart) Zenith Desk now:  docker compose up -d app")


async def list_backups(a) -> None:
    from . import backup as bk  # noqa: PLC0415
    folder = Path(a.dir or get_settings().backup_dir or "backups").resolve()
    for b in bk.list_files(folder):
        print(f"{b['name']:<58} {b.get('kind', ''):<12} {b['size']:>12}  {b.get('created_at', '')}")


def main() -> None:
    p = argparse.ArgumentParser(prog="python -m app.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("reset-password", help="set a new password (random if not given)")
    r.add_argument("username")
    r.add_argument("--password")
    r.set_defaults(fn=reset_password)
    c = sub.add_parser("create-admin", help="create an administrator")
    c.add_argument("--username", required=True)
    c.add_argument("--name", default="Administrator")
    c.add_argument("--password")
    c.set_defaults(fn=create_admin)
    sub.add_parser("list-users").set_defaults(fn=list_users)
    b = sub.add_parser("backup", help="write a backup of the whole system now")
    b.add_argument("--password", help="default: the backup password from the panel, BACKUP_PASSWORD or asked")
    b.add_argument("--dir", help="folder (default: BACKUP_DIR)")
    b.set_defaults(fn=backup_now)
    r2 = sub.add_parser("restore", help="restore the whole system from a backup file (stop the app first)")
    r2.add_argument("file")
    r2.add_argument("--password", help="default: BACKUP_PASSWORD or asked")
    r2.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    r2.set_defaults(fn=restore_file)
    ls = sub.add_parser("backups", help="list backup files")
    ls.add_argument("--dir")
    ls.set_defaults(fn=list_backups)
    args = p.parse_args()
    asyncio.run(args.fn(args))


if __name__ == "__main__":
    main()
