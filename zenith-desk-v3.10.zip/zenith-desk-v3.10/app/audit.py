from sqlalchemy.ext.asyncio import AsyncSession

from .models import AuditLog


def audit(
    s: AsyncSession,
    action: str,
    *,
    agent_id: int | None = None,
    ticket_id: int | None = None,
    actor_type: str = "system",
    actor_id: int | None = None,
    level: str = "info",
    **details,
) -> AuditLog:
    """Add an audit row to the current transaction (caller commits)."""
    row = AuditLog(
        action=action,
        agent_id=agent_id,
        ticket_id=ticket_id,
        actor_type=actor_type,
        actor_id=actor_id,
        level=level,
        details={k: v for k, v in details.items() if v is not None},
    )
    s.add(row)
    return row
