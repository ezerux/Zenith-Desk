"""v3.10 — backups for the administrator: on demand, by schedule, keep N copies, alert on failure, restore."""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

import httpx
from sqlalchemy import select

from . import backup as bk
from .audit import audit
from .db import utcnow
from .i18n import t as tr
from .models import AgentMapping, AuditLog

if TYPE_CHECKING:
    from .services import Services

log = logging.getLogger("backup")
WEEKDAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
RETRY_AFTER_FAILURE = timedelta(minutes=15)
KEEP_PRE_RESTORE = 3


def app_version() -> str:
    f = Path(__file__).parent.parent / "VERSION"
    return f.read_text().strip() if f.exists() else "dev"


def _tz(name: str):
    try:
        return ZoneInfo(name)
    except Exception:  # noqa: BLE001
        return timezone.utc


def last_slot(now: datetime, frequency: str, hhmm: str, weekday: str, tz_name: str) -> datetime:
    """The most recent moment (<= now) a scheduled backup should have run, in UTC."""
    tz = _tz(tz_name)
    local = now.astimezone(tz)
    try:
        hh, mm = (int(x) for x in hhmm.split(":"))
    except ValueError:
        hh, mm = 3, 0
    slot = local.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if frequency == "weekly":
        target = WEEKDAYS.index(weekday) if weekday in WEEKDAYS else 6
        slot -= timedelta(days=(slot.weekday() - target) % 7)
        if slot > local:
            slot -= timedelta(days=7)
    elif slot > local:
        slot -= timedelta(days=1)
    return slot.astimezone(timezone.utc)


def next_slot(now: datetime, frequency: str, hhmm: str, weekday: str, tz_name: str) -> datetime:
    last = last_slot(now, frequency, hhmm, weekday, tz_name).astimezone(_tz(tz_name))
    nxt = last + timedelta(days=7 if frequency == "weekly" else 1)
    # re-anchor on the wall clock (daylight saving time changes)
    return nxt.replace(tzinfo=None).replace(tzinfo=_tz(tz_name)).astimezone(timezone.utc)


class BackupService:
    def __init__(self, sv: Services):
        self.sv = sv
        self.lock = asyncio.Lock()
        self.busy: str = ""  # "", "backup", "restore", "verify"
        self.last_ok: dict | None = None
        self.last_error: dict | None = None
        self._failed_slot: datetime | None = None
        self._done_slot: datetime | None = None
        self._retry_at: datetime | None = None
        self._task: asyncio.Task | None = None
        self._wake = asyncio.Event()
        self.job: dict | None = None  # the last job started from the panel (runs in the background, the page polls)
        self._job_task: asyncio.Task | None = None

    # ------------------------------------------------------------------ folder
    @property
    def folder(self) -> Path:
        return Path(self.sv.settings.backup_dir or "backups").resolve()

    def ensure_folder(self) -> Path:
        f = self.folder
        f.mkdir(parents=True, exist_ok=True)
        return f

    def path(self, name: str) -> Path:
        p = self.folder / bk.safe_name(name)
        if not p.is_file():
            raise bk.BackupError("bk.not_found")
        return p

    def files(self) -> list[dict]:
        return bk.list_files(self.folder)

    # ------------------------------------------------------------------ state for the panel
    def view(self) -> dict:
        cfg = self.sv.settings
        now = utcnow()
        items = self.files()
        disk = None
        try:
            u = shutil.disk_usage(self.ensure_folder())
            disk = {"free": u.free, "total": u.total}
        except OSError:
            pass
        last_auto = next((b for b in items if b.get("kind") == "scheduled"), None)
        return {
            "folder": str(self.folder), "disk": disk, "busy": self.busy, "items": items,
            "total_size": sum(b.get("size", 0) for b in items),
            "enabled": cfg.backup_enabled, "has_password": bool(cfg.backup_password),
            "frequency": cfg.backup_frequency, "time": cfg.backup_time, "weekday": cfg.backup_weekday,
            "keep": cfg.backup_keep, "timezone": cfg.display_timezone,
            "next_run_at": next_slot(now, cfg.backup_frequency, cfg.backup_time, cfg.backup_weekday, cfg.display_timezone)
            if cfg.backup_enabled and cfg.backup_password else None,
            "last_auto": last_auto, "last_ok": next((b for b in items if b.get("kind") in ("manual", "scheduled", "cli") and b.get("ok")), None),
            "last_error": self.last_error,
            "version": app_version(),
        }

    # ------------------------------------------------------------------ create
    async def create(self, kind: str = "manual", by: AgentMapping | None = None, password: str | None = None,
                     note: str = "") -> dict:
        if self.lock.locked():
            raise bk.BackupError("bk.busy")
        async with self.lock:
            return await self._create(kind, by, password, note)

    async def _create(self, kind: str, by: AgentMapping | None, password: str | None, note: str = "") -> dict:
        password = password if password is not None else self.sv.settings.backup_password
        if not password:
            raise bk.BackupError("bk.no_password")
        folder = self.ensure_folder()
        self.busy = "backup"
        started = time.monotonic()
        try:
            path = folder / bk.new_name(kind)
            res = await bk.dump(self.sv.db, path, password, master_key=self.sv.settings.jwt_secret, app_version=app_version(),
                                kind=kind, created_by=(by.username if by else "system") or "", note=note)
        finally:
            self.busy = ""
        info = {"name": path.name, "size": path.stat().st_size, "rows": res.rows, "kind": kind,
                "created_at": res.header.get("created_at"), "seconds": round(time.monotonic() - started, 2)}
        async with self.sv.db.sessionmaker() as s:
            audit(s, "backup_created", actor_type="agent" if by else "system", actor_id=by.id if by else None,
                  name=path.name, size=info["size"], rows=res.rows, backup_kind=kind)
            await s.commit()
        self.last_ok = {**info, "at": utcnow().isoformat()}
        if kind == "scheduled":
            removed = bk.prune(folder, self.sv.settings.backup_keep, ("scheduled",))
            if removed:
                log.info("old backups deleted: %s", ", ".join(removed))
        if kind == "pre-restore":
            bk.prune(folder, KEEP_PRE_RESTORE, ("pre-restore",))
        log.info("backup %s written: %s bytes, %s rows, %.1f s", path.name, info["size"], res.rows, info["seconds"])
        return info

    def delete(self, name: str) -> None:
        self.path(name).unlink()

    # ------------------------------------------------------------------ upload / verify
    async def save_upload(self, filename: str, chunks) -> dict:
        folder = self.ensure_folder()
        base = Path(filename or "").name
        stem = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in base.rsplit(".", 1)[0])[:80].strip("-.") or "upload"
        name = f"{stem}{bk.SUFFIX}"
        if (folder / name).exists() or not bk.NAME_RE.match(name):
            name = bk.new_name("uploaded")
        part = folder / (name + ".part")
        size = 0
        try:
            with open(part, "wb") as f:
                async for chunk in chunks:
                    size += len(chunk)
                    f.write(chunk)
            bk.read_header(part)  # it must at least look like a Zenith Desk backup
            os.replace(part, folder / name)
        except BaseException:
            part.unlink(missing_ok=True)
            raise
        return {"name": name, "size": size}

    async def check_password(self, name: str, password: str) -> dict:
        return await asyncio.to_thread(bk.check_password, self.path(name), password)

    async def verify(self, name: str, password: str) -> dict:
        path = self.path(name)
        plan = await asyncio.to_thread(bk.verify, path, password, app_version=app_version())
        return {"ok": True, "app_version": plan.app_version, "created_at": plan.header.get("created_at"),
                "rows": sum(plan.tables.values()), "tables": plan.tables}

    # ------------------------------------------------------------------ restore
    async def restore(self, name: str, password: str, by: AgentMapping | None = None) -> dict:
        path = self.path(name)
        if self.lock.locked():
            raise bk.BackupError("bk.busy")
        async with self.lock:
            self.busy = "verify"
            try:  # the whole file is checked before anything is touched
                plan = await asyncio.to_thread(bk.verify, path, password, app_version=app_version())
            finally:
                self.busy = ""
            # a copy of what is there now, in case the wrong file was chosen
            safety = await self._create("pre-restore", by, password, note=name)  # the file that is being restored
            self.busy = "restore"
            log.warning("RESTORE of %s started by %s", name, by.username if by else "system")
            await self.sv.suspend()
            try:
                result = await bk.restore(self.sv.db, path, password, master_key=self.sv.settings.jwt_secret,
                                          app_version=app_version(), plan=plan)
            finally:
                try:
                    await self.sv.resume()
                finally:
                    self.busy = ""
            async with self.sv.db.sessionmaker() as s:
                audit(s, "backup_restored", level="warning", actor_type="agent" if by else "system",
                      actor_id=by.id if by else None, name=name, rows=result["rows"], safety_copy=safety["name"],
                      by=(by.username if by else "system"), rekeyed=result["rekeyed"])
                await s.commit()
            log.warning("RESTORE of %s finished: %s rows (re-encrypted: %s)", name, result["rows"], result["rekeyed"])
            result.update({"name": name, "safety_copy": safety["name"]})
            # every open browser reloads: the users, settings and data are the restored ones now
            self.sv.broker.publish_all("system_restored", {"name": name, "at": utcnow().isoformat()})
            asyncio.get_running_loop().call_later(0.5, self.sv.broker.close_streams)
            return result

    # ------------------------------------------------------------------ jobs started from the panel
    def start_job(self, kind: str, factory, **info) -> dict:
        """Run a long backup / restore in the background; the panel polls ``job``."""
        if self.lock.locked() or (self._job_task and not self._job_task.done()):
            raise bk.BackupError("bk.busy")
        job = {"id": f"{int(time.time() * 1000)}", "kind": kind, "state": "running", "started_at": utcnow().isoformat(), **info}
        self.job = job

        async def run() -> None:
            try:
                job["result"] = await factory()
                job["state"] = "done"
            except Exception as exc:  # noqa: BLE001
                job["state"] = "failed"
                job["error"] = tr(exc.code, **exc.params) if isinstance(exc, bk.BackupError) else (str(exc) or type(exc).__name__)
                if kind == "backup":
                    await self.failed(exc, "manual")
                elif not isinstance(exc, bk.BackupError):
                    log.exception("restore failed")
            finally:
                job["finished_at"] = utcnow().isoformat()

        self._job_task = asyncio.create_task(run(), name=f"backup-job-{kind}")
        return job

    async def wait_job(self) -> dict | None:
        if self._job_task:
            await asyncio.gather(self._job_task, return_exceptions=True)
        return self.job

    # ------------------------------------------------------------------ schedule
    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._loop(), name="backup-scheduler")

    async def stop(self) -> None:
        if self._job_task and not self._job_task.done():
            await asyncio.gather(self._job_task, return_exceptions=True)
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
            self._task = None

    def kick(self) -> None:
        self._wake.set()

    def due(self, now: datetime | None = None) -> datetime | None:
        """The slot a scheduled backup is due for, or None."""
        cfg = self.sv.settings
        if not cfg.backup_enabled or not cfg.backup_password:
            return None
        now = now or utcnow()
        slot = last_slot(now, cfg.backup_frequency, cfg.backup_time, cfg.backup_weekday, cfg.display_timezone)
        if self._done_slot is not None and self._done_slot >= slot:
            return None
        last = next((b for b in self.files() if b.get("kind") == "scheduled" and b.get("ok")), None)
        if last and last.get("created_at") and datetime.fromisoformat(last["created_at"]) >= slot:
            return None
        if self._failed_slot == slot and self._retry_at and now < self._retry_at:
            return None
        return slot

    async def run_due(self, now: datetime | None = None) -> dict | None:
        slot = self.due(now)
        if slot is None or self.lock.locked():
            return None
        try:
            info = await self.create("scheduled")
            self._failed_slot = self._retry_at = None
            self._done_slot = slot
            return info
        except Exception as exc:  # noqa: BLE001
            first = self._failed_slot != slot
            self._failed_slot, self._retry_at = slot, (now or utcnow()) + RETRY_AFTER_FAILURE
            await self.failed(exc, "scheduled", alert=first)
            return None

    async def failed(self, exc: Exception, kind: str, alert: bool = True) -> None:
        msg = tr(exc.code, **exc.params) if isinstance(exc, bk.BackupError) else (str(exc) or type(exc).__name__)
        log.error("backup failed (%s): %s", kind, msg, exc_info=not isinstance(exc, bk.BackupError))
        self.last_error = {"at": utcnow().isoformat(), "error": msg[:500], "kind": kind}
        if not alert:
            return
        try:
            async with self.sv.db.sessionmaker() as s:
                audit(s, "backup_failed", level="error", error=msg[:500], backup_kind=kind)
                admins = (await s.execute(select(AgentMapping.id).where(AgentMapping.role == "admin",
                                                                         AgentMapping.active.is_(True)))).scalars().all()
                await s.commit()
        except Exception:  # noqa: BLE001  (the database itself may be the problem)
            log.exception("cannot record the backup failure")
            admins = []
        text = tr("ntf.backup_failed", error=msg[:300])
        for a in admins:
            self.sv.broker.publish_agent(a, "alert", {"text": text, "ts": utcnow()})
            self.sv.push.notify_later(a, {"type": "alert", "title": tr("bk.push_title"), "body": text[:180], "url": "/#backup"})
        url = self.sv.settings.admin_alert_webhook_url
        if url:
            try:
                async with httpx.AsyncClient(timeout=5) as c:
                    await c.post(url, json={"text": text, "event": "backup_failed"})
            except httpx.HTTPError:
                log.warning("admin alert webhook failed")

    async def _loop(self) -> None:
        await asyncio.sleep(5)
        while True:
            try:
                await self.run_due()
            except Exception:  # noqa: BLE001
                log.exception("backup scheduler")
            self._wake.clear()
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=30)
            except asyncio.TimeoutError:
                pass

    async def last_failure_from_audit(self) -> dict | None:
        async with self.sv.db.sessionmaker() as s:
            row = (await s.execute(select(AuditLog).where(AuditLog.action == "backup_failed")
                                   .order_by(AuditLog.id.desc()).limit(1))).scalars().first()
        if row is None:
            return None
        return {"at": row.ts.isoformat() if row.ts else None, "error": (row.details or {}).get("error", "")}
