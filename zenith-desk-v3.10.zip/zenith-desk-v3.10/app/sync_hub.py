"""v3.9 Background synchronisation of every integration — one place that watches them all.

Each connected system has two channels:
* real time — Zammad webhooks, Asterisk AMI events, Telegram (webhook or long polling), WhatsApp webhooks, IMAP IDLE;
* fallback polling — every `sync_fallback_min` minutes the hub asks each connector to look for what the real-time
  channel may have lost (network failure, server restart, a webhook that never arrived) and to repair it.

The hub keeps the health of every connector (shown to the administrator in System status and in /api/health):
real-time connected or not, the last event, the last fallback check, how many lost items it recovered, the last error.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Awaitable, Callable

log = logging.getLogger("sync")

PollFn = Callable[[], Awaitable[int]]  # returns how many lost items were recovered


def _iso(ts: float | None) -> str | None:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat() if ts else None


@dataclass
class Health:
    name: str
    title: str
    enabled: bool = False
    realtime: str = "off"           # on | off | n/a (a channel without real time, e.g. POP3)
    realtime_detail: str = ""
    last_event: float | None = None
    events: int = 0
    last_poll: float | None = None
    last_poll_ms: int = 0
    last_recovered: int = 0
    recovered_total: int = 0
    polls: int = 0
    last_error: str = ""
    last_error_at: float | None = None
    backlog: int = 0                # waiting in the retry queue (events / commands / messages not yet done)
    poll: PollFn | None = field(default=None, repr=False)
    enabled_fn: Callable[[], bool] | None = field(default=None, repr=False)
    running: bool = False

    def view(self, interval_min: int) -> dict:
        ok = self.enabled and not (self.last_error and (self.last_error_at or 0) >= (self.last_poll or 0) and (self.last_error_at or 0) >= (self.last_event or 0))
        return {
            "name": self.name, "title": self.title, "enabled": self.enabled, "ok": ok if self.enabled else None,
            "realtime": self.realtime if self.enabled else "off", "realtime_detail": self.realtime_detail,
            "last_event_at": _iso(self.last_event), "events": self.events,
            "last_poll_at": _iso(self.last_poll), "last_poll_ms": self.last_poll_ms,
            "next_poll_at": _iso((self.last_poll or time.time()) + interval_min * 60) if self.enabled and interval_min else None,
            "last_recovered": self.last_recovered, "recovered_total": self.recovered_total, "polls": self.polls,
            "last_error": self.last_error, "last_error_at": _iso(self.last_error_at), "backlog": self.backlog,
        }


class SyncHub:
    ORDER = ["zammad", "asterisk", "telegram", "whatsapp", "mail"]

    def __init__(self, settings, broker=None):
        self.settings = settings
        self.broker = broker
        self.items: dict[str, Health] = {}
        self._task: asyncio.Task | None = None
        self._wake = asyncio.Event()

    def register(self, name: str, title: str, poll: PollFn | None, enabled: Callable[[], bool]) -> Health:
        h = self.items.get(name) or Health(name, title)
        h.title, h.poll, h.enabled_fn = title, poll, enabled
        h.enabled = bool(enabled())
        self.items[name] = h
        return h

    def get(self, name: str) -> Health:
        return self.items.setdefault(name, Health(name, name))

    # ---- reports from the connectors
    def event(self, name: str, n: int = 1) -> None:
        h = self.get(name)
        h.last_event, h.events = time.time(), h.events + n

    def realtime(self, name: str, on: bool | str, detail: str = "") -> None:
        h = self.get(name)
        state = on if isinstance(on, str) else ("on" if on else "off")
        changed = (h.realtime, h.realtime_detail) != (state, detail)
        h.realtime, h.realtime_detail = state, detail
        if changed:
            log.info("%s real time: %s %s", name, state, detail)

    def error(self, name: str, message: str) -> None:
        h = self.get(name)
        h.last_error, h.last_error_at = str(message)[:300], time.time()

    def clear_error(self, name: str) -> None:
        self.get(name).last_error = ""

    # ---- fallback polling
    @property
    def interval_min(self) -> int:
        return max(0, int(self.settings.sync_fallback_min or 0))

    async def poll(self, name: str) -> dict:
        h = self.items[name]
        h.enabled = bool(h.enabled_fn()) if h.enabled_fn else h.enabled
        if not h.enabled or h.poll is None or h.running:
            return h.view(self.interval_min)
        h.running = True
        t0 = time.monotonic()
        try:
            n = int(await asyncio.wait_for(h.poll(), timeout=240) or 0)
            h.last_recovered, h.recovered_total = n, h.recovered_total + n
            if n:
                log.warning("fallback check of %s recovered %s missed item(s)", name, n)
            h.last_error = ""
        except Exception as exc:  # noqa: BLE001
            log.warning("fallback check of %s failed: %s", name, exc)
            self.error(name, str(exc) or type(exc).__name__)
        finally:
            h.running = False
            h.last_poll, h.polls = time.time(), h.polls + 1
            h.last_poll_ms = int((time.monotonic() - t0) * 1000)
        return h.view(self.interval_min)

    async def poll_all(self) -> list[dict]:
        return list(await asyncio.gather(*(self.poll(n) for n in list(self.items))))

    def view(self) -> list[dict]:
        for h in self.items.values():
            if h.enabled_fn:
                h.enabled = bool(h.enabled_fn())
        names = sorted(self.items, key=lambda n: self.ORDER.index(n) if n in self.ORDER else 99)
        return [self.items[n].view(self.interval_min) for n in names]

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._loop(), name="sync-hub")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
            self._task = None

    def kick(self) -> None:
        self._wake.set()

    async def _loop(self) -> None:
        await asyncio.sleep(20)  # let the real-time channels connect first
        while True:
            minutes = self.interval_min
            if minutes:
                now = time.time()
                due = [n for n, h in self.items.items() if (h.last_poll or 0) + minutes * 60 <= now + 1]
                for n in due:
                    await self.poll(n)
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=30)
            except asyncio.TimeoutError:
                pass
            self._wake.clear()
