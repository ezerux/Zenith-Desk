import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

from .api import admin, admin_panel, agents, backup, auth_routes, chat, dashboard, mail, messengers, overview, phone, preferences, ticketing, tickets, webhooks
from .config import Settings, get_settings
from .i18n import get_language, set_language
from .security import SecurityHeaders
from .services import Services
from .workflow import WorkflowError

STATIC = Path(__file__).parent / "static"
VERSION_FILE = Path(__file__).parent.parent / "VERSION"
VERSION = VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "dev"


def create_app(settings: Settings | None = None, services: Services | None = None, *, background: bool = True) -> FastAPI:
    settings = settings or get_settings()
    set_language(settings.ui_language)
    logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)  # do not log every Zammad request

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if not settings.zammad_webhook_secret:
            logging.getLogger("app").warning("ZAMMAD_WEBHOOK_SECRET is empty: webhook signatures are NOT verified")
        if settings.jwt_secret.startswith("change-me"):
            logging.getLogger("app").warning("JWT_SECRET is the default value — set a random secret in .env")
        svc = services or Services(settings)
        app.state.services = svc
        await svc.start(background=background)
        try:
            yield
        finally:
            await svc.stop()

    app = FastAPI(
        title="Zenith Desk — Task & Agent State Service",
        version=VERSION,
        description="Unified operator workplace on top of Zammad + FreePBX/Asterisk: "
                    "blocking/background work modes, availability, queue pause sync, audit.",
        lifespan=lifespan,
    )

    @app.exception_handler(WorkflowError)
    async def wf_error(_: Request, exc: WorkflowError):
        return JSONResponse(status_code=exc.status, content={"detail": {"message": exc.message, **exc.details}})

    for r in (auth_routes.router, agents.router, dashboard.router, preferences.router, tickets.router, ticketing.router, ticketing.people, phone.router, chat.router, chat.push_router, admin.router, overview.router, admin_panel.router, webhooks.router,
              messengers.router, messengers.hooks, mail.router, backup.router):
        app.include_router(r)

    @app.get("/api/health", tags=["system"], summary="Health check")
    async def health(request: Request):
        svc: Services = request.app.state.services
        db_ok = True
        try:
            async with svc.db.sessionmaker() as s:
                await s.execute(text("SELECT 1"))
        except Exception:  # noqa: BLE001
            db_ok = False
        ami_ok = svc.pbx.connected
        status = 200 if db_ok else 503
        return JSONResponse(status_code=status, content={
            "status": "ok" if db_ok and ami_ok else "degraded",
            "version": VERSION,
            "database": db_ok,
            "ami_connected": ami_ok,
            "ami_last_error": getattr(svc.ami, "last_error", "") if svc.ami else "",
            "ami_event_backlog": svc._ami_events.qsize(),
            # v3.9: state of every connected system (details only for the administrator, in System status)
            "integrations": {i["name"]: ("off" if not i["enabled"] else "ok" if i["ok"] else "error") for i in svc.hub.view()},
        })

    @app.get("/api/desktop/hello", tags=["system"], summary="Desktop client (Windows): is this a Zenith Desk server, which version, HTTPS needed")
    async def desktop_hello(request: Request):
        svc: Services = request.app.state.services
        db_ok = True
        try:
            async with svc.db.sessionmaker() as s:
                await s.execute(text("SELECT 1"))
        except Exception:  # noqa: BLE001
            db_ok = False
        proto = request.headers.get("x-forwarded-proto", request.url.scheme).split(",")[0].strip()
        return {"product": "Zenith Desk", "version": VERSION, "language": get_language(), "database": db_ok,
                "https_required": bool(settings.force_https) and proto == "http" and request.url.hostname not in ("localhost", "127.0.0.1", "::1")}

    @app.get("/api/ui-language", tags=["system"], summary="Interface language (public, used by the login page)")
    async def ui_language():
        return {"language": get_language(), "version": VERSION}

    app.mount("/static", StaticFiles(directory=STATIC), name="static")

    @app.get("/", include_in_schema=False)
    async def index():
        return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})

    @app.get("/sw.js", include_in_schema=False)
    async def service_worker():  # served from the root so it may show notifications for the whole app (v3.1)
        return FileResponse(STATIC / "sw.js", media_type="text/javascript",
                            headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})

    def phone_origins() -> list[str]:  # v3.5: the browser phone talks to FreePBX over a secure WebSocket
        from urllib.parse import urlsplit
        cfg = settings  # the same object the admin panel updates at runtime
        u = urlsplit(cfg.phone_wss_url or "")
        return [f"{u.scheme}://{u.netloc}"] if cfg.phone_enabled and u.scheme in ("wss", "ws") and u.netloc else []

    app.add_middleware(SecurityHeaders, force_https=settings.force_https, connect_sources=phone_origins)

    return app



def get_app() -> FastAPI:  # uvicorn entrypoint: uvicorn app.main:get_app --factory
    return create_app()
