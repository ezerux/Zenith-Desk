"""Sign-in with a login and password created by the administrator. The service issues its own JWT.
Roles: operator / supervisor / admin (agent_mapping.role)."""
import hashlib
from datetime import timedelta

import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .db import utcnow
from .i18n import t as tr
from .models import AgentMapping
from .services import Services

bearer = HTTPBearer(auto_error=False)
ROLE_LEVEL = {"operator": 1, "supervisor": 2, "admin": 3}
# endpoints reachable while the user still has to change the password
PASSWORD_CHANGE_ALLOWED = {"/api/auth/me", "/api/auth/change-password", "/api/auth/logout", "/api/config"}


def get_services(request: Request) -> Services:
    return request.app.state.services


def password_version(agent: AgentMapping) -> str:
    """Changes whenever the password changes -> old sessions become invalid."""
    return hashlib.sha256((agent.password_hash or "").encode()).hexdigest()[:16]


def issue_token(services: Services, agent: AgentMapping) -> str:
    s = services.settings
    payload = {"sub": str(agent.id), "role": agent.role, "pv": password_version(agent),
               "exp": utcnow() + timedelta(hours=s.jwt_ttl_hours)}
    return jwt.encode(payload, s.jwt_secret, algorithm="HS256")


async def current_agent(
    request: Request,
    creds: HTTPAuthorizationCredentials | None = Depends(bearer),
    services: Services = Depends(get_services),
) -> AgentMapping:
    token = creds.credentials if creds else request.query_params.get("token")  # EventSource can't send headers
    if not token:
        raise HTTPException(401, tr("err.auth_required"))
    try:
        payload = jwt.decode(token, services.settings.jwt_secret, algorithms=["HS256"])
    except jwt.PyJWTError as exc:
        raise HTTPException(401, tr("err.session_expired")) from exc
    async with services.db.sessionmaker() as s:
        agent = await s.get(AgentMapping, int(payload["sub"]))
    if agent is None or not agent.active or payload.get("pv") != password_version(agent):
        raise HTTPException(401, tr("err.session_expired"))
    if agent.must_change_password and request.url.path not in PASSWORD_CHANGE_ALLOWED:
        raise HTTPException(403, tr("err.password_change_required"))
    return agent


def require_role(role: str):
    async def dep(agent: AgentMapping = Depends(current_agent)) -> AgentMapping:
        if ROLE_LEVEL.get(agent.role, 0) < ROLE_LEVEL[role]:
            raise HTTPException(403, tr("err.forbidden"))
        return agent
    return dep
