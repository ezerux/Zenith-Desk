"""v3.3 ticketing: read-only directory of Zammad customers and staff

Revision ID: 0010
Revises: 0009
Create Date: 2026-10-11
"""
import sqlalchemy as sa
from alembic import op


revision = '0010'
down_revision = '0009'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'zammad_user',
        sa.Column('id', sa.Integer(), autoincrement=False, nullable=False),
        sa.Column('login', sa.String(length=255), nullable=False),
        sa.Column('firstname', sa.String(length=150), nullable=False),
        sa.Column('lastname', sa.String(length=150), nullable=False),
        sa.Column('email', sa.String(length=255), nullable=False),
        sa.Column('phone', sa.String(length=100), nullable=False),
        sa.Column('mobile', sa.String(length=100), nullable=False),
        sa.Column('organization', sa.String(length=255), nullable=False),
        sa.Column('note', sa.Text(), nullable=False),
        sa.Column('active', sa.Boolean(), nullable=False),
        sa.Column('is_agent', sa.Boolean(), nullable=False),
        sa.Column('is_customer', sa.Boolean(), nullable=False),
        sa.Column('roles', sa.JSON(), nullable=False),
        sa.Column('groups', sa.JSON(), nullable=False),
        sa.Column('search_text', sa.Text(), nullable=False),
        sa.Column('z_created_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('z_updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('synced_at', sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_zammad_user_is_agent'), 'zammad_user', ['is_agent'], unique=False)
    op.create_index(op.f('ix_zammad_user_is_customer'), 'zammad_user', ['is_customer'], unique=False)
    op.create_index(op.f('ix_zammad_user_z_updated_at'), 'zammad_user', ['z_updated_at'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_zammad_user_z_updated_at'), table_name='zammad_user')
    op.drop_index(op.f('ix_zammad_user_is_customer'), table_name='zammad_user')
    op.drop_index(op.f('ix_zammad_user_is_agent'), table_name='zammad_user')
    op.drop_table('zammad_user')
