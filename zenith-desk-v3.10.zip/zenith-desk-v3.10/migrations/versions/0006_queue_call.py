"""queue_call: customer calls in ACD queues for the manager overview (v2.5)

Revision ID: 0006
Revises: 0005
Create Date: 2026-10-10
"""
import sqlalchemy as sa
from alembic import op


revision = '0006'
down_revision = '0005'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'queue_call',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('linkedid', sa.String(length=64), nullable=False),
        sa.Column('uniqueid', sa.String(length=64), nullable=False),
        sa.Column('queue', sa.String(length=40), nullable=False),
        sa.Column('caller_number', sa.String(length=64), nullable=False),
        sa.Column('caller_normalized', sa.String(length=32), nullable=False),
        sa.Column('caller_name', sa.String(length=200), nullable=False),
        sa.Column('outcome', sa.String(length=20), nullable=False),
        sa.Column('joined_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('answered_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('left_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('ended_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('agent_id', sa.Integer(), nullable=True),
        sa.Column('wait_sec', sa.Integer(), nullable=True),
        sa.Column('talk_sec', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['agent_id'], ['agent_mapping.id']),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('linkedid'),
    )
    op.create_index(op.f('ix_queue_call_caller_normalized'), 'queue_call', ['caller_normalized'], unique=False)
    op.create_index(op.f('ix_queue_call_joined_at'), 'queue_call', ['joined_at'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_queue_call_joined_at'), table_name='queue_call')
    op.drop_index(op.f('ix_queue_call_caller_normalized'), table_name='queue_call')
    op.drop_table('queue_call')
