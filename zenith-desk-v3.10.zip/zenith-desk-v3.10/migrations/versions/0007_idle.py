"""agent_state.last_activity_at / idle_since: pause after inactivity (v2.8)

Revision ID: 0007
Revises: 0006
Create Date: 2026-10-10
"""
import sqlalchemy as sa
from alembic import op


revision = '0007'
down_revision = '0006'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('agent_state', sa.Column('last_activity_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('agent_state', sa.Column('idle_since', sa.DateTime(timezone=True), nullable=True))


def downgrade() -> None:
    op.drop_column('agent_state', 'idle_since')
    op.drop_column('agent_state', 'last_activity_at')
