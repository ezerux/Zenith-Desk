"""messenger v3.1: edit/delete, reactions, web push subscriptions

Revision ID: 0009
Revises: 0008
Create Date: 2026-10-10
"""
import sqlalchemy as sa
from alembic import op


revision = '0009'
down_revision = '0008'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('chat_message', sa.Column('edited_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('chat_message', sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('chat_message', sa.Column('hidden_sender', sa.Boolean(), server_default=sa.text('false'), nullable=False))
    op.add_column('chat_message', sa.Column('hidden_recipient', sa.Boolean(), server_default=sa.text('false'), nullable=False))
    op.create_table(
        'chat_reaction',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('message_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('emoji', sa.String(length=16), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(['message_id'], ['chat_message.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['agent_mapping.id']),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('message_id', 'user_id', name='uq_reaction_message_user'),
    )
    op.create_index(op.f('ix_chat_reaction_message_id'), 'chat_reaction', ['message_id'], unique=False)
    op.create_table(
        'push_subscription',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('agent_id', sa.Integer(), nullable=False),
        sa.Column('endpoint', sa.String(length=1000), nullable=False),
        sa.Column('p256dh', sa.String(length=200), nullable=False),
        sa.Column('auth', sa.String(length=100), nullable=False),
        sa.Column('user_agent', sa.String(length=300), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('last_ok_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['agent_id'], ['agent_mapping.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('endpoint'),
    )
    op.create_index(op.f('ix_push_subscription_agent_id'), 'push_subscription', ['agent_id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_push_subscription_agent_id'), table_name='push_subscription')
    op.drop_table('push_subscription')
    op.drop_index(op.f('ix_chat_reaction_message_id'), table_name='chat_reaction')
    op.drop_table('chat_reaction')
    op.drop_column('chat_message', 'hidden_recipient')
    op.drop_column('chat_message', 'hidden_sender')
    op.drop_column('chat_message', 'deleted_at')
    op.drop_column('chat_message', 'edited_at')
