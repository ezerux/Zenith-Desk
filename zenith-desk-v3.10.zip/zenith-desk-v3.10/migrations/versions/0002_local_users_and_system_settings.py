"""local users (login/password set by the administrator) and system settings edited in the admin panel

Revision ID: 0002
Revises: 0001
Create Date: 2026-10-10
"""
from alembic import op
import sqlalchemy as sa


revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'system_setting',
        sa.Column('key', sa.String(length=100), nullable=False),
        sa.Column('value', sa.Text(), nullable=False),
        sa.Column('is_secret', sa.Boolean(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_by', sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint('key'),
    )
    op.add_column('agent_mapping', sa.Column('username', sa.String(length=100), nullable=True))
    op.add_column('agent_mapping', sa.Column('password_hash', sa.String(length=300), nullable=False, server_default=''))
    op.add_column('agent_mapping', sa.Column('first_name', sa.String(length=100), nullable=False, server_default=''))
    op.add_column('agent_mapping', sa.Column('last_name', sa.String(length=100), nullable=False, server_default=''))
    op.add_column('agent_mapping', sa.Column('position', sa.String(length=150), nullable=False, server_default=''))
    op.add_column('agent_mapping', sa.Column('active', sa.Boolean(), nullable=False, server_default=sa.true()))
    op.add_column('agent_mapping', sa.Column('must_change_password', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('agent_mapping', sa.Column('last_login_at', sa.DateTime(timezone=True), nullable=True))
    with op.batch_alter_table('agent_mapping') as batch:
        batch.alter_column('zammad_user_id', existing_type=sa.INTEGER(), nullable=True)
        batch.alter_column('password_hash', server_default=None)
        batch.alter_column('first_name', server_default=None)
        batch.alter_column('last_name', server_default=None)
        batch.alter_column('position', server_default=None)
        batch.alter_column('active', server_default=None)
        batch.alter_column('must_change_password', server_default=None)
        batch.create_unique_constraint('agent_mapping_username_key', ['username'])


def downgrade() -> None:
    with op.batch_alter_table('agent_mapping') as batch:
        batch.drop_constraint('agent_mapping_username_key', type_='unique')
        batch.alter_column('zammad_user_id', existing_type=sa.INTEGER(), nullable=False)
    for col in ('last_login_at', 'must_change_password', 'active', 'position', 'last_name', 'first_name',
                'password_hash', 'username'):
        op.drop_column('agent_mapping', col)
    op.drop_table('system_setting')
