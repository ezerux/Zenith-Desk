"""access role follows the level (Manager = supervisor rights, Administrator = admin)

Revision ID: 0005
Revises: 0004
Create Date: 2026-10-10
"""
from alembic import op


revision = '0005'
down_revision = '0004'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("UPDATE agent_mapping SET role = 'admin' WHERE level = 'admin'")
    op.execute("UPDATE agent_mapping SET role = 'supervisor' WHERE level = 'manager'")
    op.execute("UPDATE agent_mapping SET role = 'operator' WHERE level IN ('level1', 'level2', 'level3')")


def downgrade() -> None:
    pass
