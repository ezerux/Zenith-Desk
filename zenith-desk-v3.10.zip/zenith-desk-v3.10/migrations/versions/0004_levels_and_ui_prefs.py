"""user grade (level) and personal UI preferences (theme, dashboard layout)

Revision ID: 0004
Revises: 0003
Create Date: 2026-10-10
"""
from alembic import op
import sqlalchemy as sa


revision = '0004'
down_revision = '0003'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('agent_mapping', sa.Column('level', sa.String(length=20), nullable=False, server_default='level1'))
    op.add_column('agent_mapping', sa.Column('ui_prefs', sa.JSON(), nullable=True))
    op.execute("UPDATE agent_mapping SET level = 'admin' WHERE role = 'admin'")
    op.execute("UPDATE agent_mapping SET level = 'manager' WHERE role = 'supervisor'")
    with op.batch_alter_table('agent_mapping') as batch:
        batch.alter_column('level', server_default=None)


def downgrade() -> None:
    op.drop_column('agent_mapping', 'ui_prefs')
    op.drop_column('agent_mapping', 'level')
