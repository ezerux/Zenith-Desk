"""chat_message: internal messenger between employees (v3.0)

Revision ID: 0008
Revises: 0007
Create Date: 2026-10-10
"""
import sqlalchemy as sa
from alembic import op


revision = '0008'
down_revision = '0007'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'chat_message',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('sender_id', sa.Integer(), nullable=False),
        sa.Column('recipient_id', sa.Integer(), nullable=False),
        sa.Column('body', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('read_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['recipient_id'], ['agent_mapping.id']),
        sa.ForeignKeyConstraint(['sender_id'], ['agent_mapping.id']),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_chat_pair', 'chat_message', ['sender_id', 'recipient_id', 'id'], unique=False)
    op.create_index('ix_chat_unread', 'chat_message', ['recipient_id', 'read_at'], unique=False)


def downgrade() -> None:
    op.drop_index('ix_chat_unread', table_name='chat_message')
    op.drop_index('ix_chat_pair', table_name='chat_message')
    op.drop_table('chat_message')
