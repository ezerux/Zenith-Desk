"""v3.5 Zenith Phone: SIP login and encrypted SIP password per user

Revision ID: 0011
Revises: 0010
Create Date: 2026-10-11
"""
import sqlalchemy as sa
from alembic import op


revision = '0011'
down_revision = '0010'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('agent_mapping', sa.Column('sip_user', sa.String(length=100), server_default='', nullable=False))
    op.add_column('agent_mapping', sa.Column('sip_secret', sa.Text(), server_default='', nullable=False))


def downgrade() -> None:
    op.drop_column('agent_mapping', 'sip_secret')
    op.drop_column('agent_mapping', 'sip_user')
