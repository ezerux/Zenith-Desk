"""v3.7: Do not disturb flag of the operator

Revision ID: 0012
Revises: 0011
Create Date: 2026-10-11
"""
import sqlalchemy as sa
from alembic import op


revision = '0012'
down_revision = '0011'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('agent_state', sa.Column('dnd', sa.Boolean(), server_default=sa.text('false'), nullable=False))


def downgrade() -> None:
    op.drop_column('agent_state', 'dnd')
