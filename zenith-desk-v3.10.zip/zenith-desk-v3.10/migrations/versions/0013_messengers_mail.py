"""v3.9: messengers (Telegram, WhatsApp — one company number) and e-mail

Revision ID: 0013
Revises: 0012
Create Date: 2026-10-11
"""
import sqlalchemy as sa
from alembic import op


revision = '0013'
down_revision = '0012'
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        'msg_conversation',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('channel', sa.String(20), nullable=False),
        sa.Column('external_id', sa.String(100), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('handle', sa.String(255), nullable=False),
        sa.Column('phone', sa.String(50), nullable=False),
        sa.Column('zammad_customer_id', sa.Integer(), nullable=True),
        sa.Column('zammad_ticket_id', sa.Integer(), nullable=True),
        sa.Column('zammad_ticket_number', sa.String(50), nullable=False),
        sa.Column('assignee_id', sa.Integer(), sa.ForeignKey('agent_mapping.id'), nullable=True),
        sa.Column('status', sa.String(20), nullable=False),
        sa.Column('unread', sa.Integer(), nullable=False),
        sa.Column('last_text', sa.Text(), nullable=False),
        sa.Column('last_direction', sa.String(10), nullable=False),
        sa.Column('last_message_at', TS, nullable=False),
        sa.Column('last_inbound_at', TS, nullable=True),
        sa.Column('created_at', TS, nullable=False),
        sa.Column('closed_at', TS, nullable=True),
        sa.UniqueConstraint('channel', 'external_id', name='uq_msg_conv_channel_external'),
    )
    op.create_index('ix_msg_conversation_channel', 'msg_conversation', ['channel'])
    op.create_index('ix_msg_conversation_zammad_ticket_id', 'msg_conversation', ['zammad_ticket_id'])
    op.create_index('ix_msg_conversation_assignee_id', 'msg_conversation', ['assignee_id'])
    op.create_index('ix_msg_conversation_status', 'msg_conversation', ['status'])
    op.create_index('ix_msg_conversation_last_message_at', 'msg_conversation', ['last_message_at'])
    op.create_table(
        'msg_message',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('conversation_id', sa.Integer(), sa.ForeignKey('msg_conversation.id', ondelete='CASCADE'), nullable=False),
        sa.Column('channel', sa.String(20), nullable=False),
        sa.Column('direction', sa.String(10), nullable=False),
        sa.Column('external_id', sa.String(200), nullable=True),
        sa.Column('author_id', sa.Integer(), sa.ForeignKey('agent_mapping.id'), nullable=True),
        sa.Column('body', sa.Text(), nullable=False),
        sa.Column('files', sa.JSON(), nullable=False),
        sa.Column('kind', sa.String(20), nullable=False),
        sa.Column('status', sa.String(20), nullable=False),
        sa.Column('error', sa.String(500), nullable=False),
        sa.Column('attempts', sa.Integer(), nullable=False),
        sa.Column('next_try_at', TS, nullable=True),
        sa.Column('zammad_article_id', sa.Integer(), nullable=True),
        sa.Column('mirrored', sa.Boolean(), nullable=False),
        sa.Column('created_at', TS, nullable=False),
        sa.Column('sent_at', TS, nullable=True),
    )
    op.create_index('ix_msg_message_conv_id', 'msg_message', ['conversation_id', 'id'])
    op.create_index('ix_msg_message_next_try_at', 'msg_message', ['next_try_at'])
    op.create_index('ix_msg_message_mirrored', 'msg_message', ['mirrored'])
    op.create_index('uq_msg_message_external', 'msg_message', ['channel', 'external_id'], unique=True)
    op.create_table(
        'msg_file',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('key', sa.String(64), nullable=False, unique=True),
        sa.Column('conversation_id', sa.Integer(), sa.ForeignKey('msg_conversation.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('mime', sa.String(150), nullable=False),
        sa.Column('size', sa.Integer(), nullable=False),
        sa.Column('data', sa.LargeBinary(), nullable=False),
        sa.Column('created_at', TS, nullable=False),
    )
    op.create_index('ix_msg_file_conversation_id', 'msg_file', ['conversation_id'])
    op.create_table(
        'mail_account',
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('login', sa.String(255), nullable=False),
        sa.Column('secret', sa.Text(), nullable=False),
        sa.Column('status', sa.String(20), nullable=False),
        sa.Column('last_error', sa.String(500), nullable=False),
        sa.Column('uidvalidity', sa.Integer(), nullable=False),
        sa.Column('uidnext', sa.Integer(), nullable=False),
        sa.Column('unseen', sa.Integer(), nullable=False),
        sa.Column('last_check_at', TS, nullable=True),
        sa.Column('created_at', TS, nullable=False),
    )
    op.create_table(
        'mail_local',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('agent_id', sa.Integer(), sa.ForeignKey('agent_mapping.id', ondelete='CASCADE'), nullable=False),
        sa.Column('uidl', sa.String(255), nullable=False),
        sa.Column('folder', sa.String(30), nullable=False),
        sa.Column('raw', sa.Text(), nullable=False),
        sa.Column('sender', sa.String(500), nullable=False),
        sa.Column('recipients', sa.Text(), nullable=False),
        sa.Column('subject', sa.String(1000), nullable=False),
        sa.Column('snippet', sa.String(300), nullable=False),
        sa.Column('date', TS, nullable=False),
        sa.Column('size', sa.Integer(), nullable=False),
        sa.Column('seen', sa.Boolean(), nullable=False),
        sa.Column('flagged', sa.Boolean(), nullable=False),
        sa.Column('has_files', sa.Boolean(), nullable=False),
        sa.UniqueConstraint('agent_id', 'uidl', name='uq_mail_local_uidl'),
    )
    op.create_index('ix_mail_local_folder', 'mail_local', ['agent_id', 'folder', 'date'])


def downgrade() -> None:
    op.drop_table('mail_local')
    op.drop_table('mail_account')
    op.drop_table('msg_file')
    op.drop_table('msg_message')
    op.drop_table('msg_conversation')
