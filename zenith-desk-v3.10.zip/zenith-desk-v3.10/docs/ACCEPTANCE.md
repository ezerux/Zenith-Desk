# Zenith Desk — Протокол приёмочных сценариев

Автотесты запускаются командой `pytest`. Ручная проверка выполняется на тестовой очереди FreePBX и тестовом Zammad.
Состояние очереди проверяется командой `asterisk -rx "queue show <очередь>"`.

| № | Критерий ТЗ (раздел 11) | Автотест | Ручная проверка | Результат |
|---|---|---|---|---|
| 1 | При входящем вызове клиент находится по номеру и открывается его карточка, иначе предлагается создать клиента | `test_incoming_call_finds_customer`, `test_ticket_after_call_contains_call_data_and_starts` | Позвонить в очередь с номера известного клиента, затем с неизвестного | |
| 2 | После старта blocking-тикета вызовы из управляемых очередей не поступают (после подтверждения Asterisk) | `test_blocking_pauses_after_confirmation_background_does_not`, `test_unconfirmed_pause_is_not_reported_as_done`, `test_full_service_over_real_ami_protocol` | «Приступить», затем `queue show` показывает `paused`, тестовый звонок уходит другому оператору | |
| 3 | После старта background-тикета вызовы продолжают поступать | `test_blocking_pauses_after_confirmation_background_does_not` | «Фоновая задача», тестовый звонок поступает | |
| 4 | При двух blocking-тикетах завершение одного не возвращает в очередь | `test_two_blocking_complete_one_stays_paused` | Два «Приступить», одно «Завершить», `queue show` по-прежнему показывает `paused` | |
| 5 | Только background и нет перерыва — оператор доступен | `test_only_background_is_available` | | |
| 6 | Тикет из email, Telegram или WhatsApp можно начать в режиме blocking или background | `test_messenger_ticket_unassigned_gets_assigned` | Отправить сообщение в бот Telegram и письмо, затем «Приступить» и «Фоновая задача» | |
| 7 | Повтор webhook не создаёт дубликатов сессий | `test_webhook_signature_and_deduplication`, `test_repeated_ui_command_is_idempotent` | Повторить доставку webhook в Zammad (*Manage → Webhook → лог*) | |
| 8 | AMI недоступен — интерфейс показывает ошибку, после восстановления выполняется сверка | `test_ami_down_then_recovery`, `test_retry_with_backoff`, `test_never_unpause_when_state_unknown` | Закрыть порт 5038 межсетевым экраном, затем открыть | |
| 9 | После перезапуска состояние восстанавливается из БД и согласуется с Asterisk | `test_restart_restores_and_reconciles` | `docker compose restart app` при активной blocking-задаче, вручную снять паузу в Asterisk, проверить, что она вернулась | |
| 10 | Руководитель видит статус и причину занятости каждого оператора | `test_supervisor_sees_reasons_and_override_is_audited`, `test_level_decides_access_rights`, e2e | «Manager panel» под пользователем уровня Manager, фильтр Level 1/2/3 | |
| 11 | Ручной перерыв не снимается при закрытии тикета | `test_break_survives_ticket_completion` | | |
| 12 | Есть автотесты расчёта доступности и интеграционные тесты сценариев | `tests/test_availability.py`, `tests/test_acceptance.py`, `tests/test_ami.py` | `pytest`: 129 passed; `python -m scripts.release_check`: ALL CHECKS PASSED | |

## Дополнительные проверки

| Сценарий | Автотест |
|---|---|
| Ручное «Готов» не обходит blocking-задачу (FR-08) | `test_manual_ready_cannot_bypass_blocking` |
| Пауза с телефона (*46) не снимается сервисом | `test_external_pause_is_respected` |
| Тикет в «Ожидании клиента» превращает blocking в фоновую задачу (сверка без webhook) | `test_pending_state_in_zammad_turns_blocking_into_background` |
| Переназначение в Zammad снимает сессию прежнего оператора | `test_reassigned_in_zammad_cancels_session` |
| Обязательные поля типа тикета (FR-11) | `test_ticket_type_required_fields` |
| Постобработка (WRAP_UP) | `test_wrap_up` |
| Прямые звонки, пропущенные вызовы, отчёт по времени блокировки (FR-12) | `test_report_and_direct_calls` |
| Чужой тикет нельзя начать | `test_cannot_start_ticket_of_another_operator` |
| Права групп Zammad: тикет чужой группы недоступен оператору | `test_operator_cannot_start_ticket_outside_his_groups` |
| Вход: неверный пароль, неизвестный логин, пробелы в логине | `test_login_rejects_wrong_password_and_unknown_user` |
| Администратор создаёт пользователя, тот входит; оператор не видит админку | `test_admin_creates_user_who_can_sign_in`, e2e |
| Проверки уникальности логина, внутреннего номера, пользователя Zammad | `test_user_validation` |
| Отключение пользователя и сброс пароля с обязательной сменой | `test_disable_user_and_reset_password`, e2e |
| Нельзя отключить себя и последнего администратора | `test_last_admin_and_self_disable_are_protected` |
| Блокировка после 5 неудачных попыток входа | `test_login_lockout_after_failures` |
| Настройки в панели: шифрование секретов, применение без перезапуска | `test_settings_saved_encrypted_and_applied`, e2e |
| v3.3 Тикеты в Zenith Desk: списки, фильтры, поиск, страница тикета, заметка с файлом, ответ клиенту по e-mail / Telegram | `test_lists_filters_search_and_paging`, `test_ticket_page_conversation_and_reply_channels`, e2e |
| v3.3 Статус, приоритет, тема; закрытие с ответом завершает рабочую сессию | `test_state_priority_title_and_pending`, `test_close_with_reply_finishes_work_session`, e2e |
| v3.3 Передача коллеге: уведомление, проверка прав группы Zammad (отказ и откат), снятие с себя, смена группы | `test_transfer_to_colleague_notifies_and_respects_zammad_rights`, e2e |
| v3.3 Изменения в самом Zammad появляются в Zenith Desk сами; переназначение в Zammad — уведомление новому ответственному | `test_changes_made_in_zammad_reach_agentix`, e2e |
| v3.3 Новый тикет от имени оператора, по желанию «не назначен» | `test_create_ticket_in_operator_name_optionally_unassigned`, e2e |
| v3.3 Клиенты и пользователи Zammad: синхронизация, новые видны сразу, удалённые исчезают | `test_directory_full_and_incremental_sync`, e2e |
| v3.3 Права Zammad: чужой тикет недоступен, пользователь без связи с Zammad получает понятное сообщение | `test_zammad_permissions_and_unlinked_accounts` |
| Совместимость с REST API Zammad (по исходному коду Zammad 7.3) | `tests/test_zammad_contract.py` |
| v3.5 Zenith Phone: настройки, SIP-пароль зашифрован и виден только владельцу, CSP/микрофон, поиск, определение звонящего | `tests/test_softphone.py` |
| v3.5–3.6 Zenith Phone в браузере против SIP-сервера: регистрация (digest), исходящий, занято, R (повтор), голосовая почта, удержание, DTMF, входящий, две линии с автоудержанием, конференция, запись, перевод с консультацией и слепой, «Не беспокоить», автоответ, журнал и контакты, вторая вкладка, неверный пароль | `tests/e2e_phone.py` (Chromium + `tests/fake_sip.py`) |
| v3.5 Zenith Phone в демо: «Позвонить» из карточки клиента, входящий, ответ, завершение | e2e |
| Проверка подключения к Zammad и AMI, состояние системы | `test_connection_tests_and_system_status`, e2e |
| Типы тикетов в панели | `test_ticket_types_crud`, e2e |
| Первый администратор создаётся автоматически | `test_first_admin_is_created_on_empty_database` |
| Дашборд оператора: счётчики дня | `test_dashboard_numbers`, e2e |
| Центр уведомлений: вмешательство руководителя, пропущенные звонки, отметка «прочитано» | `test_notifications_flow`, e2e |
| Руководитель видит ошибки синхронизации всех операторов | `test_supervisor_sees_sync_errors_of_operators` |
| Назначение тикета по номеру руководителем | `test_supervisor_assigns_by_ticket_number`, e2e |
| Тёмная и светлая тема, запоминается в браузере | e2e |
| Дизайн «Command Center»: тёмный по умолчанию, панель иконок с подсказками, шрифты с сервера (без интернета) | `test_personal_preferences`, e2e |
| Уровень (Level) обязателен при создании и виден под именем | `test_level_is_required_and_shown_everywhere`, e2e |
| Личные настройки и раскладка хранятся в учётной записи, проверка данных | `test_personal_preferences`, e2e |
| Настройка рабочего места: перетаскивание, размеры, скрытие, сохранение после перезагрузки | e2e |
| Готовые раскладки и сброс по умолчанию | e2e |
| Уровень определяет права: Level 1–3 — оператор, Manager — панель руководителя, Administrator — администрирование | `test_level_decides_access_rights`, e2e |
| Фильтр команды по уровню в панели руководителя | e2e |
| Обзор руководителя: звонки, пропущенные, уровень сервиса, ASA, разговор, «не взял трубку», загрузка, вовлечённость, нагрузка по часам, «не перезвонили» (каждый показатель сверен с ручным расчётом) | `tests/test_overview.py`, e2e |
| Анимации: переходы между страницами, микро-интеракции, отключение в личных настройках и при «уменьшении движения» в системе | `test_personal_preferences`, e2e (все сценарии проходят с включёнными анимациями) |
| Live-режим: изменения сразу приходят в нужные экраны, откат транзакции ничего не отправляет, webhook Zammad обновляет списки тикетов, новый звонок появляется в «Обзоре» быстрее 2 с | `tests/test_live.py`, e2e |
| Пауза при бездействии: предупреждение, затемнение и «заморозка» экрана, оператор не в сети, руководитель видит «Отошёл», возврат к прежнему статусу; не срабатывает во время разговора | `tests/test_idle.py`, e2e |
| Адаптивность: от телефона 360 px до монитора 2560 px интерфейс занимает всю ширину, без горизонтальной прокрутки | e2e |
| Мессенджер: поиск, отправка, мгновенная доставка, счётчик непрочитанных, ✓✓, «печатает…», карточка, история сохраняется, переписка приватна | `tests/test_chat.py`, e2e |
| Мессенджер 3.1: список только с переписками, мгновенная пересортировка, реакции, редактирование, удаление у себя и у всех, шифрование в БД, Web Push (шифрование и подпись по стандарту), заголовки безопасности и HTTPS | `tests/test_chat_plus.py`, e2e |
| AMI-клиент: неверный пароль | `test_ami_wrong_password_never_connects` |
| v3.7 Zenith Phone: строка набора в верхней панели, полоса звонка под верхней панелью на всех страницах (ответ, удержание, DTMF, завершение, клик открывает телефон), «Не беспокоить» ставит оператора на паузу во всех очередях и отклоняет звонки, скрытие громкости и флагов, изменение размера за угол, вид окна (классический / компактный / боковая панель) | `test_dnd_pauses_queues_and_ready_clears_it`, `tests/e2e_phone.py`, e2e |


## v3.9: Telegram, WhatsApp, почта, синхронизация, записи

| Сценарий | Автотест | Ручная проверка на стенде |
|---|---|---|
| Telegram (long polling): входящее с фото, тикет и клиент в Zammad, ответ с файлом, заметка, закрытие | `test_telegram_long_polling_receive_answer_files_and_zammad_ticket`, e2e | Написать боту компании, ответить из Zenith Desk |
| Telegram webhook: секретный заголовок, потерянные обновления восстанавливает резервная проверка | `test_telegram_webhook_secret_and_fallback_recovers_missed_updates` | Режим webhook с внешним адресом |
| WhatsApp: подпись webhook, окно 24 ч и шаблоны, статусы ✓✓, повтор отправки | `test_whatsapp_webhook_signature_window_templates_statuses_retry`, e2e | Написать на номер компании, ответить; через 24 ч — только шаблон |
| Один номер / бот на организацию: «Взять», «Передать», чужой ответ запрещён | `test_assign_transfer_counts_and_admin_test`, e2e | Два оператора на одной переписке |
| Почта: вход только e-mail + пароль (сервер задан администратором), проверка администратора | `test_admin_probe_and_sign_in_with_only_email_and_password`, e2e | Вход сотрудника в свой ящик |
| Почта: отправка, чтение, ответ, вложения, папки, поиск, черновики | `test_send_read_reply_attachments_folders_search_drafts`, e2e | |
| Почта: опасный HTML очищается, внешние картинки по кнопке | `test_dangerous_html_is_cleaned_and_remote_images_blocked` | |
| Почта: новые письма сразу (IMAP IDLE, в тесте ≈ 0,5 с), резервная проверка находит пропущенное | `test_idle_real_time_and_fallback_recovers_missed_mail`, e2e | |
| Почта: режим POP3 | `test_pop3_mode_downloads_and_keeps_local_folders` | |
| Тикет из письма | `test_ticket_from_email`, e2e | |
| Запись разговора: только оператор звонка и руководитель, аудит, защита пути | `test_recording_only_for_the_operator_of_the_call_and_managers`, real Asterisk e2e | Прослушать запись из «Последних звонков» |
| Сроки хранения данных | `test_retention_removes_only_old_data` | |
| Панель Sync, `/api/health` → `integrations`, очередь повторов | `test_health_and_sync_view_show_every_integration`, `test_sync_panel_shows_retry_backlog`, e2e | *Integrations → Sync* |
| Тикет на каждый принятый звонок (настройка) | `test_ticket_for_every_answered_call_when_enabled` | |

Почтовые тесты работают с **настоящими** Dovecot 2.3 и Postfix 3.8 (`tests/realstack/mailserver.sh`).

## v3.9: проверка на настоящем Asterisk 20

`tests/realstack/asterisk.sh start && python tests/realstack/asterisk_e2e.py` — Asterisk 20.6 с конфигурацией в стиле
FreePBX (очереди 400/401, участники `Local/1XX@from-queue/n`, PJSIP по WebSocket, AMI-пользователь с правами из
INSTALL.md). Проверяется: вход AMI и панель Sync; регистрация WebRTC-телефона из Chromium; пауза в обеих очередях
при blocking-тикете; **перезапуск Asterisk** — сервис переподключается и восстанавливает паузу; Ready и DND;
звонок клиента в очередь 400 — звонит в полосе звонка с именем клиента, ответ, история, отбой, запись
воспроизводится оператору (другому — 403); исходящий звонок на эхо-тест. Входит в `scripts/release_check.py`.

Подпись заказчика: ____________________   Дата: ____________
