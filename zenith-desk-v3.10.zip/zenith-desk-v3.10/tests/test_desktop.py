"""v3.8 Windows desktop client: the installer's "Test connection" asks the server who it is."""


async def test_desktop_hello_identifies_the_server(env):
    r = await env.client.get("/api/desktop/hello")
    assert r.status_code == 200
    body = r.json()
    assert body["product"] == "Zenith Desk" and body["version"] and body["database"] is True
    assert body["https_required"] is False and body["language"] in ("en", "ru")


async def test_desktop_hello_says_https_is_required_instead_of_redirecting(tmp_path):
    from .conftest import build_env
    env = await build_env(tmp_path, force_https=True)
    try:
        r = await env.client.get("http://10.0.0.5:8000/api/desktop/hello")
        assert r.status_code == 200 and r.json()["https_required"] is True
        r = await env.client.get("http://10.0.0.5:8000/", follow_redirects=False)
        assert r.status_code == 308  # everything else still goes to HTTPS
    finally:
        await env.client.aclose()
        await env.services.db.dispose()
