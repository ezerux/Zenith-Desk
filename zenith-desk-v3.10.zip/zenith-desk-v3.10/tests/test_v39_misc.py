"""v3.9: protected call recordings, data retention, integrations health."""
from datetime import timedelta

from sqlalchemy import func, select

from app.db import utcnow
from app.models import AuditLog, CallRecord, ChatMessage, MsgConversation, MsgMessage


async def test_recording_only_for_the_operator_of_the_call_and_managers(env, tmp_path):
    rec_dir = tmp_path / "monitor" / "2026" / "10" / "11"
    rec_dir.mkdir(parents=True)
    (rec_dir / "q400-101-1700.1.wav").write_bytes(b"RIFF....WAVEfmt fake audio")
    (tmp_path / "secret.txt").write_text("not a recording")
    env.settings.recording_dir = str(tmp_path / "monitor")
    async with env.services.db.sessionmaker() as s:
        c = CallRecord(linkedid="1700.1", agent_id=1, caller_number="89123456789", state="ended", recording_file="q400-101-1700.1.wav")
        bad = CallRecord(linkedid="1700.2", agent_id=1, caller_number="1", state="ended", recording_file="../../secret.txt")
        s.add_all([c, bad])
        await s.commit()
        cid, bad_id = c.id, bad.id
    assert env.services.calls.recording_url(c) == f"/api/calls/{cid}/recording"
    ha, hb, hboss = await env.login("anna"), await env.login("boris"), await env.login("boss")
    r = await env.client.get(f"/api/calls/{cid}/recording", headers=ha)
    assert r.status_code == 200 and r.content.startswith(b"RIFF") and r.headers["content-type"] == "audio/wav"
    assert (await env.client.get(f"/api/calls/{cid}/recording", headers=hb)).status_code == 403
    assert (await env.client.get(f"/api/calls/{cid}/recording", headers=hboss)).status_code == 200
    assert (await env.client.get(f"/api/calls/{cid}/recording")).status_code == 401
    assert (await env.client.get(f"/api/calls/{bad_id}/recording", headers=ha)).status_code == 404  # outside the folder
    async with env.services.db.sessionmaker() as s:
        played = (await s.execute(select(func.count()).select_from(AuditLog).where(AuditLog.action == "recording_played"))).scalar()
        denied = (await s.execute(select(func.count()).select_from(AuditLog).where(AuditLog.action == "recording_denied"))).scalar()
    assert played == 2 and denied == 1


async def test_retention_removes_only_old_data(env):
    old = utcnow() - timedelta(days=40)
    async with env.services.db.sessionmaker() as s:
        s.add_all([AuditLog(action="old", ts=old), AuditLog(action="new")])
        s.add_all([CallRecord(linkedid="o", started_at=old), CallRecord(linkedid="n")])
        s.add_all([ChatMessage(sender_id=1, recipient_id=2, body="old", created_at=old), ChatMessage(sender_id=1, recipient_id=2, body="new")])
        conv = MsgConversation(channel="telegram", external_id="1", name="x", handle="", phone="", zammad_ticket_number="", status="closed",
                               unread=0, last_text="", last_direction="in", last_message_at=old)
        s.add(conv)
        await s.flush()
        s.add(MsgMessage(conversation_id=conv.id, channel="telegram", direction="in", body="", files=[], kind="text", status="received",
                         error="", attempts=0, mirrored=True, created_at=old))
        await s.commit()
    assert await env.services.retention_cleanup() == {}  # nothing configured → nothing deleted
    env.settings.retention_audit_days = env.settings.retention_calls_days = env.settings.retention_messages_days = 30
    done = await env.services.retention_cleanup()
    assert done["audit"] == 1 and done["calls"] == 1 and done["chat"] == 1 and done["messenger"] == 1 and done["conversations"] == 1
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(func.count()).select_from(CallRecord))).scalar() == 1
        assert (await s.execute(select(AuditLog.action).where(AuditLog.action == "new"))).scalar() == "new"
        assert (await s.execute(select(func.count()).select_from(MsgConversation))).scalar() == 0


async def test_health_and_sync_view_show_every_integration(env):
    from tests.test_messengers import _admin
    ha = await _admin(env)
    sys_ = (await env.client.get("/api/admin/system", headers=ha)).json()
    names = [i["name"] for i in sys_["integrations"]]
    assert names == ["zammad", "asterisk", "telegram", "whatsapp", "mail"] and sys_["sync_interval_min"] == 5
    tg = next(i for i in sys_["integrations"] if i["name"] == "telegram")
    assert tg["enabled"] is False and tg["ok"] is None
    r = (await env.client.post("/api/admin/sync/asterisk/poll", headers=ha)).json()
    ast = next(i for i in r["items"] if i["name"] == "asterisk")
    assert ast["polls"] == 1 and ast["last_poll_at"] and ast["realtime"] == "on" and ast["last_error"] == "" and ast["ok"] is True
    assert (await env.client.post("/api/admin/sync/nope/poll", headers=ha)).status_code == 404
    h = await env.login("anna")
    assert (await env.client.get("/api/admin/sync", headers=h)).status_code == 403


async def test_presence_work_survives_a_cancelled_sse_request(env):
    """The browser closing the event stream cancels its request; the mail IDLE start/stop must still run, never spin."""
    import asyncio
    done = []

    async def slow_presence(agent_id, connections):
        await asyncio.sleep(0.2)
        done.append((agent_id, connections))
    env.services.mail.presence = slow_presence
    caller = asyncio.create_task(env.services._on_presence(1, 0))
    await asyncio.sleep(0)
    caller.cancel()
    await asyncio.sleep(0.4)
    assert done == [(1, 0)]


async def test_ticket_for_every_answered_call_when_enabled(env):
    """ТЗ 15 open question: 'ticket for every call or only by the button' is a setting (default: the button)."""
    import asyncio
    from app.models import CallRecord
    IF1 = "Local/101@from-queue/n"
    env.zammad.add_user(70, "aram", firstname="Aram", lastname="Grigoryan", phone="+374 91 123456", roles=["Customer"])

    async def call(linkedid: str, number: str, answer: bool = True):
        h = env.services.calls.handle_event
        await h({"Event": "AgentCalled", "Queue": "400", "Interface": IF1, "CallerIDNum": number, "Uniqueid": linkedid, "Linkedid": linkedid})
        if answer:
            await h({"Event": "AgentConnect", "Queue": "400", "Interface": IF1, "Uniqueid": linkedid, "Linkedid": linkedid})
        await h({"Event": "Hangup", "Uniqueid": linkedid, "Linkedid": linkedid})
        for _ in range(50):
            await asyncio.sleep(0.02)
        async with env.services.db.sessionmaker() as s:
            return (await s.execute(select(CallRecord).where(CallRecord.linkedid == linkedid))).scalars().first()

    before = len(env.zammad.tickets)
    assert (await call("off.1", "+37491123456")).ticket_id is None  # default: only by the operator's button
    env.settings.call_auto_ticket = "answered"
    rec = await call("on.1", "+37491123456")
    assert rec.ticket_id and len(env.zammad.tickets) == before + 1
    t = env.zammad.tickets[rec.ticket_id]
    assert t["customer_id"] == 70 and t["owner_id"] == 10 and t["title"] == "Call from +37491123456"
    assert (await call("on.2", "+37455000111", answer=False)).ticket_id is None  # missed calls: no ticket
    unknown = await call("on.3", "+37455000222")  # a new caller becomes a Zammad customer
    assert unknown.ticket_id and any(u.get("mobile") == "+37455000222" for u in env.zammad.users.values())


async def test_sync_panel_shows_retry_backlog(env):
    from app.db import utcnow
    from app.models import IntegrationEvent, MsgConversation, MsgMessage
    from tests.test_messengers import _admin
    async with env.services.db.sessionmaker() as s:
        s.add(IntegrationEvent(source="zammad", external_event_id="x1", payload={}, status="retry"))
        conv = MsgConversation(channel="whatsapp", external_id="374", name="x", handle="", phone="", zammad_ticket_number="", status="open",
                               unread=0, last_text="", last_direction="out", last_message_at=utcnow())
        s.add(conv)
        await s.flush()
        s.add(MsgMessage(conversation_id=conv.id, channel="whatsapp", direction="out", body="", files=[], kind="text", status="queued",
                         error="", attempts=1, mirrored=True, created_at=utcnow()))
        await s.commit()
    items = {i["name"]: i for i in (await env.client.get("/api/admin/sync", headers=await _admin(env))).json()["items"]}
    assert items["zammad"]["backlog"] == 1 and items["whatsapp"]["backlog"] == 1 and items["telegram"]["backlog"] == 0
