"""Messenger v3.1: chat list, reactions, edit/delete, encryption at rest, Web Push, security headers."""
import asyncio
import base64
import hashlib
import hmac
import json
import struct

import httpx
import jwt
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from sqlalchemy import select

from app.models import ChatMessage, PushSubscription
from app.webpush import WebPush, b64u, b64u_dec


async def send(env, h, to, text):
    r = await env.client.post(f"/api/chat/{to}/messages", json={"body": text}, headers=h)
    assert r.status_code == 200, r.text
    return r.json()


def spy(env):
    events = []
    orig = env.services.broker.publish_agent
    env.services.broker.publish_agent = lambda aid, ev, data: (events.append((aid, ev, data)), orig(aid, ev, data))
    return events


@pytest.mark.asyncio
async def test_list_shows_only_conversations_search_finds_everyone(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    assert (await env.client.get("/api/chat/contacts", headers=anna)).json()["contacts"] == []
    found = (await env.client.get("/api/chat/contacts?q=бор", headers=anna)).json()["contacts"]
    assert [c["id"] for c in found] == [2] and found[0]["last"] is None          # Boris, no chat yet
    await send(env, boss, 1, "hello")
    assert [c["id"] for c in (await env.client.get("/api/chat/contacts", headers=anna)).json()["contacts"]] == [3]
    boris = await env.login("boris")
    await send(env, boris, 1, "newer")
    assert [c["id"] for c in (await env.client.get("/api/chat/contacts", headers=anna)).json()["contacts"]] == [2, 3]


@pytest.mark.asyncio
async def test_messages_are_encrypted_at_rest(env):
    boss = await env.login("boss")
    await send(env, boss, 1, "secret plan for Monday")
    async with env.services.db.sessionmaker() as s:
        raw = (await s.execute(select(ChatMessage.body))).scalar_one()
    assert raw.startswith("v1:") and "secret" not in raw
    anna = await env.login("anna")
    assert (await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"][0]["body"] == "secret plan for Monday"
    # rows written before v3.1 (plain text) are encrypted once at start-up
    async with env.services.db.sessionmaker() as s:
        s.add(ChatMessage(sender_id=1, recipient_id=3, body="old plain text"))
        await s.commit()
    assert await env.services.encrypt_old_messages() == 1
    async with env.services.db.sessionmaker() as s:
        assert all(b.startswith("v1:") for b in (await s.execute(select(ChatMessage.body))).scalars())
    assert (await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"][1]["body"] == "old plain text"


@pytest.mark.asyncio
async def test_reactions_one_per_person_toggle_and_live(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    m = await send(env, boss, 1, "great job")
    ev = spy(env)
    r = (await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "❤️"}, headers=anna)).json()
    assert r["reactions"] == [{"emoji": "❤️", "users": [1]}]
    assert {(a, e) for a, e, _ in ev} >= {(1, "chat_update"), (3, "chat_update")}   # both sides live
    await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "👍"}, headers=boss)
    r = (await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "😂"}, headers=anna)).json()
    assert sorted((x["emoji"], tuple(x["users"])) for x in r["reactions"]) == [("👍", (3,)), ("😂", (1,))]  # replaced, not added
    r = (await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "😂"}, headers=anna)).json()
    assert r["reactions"] == [{"emoji": "👍", "users": [3]}]                                        # same emoji = remove
    assert (await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "💩"}, headers=anna)).status_code == 422
    boris = await env.login("boris")
    assert (await env.client.post(f"/api/chat/messages/{m['id']}/react", json={"emoji": "❤️"}, headers=boris)).status_code == 404
    msgs = (await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"]
    assert msgs[0]["reactions"] == [{"emoji": "👍", "users": [3]}]


@pytest.mark.asyncio
async def test_edit_own_message(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    m = await send(env, boss, 1, "meeting at 15:00")
    ev = spy(env)
    r = await env.client.patch(f"/api/chat/messages/{m['id']}", json={"body": "meeting at 16:00"}, headers=boss)
    assert r.status_code == 200 and r.json()["edited_at"] and r.json()["body"] == "meeting at 16:00"
    assert (1, "chat_update") in [(a, e) for a, e, _ in ev]
    assert (await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"][0]["body"] == "meeting at 16:00"
    assert (await env.client.patch(f"/api/chat/messages/{m['id']}", json={"body": "hack"}, headers=anna)).status_code == 403
    async with env.services.db.sessionmaker() as s:   # older than 48 h -> no more edits
        row = await s.get(ChatMessage, m["id"])
        from datetime import timedelta
        row.created_at = row.created_at - timedelta(hours=49)
        await s.commit()
    assert (await env.client.patch(f"/api/chat/messages/{m['id']}", json={"body": "late"}, headers=boss)).status_code == 409


@pytest.mark.asyncio
async def test_delete_for_me_and_for_everyone(env):
    anna, boss = await env.login("anna"), await env.login("boss")
    m1 = await send(env, boss, 1, "first")
    m2 = await send(env, boss, 1, "oops, wrong chat")
    assert (await env.client.get("/api/chat/unread", headers=anna)).json()["unread"] == 2
    # Anna hides "first" only for herself
    assert (await env.client.delete(f"/api/chat/messages/{m1['id']}?scope=me", headers=anna)).status_code == 200
    assert [m["body"] for m in (await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"]] == ["oops, wrong chat"]
    assert len((await env.client.get("/api/chat/1/messages", headers=boss)).json()["messages"]) == 2
    # Anna may not delete the manager's message for everyone
    assert (await env.client.delete(f"/api/chat/messages/{m2['id']}?scope=all", headers=anna)).status_code == 403
    ev = spy(env)
    assert (await env.client.delete(f"/api/chat/messages/{m2['id']}?scope=all", headers=boss)).status_code == 200
    assert (1, "chat_update") in [(a, e) for a, e, _ in ev]                       # disappears on Anna's screen live
    assert (await env.client.get("/api/chat/3/messages", headers=anna)).json()["messages"] == []
    assert (await env.client.get("/api/chat/unread", headers=anna)).json()["unread"] == 0
    async with env.services.db.sessionmaker() as s:                                # the text is really gone
        row = await s.get(ChatMessage, m2["id"])
        assert env.services.cipher.open(row.body) == ""


# ------------------------------------------------------------------ Web Push
def decrypt_like_a_browser(body: bytes, ua_key: ec.EllipticCurvePrivateKey, auth: bytes) -> bytes:
    """RFC 8291 receiver side — what Chrome/Firefox/Safari do with the push message."""
    salt, rs, idlen = body[:16], struct.unpack("!L", body[16:20])[0], body[20]
    as_public, ciphertext = body[21:21 + idlen], body[21 + idlen:]
    ua_public = ua_key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    secret = ua_key.exchange(ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), as_public))
    prk_key = hmac.new(auth, secret, hashlib.sha256).digest()
    ikm = hmac.new(prk_key, b"WebPush: info\x00" + ua_public + as_public + b"\x01", hashlib.sha256).digest()
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    cek = hmac.new(prk, b"Content-Encoding: aes128gcm\x00\x01", hashlib.sha256).digest()[:16]
    nonce = hmac.new(prk, b"Content-Encoding: nonce\x00\x01", hashlib.sha256).digest()[:12]
    plain = AESGCM(cek).decrypt(nonce, ciphertext, None)
    assert rs == 4096 and plain.endswith(b"\x02")
    return plain[:-1]


@pytest.mark.asyncio
async def test_web_push_is_encrypted_and_signed(env):
    captured = []

    def handler(request: httpx.Request):
        captured.append(request)
        return httpx.Response(201 if "good" in str(request.url) else 410)

    env.services.push = WebPush(env.services.db, env.services.store.box, transport=httpx.MockTransport(handler))
    ua_key = ec.generate_private_key(ec.SECP256R1())
    p256dh = b64u(ua_key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint))
    auth = b"0123456789abcdef"
    anna, boss = await env.login("anna"), await env.login("boss")
    key = (await env.client.get("/api/push/key", headers=anna)).json()["key"]
    assert len(b64u_dec(key)) == 65
    for ep in ("https://push.example/good", "https://push.example/expired"):
        r = await env.client.post("/api/push/subscribe", headers=anna,
                                  json={"endpoint": ep, "keys": {"p256dh": p256dh, "auth": b64u(auth)}})
        assert r.status_code == 200
    assert (await env.client.get("/api/push/status", headers=anna)).json() == {"subscriptions": 2}
    assert (await env.client.post("/api/push/subscribe", headers=anna,
                                  json={"endpoint": "http://insecure", "keys": {"p256dh": "x", "auth": "y"}})).status_code == 422
    # Anna has no Zenith Desk window open -> the manager's message goes out as a push
    await send(env, boss, 1, "Please call the customer back")
    for _ in range(50):
        if len(captured) >= 2:
            break
        await asyncio.sleep(0.02)
    good = next(r for r in captured if "good" in str(r.url))
    assert good.headers["content-encoding"] == "aes128gcm" and good.headers["ttl"]
    data = json.loads(decrypt_like_a_browser(good.content, ua_key, auth))
    assert data == {"type": "chat", "title": "Руководитель", "body": "Please call the customer back", "from": 3, "id": data["id"]}
    token = good.headers["authorization"].split("t=")[1].split(",")[0]
    pub = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), b64u_dec(key))
    claims = jwt.decode(token, pub, algorithms=["ES256"], audience="https://push.example")
    assert claims["sub"].startswith("mailto:")
    await asyncio.sleep(0.05)
    async with env.services.db.sessionmaker() as s:   # the push service said "gone" -> forgotten
        eps = (await s.execute(select(PushSubscription.endpoint))).scalars().all()
    assert eps == ["https://push.example/good"]


@pytest.mark.asyncio
async def test_no_push_while_agentix_is_open(env):
    sent = []

    async def fake_notify(agent_id, data):
        sent.append(agent_id)
    env.services.push.notify = fake_notify
    anna, boss = await env.login("anna"), await env.login("boss")
    env.services.broker._agent_subs[1].add(asyncio.Queue())     # Anna has a window open
    await send(env, boss, 1, "hi")
    await asyncio.sleep(0.05)
    assert sent == []


# ------------------------------------------------------------------ transport security
@pytest.mark.asyncio
async def test_security_headers_and_https(env, tmp_path):
    r = await env.client.get("/")
    assert r.headers["x-content-type-options"] == "nosniff" and r.headers["x-frame-options"] == "DENY"
    assert "default-src 'self'" in r.headers["content-security-policy"] and "frame-ancestors 'none'" in r.headers["content-security-policy"]
    assert "strict-transport-security" not in r.headers
    r = await env.client.get("/api/ui-language", headers={"X-Forwarded-Proto": "https"})
    assert r.headers["strict-transport-security"].startswith("max-age=31536000")
    sw = await env.client.get("/sw.js")
    assert sw.status_code == 200 and sw.headers["service-worker-allowed"] == "/" and "javascript" in sw.headers["content-type"]
    from app.security import SecurityHeaders

    async def ok(scope, receive, send_):
        await send_({"type": "http.response.start", "status": 200, "headers": []})
        await send_({"type": "http.response.body", "body": b"ok"})
    forced = httpx.AsyncClient(transport=httpx.ASGITransport(app=SecurityHeaders(ok, force_https=True)), base_url="http://ops.company.ru")
    r = await forced.get("/x?y=1", headers={"X-Forwarded-Proto": "http"})
    assert r.status_code == 308 and r.headers["location"] == "https://ops.company.ru/x?y=1"
    assert (await forced.get("/x", headers={"X-Forwarded-Proto": "https"})).status_code == 200
