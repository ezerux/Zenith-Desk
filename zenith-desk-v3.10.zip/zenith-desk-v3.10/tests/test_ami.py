"""AMI client + AmiPbx against a tiny fake Asterisk Manager server speaking the real wire protocol."""
import asyncio

from app.ami import AMIClient, parse_message
from app.pbx import AmiPbx

IFACE = "Local/101@from-queue/n"


class FakeAsterisk:
    def __init__(self):
        self.paused = {"400": False, "401": False}
        self.actions: list[dict] = []
        self.server = None

    async def start(self) -> int:
        self.server = await asyncio.start_server(self.handle, "127.0.0.1", 0)
        return self.server.sockets[0].getsockname()[1]

    async def handle(self, reader, writer):
        writer.write(b"Asterisk Call Manager/7.0.3\r\n")
        buf = ""
        while True:
            data = await reader.read(4096)
            if not data:
                break
            buf += data.decode()
            while "\r\n\r\n" in buf:
                raw, buf = buf.split("\r\n\r\n", 1)
                msg = parse_message(raw)
                self.actions.append(msg)
                writer.write(self.respond(msg))
                await writer.drain()

    def respond(self, m: dict) -> bytes:
        aid = m.get("ActionID", "")
        out = lambda d: "".join(f"{k}: {v}\r\n" for k, v in d.items()) + "\r\n"  # noqa: E731
        a = m.get("Action")
        if a == "Login":
            ok = m.get("Secret") == "s3cret"
            return out({"Response": "Success" if ok else "Error", "ActionID": aid,
                        "Message": "Authentication accepted" if ok else "Authentication failed"}).encode() + \
                (out({"Event": "FullyBooted", "Status": "Fully Booted"}).encode() if ok else b"")
        if a == "QueuePause":
            q = m["Queue"]
            if m["Interface"] != IFACE or q not in self.paused:
                return out({"Response": "Error", "ActionID": aid, "Message": "Interface not found"}).encode()
            self.paused[q] = m["Paused"] == "true"
            return out({"Response": "Success", "ActionID": aid, "Message": "Interface paused successfully"}).encode() + \
                out({"Event": "QueueMemberPause", "Queue": q, "Interface": IFACE, "Paused": "1" if self.paused[q] else "0",
                     "PausedReason": m.get("Reason", "")}).encode()
        if a == "QueueStatus":
            q = m["Queue"]
            s = out({"Response": "Success", "ActionID": aid, "EventList": "start", "Message": "Queue status will follow"})
            s += out({"Event": "QueueParams", "Queue": q, "ActionID": aid})
            s += out({"Event": "QueueMember", "Queue": q, "Name": "Anna", "Location": IFACE, "StateInterface": "hint:101@ext-local",
                      "Status": "1", "Paused": "1" if self.paused[q] else "0", "PausedReason": "agent-state-service" if self.paused[q] else "",
                      "InCall": "0", "ActionID": aid})
            s += out({"Event": "QueueStatusComplete", "ActionID": aid, "EventList": "Complete", "ListItems": "2"})
            return s.encode()
        return out({"Response": "Error", "ActionID": aid, "Message": "Invalid/unknown command"}).encode()


async def test_ami_client_pause_and_status():
    fake = FakeAsterisk()
    port = await fake.start()
    events = []

    async def on_event(ev):
        events.append(ev)

    client = AMIClient("127.0.0.1", port, "u", "s3cret", on_event=on_event, action_timeout=2)
    client.start()
    assert await client.wait_connected(3)
    pbx = AmiPbx(client)
    st = await pbx.member_status(IFACE, ["400", "401"])
    assert st["400"].present and not st["400"].paused
    await pbx.set_paused(IFACE, "400", True, "agent-state-service")
    st = await pbx.member_status(IFACE, ["400"])
    assert st["400"].paused and st["400"].paused_reason == "agent-state-service"
    assert any(e.get("Event") == "QueueMemberPause" for e in events)
    st = await pbx.member_status("Local/999@from-queue/n", ["400"])
    assert not st["400"].present
    await client.stop()
    fake.server.close()


async def test_ami_wrong_password_never_connects():
    fake = FakeAsterisk()
    port = await fake.start()
    client = AMIClient("127.0.0.1", port, "u", "bad", action_timeout=1)
    client.start()
    assert not await client.wait_connected(1)
    assert "login failed" in client.last_error
    await client.stop()
    fake.server.close()


async def test_full_service_over_real_ami_protocol(tmp_path):
    """Services wired with the real AMIClient: startup reconcile + blocking pause go over the wire."""
    import httpx

    from app.db import Database
    from app.main import create_app
    from app.models import AgentMapping, AgentState
    from app.services import Services
    from app.zammad import ZammadClient

    from .conftest import make_settings
    from .fakes import FakeZammad

    fake = FakeAsterisk()
    port = await fake.start()
    settings = make_settings(tmp_path, ami_host="127.0.0.1", ami_port=port, ami_user="u", ami_secret="s3cret",
                             login_sets_ready=True)
    db = Database(settings.database_url)
    from app.db import Base
    async with db.engine.begin() as conn:  # clean schema (matters on PostgreSQL)
        await conn.run_sync(Base.metadata.drop_all)
    await db.create_all()
    async with db.sessionmaker() as s:
        from app.crypto import hash_password
        s.add(AgentMapping(id=1, username="anna", password_hash=hash_password("pw"), zammad_user_id=10,
                           display_name="A", asterisk_interface=IFACE, extension="101"))
        await s.flush()
        s.add(AgentState(agent_id=1, manual_state="ready"))
        await s.commit()
    from .conftest import fix_sequences
    await fix_sequences(db)
    fz = FakeZammad()
    fz.add_user(10, "anna")
    svc = Services(settings, db=db, zammad=ZammadClient(settings.zammad_url, "t", transport=fz.transport()))
    app = create_app(settings, svc)
    app.state.services = svc
    await svc.start(background=True)
    try:
        assert await svc.ami.wait_connected(3)
        for _ in range(50):
            await asyncio.sleep(0.05)
            if (await svc.engine.state_view(1))["sync_status"] == "ok":
                break
        assert (await svc.engine.state_view(1))["phone_status"] == "receiving"
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
            tok = (await c.post("/api/auth/login", json={"username": "anna", "password": "pw"})).json()["token"]
            t = fz.add_ticket("x", owner_id=10, state="open")
            r = await c.post(f"/api/tickets/{t['id']}/start", json={"work_mode": "blocking"},
                             headers={"Authorization": f"Bearer {tok}"})
            assert r.json()["agent_state"]["phone_status"] == "paused"
            assert fake.paused == {"400": True, "401": True}
            assert any(a.get("Action") == "QueuePause" and a.get("Reason") == "agent-state-service" for a in fake.actions)
            health = (await c.get("/api/health")).json()
            assert health["ami_connected"] is True
            assert health["integrations"]["asterisk"] == "ok" and health["integrations"]["telegram"] == "off"
    finally:
        await svc.stop()
        fake.server.close()
