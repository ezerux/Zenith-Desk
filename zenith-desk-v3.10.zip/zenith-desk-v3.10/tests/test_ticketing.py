"""v3.3: ticketing inside Zenith Desk, synchronised with Zammad both ways."""
import base64

from sqlalchemy import select

from app.models import AuditLog, WorkSession, ZammadUser


def spy(env, method="publish_all"):
    events = []
    orig = getattr(env.services.broker, method)

    def wrapper(*args):
        events.append(args)
        return orig(*args)
    setattr(env.services.broker, method, wrapper)
    return events


async def test_directory_full_and_incremental_sync(env):
    d = env.services.directory
    res = await d.sync()
    assert res["full"] and res["added"] == 4
    lst = await d.search("customers")
    assert [u["name"] for u in lst["items"]] == ["Иван"] and lst["counts"] == {"customers": 1, "staff": 3}
    staff = await d.search("staff", "bor")
    assert [u["login"] for u in staff["items"]] == ["boris"]
    assert (await d.search("customers", "912345"))["total"] == 1  # phone digits

    news = spy(env)
    env.zammad.add_user(51, "petr", firstname="Пётр", lastname="Смирнов", phone="+7 900 111-22-33", organization="Ромашка")
    env.zammad.touch_user(50, note="VIP")
    res = await d.sync()
    assert not res["full"] and res["added"] == 1 and res["updated"] == 1
    assert any(e[0] == "directory_new" and e[1]["items"][0]["name"] == "Пётр Смирнов" for e in news)
    assert any(e[0] == "changed" and "directory" in e[1]["topics"] for e in news)
    card = (await d.search("customers", "ромашка"))["items"][0]
    assert card["organization"] == "Ромашка"

    del env.zammad.users[51]  # deleted in Zammad: gone after the next full sync
    await d.sync(full=True)
    async with env.services.db.sessionmaker() as s:
        assert await s.get(ZammadUser, 51) is None and (await s.get(ZammadUser, 50)).note == "VIP"

    h = await env.login("anna")
    r = await env.client.get("/api/directory?kind=customers", headers=h)
    assert r.status_code == 200 and r.json()["total"] == 1
    t = env.zammad.add_ticket("Old question", customer_id=50, state="open")
    r = await env.client.get("/api/directory/50", headers=h)
    assert r.json()["user"]["note"] == "VIP" and r.json()["tickets"][0]["id"] == t["id"]


async def test_lists_filters_search_and_paging(env):
    z = env.zammad
    z.users[10]["groups"] = {"Users": ["full"], "Sales": ["full"]}
    z.users[11]["groups"] = {"Users": ["full"]}
    await env.services.directory.sync()
    mine = z.add_ticket("Invoice missing", owner_id=10, state="open", priority="3 high")
    z.add_ticket("Waiting for papers", owner_id=10, state="pending reminder")
    free = z.add_ticket("New lead", owner_id=1, state="new", group="Sales")
    z.add_ticket("Boris case", owner_id=11, state="open")
    closed = z.add_ticket("Done long ago", owner_id=10, state="closed")
    h = await env.login("anna")

    meta = (await env.client.get("/api/tk/meta", headers=h)).json()
    cats = {s["name"]: s["category"] for s in meta["states"]}
    assert cats == {"new": "new", "open": "open", "pending reminder": "pending", "closed": "closed", "pending close": "pending"}
    assert [g["name"] for g in meta["groups"]] == ["Users", "Sales"]
    hb = await env.login("boris")  # Boris may not use Sales: Zammad hides those tickets from him
    meta_b = (await env.client.get("/api/tk/meta", headers=hb)).json()
    assert [g["name"] for g in meta_b["groups"]] == ["Users"]
    all_b = (await env.client.get("/api/tk/tickets?view=unassigned", headers=hb)).json()
    assert all_b["tickets"] == [] and all_b["total"] == 0
    assert [p["name"] for p in meta["priorities"]] == ["1 low", "2 normal", "3 high"]

    async def ids(qs):
        r = await env.client.get(f"/api/tk/tickets?{qs}", headers=h)
        assert r.status_code == 200, r.text
        return [t["id"] for t in r.json()["tickets"]], r.json()

    got, data = await ids("view=mine")
    assert set(got) == {mine["id"], mine["id"] + 1} and data["total"] == 2
    row = next(t for t in data["tickets"] if t["id"] == mine["id"])
    assert row["mine"] and row["priority"] == "3 high" and row["customer_name"] == "Иван" and row["owner_name"] == "anna"
    assert (await ids("view=unassigned"))[0] == [free["id"]]
    assert (await ids("view=closed"))[0] == [closed["id"]]
    assert len((await ids("view=all"))[0]) == 4
    assert (await ids("view=all&priority=3%20high"))[0] == [mine["id"]]
    assert (await ids("view=all&group=Sales"))[0] == [free["id"]]
    assert (await ids("view=all&group=Nope"))[0] == []
    assert (await ids("view=all&state=pending%20reminder"))[0] == [mine["id"] + 1]
    assert (await ids("view=all&q=lead"))[0] == [free["id"]]
    page2, data = await ids("view=all&per_page=5&page=1")
    assert data["total"] == 4 and len(page2) == 4
    assert (await env.client.get("/api/tk/tickets?view=all&state=nope", headers=h)).status_code == 422


async def test_ticket_page_conversation_and_reply_channels(env):
    await env.services.directory.sync()
    z = env.zammad
    t = z.add_ticket("Where is my order?", owner_id=10, state="open", customer_id=50)
    z.add_article(t["id"], "<p>Hello,<br>where is <b>my order</b>?</p><script>alert(1)</script><a href='https://shop.test/o/1'>order</a>",
                  content_type="text/html", **{"from": "Иван <ivan@example.test>", "message_id": "<m1@mail>"},
                  files=[("invoice.pdf", b"%PDF-1.4 test")])
    h = await env.login("anna")
    d = (await env.client.get(f"/api/tk/tickets/{t['id']}", headers=h)).json()
    art = d["articles"][0]
    assert "where is my order?" in art["body"] and "alert" not in art["body"] and "<" not in art["body"]
    assert "https://shop.test/o/1" in art["body"] and art["author"] == "Иван"
    assert art["attachments"][0]["filename"] == "invoice.pdf"
    assert d["reply"] == {"type": "email", "channel": "email", "to": "Иван <ivan@example.test>", "in_reply_to": "<m1@mail>"}
    assert d["ticket"]["customer"]["name"] == "Иван" and d["zammad_url"].endswith(f"/#ticket/zoom/{t['id']}")

    r = await env.client.get(f"/api/tk/tickets/{t['id']}/articles/{art['id']}/attachments/{art['attachments'][0]['id']}", headers=h)
    assert r.status_code == 200 and r.content == b"%PDF-1.4 test" and r.headers["content-disposition"].startswith("attachment")

    # internal note with a file, in Anna's own name
    f = {"filename": "note.txt", "mime": "text/plain", "data": base64.b64encode(b"hi").decode()}
    r = await env.client.post(f"/api/tk/tickets/{t['id']}/articles", headers=h, json={"body": "Checked the warehouse", "attachments": [f]})
    assert r.status_code == 200, r.text
    note = z.articles[-1]
    assert note["internal"] and note["type"] == "note" and note["created_by_id"] == 10 and z.files[note["attachments"][0]["id"]] == b"hi"

    # reply to the customer: e-mail, threaded, HTML-escaped
    r = await env.client.post(f"/api/tk/tickets/{t['id']}/articles", headers=h,
                              json={"body": "It ships <today>", "kind": "reply"})
    assert r.status_code == 200, r.text
    mail = z.articles[-1]
    assert mail["type"] == "email" and not mail["internal"] and mail["to"] == "Иван <ivan@example.test>"
    assert mail["in_reply_to"] == "<m1@mail>" and "&lt;today&gt;" in mail["body"] and mail["content_type"] == "text/html"

    # telegram ticket: the answer goes back to telegram
    tg = z.add_ticket("Telegram question", owner_id=10, state="open", article_type="telegram personal-message")
    z.add_article(tg["id"], "hi", type="telegram personal-message", **{"from": "@ivan"})
    r = await env.client.post(f"/api/tk/tickets/{tg['id']}/articles", headers=h, json={"body": "Hello!", "kind": "reply"})
    assert z.articles[-1]["type"] == "telegram personal-message"

    big = {"filename": "big.bin", "mime": "x", "data": base64.b64encode(b"0" * (env.settings.attachment_max_mb * 1024 * 1024 + 1)).decode()}
    r = await env.client.post(f"/api/tk/tickets/{t['id']}/articles", headers=h, json={"body": "x", "attachments": [big]})
    assert r.status_code == 413
    assert (await env.client.post(f"/api/tk/tickets/{t['id']}/articles", headers=h, json={"body": "  "})).status_code == 422


async def test_close_with_reply_finishes_work_session(env):
    t = env.zammad.add_ticket("Fix login", owner_id=10, state="open")
    h = await env.login("anna")
    await env.client.post("/api/agents/me/ready", headers=h)
    r = await env.client.post(f"/api/tickets/{t['id']}/start", headers=h, json={"work_mode": "blocking"})
    assert r.status_code == 200
    events = spy(env)
    r = await env.client.post(f"/api/tk/tickets/{t['id']}/articles", headers=h,
                              json={"body": "Solved, password reset", "kind": "note", "internal": False, "state": "closed"})
    assert r.status_code == 200, r.text
    assert env.zammad.state_of(t["id"]) == "closed" and env.zammad.articles[-1]["internal"] is False
    assert r.json()["session"] is None and r.json()["ticket"]["category"] == "closed"
    async with env.services.db.sessionmaker() as s:
        ws = (await s.execute(select(WorkSession).where(WorkSession.ticket_id == t["id"]))).scalars().one()
    assert ws.state == "completed"
    assert any(e[0] == "ticket_changed" and t["id"] in e[1]["ids"] for e in events)


async def test_state_priority_title_and_pending(env):
    t = env.zammad.add_ticket("Old title", owner_id=10, state="open")
    h = await env.login("anna")
    r = await env.client.patch(f"/api/tk/tickets/{t['id']}", headers=h,
                               json={"title": "New title", "priority": "3 high", "state": "pending reminder", "pending_days": 3})
    assert r.status_code == 200, r.text
    zt = env.zammad.tickets[t["id"]]
    assert zt["title"] == "New title" and zt["priority_id"] == 3 and env.zammad.state_of(t["id"]) == "pending reminder"
    assert zt["pending_time"] and r.json()["ticket"]["category"] == "pending"
    async with env.services.db.sessionmaker() as s:
        a = (await s.execute(select(AuditLog).where(AuditLog.action == "ticket_updated"))).scalars().one()
    assert a.details["changes"]["title"] == "New title"


async def test_transfer_to_colleague_notifies_and_respects_zammad_rights(env):
    await env.services.directory.sync()
    z = env.zammad
    t = z.add_ticket("Need a sales person", owner_id=10, state="open")
    h = await env.login("anna")
    people = (await env.client.get(f"/api/tk/tickets/{t['id']}/assignees", headers=h)).json()["people"]
    assert [p["name"] for p in people][-1] == "Анна" and {"Борис", "Руководитель"} <= {p["name"] for p in people}
    assert next(p for p in people if p["me"])["owner"]

    agent_events = spy(env, "publish_agent")
    r = await env.client.patch(f"/api/tk/tickets/{t['id']}", headers=h, json={"owner_id": 11, "note": "Please call him back"})
    assert r.status_code == 200, r.text
    assert z.tickets[t["id"]]["owner_id"] == 11 and z.articles[-1]["body"] == "Please call him back" and z.articles[-1]["internal"]
    assert any(e[0] == 2 and e[1] == "ticket_assigned" and e[2]["by"] == "Анна" for e in agent_events)
    hb = await env.login("boris")
    ntf = (await env.client.get("/api/agents/me/notifications", headers=hb)).json()["items"]
    assert ntf[0]["text"] == f"Анна transferred ticket #{t['number']} to you"
    mine_b = (await env.client.get("/api/tk/tickets?view=mine", headers=hb)).json()["tickets"]
    assert [x["id"] for x in mine_b] == [t["id"]]

    # a colleague without full access to the group: Zammad would silently unassign -> refused, owner kept
    z.add_user(30, "guest", firstname="Guest", groups={"Users": ["read"]})
    await env.services.directory.sync()
    r = await env.client.patch(f"/api/tk/tickets/{t['id']}", headers=hb, json={"owner_id": 30})
    assert r.status_code == 409 and "Guest" in r.json()["detail"] and z.tickets[t["id"]]["owner_id"] == 11
    people = (await env.client.get(f"/api/tk/tickets/{t['id']}/assignees", headers=hb)).json()["people"]
    assert "Guest" not in [p["name"] for p in people]

    # unassign, then move to a group the owner cannot use
    r = await env.client.patch(f"/api/tk/tickets/{t['id']}", headers=hb, json={"owner_id": 0})
    assert z.tickets[t["id"]]["owner_id"] == 1 and r.json()["ticket"]["owner_id"] is None
    await env.client.patch(f"/api/tk/tickets/{t['id']}", headers=hb, json={"owner_id": 11})
    r = await env.client.patch(f"/api/tk/tickets/{t['id']}", headers=hb, json={"group": "Sales"})
    assert r.json()["owner_reset"] is True and z.tickets[t["id"]]["group_id"] == 2
    assert r.json()["gone"] is True  # Boris cannot see Sales tickets: the screen closes it with a message


async def test_zammad_permissions_and_unlinked_accounts(env):
    t = env.zammad.add_ticket("Secret", owner_id=11, state="open")
    env.zammad.no_access.add((10, t["id"]))
    h = await env.login("anna")
    assert (await env.client.get(f"/api/tk/tickets/{t['id']}", headers=h)).status_code == 403
    assert t["id"] not in [x["id"] for x in (await env.client.get("/api/tk/tickets?view=all", headers=h)).json()["tickets"]]
    hr = await env.login("root")  # administrator without a Zammad account
    assert (await env.client.get("/api/tk/tickets", headers=hr)).status_code == 409
    assert (await env.client.get("/api/directory?kind=staff", headers=hr)).status_code == 200


async def test_changes_made_in_zammad_reach_agentix(env):
    desk = env.services.desk
    t = env.zammad.add_ticket("Watch me", owner_id=10, state="open")
    assert await desk.poll() == []  # first look = baseline
    events = spy(env)
    env.zammad._apply_update(env.zammad.tickets[t["id"]], {"owner_id": 11}, None)  # transferred inside Zammad
    assert await desk.poll() == [t["id"]]
    assert any(e[0] == "ticket_changed" and e[1]["ids"] == [t["id"]] for e in events)
    async with env.services.db.sessionmaker() as s:
        a = (await s.execute(select(AuditLog).where(AuditLog.action == "ticket_reassigned"))).scalars().one()
    assert a.agent_id == 2 and a.actor_type == "zammad"
    assert await desk.poll() == []  # nothing new

    # our own change is not reported back as "transferred in Zammad"
    h = await env.login("boris")
    await env.client.patch(f"/api/tk/tickets/{t['id']}", headers=h, json={"owner_id": 10})
    await desk.poll()
    async with env.services.db.sessionmaker() as s:
        rows = (await s.execute(select(AuditLog).where(AuditLog.action == "ticket_reassigned"))).scalars().all()
    assert [(r.agent_id, r.actor_type) for r in rows] == [(2, "zammad"), (1, "agent")]


async def test_create_ticket_in_operator_name_optionally_unassigned(env):
    await env.services.directory.sync()
    h = await env.login("anna")
    r = await env.client.post("/api/tickets", headers=h, json={"title": "Team task", "customer_id": 50, "body": "x",
                                                               "assign_to_me": False, "group": "Users"})
    assert r.status_code == 200, r.text
    tid = r.json()["ticket"]["id"]
    assert env.zammad.tickets[tid]["owner_id"] == 1 and env.zammad.articles[-1]["created_by_id"] == 10
    r = await env.client.post("/api/tickets", headers=h, json={"title": "Mine", "customer_id": 50, "state": "open"})
    tid = r.json()["ticket"]["id"]
    assert env.zammad.tickets[tid]["owner_id"] == 10 and env.zammad.state_of(tid) == "open"
