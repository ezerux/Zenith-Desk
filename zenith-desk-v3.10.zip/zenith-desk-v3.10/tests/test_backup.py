"""v3.10 — backup and restore of the whole system in one encrypted file."""
import asyncio
import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
from sqlalchemy import func, select

from app import backup as bk
from app.backup_service import last_slot, next_slot
from app.crypto import MessageCipher, SecretBox
from app.db import Base
from app.models import AgentMapping, AuditLog, ChatMessage, MailAccount, MsgConversation, MsgFile, MsgMessage, SystemSetting

from .conftest import build_env

PASS = "correct horse battery"
ROOT = Path(__file__).parent.parent


async def close(e) -> None:
    await e.client.aclose()
    await e.services.stop()
    await e.services.db.dispose()


async def admin_h(e) -> dict:
    return await e.login("root")


async def enable_backups(e, h, **extra) -> dict:
    if "display_timezone" in extra:
        e.settings.display_timezone = extra.pop("display_timezone")
    values = {"backup_password": PASS, **extra}
    r = await e.client.put("/api/admin/backups/settings", json={"values": values}, headers=h)
    assert r.status_code == 200, r.text
    return r.json()


async def fill(e) -> dict:
    """Data of every kind: chat (encrypted), messenger conversation with a file, mail account, panel secrets."""
    anna, boris, h = await e.login("anna"), await e.login("boris"), await admin_h(e)
    r = await e.client.post("/api/chat/2/messages", json={"body": "Привет, Борис — секретная встреча в 15:00"}, headers=anna)
    assert r.status_code == 200, r.text
    r = await e.client.put("/api/admin/settings", json={"values": {"zammad_token": "zammad-token-XYZ", "ami_secret": "ami-pw-1",
                                                                     "ui_language": "en", "attachment_max_mb": 17}}, headers=h)
    assert r.status_code == 200, r.text
    r = await e.client.put("/api/admin/users/1", headers=h, json={
        "first_name": "Анна", "username": "anna", "level": "level1", "extension": "101", "asterisk_interface": "Local/101@from-queue/n",
        "sip_password": "sip-secret-101", "zammad_user_id": 10})
    assert r.status_code == 200, r.text
    sv = e.services
    payload = os.urandom(70_000)  # binary file stored in the database
    async with sv.db.sessionmaker() as s:
        conv = MsgConversation(channel="whatsapp", external_id="79001234567", name="Иван", phone="+79001234567",
                               last_text=sv.cipher.seal("Где мой заказ?"))
        s.add(conv)
        await s.flush()
        s.add(MsgMessage(conversation_id=conv.id, channel="whatsapp", direction="in", external_id="wamid.1",
                         body=sv.cipher.seal("Где мой заказ?"), files=[{"name": "photo.jpg", "key": "k1"}], kind="image"))
        s.add(MsgFile(key="k1", conversation_id=conv.id, name="photo.jpg", mime="image/jpeg", size=len(payload), data=payload))
        s.add(MailAccount(agent_id=2, email="boris@example.com", login="boris@example.com", secret=sv.store.box.encrypt("mail-pw-boris")))
        await s.commit()
    return {"payload": payload, "h": h, "anna": anna, "boris": boris}


async def counts(db) -> dict:
    out = {}
    async with db.engine.connect() as c:
        for t in Base.metadata.sorted_tables:
            out[t.name] = (await c.execute(select(func.count()).select_from(t))).scalar()
    return out


# ============================================================ file format
async def test_file_roundtrip_wrong_password_and_damage(env, tmp_path):
    await fill(env)
    path = tmp_path / "a.zdb"
    res = await bk.dump(env.services.db, path, PASS, master_key=env.settings.jwt_secret, app_version="3.10", kind="manual")
    assert path.exists() and not (tmp_path / "a.zdb.part").exists()
    assert res.rows == sum((await counts(env.services.db)).values())
    h = bk.read_header(path)
    assert h["kind"] == "manual" and h["product"] == "Zenith Desk" and h["rows"] == res.rows
    raw = path.read_bytes()
    assert b"zammad-token-XYZ" not in raw and "секретная".encode() not in raw and env.settings.jwt_secret.encode() not in raw
    plan = bk.verify(path, PASS, app_version="3.10")
    assert plan.tables["chat_message"] == 1 and plan.tables["msg_file"] == 1
    with pytest.raises(bk.BackupError) as ei:
        bk.verify(path, "wrong password!", app_version="3.10")
    assert ei.value.code == "bk.wrong_password"
    # a changed byte in the middle, a cut file, a header that was edited, a random file
    bad = bytearray(raw)
    bad[len(raw) // 2] ^= 0xFF
    (tmp_path / "b.zdb").write_bytes(bytes(bad))
    (tmp_path / "c.zdb").write_bytes(raw[: len(raw) - 100])
    (tmp_path / "e.zdb").write_bytes(b"hello world, not a backup")
    for name in ("b.zdb", "c.zdb"):
        with pytest.raises(bk.BackupError) as ei:
            bk.verify(tmp_path / name, PASS, app_version="3.10")
        assert ei.value.code == "bk.damaged", name
    hdr = raw.replace(b'"kind": "manual"', b'"kind": "manuaX"')
    assert hdr != raw
    (tmp_path / "d.zdb").write_bytes(hdr)
    with pytest.raises(bk.BackupError):
        bk.verify(tmp_path / "d.zdb", PASS, app_version="3.10")
    with pytest.raises(bk.BackupError) as ei:
        bk.verify(tmp_path / "e.zdb", PASS, app_version="3.10")
    assert ei.value.code == "bk.not_backup"
    # chunks cannot be dropped from the end (last-chunk flag): build a multi-chunk file and cut a whole chunk
    big = tmp_path / "big.zdb"
    w = bk.Writer(big, PASS, {"kind": "manual"})
    w.line({"t": "meta", "master_key": "x", "app_version": "3.10"})
    for i in range(3000):
        w.line({"r": [os.urandom(1500).hex()]})
    w.line({"t": "end", "tables": {}})
    w.close()
    assert w.index >= 3
    data = big.read_bytes()
    import struct
    n = struct.unpack(">I", data[5:9])[0]
    pos, starts = 9 + n, []
    while pos < len(data):
        starts.append(pos)
        pos += 4 + struct.unpack(">I", data[pos:pos + 4])[0]
    (tmp_path / "cut.zdb").write_bytes(data[: starts[-1]])  # last chunk removed
    r = bk.Reader(tmp_path / "cut.zdb", PASS)
    with pytest.raises(bk.BackupError) as ei:
        list(r.lines())
    assert ei.value.code == "bk.damaged"


async def test_short_password_and_newer_version_refused(env, tmp_path):
    with pytest.raises(bk.BackupError) as ei:
        await bk.dump(env.services.db, tmp_path / "x.zdb", "short", master_key="k", app_version="3.10", kind="manual")
    assert ei.value.code == "bk.password_short"
    assert not list(tmp_path.glob("x.zdb*"))
    await bk.dump(env.services.db, tmp_path / "new.zdb", PASS, master_key="k", app_version="9.1", kind="manual")
    with pytest.raises(bk.BackupError) as ei:
        bk.verify(tmp_path / "new.zdb", PASS, app_version="3.10")
    assert ei.value.code == "bk.newer"


# ============================================================ the whole system onto a new server
async def test_restore_on_new_server_with_other_key(tmp_path):
    (tmp_path / "server-a").mkdir()
    a = await build_env(tmp_path / "server-a")
    data = await fill(a)
    h = data["h"]
    await enable_backups(a, h)
    r = await a.client.post("/api/admin/backups", json={"note": "before move", "wait": True}, headers=h)
    assert r.status_code == 200, r.text
    v = r.json()
    assert v["job"]["state"] == "done" and len(v["items"]) == 1
    item = v["items"][0]
    assert item["kind"] == "manual" and item["note"] == "before move" and item["size"] > 70_000
    before = await counts(a.services.db)
    # download it like the browser does
    r = await a.client.post(f"/api/admin/backups/{item['name']}/link", headers=h)
    url = r.json()["url"]
    r = await a.client.get(url)
    assert r.status_code == 200 and r.content[:5] == bk.MAGIC
    blob = r.content
    await close(a)

    # server B: different JWT_SECRET, its own first data, nothing in common with A
    (tmp_path / "server-b").mkdir()
    b = await build_env(tmp_path / "server-b", jwt_secret="another-server-secret-9876543210-zyxwvutsrq")
    hb = await admin_h(b)
    async with b.services.db.sessionmaker() as s:
        s.add(SystemSetting(key="zammad_url", value='"http://only-on-b"'))
        await s.commit()
    await b.services.store.load()
    assert b.settings.zammad_url == "http://only-on-b"
    r = await b.client.put("/api/admin/backups/upload?filename=from-server-a.zdb", content=blob, headers=hb)
    assert r.status_code == 200, r.text
    name = r.json()["uploaded"]["name"]
    assert name == "from-server-a.zdb"
    r = await b.client.post(f"/api/admin/backups/{name}/restore", json={"password": "nope nope nope", "confirm": "RESTORE"}, headers=hb)
    assert r.status_code == 422
    r = await b.client.post(f"/api/admin/backups/{name}/restore", json={"password": PASS, "confirm": "no"}, headers=hb)
    assert r.status_code == 422
    r = await b.client.post(f"/api/admin/backups/{name}/restore", json={"password": PASS, "confirm": "RESTORE", "wait": True}, headers=hb)
    assert r.status_code == 200, r.text
    job = r.json()["job"]
    assert job["state"] == "done" and job["result"]["rekeyed"] is True and job["result"]["rekey_failed"] == 0
    after = await counts(b.services.db)
    for t, n in before.items():
        if t == "audit_log":
            assert after[t] >= n  # + "backup_restored"
        else:
            assert after[t] == n, t
    # settings and secrets of A are live on B, readable with B's key; B's own value is gone
    cfg = b.settings
    assert cfg.zammad_token == "zammad-token-XYZ" and cfg.ami_secret == "ami-pw-1" and cfg.attachment_max_mb == 17
    assert cfg.zammad_url == "http://zammad.test"  # back to the default: A never set it in the panel
    assert cfg.backup_password == PASS
    box, cipher = SecretBox(cfg.jwt_secret), MessageCipher(cfg.jwt_secret)
    async with b.services.db.sessionmaker() as s:
        anna = await s.get(AgentMapping, 1)
        assert box.decrypt(anna.sip_secret) == "sip-secret-101"
        assert box.decrypt((await s.get(MailAccount, 2)).secret) == "mail-pw-boris"
        f = (await s.execute(select(MsgFile))).scalars().one()
        assert f.data == data["payload"]
        m = (await s.execute(select(MsgMessage))).scalars().one()
        assert cipher.open(m.body) == "Где мой заказ?" and m.files[0]["name"] == "photo.jpg"
        conv = (await s.execute(select(MsgConversation))).scalars().one()
        assert cipher.open(conv.last_text) == "Где мой заказ?"
        assert (await s.execute(select(AuditLog).where(AuditLog.action == "backup_restored"))).scalars().first() is not None
    # people sign in with their old passwords and read their chat (decrypted with B's key)
    ba = await b.login("boris")
    r = await b.client.get("/api/chat/1/messages", headers=ba)
    assert r.status_code == 200 and "секретная встреча" in r.text
    # the SIP password reaches the phone with B's key
    r = await b.client.get("/api/phone/config", headers=await b.login("anna"))
    assert r.status_code == 200 and "sip-secret-101" in r.text, r.text
    # a safety copy of B's previous state was written first and is itself restorable
    v = (await b.client.get("/api/admin/backups", headers=await admin_h(b))).json()
    safety = [x for x in v["items"] if x["kind"] == "pre-restore"]
    assert len(safety) == 1 and job["result"]["safety_copy"] == safety[0]["name"]
    bk.verify(Path(b.settings.backup_dir) / safety[0]["name"], PASS, app_version="3.10")
    # new rows still get ids (sequences moved past the restored ids on PostgreSQL)
    r = await b.client.post("/api/chat/1/messages", json={"body": "после восстановления"}, headers=ba)
    assert r.status_code == 200, r.text
    # the admin sees the restore in the notifications
    r = await b.client.get("/api/agents/me/notifications", headers=await admin_h(b))
    assert any(i["kind"] == "backup" for i in r.json()["items"])
    await close(b)


async def test_failed_restore_changes_nothing(env, tmp_path):
    await fill(env)
    h = await admin_h(env)
    await enable_backups(env, h)
    r = await env.client.post("/api/admin/backups", json={"wait": True}, headers=h)
    name = r.json()["items"][0]["name"]
    path = Path(env.settings.backup_dir) / name
    raw = bytearray(path.read_bytes())
    raw[-40] ^= 0x01  # damage the last chunk: the password is right, the file is not
    path.write_bytes(bytes(raw))
    before = await counts(env.services.db)
    r = await env.client.post(f"/api/admin/backups/{name}/restore", json={"password": PASS, "confirm": "RESTORE", "wait": True}, headers=h)
    assert r.status_code == 400 and "damaged" in r.text
    assert await counts(env.services.db) == before
    assert not [x for x in (await env.client.get("/api/admin/backups", headers=h)).json()["items"] if x["kind"] == "pre-restore"]


async def test_restore_inside_one_transaction(env, tmp_path, monkeypatch):
    """A failure in the middle of writing rolls everything back."""
    await fill(env)
    path = tmp_path / "x.zdb"
    await bk.dump(env.services.db, path, PASS, master_key=env.settings.jwt_secret, app_version="3.10", kind="manual")
    before = await counts(env.services.db)
    calls = {"n": 0}

    def boom(table, n):
        calls["n"] += 1
        if table == "chat_message":
            raise RuntimeError("disk on fire")
    with pytest.raises(RuntimeError):
        await bk.restore(env.services.db, path, PASS, master_key=env.settings.jwt_secret, app_version="3.10", progress=boom)
    assert calls["n"] > 1
    assert await counts(env.services.db) == before


async def test_live_restore_with_background_jobs_running(env, tmp_path):
    """The running services are stopped, the data replaced and everything started again."""
    await fill(env)
    h = await admin_h(env)
    await enable_backups(env, h)
    r = await env.client.post("/api/admin/backups", json={"wait": True}, headers=h)
    name = r.json()["items"][0]["name"]
    sv = env.services
    sv._background = True
    await sv._start_background()
    assert sv.hub._task is not None and sv.engine._tasks
    # change things after the backup
    async with sv.db.sessionmaker() as s:
        s.add(ChatMessage(sender_id=1, recipient_id=2, body=sv.cipher.seal("после копии")))
        await s.commit()
    r = await env.client.post(f"/api/admin/backups/{name}/restore", json={"password": PASS, "confirm": "RESTORE", "wait": True}, headers=h)
    assert r.status_code == 200, r.text
    assert sv.hub._task is not None and not sv.hub._task.done() and sv.engine._tasks
    assert all(not t.done() for t in sv._tasks if t.get_name() != "startup-reconcile")
    async with sv.db.sessionmaker() as s:
        assert (await s.execute(select(func.count()).select_from(ChatMessage))).scalar() == 1
    r = await env.client.get("/api/health")
    assert r.status_code == 200


# ============================================================ schedule, copies, alerts
def test_schedule_slots():
    utc = timezone.utc
    now = datetime(2026, 10, 12, 10, 0, tzinfo=utc)  # Monday 14:00 in Yerevan
    assert last_slot(now, "daily", "03:00", "sun", "Asia/Yerevan") == datetime(2026, 10, 11, 23, 0, tzinfo=utc)
    assert next_slot(now, "daily", "03:00", "sun", "Asia/Yerevan") == datetime(2026, 10, 12, 23, 0, tzinfo=utc)
    assert last_slot(now, "daily", "15:30", "sun", "UTC") == datetime(2026, 10, 11, 15, 30, tzinfo=utc)
    assert last_slot(now, "weekly", "03:00", "sun", "UTC") == datetime(2026, 10, 11, 3, 0, tzinfo=utc)
    assert next_slot(now, "weekly", "03:00", "sun", "UTC") == datetime(2026, 10, 18, 3, 0, tzinfo=utc)
    assert last_slot(now, "weekly", "11:00", "mon", "UTC") == datetime(2026, 10, 5, 11, 0, tzinfo=utc)
    assert last_slot(now, "weekly", "09:00", "mon", "UTC") == datetime(2026, 10, 12, 9, 0, tzinfo=utc)
    # daylight saving time: 03:00 Berlin is 01:00 UTC in summer, 02:00 UTC in winter
    assert next_slot(datetime(2026, 10, 24, 12, 0, tzinfo=utc), "daily", "03:00", "sun", "Europe/Berlin") == datetime(2026, 10, 25, 2, 0, tzinfo=utc)


async def test_scheduled_backups_keep_n_copies(env, tmp_path):
    h = await admin_h(env)
    v = await enable_backups(env, h, backup_enabled=True, backup_keep=2, backup_time="03:00", display_timezone="UTC")
    assert v["enabled"] and v["has_password"] and v["next_run_at"]
    b = env.services.backups
    day = datetime(2026, 10, 12, 4, 0, tzinfo=timezone.utc)
    names = []
    for i in range(4):
        now = day + timedelta(days=i)
        info = await b.run_due(now)
        assert info is not None, i
        # the file is dated "now" (real clock); make the next day's slot look newer than it
        path = Path(env.settings.backup_dir) / info["name"]
        hdr = bk.read_header(path)
        assert hdr["kind"] == "scheduled"
        names.append(info["name"])
        assert await b.run_due(now) is None  # once per slot
    files = [x for x in b.files() if x["kind"] == "scheduled"]
    assert len(files) == 2  # only the newest two automatic copies are kept
    # manual copies are never deleted by the schedule
    r = await env.client.post("/api/admin/backups", json={"wait": True}, headers=h)
    assert r.status_code == 200
    await b.run_due(day + timedelta(days=9))
    assert len([x for x in b.files() if x["kind"] == "manual"]) == 1


async def test_due_logic_and_catch_up(env):
    h = await admin_h(env)
    await enable_backups(env, h, backup_enabled=True, backup_time="03:00", display_timezone="UTC")
    b = env.services.backups
    now = datetime.now(timezone.utc)
    assert b.due(now) is not None  # never backed up: the last slot is due (catch-up after downtime)
    info = await b.run_due(now)
    assert info and b.due(now) is None  # done for this slot
    assert b.due(now + timedelta(days=1, hours=1)) is not None  # the next day's slot


async def test_failure_alerts_admins_once_and_retries_later(env, tmp_path):
    h = await admin_h(env)
    blocker = tmp_path / "not-a-folder"
    blocker.write_text("x")
    await enable_backups(env, h, backup_enabled=True, display_timezone="UTC")
    env.settings.backup_dir = str(blocker / "sub")  # cannot be created → every backup fails
    b = env.services.backups
    now = datetime.now(timezone.utc)
    assert await b.run_due(now) is None
    assert await b.run_due(now + timedelta(minutes=1)) is None  # same slot, within 15 min: not even tried
    async with env.services.db.sessionmaker() as s:
        n = (await s.execute(select(func.count()).select_from(AuditLog).where(AuditLog.action == "backup_failed"))).scalar()
    assert n == 1
    assert b.due(now + timedelta(minutes=16)) is not None  # tried again later
    await b.run_due(now + timedelta(minutes=16))
    async with env.services.db.sessionmaker() as s:
        n = (await s.execute(select(func.count()).select_from(AuditLog).where(AuditLog.action == "backup_failed"))).scalar()
    assert n == 1  # but the administrators are not alerted twice for the same slot
    r = await env.client.get("/api/agents/me/notifications", headers=h)
    items = [i for i in r.json()["items"] if i["kind"] == "backup"]
    assert items and items[0]["level"] == "error" and "Backup failed" in items[0]["text"]
    # operators do not see it
    r = await env.client.get("/api/agents/me/notifications", headers=await env.login("anna"))
    assert not [i for i in r.json()["items"] if i["kind"] == "backup"]
    v = (await env.client.get("/api/admin/backups", headers=h)).json()
    assert v["last_error"] and v["last_error"]["error"]


async def test_alert_webhook_on_failure(env, tmp_path, monkeypatch):
    sent = []

    class FakeClient:
        def __init__(self, *a, **k):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return False

        async def post(self, url, json):
            sent.append((url, json))

    import app.backup_service as bs
    monkeypatch.setattr(bs.httpx, "AsyncClient", FakeClient)
    env.settings.admin_alert_webhook_url = "http://hook.test/alert"
    await env.services.backups.failed(bk.BackupError("bk.no_password"), "scheduled")
    assert sent and sent[0][1]["event"] == "backup_failed"


# ============================================================ API rules
async def test_api_rights_validation_and_names(env, tmp_path):
    h, op = await admin_h(env), await env.login("anna")
    assert (await env.client.get("/api/admin/backups", headers=op)).status_code == 403
    assert (await env.client.post("/api/admin/backups", json={}, headers=op)).status_code == 403
    # no password yet
    r = await env.client.post("/api/admin/backups", json={"wait": True}, headers=h)
    assert r.status_code == 409 and "password" in r.text.lower()
    r = await env.client.put("/api/admin/backups/settings", json={"values": {"backup_enabled": True}}, headers=h)
    assert r.status_code == 409
    for bad in ({"backup_time": "25:00"}, {"backup_password": "short"}, {"backup_keep": 0}, {"backup_frequency": "hourly"},
                {"zammad_token": "x"}):
        r = await env.client.put("/api/admin/backups/settings", json={"values": bad}, headers=h)
        assert r.status_code == 422, bad
    v = await enable_backups(env, h, backup_time="4:05")
    assert v["time"] == "04:05"
    r = await env.client.post("/api/admin/backups", json={"wait": True}, headers=h)
    name = r.json()["items"][0]["name"]
    # traversal / unknown names
    for bad in ("..%2F..%2Fetc%2Fpasswd", "nothing.zdb", "x.txt"):
        assert (await env.client.delete(f"/api/admin/backups/{bad}", headers=h)).status_code in (404, 405), bad
    # download tickets: only for this file, only for a while, only for an active admin
    url = (await env.client.post(f"/api/admin/backups/{name}/link", headers=h)).json()["url"]
    other = url.replace(f"/{name}/", "/zenith-backup-other.zdb/")
    assert (await env.client.get(other)).status_code == 403
    assert (await env.client.get(f"/api/admin/backups/{name}/download?ticket=abc")).status_code == 401
    assert (await env.client.get(url)).status_code == 200
    # upload of something that is not a backup is refused and not kept
    r = await env.client.put("/api/admin/backups/upload?filename=evil.zdb", content=b"MZ\x90\x00 not a backup", headers=h)
    assert r.status_code == 400
    assert not list(Path(env.settings.backup_dir).glob("evil*"))
    # verify
    r = await env.client.post(f"/api/admin/backups/{name}/verify", json={"password": PASS}, headers=h)
    assert r.status_code == 200 and r.json()["rows"] > 0
    r = await env.client.post(f"/api/admin/backups/{name}/verify", json={"password": "wrong-wrong"}, headers=h)
    assert r.status_code == 422
    # delete
    r = await env.client.delete(f"/api/admin/backups/{name}", headers=h)
    assert r.status_code == 200 and not r.json()["items"]


async def test_background_job_from_the_panel(env):
    h = await admin_h(env)
    await enable_backups(env, h)
    r = await env.client.post("/api/admin/backups", json={}, headers=h)
    assert r.status_code == 200 and r.json()["job"]["state"] in ("running", "done")
    r2 = await env.client.post("/api/admin/backups", json={}, headers=h)
    assert r2.status_code in (200, 409)
    await env.services.backups.wait_job()
    v = (await env.client.get("/api/admin/backups", headers=h)).json()
    assert v["job"]["state"] == "done" and v["items"] and v["busy"] == ""


# ============================================================ command line
def test_cli_backup_and_restore(tmp_path, monkeypatch):
    """python -m app.cli backup / restore on a stopped server (SQLite)."""
    import asyncio as aio
    monkeypatch.delenv("TEST_DATABASE_URL", raising=False)

    async def prepare():
        e = await build_env(tmp_path)
        await fill(e)
        await close(e)
    aio.run(prepare())
    url = f"sqlite+aiosqlite:///{tmp_path}/test.db"
    envv = {**os.environ, "DATABASE_URL": url, "JWT_SECRET": "test-secret-0123456789-abcdefghijklmnop", "BACKUP_PASSWORD": PASS,
            "BACKUP_DIR": str(tmp_path / "bk")}
    envv.pop("TEST_DATABASE_URL", None)
    r = subprocess.run([sys.executable, "-m", "app.cli", "backup"], cwd=ROOT, env=envv, capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr
    path = Path(r.stdout.splitlines()[0])
    assert path.exists() and bk.read_header(path)["kind"] == "cli"
    r = subprocess.run([sys.executable, "-m", "app.cli", "backups"], cwd=ROOT, env=envv, capture_output=True, text=True, timeout=60)
    assert path.name in r.stdout
    # a new empty server with another key
    (tmp_path / "new").mkdir()

    async def empty():
        e = await build_env(tmp_path / "new", seed=True)
        await close(e)
    aio.run(empty())
    env2 = {**envv, "DATABASE_URL": f"sqlite+aiosqlite:///{tmp_path}/new/test.db", "JWT_SECRET": "a-completely-different-secret-for-server-2"}
    r = subprocess.run([sys.executable, "-m", "app.cli", "restore", str(path), "--yes"], cwd=ROOT, env=env2, capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr
    assert "re-encrypted" in r.stdout
    r = subprocess.run([sys.executable, "-m", "app.cli", "restore", str(path), "--yes", "--password", "bad-password"], cwd=ROOT, env=env2,
                       capture_output=True, text=True, timeout=120)
    assert r.returncode != 0 and "wrong_password" in r.stderr

    async def check():
        from app.db import Database
        db = Database(env2["DATABASE_URL"])
        async with db.sessionmaker() as s:
            m = (await s.execute(select(ChatMessage))).scalars().one()
            assert MessageCipher(env2["JWT_SECRET"]).open(m.body).startswith("Привет, Борис")
        await db.dispose()
    aio.run(check())
