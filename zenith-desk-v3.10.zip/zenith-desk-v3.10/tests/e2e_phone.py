"""End-to-end check of Zenith Phone's real WebRTC engine (JsSIP) in Chromium against a SIP-over-WebSocket server.

    python tests/e2e_phone.py          # starts the fake SIP server and a demo server itself

What is checked: digest registration (and a refused wrong password), outgoing call (ringing, answer, timer),
busy number, hold / resume (re-INVITE), DTMF, hang up (BYE), incoming call with caller name (answer, remote BYE),
blind transfer (REFER), one phone per browser (second tab), Content-Security-Policy allows the PBX WebSocket.
Exits with code 1 if anything fails.
"""
import asyncio
import os
import socket
import subprocess
import sys
import time
import urllib.request

from playwright.async_api import async_playwright

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.fake_sip import FakeSip  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS: list[tuple[str, bool, str]] = []


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def expect(cond, msg):
    if not cond:
        raise AssertionError(msg)


async def step(name, coro):
    try:
        await coro
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}", flush=True)
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, False, str(exc)[:300]))
        print(f"  FAIL  {name}: {str(exc)[:300]}", flush=True)


async def wait_log(sip: FakeSip, text: str, timeout: float = 6.0) -> None:
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if any(text in x for x in sip.log):
            return
        await asyncio.sleep(0.1)
    raise AssertionError(f"SIP server did not see {text!r}: {sip.log[-8:]}")


async def main() -> int:
    sip = FakeSip({"101": "sip-pass-101", "102": "sip-pass-102"})
    sip_port = await sip.start()
    port = free_port()
    env = {**os.environ, "DEMO_PHONE_WSS": f"ws://127.0.0.1:{sip_port}", "DEMO_HISTORY": "0"}
    env.pop("DEMO_DB", None)
    demo = subprocess.Popen([sys.executable, "-c", f"import uvicorn; from scripts.demo import build; uvicorn.run(build(), host='127.0.0.1', port={port}, log_level='warning')"],
                            cwd=ROOT, env=env)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(base + "/api/health", timeout=1)
                break
            except Exception:  # noqa: BLE001
                await asyncio.sleep(0.5)
        async with async_playwright() as p:
            browser = await p.chromium.launch(args=["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"])
            ctx = await browser.new_context(viewport={"width": 1400, "height": 900}, permissions=["microphone"])
            errors: list[str] = []
            pg = await ctx.new_page()
            pg.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
            pg.on("console", lambda m: errors.append(m.text) if m.type == "error" and "Failed to load resource" not in m.text else None)

            async def login(page, user):
                await page.goto(base + "/")
                await page.fill("input[autocomplete=username]", user)
                await page.fill("input[type=password]", "pw")
                await page.click("form button.primary")
                await page.wait_for_selector(".sidebar", timeout=8000)

            async def register():
                await login(pg, "anna")
                await pg.wait_for_selector(".phone-btn.p-registered", timeout=10000)
                expect(sip.log[0] == "REGISTER 401" and "REGISTER 200 101" in sip.log, f"registration: {sip.log}")
                csp = await pg.evaluate("fetch('/').then(r => r.headers.get('content-security-policy'))")
                expect(f"ws://127.0.0.1:{sip_port}" in csp, f"CSP does not allow the PBX socket: {csp}")
            await step("WebRTC phone registers on the PBX with digest authentication", register())

            async def call(number):
                await pg.fill(".ph-num input", number)
                await pg.click("[data-act=call]")

            async def outgoing():
                await pg.click(".phone-btn")
                await pg.wait_for_selector(".ph-card .ph-num input")
                await call("+37491123456")
                await wait_log(sip, "INVITE +37491123456")
                await pg.wait_for_selector(".ph-card.ph-active", timeout=6000)
                await wait_log(sip, "ACK")
                await pg.wait_for_function("document.querySelector('.ph-line small') && document.querySelector('.ph-line small').textContent >= '00:01'", timeout=4000)
                await pg.wait_for_selector(".ph-who >> text=Aram Grigoryan", timeout=4000)  # customer recognised
                expect(await pg.locator(".ph-callbtn.m-end").count() == 1, "Call did not turn into End")
            await step("Outgoing call: ringing, answered, timer, customer recognised, Call becomes End", outgoing())

            async def in_call_controls():
                await pg.click("[data-act=hold]")
                await wait_log(sip, "re-INVITE sendonly")
                await pg.wait_for_selector(".ph-line.l-held", timeout=4000)
                await pg.click("[data-act=hold]")
                await wait_log(sip, "re-INVITE sendrecv")
                await pg.click(".ph-key[data-key='5']")  # the keypad sends DTMF during a call, like a desk phone
                for _ in range(40):
                    if sip.dtmf:
                        break
                    await asyncio.sleep(0.1)
                expect(sip.dtmf == ["5"], f"DTMF: {sip.dtmf}")
                await pg.click("[data-act=mute]")
                expect(await pg.locator(".ph-vbtn.off[data-act=mic-mute]").count() == 1, "mute not shown on the microphone")
                await pg.click("[data-act=mute]")
                await pg.click("[data-act=call]")  # End
                await wait_log(sip, "BYE from browser")
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=4000)
            await step("In a call: hold / resume (re-INVITE), keypad DTMF, mute, End (BYE)", in_call_controls())

            async def busy_redial_vm():
                await call("486")
                await wait_log(sip, "INVITE 486")
                await pg.wait_for_selector(".toast.error", timeout=5000)
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=4000)
                n = len([x for x in sip.log if x == "INVITE 486"])
                await pg.click(".ph-key[data-key='R']")  # redial
                await wait_log(sip, "INVITE 486")
                for _ in range(40):
                    if len([x for x in sip.log if x == "INVITE 486"]) > n:
                        break
                    await asyncio.sleep(0.1)
                expect(len([x for x in sip.log if x == "INVITE 486"]) > n, "R did not redial")
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=6000)
                await pg.click("[data-flag=vm]")
                await wait_log(sip, "INVITE *97")
                await pg.wait_for_selector(".ph-card.ph-active", timeout=6000)
                await pg.click("[data-act=call]")
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=4000)
            await step("Busy number, R (redial), voicemail button dials *97", busy_redial_vm())

            async def incoming():
                await pg.click("[data-act=minimize]")
                await sip.call_browser()
                # v3.7: the minimized phone rings in the call strip under the top bar (Answer / Decline), the window stays closed
                await pg.wait_for_selector(".ph-strip.cs-ringing >> text=Aram Grigoryan", timeout=5000)  # caller recognised
                expect(await pg.locator(".phone-btn.c-ringing").count() == 1, "phone button does not ring")
                expect(not await pg.locator(".ph-card").is_visible(), "the window must not cover the page")
                await pg.click("[data-act=strip-answer]")
                await wait_log(sip, "INVITE 200 from browser")
                await pg.wait_for_selector(".ph-strip.cs-active", timeout=5000)
                await pg.click("[data-act=strip-hold]")  # hold from the strip
                await wait_log(sip, "re-INVITE sendonly")
                await pg.wait_for_selector(".ph-strip.cs-held", timeout=4000)
                await pg.click("[data-act=strip-hold]")
                await pg.wait_for_selector(".ph-strip.cs-active", timeout=4000)
                n = len(sip.dtmf)
                await pg.click("[data-act=strip-keypad]")
                await pg.click("[data-skey='9']")  # DTMF from the strip keypad
                for _ in range(40):
                    if len(sip.dtmf) > n:
                        break
                    await asyncio.sleep(0.1)
                expect(sip.dtmf[n:] == ["9"], f"DTMF from the strip: {sip.dtmf}")
                await pg.click(".ph-strip .ph-stext")  # the strip opens the phone
                await pg.wait_for_selector(".ph-card.ph-active", timeout=5000)
                await sip.hangup()
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=5000)
                expect(await pg.locator(".ph-strip").count() == 0, "strip must go away after the call")
            await step("Incoming call rings in the call strip (name, Answer, hold, DTMF), opens the phone, the other side hangs up", incoming())

            async def two_lines():
                await call("+37491123456")
                await pg.wait_for_selector(".ph-line.l-active", timeout=6000)
                await call("102")  # second line: the first one goes on hold automatically
                await wait_log(sip, "re-INVITE sendonly")
                await pg.wait_for_function("document.querySelectorAll('.ph-line').length === 2 && !!document.querySelector('.ph-line.l-held') && !!document.querySelector('.ph-line.l-active')", timeout=6000)
                await pg.click("[data-flag=conf]")  # 3-way conference: both lines talk
                await wait_log(sip, "re-INVITE sendrecv")
                await pg.wait_for_function("document.querySelectorAll('.ph-line.l-active').length === 2", timeout=4000)
                expect(await pg.locator(".ph-flags button.on[data-flag=conf]").count() == 1, "CONF not on")
                async with pg.expect_download() as dl:
                    await pg.click("[data-flag=rec]")
                    await asyncio.sleep(1.2)
                    await pg.click("[data-flag=rec]")
                f = await dl.value
                expect(f.suggested_filename.startswith("call-") and f.suggested_filename.endswith((".webm", ".ogg")), f"recording: {f.suggested_filename}")
                await pg.click("[data-flag=conf]")  # leave the conference
                await pg.click(".ph-line[data-line='1']")  # back to line 1: line 2 is held
                await pg.wait_for_selector(".ph-line[data-line='2'].l-held", timeout=4000)
                await pg.click("[data-act=transfer]")
                await pg.click("[data-act=attended]")  # connect the customer with the colleague
                await wait_log(sip, "REFER")
                expect("Replaces=" in sip.refer_to and "102@" in sip.refer_to, f"attended transfer: {sip.refer_to}")
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=5000)
            await step("Two lines: auto-hold, conference (CONF), call recording (REC), attended transfer", two_lines())

            async def blind_transfer():
                await call("+37477445566")
                await pg.wait_for_selector(".ph-card.ph-active", timeout=6000)
                await pg.click("[data-act=transfer]")
                await pg.fill(".ph-tr input", "103")
                await pg.click("[data-act=blind]")
                await wait_log(sip, "REFER <sip:103@")
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=5000)  # the PBX took the call over: our leg is closed
            await step("Blind transfer to a colleague (REFER)", blind_transfer())

            async def dnd_and_aa():
                await pg.click("[data-act=menu]")
                await pg.check(".ph-menu [data-opt=dnd]")
                await pg.click("[data-act=menu]")
                expect("Do not disturb" in await pg.inner_text("[data-status]") or "Не беспокоить" in await pg.inner_text("[data-status]"), "DND not in the status bar")
                await pg.wait_for_selector(".ph-dndbtn.on", timeout=3000)  # the same DND in the top bar (kept on the server)
                await sip.call_browser("+79001112233", "")
                await wait_log(sip, "INVITE 486 from browser")
                await pg.click("[data-act=menu]")
                await pg.uncheck(".ph-menu [data-opt=dnd]")
                await pg.click("[data-act=menu]")
                await pg.click("[data-flag=aa]")  # auto-answer
                await sip.call_browser("+79001112244", "")
                await wait_log(sip, "INVITE 200 from browser", timeout=6)
                await pg.wait_for_selector(".ph-card.ph-active", timeout=5000)
                await sip.hangup()
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=5000)
                await pg.click("[data-flag=aa]")
            await step("Do not disturb (menu = top bar, kept on the server) rejects calls (486); AA answers by itself", dnd_and_aa())

            async def logs_and_contacts():
                await pg.click("[data-tab=logs]")
                rows = await pg.locator(".ph-logrow").count()
                expect(rows >= 8, f"call log: {rows} rows")
                expect(await pg.locator(".ph-logrow.s-rejected").count() >= 1, "rejected (DND) call not in the log")
                await pg.click("[data-tab=contacts]")
                await pg.wait_for_selector(".ph-ctrow[data-colleague='102']", timeout=4000)
                await pg.fill(".ph-ctsearch input", "Ivan")
                await pg.wait_for_selector(".ph-ctrow >> text=Ivan Sidorov", timeout=4000)
                await pg.click("[data-tab=phone]")
            await step("Logs keep every call (missed / rejected); Contacts list colleagues and customers", logs_and_contacts())

            async def second_tab():
                other = await ctx.new_page()
                await other.goto(base + "/")  # same browser: already signed in
                await other.wait_for_selector(".phone-btn", timeout=8000)
                await other.click(".phone-btn")
                await other.wait_for_selector(".ph-problem", timeout=5000)
                expect(await other.locator(".ph-problem .btn").count() == 1, "no 'use here' button in the second tab")
                await other.close()
            await step("Only one tab of the browser holds the phone (second tab offers to take it)", second_tab())

            async def wrong_password():
                bp = await (await browser.new_context(permissions=["microphone"])).new_page()
                await login(bp, "boris")
                await bp.wait_for_selector(".phone-btn.p-failed", timeout=10000)
                expect("REGISTER 403" in sip.log, "wrong SIP password was accepted")
            await step("Wrong SIP password is refused and shown as 'not connected'", wrong_password())

            async def no_errors():
                bad = [e for e in errors if "Content Security Policy" in e or "pageerror" in e]
                expect(not bad, f"browser errors: {bad[:3]}")
            await step("No JavaScript or CSP errors", no_errors())
            await browser.close()
    finally:
        demo.terminate()
        demo.wait(10)
        await sip.stop()
    ok = sum(1 for _, good, _ in RESULTS if good)
    print(f"\nPHONE E2E: {ok}/{len(RESULTS)} passed")
    return 0 if ok == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
