"""A tiny SIP-over-WebSocket server (RFC 7118) that behaves like FreePBX/Asterisk towards a browser phone.

Used by tests/e2e_phone.py to check the real WebRTC engine of Zenith Phone (JsSIP) without a PBX:
* REGISTER with digest authentication (401 challenge, MD5, qop=auth) — wrong password is refused;
* outgoing INVITE: 100 Trying, 180 Ringing, then 200 OK (or 486 Busy for the number "486"); ACK; BYE;
* incoming call on request: INVITE to the registered contact, waits for 200 OK, sends ACK; hang up with BYE;
* re-INVITE (hold / resume), REFER (blind transfer: 202 Accepted + NOTIFY 200), INFO (DTMF), CANCEL.
No media flows (there is no real RTP), but every SIP step and the SDP negotiation in the browser are real.
"""
import asyncio
import hashlib
import re
import uuid

import websockets

REALM = "zenith"


def md5(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


def parse(raw: str) -> tuple[str, dict, str]:
    head, _, body = raw.partition("\r\n\r\n")
    lines = head.split("\r\n")
    headers: dict[str, list[str]] = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers.setdefault(k.strip().lower(), []).append(v.strip())
    return lines[0], headers, body


def h(headers: dict, name: str) -> str:
    return (headers.get(name.lower()) or [""])[0]


def as_answer(sdp: str) -> str:
    """Turn the browser's own offer into an acceptable answer (same codecs / ICE / DTLS, we take the active role)."""
    return sdp.replace("a=setup:actpass", "a=setup:active")


class FakeSip:
    def __init__(self, users: dict[str, str]):
        self.users = users  # extension -> password
        self.log: list[str] = []  # "REGISTER 200", "INVITE 486", ...
        self.ws = None
        self.contact = ""
        self.registered = asyncio.Event()
        self.offer = ""
        self.dialog: dict | None = None  # the most recent call
        self.dialogs: dict[str, dict] = {}  # several calls at once (lines), by Call-ID
        self.answered = asyncio.Event()
        self.refer_to = ""
        self.dtmf: list[str] = []
        self.server = None
        self.port = 0

    async def start(self, port: int = 0) -> int:
        self.server = await websockets.serve(self.handle, "127.0.0.1", port, subprotocols=["sip"])
        self.port = self.server.sockets[0].getsockname()[1]
        return self.port

    async def stop(self) -> None:
        self.server.close()
        await self.server.wait_closed()

    async def send(self, text: str) -> None:
        await self.ws.send(text)

    def reply(self, req: dict, code: int, reason: str, extra: list[str] | None = None, body: str = "", to_tag: str = "") -> str:
        to = h(req, "to") + (f";tag={to_tag}" if to_tag and ";tag=" not in h(req, "to") else "")
        lines = [f"SIP/2.0 {code} {reason}"] + [f"Via: {v}" for v in req.get("via", [])] + [
            f"From: {h(req, 'from')}", f"To: {to}", f"Call-ID: {h(req, 'call-id')}", f"CSeq: {h(req, 'cseq')}"]
        lines += extra or []
        if body:
            lines += ["Content-Type: application/sdp"]
        lines += [f"Content-Length: {len(body.encode())}", "", body]
        return "\r\n".join(lines)

    # ------------------------------------------------------------------ browser -> us
    async def handle(self, ws):
        self.ws = ws
        async for raw in ws:
            if not isinstance(raw, str) or not raw.strip():
                continue
            first, hd, body = parse(raw)
            if first.startswith("SIP/2.0"):
                await self.on_response(first, hd, body)
                continue
            method = first.split(" ", 1)[0]
            try:
                await getattr(self, f"on_{method.lower()}", self.on_other)(first, hd, body)
            except Exception as exc:  # noqa: BLE001
                self.log.append(f"{method} error {exc}")

    async def on_register(self, first, hd, body):
        auth = h(hd, "authorization")
        if not auth:
            self.log.append("REGISTER 401")
            return await self.send(self.reply(hd, 401, "Unauthorized", [
                f'WWW-Authenticate: Digest realm="{REALM}", nonce="{uuid.uuid4().hex}", algorithm=MD5, qop="auth"']))
        p = dict(re.findall(r'(\w+)="?([^",]+)"?', auth))
        user = p.get("username", "")
        ha1 = md5(f"{user}:{REALM}:{self.users.get(user, '')}")
        ha2 = md5(f"REGISTER:{p.get('uri', '')}")
        expect = md5(f"{ha1}:{p.get('nonce')}:{p.get('nc')}:{p.get('cnonce')}:{p.get('qop')}:{ha2}")
        if user not in self.users or p.get("response") != expect:
            self.log.append("REGISTER 403")
            return await self.send(self.reply(hd, 403, "Forbidden"))
        self.contact = re.search(r"<([^>]+)>", h(hd, "contact")).group(1)
        self.log.append(f"REGISTER 200 {user}")
        self.registered.set()
        await self.send(self.reply(hd, 200, "OK", [f"Contact: {h(hd, 'contact')};expires=600", "Expires: 600"]))

    async def on_invite(self, first, hd, body):
        target = first.split(" ")[1].split("@")[0].replace("sip:", "")
        tag = uuid.uuid4().hex[:8]
        if ";tag=" in h(hd, "to"):  # re-INVITE inside the dialog (hold / resume / conference)
            self.log.append("re-INVITE " + ("sendonly" if "a=sendonly" in body else "sendrecv"))
            ans = as_answer(body).replace("a=sendonly", "a=recvonly")
            return await self.send(self.reply(hd, 200, "OK", ["Contact: <sip:pbx@127.0.0.1;transport=ws>"], ans))
        self.offer = body
        self.log.append(f"INVITE {target}")
        await self.send(self.reply(hd, 100, "Trying"))
        await asyncio.sleep(0.2)
        await self.send(self.reply(hd, 180, "Ringing", [], "", tag))
        await asyncio.sleep(0.8)
        if target == "486":
            self.log.append("INVITE 486")
            return await self.send(self.reply(hd, 486, "Busy Here", [], "", tag))
        self.dialog = {"call_id": h(hd, "call-id"), "local": h(hd, "to") + f";tag={tag}", "remote": h(hd, "from"),
                       "contact": re.search(r"<([^>]+)>", h(hd, "contact")).group(1), "cseq": 1, "uac": True, "target": target}
        self.dialogs[self.dialog["call_id"]] = self.dialog
        await self.send(self.reply(hd, 200, "OK", ["Contact: <sip:pbx@127.0.0.1;transport=ws>"], as_answer(body), tag))

    async def on_ack(self, first, hd, body):
        self.log.append("ACK")
        self.answered.set()

    async def on_bye(self, first, hd, body):
        d = self.dialogs.pop(h(hd, "call-id"), None)
        self.log.append(f"BYE from browser {d.get('target', '') if d else ''}".strip())
        if self.dialog and self.dialog["call_id"] == h(hd, "call-id"):
            self.dialog = None
        await self.send(self.reply(hd, 200, "OK"))

    async def on_cancel(self, first, hd, body):
        self.log.append("CANCEL")
        await self.send(self.reply(hd, 200, "OK"))

    async def on_refer(self, first, hd, body):
        self.refer_to = h(hd, "refer-to")
        self.log.append(f"REFER {self.refer_to}")
        await self.send(self.reply(hd, 202, "Accepted", ["Contact: <sip:pbx@127.0.0.1;transport=ws>"]))
        await asyncio.sleep(0.2)
        keep, self.dialog = self.dialog, self.dialogs.get(h(hd, "call-id"), self.dialog)
        await self.request("NOTIFY", ["Event: refer", "Subscription-State: terminated;reason=noresource",
                                      "Content-Type: message/sipfrag"], "SIP/2.0 200 OK")
        self.dialog = keep

    async def on_info(self, first, hd, body):
        m = re.search(r"Signal=\s*(\S)", body)
        if m:
            self.dtmf.append(m.group(1))
        await self.send(self.reply(hd, 200, "OK"))

    async def on_other(self, first, hd, body):
        await self.send(self.reply(hd, 200, "OK"))

    async def on_response(self, first, hd, body):
        code = int(first.split(" ")[1])
        method = h(hd, "cseq").split(" ")[-1]
        self.log.append(f"{method} {code} from browser")
        if method == "INVITE" and code >= 300 and self.dialog and not self.dialog.get("uac"):  # rejected: ACK it (same branch)
            d = self.dialog
            await self.send("\r\n".join([
                f"ACK {d['contact']} SIP/2.0", f"Via: SIP/2.0/WSS pbx.invalid;branch={d['branch']}", "Max-Forwards: 70",
                f"From: {d['local']}", f"To: {h(hd, 'to')}", f"Call-ID: {d['call_id']}", "CSeq: 1 ACK", "Content-Length: 0", "", ""]))
            self.dialogs.pop(d["call_id"], None)
            self.dialog = None
            return
        if method == "INVITE" and code == 200 and self.dialog and not self.dialog.get("uac"):
            self.dialog["local"] = h(hd, "from")
            self.dialog["remote"] = h(hd, "to")
            self.dialog["contact"] = re.search(r"<([^>]+)>", h(hd, "contact")).group(1)
            await self.send("\r\n".join([
                f"ACK {self.dialog['contact']} SIP/2.0", f"Via: SIP/2.0/WSS pbx.invalid;branch=z9hG4bK{uuid.uuid4().hex[:10]}",
                "Max-Forwards: 70", f"From: {self.dialog['local']}", f"To: {self.dialog['remote']}", f"Call-ID: {self.dialog['call_id']}",
                "CSeq: 1 ACK", "Content-Length: 0", "", ""]))
            self.answered.set()

    # ------------------------------------------------------------------ us -> browser
    async def request(self, method: str, extra: list[str], body: str = "") -> None:
        d = self.dialog
        if not d:
            return
        d["cseq"] += 1
        await self.send("\r\n".join([
            f"{method} {d['contact']} SIP/2.0", f"Via: SIP/2.0/WSS pbx.invalid;branch=z9hG4bK{uuid.uuid4().hex[:10]}", "Max-Forwards: 70",
            f"From: {d['local']}", f"To: {d['remote']}", f"Call-ID: {d['call_id']}", f"CSeq: {d['cseq'] + 100} {method}",
            *extra, f"Content-Length: {len(body.encode())}", "", body]))

    async def call_browser(self, caller: str = "+37491123456", name: str = "Aram Grigoryan") -> None:
        """An incoming call to the registered browser phone (uses an SDP offer the browser made earlier)."""
        call_id = uuid.uuid4().hex
        tag = uuid.uuid4().hex[:8]
        frm = f'"{name}" <sip:{caller}@{REALM}>;tag={tag}'
        branch = f"z9hG4bK{uuid.uuid4().hex[:10]}"
        self.dialog = {"call_id": call_id, "local": frm, "remote": f"<{self.contact}>", "contact": self.contact, "cseq": 1, "uac": False,
                       "branch": branch, "target": caller}
        self.dialogs[call_id] = self.dialog
        self.answered.clear()
        offer = self.offer
        self.log.append("INVITE to browser")
        await self.send("\r\n".join([
            f"INVITE {self.contact} SIP/2.0", f"Via: SIP/2.0/WSS pbx.invalid;branch={branch}", "Max-Forwards: 70",
            f"From: {frm}", f"To: <{self.contact}>", f"Call-ID: {call_id}", "CSeq: 1 INVITE",
            "Contact: <sip:pbx@127.0.0.1;transport=ws>", "Content-Type: application/sdp", f"Content-Length: {len(offer.encode())}", "", offer]))

    async def hangup(self, target: str | None = None) -> None:
        """The far end hangs up (the most recent call, or the call with this number)."""
        d = next((x for x in self.dialogs.values() if x.get("target") == target), None) if target else self.dialog
        if d:
            self.log.append("BYE to browser")
            keep, self.dialog = self.dialog, d
            await self.request("BYE", [])
            self.dialogs.pop(d["call_id"], None)
            self.dialog = keep if keep is not d else None
