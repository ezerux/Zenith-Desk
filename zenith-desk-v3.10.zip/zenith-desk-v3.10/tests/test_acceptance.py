"""Integration tests mapped to the acceptance criteria of the ТЗ (раздел 11)."""
import asyncio
import hashlib
import hmac
import json

from sqlalchemy import func, select

from app.models import CallRecord, IntegrationEvent, WorkSession

from .conftest import IF1, IF2, QUEUES, build_env


async def state(env, headers) -> dict:
    r = await env.client.get("/api/agents/me/state", headers=headers)
    assert r.status_code == 200, r.text
    return r.json()


async def start(env, headers, tid, mode, **kw):
    return await env.client.post(f"/api/tickets/{tid}/start", json={"work_mode": mode}, headers=headers, **kw)


async def ready(env, h):
    r = await env.client.post("/api/agents/me/ready", headers=h)
    assert r.status_code == 200, r.text
    return r.json()


# --- 1. входящий вызов: поиск клиента по номеру --------------------------------------------
async def test_incoming_call_finds_customer(env):
    h = await env.login("anna")
    q = asyncio.Queue()
    env.services.broker._agent_subs[1].add(q)
    await env.services.calls.handle_event({
        "Event": "AgentCalled", "Queue": "400", "Interface": IF1, "CallerIDNum": "89123456789",
        "CallerIDName": "Ivan", "Uniqueid": "1700.1", "Linkedid": "1700.1",
    })
    events = []
    while not q.empty():
        events.append(q.get_nowait())
    assert ("changed", {"topics": ["calls"]}) in events          # v2.7 live mode: the calls list refreshes too
    event, data = next(x for x in events if x[0] == "call_ringing")
    assert data["customers"][0]["id"] == 50 and data["call"]["caller_normalized"] == "79123456789"
    # unknown number -> no customers; operator can create one
    r = await env.client.get("/api/customers/lookup", params={"phone": "+7 999 000-00-00"}, headers=h)
    assert r.json()["customers"] == []
    r = await env.client.post("/api/customers", json={"firstname": "Новый", "phone": "+79990000000"}, headers=h)
    assert r.status_code == 200 and r.json()["customer"]["roles"] == ["Customer"]


async def test_ticket_after_call_contains_call_data_and_starts(env):
    h = await env.login("anna")
    await ready(env, h)
    for ev in ({"Event": "AgentCalled", "Queue": "400", "Interface": IF1, "CallerIDNum": "89123456789",
                "Uniqueid": "1700.2", "Linkedid": "1700.2"},
               {"Event": "AgentConnect", "Queue": "400", "Interface": IF1, "Uniqueid": "1700.2", "Linkedid": "1700.2"},
               {"Event": "VarSet", "Variable": "MIXMONITOR_FILENAME", "Value": "/var/spool/asterisk/monitor/x.wav",
                "Uniqueid": "1700.2", "Linkedid": "1700.2"},
               {"Event": "AgentComplete", "Queue": "400", "Interface": IF1, "Uniqueid": "1700.2", "Linkedid": "1700.2"}):
        await env.services.calls.handle_event(ev)
    calls = (await env.client.get("/api/agents/me/calls", headers=h)).json()
    assert calls[0]["state"] == "ended" and calls[0]["recording_file"].endswith("x.wav")
    r = await env.client.post("/api/tickets", headers=h, json={
        "title": "Не работает доступ", "customer_id": 50, "body": "Описание", "call_id": calls[0]["id"],
        "start_mode": "blocking"})
    assert r.status_code == 200, r.text
    tid = r.json()["ticket"]["id"]
    art = next(a for a in env.zammad.articles if a["ticket_id"] == tid)
    assert "1700.2" in art["body"] and "x.wav" in art["body"] and art["type"] == "phone"
    assert r.json()["agent_state"]["computed_state"] == "busy_task"
    assert env.pbx.is_paused(IF1)


# --- 2,3. blocking ставит паузу (после подтверждения), background — нет -------------------------
async def test_blocking_pauses_after_confirmation_background_does_not(env):
    h = await env.login("anna")
    await ready(env, h)
    assert not env.pbx.is_paused(IF1)
    t_bg = env.zammad.add_ticket("Фон", owner_id=10, state="open")
    r = await start(env, h, t_bg["id"], "background")
    assert r.status_code == 200 and r.json()["agent_state"]["phone_status"] == "receiving"
    assert not env.pbx.is_paused(IF1)

    t = env.zammad.add_ticket("Блок", owner_id=10, state="open")
    r = await start(env, h, t["id"], "blocking")
    body = r.json()
    assert body["agent_state"]["computed_state"] == "busy_task"
    assert body["agent_state"]["confirmed"] is True and body["agent_state"]["phone_status"] == "paused"
    assert all(env.pbx.members[q][IF1]["paused"] for q in QUEUES)
    assert not env.pbx.is_paused(IF2)  # other operators untouched


async def test_unconfirmed_pause_is_not_reported_as_done(env):
    h = await env.login("anna")
    await ready(env, h)
    env.pbx.ignore_commands = True  # Asterisk "accepts" but state does not change
    t = env.zammad.add_ticket("Блок", owner_id=10, state="open")
    r = await start(env, h, t["id"], "blocking")
    st = r.json()["agent_state"]
    assert st["sync_status"] == "error" and st["confirmed"] is False
    assert "did not confirm" in st["sync_error"]


# --- 4. два blocking: завершение одного не возвращает в очередь ----------------------------------
async def test_two_blocking_complete_one_stays_paused(env):
    h = await env.login("anna")
    await ready(env, h)
    t1 = env.zammad.add_ticket("A", owner_id=10, state="open")
    t2 = env.zammad.add_ticket("B", owner_id=10, state="open")
    await start(env, h, t1["id"], "blocking")
    await start(env, h, t2["id"], "blocking")
    r = await env.client.post(f"/api/tickets/{t1['id']}/complete", json={}, headers=h)
    assert r.status_code == 200, r.text
    assert env.zammad.state_of(t1["id"]) == "closed"
    assert r.json()["agent_state"]["computed_state"] == "busy_task" and env.pbx.is_paused(IF1)
    r = await env.client.post(f"/api/tickets/{t2['id']}/complete", json={}, headers=h)
    assert r.json()["agent_state"]["computed_state"] == "ready" and not env.pbx.is_paused(IF1)


# --- 5. только background и нет перерыва -> доступен ---------------------------------------------
async def test_only_background_is_available(env):
    h = await env.login("anna")
    await ready(env, h)
    for i in range(2):
        t = env.zammad.add_ticket(f"bg{i}", owner_id=10, state="open")
        await start(env, h, t["id"], "background")
    s = await state(env, h)
    assert s["display_state"] == "ready" and s["phone_status"] == "receiving"
    tasks = (await env.client.get("/api/agents/me/tasks", headers=h)).json()
    assert len(tasks["background"]) == 2 and tasks["blocking"] == []


# --- 6. тикет из email/Telegram/WhatsApp можно начать в любом режиме ------------------------------
async def test_messenger_ticket_unassigned_gets_assigned(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("Из Telegram", owner_id=1, state="new", article_type="telegram personal-message")
    unassigned = (await env.client.get("/api/tickets/unassigned", headers=h)).json()["tickets"]
    assert any(x["id"] == t["id"] and x["source"] == "telegram" for x in unassigned)
    r = await start(env, h, t["id"], "background")
    assert r.status_code == 200 and r.json()["session"]["source"] == "telegram"
    assert env.zammad.tickets[t["id"]]["owner_id"] == 10 and env.zammad.state_of(t["id"]) == "open"
    # «Фоновая задача» <-> blocking switch
    r = await env.client.post(f"/api/tickets/{t['id']}/mode", json={"work_mode": "blocking"}, headers=h)
    assert r.json()["agent_state"]["computed_state"] == "busy_task"


async def test_cannot_start_ticket_of_another_operator(env):
    h = await env.login("anna")
    t = env.zammad.add_ticket("чужой", owner_id=11, state="open")
    r = await start(env, h, t["id"], "blocking")
    assert r.status_code == 409


# --- 7. повтор webhook не создаёт дубликатов ----------------------------------------------------
def sign(body: bytes, secret="hooksecret") -> str:
    return "sha1=" + hmac.new(secret.encode(), body, hashlib.sha1).hexdigest()


async def test_webhook_signature_and_deduplication(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    env.zammad.tickets[t["id"]]["state_id"] = 4  # closed directly in Zammad
    body = json.dumps({"ticket": {"id": t["id"], "state": "closed"}}).encode()
    bad = await env.client.post("/api/integrations/zammad/webhook", content=body, headers={"X-Hub-Signature": "sha1=00"})
    assert bad.status_code == 401
    hdrs = {"X-Hub-Signature": sign(body), "X-Zammad-Delivery": "d-1", "Content-Type": "application/json"}
    r1 = await env.client.post("/api/integrations/zammad/webhook", content=body, headers=hdrs)
    r2 = await env.client.post("/api/integrations/zammad/webhook", content=body, headers=hdrs)
    assert r1.json()["status"] == "accepted" and r2.json()["status"] == "duplicate"
    for _ in range(50):
        await asyncio.sleep(0.02)
        if not env.pbx.is_paused(IF1):
            break
    async with env.services.db.sessionmaker() as s:
        n = (await s.execute(select(func.count()).select_from(IntegrationEvent).where(IntegrationEvent.source == "zammad"))).scalar()
        ws = (await s.execute(select(WorkSession))).scalars().all()
    assert n == 1 and len(ws) == 1 and ws[0].state == "completed"
    assert not env.pbx.is_paused(IF1)


async def test_repeated_ui_command_is_idempotent(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    hk = {**h, "Idempotency-Key": "k-1"}
    env.pbx.commands.clear()
    r1 = await start(env, hk, t["id"], "blocking")
    r2 = await start(env, hk, t["id"], "blocking")
    r3 = await start(env, h, t["id"], "blocking")  # same command without key
    assert r1.status_code == r2.status_code == r3.status_code == 200
    assert r2.json().get("idempotent_replay") and r3.json().get("idempotent")
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(select(func.count()).select_from(WorkSession))).scalar() == 1
    pauses = [c for c in env.pbx.commands if c[1] == IF1 and c[2]]
    assert len(pauses) == len(QUEUES)  # no duplicate pause commands


# --- 8. AMI недоступен -> ошибка/синхронизация, после восстановления — сверка ---------------------
async def test_ami_down_then_recovery(env):
    h = await env.login("anna")
    await ready(env, h)
    env.pbx.connected_flag = False
    await env.services.engine.on_ami_disconnect()
    s = await state(env, h)
    assert s["sync_status"] == "error" and s["display_state"] == "ready_unconfirmed" and s["confirmed"] is False
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    r = await start(env, h, t["id"], "blocking")
    assert r.status_code == 200 and r.json()["agent_state"]["phone_status"] == "unknown"
    env.pbx.connected_flag = True
    await env.services.engine.on_ami_connect()
    s = await state(env, h)
    assert s["sync_status"] == "ok" and s["phone_status"] == "paused" and env.pbx.is_paused(IF1)


async def test_retry_with_backoff(env):
    h = await env.login("anna")
    await ready(env, h)
    env.pbx.connected_flag = False
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    s = await state(env, h)
    assert s["next_retry_at"] is not None
    env.pbx.connected_flag = True
    await asyncio.sleep(1.1)
    await env.services.engine.tick()
    assert env.pbx.is_paused(IF1) and (await state(env, h))["sync_status"] == "ok"


# --- 9. перезапуск: состояние из БД, согласование с Asterisk --------------------------------------
async def test_restart_restores_and_reconciles(env, tmp_path):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    assert env.pbx.is_paused(IF1)
    # while the service is down somebody unpauses the member in Asterisk
    for q in QUEUES:
        env.pbx.members[q][IF1] = {"paused": False, "reason": ""}
    env2 = await build_env(tmp_path, db=env.services.db, pbx=env.pbx, fz=env.zammad, seed=False)
    await env2.services.engine.reconcile_all("startup")
    assert env.pbx.is_paused(IF1)
    async with env2.services.db.sessionmaker() as s:
        assert (await s.execute(select(WorkSession))).scalars().one().state == "active"
    await env2.client.aclose()


async def test_never_unpause_when_state_unknown(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    env.pbx.connected_flag = False
    r = await env.client.post(f"/api/tickets/{t['id']}/complete", json={}, headers=h)
    assert r.json()["agent_state"]["computed_state"] == "ready"
    assert r.json()["agent_state"]["display_state"] == "ready_unconfirmed"
    assert env.pbx.is_paused(IF1)  # still paused, nothing was sent blindly


# --- 10. руководитель видит статус и причину ------------------------------------------------------
async def test_supervisor_sees_reasons_and_override_is_audited(env):
    ha = await env.login("anna")
    hb = await env.login("boss")
    await ready(env, ha)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, ha, t["id"], "blocking")
    r = await env.client.get("/api/admin/agents", headers=hb)
    anna = next(a for a in r.json()["agents"] if a["agent_id"] == 1)
    assert anna["computed_state"] == "busy_task" and t["number"] in anna["reason"] and len(anna["blocking"]) == 1
    assert (await env.client.get("/api/admin/agents", headers=ha)).status_code == 403
    bad = await env.client.post("/api/admin/agents/1/override", json={"manual_state": "ready", "ignore_blocking": True, "reason": ""}, headers=hb)
    assert bad.status_code == 422
    r = await env.client.post("/api/admin/agents/1/override",
                              json={"manual_state": "ready", "ignore_blocking": True, "reason": "Пиковая нагрузка"}, headers=hb)
    assert r.json()["computed_state"] == "ready" and not env.pbx.is_paused(IF1)
    audit = (await env.client.get("/api/admin/audit", params={"agent_id": 1}, headers=hb)).json()
    assert any(a["action"] == "supervisor_override" and a["details"]["reason"] == "Пиковая нагрузка" for a in audit)


# --- 11. ручной перерыв не снимается при закрытии тикета ------------------------------------------
async def test_break_survives_ticket_completion(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    await env.client.post("/api/agents/me/break", headers=h)
    r = await env.client.post(f"/api/tickets/{t['id']}/complete", json={}, headers=h)
    assert r.json()["agent_state"]["computed_state"] == "break" and env.pbx.is_paused(IF1)


async def test_manual_ready_cannot_bypass_blocking(env):
    h = await env.login("anna")
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    r = await env.client.post("/api/agents/me/ready", headers=h)
    assert r.status_code == 409 and r.json()["detail"]["blocking_tickets"] == [t["number"]]


# --- дополнительные сценарии ---------------------------------------------------------------------
async def test_external_pause_is_respected(env):
    h = await env.login("anna")
    await ready(env, h)
    env.pbx.members["400"][IF1] = {"paused": True, "reason": "phone *46"}
    s = (await env.client.post("/api/admin/agents/1/reconcile", headers=await env.login("boss"))).json()
    assert env.pbx.members["400"][IF1]["paused"] and s["display_state"] == "external_pause"


async def test_pending_state_in_zammad_turns_blocking_into_background(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    env.zammad.tickets[t["id"]]["state_id"] = 3  # pending reminder ("Ожидание клиента")
    await env.services.workflow.reconcile_zammad()  # periodic reconcile, no webhook needed
    tasks = (await env.client.get("/api/agents/me/tasks", headers=h)).json()
    assert len(tasks["background"]) == 1 and not env.pbx.is_paused(IF1)


async def test_reassigned_in_zammad_cancels_session(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    env.zammad.tickets[t["id"]]["owner_id"] = 11
    await env.services.workflow.reconcile_zammad()
    assert not env.pbx.is_paused(IF1)


async def test_ticket_type_required_fields(env):
    hb = await env.login("boss")
    # supervisor is not admin -> forbidden
    r = await env.client.put("/api/admin/ticket-types/Заказ", headers=hb, json={"name": "Заказ", "zammad_value": "order"})
    assert r.status_code == 403
    async with env.services.db.sessionmaker() as s:
        from app.models import TicketType
        s.add(TicketType(name="Заказ", zammad_value="order", required_fields=[{"name": "order_no", "label": "Номер заказа"}]))
        await s.commit()
    h = await env.login("anna")
    t = env.zammad.add_ticket("Заказ", owner_id=10, state="open", type="order")
    r = await start(env, h, t["id"], "blocking")
    assert r.status_code == 422 and "Номер заказа" in r.json()["detail"]["message"]
    r = await env.client.patch(f"/api/tickets/{t['id']}/fields", json={"fields": {"order_no": "A-1"}}, headers=h)
    assert r.status_code == 200
    assert (await start(env, h, t["id"], "blocking")).status_code == 200


async def test_wrap_up(tmp_path):
    env = await build_env(tmp_path, wrap_up_seconds=1)
    h = await env.login("anna")
    await ready(env, h)
    await env.services.calls.handle_event({"Event": "AgentComplete", "Queue": "400", "Interface": IF1,
                                           "Uniqueid": "9.1", "Linkedid": "9.1"})
    assert (await state(env, h))["computed_state"] == "wrap_up" and env.pbx.is_paused(IF1)
    await asyncio.sleep(1.1)
    await env.services.engine.tick()
    assert (await state(env, h))["computed_state"] == "ready" and not env.pbx.is_paused(IF1)
    await env.client.aclose()


async def test_report_and_direct_calls(env):
    h = await env.login("anna")
    await ready(env, h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await start(env, h, t["id"], "blocking")
    await env.client.post(f"/api/tickets/{t['id']}/complete", json={}, headers=h)
    await env.services.calls.handle_event({"Event": "DialBegin", "Channel": "PJSIP/trunk-0001",
                                           "DestChannel": "PJSIP/101-0002", "CallerIDNum": "+79123456789",
                                           "Uniqueid": "5.1", "Linkedid": "5.1"})
    await env.services.calls.handle_event({"Event": "Hangup", "Uniqueid": "5.1", "Linkedid": "5.1"})
    async with env.services.db.sessionmaker() as s:
        c = (await s.execute(select(CallRecord).where(CallRecord.linkedid == "5.1"))).scalars().one()
    assert c.agent_id == 1 and c.state == "missed"
    rep = (await env.client.get("/api/admin/reports/summary", headers=await env.login("boss"))).json()
    anna = next(a for a in rep["agents"] if a["agent_id"] == 1)
    assert anna["sessions_completed"] == 1 and "busy_task" in anna["queue_paused_by_reason_sec"]


async def test_login_rejects_wrong_password_and_unknown_user(env):
    r = await env.client.post("/api/auth/login", json={"username": "anna", "password": "bad"})
    assert r.status_code == 401
    r = await env.client.post("/api/auth/login", json={"username": "stranger", "password": "pw"})
    assert r.status_code == 401
    r = await env.client.post("/api/auth/login", json={"username": " Anna ", "password": "pw"})
    assert r.status_code == 200


async def test_operator_cannot_start_ticket_outside_his_groups(env):
    h = await env.login("anna")
    t = env.zammad.add_ticket("Чужая группа", owner_id=1, state="new")
    env.zammad.no_access.add((10, t["id"]))
    r = await start(env, h, t["id"], "blocking")
    assert r.status_code == 404 and env.zammad.tickets[t["id"]]["owner_id"] == 1
    assert (await env.client.get(f"/api/tickets/{t['id']}", headers=h)).status_code == 404
