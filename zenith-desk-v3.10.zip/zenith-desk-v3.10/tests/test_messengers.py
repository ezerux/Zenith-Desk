"""v3.9 Telegram and WhatsApp chats (one company bot / number), against simulators of the real APIs."""
import asyncio
import base64
import hashlib
import hmac
import json
import socket
import threading
import time

import httpx
import pytest
import uvicorn
from sqlalchemy import select

from app.models import MsgConversation, MsgMessage
from scripts.sim_messengers import TG_TOKEN, WA_PHONE_ID, WA_TOKEN, build_sim


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


@pytest.fixture(scope="module")
def sim():
    port = free_port()
    server = uvicorn.Server(uvicorn.Config(build_sim(), host="127.0.0.1", port=port, log_level="warning"))
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    yield f"http://127.0.0.1:{port}"
    server.should_exit = True
    t.join(5)


async def until(cond, timeout=8.0, what=""):
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        r = cond()
        if asyncio.iscoroutine(r):
            r = await r
        if r:
            return r
        await asyncio.sleep(0.05)
    raise AssertionError(f"timeout: {what}")


async def reset_sim(sim):
    async with httpx.AsyncClient() as c:
        assert (await c.post(sim + "/sim/reset")).status_code == 200


async def setup(env, sim, telegram=True, whatsapp=True, mode="polling"):
    await reset_sim(sim)  # the simulator is shared by the module: start every test from an empty bot / number
    cfg = env.settings
    cfg.telegram_enabled, cfg.telegram_bot_token, cfg.telegram_mode, cfg.telegram_api_base = telegram, TG_TOKEN, mode, sim + "/telegram"
    cfg.whatsapp_enabled, cfg.whatsapp_access_token, cfg.whatsapp_phone_number_id = whatsapp, WA_TOKEN, WA_PHONE_ID
    cfg.whatsapp_app_secret, cfg.whatsapp_api_base, cfg.public_url = "app-secret-1", sim + "/graph", ""
    cfg.messenger_quick_replies = "Hello | Hello, {name}! How can I help?\nDelivery | Delivery takes 2 days"
    cfg.whatsapp_templates = "hello_followup:ru"
    await env.services.messengers.start()


async def convs(env, channel=None):
    async with env.services.db.sessionmaker() as s:
        q = select(MsgConversation)
        if channel:
            q = q.where(MsgConversation.channel == channel)
        return (await s.execute(q)).scalars().all()


def signed(body: dict, secret="app-secret-1") -> tuple[bytes, dict]:
    raw = json.dumps(body).encode()
    return raw, {"X-Hub-Signature-256": "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest(), "Content-Type": "application/json"}


def wa_message(frm="37491123456", name="Aram Grigoryan", text="Hello", mid=None, ts=None):
    return {"object": "whatsapp_business_account", "entry": [{"id": "1", "changes": [{"field": "messages", "value": {
        "messaging_product": "whatsapp", "metadata": {"display_phone_number": "37410555000", "phone_number_id": WA_PHONE_ID},
        "contacts": [{"profile": {"name": name}, "wa_id": frm}],
        "messages": [{"from": frm, "id": mid or f"wamid.{time.time_ns()}", "timestamp": str(ts or int(time.time())), "type": "text", "text": {"body": text}}]}}]}]}


async def test_telegram_long_polling_receive_answer_files_and_zammad_ticket(env, sim):
    await setup(env, sim, whatsapp=False)
    try:
        h = await env.login("anna")
        async with httpx.AsyncClient() as c:
            await c.post(sim + "/sim/telegram/message", json={"chat_id": 555001, "first_name": "Maria", "last_name": "Kuznetsova",
                                                              "username": "maria_k", "text": "Здравствуйте! Где мой заказ?"})
            photo = base64.b64encode(b"\xff\xd8\xff fake jpeg " * 50).decode()
            await c.post(sim + "/sim/telegram/message", json={"chat_id": 555001, "first_name": "Maria", "photo": photo, "text": "Вот фото"})
            conv = (await until(lambda: convs(env, "telegram"), what="conversation"))[0]
            assert conv.name == "Maria Kuznetsova" and conv.handle == "@maria_k" and conv.status == "open"

            async def both_arrived():
                return (await env.client.get("/api/msg/conversations", headers=h)).json()["items"][0]["unread"] == 2
            await until(both_arrived, what="second message")
            r = await env.client.get("/api/msg/conversations", headers=h)
            item = r.json()["items"][0]
            assert item["channel"] == "telegram" and item["unread"] == 2 and r.json()["counts"]["telegram"] == 1

            async def photo_arrived():
                d = (await env.client.get(f"/api/msg/conversations/{conv.id}", headers=h)).json()
                fs = [f for m in d["messages"] for f in m["files"] if f.get("key")]
                return fs and d
            d = await until(photo_arrived, what="photo downloaded from Telegram")
            texts = [m["text"] for m in d["messages"]]
            assert texts[:2] == ["Здравствуйте! Где мой заказ?", "Вот фото"]
            key = [f for m in d["messages"] for f in m["files"] if f.get("key")][0]["key"]
            f = await env.client.get(f"/api/msg/files/{key}", headers=h)
            assert f.status_code == 200 and f.content == b"\xff\xd8\xff fake jpeg " * 50
            assert d["quick_replies"][0]["title"] == "Hello"

            # answer: text + a file; whoever answers first takes the chat
            r = await env.client.post(f"/api/msg/conversations/{conv.id}/messages", headers=h,
                                      json={"text": "Добрый день, Мария! Заказ передан курьеру."})
            assert r.status_code == 200 and r.json()["status"] == "sent", r.text
            pdf = base64.b64encode(b"%PDF-1.4 invoice").decode()
            r = await env.client.post(f"/api/msg/conversations/{conv.id}/messages", headers=h,
                                      json={"text": "Счёт", "files": [{"name": "invoice.pdf", "mime": "application/pdf", "data": pdf}]})
            assert r.json()["status"] == "sent"
            sent = (await c.get(sim + "/sim/telegram/sent")).json()["sent"]
            assert sent[0]["chat_id"] == "555001" and sent[0]["text"].startswith("Добрый день")
            assert sent[1]["method"] == "sendDocument" and sent[1]["file"]["name"] == "invoice.pdf" and sent[1]["text"] == "Счёт"
            async with env.services.db.sessionmaker() as s:
                c2 = await s.get(MsgConversation, conv.id)
                assert c2.assignee_id == 1 and c2.unread == 0

            # boris (operator) cannot answer a chat Anna took; a note is fine
            hb = await env.login("boris")
            r = await env.client.post(f"/api/msg/conversations/{conv.id}/messages", headers=hb, json={"text": "me too"})
            assert r.status_code == 409
            r = await env.client.post(f"/api/msg/conversations/{conv.id}/messages", headers=hb, json={"text": "VIP!", "note": True})
            assert r.status_code == 200 and r.json()["direction"] == "note"

            # every message is copied into a Zammad ticket (customer created, sender / internal flags right)
            await env.services.messengers.mirror_pending()
            async with env.services.db.sessionmaker() as s:
                c2 = await s.get(MsgConversation, conv.id)
                msgs = (await s.execute(select(MsgMessage).where(MsgMessage.conversation_id == conv.id))).scalars().all()
            assert c2.zammad_ticket_id and all(m.mirrored for m in msgs if m.direction != "event")
            t = env.zammad.tickets[c2.zammad_ticket_id]
            assert t["title"] == "Telegram: Maria Kuznetsova"
            cust = env.zammad.users[c2.zammad_customer_id]
            assert "telegram:555001" in cust["note"]
            arts = [a for a in env.zammad.articles if a.get("ticket_id") == c2.zammad_ticket_id]
            assert len(arts) == 5 and any(a.get("internal") for a in arts) and any(a.get("attachments") for a in arts)

            # the same Telegram update twice (Telegram retries) → no double message
            n = len(msgs)
            upd = {"update_id": 1, "message": {"message_id": int(c2.external_id) if False else 99999, "chat": {"id": 555001, "type": "private"},
                                                "from": {"id": 555001, "first_name": "Maria"}, "date": 1, "text": "again"}}
            assert await env.services.messengers.handle_telegram_update(upd) is True
            assert await env.services.messengers.handle_telegram_update(upd) is False
            async with env.services.db.sessionmaker() as s:
                assert len((await s.execute(select(MsgMessage).where(MsgMessage.conversation_id == conv.id))).scalars().all()) == n + 1

            # close → the Zammad ticket is closed; a new message reopens the chat and starts a new ticket
            r = await env.client.post(f"/api/msg/conversations/{conv.id}/status", headers=h, json={"status": "closed"})
            assert r.json()["status"] == "closed"
            assert env.zammad.STATES[env.zammad.tickets[c2.zammad_ticket_id]["state_id"]] == "closed"
            await c.post(sim + "/sim/telegram/message", json={"chat_id": 555001, "first_name": "Maria", "text": "Ещё вопрос"})
            await until(lambda: convs(env, "telegram"), what="")
            conv3 = await until(lambda: _reopened(env, conv.id), what="reopened")
            await env.services.messengers.mirror_pending()
            async with env.services.db.sessionmaker() as s:
                c3 = await s.get(MsgConversation, conv.id)
            assert c3.status == "open" and c3.zammad_ticket_id != c2.zammad_ticket_id
            assert env.services.hub.items["telegram"].realtime == "on"
    finally:
        await env.services.messengers.stop()


async def _reopened(env, cid):
    async with env.services.db.sessionmaker() as s:
        c = await s.get(MsgConversation, cid)
        return c if c.status == "open" else None


async def test_telegram_webhook_secret_and_fallback_recovers_missed_updates(env, sim):
    await reset_sim(sim)
    env.settings.public_url = "http://127.0.0.1:1"   # Telegram cannot reach us (simulated network failure)
    cfg = env.settings
    cfg.telegram_enabled, cfg.telegram_bot_token, cfg.telegram_mode, cfg.telegram_api_base = True, TG_TOKEN, "webhook", sim + "/telegram"
    await env.services.messengers.start()
    try:
        async with httpx.AsyncClient() as c:
            await until(lambda: _webhook_set(c, sim), what="webhook registered at Telegram")
            # wrong / missing secret header → refused
            upd = {"update_id": 5, "message": {"message_id": 1, "chat": {"id": 777, "type": "private"}, "from": {"id": 777, "first_name": "Ivan"}, "date": 1, "text": "hi"}}
            assert (await env.client.post("/api/integrations/telegram/webhook", json=upd)).status_code == 401
            assert (await env.client.post("/api/integrations/telegram/webhook", json=upd, headers={"X-Telegram-Bot-Api-Secret-Token": "x"})).status_code == 401
            r = await env.client.post("/api/integrations/telegram/webhook", json=upd, headers={"X-Telegram-Bot-Api-Secret-Token": cfg.telegram_webhook_secret})
            assert r.status_code == 200 and len(await convs(env, "telegram")) == 1
            # two messages while our server is unreachable: they wait at Telegram
            await c.post(sim + "/sim/telegram/break_webhook", json={"on": True})
            for txt in ("lost 1", "lost 2"):
                await c.post(sim + "/sim/telegram/message", json={"chat_id": 888, "first_name": "Lost", "text": txt})
            assert (await c.get(sim + "/sim/telegram/sent")).json()["pending"] == 2
            await c.post(sim + "/sim/telegram/break_webhook", json={"on": False})
            res = await env.services.hub.poll("telegram")      # fallback check
            assert res["last_recovered"] >= 2, res
            lost = [x for x in await convs(env, "telegram") if x.external_id == "888"]
            assert lost and (await c.get(sim + "/sim/telegram/sent")).json()["webhook"], "webhook must be restored"
    finally:
        await env.services.messengers.stop()


async def _webhook_set(c, sim):
    return (await c.get(sim + "/sim/telegram/sent")).json()["webhook"]


async def test_whatsapp_webhook_signature_window_templates_statuses_retry(env, sim):
    await setup(env, sim, telegram=False)
    try:
        h = await env.login("anna")
        # Meta's verification call
        tok = env.settings.whatsapp_verify_token
        r = await env.client.get(f"/api/integrations/whatsapp/webhook?hub.mode=subscribe&hub.verify_token={tok}&hub.challenge=12345")
        assert r.status_code == 200 and r.text == "12345"
        assert (await env.client.get("/api/integrations/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=bad&hub.challenge=1")).status_code == 403
        # unsigned / wrongly signed → refused
        raw, hd = signed(wa_message())
        assert (await env.client.post("/api/integrations/whatsapp/webhook", content=raw, headers={"Content-Type": "application/json"})).status_code == 401
        assert (await env.client.post("/api/integrations/whatsapp/webhook", content=raw, headers={**hd, "X-Hub-Signature-256": "sha256=00"})).status_code == 401
        env.zammad.add_user(60, "aram", firstname="Aram", phone="+374 91 123456")  # known customer: found by phone
        mid = "wamid.TEST1"
        raw, hd = signed(wa_message(text="Можно оплатить картой?", mid=mid))
        assert (await env.client.post("/api/integrations/whatsapp/webhook", content=raw, headers=hd)).status_code == 200
        assert (await env.client.post("/api/integrations/whatsapp/webhook", content=raw, headers=hd)).status_code == 200  # Meta retry
        conv = (await convs(env, "whatsapp"))[0]
        assert conv.phone == "+37491123456" and conv.name == "Aram Grigoryan"
        d = (await env.client.get(f"/api/msg/conversations/{conv.id}", headers=h)).json()
        assert len(d["messages"]) == 1 and d["conversation"]["window_open"] and d["templates"] == [{"name": "hello_followup", "language": "ru"}]
        # answer → sent; the simulator reports delivered / read through signed status webhooks
        async with httpx.AsyncClient() as c:
            await c.post(sim + "/sim/whatsapp/config", json={"webhook_url": "http://invalid.local/x", "app_secret": "app-secret-1"})
            r = await env.client.post(f"/api/msg/conversations/{conv.id}/messages", headers=h, json={"text": "Да, курьеру картой."})
            assert r.json()["status"] == "sent", r.text
            sent = (await c.get(sim + "/sim/whatsapp/sent")).json()["sent"]
            assert sent[-1]["to"] == "37491123456" and sent[-1]["text"] == "Да, курьеру картой."
        msg_ext = sent[-1]["id"]
        for st in ("sent", "delivered", "read"):
            raw, hd = signed({"entry": [{"changes": [{"value": {"metadata": {"phone_number_id": WA_PHONE_ID},
                                                                "statuses": [{"id": msg_ext, "status": st, "recipient_id": "37491123456"}]}}]}]})
            await env.client.post("/api/integrations/whatsapp/webhook", content=raw, headers=hd)
        d = (await env.client.get(f"/api/msg/conversations/{conv.id}", headers=h)).json()
        assert d["messages"][-1]["status"] == "read"
        # the chat ticket uses the customer found by phone
        await env.services.messengers.mirror_pending()
        async with env.services.db.sessionmaker() as s:
            assert (await s.get(MsgConversation, conv.id)).zammad_customer_id == 60

        # 24 hours later: free text is refused, an approved template works
        old = int(time.time()) - 25 * 3600
        raw, hd = signed(wa_message(frm="37477000111", name="Old Customer", text="old", ts=old))
        await env.client.post("/api/integrations/whatsapp/webhook", content=raw, headers=hd)
        old_conv = [x for x in await convs(env, "whatsapp") if x.external_id == "37477000111"][0]
        async with env.services.db.sessionmaker() as s:
            oc = await s.get(MsgConversation, old_conv.id)
            from datetime import datetime, timezone
            oc.last_inbound_at = datetime.fromtimestamp(old, tz=timezone.utc)
            await s.commit()
        r = await env.client.post(f"/api/msg/conversations/{old_conv.id}/messages", headers=h, json={"text": "Hello again"})
        assert r.status_code == 409 and "whatsapp_window" in r.text
        r = await env.client.post(f"/api/msg/conversations/{old_conv.id}/messages", headers=h, json={"template": "hello_followup:ru"})
        assert r.status_code == 200 and r.json()["status"] == "sent"
        async with httpx.AsyncClient() as c:
            last = (await c.get(sim + "/sim/whatsapp/sent")).json()["sent"][-1]
        assert last["type"] == "template" and last["template"] == {"name": "hello_followup", "language": {"code": "ru"}}

        # WhatsApp is down: the message waits in the outbox and goes out by itself later
        env.services.messengers.wa.root = "http://127.0.0.1:1/v21.0"
        r = await env.client.post(f"/api/msg/conversations/{conv.id}/messages", headers=h, json={"text": "after outage"})
        assert r.json()["status"] == "queued" and r.json()["error"]
        env.services.messengers.wa.root = sim + "/graph/v21.0"
        res = await env.services.hub.poll("whatsapp")
        assert res["last_recovered"] >= 1 and res["ok"], res
        d = (await env.client.get(f"/api/msg/conversations/{conv.id}", headers=h)).json()
        assert d["messages"][-1]["text"] == "after outage" and d["messages"][-1]["status"] == "sent"
    finally:
        await env.services.messengers.stop()


async def test_assign_transfer_counts_and_admin_test(env, sim):
    await setup(env, sim)
    try:
        h, hb, hr = await env.login("anna"), await env.login("boris"), None
        raw, hd = signed(wa_message(frm="37499111222", name="Lilit", text="Hi"))
        await env.client.post("/api/integrations/whatsapp/webhook", content=raw, headers=hd)
        conv = (await convs(env, "whatsapp"))[0]
        assert (await env.client.get("/api/msg/counts", headers=hb)).json()["whatsapp"] == 1
        r = await env.client.post(f"/api/msg/conversations/{conv.id}/assign", headers=h, json={"agent_id": 2})
        assert r.json()["assignee_id"] == 2 and r.json()["assignee_name"]
        assert (await env.client.get("/api/msg/conversations?view=mine", headers=hb)).json()["items"][0]["id"] == conv.id
        assert (await env.client.get("/api/msg/conversations?view=unassigned", headers=h)).json()["items"] == []
        assert (await env.client.get("/api/msg/counts", headers=h)).json()["whatsapp"] == 0  # someone else's chat
        assert (await env.client.get("/api/msg/conversations?q=lili", headers=h)).json()["items"][0]["id"] == conv.id
        # administrator's "Test connection"
        env.services.settings  # noqa: B018
        ha = await _admin(env)
        r = await env.client.post("/api/admin/settings/test/telegram", headers=ha, json={"values": {}})
        assert r.json()["ok"] and "@zenith_shop_bot" in r.json()["detail"]
        r = await env.client.post("/api/admin/settings/test/telegram", headers=ha, json={"values": {"telegram_bot_token": "1:bad"}})
        assert not r.json()["ok"] and "Unauthorized" in r.json()["detail"]
        r = await env.client.post("/api/admin/settings/test/whatsapp", headers=ha, json={"values": {}})
        assert r.json()["ok"] and "+374 10 555 000" in r.json()["detail"]
        r = await env.client.post("/api/admin/settings/test/whatsapp", headers=ha, json={"values": {"whatsapp_access_token": "bad"}})
        assert not r.json()["ok"] and "access token" in r.json()["detail"]
        s = (await env.client.get("/api/admin/settings", headers=ha)).json()
        assert s["whatsapp_verify_token"] and {g["id"] for g in s["groups"]} >= {"telegram", "whatsapp", "messengers", "mail", "sync"}
        sync = (await env.client.get("/api/admin/sync", headers=ha)).json()
        names = [i["name"] for i in sync["items"]]
        assert names[:5] == ["zammad", "asterisk", "telegram", "whatsapp", "mail"]
    finally:
        await env.services.messengers.stop()


async def _admin(env):
    from app.crypto import hash_password
    from app.models import AgentMapping
    async with env.services.db.sessionmaker() as s:
        root = (await s.execute(select(AgentMapping).where(AgentMapping.username == "root"))).scalars().one()
        root.password_hash = hash_password("pw")
        root.must_change_password = False
        await s.commit()
    return await env.login("root")
