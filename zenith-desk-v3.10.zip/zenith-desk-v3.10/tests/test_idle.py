"""Inactivity pause (v2.8): away for longer than the limit -> calls stop, the manager sees "offline / away"."""
from datetime import timedelta

import pytest

from app.db import utcnow
from app.models import AgentState, AuditLog, CallRecord

from .conftest import IF1


async def set_activity(env, agent_id, minutes_ago):
    async with env.services.db.sessionmaker() as s:
        st = await s.get(AgentState, agent_id)
        st.last_activity_at = utcnow() - timedelta(minutes=minutes_ago)
        await s.commit()


@pytest.mark.asyncio
async def test_server_pauses_inactive_operator_and_manager_sees_it(env):
    h = await env.login("anna")
    assert (await env.client.post("/api/agents/me/ready", headers=h)).status_code == 200
    assert not env.pbx.is_paused(IF1)
    await set_activity(env, 1, 30)                       # 30 min: still fine
    assert await env.services.check_idle() == []
    await set_activity(env, 1, 61)                       # more than an hour without touching Zenith Desk
    assert await env.services.check_idle() == [1]
    assert env.pbx.is_paused(IF1)                        # no more calls to an empty chair
    me = (await env.client.get("/api/agents/me/state", headers=h)).json()
    assert me["computed_state"] == "offline" and me["idle_since"]
    boss = await env.login("boss")
    row = next(a for a in (await env.client.get("/api/admin/agents", headers=boss)).json()["agents"] if a["agent_id"] == 1)
    assert row["display_state"] == "offline" and row["idle_since"] and "Away" in row["reason"]
    async with env.services.db.sessionmaker() as s:
        assert (await s.execute(AuditLog.__table__.select().where(AuditLog.action == "idle_offline"))).first()
    assert await env.services.check_idle() == []         # only once
    # back: exactly the state before the pause (Ready), calls resume
    r = await env.client.post("/api/agents/me/resume", headers=h)
    assert r.status_code == 200 and r.json()["computed_state"] == "ready" and r.json()["idle_since"] is None
    assert not env.pbx.is_paused(IF1)


@pytest.mark.asyncio
async def test_no_pause_during_a_long_call_or_when_switched_off(env):
    h = await env.login("anna")
    await env.client.post("/api/agents/me/ready", headers=h)
    async with env.services.db.sessionmaker() as s:
        s.add(CallRecord(linkedid="long", agent_id=1, state="answered", answered_at=utcnow() - timedelta(minutes=70),
                         started_at=utcnow() - timedelta(minutes=71)))
        await s.commit()
    await set_activity(env, 1, 75)
    assert await env.services.check_idle() == []        # talking on the phone is work
    env.services.settings.idle_timeout_min = 0
    assert (await env.client.post("/api/agents/me/idle", headers=h)).status_code == 409


@pytest.mark.asyncio
async def test_return_restores_break(env):
    h = await env.login("anna")
    await env.client.post("/api/agents/me/break", headers=h)
    await set_activity(env, 1, 90)
    assert await env.services.check_idle() == [1]
    r = (await env.client.post("/api/agents/me/resume", headers=h)).json()
    assert r["computed_state"] == "break"                # was on break -> still on break, not suddenly Ready


@pytest.mark.asyncio
async def test_browser_reported_idle_and_activity_heartbeat(env):
    h = await env.login("anna")
    await env.client.post("/api/agents/me/ready", headers=h)
    assert (await env.client.post("/api/agents/me/activity", headers=h)).json() == {"ok": True, "idle": False}
    r = (await env.client.post("/api/agents/me/idle", headers=h)).json()
    assert r["computed_state"] == "offline" and r["idle_since"]
    assert (await env.client.post("/api/agents/me/activity", headers=h)).json()["idle"] is True
    # a supervisor putting the person back to work also ends the pause
    boss = await env.login("boss")
    r = await env.client.post("/api/admin/agents/1/override", json={"manual_state": "ready", "reason": "she is here"}, headers=boss)
    assert r.status_code == 200 and r.json()["idle_since"] is None


@pytest.mark.asyncio
async def test_heartbeat_does_not_spam_live_updates(env):
    h = await env.login("anna")
    sent = []
    orig = env.services.broker.publish_supervisors
    env.services.broker.publish_supervisors = lambda ev, data: (sent.append((ev, data)), orig(ev, data))
    await env.client.post("/api/agents/me/activity", headers=h)
    assert not [x for x in sent if x[0] == "changed"]
