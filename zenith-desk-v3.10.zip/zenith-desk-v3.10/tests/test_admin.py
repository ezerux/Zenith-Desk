"""Administrator panel: users, roles, passwords, settings stored in the DB, connection tests, ticket types."""
from sqlalchemy import select

from app.models import AgentMapping, SystemSetting
from app.settings_store import SettingsStore

from .conftest import build_env

NEW_USER = {"first_name": "Karen", "last_name": "Petrosyan", "username": "karen", "position": "Senior operator",
            "role": "operator", "level": "level1", "password": "secret-123", "zammad_user_id": 11, "extension": "105",
            "asterisk_interface": "Local/105@from-queue/n"}


async def admin_headers(env):
    return await env.login("root")


async def test_admin_creates_user_who_can_sign_in(env):
    h = await admin_headers(env)
    body = {**NEW_USER, "zammad_user_id": None}
    r = await env.client.post("/api/admin/users", json=body, headers=h)
    assert r.status_code == 200, r.text
    u = r.json()
    assert u["name"] == "Karen Petrosyan" and u["position"] == "Senior operator" and u["has_password"]
    r = await env.client.post("/api/auth/login", json={"username": "Karen", "password": "secret-123"})
    assert r.status_code == 200 and r.json()["agent"]["position"] == "Senior operator"
    tok = {"Authorization": f"Bearer {r.json()['token']}"}
    # operator has no access to the admin panel
    assert (await env.client.get("/api/admin/users", headers=tok)).status_code == 403
    assert (await env.client.get("/api/admin/settings", headers=tok)).status_code == 403
    # not linked to Zammad -> clear error instead of a crash
    t = env.zammad.add_ticket("x", owner_id=1)
    r = await env.client.post(f"/api/tickets/{t['id']}/start", json={"work_mode": "blocking"}, headers=tok)
    assert r.status_code == 409 and "Zammad" in r.json()["detail"]["message"]


async def test_supervisor_has_no_admin_access(env):
    h = await env.login("boss")
    assert (await env.client.get("/api/admin/users", headers=h)).status_code == 403
    assert (await env.client.get("/api/admin/agents", headers=h)).status_code == 200


async def test_user_validation(env):
    h = await admin_headers(env)
    r = await env.client.post("/api/admin/users", json={**NEW_USER, "username": "anna"}, headers=h)
    assert r.status_code == 409
    r = await env.client.post("/api/admin/users", json={**NEW_USER, "zammad_user_id": None, "extension": "101"}, headers=h)
    assert r.status_code == 409 and "101" in r.json()["detail"]
    r = await env.client.post("/api/admin/users", json={**NEW_USER}, headers=h)  # zammad 11 = boris
    assert r.status_code == 409
    r = await env.client.post("/api/admin/users", json={**NEW_USER, "zammad_user_id": None, "username": "bad name!"}, headers=h)
    assert r.status_code == 422
    r = await env.client.post("/api/admin/users", json={**NEW_USER, "zammad_user_id": None, "password": "short"}, headers=h)
    assert r.status_code == 422


async def test_disable_user_and_reset_password(env):
    h = await admin_headers(env)
    anna = await env.login("anna")
    users = (await env.client.get("/api/admin/users", headers=h)).json()
    a = next(u for u in users if u["username"] == "anna")
    body = {k: a[k] for k in ("first_name", "last_name", "username", "position", "role", "level", "zammad_user_id",
                              "extension", "asterisk_interface", "enabled")}
    body["first_name"] = "Anna"
    r = await env.client.put(f"/api/admin/users/{a['id']}", json={**body, "active": False}, headers=h)
    assert r.status_code == 200 and r.json()["active"] is False
    assert (await env.client.get("/api/agents/me/state", headers=anna)).status_code == 401  # session killed
    r = await env.client.post("/api/auth/login", json={"username": "anna", "password": "pw"})
    assert r.status_code == 403
    await env.client.put(f"/api/admin/users/{a['id']}", json={**body, "active": True}, headers=h)
    # password reset with forced change on first sign-in
    r = await env.client.post(f"/api/admin/users/{a['id']}/password", json={"password": "new-pass-1", "must_change_password": True}, headers=h)
    assert r.status_code == 200
    assert (await env.client.post("/api/auth/login", json={"username": "anna", "password": "pw"})).status_code == 401
    r = await env.client.post("/api/auth/login", json={"username": "anna", "password": "new-pass-1"})
    assert r.json()["agent"]["must_change_password"] is True
    tok = {"Authorization": f"Bearer {r.json()['token']}"}
    assert (await env.client.get("/api/agents/me/tasks", headers=tok)).status_code == 403
    r = await env.client.post("/api/auth/change-password", json={"current_password": "new-pass-1", "new_password": "anna-own-pass"}, headers=tok)
    assert r.status_code == 200
    tok = {"Authorization": f"Bearer {r.json()['token']}"}
    assert (await env.client.get("/api/agents/me/tasks", headers=tok)).status_code == 200


async def test_last_admin_and_self_disable_are_protected(env):
    h = await admin_headers(env)
    users = (await env.client.get("/api/admin/users", headers=h)).json()
    root = next(u for u in users if u["username"] == "root")
    body = {k: root[k] for k in ("first_name", "last_name", "username", "position", "level", "zammad_user_id",
                                 "extension", "asterisk_interface", "enabled")}
    body["first_name"] = body["first_name"] or "Admin"
    assert (await env.client.put(f"/api/admin/users/{root['id']}", json={**body, "role": "admin", "active": False}, headers=h)).status_code == 409
    assert (await env.client.put(f"/api/admin/users/{root['id']}", json={**body, "level": "level1", "active": True}, headers=h)).status_code == 409


async def test_login_lockout_after_failures(env):
    for _ in range(5):
        assert (await env.client.post("/api/auth/login", json={"username": "boris", "password": "x"})).status_code == 401
    assert (await env.client.post("/api/auth/login", json={"username": "boris", "password": "pw"})).status_code == 429


async def test_settings_saved_encrypted_and_applied(env):
    h = await admin_headers(env)
    r = await env.client.get("/api/admin/settings", headers=h)
    groups = {g["id"]: g for g in r.json()["groups"]}
    token_item = next(i for i in groups["zammad"]["items"] if i["key"] == "zammad_token")
    assert token_item["value"] == "" and token_item["has_value"] is True  # secrets never sent to the browser
    assert r.json()["webhook_url"].endswith("/api/integrations/zammad/webhook")

    r = await env.client.put("/api/admin/settings", json={"values": {
        "zammad_token": "new-secret-token", "ui_language": "ru", "managed_queues": "400, 401 ,", "wrap_up_seconds": "15"}}, headers=h)
    assert r.status_code == 200, r.text
    assert set(r.json()["changed"]) == {"zammad_token", "ui_language", "wrap_up_seconds"}  # queues unchanged
    assert env.settings.zammad_token == "new-secret-token" and env.settings.wrap_up_seconds == 15
    async with env.services.db.sessionmaker() as s:
        row = await s.get(SystemSetting, "zammad_token")
    assert row.is_secret and "new-secret-token" not in row.value  # encrypted at rest
    # interface language switched immediately
    r = await env.client.post("/api/agents/me/break", headers=await env.login("anna"))
    assert r.json()["reason"] == "Перерыв"
    # empty secret keeps the stored one; values survive a restart
    await env.client.put("/api/admin/settings", json={"values": {"zammad_token": "", "ui_language": "en"}}, headers=h)
    assert env.settings.zammad_token == "new-secret-token"
    from .conftest import make_settings
    fresh = make_settings("/tmp")
    store = SettingsStore(env.services.db, fresh)
    await store.load()
    assert fresh.zammad_token == "new-secret-token" and fresh.wrap_up_seconds == 15 and fresh.ui_language == "en"
    # validation
    assert (await env.client.put("/api/admin/settings", json={"values": {"ami_port": "abc"}}, headers=h)).status_code == 422
    assert (await env.client.put("/api/admin/settings", json={"values": {"nope": 1}}, headers=h)).status_code == 422
    assert (await env.client.put("/api/admin/settings", json={"values": {"zammad_url": "zammad.local"}}, headers=h)).status_code == 422


async def test_connection_tests_and_system_status(env):
    h = await admin_headers(env)
    r = await env.client.post("/api/admin/settings/test-zammad", json={}, headers=h)
    assert r.json()["ok"] is True and "ops-service" in r.json()["detail"]
    r = await env.client.post("/api/admin/settings/test-ami", json={}, headers=h)
    assert r.json()["ok"] is True
    r = await env.client.get("/api/admin/system", headers=h)
    body = r.json()
    assert body["ami"]["connected"] and body["zammad"]["ok"] and body["users"]["active"] == 4
    r = await env.client.get("/api/admin/zammad-users", params={"q": "bor"}, headers=h)
    assert [u["id"] for u in r.json()] == [11]


async def test_ticket_types_crud(env):
    h = await admin_headers(env)
    r = await env.client.put("/api/admin/ticket-types/0", json={
        "name": "Order", "zammad_value": "order",
        "required_fields": [{"name": "order_no", "label": "Order number"}, {"name": "cat", "type": "select", "options": ["A", " B "]}]}, headers=h)
    assert r.status_code == 200 and r.json()["required_fields"][1]["options"] == ["A", "B"]
    tid = r.json()["id"]
    assert (await env.client.put(f"/api/admin/ticket-types/{tid}", json={"name": "Order 2", "zammad_value": "order"}, headers=h)).status_code == 200
    cfg = (await env.client.get("/api/config", headers=await env.login("anna"))).json()
    assert [t["name"] for t in cfg["ticket_types"]] == ["Order 2"]
    assert (await env.client.delete(f"/api/admin/ticket-types/{tid}", headers=h)).status_code == 200
    assert (await env.client.get("/api/admin/ticket-types", headers=h)).json() == []


async def test_first_admin_is_created_on_empty_database(tmp_path):
    from app.db import Base, Database

    from .conftest import make_settings
    db = Database(make_settings(tmp_path).database_url)
    async with db.engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    env = await build_env(tmp_path, db=db, seed=False)  # start() runs ensure_admin()
    async with env.services.db.sessionmaker() as s:
        admins = (await s.execute(select(AgentMapping).where(AgentMapping.role == "admin"))).scalars().all()
    assert len(admins) == 1 and admins[0].username == "admin" and admins[0].must_change_password
    await env.services.ensure_admin()  # idempotent
    async with env.services.db.sessionmaker() as s:
        assert len((await s.execute(select(AgentMapping).where(AgentMapping.role == "admin"))).scalars().all()) == 1
    await env.client.aclose()


async def test_level_is_required_and_shown_everywhere(env):
    h = await admin_headers(env)
    body = {**NEW_USER, "zammad_user_id": None}
    body.pop("level")
    assert (await env.client.post("/api/admin/users", json=body, headers=h)).status_code == 422
    assert (await env.client.post("/api/admin/users", json={**body, "level": "boss"}, headers=h)).status_code == 422
    r = await env.client.post("/api/admin/users", json={**body, "level": "level3"}, headers=h)
    assert r.status_code == 200 and r.json()["level"] == "level3"
    login = await env.client.post("/api/auth/login", json={"username": "karen", "password": "secret-123"})
    assert login.json()["agent"]["level"] == "level3"
    sup = (await env.client.get("/api/admin/agents", headers=await env.login("boss"))).json()["agents"]
    assert next(a for a in sup if a["name"] == "Karen Petrosyan")["level"] == "level3"


async def test_personal_preferences(env):
    h = await env.login("anna")
    p = (await env.client.get("/api/agents/me/preferences", headers=h)).json()
    assert p["theme"] == "" and p["preset"] == "default" and p["layout"] == []
    layout = [{"id": "calls", "w": 3, "h": "l"}, {"id": "kpis", "w": 3, "h": "auto", "hidden": True}]
    r = await env.client.put("/api/agents/me/preferences", json={"theme": "dark", "sound": False, "preset": "custom", "layout": layout}, headers=h)
    assert r.status_code == 200
    # stored on the server -> same on any computer, returned at sign-in
    login = await env.client.post("/api/auth/login", json={"username": "anna", "password": "pw"})
    prefs = login.json()["agent"]["prefs"]
    assert prefs["theme"] == "dark" and prefs["sound"] is False and prefs["layout"][0]["id"] == "calls"
    assert prefs["layout"][1]["hidden"] is True
    # other users are not affected
    assert (await env.client.get("/api/agents/me/preferences", headers=await env.login("boris"))).json()["theme"] == ""
    # validation
    bad = [{"id": "hack", "w": 1}]
    assert (await env.client.put("/api/agents/me/preferences", json={"layout": bad}, headers=h)).status_code == 422
    assert (await env.client.put("/api/agents/me/preferences", json={"layout": [{"id": "calls", "w": 9}]}, headers=h)).status_code == 422
    dup = [{"id": "calls", "w": 1}, {"id": "calls", "w": 2}]
    assert (await env.client.put("/api/agents/me/preferences", json={"layout": dup}, headers=h)).status_code == 422
    assert (await env.client.put("/api/agents/me/preferences", json={"theme": "pink"}, headers=h)).status_code == 422
    # v2.4: "system" follows the computer's setting; "" means the default dark console look
    assert (await env.client.put("/api/agents/me/preferences", json={"theme": "system"}, headers=h)).status_code == 200
    assert (await env.client.get("/api/agents/me/preferences", headers=h)).json()["theme"] == "system"
    # v2.6: animations can be switched off per user (default on)
    assert (await env.client.get("/api/agents/me/preferences", headers=h)).json()["motion"] is True
    assert (await env.client.put("/api/agents/me/preferences", json={"motion": False}, headers=h)).json()["motion"] is False


async def test_level_decides_access_rights(env):
    h = await admin_headers(env)
    body = {**NEW_USER, "zammad_user_id": None, "level": "manager", "role": "operator"}  # role is ignored
    r = await env.client.post("/api/admin/users", json=body, headers=h)
    assert r.status_code == 200 and r.json()["role"] == "supervisor"
    tok = (await env.client.post("/api/auth/login", json={"username": "karen", "password": "secret-123"})).json()["token"]
    mh = {"Authorization": f"Bearer {tok}"}
    # a Manager leads the team: sees operators, can override, reassign
    team = (await env.client.get("/api/admin/agents", headers=mh)).json()["agents"]
    assert {a["level"] for a in team} >= {"level1"}
    assert (await env.client.post("/api/admin/agents/1/override", json={"manual_state": "break", "reason": "team meeting"}, headers=mh)).status_code == 200
    # but has no administrator rights
    assert (await env.client.get("/api/admin/users", headers=mh)).status_code == 403
    # changing the level changes the rights immediately
    uid = r.json()["id"]
    upd = {k: r.json()[k] for k in ("first_name", "last_name", "username", "position", "zammad_user_id", "extension", "asterisk_interface", "enabled", "active")}
    r2 = await env.client.put(f"/api/admin/users/{uid}", json={**upd, "level": "level2"}, headers=h)
    assert r2.json()["role"] == "operator"
    assert (await env.client.get("/api/admin/agents", headers=mh)).status_code == 403
