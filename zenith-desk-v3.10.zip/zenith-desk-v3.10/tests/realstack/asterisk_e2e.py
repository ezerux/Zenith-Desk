"""End-to-end check of Zenith Desk against a REAL Asterisk 20 (no simulators on the telephony side).

    tests/realstack/asterisk.sh start        # once (apt-get install asterisk asterisk-modules)
    python tests/realstack/asterisk_e2e.py   # starts the Zenith Desk demo server connected to that Asterisk

What is checked, on the real PBX:
  * AMI login with exactly the permissions from docs/INSTALL.md; /api/health and the sync panel see Asterisk;
  * the browser phone (JsSIP in Chromium) registers on Asterisk PJSIP over WebSocket (digest auth, DTLS-SRTP);
  * work-state → queue pause: blocking ticket pauses the member in queues 400/401, Ready unpauses, DND pauses;
  * resilience: Asterisk restarts (members come back unpaused) → Zenith Desk reconnects and restores the pause;
  * customer call into ACD queue 400 → rings in the call strip with the customer recognised → answered →
    call history (queue, answered, recording) → hang up → the MixMonitor recording plays through Zenith Desk;
  * outgoing call from the browser phone to the echo test (600) and hang up.
Exits with code 1 if anything fails.
"""
import asyncio
import json
import os
import re
import socket
import subprocess
import sys
import time
import urllib.request

from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
AST = os.path.join(ROOT, "tests", "realstack", "asterisk.sh")
AST_DIR = os.environ.get("ZENITH_AST_DIR", "/tmp/zenith-asterisk")
RESULTS: list[tuple[str, bool, str]] = []
STATE: dict = {}


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def expect(cond, msg):
    if not cond:
        raise AssertionError(msg)


def cli(cmd: str) -> str:
    out = subprocess.run([AST, "cli", cmd], capture_output=True, text=True, timeout=20).stdout
    return re.sub(r"\x1b\[[0-9;]*m", "", out)


def member_line(queue: str, name: str) -> str:
    return next((ln for ln in cli(f"queue show {queue}").splitlines() if name in ln), "")


async def wait_for(fn, what: str, timeout: float = 15.0, every: float = 0.3):
    end = time.monotonic() + timeout
    last = None
    while time.monotonic() < end:
        last = fn()
        if last:
            return last
        await asyncio.sleep(every)
    raise AssertionError(f"timeout waiting for {what}; last: {last!r}")


async def step(name, coro):
    try:
        await coro
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}", flush=True)
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, False, str(exc)[:400]))
        print(f"  FAIL  {name}: {str(exc)[:400]}", flush=True)


class Tester:
    """The test's own AMI connection (user `tester`), used only to place customer calls."""

    async def originate(self, **fields) -> dict:
        r, w = await asyncio.open_connection("127.0.0.1", 5038)
        await r.readline()

        async def send(d):
            w.write(("".join(f"{k}: {v}\r\n" for k, v in d.items()) + "\r\n").encode())
            await w.drain()
            block = (await asyncio.wait_for(r.readuntil(b"\r\n\r\n"), 10)).decode()
            return dict(x.split(": ", 1) for x in block.strip().split("\r\n") if ": " in x)
        login = await send({"Action": "Login", "Username": "tester", "Secret": "tester-secret", "Events": "off"})
        expect(login.get("Response") == "Success", f"tester login: {login}")
        resp = await send({"Action": "Originate", "Async": "true", **fields})
        w.close()
        return resp


def api(base: str, method: str, path: str, token: str | None = None, body=None, raw=False):
    req = urllib.request.Request(base + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            data = r.read()
            return (r.status, r.headers, data) if raw else (r.status, json.loads(data or b"null"))
    except urllib.error.HTTPError as e:
        data = e.read()
        return (e.code, e.headers, data) if raw else (e.code, json.loads(data or b"null") if data[:1] in (b"{", b"[") else data)


def calls(base: str, token: str) -> list:
    r = api(base, "GET", "/api/agents/me/calls", token)[1]
    return r.get("calls", []) if isinstance(r, dict) else r


async def main() -> int:
    subprocess.run([AST, "start"], check=True, timeout=60)
    port = free_port()
    env = {**os.environ, "DEMO_AMI": "127.0.0.1:5038:agent-state:ami-secret-zenith", "DEMO_PHONE_WSS": "ws://127.0.0.1:8088/ws",
           "DEMO_SIP_PASSWORDS": "1=sip-pass-101,2=sip-pass-102", "DEMO_RECORDING_DIR": f"{AST_DIR}/spool/monitor",
           "DEMO_HISTORY": "0", "DEMO_MAIL": os.environ.get("DEMO_MAIL", "0")}
    env.pop("DEMO_DB", None)
    demo = subprocess.Popen([sys.executable, "-c", f"import uvicorn; from scripts.demo import build; uvicorn.run(build(), host='127.0.0.1', port={port}, log_level='warning')"],
                            cwd=ROOT, env=env)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(base + "/api/health", timeout=1)
                break
            except Exception:  # noqa: BLE001
                await asyncio.sleep(0.5)
        anna = api(base, "POST", "/api/auth/login", body={"username": "anna", "password": "pw"})[1]["token"]
        admin = api(base, "POST", "/api/auth/login", body={"username": "admin", "password": "admin"})[1]["token"]

        async def ami_connected():
            h = await wait_for(lambda: (lambda x: x if x["ami_connected"] else None)(api(base, "GET", "/api/health")[1]), "AMI connection")
            expect(h["integrations"]["asterisk"] == "ok", f"health: {h}")
            items = api(base, "POST", "/api/admin/sync/asterisk/poll", admin)[1]["items"]
            a = next(i for i in items if i["name"] == "asterisk")
            expect(a["realtime"] == "on" and a["ok"] and a["polls"] >= 1 and not a["last_error"], f"sync panel: {a}")
            expect("agent-state" in cli("manager show connected"), "AMI user agent-state not connected to Asterisk")
        await step("AMI: Zenith Desk logs in with the documented permissions; health + sync panel show Asterisk OK", ami_connected())

        async with async_playwright() as p:
            browser = await p.chromium.launch(args=["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"])
            ctx = await browser.new_context(viewport={"width": 1400, "height": 900}, permissions=["microphone"])
            pg = await ctx.new_page()
            errors: list[str] = []
            pg.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))

            async def register():
                await pg.goto(base + "/")
                await pg.fill("input[autocomplete=username]", "anna")
                await pg.fill("input[type=password]", "pw")
                await pg.click("form button.primary")
                await pg.wait_for_selector(".sidebar", timeout=8000)
                await pg.wait_for_selector(".phone-btn.p-registered", timeout=15000)
                await wait_for(lambda: "101/" in cli("pjsip show contacts"), "PJSIP contact 101")
                await wait_for(lambda: "Not in use" in member_line("400", "Anna"), "Anna available in queue 400")
            await step("Browser phone registers on Asterisk PJSIP over WebSocket; queue member 101 becomes available", register())

            async def pause_sync():
                ready = await wait_for(lambda: "paused" not in member_line("400", "Anna") and member_line("400", "Anna"), "Anna not paused")
                tickets = api(base, "GET", "/api/agents/me/tickets", anna)[1]
                tid = (tickets["active"] + tickets["pending"])[0]["id"]
                st, r = api(base, "POST", f"/api/tickets/{tid}/start", anna, {"work_mode": "blocking"})
                expect(st == 200 and r["agent_state"]["phone_status"] == "paused", f"start: {st} {r}")
                for q in ("400", "401"):
                    line = await wait_for(lambda q=q: "paused" in member_line(q, "Anna") and member_line(q, "Anna"), f"Anna paused in {q}")
                expect("agent-state-service" in line or "paused" in line, line)
                STATE["tid"] = tid
                del ready
            await step("Blocking ticket → Asterisk pauses Anna in queues 400 and 401 (QueuePause, real AMI)", pause_sync())

            async def restart():
                subprocess.run([AST, "stop"], timeout=30)
                await wait_for(lambda: not api(base, "GET", "/api/health")[1]["ami_connected"], "AMI disconnect noticed", 20)
                subprocess.run([AST, "start"], check=True, timeout=60)
                await wait_for(lambda: api(base, "GET", "/api/health")[1]["ami_connected"], "AMI reconnect", 40)
                await wait_for(lambda: "paused" in member_line("400", "Anna") and "paused" in member_line("401", "Anna"),
                               "pause restored after the PBX restart", 30)
                await wait_for(lambda: "101/" in cli("pjsip show contacts"), "browser phone re-registered", 60, 1)
            await step("Asterisk restart: Zenith Desk reconnects and restores Anna's pause; the browser phone re-registers", restart())

            async def ready_and_dnd():
                st, _ = api(base, "POST", f"/api/tickets/{STATE['tid']}/release", anna)
                expect(st == 200, f"release {st}")
                api(base, "POST", "/api/agents/me/ready", anna)
                await wait_for(lambda: "paused" not in member_line("400", "Anna") and "paused" not in member_line("401", "Anna"), "unpaused after Ready")
                st, _ = api(base, "POST", "/api/agents/me/dnd", anna, {"on": True})
                expect(st == 200, f"dnd {st}")
                await wait_for(lambda: "paused" in member_line("400", "Anna"), "paused by DND")
                api(base, "POST", "/api/agents/me/dnd", anna, {"on": False})
                api(base, "POST", "/api/agents/me/ready", anna)
                await wait_for(lambda: "paused" not in member_line("400", "Anna"), "unpaused after DND off")
            await step("Release + Ready unpauses in Asterisk; Do-not-disturb pauses and unpauses", ready_and_dnd())

            async def queue_call():
                await pg.wait_for_selector(".phone-btn.p-registered", timeout=20000)
                r = await Tester().originate(Channel="Local/400@incoming", Context="customer", Exten="s", Priority="1",
                                             CallerID='"Aram Grigoryan" <+37491123456>', Timeout="30000")
                expect(r.get("Response") == "Success", f"originate: {r}")
                await pg.wait_for_selector(".ph-strip.cs-ringing", timeout=15000)
                await pg.wait_for_selector(".ph-strip >> text=Aram Grigoryan", timeout=5000)
                await pg.click("[data-act=strip-answer]")
                await pg.wait_for_selector(".ph-strip.cs-active", timeout=10000)
                await wait_for(lambda: "Up" in "".join(ln for ln in cli("core show channels").splitlines() if "PJSIP/101" in ln), "PJSIP/101 Up")
                call = await wait_for(lambda: next((c for c in calls(base, anna)
                                                     if c.get("queue") == "400" and c.get("state") == "answered"), None), "answered queue call in history")
                expect(call.get("recording_url", "").startswith("/api/calls/"), f"recording url: {call}")
                await asyncio.sleep(2.5)  # talk a little, so the recording has audio
                await pg.click("[data-act=strip-hangup]")
                await pg.wait_for_selector(".ph-strip", state="detached", timeout=10000)
                ended = await wait_for(lambda: next((c for c in calls(base, anna)
                                                     if c["id"] == call["id"] and c["state"] == "ended"), None), "call ended in history")
                st, hdr, data = await wait_for(lambda: (lambda x: x if x[0] == 200 and len(x[2]) > 1000 else None)(
                    api(base, "GET", ended["recording_url"], anna, raw=True)), "recording file", 15)
                expect(data[:4] == b"RIFF" and hdr["content-type"] == "audio/wav", f"recording: {hdr['content-type']} {data[:4]}")
                st_b = api(base, "GET", ended["recording_url"], api(base, "POST", "/api/auth/login", body={"username": "boris", "password": "pw"})[1]["token"], raw=True)[0]
                expect(st_b == 403, f"other operator got {st_b}")
                await wait_for(lambda: "0 calls" in cli("queue show 400").splitlines()[0], "queue empty")
            await step("Customer call into queue 400: rings in the strip (customer recognised), answered, history, hang up, recording plays (others: 403)", queue_call())

            async def outgoing_echo():
                await pg.click(".phone-btn")
                await pg.wait_for_selector(".ph-card .ph-num input")
                await pg.fill(".ph-num input", "600")
                await pg.click("[data-act=call]")
                await pg.wait_for_selector(".ph-card.ph-active", timeout=10000)
                await pg.wait_for_function("document.querySelector('.ph-line small') && document.querySelector('.ph-line small').textContent >= '00:02'", timeout=8000)
                expect("Echo" in cli("core show channels"), "echo application not running on Asterisk")
                await pg.click("[data-act=call]")
                await pg.wait_for_selector(".ph-card.ph-idle", timeout=8000)
                await wait_for(lambda: "PJSIP/101" not in cli("core show channels"), "channel gone on Asterisk")
            await step("Outgoing call from the browser phone to the echo test (600): connected with media, End hangs up on Asterisk", outgoing_echo())

            expect_no = [e for e in errors if "pageerror" in e]
            RESULTS.append(("No JavaScript errors in the page", not expect_no, "; ".join(expect_no)[:300]))
            print(f"  {'PASS' if not expect_no else 'FAIL'}  No JavaScript errors in the page", flush=True)
            await browser.close()
    finally:
        demo.terminate()
        demo.wait(10)
    failed = [r for r in RESULTS if not r[1]]
    print(f"\nReal Asterisk e2e: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
