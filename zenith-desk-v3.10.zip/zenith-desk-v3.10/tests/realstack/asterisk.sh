#!/usr/bin/env bash
# A real Asterisk 20 for integration tests, configured the way FreePBX does it:
#   * ACD queues 400 / 401 with members Local/1XX@from-queue/n (state interface PJSIP/1XX);
#   * PJSIP extensions 101, 102 for WebRTC (SIP over WebSocket ws://127.0.0.1:8088/ws, DTLS-SRTP, ICE);
#   * AMI user `agent-state` with exactly the permissions from docs/INSTALL.md (read call,agent,dialplan; write agent)
#     and a separate `tester` user that the test uses to place customer calls (Originate);
#   * 600 = echo test, 400 = the incoming line into queue 400, MixMonitor records every queue call.
#
#   tests/realstack/asterisk.sh start | stop | status | cli "queue show 400"
# Install once: apt-get install asterisk asterisk-modules   (Ubuntu 24.04: Asterisk 20.6)
set -euo pipefail
DIR=${ZENITH_AST_DIR:-/tmp/zenith-asterisk}
CONF="$DIR/etc/asterisk.conf"

write_config() {
  mkdir -p "$DIR"/{etc,lib,spool/monitor,run,log,cache,keys/keys}
  cat > "$CONF" <<EOF
[directories]
astetcdir => $DIR/etc
astmoddir => /usr/lib/x86_64-linux-gnu/asterisk/modules
astvarlibdir => $DIR/lib
astdbdir => $DIR/lib
astkeydir => $DIR/keys
astdatadir => /usr/share/asterisk
astagidir => /usr/share/asterisk/agi-bin
astspooldir => $DIR/spool
astrundir => $DIR/run
astlogdir => $DIR/log
astcachedir => $DIR/cache
astsbindir => /usr/sbin
[options]
systemname = zenith-test
EOF
  cat > "$DIR/etc/modules.conf" <<'EOF'
[modules]
autoload = yes
noload = chan_iax2.so
noload = chan_unistim.so
noload = chan_mgcp.so
noload = chan_skinny.so
noload = res_config_ldap.so
noload = res_config_pgsql.so
noload = res_config_odbc.so
noload = cdr_pgsql.so
noload = cel_pgsql.so
noload = res_phoneprov.so
noload = res_pjsip_phoneprov_provider.so
noload = pbx_dundi.so
noload = res_hep.so
noload = res_hep_pjsip.so
noload = res_hep_rtcp.so
noload = res_xmpp.so
noload = chan_motif.so
noload = res_calendar.so
noload = res_statsd.so
noload = res_smdi.so
noload = res_ari.so
noload = res_stasis_test.so
EOF
  cat > "$DIR/etc/logger.conf" <<'EOF'
[general]
[logfiles]
messages => notice,warning,error
EOF
  cat > "$DIR/etc/http.conf" <<'EOF'
[general]
enabled = yes
bindaddr = 127.0.0.1
bindport = 8088
EOF
  cat > "$DIR/etc/rtp.conf" <<'EOF'
[general]
rtpstart = 20000
rtpend = 20999
icesupport = yes
EOF
  cat > "$DIR/etc/manager.conf" <<'EOF'
[general]
enabled = yes
port = 5038
bindaddr = 127.0.0.1

; exactly as in docs/INSTALL.md
[agent-state]
secret = ami-secret-zenith
deny = 0.0.0.0/0.0.0.0
permit = 127.0.0.1/255.255.255.255
read = call,agent,dialplan
write = agent
writetimeout = 5000

; only for the test itself (places customer calls)
[tester]
secret = tester-secret
deny = 0.0.0.0/0.0.0.0
permit = 127.0.0.1/255.255.255.255
read = all
write = all
EOF
  cat > "$DIR/etc/pjsip.conf" <<'EOF'
[transport-udp]
type = transport
protocol = udp
bind = 127.0.0.1:5060

[transport-ws]
type = transport
protocol = ws
bind = 0.0.0.0

[webrtc](!)
type = endpoint
context = from-internal
disallow = all
allow = opus,ulaw,alaw
webrtc = yes
dtls_auto_generate_cert = yes
direct_media = no
rtp_symmetric = yes
force_rport = yes
rewrite_contact = yes

[101](webrtc)
auth = 101
aors = 101
callerid = "Anna Petrova" <101>
[101]
type = auth
auth_type = userpass
username = 101
password = sip-pass-101
[101]
type = aor
max_contacts = 3
remove_existing = yes

[102](webrtc)
auth = 102
aors = 102
callerid = "Boris Ivanov" <102>
[102]
type = auth
auth_type = userpass
username = 102
password = sip-pass-102
[102]
type = aor
max_contacts = 3
remove_existing = yes
EOF
  cat > "$DIR/etc/queues.conf" <<'EOF'
[general]
persistentmembers = no
shared_lastcall = yes

[q](!)
strategy = ringall
timeout = 25
retry = 2
wrapuptime = 0
joinempty = yes
leavewhenempty = no
ringinuse = no
announce-frequency = 0
periodic-announce-frequency = 0
member => Local/101@from-queue/n,0,Anna Petrova,PJSIP/101
member => Local/102@from-queue/n,0,Boris Ivanov,PJSIP/102

[400](q)
[401](q)
EOF
  cat > "$DIR/etc/extensions.conf" <<'EOF'
[general]
static = yes
writeprotect = yes

[from-internal]
exten => 600,1,Answer()
 same => n,Echo()
 same => n,Hangup()
exten => _1XX,1,Dial(PJSIP/${EXTEN},30)
 same => n,Hangup()
exten => 400,1,Goto(incoming,400,1)
exten => _X.,1,Answer()
 same => n,Wait(1)
 same => n,Echo()
 same => n,Hangup()

; queue members (FreePBX: Local/1XX@from-queue/n)
[from-queue]
exten => _1XX,1,Dial(PJSIP/${EXTEN},30)
 same => n,Hangup()

; the customer's line into the ACD queue; every queue call is recorded (as FreePBX does)
[incoming]
exten => _4XX,1,Answer()
 same => n,Set(__MIXMONITOR_FILENAME=q${EXTEN}-${CALLERID(num)}-${UNIQUEID}.wav)
 same => n,MixMonitor(${ASTSPOOLDIR}/monitor/${MIXMONITOR_FILENAME})
 same => n,Queue(${EXTEN},t,,,120)
 same => n,Hangup()

; the far end of a test customer call: just keeps the line open
[customer]
exten => s,1,Answer()
 same => n,Wait(120)
 same => n,Hangup()
EOF
  : > "$DIR/etc/cdr.conf"; : > "$DIR/etc/cel.conf"; : > "$DIR/etc/musiconhold.conf"; : > "$DIR/etc/features.conf"
  printf '[general]\n' > "$DIR/etc/stasis.conf"
}

cli() { asterisk -C "$CONF" -rx "$1"; }

case "${1:-start}" in
  start)
    if [ -S "$DIR/run/asterisk.ctl" ] && cli "core show uptime" >/dev/null 2>&1; then echo "asterisk already running"; exit 0; fi
    write_config
    asterisk -C "$CONF" -F -U root 2>/dev/null || asterisk -C "$CONF" -F
    for _ in $(seq 1 60); do
      if cli "core waitfullybooted" >/dev/null 2>&1 && cli "pjsip show transports" 2>/dev/null | grep -q transport-ws; then
        echo "asterisk up: AMI 127.0.0.1:5038, WebSocket ws://127.0.0.1:8088/ws, config in $DIR/etc"; exit 0
      fi
      sleep 0.5
    done
    echo "asterisk did not start, see $DIR/log/messages" >&2; exit 1 ;;
  stop)
    cli "core stop now" >/dev/null 2>&1 || true
    for _ in $(seq 1 20); do pgrep -f "asterisk -C $CONF" >/dev/null || exit 0; sleep 0.3; done
    pkill -f "asterisk -C $CONF" || true ;;
  status) cli "core show uptime"; cli "queue show 400"; cli "pjsip show contacts" ;;
  cli) cli "$2" ;;
  *) echo "usage: $0 start|stop|status|cli CMD" >&2; exit 2 ;;
esac
