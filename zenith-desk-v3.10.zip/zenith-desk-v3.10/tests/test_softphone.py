"""v3.5 Zenith Phone: configuration, SIP passwords, search, caller recognition, security headers."""
from sqlalchemy import select

from app.models import AgentMapping


async def admin_headers(env):
    return await env.login("root")


async def test_phone_config_explains_what_is_missing(env):
    h = await env.login("anna")
    cfg = (await env.client.get("/api/phone/config", headers=h)).json()
    assert cfg["ready"] is False and cfg["problem"] == "disabled"
    env.settings.phone_enabled = True
    assert (await env.client.get("/api/phone/config", headers=h)).json()["problem"] == "no_server"
    env.settings.phone_wss_url = "wss://pbx.company.ru:8089/ws"
    assert (await env.client.get("/api/phone/config", headers=h)).json()["problem"] == "no_password"
    hb = await env.login("boss")  # no extension
    assert (await env.client.get("/api/phone/config", headers=hb)).json()["problem"] == "no_extension"


async def test_admin_sets_sip_password_encrypted_and_user_gets_it(env):
    env.settings.phone_enabled = True
    env.settings.phone_wss_url = "wss://pbx.company.ru:8089/ws"
    env.settings.phone_ice_servers = "stun:stun.l.google.com:19302,turn:turn.company.ru:3478"
    env.settings.phone_turn_username, env.settings.phone_turn_password = "zen", "turn-pw"
    ha = await admin_headers(env)
    users = (await env.client.get("/api/admin/users", headers=ha)).json()
    anna = next(u for u in users if u["username"] == "anna")
    assert anna["has_sip_password"] is False
    body = {k: anna[k] for k in ("first_name", "last_name", "username", "position", "level", "active", "zammad_user_id",
                                 "extension", "asterisk_interface", "enabled")}
    body["first_name"] = body["first_name"] or "Анна"
    r = await env.client.put(f"/api/admin/users/{anna['id']}", headers=ha, json={**body, "sip_password": "S3cret-101", "sip_user": ""})
    assert r.status_code == 200 and r.json()["has_sip_password"] is True and "S3cret" not in r.text
    async with env.services.db.sessionmaker() as s:
        m = (await s.execute(select(AgentMapping).where(AgentMapping.username == "anna"))).scalars().one()
    assert m.sip_secret and "S3cret" not in m.sip_secret  # encrypted at rest

    h = await env.login("anna")
    r = await env.client.get("/api/phone/config", headers=h)
    cfg = r.json()
    assert cfg["ready"] and cfg["password"] == "S3cret-101" and cfg["sip_uri"] == "sip:101@pbx.company.ru"
    assert cfg["authorization_user"] == "101" and r.headers["cache-control"] == "no-store"
    assert cfg["ice_servers"] == [{"urls": "stun:stun.l.google.com:19302"},
                                  {"urls": "turn:turn.company.ru:3478", "username": "zen", "credential": "turn-pw"}]
    # other users never see it
    hb = await env.login("boris")
    assert (await env.client.get("/api/phone/config", headers=hb)).json()["password"] == ""

    # keep on empty, separate SIP login, then remove
    r = await env.client.put(f"/api/admin/users/{anna['id']}", headers=ha, json={**body, "sip_user": "anna-webrtc"})
    assert r.json()["has_sip_password"] is True
    cfg = (await env.client.get("/api/phone/config", headers=h)).json()
    assert cfg["sip_uri"] == "sip:anna-webrtc@pbx.company.ru" and cfg["password"] == "S3cret-101"
    r = await env.client.put(f"/api/admin/users/{anna['id']}", headers=ha, json={**body, "sip_password_clear": True})
    assert r.json()["has_sip_password"] is False


async def test_security_headers_allow_microphone_and_the_pbx_socket(env):
    r = await env.client.get("/")
    assert "microphone=(self)" in r.headers["permissions-policy"]
    assert "connect-src 'self';" in r.headers["content-security-policy"]
    env.settings.phone_enabled = True
    env.settings.phone_wss_url = "wss://pbx.company.ru:8089/ws"
    r = await env.client.get("/")
    assert "connect-src 'self' wss://pbx.company.ru:8089;" in r.headers["content-security-policy"]
    env.settings.phone_wss_url = "wss://evil.example; script-src *"  # never lets a setting inject CSP
    r = await env.client.get("/")
    assert "evil" not in r.headers["content-security-policy"]


async def test_search_and_caller_recognition(env):
    await env.services.directory.sync()
    h = await env.login("anna")
    assert (await env.client.get("/api/phone/search?q=xyz", headers=h)).json()["items"] == []
    items = (await env.client.get("/api/phone/search?q=Борис", headers=h)).json()["items"]
    assert items[0] == {"kind": "colleague", "id": 2, "name": "Борис", "number": "102", "detail": "", "state": items[0]["state"]}
    items = (await env.client.get("/api/phone/search?q=Иван", headers=h)).json()["items"]
    assert items[0]["kind"] == "customer" and items[0]["number"] == "+7 (912) 345-67-89"
    items = (await env.client.get("/api/phone/search?q=%2B37400111222", headers=h)).json()["items"]
    assert items[0]["kind"] == "number" and items[0]["number"] == "+37400111222"

    who = (await env.client.get("/api/phone/whois?number=89123456789", headers=h)).json()
    assert who["kind"] == "customer" and who["name"] == "Иван"
    who = (await env.client.get("/api/phone/whois?number=102", headers=h)).json()
    assert who["kind"] == "colleague" and who["name"] == "Борис"
    assert (await env.client.get("/api/phone/whois?number=555", headers=h)).json()["kind"] == "unknown"


async def test_ui_config_tells_whether_the_phone_is_on(env):
    h = await env.login("anna")
    assert (await env.client.get("/api/config", headers=h)).json()["phone_enabled"] is False
    env.settings.phone_enabled = True
    assert (await env.client.get("/api/config", headers=h)).json()["phone_enabled"] is True
    hb = await env.login("boss")  # without an extension there is no phone
    assert (await env.client.get("/api/config", headers=hb)).json()["phone_enabled"] is False


async def test_softphone_calls_are_tracked_like_desk_phone_calls(env):
    """A WebRTC call goes through FreePBX; AMI reports it on the PJSIP channel of the extension."""
    calls = env.services.calls
    await calls.handle_event({"Event": "DialBegin", "Channel": "PJSIP/101-00000a1", "DestChannel": "PJSIP/trunk-00000a2",
                              "DestCallerIDNum": "+37491123456", "Uniqueid": "w1", "Linkedid": "w1"})
    await calls.handle_event({"Event": "DialEnd", "DialStatus": "ANSWER", "Channel": "PJSIP/101-00000a1",
                              "DestChannel": "PJSIP/trunk-00000a2", "Uniqueid": "w1", "Linkedid": "w1"})
    await calls.handle_event({"Event": "Hangup", "Uniqueid": "w1", "Linkedid": "w1"})
    h = await env.login("anna")
    recent = (await env.client.get("/api/agents/me/calls", headers=h)).json()
    assert recent[0]["direction"] == "out" and recent[0]["caller_number"] == "+37491123456" and recent[0]["state"] == "ended"


async def test_phone_book_and_voicemail(env):
    env.settings.phone_enabled = True
    env.settings.phone_voicemail_number = "*97"
    h = await env.login("anna")
    book = (await env.client.get("/api/phone/contacts", headers=h)).json()["colleagues"]
    assert {c["number"]: c["me"] for c in book} == {"101": True, "102": False}
    assert all(c["state"] for c in book)
    assert (await env.client.get("/api/phone/config", headers=h)).json()["voicemail"] == "*97"


async def test_dnd_pauses_queues_and_ready_clears_it(env):
    """v3.7 Do not disturb: no calls at all until the operator turns it off (or presses Ready)."""
    from .conftest import IF1
    h = await env.login("anna")
    r = await env.client.post("/api/agents/me/ready", headers=h)
    assert r.json()["computed_state"] == "ready" and not env.pbx.is_paused(IF1)
    r = await env.client.post("/api/agents/me/dnd", headers=h, json={"on": True})
    assert r.status_code == 200 and r.json()["dnd"] is True
    assert r.json()["computed_state"] == "break" and r.json()["reason"] in ("Do not disturb", "Не беспокоить")
    assert env.pbx.is_paused(IF1)
    r = await env.client.post("/api/agents/me/dnd", headers=h, json={"on": False})
    assert r.json()["dnd"] is False and r.json()["computed_state"] == "ready" and not env.pbx.is_paused(IF1)
    await env.client.post("/api/agents/me/dnd", headers=h, json={"on": True})
    r = await env.client.post("/api/agents/me/ready", headers=h)
    assert r.json()["dnd"] is False and r.json()["computed_state"] == "ready"
