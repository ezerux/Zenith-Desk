"""Dashboard numbers, notification center, supervisor assignment by ticket number (v2.1)."""
from .conftest import IF1


async def test_dashboard_numbers(env):
    h = await env.login("anna")
    await env.client.post("/api/agents/me/ready", headers=h)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await env.client.post(f"/api/tickets/{t['id']}/start", json={"work_mode": "blocking"}, headers=h)
    await env.client.post(f"/api/tickets/{t['id']}/complete", json={}, headers=h)
    for ev in ({"Event": "AgentCalled", "Interface": IF1, "Queue": "400", "CallerIDNum": "79001112233", "Uniqueid": "1.1", "Linkedid": "1.1"},
               {"Event": "AgentRingNoAnswer", "Interface": IF1, "Queue": "400", "Uniqueid": "1.1", "Linkedid": "1.1"}):
        await env.services.calls.handle_event(ev)
    d = (await env.client.get("/api/agents/me/dashboard", headers=h)).json()
    assert d["completed_today"] == 1 and d["started_today"] == 1
    assert d["calls_today"] == 1 and d["calls_missed"] == 1 and d["calls_answered"] == 0


async def test_notifications_flow(env):
    ha, hb = await env.login("anna"), await env.login("boss")
    await env.client.post("/api/agents/me/ready", headers=ha)
    t = env.zammad.add_ticket("A", owner_id=10, state="open")
    await env.client.post(f"/api/tickets/{t['id']}/start", json={"work_mode": "blocking"}, headers=ha)
    # own actions do not create notifications
    n = (await env.client.get("/api/agents/me/notifications", headers=ha)).json()
    assert n["items"] == [] and n["unread"] == 0
    # supervisor cancels the session and overrides the state -> anna is notified
    sessions = (await env.client.get("/api/agents/me/tasks", headers=ha)).json()["blocking"]
    await env.client.post(f"/api/admin/sessions/{sessions[0]['id']}/cancel", json={"reason": "urgent call"}, headers=hb)
    await env.client.post("/api/admin/agents/1/override", json={"manual_state": "break", "reason": "lunch time"}, headers=hb)
    await env.services.calls.handle_event({"Event": "AgentCalled", "Interface": IF1, "Queue": "400", "CallerIDNum": "79005556677", "Uniqueid": "2.1", "Linkedid": "2.1"})
    await env.services.calls.handle_event({"Event": "AgentRingNoAnswer", "Interface": IF1, "Queue": "400", "Uniqueid": "2.1", "Linkedid": "2.1"})
    n = (await env.client.get("/api/agents/me/notifications", headers=ha)).json()
    texts = " | ".join(i["text"] for i in n["items"])
    assert n["unread"] == 3, texts
    assert "urgent call" in texts and "lunch time" in texts and "79005556677" in texts and f"#{t['number']}" in texts
    await env.client.post("/api/agents/me/notifications/seen", headers=ha)
    assert (await env.client.get("/api/agents/me/notifications", headers=ha)).json()["unread"] == 0


async def test_supervisor_sees_sync_errors_of_operators(env):
    ha, hb = await env.login("anna"), await env.login("boss")
    env.pbx.connected_flag = False
    await env.services.engine.on_ami_disconnect()
    n = (await env.client.get("/api/agents/me/notifications", headers=hb)).json()
    assert any(i["kind"] == "sync" and i["level"] == "error" and "Анна" in i["text"] for i in n["items"])
    n = (await env.client.get("/api/agents/me/notifications", headers=ha)).json()
    assert any(i["kind"] == "sync" for i in n["items"])


async def test_supervisor_assigns_by_ticket_number(env):
    hb, hbor = await env.login("boss"), await env.login("boris")
    await env.client.post("/api/agents/me/ready", headers=hbor)
    t = env.zammad.add_ticket("Needs Boris", owner_id=1, state="new")
    r = await env.client.post("/api/admin/assign", json={"ticket": f"#{t['number']}", "agent_id": 2, "work_mode": "blocking"}, headers=hb)
    assert r.status_code == 200, r.text
    assert env.zammad.tickets[t["id"]]["owner_id"] == 11 and env.pbx.is_paused("Local/102@from-queue/n")
    n = (await env.client.get("/api/agents/me/notifications", headers=hbor)).json()
    assert any("assigned to you" in i["text"] for i in n["items"])
    assert (await env.client.post("/api/admin/assign", json={"ticket": "99999999", "agent_id": 2}, headers=hb)).status_code in (404, 502)
    assert (await env.client.post("/api/admin/assign", json={"ticket": t["number"], "agent_id": 2}, headers=hbor)).status_code == 403
