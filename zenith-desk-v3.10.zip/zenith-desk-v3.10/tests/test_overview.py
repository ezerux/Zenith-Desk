"""Manager overview (v2.5): every number checked against a hand-calculated scenario."""
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace as NS

import pytest

from app.metrics import compute_overview, intersect, total, union

from .conftest import IF1, IF2

D = datetime(2026, 10, 10, tzinfo=timezone.utc)


def at(h, m=0, s=0):
    return D + timedelta(hours=h, minutes=m, seconds=s)


def qc(link, joined, outcome, wait, agent=None, talk=None, number="", left=True):
    answered = joined + timedelta(seconds=wait) if outcome == "answered" else None
    return NS(linkedid=link, joined_at=joined, outcome=outcome, wait_sec=wait if outcome != "waiting" else None,
              answered_at=answered, talk_sec=talk, agent_id=agent, queue="400", caller_number=number,
              caller_normalized=number, caller_name="", left_at=(joined + timedelta(seconds=wait)) if left else None,
              ended_at=(answered + timedelta(seconds=talk)) if answered and talk else None)


def rec(link, agent, started, answered=None, ended=None, direction="in", state=None, number=""):
    return NS(linkedid=link, agent_id=agent, started_at=started, answered_at=answered, ended_at=ended, direction=direction,
              state=state or ("ended" if answered and ended else "missed" if ended else "ringing"), queue="400",
              caller_normalized=number, caller_number=number, caller_name="")


def ev(agent, ts, new):
    return NS(agent_id=agent, ts=ts, details={"new": new})


def scenario():
    agents = [NS(id=1, display_name="Anna", level="level1", position="", extension="101", active=True),
              NS(id=2, display_name="Boris", level="level2", position="", extension="102", active=True)]
    queue_calls = [
        qc("L1", at(9), "answered", 10, agent=1, talk=120),
        qc("L2", at(9, 30), "answered", 40, agent=2, talk=60),
        qc("L3", at(10), "abandoned", 3),                        # short abandon: not counted in rates
        qc("L4", at(10, 15), "abandoned", 50, number="79004"),   # missed, called back at 10:30
        qc("L5", at(11), "exited", 90, number="79005"),          # missed (queue timeout), never called back
        qc("L6", at(11, 59, 50), "waiting", 0, left=False),      # still waiting at 12:00
    ]
    records = [
        rec("L1", 2, at(9), ended=at(9, 0, 5)),                               # Boris did not pick up -> RONA
        rec("L1", 1, at(9, 0, 5), answered=at(9, 0, 10), ended=at(9, 2, 10)),
        rec("L2", 1, at(9, 30), ended=at(9, 30, 40)),                         # cancelled: Boris answered -> not RONA
        rec("L2", 2, at(9, 30), answered=at(9, 30, 40), ended=at(9, 31, 40)),
        rec("O1", 1, at(10, 30), answered=at(10, 30, 5), ended=at(10, 31, 5), direction="out", number="79004"),
    ]
    sessions = [NS(agent_id=1, state="completed", work_mode="blocking", source="phone", started_at=at(10), ended_at=at(10, 30)),
                NS(agent_id=2, state="active", work_mode="background", source="email", started_at=at(11), ended_at=None)]
    events = [ev(1, at(8), "ready"), ev(1, at(10), "busy_task"), ev(1, at(10, 30), "ready"),
              ev(1, at(11), "break"), ev(1, at(11, 30), "ready")]
    states_now = {1: NS(computed_state="ready"), 2: NS(computed_state="ready")}
    return compute_overview(start=D, end=D + timedelta(days=1), now=at(12), tz="UTC", agents=agents, states_now=states_now,
                            queue_calls=queue_calls, records=records, sessions=sessions, events=events,
                            initial_states={1: "offline", 2: "ready"}, sla_sec=20, short_sec=5, sla_target=0.8)


def test_interval_helpers():
    a = [(at(1), at(3)), (at(2), at(4)), (at(6), at(7))]
    assert union(a) == [(at(1), at(4)), (at(6), at(7))]
    assert total(a) == 4 * 3600
    assert intersect(a, [(at(3), at(6, 30))]) == [(at(3), at(4)), (at(6), at(6, 30))]


def test_call_metrics_follow_contact_center_definitions():
    c = scenario()["calls"]
    assert c["offered"] == 5 and c["answered"] == 2
    assert c["short_abandoned"] == 1 and c["abandoned"] == 1 and c["unanswered"] == 1 and c["missed"] == 2
    assert c["answer_rate"] == 0.5          # 2 / (5 - 1 short abandon)
    assert c["abandon_rate"] == 0.25        # 1 / 4
    assert c["service_level"] == 0.25       # only L1 answered within 20 s: 1 / 4
    assert c["asa_sec"] == 25.0             # (10 + 40) / 2
    assert c["aht_talk_sec"] == 90.0        # (120 + 60) / 2
    assert c["longest_wait_sec"] == 90
    assert c["outbound"] == 1 and c["outbound_connected"] == 1


def test_live_and_unreturned_missed_calls():
    o = scenario()
    assert o["live"]["waiting"] == 1 and o["live"]["longest_wait_sec"] == 10
    assert o["unreturned_count"] == 1 and o["unreturned"][0]["number"] == "79005"   # 79004 was called back


def test_operator_time_occupancy_rona_and_engagement():
    rows = {r["agent_id"]: r for r in scenario()["agents"]}
    anna, boris = rows[1], rows[2]
    assert anna["logged_in_sec"] == 4 * 3600 and anna["break_sec"] == 1800 and anna["ready_sec"] == 3 * 3600
    assert anna["busy_task_sec"] == 1800
    assert anna["calls_rang"] == 2 and anna["calls_answered"] == 1 and anna["rona"] == 0   # L2 ring was cancelled
    assert anna["talk_sec"] == 180                     # 120 s inbound + 60 s outbound
    assert anna["productive_sec"] == 1980              # talk 180 + blocking task 1800
    assert anna["occupancy"] == round(1980 / 12600, 4)
    assert anna["break_share"] == 0.125
    assert anna["engagement"] == 80                    # 100 * (0.5*1 + 0.3*0.875 + 0.2*(0.1571/0.85))
    assert anna["tickets_completed"] == 1 and anna["avg_ticket_work_sec"] == 1800.0
    assert boris["rona"] == 1 and boris["answer_reliability"] == 0.5
    assert boris["logged_in_sec"] == 12 * 3600 and boris["engagement"] == 55
    assert "low_occupancy" in boris["flags"] and "rona" not in boris["flags"]


def test_workload_series_tickets_and_leaders():
    o = scenario()
    assert o["bucket"] == "hour" and len(o["series"]) == 24
    h9 = o["series"][9]
    assert h9["label"] == "09:00" and h9["offered"] == 2 and h9["answered"] == 2
    assert h9["agents_avg"] == 2.0                     # Anna and Boris logged in for the whole hour
    assert h9["erlangs"] == round(180 / 3600, 2)       # 120 s + 60 s of talk
    assert o["series"][10]["offered"] == 2 and o["series"][10]["missed"] == 1
    assert o["peak"]["offered"] == 2
    assert o["tickets"]["completed"] == 1 and o["tickets"]["active_background"] == 1
    assert o["tickets"]["by_channel"] == {"phone": 1}
    assert [(x["name"], x["value"]) for x in o["leaders"]["answered"]] == [("Anna", 1), ("Boris", 1)]
    assert [(x["name"], x["value"]) for x in o["leaders"]["tickets"]] == [("Anna", 1)]


@pytest.mark.asyncio
async def test_overview_from_real_ami_events(env):
    calls = env.services.calls
    # answered call: joins queue, Anna's phone rings, she answers after 7 s and talks 33 s
    for e in [
        {"Event": "QueueCallerJoin", "Queue": "400", "Linkedid": "A1", "Uniqueid": "A1", "CallerIDNum": "89123456789"},
        {"Event": "AgentCalled", "Queue": "400", "Interface": IF1, "Linkedid": "A1", "Uniqueid": "A1", "CallerIDNum": "89123456789"},
        {"Event": "QueueCallerLeave", "Queue": "400", "Linkedid": "A1", "Uniqueid": "A1"},
        {"Event": "AgentConnect", "Queue": "400", "Interface": IF1, "Linkedid": "A1", "Uniqueid": "A1", "HoldTime": "7", "RingTime": "3"},
        {"Event": "AgentComplete", "Queue": "400", "Interface": IF1, "Linkedid": "A1", "Uniqueid": "A1", "HoldTime": "7", "TalkTime": "33"},
        {"Event": "Hangup", "Linkedid": "A1", "Uniqueid": "A1"},
        # abandoned call: Boris' phone rings, nobody answers, the caller hangs up after 30 s
        {"Event": "QueueCallerJoin", "Queue": "400", "Linkedid": "B1", "Uniqueid": "B1", "CallerIDNum": "89990001122"},
        {"Event": "AgentCalled", "Queue": "400", "Interface": IF2, "Linkedid": "B1", "Uniqueid": "B1", "CallerIDNum": "89990001122"},
        {"Event": "AgentRingNoAnswer", "Queue": "400", "Interface": IF2, "Linkedid": "B1", "Uniqueid": "B1"},
        {"Event": "QueueCallerAbandon", "Queue": "400", "Linkedid": "B1", "Uniqueid": "B1", "HoldTime": "30"},
        {"Event": "QueueCallerLeave", "Queue": "400", "Linkedid": "B1", "Uniqueid": "B1"},
        {"Event": "Hangup", "Linkedid": "B1", "Uniqueid": "B1"},
    ]:
        await calls.handle_event(e)
    r = await env.client.get("/api/admin/overview", headers=await env.login("boss"))
    assert r.status_code == 200, r.text
    o = r.json()
    c = o["calls"]
    assert c["offered"] == 2 and c["answered"] == 1 and c["abandoned"] == 1 and c["missed"] == 1
    assert c["asa_sec"] == 7.0 and c["aht_talk_sec"] == 33.0 and c["service_level"] == 0.5
    assert o["unreturned_count"] == 1 and o["unreturned"][0]["number"].endswith("9990001122")
    rows = {a["agent_id"]: a for a in o["agents"]}
    assert rows[1]["calls_answered"] == 1 and rows[2]["rona"] == 1
    assert 4 not in rows                                   # administrators are not in the statistics
    # other periods work and operators have no access
    assert (await env.client.get("/api/admin/overview?period=7d", headers=await env.login("boss"))).json()["bucket"] == "day"
    assert (await env.client.get("/api/admin/overview", headers=await env.login("anna"))).status_code == 403
