"""Live mode (v2.7): every committed change is pushed to the right browsers, rolled-back ones are not."""
import json

import pytest

from app.models import AuditLog


class Spy:
    def __init__(self, broker):
        self.events = []
        for name in ("publish_agent", "publish_all", "publish_supervisors"):
            orig = getattr(broker, name)

            def wrap(*args, _n=name, _o=orig):
                self.events.append((_n, args))
                return _o(*args)
            setattr(broker, name, wrap)

    def changed(self, kind, agent_id=None):
        topics = set()
        for name, args in self.events:
            if name != kind:
                continue
            if kind == "publish_agent":
                aid, ev, data = args
                if ev == "changed" and aid == agent_id:
                    topics |= set(data["topics"])
            else:
                ev, data = args
                if ev == "changed":
                    topics |= set(data["topics"])
        return topics


@pytest.mark.asyncio
async def test_starting_work_is_pushed_to_operator_and_managers(env):
    spy = Spy(env.services.broker)
    h = await env.login("anna")
    t = env.zammad.add_ticket("Live", owner_id=10, state="open")
    r = await env.client.post(f"/api/tickets/{t['id']}/start", json={"work_mode": "blocking"}, headers=h)
    assert r.status_code == 200, r.text
    assert {"tasks", "notifications"} <= spy.changed("publish_agent", 1)
    assert "team" in spy.changed("publish_supervisors")
    assert "tickets" in spy.changed("publish_all")


@pytest.mark.asyncio
async def test_rollback_publishes_nothing(env):
    spy = Spy(env.services.broker)
    async with env.services.db.sessionmaker() as s:
        s.add(AuditLog(action="test", agent_id=1))
        await s.flush()
        await s.rollback()
    assert not [e for e in spy.events if e[1] and "changed" in e[1]]


@pytest.mark.asyncio
async def test_admin_changes_reach_user_and_settings_reach_everyone(env):
    spy = Spy(env.services.broker)
    h = await env.login("root")
    users = (await env.client.get("/api/admin/users", headers=h)).json()
    boris = next(u for u in users if u["username"] == "boris")
    body = {k: boris[k] for k in ("first_name", "last_name", "username", "position", "extension", "asterisk_interface",
                                  "zammad_user_id", "active", "enabled") if k in boris}
    body.update(first_name="Boris", level="level3", position="Senior")
    r = await env.client.put(f"/api/admin/users/{boris['id']}", json=body, headers=h)
    assert r.status_code == 200, r.text
    assert "me" in spy.changed("publish_agent", boris["id"])         # Boris' screen updates his level at once
    assert "users" in spy.changed("publish_supervisors")
    r = await env.client.put("/api/admin/settings", json={"values": {"sla_answer_seconds": 30}}, headers=h)
    assert r.status_code == 200, r.text
    assert "config" in spy.changed("publish_all")


@pytest.mark.asyncio
async def test_stream_sends_hello_and_changed_events(env):
    broker = env.services.broker
    gen = broker.stream(1, supervisor=False, heartbeat=0.05)
    assert (await gen.__anext__()).startswith("retry:")
    assert (await gen.__anext__()).startswith("event: hello")
    broker.publish_agent(1, "changed", {"topics": ["tasks"]})
    msg = await gen.__anext__()
    assert msg.startswith("event: changed") and json.loads(msg.split("data: ")[1])["topics"] == ["tasks"]
    assert (await gen.__anext__()).startswith("event: ping")              # heartbeat is a real event
    await gen.aclose()


@pytest.mark.asyncio
async def test_zammad_webhook_refreshes_ticket_lists_everywhere(env):
    from .test_acceptance import sign
    spy = Spy(env.services.broker)
    t = env.zammad.add_ticket("New from Telegram", owner_id=1, state="new", article_type="telegram personal-message")
    body = json.dumps({"ticket": {"id": t["id"], "state": "new"}}).encode()
    hdrs = {"X-Hub-Signature": sign(body), "X-Zammad-Delivery": "live-1", "Content-Type": "application/json"}
    r = await env.client.post("/api/integrations/zammad/webhook", content=body, headers=hdrs)
    assert r.json()["status"] == "accepted"
    assert "tickets" in spy.changed("publish_all")   # every operator's "New requests" reloads at once
