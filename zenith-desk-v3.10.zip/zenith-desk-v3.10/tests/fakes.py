"""In-memory fakes of Asterisk queues and the Zammad REST API used by the tests."""
import base64
import json
import re
from itertools import count

import httpx

from app.ami import AMINotConnected, AMIError
from app.pbx import MemberStatus


class FakePbx:
    def __init__(self, queues: list[str], members: list[str]):
        self.connected_flag = True
        self.members = {q: {m: {"paused": False, "reason": ""} for m in members} for q in queues}
        self.commands: list[tuple] = []
        self.ignore_commands = False  # simulate Asterisk not applying a command

    @property
    def connected(self) -> bool:
        return self.connected_flag

    def is_paused(self, interface: str) -> bool:
        return all(self.members[q][interface]["paused"] for q in self.members if interface in self.members[q])

    async def member_status(self, interface: str, queues: list[str]) -> dict[str, MemberStatus]:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        out = {}
        for q in queues:
            m = self.members.get(q, {}).get(interface)
            out[q] = MemberStatus(queue=q, present=m is not None, paused=bool(m and m["paused"]),
                                  paused_reason=m["reason"] if m else "")
        return out

    async def set_paused(self, interface: str, queue: str, paused: bool, reason: str) -> None:
        if not self.connected_flag:
            raise AMINotConnected("AMI is not connected")
        m = self.members.get(queue, {}).get(interface)
        if m is None:
            raise AMIError("Interface not found")
        self.commands.append((queue, interface, paused))
        if not self.ignore_commands:
            m["paused"], m["reason"] = paused, (reason if paused else "")


class FakeZammad:
    """Implements the subset of the Zammad API the service uses, with Zammad's own rules where they matter
    (owner needs full group access, state types, search paging, expanded names, "From" impersonation)."""

    STATES = {1: "new", 2: "open", 3: "pending reminder", 4: "closed", 5: "merged", 6: "pending close"}
    STATE_TYPES = {1: "new", 2: "open", 3: "pending reminder", 4: "closed", 5: "merged", 6: "pending action"}
    PRIORITIES = {1: "1 low", 2: "2 normal", 3: "3 high"}
    GROUPS = {1: "Users", 2: "Sales"}

    def __init__(self):
        self.ids = count(100)
        self.aids = count(5000)  # articles and files: ticket numbers stay 31100, 31101, … as in Zammad
        self.users: dict[int, dict] = {}
        self.passwords: dict[str, int] = {}
        self.tickets: dict[int, dict] = {}
        self.articles: list[dict] = []
        self.files: dict[int, bytes] = {}
        self.fail = False
        self.requests: list[tuple[str, str]] = []
        self.no_access: set[tuple[int, int]] = set()  # (user_id, ticket_id) hidden from that user
        self.clock = 0

    # helpers for tests
    def _now(self) -> str:
        from datetime import datetime, timedelta, timezone
        self.clock += 1
        return (datetime(2026, 10, 1, tzinfo=timezone.utc) + timedelta(seconds=self.clock)).isoformat().replace("+00:00", "Z")

    def add_user(self, uid: int, login: str, password: str = "pw", **kw) -> dict:
        roles = kw.pop("roles", None) or (["Customer"] if uid >= 50 else ["Agent"])
        groups = kw.pop("groups", None)
        if groups is None:
            groups = {"Users": ["full"]} if "Agent" in roles else {}
        u = {"id": uid, "login": login, "firstname": kw.pop("firstname", login), "lastname": kw.pop("lastname", ""),
             "email": kw.pop("email", f"{login}@example.test"), "active": True, "roles": roles, "groups": groups,
             "created_at": self._now(), **kw}
        u["updated_at"] = u["created_at"]
        self.users[uid] = u
        self.passwords[f"{login.lower()}:{password}"] = uid
        return u

    def touch_user(self, uid: int, **kw) -> dict:
        self.users[uid].update(kw, updated_at=self._now())
        return self.users[uid]

    def add_ticket(self, title: str, owner_id: int = 1, state: str = "new", article_type: str = "email", **kw) -> dict:
        tid = next(self.ids)
        group = kw.pop("group", "Users")
        priority = kw.pop("priority", "2 normal")
        now = self._now()
        t = {"id": tid, "number": str(31000 + tid), "title": title, "owner_id": owner_id, "customer_id": 50,
             "state_id": self._state_id(state), "create_article_type": article_type, "group": group,
             "group_id": self._gid(group), "priority_id": self._pid(priority), "created_at": now, "updated_at": now,
             "article_count": 0, **kw}
        self.tickets[tid] = t
        return t

    def add_article(self, tid: int, body: str, *, sender: str = "Customer", type: str = "email", internal: bool = False,
                    created_by_id: int | None = None, files: list[tuple[str, bytes]] | None = None, **kw) -> dict:
        t = self.tickets[tid]
        aid = next(self.aids)
        atts = []
        for name, data in files or []:
            fid = next(self.aids)
            self.files[fid] = data
            atts.append({"id": fid, "filename": name, "size": len(data), "preferences": {"Content-Type": "application/octet-stream"}})
        a = {"id": aid, "ticket_id": tid, "body": body, "sender": sender, "type": type, "internal": internal,
             "content_type": kw.pop("content_type", "text/plain"), "from": kw.pop("from", ""), "to": kw.pop("to", ""),
             "subject": kw.pop("subject", t["title"]), "created_by_id": created_by_id or t.get("customer_id"),
             "created_at": self._now(), "attachments": atts, **kw}
        self.articles.append(a)
        t["article_count"] = t.get("article_count", 0) + 1
        t["updated_at"] = a["created_at"]
        return a

    def _state_id(self, name: str) -> int:
        return next(i for i, n in self.STATES.items() if n == name)

    def _gid(self, name) -> int:
        return next((i for i, n in self.GROUPS.items() if n == name), 1)

    def _pid(self, name) -> int:
        return next((i for i, n in self.PRIORITIES.items() if n == name), 2)

    def state_of(self, tid: int) -> str:
        return self.STATES[self.tickets[tid]["state_id"]]

    def _expand(self, t: dict) -> dict:
        owner = self.users.get(t.get("owner_id") or 0, {})
        cust = self.users.get(t.get("customer_id") or 0, {})
        return {**t, "state": self.STATES[t["state_id"]], "priority": self.PRIORITIES.get(t.get("priority_id"), "2 normal"),
                "group": self.GROUPS.get(t.get("group_id"), t.get("group")), "owner": owner.get("login", "-"),
                "customer": cust.get("email") or cust.get("login", "")}

    def _can_read(self, uid: int | None, t: dict) -> bool:
        """Zammad's TicketPolicy::ReadScope: agents see tickets of their groups (and the ones they own)."""
        if not uid or uid not in self.users or (uid, t["id"]) in self.no_access:
            return not (uid and (uid, t["id"]) in self.no_access)
        u = self.users[uid]
        return t.get("owner_id") == uid or self.GROUPS.get(t.get("group_id"), t.get("group")) in (u.get("groups") or {})

    def _full_access(self, uid: int, group_id: int) -> bool:
        u = self.users.get(uid)
        return bool(u and "Agent" in u.get("roles", []) and "full" in (u.get("groups") or {}).get(self.GROUPS.get(group_id, ""), []))

    def _apply_update(self, t: dict, body: dict, actor: int | None) -> None:
        body = dict(body)
        article = body.pop("article", None)
        if "state" in body:
            body["state_id"] = self._state_id(body.pop("state"))
        if "priority" in body:
            body["priority_id"] = self._pid(body.pop("priority"))
        if "group" in body:
            body["group_id"] = self._gid(body["group"])
        t.update(body)
        if t.get("owner_id") not in (None, 1) and not self._full_access(t["owner_id"], t.get("group_id", 1)):
            t["owner_id"] = 1  # Zammad: Ticket#check_owner_active resets an owner without full access
        t["updated_at"] = self._now()
        if article:
            self._create_article(t["id"], article, actor)

    def _create_article(self, tid: int, body: dict, actor: int | None) -> dict:
        files = []
        for f in body.pop("attachments", None) or []:
            for key in ("filename", "data", "mime-type"):
                if key not in f:
                    raise ValueError(f"Attachment needs '{key}' param")
            files.append((f["filename"], base64.b64decode(f["data"])))
        body.pop("ticket_id", None)
        a = self.add_article(tid, body.pop("body"), sender=body.pop("sender", "Agent"), type=body.pop("type", "note"),
                             internal=body.pop("internal", False), created_by_id=actor or 1, files=files, **body)
        return a

    def transport(self) -> httpx.MockTransport:
        return httpx.MockTransport(self._handle)

    def _handle(self, req: httpx.Request) -> httpx.Response:
        path, method = req.url.path, req.method
        self.requests.append((method, path))
        if self.fail:
            return httpx.Response(503, json={"error": "down"})
        body = json.loads(req.content) if req.content else {}
        params = req.url.params
        obo = req.headers.get("from") or req.headers.get("x-on-behalf-of")
        actor = int(obo) if obo else None

        if path == "/api/v1/users/me":
            auth = req.headers.get("authorization", "")
            if auth.startswith("Token "):  # service token -> the service user
                return httpx.Response(200, json={"id": 1, "login": "ops-service", "email": "ops@zammad.test"})
            if auth.startswith("Basic "):
                login, _, pw = base64.b64decode(auth[6:]).decode().partition(":")
                uid = self.passwords.get(f"{login.lower()}:{pw}")
                if uid:
                    return httpx.Response(200, json=self.users[uid])
            return httpx.Response(401, json={"error": "auth"})
        if path == "/api/v1/ticket_states":
            return httpx.Response(200, json=[{"id": i, "name": n, "active": True, "state_type": self.STATE_TYPES[i]}
                                             for i, n in self.STATES.items()])
        if path == "/api/v1/ticket_priorities":
            return httpx.Response(200, json=[{"id": i, "name": n, "active": True, "default_create": i == 2}
                                             for i, n in self.PRIORITIES.items()])
        if path == "/api/v1/groups":
            allowed = self.GROUPS.items()
            if actor and actor in self.users:
                access = self.users[actor].get("groups") or {}
                allowed = [(i, n) for i, n in self.GROUPS.items() if n in access]
            return httpx.Response(200, json=[{"id": i, "name": n, "active": True} for i, n in allowed])
        if m := re.fullmatch(r"/api/v1/tickets/(\d+)", path):
            tid = int(m.group(1))
            if tid in self.tickets and not self._can_read(actor, self.tickets[tid]):
                return httpx.Response(403, json={"error": "Not authorized"})
            if tid not in self.tickets:
                return httpx.Response(404, json={"error": "not found"})
            if method == "PUT":
                try:
                    self._apply_update(self.tickets[tid], body, actor)
                except ValueError as exc:
                    return httpx.Response(422, json={"error": str(exc)})
            return httpx.Response(200, json=self._expand(self.tickets[tid]))
        if path == "/api/v1/tickets" and method == "POST":
            article = body.pop("article", None)
            t = self.add_ticket(body.pop("title"), owner_id=body.pop("owner_id", 1), state=body.pop("state", "new"),
                                article_type=(article or {}).get("type", "note"), **body)
            if t.get("owner_id") not in (None, 1) and not self._full_access(t["owner_id"], t["group_id"]):
                t["owner_id"] = 1
            if article:
                self._create_article(t["id"], dict(article), actor)
            return httpx.Response(201, json=self._expand(t))
        if m := re.fullmatch(r"/api/v1/ticket_articles/by_ticket/(\d+)", path):
            tid = int(m.group(1))
            if actor and (actor, tid) in self.no_access:
                return httpx.Response(403, json={"error": "Not authorized"})
            arts = [a for a in self.articles if a.get("ticket_id") == tid and "id" in a]
            return httpx.Response(200, json=arts)
        if m := re.fullmatch(r"/api/v1/ticket_attachment/(\d+)/(\d+)/(\d+)", path):
            data = self.files.get(int(m.group(3)))
            if data is None:
                return httpx.Response(404, json={"error": "not found"})
            return httpx.Response(200, content=data, headers={"content-type": "application/octet-stream",
                                                              "content-disposition": "attachment; filename=f"})
        if path == "/api/v1/ticket_articles":
            if "ticket_id" in body and int(body["ticket_id"]) in self.tickets and "body" in body:
                try:
                    a = self._create_article(int(body["ticket_id"]), dict(body), actor)
                except ValueError as exc:
                    return httpx.Response(422, json={"error": str(exc)})
                self.tickets[int(body["ticket_id"])]["updated_at"] = a["created_at"]
                return httpx.Response(201, json=a)
            self.articles.append(body)
            return httpx.Response(201, json={"id": next(self.aids), **body})
        if path == "/api/v1/tickets/search":
            cond = body.get("condition", {})
            q = str(body.get("query") or "").lower().strip("*")
            res = []
            for t in self.tickets.values():
                if not self._can_read(actor, t):
                    continue
                ok = True
                for key, c in cond.items():
                    field = key.split(".", 1)[1]
                    if c.get("pre_condition") == "not_set":
                        ok &= t.get(field) in (None, 1)
                    else:
                        ok &= str(t.get(field)) in [str(v) for v in c.get("value", [])]
                if ok and q:
                    ok = q in (t["title"] + " " + t["number"]).lower()
                if ok:
                    res.append(self._expand(t))
            if body.get("with_total_count"):  # the paged ticket lists (v3.3) are sorted like in Zammad
                res.sort(key=lambda x: (str(x.get(body.get("sort_by") or "updated_at") or ""), x["id"]), reverse=body.get("order_by", "desc") == "desc")
            per = int(body.get("per_page") or body.get("limit") or 50)
            page = int(body.get("page") or 1)
            chunk = res[(page - 1) * per: page * per]
            if body.get("with_total_count"):
                return httpx.Response(200, json={"records": chunk, "total_count": len(res)})
            return httpx.Response(200, json=chunk)
        if path == "/api/v1/users/search":
            q = params.get("query", "")
            digits = lambda s: re.sub(r"\D", "", s or "")  # noqa: E731
            if q == "*" or not q.isdigit():
                hay = lambda u: " ".join(str(u.get(k) or "") for k in ("login", "firstname", "lastname", "email", "note")).lower()  # noqa: E731
                res = [u for u in self.users.values() if q == "*" or q.lower() in hay(u)]
            else:
                res = [u for u in self.users.values() if q in digits(u.get("phone")) or q in digits(u.get("mobile"))]
            if params.get("sort_by") == "updated_at":
                res.sort(key=lambda u: (u.get("updated_at") or "", u["id"]), reverse=params.get("order_by") != "asc")
            if params.get("per_page"):
                per, page = int(params["per_page"]), int(params.get("page") or 1)
                res = res[(page - 1) * per: page * per]
            return httpx.Response(200, json=res)
        if m := re.fullmatch(r"/api/v1/users/(\d+)", path):
            return httpx.Response(200, json=self.users[int(m.group(1))])
        if path == "/api/v1/users" and method == "POST":
            uid = next(self.ids)
            self.users[uid] = {"id": uid, "roles": ["Customer"], "created_at": self._now(), **body}
            self.users[uid]["updated_at"] = self.users[uid]["created_at"]
            return httpx.Response(201, json=self.users[uid])
        return httpx.Response(404, json={"error": f"unhandled {method} {path}"})
