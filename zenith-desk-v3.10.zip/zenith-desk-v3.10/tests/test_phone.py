from app.phone import normalize_phone, phone_matches


def test_normalize_ru_formats():
    for raw in ["+7 (912) 345-67-89", "89123456789", "9123456789", "7 912 345 67 89"]:
        assert normalize_phone(raw) == "79123456789"


def test_international_and_short():
    assert normalize_phone("0037491123456") == "37491123456"
    assert normalize_phone("+374 91 123456") == "37491123456"
    assert normalize_phone("101") == "101"
    assert normalize_phone("") == ""


def test_matches():
    assert phone_matches("89123456789", "+7 912 345-67-89")
    assert not phone_matches("89123456789", "+7 912 345-67-80")
