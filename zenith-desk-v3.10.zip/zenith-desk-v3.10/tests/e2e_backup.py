"""v3.10 — end-to-end check of the Backup page in a real browser against the demo server.

    python -m scripts.demo &
    python tests/e2e_backup.py http://localhost:8000 [screenshots_dir]

Sets the password and the schedule, creates a backup, checks it, downloads it, uploads it again, restores the
whole system from it in the browser (live, with every background job running) and checks that the data written
after the backup is gone and everybody can sign in again.
"""
import asyncio
import json
import os
import sys
import tempfile
import urllib.request

from playwright.async_api import Page, async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
SHOTS = sys.argv[2] if len(sys.argv) > 2 else ""
PW = "Backup-Pass-2026"
RESULTS: list[tuple[str, bool, str]] = []


def http(method: str, path: str, data: dict | None = None, token: str = ""):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(data).encode() if data is not None else None,
                                 headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read() or b"null")


def token(user: str, password: str = "pw") -> str:
    return http("POST", "/api/auth/login", {"username": user, "password": password})["token"]


def expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


async def step(name: str, coro):
    try:
        await coro
        RESULTS.append((name, True, ""))
        print(f"  PASS  {name}")
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, False, str(exc)[:400]))
        print(f"  FAIL  {name}: {str(exc)[:400]}")


async def login(page: Page, user: str, password: str) -> None:
    await page.goto(BASE + "/")
    await page.wait_for_selector("input[autocomplete=username], .sidebar")
    if await page.locator(".sidebar").count():  # still signed in
        return
    await page.fill("input[autocomplete=username]", user)
    await page.fill("input[type=password]", password)
    await page.click("form button.primary")
    await page.wait_for_selector(".sidebar", timeout=8000)
    await page.wait_for_timeout(500)


async def nav(page: Page, key: str) -> None:
    if await page.locator(".burger").is_visible():
        await page.click(".burger")
    await page.click(f".side-nav button[data-nav={key}]")
    await page.wait_for_timeout(700)


async def shot(page: Page, name: str, full: bool = False) -> None:
    if SHOTS:
        os.makedirs(SHOTS, exist_ok=True)
        await page.evaluate("document.querySelectorAll('.toast').forEach((t) => { t.style.visibility = 'hidden'; })")
        await page.screenshot(path=os.path.join(SHOTS, name), full_page=full)
        await page.evaluate("document.querySelectorAll('.toast').forEach((t) => { t.style.visibility = ''; })")


async def main() -> int:
    tmp = tempfile.mkdtemp()
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        ctx = await browser.new_context(viewport={"width": 1440, "height": 900}, accept_downloads=True)
        page = await ctx.new_page()
        errors: list[str] = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        state: dict = {}

        async def open_page():
            await login(page, "admin", "admin")
            await nav(page, "backup")
            await page.wait_for_selector("[data-bk=no-password]")
            expect(await page.locator("[data-bk=create]").is_disabled(), "create must wait for a password")
            await shot(page, "backup-empty.png")
        await step("Backup page opens; asks for a password first", open_page())

        async def settings():
            await page.check("input[name=backup_enabled]")
            await page.select_option("select[name=backup_frequency]", "weekly")
            await page.wait_for_selector("select[name=backup_weekday]")
            await page.select_option("select[name=backup_weekday]", "sat")
            await page.fill("input[name=backup_time]", "02:30")
            await page.fill("input[name=backup_keep]", "5")
            await page.fill("input[name=backup_password]", "short")
            await page.click("[data-bk=save]")
            await page.wait_for_selector(".toast >> text=/8/", timeout=5000)  # “at least 8 characters”
            await page.fill("input[name=backup_password]", PW)
            await page.click("[data-bk=save]")
            await page.wait_for_selector("[data-bk=no-password]", state="detached", timeout=5000)
            v = http("GET", "/api/admin/backups", token=token("admin", "admin"))
            expect(v["enabled"] and v["frequency"] == "weekly" and v["weekday"] == "sat" and v["time"] == "02:30" and v["keep"] == 5,
                   f"saved {v['enabled'], v['frequency'], v['weekday'], v['time'], v['keep']}")
            expect(v["next_run_at"], "next run shown")
            nxt = await page.inner_text("[data-bk=next]")
            expect(nxt and nxt != "off", f"next: {nxt}")
        await step("Schedule, copies and password saved (short password refused)", settings())

        async def create():
            await page.click("[data-bk=create]")
            await page.wait_for_selector("tr[data-backup]", timeout=20000)
            await page.wait_for_selector("[data-bk=running]", state="detached", timeout=20000)
            state["name"] = await page.locator("tr[data-backup]").first.get_attribute("data-backup")
            expect(state["name"].endswith(".zdb"), state["name"])
            await shot(page, "backup-page.png")
        await step("Create backup now", create())

        async def change_after_backup():
            anna = token("anna")
            http("POST", "/api/chat/2/messages", {"body": "written AFTER the backup"}, token=anna)
            state["msgs_after"] = len(http("GET", "/api/chat/2/messages", token=anna)["messages"])
            adm = token("admin", "admin")
            http("PUT", "/api/admin/settings", {"values": {"attachment_max_mb": 33}}, token=adm)
        await step("Data changed after the backup", change_after_backup())

        async def verify():
            await page.locator(f"tr[data-backup='{state['name']}'] [data-act=verify]").click()
            await page.fill("input[name=bk-verify-password]", "wrong password")
            await page.click(".modal .btn.primary")
            await page.wait_for_selector(".toast.error, .toast >> text=/password/i", timeout=8000)
            await page.fill("input[name=bk-verify-password]", PW)
            await page.click(".modal .btn.primary")
            await page.wait_for_selector("[data-bk=verified]", timeout=15000)
            await shot(page, "backup-verify.png")
            await page.click(".modal .btn:not(.primary)")
        await step("Check: wrong password refused, right password → file complete", verify())

        async def download():
            async with page.expect_download() as d:
                await page.locator(f"tr[data-backup='{state['name']}'] [data-act=download]").click()
            dl = await d.value
            path = os.path.join(tmp, "moved-to-new-server.zdb")
            await dl.save_as(path)
            with open(path, "rb") as f:
                head = f.read(5)
            expect(head == b"ZDBK\x01", f"downloaded file header {head!r}")
            expect(os.path.getsize(path) > 1000, "size")
            state["file"] = path
        await step("Download the backup file", download())

        async def upload_and_restore():
            await page.set_input_files("input[type=file]", state["file"])
            await page.wait_for_selector(".modal >> text=/RESTORE/", timeout=15000)  # the restore dialog opens by itself
            expect(await page.locator("tr[data-backup='moved-to-new-server.zdb']").count() == 1, "uploaded file listed")
            go = page.locator("[data-bk=restore-go]")
            await page.fill("input[name=bk-restore-password]", PW)
            expect(await go.is_disabled(), "needs RESTORE typed")
            await page.fill("input[name=bk-restore-confirm]", "restore")
            await shot(page, "backup-restore-dialog.png")
            async with page.expect_navigation(timeout=40000):  # the page reloads by itself when the restore is done
                await go.click()
            await page.wait_for_selector("input[autocomplete=username], .sidebar", timeout=15000)
        await step("Upload the file and restore the whole system from the browser", upload_and_restore())

        async def after():
            anna = token("anna")
            msgs = http("GET", "/api/chat/2/messages", token=anna)["messages"]
            expect(len(msgs) == state["msgs_after"] - 1, f"messages {len(msgs)} vs {state['msgs_after']}")
            expect(not any("AFTER the backup" in m["body"] for m in msgs), "message written after the backup is gone")
            adm = token("admin", "admin")
            groups = http("GET", "/api/admin/settings", token=adm)["groups"]
            val = [i["value"] for g in groups for i in g["items"] if i["key"] == "attachment_max_mb"][0]
            expect(val != 33, f"setting changed after the backup is back: {val}")
            v = http("GET", "/api/admin/backups", token=adm)
            kinds = sorted(b["kind"] for b in v["items"])
            expect(any(b["kind"] == "pre-restore" for b in v["items"]), f"safety copy: {kinds}")
            h = http("GET", "/api/health")
            expect(h["status"] == "ok" and h["integrations"]["telegram"] == "ok" and h["integrations"]["whatsapp"] == "ok", str(h))
            n = http("GET", "/api/agents/me/notifications", token=adm)
            expect(any(i["kind"] == "backup" for i in n["items"]), "restore in the notifications")
        await step("After restore: data of the backup, safety copy, integrations running, notification", after())

        async def telegram_after_restore():
            # the messenger polling was stopped and started again: a new customer message still arrives
            marker = f"after-restore-{os.getpid()}"
            req = urllib.request.Request(BASE + f"/demo/telegram/message?text={marker}", method="POST")
            urllib.request.urlopen(req).read()
            anna = token("anna")
            for _ in range(30):
                convs = http("GET", "/api/msg/conversations?view=unassigned&channel=telegram", token=anna)
                items = convs.get("items", convs) if isinstance(convs, dict) else convs
                if any(marker in json.dumps(c, ensure_ascii=False) for c in items):
                    return
                await asyncio.sleep(0.5)
            raise AssertionError("telegram message after restore did not arrive")
        await step("Telegram works after the restore (jobs restarted)", telegram_after_restore())

        async def screens():
            await login(page, "admin", "admin")
            await nav(page, "backup")
            await page.wait_for_selector("tr[data-backup]")
            await shot(page, "backup-after-restore.png")
            await page.set_viewport_size({"width": 390, "height": 844})
            await page.wait_for_timeout(400)
            await shot(page, "backup-mobile.png", full=True)
            width = await page.evaluate("document.documentElement.scrollWidth")
            expect(width <= 392, f"no horizontal scroll on a phone: {width}")
            await page.set_viewport_size({"width": 1440, "height": 900})
        await step("Screens (desktop, phone)", screens())

        async def no_js_errors():
            expect(not errors, "; ".join(errors[:3]))
        await step("No JavaScript errors", no_js_errors())
        await browser.close()
    failed = [r for r in RESULTS if not r[1]]
    print(f"\n{len(RESULTS) - len(failed)}/{len(RESULTS)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
