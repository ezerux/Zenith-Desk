"""Contract test (v3.2): every request our Zammad client sends is checked against the rules of the real
Zammad REST API (verified in Zammad's source: config/routes, controllers, lib/selector/sql.rb,
app/jobs/trigger_webhook_job.rb, lib/user_agent.rb). The fake answers in the exact shapes Zammad returns."""
import hashlib
import hmac
import json

import httpx
import pytest

from app.zammad import ZammadClient, ZammadError

TOKEN = "tok123"
STATES = [{"id": 1, "name": "new"}, {"id": 2, "name": "open"}, {"id": 3, "name": "pending reminder"},
          {"id": 4, "name": "closed"}]
TICKETS = {7: {"id": 7, "number": "31007", "title": "Refund", "owner_id": 5, "state_id": 2, "customer_id": 9},
           8: {"id": 8, "number": "31008", "title": "New one", "owner_id": 1, "state_id": 1, "customer_id": 9}}
VALID_OPERATORS = {"is", "is not", "contains", "contains not"}
calls: list[httpx.Request] = []


def _valid_condition(cond: dict) -> bool:
    """Mirror of Zammad's selector validation (lib/selector/sql.rb, Selector::Base)."""
    for attr, rule in cond.items():
        if "." not in attr or rule.get("operator") not in VALID_OPERATORS:
            return False
        pre = rule.get("pre_condition")
        if pre is not None and not (pre.startswith("not_set") or pre.startswith("current_user.") or pre.startswith("specific")):
            return False
        if pre in (None, "specific") and rule.get("value") in (None, "", []):
            return False
    return True


def _match(t: dict, cond: dict) -> bool:
    for attr, rule in cond.items():
        field = attr.split(".", 1)[1]
        if rule.get("pre_condition") == "not_set":
            ok = t.get(field) in (None, 1)  # Zammad: IS NULL OR IN (1)
        else:
            vals = rule["value"] if isinstance(rule["value"], list) else [rule["value"]]
            ok = str(t.get(field)) in {str(v) for v in vals}
        if (rule["operator"] == "is") != ok:
            return False
    return True


def handler(full_form: bool = False):
    def h(req: httpx.Request) -> httpx.Response:
        calls.append(req)
        if req.headers.get("Authorization") != f"Token token={TOKEN}":
            return httpx.Response(401, json={"error": "authentication failed"})
        p, m = req.url.path, req.method
        body = json.loads(req.content) if req.content else {}
        if (m, p) == ("GET", "/api/v1/users/me"):
            return httpx.Response(200, json={"id": 3, "login": "admin"})
        if (m, p) == ("GET", "/api/v1/ticket_states"):
            if req.url.params.get("expand") == "true":  # attributes_with_association_names: state_type by name
                return httpx.Response(200, json=[{**st, "state_type": st["name"], "active": True} for st in STATES])
            return httpx.Response(200, json=STATES)
        if (m, p) == ("GET", "/api/v1/ticket_priorities"):
            return httpx.Response(200, json=[{"id": 2, "name": "2 normal", "active": True, "default_create": True}])
        if (m, p) == ("GET", "/api/v1/groups"):
            assert req.headers.get("From") == "5"  # GroupPolicy::Scope of the operator
            return httpx.Response(200, json=[{"id": 1, "name": "Users", "name_last": "Users", "active": True}])
        if (m, p) == ("GET", "/api/v1/ticket_articles/by_ticket/7"):
            assert req.url.params.get("expand") == "true"
            return httpx.Response(200, json=[{"id": 1, "ticket_id": 7, "body": "hi", "type": "email", "sender": "Customer"}])
        if (m, p) == ("GET", "/api/v1/ticket_attachment/7/1/3"):
            return httpx.Response(200, content=b"PDF", headers={"content-type": "application/pdf"})
        if (m, p) == ("POST", "/api/v1/tickets/search"):
            if not _valid_condition(body.get("condition", {})):
                return httpx.Response(422, json={"error": "Invalid condition"})
            per_page = int(body.get("per_page") or body.get("limit") or 50)
            if per_page > 200 or body.get("sort_by") not in ("updated_at", "created_at"):
                return httpx.Response(422, json={"error": "bad paging"})
            found = [t for t in TICKETS.values() if _match(t, body["condition"])]
            if body.get("with_total_count") and body.get("expand"):  # renders_models: {records, total_count}
                page = int(body.get("page") or 1)
                return httpx.Response(200, json={"records": found[(page - 1) * per_page: page * per_page], "total_count": len(found)})
            if full_form or not body.get("expand"):
                return httpx.Response(200, json={"record_ids": [t["id"] for t in found], "total_count": len(found),
                                                 "assets": {"Ticket": {str(t["id"]): t for t in found}}})
            return httpx.Response(200, json=[{**t, "state": "open"} for t in found])
        if m == "GET" and p.startswith("/api/v1/tickets/"):
            t = TICKETS.get(int(p.rsplit("/", 1)[1]))
            return httpx.Response(200, json=t) if t else httpx.Response(404, json={"error": "Couldn't find Ticket"})
        if (m, p) == ("PUT", "/api/v1/tickets/7"):
            return httpx.Response(200, json={**TICKETS[7], **body})
        if (m, p) == ("POST", "/api/v1/tickets"):
            art = body.get("article") or {}
            if not body.get("title") or not (body.get("group") or body.get("group_id")) or not body.get("customer_id"):
                return httpx.Response(422, json={"error": "title, group and customer are required"})
            if not art.get("body") or art.get("type") not in ("note", "phone", "email", "web"):
                return httpx.Response(422, json={"error": "bad article"})
            return httpx.Response(201, json={"id": 99, "number": "31099", **{k: v for k, v in body.items() if k != "article"}})
        if (m, p) == ("POST", "/api/v1/ticket_articles"):
            if not body.get("ticket_id") or body.get("type") != "note" or body.get("content_type") not in ("text/plain", "text/html"):
                return httpx.Response(422, json={"error": "bad article"})
            return httpx.Response(201, json={"id": 500, **body, "type": "note", "sender": "Agent"})
        if (m, p) == ("GET", "/api/v1/users/search") and req.url.params.get("per_page"):
            prm = req.url.params
            assert prm["query"] == "*" and prm["sort_by"] == "updated_at" and int(prm["per_page"]) <= 200
            if prm["page"] == "1":
                return httpx.Response(200, json=[{"id": 9, "firstname": "Ivan", "roles": ["Customer"], "updated_at": "2026-10-01T10:00:00.000Z"}])
            return httpx.Response(200, json=[])
        if (m, p) == ("GET", "/api/v1/users/search"):
            if not req.url.params.get("query"):
                return httpx.Response(422, json={"error": "query required"})
            return httpx.Response(200, json=[{"id": 9, "firstname": "Ivan", "phone": "+79001112233"}])
        if (m, p) == ("POST", "/api/v1/users"):
            return httpx.Response(201, json={"id": 10, **body})
        return httpx.Response(404, json={"error": f"No route matches [{m}] {p}"})
    return h


@pytest.fixture
def z():
    calls.clear()
    return ZammadClient("https://zammad.example", TOKEN, transport=httpx.MockTransport(handler()))


async def test_states_and_search_conditions_are_valid(z):
    assert await z.state_ids(["new", "open"]) == [1, 2]
    mine = await z.search_tickets({"ticket.owner_id": {"operator": "is", "pre_condition": "specific", "value": ["5"]},
                                   "ticket.state_id": {"operator": "is", "value": [1, 2, 3]}})
    assert [t["id"] for t in mine] == [7]
    unassigned = await z.search_tickets({"ticket.owner_id": {"operator": "is", "pre_condition": "not_set"},
                                         "ticket.state_id": {"operator": "is", "value": [1]}})
    assert [t["id"] for t in unassigned] == [8]
    by_number = await z.search_tickets({"ticket.number": {"operator": "is", "value": ["31008"]}})
    assert by_number[0]["id"] == 8


async def test_search_full_response_shape():
    calls.clear()
    z = ZammadClient("https://zammad.example", TOKEN, transport=httpx.MockTransport(handler(full_form=True)))
    found = await z.search_tickets({"ticket.customer_id": {"operator": "is", "pre_condition": "specific", "value": ["9"]}})
    assert sorted(t["id"] for t in found) == [7, 8]
    assert ZammadClient._search_records({"records": [{"id": 1}], "total_count": 1}, "Ticket") == [{"id": 1}]
    assert ZammadClient._search_records({"tickets": [2], "assets": {"Ticket": {"2": {"id": 2}}}}, "Ticket") == [{"id": 2}]


async def test_on_behalf_header_for_old_and_new_zammad(z):
    await z.get_ticket(7, on_behalf_of=5)
    assert calls[-1].headers["From"] == "5" and calls[-1].headers["X-On-Behalf-Of"] == "5"
    await z.get_ticket(7)
    assert "From" not in calls[-1].headers


async def test_ticket_create_update_note_users(z):
    t = await z.create_ticket({"title": "Call", "group": "Users", "customer_id": 9, "owner_id": 5,
                               "article": {"subject": "Call", "body": "Talked", "type": "phone", "internal": False,
                                           "sender": "Agent", "content_type": "text/plain"}})
    assert t["id"] == 99
    assert (await z.update_ticket(7, {"state": "closed"}))["state"] == "closed"
    assert (await z.add_note(7, "done"))["id"] == 500
    assert (await z.search_users("Ivan"))[0]["id"] == 9
    assert (await z.create_user({"firstname": "A", "phone": "1"}))["id"] == 10
    with pytest.raises(ZammadError) as e:
        await z.get_ticket(12345)
    assert e.value.status == 404


async def test_wrong_token_is_reported():
    z = ZammadClient("https://zammad.example", "bad", transport=httpx.MockTransport(handler()))
    with pytest.raises(ZammadError) as e:
        await z.me()
    assert e.value.status == 401


async def test_webhook_signature_like_zammad(env):
    """Zammad (lib/user_agent.rb): X-Hub-Signature = "sha1=" + HMAC-SHA1(token, raw body)."""
    client = env.client
    secret = env.settings.zammad_webhook_secret.encode()
    raw = json.dumps({"ticket": {"id": 7, "state": "open", "owner_id": 5}, "article": {}}).encode()
    sig = "sha1=" + hmac.new(secret, raw, hashlib.sha1).hexdigest()
    headers = {"Content-Type": "application/json", "X-Hub-Signature": sig, "X-Zammad-Trigger": "Zenith Desk",
               "X-Zammad-Delivery": "job-abc"}
    r = await client.post("/api/integrations/zammad/webhook", content=raw, headers=headers)
    assert r.status_code == 200 and r.json()["status"] == "accepted"
    r = await client.post("/api/integrations/zammad/webhook", content=raw, headers=headers)
    assert r.json()["status"] == "duplicate"
    bad = {**headers, "X-Hub-Signature": "sha1=00", "X-Zammad-Delivery": "job-x"}
    assert (await client.post("/api/integrations/zammad/webhook", content=raw, headers=bad)).status_code == 401


async def test_ticketing_endpoints_v33(z):
    states = await z.state_list()
    assert {s["name"]: s["type"] for s in states}["pending reminder"] == "pending reminder"
    assert (await z.priorities())[0]["default"] is True
    assert (await z.groups(5))[0]["name"] == "Users"
    records, total = await z.search_tickets_page({"ticket.state_id": {"operator": "is", "value": ["1", "2"]}},
                                                 page=1, per_page=1, on_behalf_of=5)
    assert total == 2 and len(records) == 1
    assert (await z.articles(7, 5))[0]["sender"] == "Customer"
    assert (await z.attachment(7, 1, 3, 5)).content == b"PDF"
    assert [u["id"] for u in await z.users_page(1)] == [9] and await z.users_page(2) == []
