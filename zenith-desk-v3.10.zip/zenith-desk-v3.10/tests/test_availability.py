"""Unit tests for the availability rules (ТЗ 4.3, FR-07, FR-08)."""
import pytest

from app.availability import compute_availability as ca


def test_ready_without_tasks():
    assert ca("ready", []).state == "ready"


def test_background_tasks_do_not_block():
    # background tasks are simply not passed as blocking
    assert ca("ready", []).should_be_paused is False


def test_one_blocking_means_busy():
    a = ca("ready", ["31001"])
    assert a.state == "busy_task" and a.should_be_paused and "#31001" in a.reason


def test_two_blocking_still_busy():
    assert ca("ready", ["1", "2"]).state == "busy_task"


@pytest.mark.parametrize("manual", ["offline", "break"])
def test_manual_states_have_priority_over_blocking(manual):
    assert ca(manual, ["1"]).state == manual


def test_offline_beats_break_semantics():
    assert ca("offline", [], wrap_up_active=True).state == "offline"


def test_wrap_up():
    assert ca("ready", [], wrap_up_active=True).state == "wrap_up"
    assert ca("ready", ["1"], wrap_up_active=True).state == "busy_task"


def test_supervisor_override_ignores_blocking_but_not_break():
    assert ca("ready", ["1"], override_ready=True).state == "ready"
    assert ca("break", ["1"], override_ready=True).state == "break"


def test_messages_follow_ui_language():
    from app.i18n import set_language
    try:
        set_language("ru")
        assert ca("break", []).reason == "Перерыв"
        set_language("en")
        assert ca("break", []).reason == "On break"
        assert "2 blocking task(s)" in ca("ready", ["1", "2"]).reason
    finally:
        set_language("en")
