#!/bin/sh
# Builds the Windows programs of Zenith Desk:
#   dist/ZenithDesk-Setup-<version>.exe   — the installer (contains the program)
# Needs: mono-complete (mcs, C# for .NET Framework 4.8 / WinForms), binutils-mingw-w64 (windres), cpp.
# Works on Linux (or WSL). The result runs on Windows 10 / 11 with .NET Framework 4.8 (built into Windows).
set -e
cd "$(dirname "$0")"
VERSION=3.10
B=build; P=$B/payload; D=dist
rm -rf "$B"; mkdir -p "$P/runtimes" "$D"
WV=vendor/webview2
REFS="-r:System.dll -r:System.Core.dll -r:System.Drawing.dll -r:System.Windows.Forms.dll -r:System.Web.Extensions.dll"
MCS="mcs -sdk:4.5 -langversion:7 -platform:anycpu -optimize+ -nowarn:618 -warnaserror+ -debug-"

echo "== resources"
for k in setup client; do
  (cd res && x86_64-w64-mingw32-windres --preprocessor=cpp -O res -i $k.rc -o ../$B/$k.res)
done

echo "== ZenithDesk.exe (client)"
$MCS -target:winexe -win32res:$B/client.res $REFS -r:$WV/Microsoft.Web.WebView2.Core.dll -r:$WV/Microsoft.Web.WebView2.WinForms.dll \
  -resource:res/logo.png,logo.png -resource:res/app.ico,app.ico \
  -out:$P/ZenithDesk.exe src/Common/*.cs src/Client/*.cs src/Setup/Prereqs.cs
cp res/ZenithDesk.exe.config $P/
cp $WV/Microsoft.Web.WebView2.Core.dll $WV/Microsoft.Web.WebView2.WinForms.dll $P/
cp -r $WV/runtimes/* $P/runtimes/
cp res/THIRD-PARTY-NOTICES.txt $P/

echo "== payload list"
(cd $P && find . -type f | sed 's|^\./||' | sort) > $B/payload.txt
RES=""
for f in $(cat $B/payload.txt); do RES="$RES -resource:$P/$f,payload/$f"; done

echo "== ZenithDesk-Setup-$VERSION.exe (installer)"
$MCS -target:winexe -win32res:$B/setup.res $REFS $RES -resource:$B/payload.txt,payload.txt \
  -resource:res/logo.png,logo.png -resource:res/app.ico,app.ico \
  -out:$D/ZenithDesk-Setup-$VERSION.exe src/Common/*.cs src/Setup/*.cs
ls -la $D
