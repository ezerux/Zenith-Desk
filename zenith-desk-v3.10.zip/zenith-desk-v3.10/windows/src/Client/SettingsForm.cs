using System;
using System.Drawing;
using System.Windows.Forms;

namespace ZenithDesk.Client
{
    /// <summary>"Server settings": change the server address; saving is possible only after a successful test.</summary>
    public class SettingsForm : Form
    {
        public readonly ServerPanel Panel = new ServerPanel();
        public readonly Button Save = new Button(), Cancel = new Button();
        public ServerConfig Saved;

        public SettingsForm(ServerConfig current)
        {
            Text = Lang.T("cl.settings_title"); Icon = Ui.AppIcon; Font = Ui.Body; BackColor = Color.White;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = MinimizeBox = false; StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(560, 400); ShowInTaskbar = false;
            var head = new Panel { Bounds = new Rectangle(0, 0, 560, 62), BackColor = Color.White };
            head.Paint += (s, e) => {
                e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                if (Ui.Logo != null) e.Graphics.DrawImage(Ui.Logo, new Rectangle(500, 9, 44, 44));
                e.Graphics.DrawLine(SystemPens.ControlDark, 0, 61, 560, 61);
            };
            head.Controls.Add(Ui.Text(Lang.T("server.title"), 20, 11, 460, 20, Ui.Title));
            head.Controls.Add(Ui.Text(Lang.T("cl.settings_sub"), 34, 30, 456, 30, Ui.Small, Ui.Muted));
            Panel.Location = new Point(24, 78); Panel.Width = 512;
            Panel.SetConfig(current);
            var foot = new Panel { Bounds = new Rectangle(0, 348, 560, 52), BackColor = SystemColors.Control };
            foot.Paint += (s, e) => e.Graphics.DrawLine(SystemPens.ControlDark, 0, 0, 560, 0);
            Save.SetBounds(360, 13, 90, 27); Save.Text = Lang.T("btn.save"); Save.FlatStyle = FlatStyle.System; Save.Enabled = false; Save.Name = "save";
            Cancel.SetBounds(458, 13, 90, 27); Cancel.Text = Lang.T("btn.cancel"); Cancel.FlatStyle = FlatStyle.System; Cancel.DialogResult = DialogResult.Cancel;
            foot.Controls.AddRange(new Control[] { Save, Cancel });
            Controls.AddRange(new Control[] { head, Panel, foot });
            CancelButton = Cancel;
            Panel.PassedChanged += (s, e) => Save.Enabled = Panel.Passed;
            Save.Click += (s, e) => {
                if (!Panel.Passed) return;
                Saved = Panel.Result;
                try { Saved.Save(ServerConfig.UserFile); Log.Write("server settings saved: " + Saved.Display); }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                DialogResult = DialogResult.OK; Close();
            };
            AutoScaleDimensions = new SizeF(96f, 96f); AutoScaleMode = AutoScaleMode.Dpi;
        }
    }
}
