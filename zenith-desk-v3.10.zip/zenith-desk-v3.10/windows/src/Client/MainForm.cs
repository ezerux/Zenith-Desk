using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace ZenithDesk.Client
{
    /// <summary>
    /// The workplace window. It checks the server first (so a wrong address or a network problem is explained in words,
    /// with "Retry" and "Server settings"), then shows the Zenith Desk sign-in page in Microsoft Edge WebView2.
    /// Login stays remembered for the Windows user. Closing the window keeps the program in the notification area so
    /// calls are not missed.
    /// </summary>
    public class MainForm : Form
    {
        ServerConfig cfg;
        WebView2 web;
        bool webReady, reallyExit, trayHintShown;
        readonly Overlay overlay = new Overlay();
        readonly NotifyIcon tray = new NotifyIcon();
        readonly System.Windows.Forms.Timer retryTimer = new System.Windows.Forms.Timer { Interval = 1000 };
        int retryIn;
        string callState = "idle", userName = "";
        int unread;
        public string LastError = "";          // tests
        public Overlay Screen { get { return overlay; } }

        public MainForm()
        {
            Text = AppInfo.Product; Icon = Ui.AppIcon; Font = Ui.Body;
            MinimumSize = new Size(900, 600); BackColor = Ui.Navy;
            StartPosition = FormStartPosition.Manual;
            RestorePlacement();
            overlay.Dock = DockStyle.Fill;
            overlay.RetryClicked += (s, e) => Connect();
            overlay.SettingsClicked += (s, e) => OpenSettings();
            overlay.ExitClicked += (s, e) => ExitApp(false);
            overlay.InstallClicked += (s, e) => InstallWebView2();
            Controls.Add(overlay);

            tray.Icon = Ui.AppIcon; tray.Text = AppInfo.Product; tray.Visible = true;
            var menu = new ContextMenuStrip();
            menu.Items.Add(Lang.T("cl.tray_open"), null, (s, e) => ShowFromTray()).Font = Ui.Bold;
            menu.Items.Add(Lang.T("cl.settings"), null, (s, e) => OpenSettings());
            menu.Items.Add(Lang.T("cl.reload").Split('\t')[0], null, (s, e) => Reload());
            menu.Items.Add(Lang.T("cl.about"), null, (s, e) => About());
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(Lang.T("cl.exit"), null, (s, e) => ExitApp(true));
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += (s, e) => ShowFromTray();
            tray.BalloonTipClicked += (s, e) => ShowFromTray();

            retryTimer.Tick += (s, e) => {
                if (--retryIn <= 0) { retryTimer.Stop(); Connect(); }
                else overlay.SetCountdown(Lang.T("cl.retry_in", retryIn));
            };
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            AddSystemMenu();
            cfg = ServerConfig.Load();
            if (!cfg.IsSet)
            {
                overlay.ShowMessage(Status.Warn, Lang.T("cl.noconfig"), "", Overlay.Buttons.Settings | Overlay.Buttons.Exit);
                if (!AppInfo.IsTest) OpenSettings();
                return;
            }
            Connect();
        }

        // ------------------------------------------------------------------ connecting
        public void Connect()
        {
            retryTimer.Stop();
            if (cfg == null || !cfg.IsSet) { overlay.ShowMessage(Status.Warn, Lang.T("cl.noconfig"), "", Overlay.Buttons.Settings | Overlay.Buttons.Exit); return; }
            overlay.Visible = true; overlay.BringToFront();
            overlay.ShowMessage(Status.Busy, Lang.T("cl.connecting", cfg.Display), "", Overlay.Buttons.None);
            ConnectionTester.TestAsync(cfg).ContinueWith(t => {
                var r = t.Exception == null ? t.Result : new TestResult { Code = TestCode.Network, Title = Lang.T("test.net"), Detail = t.Exception.InnerException.Message };
                if (!IsDisposed) BeginInvoke((Action)(() => AfterTest(r)));
            });
        }

        void AfterTest(TestResult r)
        {
            Log.Write("server check: " + r);
            if (!r.Ok)
            {
                LastError = r.Title;
                overlay.ShowMessage(Status.Fail, Lang.T("cl.offline"), r.Title + "\n" + r.Detail, Overlay.Buttons.Retry | Overlay.Buttons.Settings | Overlay.Buttons.Exit);
                retryIn = 15; overlay.SetCountdown(Lang.T("cl.retry_in", retryIn)); retryTimer.Start();
                return;
            }
            if (webReady) { web.CoreWebView2.Navigate(cfg.BaseUrl); return; }
            InitWebView();
        }

        async void InitWebView()
        {
            try
            {
                // Microsoft Edge WebView2 exists only on Windows (the build machine's tests end here, with the install offer)
                if (!AppInfo.IsWindows) throw new DllNotFoundException("WebView2Loader.dll: Microsoft Edge WebView2 runs only on Windows");
                if (web == null)
                {
                    // stays visible behind the navy screen: WebView2 needs a real window handle to start
                    web = new WebView2 { Dock = DockStyle.Fill, DefaultBackgroundColor = Ui.Navy };
                    Controls.Add(web); overlay.BringToFront();
                }
                var args = "--autoplay-policy=no-user-gesture-required";
                // the phone needs the microphone, which browsers allow only on HTTPS — or on an origin marked as trusted:
                if (!cfg.Https) args += " --unsafely-treat-insecure-origin-as-secure=" + cfg.Origin;
                var env = await CoreWebView2Environment.CreateAsync(null, AppInfo.WebViewDataDir,
                                                                    new CoreWebView2EnvironmentOptions(args, Lang.IsRu ? "ru" : "en"));
                await web.EnsureCoreWebView2Async(env);
                var core = web.CoreWebView2;
                core.Settings.AreDevToolsEnabled = ClientProgram.DevTools;
                core.Settings.IsStatusBarEnabled = false;
                core.Settings.AreBrowserAcceleratorKeysEnabled = true;
                core.Settings.UserAgent = core.Settings.UserAgent + " ZenithDesk-Windows/" + AppInfo.Version;
                await core.AddScriptToExecuteOnDocumentCreatedAsync("window.zenithDesktop = { version: '" + AppInfo.Version + "', platform: 'windows' };");
                core.PermissionRequested += OnPermission;
                core.NewWindowRequested += OnNewWindow;
                core.NavigationStarting += OnNavigationStarting;
                core.NavigationCompleted += OnNavigationCompleted;
                core.WebMessageReceived += OnWebMessage;
                core.ProcessFailed += OnProcessFailed;
                core.ServerCertificateErrorDetected += OnCertificateError;
                core.DocumentTitleChanged += (s, e) => UpdateTitle();
                webReady = true;
                Log.Write("WebView2 " + env.BrowserVersionString + " ready, data " + AppInfo.WebViewDataDir);
                core.Navigate(cfg.BaseUrl);
            }
            catch (Exception e)
            {
                Log.Error("WebView2", e);
                LastError = e.GetType().Name;
                if (e is WebView2RuntimeNotFoundException || e is DllNotFoundException || e is BadImageFormatException || e is EntryPointNotFoundException)
                    overlay.ShowMessage(Status.Warn, Lang.T("cl.nowv"), Lang.T("cl.nowv_d"), Overlay.Buttons.Install | Overlay.Buttons.Exit);
                else
                    overlay.ShowMessage(Status.Fail, Lang.T("cl.wv_failed"), e.Message, Overlay.Buttons.Retry | Overlay.Buttons.Exit);
            }
        }

        bool SameOrigin(string uri)
        {
            try { var u = new Uri(uri); return string.Equals(u.Scheme + "://" + u.Authority, new Uri(cfg.BaseUrl).Scheme + "://" + new Uri(cfg.BaseUrl).Authority, StringComparison.OrdinalIgnoreCase); }
            catch { return false; }
        }

        static readonly HashSet<string> Allowed = new HashSet<string> { "Microphone", "Notifications", "ClipboardRead", "Autoplay", "MultipleAutomaticDownloads" };
        void OnPermission(object sender, CoreWebView2PermissionRequestedEventArgs e)
        {   // only the company's Zenith Desk server gets the microphone (phone) and notifications
            if (SameOrigin(e.Uri) && Allowed.Contains(e.PermissionKind.ToString())) e.State = CoreWebView2PermissionState.Allow;
            Log.Write("permission " + e.PermissionKind + " for " + e.Uri + ": " + e.State);
        }

        void OnNewWindow(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            if (SameOrigin(e.Uri)) return;          // attachments etc.: WebView2's own small window / download
            e.Handled = true; OpenExternal(e.Uri);  // Zammad and other sites: the normal browser
        }

        void OnNavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            if (SameOrigin(e.Uri) || e.Uri.StartsWith("about:") || e.Uri.StartsWith("data:")) return;
            e.Cancel = true; OpenExternal(e.Uri);
        }

        void OnNavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess) { overlay.Visible = false; UpdateTitle(); return; }
            Log.Write("navigation failed: " + e.WebErrorStatus);
            if (e.WebErrorStatus == CoreWebView2WebErrorStatus.OperationCanceled) return;
            Connect();   // explain what is wrong and retry
        }

        void OnCertificateError(object sender, CoreWebView2ServerCertificateErrorDetectedEventArgs e)
        {
            try
            {
                var thumb = e.ServerCertificate.ToX509Certificate2().Thumbprint;
                e.Action = cfg.CertThumbprint.Length > 0 && string.Equals(thumb, cfg.CertThumbprint, StringComparison.OrdinalIgnoreCase)
                    ? CoreWebView2ServerCertificateErrorAction.AlwaysAllow : CoreWebView2ServerCertificateErrorAction.Cancel;
            }
            catch { e.Action = CoreWebView2ServerCertificateErrorAction.Cancel; }
        }

        void OnProcessFailed(object sender, CoreWebView2ProcessFailedEventArgs e)
        {
            Log.Write("WebView2 process failed: " + e.ProcessFailedKind);
            if (e.ProcessFailedKind == CoreWebView2ProcessFailedKind.BrowserProcessExited)
            {
                webReady = false; Controls.Remove(web); web.Dispose(); web = null;
                tray.ShowBalloonTip(4000, AppInfo.Product, Lang.T("cl.crash"), ToolTipIcon.Warning);
                Connect();
            }
            else if (e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessExited || e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessUnresponsive)
                Reload();
        }

        // ------------------------------------------------------------------ messages from the web page (app.js)
        void OnWebMessage(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            Dictionary<string, object> m;
            try { m = Json.Read(e.WebMessageAsJson); } catch { return; }
            HandleMessage(m);
        }

        public void HandleMessage(Dictionary<string, object> m)
        {
            var type = Json.Str(m, "type");
            if (type == "call")
            {
                var st = Json.Str(m, "state", "idle");
                if (st == "ringing" && callState != "ringing") OnIncomingCall(Json.Str(m, "name"));
                callState = st;
            }
            else if (type == "unread") { unread = Json.Int(m, "n"); UpdateTitle(); }
            else if (type == "user") { userName = Json.Str(m, "name"); UpdateTitle(); }
        }

        void OnIncomingCall(string who)
        {
            bool away = !Visible || WindowState == FormWindowState.Minimized || !ContainsFocus;
            if (!away) return;
            Log.Write("incoming call while the window is in the background");
            if (!Visible) { Show(); WindowState = FormWindowState.Normal; }
            else if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Flash();
            tray.ShowBalloonTip(6000, Lang.T("cl.call_in"), who.Length > 0 ? who : AppInfo.Product, ToolTipIcon.Info);
        }

        void UpdateTitle()
        {
            var t = AppInfo.Product + (userName.Length > 0 ? " — " + userName : "");
            if (unread > 0) t = "(" + unread + ") " + t;
            Text = t;
            var tip = AppInfo.Product + (unread > 0 ? " — " + Lang.T("cl.unread", unread) : "");
            tray.Text = tip.Length > 63 ? tip.Substring(0, 63) : tip;
        }

        // ------------------------------------------------------------------ window, tray, menus
        public void ShowFromTray()
        {
            Show(); if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate(); BringToFront();
        }

        public void ShowFromOtherInstance()
        {
            var fresh = ServerConfig.Load();   // "Server settings" from the Start menu may have changed the server
            if (cfg != null && fresh.IsSet && !fresh.SameServer(cfg)) { cfg = fresh; RestartWeb(); }
            ShowFromTray();
        }

        void RestartWeb()
        {   // a new origin needs a new browser environment (HTTP trust flag), so the WebView is recreated
            if (web != null) { Controls.Remove(web); web.Dispose(); web = null; webReady = false; }
            Connect();
        }

        public void OpenSettings()
        {
            ShowFromTray();
            using (var f = new SettingsForm(cfg ?? ServerConfig.Load()))
                if (f.ShowDialog(this) == DialogResult.OK && f.Saved != null)
                {
                    var changed = cfg == null || !f.Saved.SameServer(cfg);
                    cfg = f.Saved;
                    if (changed || !webReady) RestartWeb();
                }
        }

        void Reload()
        {
            if (webReady) web.CoreWebView2.Reload(); else Connect();
        }

        void About()
        {
            string wv = "—";
            try { wv = CoreWebView2Environment.GetAvailableBrowserVersionString(); } catch { }
            MessageBox.Show(this, Lang.T("cl.about_t", AppInfo.Version, cfg != null && cfg.IsSet ? cfg.BaseUrl : "—", wv), Lang.T("cl.about"), MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        void InstallWebView2()
        {
            overlay.ShowMessage(Status.Busy, Lang.T("cl.installing"), "", Overlay.Buttons.None);
            Task.Run(() => ZenithDesk.Setup.Prereqs.InstallFromMicrosoft("Microsoft Edge WebView2 Runtime", AppInfo.WebView2BootstrapperUrl,
                                                                         "MicrosoftEdgeWebview2Setup.exe", "/silent /install", ZenithDesk.Setup.Prereqs.OfflineWebView2(),
                                                                         (p, d) => { }, CancellationToken.None))
                .ContinueWith(t => BeginInvoke((Action)(() => {
                    if (t.Exception != null) overlay.ShowMessage(Status.Fail, Lang.T("cl.nowv"), t.Exception.InnerException.Message, Overlay.Buttons.Install | Overlay.Buttons.Exit);
                    else { if (web != null) { Controls.Remove(web); web.Dispose(); web = null; } Connect(); }
                })));
        }

        static void OpenExternal(string uri)
        {
            try { if (uri.StartsWith("http:", StringComparison.OrdinalIgnoreCase) || uri.StartsWith("https:", StringComparison.OrdinalIgnoreCase) || uri.StartsWith("mailto:") || uri.StartsWith("tel:")) Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); }
            catch (Exception e) { Log.Error("open " + uri, e); }
        }

        void ExitApp(bool ask)
        {
            if (ask && MessageBox.Show(this, Lang.T("cl.exit_q"), AppInfo.Product, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            reallyExit = true; Close();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!reallyExit && e.CloseReason == CloseReason.UserClosing && !AppInfo.IsTest)
            {   // the X keeps Zenith Desk in the tray so calls still ring
                e.Cancel = true; SavePlacement(); Hide();
                if (!trayHintShown) { trayHintShown = true; tray.ShowBalloonTip(5000, AppInfo.Product, Lang.T("cl.tray_hint"), ToolTipIcon.Info); }
                return;
            }
            SavePlacement();
            tray.Visible = false;
            base.OnFormClosing(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { tray.Dispose(); retryTimer.Dispose(); if (web != null) web.Dispose(); }
            base.Dispose(disposing);
        }

        // remembers size and position (one file per Windows user)
        static string PlacementFile { get { return Path.Combine(AppInfo.UserDataDir, "window.json"); } }
        void RestorePlacement()
        {
            var area = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
            var r = new Rectangle(area.X + area.Width / 12, area.Y + area.Height / 14, area.Width * 5 / 6, area.Height * 6 / 7);
            bool max = true;
            try
            {
                if (File.Exists(PlacementFile))
                {
                    var d = Json.Read(File.ReadAllText(PlacementFile));
                    var saved = new Rectangle(Json.Int(d, "x"), Json.Int(d, "y"), Json.Int(d, "w", r.Width), Json.Int(d, "h", r.Height));
                    foreach (var s in System.Windows.Forms.Screen.AllScreens)
                        if (s.WorkingArea.IntersectsWith(saved) && saved.Width >= 600 && saved.Height >= 400) { r = saved; break; }
                    max = Json.Bool(d, "max", true);
                }
            }
            catch { }
            Bounds = r;
            if (max) WindowState = FormWindowState.Maximized;
        }
        void SavePlacement()
        {
            try
            {
                var r = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
                Directory.CreateDirectory(AppInfo.UserDataDir);
                File.WriteAllText(PlacementFile, Json.Write(new Dictionary<string, object> { {"x", r.X}, {"y", r.Y}, {"w", r.Width}, {"h", r.Height}, {"max", WindowState == FormWindowState.Maximized} }));
            }
            catch { }
        }

        // ---- Windows: extra items in the window's system menu, taskbar flashing
        const int WM_SYSCOMMAND = 0x112, MF_STRING = 0, MF_SEPARATOR = 0x800, ID_SETTINGS = 0x7101, ID_ABOUT = 0x7102;
        [DllImport("user32.dll")] static extern IntPtr GetSystemMenu(IntPtr hWnd, bool revert);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool AppendMenu(IntPtr menu, int flags, int id, string text);
        [StructLayout(LayoutKind.Sequential)] struct FLASHWINFO { public uint cbSize; public IntPtr hwnd; public uint dwFlags, uCount, dwTimeout; }
        [DllImport("user32.dll")] static extern bool FlashWindowEx(ref FLASHWINFO pwfi);

        void AddSystemMenu()
        {
            if (!AppInfo.IsWindows) return;
            try
            {
                var m = GetSystemMenu(Handle, false);
                AppendMenu(m, MF_SEPARATOR, 0, null);
                AppendMenu(m, MF_STRING, ID_SETTINGS, Lang.T("cl.settings"));
                AppendMenu(m, MF_STRING, ID_ABOUT, Lang.T("cl.about"));
            }
            catch (Exception e) { Log.Error("system menu", e); }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_SYSCOMMAND && (int)m.WParam == ID_SETTINGS) { OpenSettings(); return; }
            if (m.Msg == WM_SYSCOMMAND && (int)m.WParam == ID_ABOUT) { About(); return; }
            base.WndProc(ref m);
        }

        void Flash()
        {
            if (!AppInfo.IsWindows) return;
            try { var f = new FLASHWINFO { hwnd = Handle, dwFlags = 3 | 0xC, uCount = 0, dwTimeout = 0 }; f.cbSize = (uint)Marshal.SizeOf(f); FlashWindowEx(ref f); } catch { }
        }
    }

    /// <summary>The navy start / error screen in front of the workplace: logo, what is happening, what to do.</summary>
    public class Overlay : Panel
    {
        [Flags] public enum Buttons { None = 0, Retry = 1, Settings = 2, Exit = 4, Install = 8 }
        public event EventHandler RetryClicked, SettingsClicked, ExitClicked, InstallClicked;
        readonly StatusMark mark = new StatusMark { Width = 26, Height = 26 };
        readonly Label title = new Label(), detail = new Label(), countdown = new Label();
        public readonly Button Retry = new Button(), Settings = new Button(), Exit = new Button(), Install = new Button();
        public string TitleText { get { return title.Text; } }
        public string DetailText { get { return detail.Text; } }

        public Overlay()
        {
            BackColor = Ui.Navy; DoubleBuffered = true;
            title.ForeColor = Color.White; title.Font = new Font(Ui.Big.FontFamily, 14f, FontStyle.Bold); title.TextAlign = ContentAlignment.MiddleCenter; title.Name = "overlay_title";
            detail.ForeColor = Color.FromArgb(200, 255, 255, 255); detail.TextAlign = ContentAlignment.TopCenter; detail.Name = "overlay_detail";
            countdown.ForeColor = Color.FromArgb(150, 255, 255, 255); countdown.TextAlign = ContentAlignment.MiddleCenter; countdown.Font = Ui.Small;
            foreach (var l in new[] { title, detail, countdown }) l.BackColor = Color.Transparent;
            Retry.Text = Lang.T("cl.retry"); Settings.Text = Lang.T("cl.settings"); Exit.Text = Lang.T("cl.exit"); Install.Text = Lang.T("cl.install");
            foreach (var b in new[] { Install, Retry, Settings, Exit })
            {
                b.FlatStyle = FlatStyle.Flat; b.ForeColor = Color.White; b.BackColor = Color.FromArgb(0x2A, 0x38, 0x4E);
                b.FlatAppearance.BorderColor = Color.FromArgb(0x44, 0x55, 0x6E); b.Height = 32; b.Width = 170; b.Visible = false;
            }
            Retry.BackColor = Install.BackColor = Ui.Green; Retry.ForeColor = Install.ForeColor = Color.FromArgb(0x0A, 0x0C, 0x10);
            Retry.Click += (s, e) => { if (RetryClicked != null) RetryClicked(this, e); };
            Settings.Click += (s, e) => { if (SettingsClicked != null) SettingsClicked(this, e); };
            Exit.Click += (s, e) => { if (ExitClicked != null) ExitClicked(this, e); };
            Install.Click += (s, e) => { if (InstallClicked != null) InstallClicked(this, e); };
            Controls.AddRange(new Control[] { mark, title, detail, countdown, Install, Retry, Settings, Exit });
            Resize += (s, e) => DoLayout();
        }

        public void ShowMessage(Status st, string t, string d, Buttons buttons)
        {
            mark.Status = st; mark.Visible = st != Status.Pending;
            title.Text = t; detail.Text = d; countdown.Text = "";
            Install.Visible = (buttons & Buttons.Install) != 0; Retry.Visible = (buttons & Buttons.Retry) != 0;
            Settings.Visible = (buttons & Buttons.Settings) != 0; Exit.Visible = (buttons & Buttons.Exit) != 0;
            Visible = true; BringToFront(); DoLayout(); Invalidate();
        }

        public void SetCountdown(string text) { countdown.Text = text; }

        void DoLayout()
        {
            int cx = Width / 2, top = Math.Max(150, Height / 2 - 40);
            mark.Location = new Point(cx - 13, top - 4);
            title.SetBounds(cx - 330, top + 32, 660, 34);
            detail.SetBounds(cx - 330, top + 70, 660, 66);
            var shown = new List<Button>();
            foreach (var b in new[] { Install, Retry, Settings, Exit }) if (b.Visible) shown.Add(b);
            int w = shown.Count * 170 + Math.Max(0, shown.Count - 1) * 10, x = cx - w / 2;
            foreach (var b in shown) { b.Location = new Point(x, top + 146); x += 180; }
            countdown.SetBounds(cx - 200, top + 188, 400, 20);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            using (var b = new LinearGradientBrush(ClientRectangle.Width > 0 ? ClientRectangle : new Rectangle(0, 0, 1, 1), Ui.Navy, Ui.NavyDark, 90f)) g.FillRectangle(b, ClientRectangle);
            int top = Math.Max(150, Height / 2 - 40);
            if (Ui.Logo != null) g.DrawImage(Ui.Logo, new Rectangle(Width / 2 - 48, top - 130, 96, 96));
            using (var f = new Font(Ui.Body.FontFamily, 8.5f))
            using (var br = new SolidBrush(Color.FromArgb(110, 255, 255, 255)))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center })
                g.DrawString(AppInfo.Product + " " + AppInfo.ShortVersion, f, br, new RectangleF(0, Height - 34, Width, 20), sf);
        }
    }
}
