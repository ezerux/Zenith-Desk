// Zenith Desk for Windows — common constants and well-known places.
// Built for .NET Framework 4.8 (part of Windows 10 1903+ and Windows 11), so nothing extra is needed to run the setup.
using System;
using System.IO;
using Microsoft.Win32;

namespace ZenithDesk
{
    public static class AppInfo
    {
        public const string Product = "Zenith Desk";
        public const string Version = "3.10.0";
        public const string ShortVersion = "3.10";
        public const string Publisher = "Zenith Desk";
        public const string ClientExe = "ZenithDesk.exe";
        public const string UninstallExe = "uninstall.exe";
        public const string UninstallKeyName = "ZenithDesk";
        public const string RunValueName = "ZenithDesk";
        public const string WebView2ClientId = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";
        public const string WebView2BootstrapperUrl = "https://go.microsoft.com/fwlink/p/?LinkId=2124703";
        public const string NetFx48Url = "https://go.microsoft.com/fwlink/?linkid=2088631";
        public const int DefaultPort = 8000;

        /// <summary>Tests (and only tests) redirect every system place into one folder: ZD_TEST_ROOT.</summary>
        public static string TestRoot { get { return Environment.GetEnvironmentVariable("ZD_TEST_ROOT") ?? ""; } }
        public static bool IsTest { get { return TestRoot.Length > 0; } }
        public static bool IsWindows { get { return Environment.OSVersion.Platform == PlatformID.Win32NT; } }

        static string Place(string test, Environment.SpecialFolder folder)
        {
            if (IsTest) { var p = Path.Combine(TestRoot, test); Directory.CreateDirectory(p); return p; }
            return Environment.GetFolderPath(folder);
        }

        public static string ProgramFiles { get { return Place("Program Files", Environment.SpecialFolder.ProgramFiles); } }
        public static string ProgramData { get { return Place("ProgramData", Environment.SpecialFolder.CommonApplicationData); } }
        public static string CommonDesktop { get { return Place("Users/Public/Desktop", Environment.SpecialFolder.CommonDesktopDirectory); } }
        public static string CommonPrograms { get { return Place("ProgramData/Microsoft/Windows/Start Menu/Programs", Environment.SpecialFolder.CommonPrograms); } }
        public static string UserAppData { get { return Place("Users/me/AppData/Roaming", Environment.SpecialFolder.ApplicationData); } }
        public static string UserLocalAppData { get { return Place("Users/me/AppData/Local", Environment.SpecialFolder.LocalApplicationData); } }

        public static string DefaultInstallDir { get { return Path.Combine(ProgramFiles, Product); } }
        public static string MachineDataDir { get { return Path.Combine(ProgramData, Product); } }
        public static string UserDataDir { get { return Path.Combine(UserAppData, Product); } }
        public static string WebViewDataDir { get { return Path.Combine(UserLocalAppData, Product, "WebView2"); } }
        public static string StartMenuDir { get { return Path.Combine(CommonPrograms, Product); } }

        /// <summary>HKLM (in tests: a private branch of HKCU, so nothing on the machine is touched).</summary>
        public static RegistryKey MachineRoot(bool writable)
        {
            if (IsTest) return Registry.CurrentUser.CreateSubKey(@"Software\ZenithDeskTest\" + Path.GetFileName(TestRoot.TrimEnd('/', '\\')) + @"\HKLM");
            if (Environment.Is64BitOperatingSystem)
                return RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            return Registry.LocalMachine;
        }

        public static RegistryKey UserRoot()
        {
            if (IsTest) return Registry.CurrentUser.CreateSubKey(@"Software\ZenithDeskTest\" + Path.GetFileName(TestRoot.TrimEnd('/', '\\')) + @"\HKCU");
            return Registry.CurrentUser;
        }

        public const string UninstallKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\" + UninstallKeyName;
        public const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";

        public static string FormatSize(long bytes)
        {
            if (bytes >= 1L << 30) return (bytes / (double)(1L << 30)).ToString("0.0") + (Lang.IsRu ? " ГБ" : " GB");
            if (bytes >= 1L << 20) return (bytes / (double)(1L << 20)).ToString("0.0") + (Lang.IsRu ? " МБ" : " MB");
            return Math.Max(1, bytes / 1024) + (Lang.IsRu ? " КБ" : " KB");
        }
    }
}
