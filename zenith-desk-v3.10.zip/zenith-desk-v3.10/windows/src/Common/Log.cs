using System;
using System.IO;
using System.Text;

namespace ZenithDesk
{
    /// <summary>Plain text log (setup: %TEMP%\ZenithDesk-Setup.log, client: %LOCALAPPDATA%\Zenith Desk\client.log).</summary>
    public static class Log
    {
        static readonly object Gate = new object();
        public static string FilePath = Path.Combine(Path.GetTempPath(), "ZenithDesk.log");

        public static void Write(string text)
        {
            lock (Gate)
            {
                try
                {
                    var dir = Path.GetDirectoryName(FilePath);
                    if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                    File.AppendAllText(FilePath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "  " + text + Environment.NewLine, Encoding.UTF8);
                }
                catch { /* logging must never break the program */ }
            }
        }

        public static void Error(string what, Exception e) { Write("ERROR " + what + ": " + e); }
    }
}
