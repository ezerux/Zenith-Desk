using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Reflection;
using System.Windows.Forms;

namespace ZenithDesk
{
    /// <summary>Colours, fonts and images of the Zenith Desk brand for the Windows programs.</summary>
    public static class Ui
    {
        public static readonly Color Navy = Color.FromArgb(0x1F, 0x2A, 0x3B);
        public static readonly Color NavyDark = Color.FromArgb(0x14, 0x1C, 0x29);
        public static readonly Color Green = Color.FromArgb(0x10, 0xB9, 0x81);
        public static readonly Color Red = Color.FromArgb(0xDC, 0x26, 0x26);
        public static readonly Color Amber = Color.FromArgb(0xD9, 0x77, 0x06);
        public static readonly Color Blue = Color.FromArgb(0x25, 0x63, 0xEB);
        public static readonly Color Ink = Color.FromArgb(0x11, 0x18, 0x27);
        public static readonly Color Muted = Color.FromArgb(0x4B, 0x55, 0x63);
        public static readonly Color Line = Color.FromArgb(0xD9, 0xDE, 0xE5);
        public static readonly Color Soft = Color.FromArgb(0xF4, 0xF6, 0xF8);

        static string Face { get { return AppInfo.IsWindows ? "Segoe UI" : "Inter"; } }
        public static Font Body = new Font(Face, 9f);
        public static Font Bold = new Font(Face, 9f, FontStyle.Bold);
        public static Font Title = new Font(Face, 9.5f, FontStyle.Bold);
        public static Font Big = new Font(Face, 13f, FontStyle.Bold);
        public static Font Small = new Font(Face, 8.25f);

        public static Stream Resource(string name)
        {
            return Assembly.GetExecutingAssembly().GetManifestResourceStream(name);
        }

        static Image logo;
        public static Image Logo
        {
            get
            {
                if (logo == null) { var s = Resource("logo.png"); if (s != null) logo = Image.FromStream(s); }
                return logo;
            }
        }

        static Icon icon;
        public static Icon AppIcon
        {
            get
            {
                if (icon == null) { var s = Resource("app.ico"); if (s != null) icon = new Icon(s); }
                return icon;
            }
        }

        public static void Prepare()
        {
            // modern TLS for the HTTPS test and downloads of Microsoft components
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12 | (SecurityProtocolType)12288; }
            catch { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
        }

        public static GraphicsPath Round(Rectangle r, int radius)
        {
            var p = new GraphicsPath(); int d = radius * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure(); return p;
        }

        public static Label Text(string text, int x, int y, int w, int h, Font font = null, Color? color = null)
        {
            return new Label { Text = text, Left = x, Top = y, Width = w, Height = h, Font = font ?? Body, ForeColor = color ?? Ink, BackColor = Color.Transparent };
        }
    }

    public enum Status { Pending, Ok, Warn, Fail, Busy }

    /// <summary>A round status mark: ✓ green, ! amber, ✕ red, grey while waiting, blue ring while working.</summary>
    public class StatusMark : Control
    {
        Status st = Status.Pending;
        int spin;
        readonly Timer timer = new Timer { Interval = 80 };
        public StatusMark()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; Width = 18; Height = 18;
            timer.Tick += (s, e) => { spin = (spin + 30) % 360; Invalidate(); };
        }
        public Status Status { get { return st; } set { st = value; timer.Enabled = value == Status.Busy; Invalidate(); } }
        protected override void Dispose(bool disposing) { if (disposing) timer.Dispose(); base.Dispose(disposing); }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new Rectangle(1, 1, Width - 3, Height - 3);
            if (st == Status.Busy)
            {
                using (var p = new Pen(Ui.Line, 2.4f)) g.DrawEllipse(p, r);
                using (var p = new Pen(Ui.Blue, 2.4f)) g.DrawArc(p, r, spin, 100);
                return;
            }
            var c = st == Status.Ok ? Ui.Green : st == Status.Warn ? Ui.Amber : st == Status.Fail ? Ui.Red : Ui.Line;
            using (var b = new SolidBrush(c)) g.FillEllipse(b, r);
            using (var p = new Pen(Color.White, 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                float w = r.Width, x = r.X, y = r.Y;
                if (st == Status.Ok) g.DrawLines(p, new[] { new PointF(x + w * .27f, y + w * .52f), new PointF(x + w * .44f, y + w * .68f), new PointF(x + w * .74f, y + w * .34f) });
                else if (st == Status.Fail) { g.DrawLine(p, x + w * .32f, y + w * .32f, x + w * .68f, y + w * .68f); g.DrawLine(p, x + w * .68f, y + w * .32f, x + w * .32f, y + w * .68f); }
                else if (st == Status.Warn) { g.DrawLine(p, x + w / 2, y + w * .25f, x + w / 2, y + w * .56f); g.FillEllipse(Brushes.White, x + w / 2 - 1.3f, y + w * .68f, 2.6f, 2.6f); }
            }
        }
    }
}
