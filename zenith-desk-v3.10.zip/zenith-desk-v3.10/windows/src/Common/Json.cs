using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace ZenithDesk
{
    /// <summary>Tiny JSON helpers on top of the JavaScriptSerializer that ships with .NET Framework.</summary>
    public static class Json
    {
        static JavaScriptSerializer S() { return new JavaScriptSerializer { MaxJsonLength = 4 * 1024 * 1024 }; }
        public static string Write(object o) { return S().Serialize(o); }
        public static Dictionary<string, object> Read(string text)
        {
            var o = S().DeserializeObject(text) as Dictionary<string, object>;
            return o ?? new Dictionary<string, object>();
        }
        public static string Str(Dictionary<string, object> d, string k, string def = "")
        {
            object v; return d != null && d.TryGetValue(k, out v) && v != null ? v.ToString() : def;
        }
        public static bool Bool(Dictionary<string, object> d, string k, bool def = false)
        {
            object v; if (d == null || !d.TryGetValue(k, out v) || v == null) return def;
            if (v is bool) return (bool)v;
            bool b; return bool.TryParse(v.ToString(), out b) ? b : def;
        }
        public static int Int(Dictionary<string, object> d, string k, int def = 0)
        {
            object v; if (d == null || !d.TryGetValue(k, out v) || v == null) return def;
            int i; return int.TryParse(v.ToString(), out i) ? i : def;
        }
    }
}
