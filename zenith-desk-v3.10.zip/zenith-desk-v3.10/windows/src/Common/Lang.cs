using System.Collections.Generic;
using System.Globalization;

namespace ZenithDesk
{
    /// <summary>Texts of the setup and the desktop client: Russian and English (same languages as the web interface).</summary>
    public static class Lang
    {
        public static string Code = Default();
        public static bool IsRu { get { return Code == "ru"; } }

        public static string Default()
        {
            var two = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
            return two == "en" ? "en" : "ru";  // RU for Russian, Armenian, Kazakh, Ukrainian … users; EN only for English Windows
        }

        public static string T(string key, params object[] args)
        {
            string[] v;
            var s = D.TryGetValue(key, out v) ? (IsRu ? v[0] : v[1]) : key;
            return args.Length > 0 ? string.Format(s, args) : s;
        }

        public static IEnumerable<string> Keys { get { return D.Keys; } }
        public static string[] Raw(string key) { return D[key]; }

        static readonly Dictionary<string, string[]> D = new Dictionary<string, string[]>
        {
            // ---------------------------------------------------------------- common buttons
            {"btn.back", new[]{"< Назад", "< Back"}},
            {"btn.next", new[]{"Далее >", "Next >"}},
            {"btn.cancel", new[]{"Отмена", "Cancel"}},
            {"btn.install", new[]{"Установить", "Install"}},
            {"btn.finish", new[]{"Готово", "Finish"}},
            {"btn.ok", new[]{"OK", "OK"}},
            {"btn.change", new[]{"Изменить...", "Change..."}},
            {"btn.retry", new[]{"Повторить", "Retry"}},
            {"btn.close", new[]{"Закрыть", "Close"}},
            {"btn.remove", new[]{"Удалить", "Remove"}},
            {"btn.save", new[]{"Сохранить", "Save"}},
            {"yes", new[]{"Да", "Yes"}},
            {"no", new[]{"Нет", "No"}},

            // ---------------------------------------------------------------- setup: language
            {"lang.title", new[]{"Язык установки", "Setup Language"}},
            {"lang.prompt", new[]{"Выберите язык, который будет использоваться во время установки:", "Select the language to use during the installation:"}},

            // ---------------------------------------------------------------- setup: frame
            {"setup.title", new[]{"Установка Zenith Desk {0}", "Zenith Desk {0} Setup"}},
            {"cancel.confirm", new[]{"Прервать установку Zenith Desk?", "Cancel the Zenith Desk installation?"}},
            {"err.admin", new[]{"Для установки нужны права администратора. Запустите файл установки от имени администратора.", "Administrator rights are required. Run the setup file as administrator."}},
            {"err.other_setup", new[]{"Установка Zenith Desk уже запущена.", "Zenith Desk Setup is already running."}},

            // ---------------------------------------------------------------- welcome
            {"welcome.head", new[]{"Вас приветствует программа установки Zenith Desk", "Welcome to the Zenith Desk Setup"}},
            {"welcome.text", new[]{
                "Программа установит Zenith Desk {0} — рабочее место оператора (тикеты, телефон, сообщения) — на этот компьютер.\n\nВо время установки понадобится адрес сервера Zenith Desk: IP-адрес и порт. Их сообщает администратор.\n\nДля продолжения нажмите «Далее».",
                "This will install Zenith Desk {0} — the operator workplace (tickets, phone, messages) — on this computer.\n\nDuring the installation you will need the address of the Zenith Desk server: its IP address and port. Your administrator will give them to you.\n\nClick Next to continue."}},
            {"welcome.upgrade", new[]{
                "На компьютере уже установлен Zenith Desk {0}. Программа обновит его до версии {1}. Настройки подключения к серверу сохранятся.\n\nДля продолжения нажмите «Далее».",
                "Zenith Desk {0} is already installed on this computer. Setup will update it to version {1}. The server connection settings are kept.\n\nClick Next to continue."}},
            {"welcome.warn", new[]{
                "ПРЕДУПРЕЖДЕНИЕ: Данная программа защищена законами об авторских правах и международными соглашениями.",
                "WARNING: This program is protected by copyright law and international treaties."}},

            // ---------------------------------------------------------------- maintenance (already installed, same version)
            {"maint.title", new[]{"Zenith Desk уже установлен", "Zenith Desk is already installed"}},
            {"maint.sub", new[]{"Выберите, что нужно сделать.", "Choose what you want to do."}},
            {"maint.repair", new[]{"Восстановить", "Repair"}},
            {"maint.repair_d", new[]{"Заново установить файлы программы и ярлыки. Можно изменить адрес сервера.", "Install the program files and shortcuts again. The server address can be changed."}},
            {"maint.remove", new[]{"Удалить", "Remove"}},
            {"maint.remove_d", new[]{"Удалить Zenith Desk с этого компьютера.", "Remove Zenith Desk from this computer."}},

            // ---------------------------------------------------------------- license
            {"license.title", new[]{"Лицензионное соглашение", "License Agreement"}},
            {"license.sub", new[]{"Прочитайте условия использования программы.", "Please read the terms of use."}},
            {"license.accept", new[]{"Я принимаю условия соглашения", "I accept the terms of the agreement"}},
            {"license.decline", new[]{"Я не принимаю условия соглашения", "I do not accept the terms of the agreement"}},
            {"license.text", new[]{
                "ЛИЦЕНЗИОННОЕ СОГЛАШЕНИЕ — ZENITH DESK (КЛИЕНТ ДЛЯ WINDOWS)\n\n1. Программа предназначена для работы сотрудников организации с сервером Zenith Desk этой организации.\n\n2. Программу разрешается устанавливать на любое количество компьютеров организации. Запрещается изменять, декомпилировать и распространять программу за пределами организации без согласия правообладателя.\n\n3. Программа сохраняет на компьютере только адрес сервера, размер окна и данные входа текущего пользователя Windows. Вся рабочая информация (тикеты, звонки, сообщения) хранится на сервере организации.\n\n4. Для показа рабочего места используется компонент Microsoft Edge WebView2 Runtime, который распространяется корпорацией Microsoft на условиях её собственной лицензии. Компонент Microsoft .NET Framework 4.8 является частью Windows.\n\n5. Программа предоставляется «как есть». Правообладатель не несёт ответственности за убытки, связанные с использованием программы, в пределах, допускаемых законом.\n\nНажимая «Я принимаю условия соглашения», вы соглашаетесь с этими условиями.",
                "LICENSE AGREEMENT — ZENITH DESK (WINDOWS CLIENT)\n\n1. The program is intended for the employees of an organization to work with that organization's Zenith Desk server.\n\n2. The program may be installed on any number of the organization's computers. It must not be modified, decompiled or distributed outside the organization without the consent of the right holder.\n\n3. The program keeps on the computer only the server address, the window size and the sign-in data of the current Windows user. All work information (tickets, calls, messages) is stored on the organization's server.\n\n4. To show the workplace the program uses Microsoft Edge WebView2 Runtime, distributed by Microsoft under its own license. Microsoft .NET Framework 4.8 is part of Windows.\n\n5. The program is provided \"as is\". To the extent permitted by law the right holder is not liable for any damage related to the use of the program.\n\nBy choosing \"I accept the terms of the agreement\" you agree to these terms."}},

            // ---------------------------------------------------------------- components
            {"comp.title", new[]{"Выборочная установка", "Custom Setup"}},
            {"comp.sub", new[]{"Выберите компоненты программы, которые необходимо установить.", "Select the program features you want to install."}},
            {"comp.app", new[]{"Zenith Desk", "Zenith Desk"}},
            {"comp.app_d", new[]{"Основная программа: окно рабочего места оператора, вход по логину и паролю, телефон, тикеты и сообщения. Устанавливается обязательно.", "The main program: the operator workplace window, sign-in with login and password, phone, tickets and messages. Always installed."}},
            {"comp.desktop", new[]{"Ярлык на рабочем столе", "Desktop shortcut"}},
            {"comp.desktop_d", new[]{"Ярлык «Zenith Desk» на рабочем столе для всех пользователей этого компьютера.", "A \"Zenith Desk\" shortcut on the desktop for every user of this computer."}},
            {"comp.start", new[]{"Ярлыки в меню «Пуск»", "Start menu shortcuts"}},
            {"comp.start_d", new[]{"Папка «Zenith Desk» в меню «Пуск»: запуск программы и настройки сервера.", "A \"Zenith Desk\" folder in the Start menu: the program and the server settings."}},
            {"comp.autorun", new[]{"Запускать при входе в Windows", "Start when Windows starts"}},
            {"comp.autorun_d", new[]{"Программа откроется сама после включения компьютера, и оператор сразу начнёт получать звонки.", "The program opens by itself after the computer starts, so the operator receives calls right away."}},
            {"comp.desc", new[]{"Описание компонента", "Feature description"}},
            {"comp.folder", new[]{"Папка:", "Folder:"}},
            {"comp.space", new[]{"Требуется на диске: {0}. Доступно: {1}.", "Required disk space: {0}. Available: {1}."}},
            {"comp.pick", new[]{"Выберите папку для установки Zenith Desk", "Choose the folder to install Zenith Desk to"}},

            // ---------------------------------------------------------------- prerequisites
            {"prereq.title", new[]{"Проверка системы", "System Check"}},
            {"prereq.sub", new[]{"Проверяется, есть ли на компьютере всё необходимое для работы Zenith Desk.", "Checking that this computer has everything Zenith Desk needs."}},
            {"prereq.os", new[]{"Windows 10 / Windows 11", "Windows 10 / Windows 11"}},
            {"prereq.os_bad", new[]{"Нужна Windows 10 или Windows 11 (сейчас: {0})", "Windows 10 or Windows 11 is required (this is: {0})"}},
            {"prereq.net", new[]{"Microsoft .NET Framework 4.8", "Microsoft .NET Framework 4.8"}},
            {"prereq.net_ok", new[]{"Установлен ({0})", "Installed ({0})"}},
            {"prereq.net_missing", new[]{"Не установлен — будет загружен с сайта Microsoft и установлен (может потребоваться перезагрузка)", "Not installed — will be downloaded from Microsoft and installed (a restart may be needed)"}},
            {"prereq.wv", new[]{"Microsoft Edge WebView2 Runtime", "Microsoft Edge WebView2 Runtime"}},
            {"prereq.wv_ok", new[]{"Установлен (версия {0})", "Installed (version {0})"}},
            {"prereq.wv_missing", new[]{"Не установлен — будет загружен с сайта Microsoft и установлен", "Not installed — will be downloaded from Microsoft and installed"}},
            {"prereq.wv_offline", new[]{"Не установлен — будет установлен из файла {0}", "Not installed — will be installed from the file {0}"}},
            {"prereq.disk", new[]{"Свободное место на диске", "Free disk space"}},
            {"prereq.disk_ok", new[]{"{0} свободно", "{0} free"}},
            {"prereq.disk_bad", new[]{"Недостаточно места: нужно {0}, свободно {1}", "Not enough space: {0} needed, {1} free"}},
            {"prereq.admin", new[]{"Права администратора", "Administrator rights"}},
            {"prereq.admin_ok", new[]{"Есть", "Yes"}},
            {"prereq.admin_bad", new[]{"Нет — запустите установку от имени администратора", "No — run the setup as administrator"}},
            {"prereq.recheck", new[]{"Проверить снова", "Check again"}},
            {"prereq.note", new[]{
                "Компоненты Microsoft загружаются только с официального сайта Microsoft. Если на компьютере нет Интернета, положите установщик WebView2 (MicrosoftEdgeWebview2Setup.exe или MicrosoftEdgeWebView2RuntimeInstallerX64.exe) в папку с файлом установки.",
                "Microsoft components are downloaded only from the official Microsoft site. If this computer has no Internet, put the WebView2 installer (MicrosoftEdgeWebview2Setup.exe or MicrosoftEdgeWebView2RuntimeInstallerX64.exe) next to the setup file."}},
            {"prereq.blocked", new[]{"Установку нельзя продолжить: {0}", "Setup cannot continue: {0}"}},

            // ---------------------------------------------------------------- server
            {"server.title", new[]{"Подключение к серверу", "Server Connection"}},
            {"server.sub", new[]{"Укажите адрес сервера Zenith Desk и проверьте подключение.", "Enter the address of the Zenith Desk server and test the connection."}},
            {"server.host", new[]{"Адрес сервера (IP-адрес или имя):", "Server address (IP address or name):"}},
            {"server.port", new[]{"Порт:", "Port:"}},
            {"server.https", new[]{"Защищённое соединение (HTTPS)", "Secure connection (HTTPS)"}},
            {"server.test", new[]{"Проверить подключение", "Test connection"}},
            {"server.testing", new[]{"Проверка подключения…", "Testing the connection…"}},
            {"server.hint", new[]{"Например: 192.168.1.10, порт 8000. Адрес и порт сообщает администратор.", "For example: 192.168.1.10, port 8000. Your administrator gives you the address and port."}},
            {"server.must", new[]{"Чтобы продолжить, нажмите «Проверить подключение»: программа должна убедиться, что сервер доступен.", "To continue, click \"Test connection\": Setup must make sure the server can be reached."}},
            {"server.trust", new[]{"Доверять сертификату этого сервера", "Trust this server's certificate"}},

            {"test.ok", new[]{"Подключение установлено", "Connected"}},
            {"test.ok_d", new[]{"Сервер Zenith Desk {0} отвечает за {1} мс.\n{2}", "Zenith Desk server {0} answers in {1} ms.\n{2}"}},
            {"test.warn_db", new[]{"Сервер доступен, но у него сейчас нет связи со своей базой данных. Сообщите администратору — установку можно продолжить.", "The server answers, but it has no connection to its database right now. Tell your administrator — the installation can continue."}},
            {"test.invalid", new[]{"Неверный адрес сервера", "Invalid server address"}},
            {"test.invalid_d", new[]{"Укажите IP-адрес (например 192.168.1.10) или имя сервера — без «http://», пробелов и «/».", "Enter an IP address (for example 192.168.1.10) or a server name — without \"http://\", spaces or \"/\"."}},
            {"test.port", new[]{"Неверный порт", "Invalid port"}},
            {"test.port_d", new[]{"Порт — число от 1 до 65535 (например 8000).", "The port is a number from 1 to 65535 (for example 8000)."}},
            {"test.dns", new[]{"Сервер не найден", "Server not found"}},
            {"test.dns_d", new[]{"Имя «{0}» не найдено в сети. Проверьте написание или укажите IP-адрес.", "The name \"{0}\" was not found on the network. Check the spelling or use the IP address."}},
            {"test.refused", new[]{"Сервер отклонил подключение", "Connection refused"}},
            {"test.refused_d", new[]{"Компьютер {0} доступен, но на порту {1} никто не отвечает. Проверьте порт и что сервер Zenith Desk запущен.", "The computer {0} is reachable, but nothing answers on port {1}. Check the port and that the Zenith Desk server is running."}},
            {"test.timeout", new[]{"Нет ответа от сервера", "No answer from the server"}},
            {"test.timeout_d", new[]{"{0}:{1} не ответил за {2} с. Проверьте адрес, подключение к сети, VPN и брандмауэр.", "{0}:{1} did not answer within {2} s. Check the address, the network connection, VPN and firewall."}},
            {"test.tls", new[]{"Ошибка защищённого соединения", "Secure connection failed"}},
            {"test.tls_d", new[]{"На этом порту сервер не работает по HTTPS. Снимите галочку «HTTPS» или укажите порт HTTPS.", "The server does not use HTTPS on this port. Untick \"HTTPS\" or enter the HTTPS port."}},
            {"test.cert", new[]{"Сертификат сервера не подтверждён", "Server certificate is not trusted"}},
            {"test.cert_d", new[]{"Сертификат «{0}» выдан не доверенным центром сертификации (отпечаток {1}). Если это сервер вашей организации, нажмите «Доверять сертификату этого сервера».", "The certificate \"{0}\" is not issued by a trusted authority (thumbprint {1}). If this is your organization's server, click \"Trust this server's certificate\"."}},
            {"test.https_req", new[]{"Сервер требует HTTPS", "The server requires HTTPS"}},
            {"test.https_req_d", new[]{"Включите «Защищённое соединение (HTTPS)» и укажите порт HTTPS (обычно 443).", "Tick \"Secure connection (HTTPS)\" and enter the HTTPS port (usually 443)."}},
            {"test.notzd", new[]{"Это не сервер Zenith Desk", "This is not a Zenith Desk server"}},
            {"test.notzd_d", new[]{"По адресу {0} отвечает другая программа. Проверьте адрес и порт.", "Another program answers at {0}. Check the address and port."}},
            {"test.server_err", new[]{"Ошибка сервера", "Server error"}},
            {"test.server_err_d", new[]{"Сервер ответил: {0}.", "The server answered: {0}."}},
            {"test.net", new[]{"Ошибка сети", "Network error"}},

            // ---------------------------------------------------------------- ready / progress / finish
            {"ready.title", new[]{"Всё готово к установке", "Ready to Install"}},
            {"ready.sub", new[]{"Проверьте параметры и нажмите «Установить».", "Check the settings and click Install."}},
            {"ready.folder", new[]{"Папка установки:", "Destination folder:"}},
            {"ready.server", new[]{"Сервер Zenith Desk:", "Zenith Desk server:"}},
            {"ready.components", new[]{"Компоненты:", "Features:"}},
            {"ready.prereq", new[]{"Будет установлено дополнительно:", "Will also be installed:"}},
            {"ready.none", new[]{"ничего", "nothing"}},
            {"progress.title", new[]{"Установка", "Installing"}},
            {"progress.sub", new[]{"Подождите, идёт установка Zenith Desk.", "Please wait while Zenith Desk is being installed."}},
            {"progress.error", new[]{"Установка не завершена: {0}", "The installation did not finish: {0}"}},
            {"progress.rollback", new[]{"Сделанные изменения отменены.", "The changes made have been undone."}},
            {"step.close", new[]{"Закрытие запущенного Zenith Desk", "Closing the running Zenith Desk"}},
            {"step.download", new[]{"Загрузка: {0}", "Downloading: {0}"}},
            {"step.prereq", new[]{"Установка: {0}", "Installing: {0}"}},
            {"step.files", new[]{"Копирование файлов", "Copying files"}},
            {"step.config", new[]{"Сохранение подключения к серверу", "Saving the server connection"}},
            {"step.shortcuts", new[]{"Создание ярлыков", "Creating shortcuts"}},
            {"step.registry", new[]{"Регистрация в «Установленных приложениях»", "Registering in \"Installed apps\""}},
            {"step.autorun", new[]{"Настройка автозапуска", "Setting up start with Windows"}},
            {"step.done", new[]{"Готово", "Done"}},
            {"finish.head", new[]{"Установка Zenith Desk завершена", "Completing the Zenith Desk Setup"}},
            {"finish.text", new[]{
                "Zenith Desk {0} установлен.\n\nДля запуска используйте ярлык «Zenith Desk» на рабочем столе. Откроется окно входа — введите свой логин и пароль.\n\nСервер: {1}",
                "Zenith Desk {0} has been installed.\n\nStart it with the \"Zenith Desk\" shortcut on the desktop. The sign-in window opens — enter your login and password.\n\nServer: {1}"}},
            {"finish.launch", new[]{"Запустить Zenith Desk", "Launch Zenith Desk"}},
            {"finish.failhead", new[]{"Установка прервана", "Setup was interrupted"}},
            {"finish.reboot", new[]{"Чтобы завершить установку компонентов Microsoft, перезагрузите компьютер.", "Restart the computer to finish installing the Microsoft components."}},

            // ---------------------------------------------------------------- uninstall
            {"uninst.title", new[]{"Удаление Zenith Desk", "Uninstall Zenith Desk"}},
            {"uninst.confirm", new[]{"Удалить Zenith Desk {0} с этого компьютера?", "Remove Zenith Desk {0} from this computer?"}},
            {"uninst.data", new[]{"Удалить также настройки подключения к серверу", "Also remove the server connection settings"}},
            {"uninst.progress", new[]{"Удаление Zenith Desk…", "Removing Zenith Desk…"}},
            {"uninst.done", new[]{"Zenith Desk удалён с этого компьютера.", "Zenith Desk has been removed from this computer."}},
            {"uninst.notfound", new[]{"Zenith Desk не установлен на этом компьютере.", "Zenith Desk is not installed on this computer."}},

            // ---------------------------------------------------------------- shortcuts
            {"sc.app_desc", new[]{"Рабочее место оператора Zenith Desk", "Zenith Desk operator workplace"}},
            {"sc.settings", new[]{"Zenith Desk — подключение к серверу", "Zenith Desk — server connection"}},

            // ---------------------------------------------------------------- desktop client
            {"cl.connecting", new[]{"Подключение к серверу {0}…", "Connecting to the server {0}…"}},
            {"cl.offline", new[]{"Нет связи с сервером Zenith Desk", "No connection to the Zenith Desk server"}},
            {"cl.retry_in", new[]{"Новая попытка через {0} с.", "Trying again in {0} s."}},
            {"cl.retry", new[]{"Повторить", "Retry"}},
            {"cl.settings", new[]{"Настройки сервера…", "Server settings…"}},
            {"cl.exit", new[]{"Выход", "Exit"}},
            {"cl.nowv", new[]{"Не установлен Microsoft Edge WebView2 Runtime", "Microsoft Edge WebView2 Runtime is not installed"}},
            {"cl.nowv_d", new[]{"Этот компонент Windows нужен Zenith Desk, чтобы показать рабочее место. Нажмите «Установить» — он будет загружен с сайта Microsoft.", "Zenith Desk needs this Windows component to show the workplace. Click Install to download it from Microsoft."}},
            {"cl.wv_failed", new[]{"Не удалось открыть окно рабочего места", "The workplace window could not be opened"}},
            {"cl.install", new[]{"Установить", "Install"}},
            {"cl.installing", new[]{"Установка компонента Microsoft…", "Installing the Microsoft component…"}},
            {"cl.noconfig", new[]{"Адрес сервера не указан. Укажите его в настройках.", "The server address is not set. Enter it in the settings."}},
            {"cl.tray_hint", new[]{"Zenith Desk продолжает работать в области уведомлений, чтобы вы не пропустили звонки.", "Zenith Desk keeps running in the notification area so you don't miss calls."}},
            {"cl.tray_open", new[]{"Открыть Zenith Desk", "Open Zenith Desk"}},
            {"cl.exit_q", new[]{"Закрыть Zenith Desk? Вы перестанете получать звонки на этом компьютере.", "Close Zenith Desk? You will stop receiving calls on this computer."}},
            {"cl.call_in", new[]{"Входящий звонок", "Incoming call"}},
            {"cl.unread", new[]{"Новых сообщений: {0}", "Unread messages: {0}"}},
            {"cl.about", new[]{"О программе Zenith Desk", "About Zenith Desk"}},
            {"cl.about_t", new[]{"Zenith Desk для Windows {0}\nСервер: {1}\nКомпонент WebView2: {2}", "Zenith Desk for Windows {0}\nServer: {1}\nWebView2 component: {2}"}},
            {"cl.reload", new[]{"Обновить страницу\tF5", "Reload\tF5"}},
            {"cl.settings_title", new[]{"Zenith Desk — подключение к серверу", "Zenith Desk — server connection"}},
            {"cl.settings_sub", new[]{"Адрес сервера Zenith Desk вашей организации. Изменения применяются для текущего пользователя Windows.", "The address of your organization's Zenith Desk server. Changes apply to the current Windows user."}},
            {"cl.crash", new[]{"Окно рабочего места перезапущено после сбоя.", "The workplace window was restarted after a failure."}},
        };
    }
}
