using System;
using System.Drawing;
using System.Windows.Forms;

namespace ZenithDesk
{
    /// <summary>
    /// Server address + port + HTTPS + "Test connection" with an explained result. Used by the setup wizard and by the
    /// client's "Server settings". <see cref="Passed"/> is true only when the last test succeeded for exactly the values
    /// now in the boxes — changing anything asks for a new test.
    /// </summary>
    public class ServerPanel : UserControl
    {
        public readonly TextBox HostBox = new TextBox();
        public readonly TextBox PortBox = new TextBox();
        public readonly CheckBox HttpsBox = new CheckBox();
        public readonly Button TestButton = new Button();
        public readonly LinkLabel TrustLink = new LinkLabel();
        readonly StatusMark mark = new StatusMark();
        readonly Label resTitle = new Label(), resText = new Label(), hint = new Label();
        readonly Panel resBox = new Panel();
        ServerConfig tested;          // the values of the last successful test
        string trusted = "";          // certificate thumbprint the user chose to trust
        public TestResult LastResult;
        public event EventHandler PassedChanged;
        public bool Passed { get { return tested != null && tested.SameServer(Current) && LastResult != null && LastResult.Ok; } }
        bool busy;

        public ServerPanel()
        {
            Size = new Size(470, 240); BackColor = Color.White; Font = Ui.Body;
            Controls.Add(Ui.Text(Lang.T("server.host"), 0, 2, 300, 18));
            Controls.Add(Ui.Text(Lang.T("server.port"), 316, 2, 80, 18));
            HostBox.SetBounds(0, 22, 300, 24); HostBox.Name = "host";
            PortBox.SetBounds(316, 22, 80, 24); PortBox.Name = "port"; PortBox.MaxLength = 5; PortBox.Text = AppInfo.DefaultPort.ToString();
            HttpsBox.SetBounds(0, 52, 300, 22); HttpsBox.Text = Lang.T("server.https"); HttpsBox.Name = "https";
            hint.SetBounds(0, 76, 470, 18); hint.Text = Lang.T("server.hint"); hint.ForeColor = Ui.Muted; hint.Font = Ui.Small;
            TestButton.SetBounds(0, 100, 210, 28); TestButton.Text = Lang.T("server.test"); TestButton.Name = "test"; TestButton.FlatStyle = FlatStyle.System;
            resBox.SetBounds(0, 138, 470, 100); resBox.BackColor = Ui.Soft; resBox.Paint += (s, e) => { using (var p = new Pen(Ui.Line)) e.Graphics.DrawRectangle(p, 0, 0, resBox.Width - 1, resBox.Height - 1); };
            mark.SetBounds(10, 11, 18, 18);
            resTitle.SetBounds(36, 10, 424, 20); resTitle.Font = Ui.Bold; resTitle.BackColor = Color.Transparent; resTitle.Name = "result_title";
            resText.SetBounds(36, 31, 424, 48); resText.ForeColor = Ui.Muted; resText.BackColor = Color.Transparent; resText.Name = "result_text";
            TrustLink.SetBounds(36, 78, 424, 18); TrustLink.Text = Lang.T("server.trust"); TrustLink.Visible = false; TrustLink.BackColor = Color.Transparent; TrustLink.Name = "trust";
            resBox.Controls.AddRange(new Control[] { mark, resTitle, resText, TrustLink });
            Controls.AddRange(new Control[] { HostBox, PortBox, HttpsBox, hint, TestButton, resBox });
            ShowIdle();

            HostBox.TextChanged += (s, e) => Changed();
            PortBox.TextChanged += (s, e) => Changed();
            PortBox.KeyPress += (s, e) => { if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true; };
            HttpsBox.CheckedChanged += (s, e) => { if (HttpsBox.Checked && PortBox.Text == "80") PortBox.Text = "443"; Changed(); };
            HostBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; RunTest(); } };
            PortBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; RunTest(); } };
            TestButton.Click += (s, e) => RunTest();
            TrustLink.LinkClicked += (s, e) => { if (LastResult != null) { trusted = LastResult.CertThumbprint; RunTest(); } };
        }

        public ServerConfig Current
        {
            get
            {
                int port; int.TryParse(PortBox.Text.Trim(), out port);
                return new ServerConfig { Host = HostBox.Text.Trim(), Port = port, Https = HttpsBox.Checked, CertThumbprint = trusted };
            }
        }

        /// <summary>The checked configuration, ready to save (null until a test passed).</summary>
        public ServerConfig Result
        {
            get
            {
                if (!Passed) return null;
                var c = tested.Clone();
                c.ServerVersion = LastResult.Version; c.TestedAt = DateTime.UtcNow.ToString("o");
                return c;
            }
        }

        public void SetConfig(ServerConfig c)
        {
            if (c == null) return;
            HostBox.Text = c.Host; PortBox.Text = c.Port > 0 ? c.Port.ToString() : AppInfo.DefaultPort.ToString();
            HttpsBox.Checked = c.Https; trusted = c.CertThumbprint ?? "";
        }

        void Changed()
        {
            if (busy) return;
            if (LastResult != null && !(tested != null && tested.SameServer(Current))) { LastResult = null; tested = null; ShowIdle(); }
            if (PassedChanged != null) PassedChanged(this, EventArgs.Empty);
        }

        void ShowIdle()
        {
            mark.Status = Status.Pending; resTitle.Text = Lang.T("server.test"); resText.Text = Lang.T("server.must"); TrustLink.Visible = false;
        }

        public void RunTest()
        {
            if (busy) return;
            string host = HostBox.Text, port = PortBox.Text, err; bool https = HttpsBox.Checked;
            if (ServerConfig.Normalize(ref host, ref port, ref https, out err))
            {   // tidy up a pasted "http://10.0.0.5:8000/" into the three boxes
                busy = true; HostBox.Text = host; PortBox.Text = port; HttpsBox.Checked = https; busy = false;
            }
            var cfg = Current;
            busy = true; TestButton.Enabled = false; HostBox.Enabled = PortBox.Enabled = HttpsBox.Enabled = false;
            mark.Status = Status.Busy; resTitle.Text = Lang.T("server.testing"); resText.Text = cfg.Display; TrustLink.Visible = false;
            Log.Write("test connection " + cfg.Display);
            ConnectionTester.TestAsync(cfg).ContinueWith(t => {
                var r = t.Exception == null ? t.Result : new TestResult { Code = TestCode.Network, Title = Lang.T("test.net"), Detail = t.Exception.InnerException.Message };
                if (IsDisposed) return;
                BeginInvoke((Action)(() => Show(r, cfg)));
            });
        }

        void Show(TestResult r, ServerConfig cfg)
        {
            Log.Write("test result " + r);
            busy = false; TestButton.Enabled = true; HostBox.Enabled = PortBox.Enabled = HttpsBox.Enabled = true;
            LastResult = r;
            tested = r.Ok ? cfg : null;
            if (r.Ok && r.CertThumbprint.Length > 0 && cfg.CertThumbprint.Length > 0) tested.CertThumbprint = cfg.CertThumbprint;
            mark.Status = r.Ok ? (r.Warning ? Status.Warn : Status.Ok) : Status.Fail;
            resTitle.Text = r.Title; resTitle.ForeColor = r.Ok ? Ui.Ink : Ui.Red; resText.Text = r.Detail;
            TrustLink.Visible = r.Code == TestCode.CertUntrusted;
            if (PassedChanged != null) PassedChanged(this, EventArgs.Empty);
        }
    }
}
