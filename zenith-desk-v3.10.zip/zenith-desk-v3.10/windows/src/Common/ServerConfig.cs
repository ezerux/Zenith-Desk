using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ZenithDesk
{
    /// <summary>
    /// Where the Zenith Desk server is. The installer writes it for the whole computer
    /// (%ProgramData%\Zenith Desk\server.json); a user may override it in the client's settings
    /// (%APPDATA%\Zenith Desk\server.json). The newer of the two wins. Survives restarts and updates.
    /// </summary>
    public class ServerConfig
    {
        public string Host = "";
        public int Port = AppInfo.DefaultPort;
        public bool Https;
        public string CertThumbprint = "";   // a self-signed server certificate the user decided to trust
        public string ServerVersion = "";    // what the last successful test saw
        public string TestedAt = "";

        public const string FileName = "server.json";
        public static string MachineFile { get { return Path.Combine(AppInfo.MachineDataDir, FileName); } }
        public static string UserFile { get { return Path.Combine(AppInfo.UserDataDir, FileName); } }

        public bool IsSet { get { return Host.Length > 0 && Port > 0; } }
        public string Scheme { get { return Https ? "https" : "http"; } }
        public string BaseUrl { get { return Scheme + "://" + HostForUrl + (DefaultPortForScheme ? "" : ":" + Port) + "/"; } }
        public string Origin { get { return BaseUrl.TrimEnd('/'); } }
        public string Display { get { return HostForUrl + ":" + Port + (Https ? " (HTTPS)" : ""); } }
        bool DefaultPortForScheme { get { return (Https && Port == 443) || (!Https && Port == 80); } }
        string HostForUrl { get { return Host.Contains(":") && !Host.StartsWith("[") ? "[" + Host + "]" : Host; } }

        public ServerConfig Clone() { return (ServerConfig)MemberwiseClone(); }

        public bool SameServer(ServerConfig o)
        {
            return o != null && string.Equals(Host, o.Host, StringComparison.OrdinalIgnoreCase) && Port == o.Port && Https == o.Https;
        }

        public string ToJson()
        {
            return Json.Write(new Dictionary<string, object> {
                {"host", Host}, {"port", Port}, {"https", Https}, {"cert_thumbprint", CertThumbprint},
                {"server_version", ServerVersion}, {"tested_at", TestedAt}, {"client_version", AppInfo.Version},
            });
        }

        public static ServerConfig FromJson(string text)
        {
            var d = Json.Read(text);
            return new ServerConfig {
                Host = Json.Str(d, "host").Trim(), Port = Json.Int(d, "port", AppInfo.DefaultPort), Https = Json.Bool(d, "https"),
                CertThumbprint = Json.Str(d, "cert_thumbprint"), ServerVersion = Json.Str(d, "server_version"), TestedAt = Json.Str(d, "tested_at"),
            };
        }

        public static ServerConfig LoadFile(string path)
        {
            try { return File.Exists(path) ? FromJson(File.ReadAllText(path, Encoding.UTF8)) : null; }
            catch (Exception e) { Log.Error("read " + path, e); return null; }
        }

        /// <summary>The configuration the client uses: the user's own, otherwise the computer's, otherwise empty.</summary>
        public static ServerConfig Load()
        {
            var u = LoadFile(UserFile);
            var m = LoadFile(MachineFile);
            bool hasU = u != null && u.IsSet, hasM = m != null && m.IsSet;
            if (hasU && hasM)  // the newer decision wins: a later re-install with a new server beats an old personal setting
                return string.CompareOrdinal(u.TestedAt, m.TestedAt) >= 0 ? u : m;
            return hasU ? u : hasM ? m : new ServerConfig();
        }

        public void Save(string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            var tmp = path + ".tmp";
            File.WriteAllText(tmp, ToJson(), new UTF8Encoding(false));
            if (File.Exists(path)) File.Delete(path);
            File.Move(tmp, path);  // never leave a half-written file behind
        }

        /// <summary>
        /// Checks what the user typed. Accepts "192.168.1.10", "pbx.company.local", "[fe80::1]", and forgives a pasted
        /// "http://host:port/" (then splits it into host, port and HTTPS).
        /// </summary>
        public static bool Normalize(ref string host, ref string portText, ref bool https, out string error)
        {
            error = "";
            host = (host ?? "").Trim();
            portText = (portText ?? "").Trim();
            if (host.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) { https = true; host = host.Substring(8); }
            else if (host.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) { https = false; host = host.Substring(7); }
            var slash = host.IndexOf('/');
            if (slash >= 0) host = host.Substring(0, slash);
            if (!host.StartsWith("[") && host.Split(':').Length == 2)  // "host:port"
            {
                var parts = host.Split(':');
                host = parts[0];
                if (parts[1].Length > 0) portText = parts[1];
            }
            else if (host.StartsWith("[") && host.Contains("]:"))
            {
                var i = host.IndexOf("]:", StringComparison.Ordinal);
                portText = host.Substring(i + 2); host = host.Substring(0, i + 1);
            }
            if (host.StartsWith("[") && host.EndsWith("]")) host = host.Substring(1, host.Length - 2);
            if (host.Length == 0 || host.Length > 253 || host.IndexOfAny(new[] { ' ', '\t', '/', '\\', '?', '#', '@', '"', '\'' }) >= 0)
            {
                error = "invalid"; return false;
            }
            if (Uri.CheckHostName(host) == UriHostNameType.Unknown) { error = "invalid"; return false; }
            int port;
            if (!int.TryParse(portText, out port) || port < 1 || port > 65535) { error = "port"; return false; }
            portText = port.ToString();
            return true;
        }
    }
}
