using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ZenithDesk
{
    public enum TestCode { Ok, Invalid, BadPort, DnsFailed, Refused, Timeout, TlsFailed, CertUntrusted, HttpsRequired, NotZenith, ServerError, Network }

    public class TestResult
    {
        public TestCode Code;
        public bool Ok { get { return Code == TestCode.Ok; } }
        public string Title = "";
        public string Detail = "";
        public bool Warning;          // connected, but something on the server needs attention (database down)
        public string Version = "";
        public string Language = "";
        public long Ms;
        public string CertThumbprint = "";
        public string CertSubject = "";
        public override string ToString() { return Code + ": " + Title + " — " + Detail.Replace("\n", " "); }
    }

    /// <summary>
    /// "Test connection": name lookup → TCP connect → HTTP(S) GET /api/desktop/hello. Every failure is explained in words
    /// an operator understands (wrong name, nothing on that port, firewall, HTTPS mismatch, not a Zenith Desk server …).
    /// </summary>
    public static class ConnectionTester
    {
        public static int TimeoutMs = 6000;

        static TestResult Fail(TestCode code, string title, string detail)
        {
            return new TestResult { Code = code, Title = Lang.T(title), Detail = detail };
        }

        public static TestResult Test(ServerConfig cfg)
        {
            var sw = Stopwatch.StartNew();
            string host = cfg.Host, portText = cfg.Port.ToString(), err;
            bool https = cfg.Https;
            if (!ServerConfig.Normalize(ref host, ref portText, ref https, out err))
                return err == "port" ? Fail(TestCode.BadPort, "test.port", Lang.T("test.port_d")) : Fail(TestCode.Invalid, "test.invalid", Lang.T("test.invalid_d"));
            int port = int.Parse(portText);
            var shown = cfg.Display;

            // 1. name → address
            IPAddress[] addrs;
            IPAddress ip;
            if (IPAddress.TryParse(host, out ip)) addrs = new[] { ip };
            else
            {
                try
                {
                    var t = Dns.GetHostAddressesAsync(host);
                    if (!t.Wait(TimeoutMs)) return Fail(TestCode.DnsFailed, "test.dns", Lang.T("test.dns_d", host));
                    addrs = t.Result;
                }
                catch (Exception) { return Fail(TestCode.DnsFailed, "test.dns", Lang.T("test.dns_d", host)); }
                if (addrs.Length == 0) return Fail(TestCode.DnsFailed, "test.dns", Lang.T("test.dns_d", host));
            }

            // 2. TCP: refused (nothing listens) vs. timeout (firewall / wrong network) are different problems
            var target = addrs.FirstOrDefault(a => a.AddressFamily == AddressFamily.InterNetwork) ?? addrs[0];
            using (var tcp = new TcpClient(target.AddressFamily))
            {
                try
                {
                    var c = tcp.ConnectAsync(target, port);
                    if (!c.Wait(TimeoutMs)) return Fail(TestCode.Timeout, "test.timeout", Lang.T("test.timeout_d", host, port, TimeoutMs / 1000));
                }
                catch (AggregateException ae)
                {
                    var se = ae.InnerException as SocketException;
                    if (se != null && se.SocketErrorCode == SocketError.ConnectionRefused)
                        return Fail(TestCode.Refused, "test.refused", Lang.T("test.refused_d", host, port));
                    if (se != null && (se.SocketErrorCode == SocketError.TimedOut || se.SocketErrorCode == SocketError.HostUnreachable || se.SocketErrorCode == SocketError.NetworkUnreachable))
                        return Fail(TestCode.Timeout, "test.timeout", Lang.T("test.timeout_d", host, port, TimeoutMs / 1000));
                    return Fail(TestCode.Network, "test.net", (ae.InnerException ?? ae).Message);
                }
            }

            // 3. the HTTP(S) question: are you Zenith Desk?
            var probe = cfg.Clone(); probe.Host = host; probe.Port = port; probe.Https = https;
            X509Certificate2 seen = null;
            SslPolicyErrors sslErrors = SslPolicyErrors.None;
            var req = (HttpWebRequest)WebRequest.Create(probe.BaseUrl + "api/desktop/hello");
            req.Timeout = TimeoutMs; req.ReadWriteTimeout = TimeoutMs;
            req.AllowAutoRedirect = false;
            req.UserAgent = "ZenithDesk-Windows/" + AppInfo.Version;
            req.Accept = "application/json";
            req.Proxy = null;  // the company server is on the local network: never go through a proxy for it
            if (https)
                req.ServerCertificateValidationCallback = (s, cert, chain, errors) => {
                    seen = cert == null ? null : new X509Certificate2(cert);
                    sslErrors = errors;
                    if (errors == SslPolicyErrors.None) return true;
                    return seen != null && cfg.CertThumbprint.Length > 0 && string.Equals(seen.Thumbprint, cfg.CertThumbprint, StringComparison.OrdinalIgnoreCase);
                };
            int status; string body; string location = "";
            try
            {
                using (var resp = (HttpWebResponse)req.GetResponse()) { status = (int)resp.StatusCode; location = resp.Headers["Location"] ?? ""; body = ReadBody(resp); }
            }
            catch (WebException we)
            {
                var resp = we.Response as HttpWebResponse;
                if (resp != null) { status = (int)resp.StatusCode; location = resp.Headers["Location"] ?? ""; body = ReadBody(resp); resp.Close(); }
                else if (https && seen != null && sslErrors != SslPolicyErrors.None)
                {
                    var r = Fail(TestCode.CertUntrusted, "test.cert", Lang.T("test.cert_d", seen.GetNameInfo(X509NameType.SimpleName, false), seen.Thumbprint));
                    r.CertThumbprint = seen.Thumbprint; r.CertSubject = seen.Subject;
                    return r;
                }
                else if (https && (we.Status == WebExceptionStatus.SecureChannelFailure || we.Status == WebExceptionStatus.TrustFailure ||
                                   we.Status == WebExceptionStatus.ReceiveFailure || we.Status == WebExceptionStatus.SendFailure ||
                                   we.Status == WebExceptionStatus.ConnectionClosed || we.Status == WebExceptionStatus.UnknownError))
                    return Fail(TestCode.TlsFailed, "test.tls", Lang.T("test.tls_d"));
                else if (we.Status == WebExceptionStatus.Timeout)
                    return Fail(TestCode.Timeout, "test.timeout", Lang.T("test.timeout_d", host, port, TimeoutMs / 1000));
                else if (we.Status == WebExceptionStatus.ServerProtocolViolation || we.Status == WebExceptionStatus.ReceiveFailure || we.Status == WebExceptionStatus.ConnectionClosed)
                    return Fail(TestCode.NotZenith, "test.notzd", Lang.T("test.notzd_d", shown));
                else return Fail(TestCode.Network, "test.net", we.Message);
            }
            catch (Exception e) { return Fail(TestCode.Network, "test.net", e.Message); }

            if (status >= 300 && status < 400)
                return location.StartsWith("https:", StringComparison.OrdinalIgnoreCase)
                    ? Fail(TestCode.HttpsRequired, "test.https_req", Lang.T("test.https_req_d"))
                    : Fail(TestCode.NotZenith, "test.notzd", Lang.T("test.notzd_d", shown));
            System.Collections.Generic.Dictionary<string, object> d = null;
            try { d = Json.Read(body); } catch { /* not JSON */ }
            if (status == 404 || d == null || Json.Str(d, "product") != AppInfo.Product)
            {
                if (status >= 500) return Fail(TestCode.ServerError, "test.server_err", Lang.T("test.server_err_d", "HTTP " + status));
                return Fail(TestCode.NotZenith, "test.notzd", Lang.T("test.notzd_d", shown));
            }
            if (status != 200) return Fail(TestCode.ServerError, "test.server_err", Lang.T("test.server_err_d", "HTTP " + status));
            if (Json.Bool(d, "https_required") && !https) return Fail(TestCode.HttpsRequired, "test.https_req", Lang.T("test.https_req_d"));

            var ok = new TestResult { Code = TestCode.Ok, Title = Lang.T("test.ok"), Version = Json.Str(d, "version"), Language = Json.Str(d, "language"), Ms = sw.ElapsedMilliseconds };
            if (seen != null) { ok.CertThumbprint = seen.Thumbprint; ok.CertSubject = seen.Subject; }
            ok.Warning = !Json.Bool(d, "database", true);
            ok.Detail = Lang.T("test.ok_d", ok.Version, ok.Ms, probe.BaseUrl) + (ok.Warning ? "\n" + Lang.T("test.warn_db") : "");
            return ok;
        }

        static string ReadBody(HttpWebResponse resp)
        {
            using (var s = resp.GetResponseStream())
            using (var r = new StreamReader(s, Encoding.UTF8))
            {
                var buf = new char[64 * 1024];
                var n = r.ReadBlock(buf, 0, buf.Length);
                return new string(buf, 0, n);
            }
        }

        public static Task<TestResult> TestAsync(ServerConfig cfg) { return Task.Run(() => Test(cfg)); }
    }
}
