using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("Zenith Desk Setup")]
[assembly: System.Reflection.AssemblyProduct("Zenith Desk")]
[assembly: System.Reflection.AssemblyCompany("Zenith Desk")]
[assembly: System.Reflection.AssemblyVersion("3.10.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("3.10.0.0")]
[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]

namespace ZenithDesk.Setup
{
    /// <summary>
    /// ZenithDesk-Setup-3.10.exe
    ///   (no arguments)        the installation wizard
    ///   /S                    silent installation for administrators (mass deployment, GPO, SCCM …):
    ///       /SERVER=10.0.0.5 /PORT=8000 [/HTTPS] [/DIR="C:\Program Files\Zenith Desk"] [/NODESKTOP] [/NOSTARTMENU]
    ///       [/AUTOSTART] [/LANG=ru|en] [/LOG=file] — the connection is always tested; without /SERVER an update keeps
    ///       the server already configured
    ///   /uninstall [/S] [/REMOVEDATA]   removal (this is what "Installed apps" → Uninstall runs)
    /// Exit codes: 0 done, 3010 done — restart needed, 1 error, 2 server connection failed, 3 system requirements,
    /// 4 no administrator rights, 1602 cancelled.
    /// </summary>
    public static class SetupProgram
    {
        public static Dictionary<string, string> Args = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        static bool Has(string k) { return Args.ContainsKey(k); }
        static string Arg(string k, string def = "") { string v; return Args.TryGetValue(k, out v) ? v : def; }

        public static void ParseArgs(string[] argv)
        {
            Args.Clear();
            foreach (var a in argv)
            {
                var t = a.TrimStart('/', '-');
                var i = t.IndexOf('=');
                if (i < 0) Args[t] = "";
                else Args[t.Substring(0, i)] = t.Substring(i + 1).Trim('"');
            }
        }

        [STAThread]
        public static int Main(string[] argv)
        {
            ParseArgs(argv);
            Log.FilePath = Arg("LOG", Path.Combine(Path.GetTempPath(), "ZenithDesk-Setup.log"));
            Log.Write("==== Zenith Desk Setup " + AppInfo.Version + " " + string.Join(" ", argv) + " on " + Environment.OSVersion);
            if (Has("LANG")) Lang.Code = Arg("LANG").ToLowerInvariant().StartsWith("en") ? "en" : "ru";
            Ui.Prepare();
            bool silent = Has("S") || Has("SILENT") || Has("QUIET");

            bool first;
            using (var mutex = new Mutex(true, AppInfo.IsTest ? "ZenithDeskSetupTest" + Process.GetCurrentProcess().Id : @"Global\ZenithDeskSetup", out first))
            {
                if (!first)
                {
                    if (!silent) MessageBox.Show(Lang.T("err.other_setup"), AppInfo.Product, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return 1;
                }
                try { return Run(argv, silent); }
                catch (Exception e)
                {
                    Log.Error("setup", e);
                    if (!silent) MessageBox.Show(e.Message + "\n\n" + Log.FilePath, AppInfo.Product, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 1;
                }
            }
        }

        static int Run(string[] argv, bool silent)
        {
            bool uninstall = Has("UNINSTALL");
            if (!Prereqs.IsAdmin())
            {
                Log.Write("no administrator rights");
                if (!silent) MessageBox.Show(Lang.T("err.admin"), AppInfo.Product, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 4;
            }
            // The uninstaller lives in the folder it removes: run a copy from %TEMP% so the whole folder can go.
            if (uninstall && AppInfo.IsWindows && !Has("TEMPCOPY"))
            {
                var self = InstallEngine.SelfPath();
                var inst = Installed.Read();
                if (inst != null && self.StartsWith(inst.Dir, StringComparison.OrdinalIgnoreCase))
                {
                    var copy = Path.Combine(Path.GetTempPath(), "ZenithDesk-Uninstall-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".exe");
                    File.Copy(self, copy, true);
                    var p = Process.Start(new ProcessStartInfo(copy, string.Join(" ", argv.Select(a => a.Contains(" ") ? "\"" + a + "\"" : a)) + " /TEMPCOPY") { UseShellExecute = false });
                    p.WaitForExit();
                    return p.ExitCode;
                }
            }
            if (silent) return uninstall ? SilentUninstall() : SilentInstall();

            if (!Has("LANG"))
                using (var lf = new LanguageForm())
                {
                    if (lf.ShowDialog() != DialogResult.OK) return 1602;
                    Lang.Code = lf.Chosen;
                }
            var state = NewState(uninstall);
            if (uninstall && state.Installed == null)
            {
                MessageBox.Show(Lang.T("uninst.notfound"), AppInfo.Product, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return 0;
            }
            using (var w = CreateWizard(state)) Application.Run(w);
            Log.Write("setup finished, exit code " + state.ExitCode);
            if (state.ExitCode == 0 && !state.Remove && state.LaunchAfter) LaunchClient(state.Options.InstallDir);
            if (state.Remove && state.Outcome != null && state.Outcome.Success && AppInfo.IsWindows && Has("TEMPCOPY")) SelfDelete();
            return state.ExitCode;
        }

        public static WizardState NewState(bool uninstall)
        {
            var state = new WizardState { Installed = Installed.Read() };
            state.Remove = uninstall; state.StartedAsUninstaller = uninstall;
            var cfg = ServerConfig.LoadFile(ServerConfig.MachineFile);
            if (cfg != null) state.Options.Server = cfg;
            if (Has("SERVER")) state.Options.Server = new ServerConfig { Host = Arg("SERVER"), Port = int.Parse(Arg("PORT", AppInfo.DefaultPort.ToString())), Https = Has("HTTPS") };
            if (Has("DIR")) state.Options.InstallDir = Arg("DIR");
            return state;
        }

        public static WizardForm CreateWizard(WizardState state)
        {
            return new WizardForm(state, new WizardPage[] {
                new WelcomePage(), new MaintenancePage(), new LicensePage(), new ComponentsPage(), new PrereqPage(), new ServerPage(),
                new ReadyPage(), new RemovePage(), new ProgressPage(), new FinishPage() });
        }

        static void LaunchClient(string dir)
        {
            try
            {
                var exe = Path.Combine(dir, AppInfo.ClientExe);
                if (AppInfo.IsWindows && File.Exists(exe)) Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true, WorkingDirectory = dir });
            }
            catch (Exception e) { Log.Error("launch client", e); }
        }

        static void SelfDelete()
        {
            try
            {
                Process.Start(new ProcessStartInfo("cmd.exe", "/c ping 127.0.0.1 -n 3 > nul & del /f /q \"" + InstallEngine.SelfPath() + "\"") { CreateNoWindow = true, UseShellExecute = false });
            }
            catch { }
        }

        // ------------------------------------------------------------------ silent mode for administrators
        static int SilentInstall()
        {
            var state = NewState(false);
            var o = state.Options;
            if (state.Installed != null && state.Installed.Dir.Length > 0 && !Has("DIR")) o.InstallDir = state.Installed.Dir;
            o.Desktop = !Has("NODESKTOP"); o.StartMenu = !Has("NOSTARTMENU");
            o.AutoRun = Has("AUTOSTART") || (state.Installed != null && state.Installed.AutoRun && !Has("NOAUTOSTART"));
            var pre = Prereqs.Check(o.InstallDir);
            var blocked = pre.Where(p => p.State == PrereqState.Blocked).ToList();
            if (blocked.Count > 0) { Log.Write(Lang.T("prereq.blocked", string.Join("; ", blocked.Select(b => b.Name + ": " + b.Detail)))); return 3; }
            var wv = pre.First(p => p.Key == "webview2");
            o.InstallWebView2 = wv.State == PrereqState.WillInstall; o.WebView2Offline = wv.OfflineFile;
            o.InstallNetFx = pre.First(p => p.Key == "netfx").State == PrereqState.WillInstall;
            if (!o.Server.IsSet) { Log.Write("silent install: /SERVER=address is required"); return 2; }
            var r = ConnectionTester.Test(o.Server);
            Log.Write("connection test: " + r);
            if (!r.Ok) return 2;
            o.Server.ServerVersion = r.Version; o.Server.TestedAt = DateTime.UtcNow.ToString("o");
            var outcome = new InstallEngine().Install(o, CancellationToken.None);
            return outcome.Success ? (outcome.RebootRequired ? 3010 : 0) : 1;
        }

        static int SilentUninstall()
        {
            if (Installed.Read() == null) { Log.Write(Lang.T("uninst.notfound")); return 0; }
            var outcome = new InstallEngine().Uninstall(Has("REMOVEDATA"));
            if (outcome.Success && AppInfo.IsWindows && Has("TEMPCOPY")) SelfDelete();
            return outcome.Success ? 0 : 1;
        }
    }
}
