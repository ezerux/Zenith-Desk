using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace ZenithDesk.Setup
{
    /// <summary>Everything the wizard collects on its way to the "Install" button.</summary>
    public class WizardState
    {
        public InstallOptions Options = new InstallOptions();
        public Installed Installed;            // what is on the computer already (null: fresh install)
        public bool Upgrade { get { return Installed != null && Installed.Compare(Installed.Version, AppInfo.Version) < 0; } }
        public bool Maintenance { get { return Installed != null && !Upgrade; } }
        public bool Remove;                    // maintenance: "Remove" chosen (or started as the uninstaller)
        public bool RemoveSettings;
        public bool StartedAsUninstaller;      // run from "Installed apps" → Uninstall
        public List<Prereq> Prereqs = new List<Prereq>();
        public Outcome Outcome;
        public bool LaunchAfter = true;
        public int ExitCode = 1602;            // "cancelled by the user" until something else happens
    }

    public abstract class WizardPage : Panel
    {
        public WizardForm Wizard;
        public virtual string Title { get { return ""; } }
        public virtual string Subtitle { get { return ""; } }
        public virtual bool Banner { get { return false; } }       // welcome / finish: the big picture on the left
        public virtual bool Applies(WizardState s) { return true; }
        public virtual bool CanNext { get { return true; } }
        public virtual bool CanBack { get { return true; } }
        public virtual bool CanCancel { get { return true; } }
        public virtual string NextText { get { return Lang.T("btn.next"); } }
        public virtual void OnShowPage() { }
        public virtual bool OnLeavePage() { return true; }
        protected WizardState S { get { return Wizard.State; } }
        protected void Changed() { if (Wizard != null) Wizard.UpdateButtons(); }
        protected WizardPage() { BackColor = Color.White; Font = Ui.Body; }
    }

    /// <summary>
    /// Classic Windows installer window (like the 1C:Enterprise setup): a picture on the left of the first and last
    /// pages, a white header with title and logo on the others, and "&lt; Back · Next &gt; · Cancel" at the bottom.
    /// </summary>
    public class WizardForm : Form
    {
        public readonly WizardState State;
        public readonly List<WizardPage> Pages = new List<WizardPage>();
        public readonly Button BackBtn = new Button(), NextBtn = new Button(), CancelBtn = new Button();
        readonly Panel header = new Panel(), footer = new Panel(), banner = new Panel(), host = new Panel();
        readonly Label hTitle = new Label(), hSub = new Label(), brand = new Label();
        int index = -1;
        public WizardPage Page { get { return index >= 0 ? Pages[index] : null; } }
        public bool Busy;   // while installing nothing may close the window

        public const int W = 620, H = 440, HeaderH = 62, FooterH = 52, BannerW = 170;

        public WizardForm(WizardState state, IEnumerable<WizardPage> pages)
        {
            State = state;
            Text = Lang.T("setup.title", AppInfo.ShortVersion);
            Icon = Ui.AppIcon; Font = Ui.Body;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = true;
            StartPosition = FormStartPosition.CenterScreen; ClientSize = new Size(W, H); BackColor = Color.White;
            ShowInTaskbar = true;

            header.SetBounds(0, 0, W, HeaderH); header.BackColor = Color.White; header.Paint += PaintHeader;
            hTitle.SetBounds(20, 11, W - 110, 20); hTitle.Font = Ui.Title; hTitle.BackColor = Color.Transparent; hTitle.Name = "page_title";
            hSub.SetBounds(34, 32, W - 124, 26); hSub.ForeColor = Ui.Muted; hSub.BackColor = Color.Transparent;
            header.Controls.AddRange(new Control[] { hTitle, hSub });

            banner.SetBounds(0, 0, BannerW, H - FooterH); banner.Paint += PaintBanner;
            host.SetBounds(0, HeaderH, W, H - HeaderH - FooterH); host.BackColor = Color.White;

            footer.SetBounds(0, H - FooterH, W, FooterH); footer.BackColor = SystemColors.Control; footer.Paint += (s, e) => e.Graphics.DrawLine(SystemPens.ControlDark, 0, 0, W, 0);
            brand.SetBounds(14, 18, 200, 18); brand.Text = AppInfo.Product + " " + AppInfo.ShortVersion; brand.ForeColor = SystemColors.GrayText; brand.Font = Ui.Small;
            BackBtn.SetBounds(W - 300, 13, 90, 27); NextBtn.SetBounds(W - 204, 13, 90, 27); CancelBtn.SetBounds(W - 102, 13, 90, 27);
            foreach (var b in new[] { BackBtn, NextBtn, CancelBtn }) b.FlatStyle = FlatStyle.System;
            BackBtn.Text = Lang.T("btn.back"); CancelBtn.Text = Lang.T("btn.cancel");
            BackBtn.Name = "back"; NextBtn.Name = "next"; CancelBtn.Name = "cancel";
            footer.Controls.AddRange(new Control[] { brand, BackBtn, NextBtn, CancelBtn });
            BackBtn.Click += (s, e) => GoBack();
            NextBtn.Click += (s, e) => GoNext();
            CancelBtn.Click += (s, e) => Close();
            AcceptButton = NextBtn;

            Controls.AddRange(new Control[] { banner, header, host, footer });
            foreach (var p in pages)
            {
                p.Wizard = this; p.Visible = false;
                Pages.Add(p); Controls.Add(p);
            }
            AutoScaleDimensions = new SizeF(96f, 96f); AutoScaleMode = AutoScaleMode.Dpi;
            Show(Next(-1, 1));
        }

        int Next(int from, int dir)
        {
            for (int i = from + dir; i >= 0 && i < Pages.Count; i += dir) if (Pages[i].Applies(State)) return i;
            return from;
        }

        public void Show(int i)
        {
            if (Page != null) Page.Visible = false;
            index = i;
            var p = Page;
            bool big = p.Banner;
            banner.Visible = big; header.Visible = !big; host.Visible = false;
            if (big) p.SetBounds(BannerW, 0, W - BannerW, H - FooterH);
            else p.SetBounds(0, HeaderH, W, H - HeaderH - FooterH);
            hTitle.Text = p.Title; hSub.Text = p.Subtitle;
            p.Visible = true; p.BringToFront();
            header.Invalidate(); banner.Invalidate();
            Log.Write("page " + p.GetType().Name);
            p.OnShowPage();
            UpdateButtons();
            var first = p.Controls.Cast<Control>().Where(c => c.TabStop && c.Enabled && c.Visible && !(c is Label)).OrderBy(c => c.TabIndex).FirstOrDefault();
            if (first != null && !(first is Button)) first.Focus(); else NextBtn.Focus();
        }

        public void UpdateButtons()
        {
            var p = Page; if (p == null) return;
            BackBtn.Enabled = p.CanBack && Next(index, -1) != index && !Busy;
            NextBtn.Enabled = p.CanNext && !Busy;
            NextBtn.Text = p.NextText;
            CancelBtn.Enabled = p.CanCancel && !Busy;
            CancelBtn.Visible = p.CanCancel || Busy;
            BackBtn.Visible = p.CanBack || Busy;
        }

        public void GoNext()
        {
            var p = Page;
            if (!NextBtn.Enabled || !p.OnLeavePage()) return;
            var n = Next(index, 1);
            if (n == index) { Close(); return; }   // the last page: Finish
            Show(n);
        }

        public void GoBack() { if (BackBtn.Enabled) Show(Next(index, -1)); }

        public static bool QuietClose;   // tests
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (Busy) { e.Cancel = true; return; }
            var last = Next(index, 1) == index;
            if (!last && !QuietClose && e.CloseReason == CloseReason.UserClosing &&
                MessageBox.Show(this, Lang.T("cancel.confirm"), Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            { e.Cancel = true; return; }
            if (!last) Log.Write("cancelled by the user on " + Page.GetType().Name);
            base.OnFormClosing(e);
        }

        void PaintHeader(object sender, PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            if (Ui.Logo != null) g.DrawImage(Ui.Logo, new Rectangle(W - 62, 9, 44, 44));
            g.DrawLine(SystemPens.ControlDark, 0, HeaderH - 1, W, HeaderH - 1);
        }

        void PaintBanner(object sender, PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            var r = banner.ClientRectangle;
            using (var b = new LinearGradientBrush(r, Ui.Navy, Ui.NavyDark, 90f)) g.FillRectangle(b, r);
            // faint diagonal "Z" stroke in the background
            using (var p = new Pen(Color.FromArgb(22, 255, 255, 255), 26f)) g.DrawLine(p, -20, r.Height - 40, r.Width + 20, 120);
            if (Ui.Logo != null) g.DrawImage(Ui.Logo, new Rectangle((r.Width - 96) / 2, 44, 96, 96));
            using (var f = new Font(Ui.Big.FontFamily, 14f, FontStyle.Bold))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center })
            {
                g.DrawString(AppInfo.Product, f, Brushes.White, new RectangleF(0, 156, r.Width, 30), sf);
                using (var mb = new SolidBrush(Color.FromArgb(170, 255, 255, 255)))
                    g.DrawString(Lang.IsRu ? "рабочее место оператора" : "operator workplace", Ui.Small, mb, new RectangleF(0, 186, r.Width, 20), sf);
                using (var gb = new SolidBrush(Ui.Green)) g.FillEllipse(gb, r.Width / 2 - 4, 216, 8, 8);
                using (var mb = new SolidBrush(Color.FromArgb(130, 255, 255, 255)))
                    g.DrawString("v" + AppInfo.ShortVersion, Ui.Small, mb, new RectangleF(0, r.Height - 30, r.Width, 20), sf);
            }
        }
    }

    /// <summary>The first question: which language to use for the installation.</summary>
    public class LanguageForm : Form
    {
        public readonly ComboBox Combo = new ComboBox();
        public LanguageForm()
        {
            Text = Lang.T("lang.title"); Icon = Ui.AppIcon; Font = Ui.Body;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = MinimizeBox = false; StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(380, 150); ShowInTaskbar = true;
            var pic = new PictureBox { Image = Ui.Logo, SizeMode = PictureBoxSizeMode.Zoom, Bounds = new Rectangle(16, 16, 40, 40) };
            var lbl = new Label { Text = "Выберите язык, который будет использоваться во время установки:\nSelect the language to use during the installation:", Bounds = new Rectangle(68, 14, 300, 46) };
            Combo.SetBounds(68, 66, 296, 24); Combo.DropDownStyle = ComboBoxStyle.DropDownList;
            Combo.Items.AddRange(new object[] { "Русский", "English" });
            Combo.SelectedIndex = Lang.Code == "en" ? 1 : 0;
            var ok = new Button { Text = "OK", Bounds = new Rectangle(188, 110, 85, 27), DialogResult = DialogResult.OK, FlatStyle = FlatStyle.System };
            var cancel = new Button { Text = Lang.Code == "en" ? "Cancel" : "Отмена", Bounds = new Rectangle(279, 110, 85, 27), DialogResult = DialogResult.Cancel, FlatStyle = FlatStyle.System };
            Controls.AddRange(new Control[] { pic, lbl, Combo, ok, cancel });
            AcceptButton = ok; CancelButton = cancel;
            AutoScaleDimensions = new SizeF(96f, 96f); AutoScaleMode = AutoScaleMode.Dpi;
        }
        public string Chosen { get { return Combo.SelectedIndex == 1 ? "en" : "ru"; } }
    }
}
