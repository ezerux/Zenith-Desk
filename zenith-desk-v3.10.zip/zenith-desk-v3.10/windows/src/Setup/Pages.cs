using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZenithDesk.Setup
{
    // ====================================================================== 1. welcome
    public class WelcomePage : WizardPage
    {
        readonly Label head = new Label(), text = new Label(), warn = new Label();
        public override bool Banner { get { return true; } }
        public override bool CanBack { get { return false; } }
        public override bool Applies(WizardState s) { return !s.StartedAsUninstaller; }
        public WelcomePage()
        {
            head.SetBounds(22, 22, 410, 52); head.Font = Ui.Big;
            text.SetBounds(22, 84, 410, 170);
            warn.SetBounds(22, 296, 410, 60); warn.ForeColor = Ui.Muted; warn.Font = Ui.Small;
            Controls.AddRange(new Control[] { head, text, warn });
        }
        public override void OnShowPage()
        {
            head.Text = S.Remove ? Lang.T("uninst.title") : Lang.T("welcome.head");
            text.Text = S.Upgrade ? Lang.T("welcome.upgrade", S.Installed.Version, AppInfo.Version)
                      : S.Remove ? Lang.T("uninst.confirm", S.Installed != null ? S.Installed.Version : AppInfo.Version)
                      : Lang.T("welcome.text", AppInfo.Version);
            warn.Text = Lang.T("welcome.warn");
        }
    }

    // ====================================================================== 1b. already installed: repair or remove
    public class MaintenancePage : WizardPage
    {
        public readonly RadioButton Repair = new RadioButton(), Remove = new RadioButton();
        public override string Title { get { return Lang.T("maint.title"); } }
        public override string Subtitle { get { return Lang.T("maint.sub"); } }
        public override bool Applies(WizardState s) { return s.Maintenance && !s.StartedAsUninstaller; }
        public MaintenancePage()
        {
            Repair.SetBounds(30, 24, 400, 22); Repair.Text = Lang.T("maint.repair"); Repair.Font = Ui.Bold; Repair.Checked = true; Repair.Name = "repair";
            var rd = Ui.Text(Lang.T("maint.repair_d"), 48, 48, 520, 36, null, Ui.Muted);
            Remove.SetBounds(30, 98, 400, 22); Remove.Text = Lang.T("maint.remove"); Remove.Font = Ui.Bold; Remove.Name = "remove";
            var md = Ui.Text(Lang.T("maint.remove_d"), 48, 122, 520, 36, null, Ui.Muted);
            Controls.AddRange(new Control[] { Repair, rd, Remove, md });
        }
        public override bool OnLeavePage() { S.Remove = Remove.Checked; return true; }
    }

    // ====================================================================== 2. license
    public class LicensePage : WizardPage
    {
        public readonly RadioButton Accept = new RadioButton(), Decline = new RadioButton();
        readonly TextBox box = new TextBox();
        public override string Title { get { return Lang.T("license.title"); } }
        public override string Subtitle { get { return Lang.T("license.sub"); } }
        public override bool Applies(WizardState s) { return !s.Remove; }
        public override bool CanNext { get { return Accept.Checked; } }
        public LicensePage()
        {
            box.SetBounds(24, 14, 572, 220); box.Multiline = true; box.ReadOnly = true; box.ScrollBars = ScrollBars.Vertical; box.BackColor = Color.White;
            box.Text = Lang.T("license.text").Replace("\n", Environment.NewLine); box.TabStop = false;
            Accept.SetBounds(24, 244, 500, 22); Accept.Text = Lang.T("license.accept"); Accept.Name = "accept";
            Decline.SetBounds(24, 268, 500, 22); Decline.Text = Lang.T("license.decline"); Decline.Checked = true; Decline.Name = "decline";
            Accept.CheckedChanged += (s, e) => Changed();
            Controls.AddRange(new Control[] { box, Accept, Decline });
        }
    }

    // ====================================================================== 3. components and folder
    public class ComponentsPage : WizardPage
    {
        public readonly CheckBox App = new CheckBox(), Desktop = new CheckBox(), StartMenu = new CheckBox(), AutoRun = new CheckBox();
        public readonly TextBox Folder = new TextBox();
        public readonly Button Change = new Button();
        readonly Label desc = new Label(), space = new Label();
        public override string Title { get { return Lang.T("comp.title"); } }
        public override string Subtitle { get { return Lang.T("comp.sub"); } }
        public override bool Applies(WizardState s) { return !s.Remove; }
        public ComponentsPage()
        {
            var list = new Panel { Bounds = new Rectangle(24, 14, 330, 150), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
            int y = 8;
            foreach (var t in new[] { Tuple.Create(App, "comp.app"), Tuple.Create(Desktop, "comp.desktop"), Tuple.Create(StartMenu, "comp.start"), Tuple.Create(AutoRun, "comp.autorun") })
            {
                var cb = t.Item1; var key = t.Item2;
                cb.SetBounds(t.Item1 == App ? 10 : 30, y, 290, 24); cb.Text = Lang.T(key); cb.Name = key; y += 32;
                cb.Enter += (s, e) => desc.Text = Lang.T(key + "_d");
                cb.MouseEnter += (s, e) => desc.Text = Lang.T(key + "_d");
                list.Controls.Add(cb);
            }
            App.Checked = true; App.Enabled = false; App.Font = Ui.Bold;
            Desktop.Checked = true; StartMenu.Checked = true;
            var dbox = new GroupBox { Text = Lang.T("comp.desc"), Bounds = new Rectangle(366, 8, 230, 156) };
            desc.SetBounds(10, 22, 210, 126); desc.ForeColor = Ui.Muted; desc.Text = Lang.T("comp.app_d");
            dbox.Controls.Add(desc);
            var fl = Ui.Text(Lang.T("comp.folder"), 24, 182, 300, 18);
            Folder.SetBounds(24, 202, 452, 24); Folder.ReadOnly = true; Folder.BackColor = Color.White; Folder.Name = "folder";
            Change.SetBounds(484, 201, 112, 27); Change.Text = Lang.T("btn.change"); Change.FlatStyle = FlatStyle.System;
            Change.Click += (s, e) => Pick();
            space.SetBounds(24, 236, 572, 20); space.ForeColor = Ui.Muted;
            Controls.AddRange(new Control[] { list, dbox, fl, Folder, Change, space });
        }
        public override void OnShowPage()
        {
            if (Folder.Text.Length == 0)
            {
                Folder.Text = S.Installed != null && S.Installed.Dir.Length > 0 ? S.Installed.Dir : S.Options.InstallDir;
                if (S.Installed != null) AutoRun.Checked = S.Installed.AutoRun;
            }
            Change.Enabled = S.Installed == null;   // an update stays where it is
            UpdateSpace();
            Folder.SelectionLength = 0; Desktop.Focus();
        }
        void Pick()
        {
            using (var d = new FolderBrowserDialog { Description = Lang.T("comp.pick"), SelectedPath = Path.GetDirectoryName(Folder.Text) ?? Folder.Text })
                if (d.ShowDialog(this) == DialogResult.OK)
                {
                    var path = d.SelectedPath;
                    if (!path.TrimEnd('\\', '/').EndsWith(AppInfo.Product, StringComparison.OrdinalIgnoreCase)) path = Path.Combine(path, AppInfo.Product);
                    Folder.Text = path; UpdateSpace();
                }
        }
        void UpdateSpace() { space.Text = Lang.T("comp.space", AppInfo.FormatSize(InstallEngine.PayloadSize()), AppInfo.FormatSize(Prereqs.FreeBytes(Folder.Text))); }
        public override bool OnLeavePage()
        {
            S.Options.InstallDir = Folder.Text; S.Options.Desktop = Desktop.Checked; S.Options.StartMenu = StartMenu.Checked; S.Options.AutoRun = AutoRun.Checked;
            return true;
        }
    }

    // ====================================================================== 4. system check
    public class PrereqPage : WizardPage
    {
        readonly List<Tuple<StatusMark, Label, Label>> rows = new List<Tuple<StatusMark, Label, Label>>();
        readonly Button recheck = new Button();
        readonly Label note = new Label();
        bool checking;
        public override string Title { get { return Lang.T("prereq.title"); } }
        public override string Subtitle { get { return Lang.T("prereq.sub"); } }
        public override bool Applies(WizardState s) { return !s.Remove; }
        public override bool CanNext { get { return !checking && S.Prereqs.Count > 0 && S.Prereqs.All(p => p.State != PrereqState.Blocked); } }
        public PrereqPage()
        {
            for (int i = 0; i < 5; i++)
            {
                int y = 12 + i * 40;
                var m = new StatusMark { Left = 26, Top = y + 2 };
                var n = Ui.Text("", 54, y, 540, 18, Ui.Bold);
                var d = Ui.Text("", 54, y + 18, 540, 20, null, Ui.Muted);
                n.Name = "prereq_name" + i; d.Name = "prereq_detail" + i;
                rows.Add(Tuple.Create(m, n, d)); Controls.AddRange(new Control[] { m, n, d });
            }
            note.SetBounds(26, 214, 440, 84); note.ForeColor = Ui.Muted; note.Font = Ui.Small; note.Text = Lang.T("prereq.note");
            recheck.SetBounds(478, 216, 118, 27); recheck.Text = Lang.T("prereq.recheck"); recheck.FlatStyle = FlatStyle.System;
            recheck.Click += (s, e) => Run();
            Controls.AddRange(new Control[] { note, recheck });
        }
        public override void OnShowPage() { Run(); }
        void Run()
        {
            checking = true; recheck.Enabled = false; Changed();
            foreach (var r in rows) { r.Item1.Status = Status.Busy; }
            var dir = S.Options.InstallDir;
            Task.Run(() => { Thread.Sleep(400); return Prereqs.Check(dir); }).ContinueWith(t => BeginInvoke((Action)(() => {
                S.Prereqs = t.Exception == null ? t.Result : new List<Prereq>();
                for (int i = 0; i < rows.Count; i++)
                {
                    var p = i < S.Prereqs.Count ? S.Prereqs[i] : null;
                    rows[i].Item1.Status = p == null ? Status.Pending : p.State == PrereqState.Ok ? Status.Ok : p.State == PrereqState.WillInstall ? Status.Warn : Status.Fail;
                    rows[i].Item2.Text = p == null ? "" : p.Name;
                    rows[i].Item3.Text = p == null ? "" : p.Detail;
                    rows[i].Item3.ForeColor = p != null && p.State == PrereqState.Blocked ? Ui.Red : Ui.Muted;
                }
                checking = false; recheck.Enabled = true; Changed();
            })));
        }
        public override bool OnLeavePage()
        {
            var wv = S.Prereqs.FirstOrDefault(p => p.Key == "webview2");
            S.Options.InstallWebView2 = wv != null && wv.State == PrereqState.WillInstall;
            S.Options.WebView2Offline = wv != null ? wv.OfflineFile : "";
            var nf = S.Prereqs.FirstOrDefault(p => p.Key == "netfx");
            S.Options.InstallNetFx = nf != null && nf.State == PrereqState.WillInstall;
            return true;
        }
    }

    // ====================================================================== 5. server address + mandatory test
    public class ServerPage : WizardPage
    {
        public readonly ServerPanel Panel = new ServerPanel();
        public override string Title { get { return Lang.T("server.title"); } }
        public override string Subtitle { get { return Lang.T("server.sub"); } }
        public override bool Applies(WizardState s) { return !s.Remove; }
        public override bool CanNext { get { return Panel.Passed; } }
        public ServerPage()
        {
            Panel.Location = new Point(28, 16); Panel.Width = 564;
            Panel.PassedChanged += (s, e) => Changed();
            Controls.Add(Panel);
        }
        bool loaded;
        public override void OnShowPage()
        {
            if (!loaded) { loaded = true; Panel.SetConfig(S.Options.Server.IsSet ? S.Options.Server : ServerConfig.LoadFile(ServerConfig.MachineFile)); }
            Panel.HostBox.Focus();
        }
        public override bool OnLeavePage()
        {
            if (!Panel.Passed) return false;
            S.Options.Server = Panel.Result;
            return true;
        }
    }

    // ====================================================================== 6. summary
    public class ReadyPage : WizardPage
    {
        readonly TextBox box = new TextBox();
        public override string Title { get { return Lang.T("ready.title"); } }
        public override string Subtitle { get { return Lang.T("ready.sub"); } }
        public override bool Applies(WizardState s) { return !s.Remove; }
        public override string NextText { get { return Lang.T("btn.install"); } }
        public ReadyPage()
        {
            box.SetBounds(24, 14, 572, 260); box.Multiline = true; box.ReadOnly = true; box.BackColor = Color.White; box.ScrollBars = ScrollBars.Vertical; box.Name = "summary";
            Controls.Add(box);
        }
        public override void OnShowPage()
        {
            var o = S.Options; var nl = Environment.NewLine;
            var comps = new List<string> { Lang.T("comp.app") };
            if (o.Desktop) comps.Add(Lang.T("comp.desktop"));
            if (o.StartMenu) comps.Add(Lang.T("comp.start"));
            if (o.AutoRun) comps.Add(Lang.T("comp.autorun"));
            var pre = new List<string>();
            if (o.InstallNetFx) pre.Add("Microsoft .NET Framework 4.8");
            if (o.InstallWebView2) pre.Add("Microsoft Edge WebView2 Runtime");
            box.Text = Lang.T("ready.folder") + nl + "    " + o.InstallDir + nl + nl +
                       Lang.T("ready.server") + nl + "    " + o.Server.BaseUrl + "   (Zenith Desk " + o.Server.ServerVersion + ")" + nl + nl +
                       Lang.T("ready.components") + nl + string.Join(nl, comps.Select(c => "    " + c)) + nl + nl +
                       Lang.T("ready.prereq") + nl + "    " + (pre.Count > 0 ? string.Join(", ", pre) : Lang.T("ready.none"));
            box.Select(0, 0);
        }
    }

    // ====================================================================== 6b. removal: confirm
    public class RemovePage : WizardPage
    {
        public readonly CheckBox Data = new CheckBox();
        readonly Label text = new Label();
        public override string Title { get { return Lang.T("uninst.title"); } }
        public override string Subtitle { get { return Lang.T("maint.remove_d"); } }
        public override bool Applies(WizardState s) { return s.Remove; }
        public override string NextText { get { return Lang.T("btn.remove"); } }
        public RemovePage()
        {
            text.SetBounds(28, 24, 560, 40); text.Font = Ui.Bold;
            Data.SetBounds(28, 74, 560, 24); Data.Text = Lang.T("uninst.data"); Data.Name = "remove_data";
            Controls.AddRange(new Control[] { text, Data });
        }
        public override void OnShowPage() { text.Text = Lang.T("uninst.confirm", S.Installed != null ? S.Installed.Version : AppInfo.Version); }
        public override bool OnLeavePage() { S.RemoveSettings = Data.Checked; return true; }
    }

    // ====================================================================== 7. installing / removing
    public class ProgressPage : WizardPage
    {
        public readonly ProgressBar Bar = new ProgressBar();
        readonly Label step = new Label(), detail = new Label();
        public readonly ListBox Lines = new ListBox();
        bool done;
        public override string Title { get { return S.Remove ? Lang.T("uninst.title") : Lang.T("progress.title"); } }
        public override string Subtitle { get { return S.Remove ? Lang.T("uninst.progress") : Lang.T("progress.sub"); } }
        public override bool CanNext { get { return done; } }
        public override bool CanBack { get { return false; } }
        public override bool CanCancel { get { return false; } }
        public ProgressPage()
        {
            step.SetBounds(28, 18, 564, 20); step.Font = Ui.Bold; step.Name = "step";
            Bar.SetBounds(28, 42, 564, 20); Bar.Maximum = 100;
            detail.SetBounds(28, 66, 564, 18); detail.ForeColor = Ui.Muted; detail.Font = Ui.Small;
            Lines.SetBounds(28, 92, 564, 180); Lines.IntegralHeight = false; Lines.Font = Ui.Small; Lines.BorderStyle = BorderStyle.FixedSingle;
            Controls.AddRange(new Control[] { step, Bar, detail, Lines });
        }
        public override void OnShowPage()
        {
            if (done) return;
            Wizard.Busy = true; Changed();
            var engine = new InstallEngine();
            string last = "";
            engine.Progress += (pct, st, d) => BeginInvoke((Action)(() => {
                Bar.Value = Math.Max(0, Math.Min(100, pct)); step.Text = st; detail.Text = d;
                if (st != last) { Lines.Items.Add(DateTime.Now.ToString("HH:mm:ss") + "   " + st); Lines.TopIndex = Lines.Items.Count - 1; last = st; }
            }));
            var s = S;
            Task.Run(() => s.Remove ? engine.Uninstall(s.RemoveSettings) : engine.Install(s.Options, CancellationToken.None)).ContinueWith(t => BeginInvoke((Action)(() => {
                s.Outcome = t.Exception == null ? t.Result : new Outcome { Error = t.Exception.InnerException.Message };
                s.ExitCode = s.Outcome.Success ? (s.Outcome.RebootRequired ? 3010 : 0) : 1;
                if (!s.Outcome.Success) { Lines.Items.Add(Lang.T("progress.error", s.Outcome.Error)); Lines.Items.Add(Lang.T("progress.rollback")); step.ForeColor = Ui.Red; step.Text = Lang.T("progress.error", s.Outcome.Error); }
                done = true; Wizard.Busy = false; Changed();
                Wizard.GoNext();   // straight to the last page
            })));
        }
    }

    // ====================================================================== 8. finish
    public class FinishPage : WizardPage
    {
        readonly Label head = new Label(), text = new Label();
        public readonly CheckBox Launch = new CheckBox();
        public override bool Banner { get { return true; } }
        public override bool CanBack { get { return false; } }
        public override bool CanCancel { get { return false; } }
        public override string NextText { get { return Lang.T("btn.finish"); } }
        public FinishPage()
        {
            head.SetBounds(22, 22, 410, 52); head.Font = Ui.Big; head.Name = "finish_head";
            text.SetBounds(22, 84, 410, 190); text.Name = "finish_text";
            Launch.SetBounds(22, 290, 410, 24); Launch.Text = Lang.T("finish.launch"); Launch.Checked = true; Launch.Name = "launch";
            Controls.AddRange(new Control[] { head, text, Launch });
        }
        public override void OnShowPage()
        {
            var o = S.Outcome ?? new Outcome { Error = "?" };
            if (S.Remove)
            {
                head.Text = o.Success ? Lang.T("uninst.title") : Lang.T("finish.failhead");
                text.Text = o.Success ? Lang.T("uninst.done") : Lang.T("progress.error", o.Error) + "\n\n" + Log.FilePath;
                Launch.Visible = false;
                return;
            }
            head.Text = o.Success ? Lang.T("finish.head") : Lang.T("finish.failhead");
            text.Text = o.Success ? Lang.T("finish.text", AppInfo.Version, S.Options.Server.BaseUrl) + (o.RebootRequired ? "\n\n" + Lang.T("finish.reboot") : "")
                                  : Lang.T("progress.error", o.Error) + "\n" + Lang.T("progress.rollback") + "\n\n" + Log.FilePath;
            Launch.Visible = o.Success && !o.RebootRequired;
        }
        public override bool OnLeavePage() { S.LaunchAfter = Launch.Visible && Launch.Checked; return true; }
    }
}
