using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using Microsoft.Win32;

namespace ZenithDesk.Setup
{
    public class InstallOptions
    {
        public string InstallDir = AppInfo.DefaultInstallDir;
        public ServerConfig Server = new ServerConfig();
        public bool Desktop = true, StartMenu = true, AutoRun;
        public bool InstallWebView2, InstallNetFx;
        public string WebView2Offline = "";
    }

    public class Outcome
    {
        public bool Success, RebootRequired;
        public string Error = "";
    }

    /// <summary>What is installed now (read from "Installed apps" registration).</summary>
    public class Installed
    {
        public string Version = "", Dir = "";
        public bool AutoRun;
        public static Installed Read()
        {
            using (var root = AppInfo.MachineRoot(false))
            using (var k = root.OpenSubKey(AppInfo.UninstallKeyPath))
            {
                if (k == null) return null;
                var r = new Installed { Version = (k.GetValue("DisplayVersion") ?? "").ToString(), Dir = (k.GetValue("InstallLocation") ?? "").ToString() };
                using (var run = root.OpenSubKey(AppInfo.RunKeyPath)) r.AutoRun = run != null && run.GetValue(AppInfo.RunValueName) != null;
                return r.Version.Length > 0 ? r : null;
            }
        }
        public static int Compare(string a, string b)
        {
            Version va, vb;
            if (!System.Version.TryParse(a, out va)) va = new Version(0, 0);
            if (!System.Version.TryParse(b, out vb)) vb = new Version(0, 0);
            return va.CompareTo(vb);
        }
    }

    /// <summary>The installation itself — the same steps for the wizard and for silent (/S) installation.</summary>
    public class InstallEngine
    {
        public delegate void ProgressFn(int percent, string step, string detail);
        public event ProgressFn Progress;
        readonly List<string> createdFiles = new List<string>();
        readonly List<string> createdDirs = new List<string>();
        bool createdUninstallKey;

        void Report(int pct, string step, string detail = "") { Log.Write("[" + pct + "%] " + step + (detail.Length > 0 ? " — " + detail : "")); if (Progress != null) Progress(pct, step, detail); }

        public static IEnumerable<string> PayloadNames()
        {
            using (var s = Ui.Resource("payload.txt"))
            using (var r = new StreamReader(s))
            {
                string line;
                while ((line = r.ReadLine()) != null) if (line.Trim().Length > 0) yield return line.Trim();
            }
        }

        public static long PayloadSize()
        {
            long n = 0;
            foreach (var name in PayloadNames()) using (var s = Ui.Resource("payload/" + name)) n += s.Length;
            return n;
        }

        public static string SelfPath()
        {
            try { return Process.GetCurrentProcess().MainModule.FileName.EndsWith("mono", StringComparison.Ordinal) || Process.GetCurrentProcess().MainModule.FileName.EndsWith("mono-sgen", StringComparison.Ordinal)
                    ? Assembly.GetExecutingAssembly().Location : Process.GetCurrentProcess().MainModule.FileName; }
            catch { return Assembly.GetExecutingAssembly().Location; }
        }

        public static void CloseRunningClient()
        {
            if (!AppInfo.IsWindows) return;
            foreach (var p in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(AppInfo.ClientExe)))
            {
                try
                {
                    Log.Write("closing running client pid " + p.Id);
                    p.CloseMainWindow();
                    if (!p.WaitForExit(4000)) { p.Kill(); p.WaitForExit(4000); }
                }
                catch (Exception e) { Log.Error("close client", e); }
            }
        }

        public Outcome Install(InstallOptions o, CancellationToken ct)
        {
            var outcome = new Outcome();
            bool freshDir = !Directory.Exists(o.InstallDir);
            try
            {
                Log.Write("install to " + o.InstallDir + ", server " + o.Server.Display + ", desktop=" + o.Desktop + ", startmenu=" + o.StartMenu + ", autorun=" + o.AutoRun);
                Report(2, Lang.T("step.close"));
                CloseRunningClient();

                // 1. Microsoft components
                if (o.InstallNetFx)
                {
                    var code = Prereqs.InstallFromMicrosoft(".NET Framework 4.8", AppInfo.NetFx48Url, "ndp48-web.exe", "/q /norestart", "",
                                                            (p, d) => Report(4 + p * 16 / 100, Lang.T("step.prereq", ".NET Framework 4.8"), d), ct);
                    if (code == 3010 || code == 1641) outcome.RebootRequired = true;
                    else if (code != 0) throw new Exception(".NET Framework 4.8: exit code " + code);
                }
                if (o.InstallWebView2)
                {
                    var code = Prereqs.InstallFromMicrosoft("Microsoft Edge WebView2 Runtime", AppInfo.WebView2BootstrapperUrl, "MicrosoftEdgeWebview2Setup.exe",
                                                            "/silent /install", o.WebView2Offline, (p, d) => Report(20 + p * 30 / 100, Lang.T("step.prereq", "WebView2 Runtime"), d), ct);
                    if (code != 0 && Prereqs.WebView2Version().Length == 0) throw new Exception("Microsoft Edge WebView2 Runtime: exit code 0x" + code.ToString("X"));
                }
                ct.ThrowIfCancellationRequested();

                // 2. program files
                Report(52, Lang.T("step.files"));
                var names = PayloadNames().ToList();
                if (freshDir) { Directory.CreateDirectory(o.InstallDir); createdDirs.Add(o.InstallDir); }
                int i = 0;
                foreach (var name in names)
                {
                    ct.ThrowIfCancellationRequested();
                    var dest = Path.Combine(o.InstallDir, name.Replace('/', Path.DirectorySeparatorChar));
                    Directory.CreateDirectory(Path.GetDirectoryName(dest));
                    var tmp = dest + ".new";
                    using (var src = Ui.Resource("payload/" + name))
                    using (var f = File.Create(tmp)) src.CopyTo(f);
                    if (File.Exists(dest)) File.Delete(dest);
                    File.Move(tmp, dest);
                    createdFiles.Add(dest);
                    Report(52 + ++i * 18 / Math.Max(1, names.Count), Lang.T("step.files"), name);
                }
                // the WebView2 loader of this computer's architecture next to the program
                var arch = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE") == "ARM64" ? "win-arm64" : Environment.Is64BitOperatingSystem ? "win-x64" : "win-x86";
                var loader = Path.Combine(o.InstallDir, "runtimes", arch, "native", "WebView2Loader.dll");
                if (File.Exists(loader)) { var d = Path.Combine(o.InstallDir, "WebView2Loader.dll"); File.Copy(loader, d, true); createdFiles.Add(d); }
                // the uninstaller is this very setup program
                var uninst = Path.Combine(o.InstallDir, AppInfo.UninstallExe);
                var self = SelfPath();
                if (!string.Equals(Path.GetFullPath(self), Path.GetFullPath(uninst), StringComparison.OrdinalIgnoreCase)) File.Copy(self, uninst, true);
                createdFiles.Add(uninst);

                // 3. server connection, for every user of this computer
                Report(72, Lang.T("step.config"), o.Server.Display);
                o.Server.Save(ServerConfig.MachineFile);
                ct.ThrowIfCancellationRequested();

                // 4. shortcuts
                Report(80, Lang.T("step.shortcuts"));
                var exe = Path.Combine(o.InstallDir, AppInfo.ClientExe);
                var desktopLnk = Path.Combine(AppInfo.CommonDesktop, AppInfo.Product + ".lnk");
                if (o.Desktop) { Shortcuts.Create(desktopLnk, exe, "", o.InstallDir, Lang.T("sc.app_desc"), exe); createdFiles.Add(desktopLnk); }
                else if (File.Exists(desktopLnk)) File.Delete(desktopLnk);
                if (o.StartMenu)
                {
                    var appLnk = Path.Combine(AppInfo.StartMenuDir, AppInfo.Product + ".lnk");
                    var setLnk = Path.Combine(AppInfo.StartMenuDir, Lang.T("sc.settings") + ".lnk");
                    Shortcuts.Create(appLnk, exe, "", o.InstallDir, Lang.T("sc.app_desc"), exe); createdFiles.Add(appLnk);
                    Shortcuts.Create(setLnk, exe, "/settings", o.InstallDir, Lang.T("sc.settings"), exe); createdFiles.Add(setLnk);
                }
                else if (Directory.Exists(AppInfo.StartMenuDir)) Directory.Delete(AppInfo.StartMenuDir, true);

                // 5. "Installed apps" (Settings → Apps) registration
                Report(90, Lang.T("step.registry"));
                using (var root = AppInfo.MachineRoot(true))
                {
                    using (var existing = root.OpenSubKey(AppInfo.UninstallKeyPath)) createdUninstallKey = existing == null;
                    using (var k = root.CreateSubKey(AppInfo.UninstallKeyPath))
                    {
                        k.SetValue("DisplayName", AppInfo.Product);
                        k.SetValue("DisplayVersion", AppInfo.Version);
                        k.SetValue("Publisher", AppInfo.Publisher);
                        k.SetValue("DisplayIcon", exe + ",0");
                        k.SetValue("InstallLocation", o.InstallDir);
                        k.SetValue("InstallDate", DateTime.Now.ToString("yyyyMMdd"));
                        k.SetValue("UninstallString", "\"" + uninst + "\" /uninstall");
                        k.SetValue("QuietUninstallString", "\"" + uninst + "\" /uninstall /S");
                        k.SetValue("EstimatedSize", (int)(DirSize(o.InstallDir) / 1024), RegistryValueKind.DWord);
                        k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                        k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
                        k.SetValue("Comments", Lang.T("sc.app_desc"));
                        k.SetValue("ZenithServer", o.Server.BaseUrl);
                        k.SetValue("Language", Lang.Code);
                    }
                    Report(95, Lang.T("step.autorun"));
                    using (var run = root.CreateSubKey(AppInfo.RunKeyPath))
                    {
                        if (o.AutoRun) run.SetValue(AppInfo.RunValueName, "\"" + exe + "\" /autostart");
                        else if (run.GetValue(AppInfo.RunValueName) != null) run.DeleteValue(AppInfo.RunValueName);
                    }
                }
                Report(100, Lang.T("step.done"));
                outcome.Success = true;
                Log.Write("installation finished");
            }
            catch (Exception e)
            {
                outcome.Error = e is OperationCanceledException ? Lang.T("btn.cancel") : e.Message;
                Log.Error("install", e);
                Rollback(freshDir, o.InstallDir);
            }
            return outcome;
        }

        void Rollback(bool freshDir, string dir)
        {
            Log.Write("rollback");
            foreach (var f in createdFiles.AsEnumerable().Reverse())
                try { if (f.EndsWith(".lnk") && File.Exists(f)) File.Delete(f); } catch { }
            if (freshDir) try { if (Directory.Exists(dir)) Directory.Delete(dir, true); } catch (Exception e) { Log.Error("rollback dir", e); }
            if (createdUninstallKey)
                try { using (var root = AppInfo.MachineRoot(true)) root.DeleteSubKeyTree(AppInfo.UninstallKeyPath, false); } catch { }
        }

        static long DirSize(string dir)
        {
            try { return new DirectoryInfo(dir).EnumerateFiles("*", SearchOption.AllDirectories).Sum(f => f.Length); } catch { return 0; }
        }

        // ------------------------------------------------------------------ removal
        public Outcome Uninstall(bool removeSettings)
        {
            var outcome = new Outcome();
            try
            {
                var inst = Installed.Read();
                var dir = inst != null && inst.Dir.Length > 0 ? inst.Dir : AppInfo.DefaultInstallDir;
                Log.Write("uninstall from " + dir + ", remove settings=" + removeSettings);
                Report(5, Lang.T("step.close"));
                CloseRunningClient();
                Report(20, Lang.T("step.shortcuts"));
                var desktopLnk = Path.Combine(AppInfo.CommonDesktop, AppInfo.Product + ".lnk");
                if (File.Exists(desktopLnk)) File.Delete(desktopLnk);
                if (Directory.Exists(AppInfo.StartMenuDir)) Directory.Delete(AppInfo.StartMenuDir, true);
                Report(40, Lang.T("step.registry"));
                using (var root = AppInfo.MachineRoot(true))
                {
                    using (var run = root.OpenSubKey(AppInfo.RunKeyPath, true))
                        if (run != null && run.GetValue(AppInfo.RunValueName) != null) run.DeleteValue(AppInfo.RunValueName);
                    root.DeleteSubKeyTree(AppInfo.UninstallKeyPath, false);
                }
                Report(60, Lang.T("step.files"));
                if (Directory.Exists(dir)) DeleteProgramDir(dir);
                if (removeSettings)
                {
                    Report(85, Lang.T("step.config"));
                    foreach (var d in new[] { AppInfo.MachineDataDir, AppInfo.UserDataDir, Path.Combine(AppInfo.UserLocalAppData, AppInfo.Product) })
                        try { if (Directory.Exists(d)) Directory.Delete(d, true); } catch (Exception e) { Log.Error("remove " + d, e); }
                }
                Report(100, Lang.T("step.done"));
                outcome.Success = true;
            }
            catch (Exception e) { outcome.Error = e.Message; Log.Error("uninstall", e); }
            return outcome;
        }

        static void DeleteProgramDir(string dir)
        {
            var self = Path.GetFullPath(SelfPath());
            foreach (var f in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
            {
                if (string.Equals(Path.GetFullPath(f), self, StringComparison.OrdinalIgnoreCase) && AppInfo.IsWindows) continue;  // still running
                try { File.Delete(f); } catch (Exception e) { Log.Error("delete " + f, e); }
            }
            try { Directory.Delete(dir, true); }
            catch
            {   // the running uninstaller: Windows removes it a moment after we exit
                if (AppInfo.IsWindows)
                    Process.Start(new ProcessStartInfo("cmd.exe", "/c ping 127.0.0.1 -n 3 > nul & rmdir /s /q \"" + dir + "\"") { CreateNoWindow = true, UseShellExecute = false });
            }
        }
    }
}
