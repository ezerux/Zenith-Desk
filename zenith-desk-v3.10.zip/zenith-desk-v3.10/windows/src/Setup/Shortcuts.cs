using System;
using System.IO;
using System.Reflection;
using System.Text;

namespace ZenithDesk.Setup
{
    /// <summary>
    /// .lnk shortcuts. On Windows they are made by the Windows shell itself (WScript.Shell, the same object every
    /// installer uses). Where it is not available, a shortcut is written byte by byte by the [MS-SHLLINK] format.
    /// </summary>
    public static class Shortcuts
    {
        public static bool ForceManaged;   // tests

        public static void Create(string lnk, string target, string args, string workDir, string description, string icon)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(lnk));
            if (File.Exists(lnk)) File.Delete(lnk);
            if (!ForceManaged && AppInfo.IsWindows && TryShell(lnk, target, args, workDir, description, icon)) return;
            File.WriteAllBytes(lnk, ManagedLink(target, args, workDir, description, icon));
        }

        static bool TryShell(string lnk, string target, string args, string workDir, string description, string icon)
        {
            object shell = null, sc = null;
            try
            {
                var t = Type.GetTypeFromProgID("WScript.Shell");
                if (t == null) return false;
                shell = Activator.CreateInstance(t);
                sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
                var st = sc.GetType();
                st.InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { target });
                st.InvokeMember("Arguments", BindingFlags.SetProperty, null, sc, new object[] { args ?? "" });
                st.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { workDir });
                st.InvokeMember("Description", BindingFlags.SetProperty, null, sc, new object[] { description });
                st.InvokeMember("IconLocation", BindingFlags.SetProperty, null, sc, new object[] { icon + ",0" });
                st.InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                return File.Exists(lnk);
            }
            catch (Exception e) { Log.Error("WScript.Shell shortcut", e); return false; }
            finally
            {
                if (sc != null && System.Runtime.InteropServices.Marshal.IsComObject(sc)) System.Runtime.InteropServices.Marshal.ReleaseComObject(sc);
                if (shell != null && System.Runtime.InteropServices.Marshal.IsComObject(shell)) System.Runtime.InteropServices.Marshal.ReleaseComObject(shell);
            }
        }

        /// <summary>A shell link with LinkInfo (local path) and string data, [MS-SHLLINK] 2.1–2.4.</summary>
        public static byte[] ManagedLink(string target, string args, string workDir, string description, string icon)
        {
            var ms = new MemoryStream();
            var w = new BinaryWriter(ms);
            const uint HasLinkInfo = 0x2, HasName = 0x4, HasWorkingDir = 0x10, HasArguments = 0x20, HasIconLocation = 0x40, IsUnicode = 0x80;
            uint flags = HasLinkInfo | HasName | HasWorkingDir | HasIconLocation | IsUnicode | (string.IsNullOrEmpty(args) ? 0 : HasArguments);
            // ShellLinkHeader
            w.Write(0x4C);
            w.Write(new Guid("00021401-0000-0000-C000-000000000046").ToByteArray());
            w.Write(flags);
            w.Write(0x20u);                         // FILE_ATTRIBUTE_ARCHIVE
            long now = DateTime.UtcNow.ToFileTimeUtc();
            w.Write(now); w.Write(now); w.Write(now);
            long size = File.Exists(target) ? new FileInfo(target).Length : 0;
            w.Write((uint)Math.Min(size, uint.MaxValue));
            w.Write(0);                             // icon index
            w.Write(1);                             // SW_SHOWNORMAL
            w.Write((ushort)0); w.Write((ushort)0); w.Write(0); w.Write(0);
            // LinkInfo: VolumeID + LocalBasePath (ANSI and Unicode)
            var winTarget = target.Replace('/', '\\');
            var ansiPath = Encoding.Default.GetBytes(winTarget + "\0");
            var uniPath = Encoding.Unicode.GetBytes(winTarget + "\0");
            var volume = new byte[] { 0x11, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0x10, 0, 0, 0, 0 }; // size 17, DRIVE_FIXED, serial 0, label offset 16, ""
            const int headerSize = 0x24;
            int volOff = headerSize, baseOff = volOff + volume.Length, suffixOff = baseOff + ansiPath.Length;
            int uniBaseOff = suffixOff + 1, uniSuffixOff = uniBaseOff + uniPath.Length;
            int total = uniSuffixOff + 2;
            w.Write(total); w.Write(headerSize); w.Write(1u);  // VolumeIDAndLocalBasePath
            w.Write(volOff); w.Write(baseOff); w.Write(0); w.Write(suffixOff); w.Write(uniBaseOff); w.Write(uniSuffixOff);
            w.Write(volume); w.Write(ansiPath); w.Write((byte)0); w.Write(uniPath); w.Write((ushort)0);
            // StringData
            Action<string> str = s => { w.Write((ushort)s.Length); w.Write(Encoding.Unicode.GetBytes(s)); };
            str(description);
            str(workDir.Replace('/', '\\'));
            if (!string.IsNullOrEmpty(args)) str(args);
            str(icon.Replace('/', '\\'));
            w.Write(0);                             // TerminalBlock
            w.Flush();
            return ms.ToArray();
        }
    }
}
