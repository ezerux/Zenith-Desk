using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Threading;
using Microsoft.Win32;

namespace ZenithDesk.Setup
{
    public enum PrereqState { Ok, WillInstall, Blocked }

    public class Prereq
    {
        public string Key, Name, Detail;
        public PrereqState State;
        public string OfflineFile = "";   // a Microsoft installer the admin put next to setup.exe
        public override string ToString() { return Key + "=" + State + " (" + Detail + ")"; }
    }

    /// <summary>What Zenith Desk needs on the computer, and how to get what is missing (from Microsoft only).</summary>
    public static class Prereqs
    {
        public const long PayloadBytes = 4L * 1024 * 1024;     // program files (~2 MB) with room to spare
        public const long WebView2Bytes = 600L * 1024 * 1024;  // what the WebView2 Runtime takes when installed
        public const int NetFx48Release = 528040;

        static string Env(string name) { return Environment.GetEnvironmentVariable(name); }

        public static string WindowsName()
        {
            if (AppInfo.IsTest || !AppInfo.IsWindows) return Env("ZD_FAKE_OS") ?? "Windows 11 Pro (build 22631)";
            try
            {
                using (var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion"))
                {
                    var name = (k.GetValue("ProductName") ?? "Windows").ToString();
                    int build; int.TryParse((k.GetValue("CurrentBuildNumber") ?? "0").ToString(), out build);
                    if (build >= 22000) name = name.Replace("Windows 10", "Windows 11");  // Windows 11 still says "10" in ProductName
                    return name + " (build " + build + ")";
                }
            }
            catch { return Environment.OSVersion.VersionString; }
        }

        public static bool WindowsOk()
        {
            if (AppInfo.IsTest || !AppInfo.IsWindows) return (Env("ZD_FAKE_OS") ?? "Windows 11").Contains("Windows 1");
            return Environment.OSVersion.Version.Major >= 10;
        }

        public static int NetFxRelease()
        {
            if (AppInfo.IsTest || !AppInfo.IsWindows) { int r; return int.TryParse(Env("ZD_FAKE_NETFX"), out r) ? r : 533320; }
            try
            {
                using (var k = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey(@"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"))
                    return k == null ? 0 : Convert.ToInt32(k.GetValue("Release", 0));
            }
            catch { return 0; }
        }

        public static string NetFxName(int release)
        {
            return release >= 533320 ? "4.8.1" : release >= 528040 ? "4.8" : release >= 461808 ? "4.7.2" : release > 0 ? "4.x" : "—";
        }

        /// <summary>Installed WebView2 Runtime version, "" if none (registry places documented by Microsoft).</summary>
        public static string WebView2Version()
        {
            if (AppInfo.IsTest || !AppInfo.IsWindows) return Env("ZD_FAKE_WEBVIEW2") ?? "";
            var places = new List<Tuple<RegistryHive, RegistryView, string>> {
                Tuple.Create(RegistryHive.LocalMachine, RegistryView.Registry32, @"SOFTWARE\Microsoft\EdgeUpdate\Clients\" + AppInfo.WebView2ClientId),
                Tuple.Create(RegistryHive.LocalMachine, RegistryView.Registry64, @"SOFTWARE\Microsoft\EdgeUpdate\Clients\" + AppInfo.WebView2ClientId),
                Tuple.Create(RegistryHive.CurrentUser, RegistryView.Default, @"Software\Microsoft\EdgeUpdate\Clients\" + AppInfo.WebView2ClientId),
            };
            foreach (var p in places)
            {
                try
                {
                    using (var b = RegistryKey.OpenBaseKey(p.Item1, p.Item2))
                    using (var k = b.OpenSubKey(p.Item3))
                    {
                        var v = k == null ? "" : (k.GetValue("pv") ?? "").ToString();
                        if (v.Length > 0 && v != "0.0.0.0") return v;
                    }
                }
                catch { /* next place */ }
            }
            return "";
        }

        public static bool IsAdmin()
        {
            if (AppInfo.IsTest || !AppInfo.IsWindows) return Env("ZD_FAKE_NOADMIN") == null;
            try { return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator); }
            catch { return false; }
        }

        public static string SetupDir()
        {
            try { return Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName); }
            catch { return AppDomain.CurrentDomain.BaseDirectory; }
        }

        public static string OfflineWebView2()
        {
            foreach (var dir in new[] { SetupDir(), AppDomain.CurrentDomain.BaseDirectory })
                foreach (var name in new[] { "MicrosoftEdgeWebView2RuntimeInstallerX64.exe", "MicrosoftEdgeWebView2RuntimeInstallerX86.exe", "MicrosoftEdgeWebView2RuntimeInstallerARM64.exe", "MicrosoftEdgeWebview2Setup.exe" })
                {
                    var f = Path.Combine(dir ?? "", name);
                    if (File.Exists(f)) return f;
                }
            return "";
        }

        public static long FreeBytes(string dir)
        {
            try
            {
                var root = Path.GetPathRoot(Path.GetFullPath(dir));
                return new DriveInfo(root).AvailableFreeSpace;
            }
            catch { return long.MaxValue; }
        }

        public static List<Prereq> Check(string installDir)
        {
            var list = new List<Prereq>();
            var os = WindowsName();
            list.Add(new Prereq { Key = "os", Name = Lang.T("prereq.os"), State = WindowsOk() ? PrereqState.Ok : PrereqState.Blocked,
                                  Detail = WindowsOk() ? os : Lang.T("prereq.os_bad", os) });
            var rel = NetFxRelease();
            list.Add(new Prereq { Key = "netfx", Name = Lang.T("prereq.net"), State = rel >= NetFx48Release ? PrereqState.Ok : PrereqState.WillInstall,
                                  Detail = rel >= NetFx48Release ? Lang.T("prereq.net_ok", NetFxName(rel)) : Lang.T("prereq.net_missing") });
            var wv = WebView2Version();
            var wvItem = new Prereq { Key = "webview2", Name = Lang.T("prereq.wv") };
            if (wv.Length > 0) { wvItem.State = PrereqState.Ok; wvItem.Detail = Lang.T("prereq.wv_ok", wv); }
            else
            {
                wvItem.State = PrereqState.WillInstall; wvItem.OfflineFile = OfflineWebView2();
                wvItem.Detail = wvItem.OfflineFile.Length > 0 ? Lang.T("prereq.wv_offline", Path.GetFileName(wvItem.OfflineFile)) : Lang.T("prereq.wv_missing");
            }
            list.Add(wvItem);
            long need = PayloadBytes + (wv.Length > 0 ? 0 : WebView2Bytes), free = FreeBytes(installDir);
            list.Add(new Prereq { Key = "disk", Name = Lang.T("prereq.disk"), State = free >= need ? PrereqState.Ok : PrereqState.Blocked,
                                  Detail = free >= need ? Lang.T("prereq.disk_ok", AppInfo.FormatSize(free)) : Lang.T("prereq.disk_bad", AppInfo.FormatSize(need), AppInfo.FormatSize(free)) });
            var admin = IsAdmin();
            list.Add(new Prereq { Key = "admin", Name = Lang.T("prereq.admin"), State = admin ? PrereqState.Ok : PrereqState.Blocked,
                                  Detail = admin ? Lang.T("prereq.admin_ok") : Lang.T("prereq.admin_bad") });
            Log.Write("prerequisites: " + string.Join("; ", list.Select(p => p.ToString())));
            return list;
        }

        // ------------------------------------------------------------------ installing what is missing
        public delegate void ProgressFn(int percent, string detail);

        /// <summary>Downloads a Microsoft installer (only from go.microsoft.com links) and runs it silently.</summary>
        public static int InstallFromMicrosoft(string displayName, string url, string fileName, string args, string offlineFile, ProgressFn progress, CancellationToken ct)
        {
            if (AppInfo.IsTest || !AppInfo.IsWindows)
            {   // tests: pretend, and make the next check see the component
                for (int i = 0; i <= 100; i += 25) { progress(i, displayName); Thread.Sleep(60); }
                if (fileName.Contains("WebView2")) Environment.SetEnvironmentVariable("ZD_FAKE_WEBVIEW2", "130.0.2849.80");
                if (fileName.Contains("ndp48")) Environment.SetEnvironmentVariable("ZD_FAKE_NETFX", "528040");
                return 0;
            }
            string exe = offlineFile;
            if (string.IsNullOrEmpty(exe))
            {
                var dir = Path.Combine(Path.GetTempPath(), "ZenithDesk-Setup");
                Directory.CreateDirectory(dir);
                exe = Path.Combine(dir, fileName);
                using (var wc = new WebClient())
                {
                    Exception err = null;
                    var done = new ManualResetEventSlim();
                    wc.DownloadProgressChanged += (s, e) => progress(e.ProgressPercentage / 2, Lang.T("step.download", displayName) + "  " + AppInfo.FormatSize(e.BytesReceived));
                    wc.DownloadFileCompleted += (s, e) => { err = e.Error; done.Set(); };
                    Log.Write("download " + url + " -> " + exe);
                    wc.DownloadFileAsync(new Uri(url), exe);
                    while (!done.Wait(200)) if (ct.IsCancellationRequested) { wc.CancelAsync(); }
                    if (ct.IsCancellationRequested) throw new OperationCanceledException();
                    if (err != null) throw new Exception(Lang.T("step.download", displayName) + ": " + err.Message, err);
                }
            }
            progress(55, Lang.T("step.prereq", displayName));
            Log.Write("run " + exe + " " + args);
            var p = Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true });
            int pct = 55;
            while (!p.WaitForExit(500)) { if (pct < 95) pct++; progress(pct, Lang.T("step.prereq", displayName)); }
            Log.Write(displayName + " installer exit code " + p.ExitCode);
            progress(100, Lang.T("step.prereq", displayName));
            return p.ExitCode;
        }
    }
}
